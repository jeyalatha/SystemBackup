IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'ngplf_ngplf_plf_transferdata' AND TYPE = 'P')
	DROP PROC ngplf_ngplf_plf_transferdata
GO
/************************************************************************************/
/* Procedure					: ngplf_ngplf_plf_transferdata						*/
/* Description					: It migrates the data FROM NGPLF tables to			*/
/*									Platform Tables									*/
/************************************************************************************/
/* Development history			: 													*/
/************************************************************************************/
/* Author						: Jeyalatha K										*/
/* Date							: 12-Jun-2018										*/
/************************************************************************************/
/* ModIFication History			: 												    */
/************************************************************************************/
/* Modified by : Jeya Latha K/Venkatesan K	Date: 31-Oct-2018  Defect ID: TECH-28010*/  
/* Modified By : Jeya Latha K/Venkatesan K  Date: 04-Dec-2018  Defect ID: TECH-28806*/
/* Modified By : Jeya Latha K/Venkatesan K	Date: 06-Mar-2019  Defect ID: TECH-32100*/
/* Modified by : Jeya Latha K/Venkatesan K  Date: 17-Jun-2019  Defect ID: TECH-34971*/
/* Modified by : Jeya Latha K				Date: 01-Nov-2019  Defect ID: TECH-39534*/
/* Modified by : Manoj S					Date: 30-Nov-2022  Defect ID: TECH-75147*/
/************************************************************************************/
CREATE PROCEDURE ngplf_ngplf_plf_transferdata
	@ctxt_language		NGPLF_CTXT_LANGUAGE,
	@ctxt_ouinstance	NGPLF_CTXT_OUINSTANCE,
	@ctxt_user			NGPLF_CTXT_USER, 
	@ctxt_role			NGPLF_CTXT_ROLE, 
	@CustomerID			NGPLF_NAME,
	@ProjectID			NGPLF_NAME,
	@ProcessName		NGPLF_NAME,
	@ComponentName		NGPLF_NAME,
	@Docno				NGPLF_NAME,
	@ActivityName		NGPLF_NAME,
	@UIName				NGPLF_NAME,
	@GUID				NGPLF_NAME
AS
BEGIN

	SET NOCOUNT ON

	DECLARE	@tmp_reqno				NGPLF_NAME,
			@tmp_prevreqno			NGPLF_NAME,
			@tmp_UIDescription		NGPLF_NAME,
			@MaxHOrder				NGPLF_INT,
			@MaxVOrder				NGPLF_INT,
			@ngplf_sysdate			NGPLF_DATETIME,
			@IsAutoClose			NGPLF_FLAG,	
			@TargetSection			NGPLF_NAME,
			@TargetWidth			NGPLF_NAME,	
			@TargetHeight			NGPLF_NAME,
			@PopupStyle				NGPLF_NAME,
			@IsClosable				NGPLF_FLAG,
			@tmp_pagename			NGPLF_NAME,
			@tmp_sectionname		NGPLF_NAME,
			@tmp_ControlName		NGPLF_NAME,
			@tmp_viewname			NGPLF_NAME,
			@tmp_taskname			NGPLF_NAME,
			@tmp_popup_section		NGPLF_NAME,
			@tmp_ReverseEngineered	NGPLF_FLAG

	SET		@ngplf_sysdate			= Getdate()	
	SET		@tmp_reqno				= 'BASE'
	SET		@tmp_ReverseEngineered	= ''

	SELECT	@tmp_ReverseEngineered	= ReverseEngineered
	FROM	ngplf_ws_userinterface_info (nolock)
	WHERE	CustomerID				= @CustomerID
	AND		ProjectID				= @ProjectID
	AND		ComponentName			= @ComponentName				
	AND		ActivityName			= @ActivityName
	AND		UIName					= @UIName
	AND		GUID					= @GUID

	IF ISNULL(@ProcessName,'') = ''
	BEGIN
		SELECT	@ProcessName	= Process_Name
		FROM	ep_ui_req_dtl (nolock)
		WHERE	customer_name	= @CustomerID
		AND		project_name	= @ProjectID	
		AND		component_name	= @ComponentName
	END

	SELECT	@tmp_UIDescription	= LTRIM(RTRIM(ui_descr))
	FROM	ep_ui_req_dtl (nolock)
	WHERE	customer_name		=	@CustomerID
	AND		project_name		=	@ProjectID	
	AND		component_name		=	@ComponentName
	AND 	Activity_Name		=	@ActivityName
	AND		UI_Name				=	@UIName
	AND		req_no				=	@Docno	
	
	
	IF ISNULL(@tmp_ReverseEngineered, 'no')	= 'no'
	BEGIN

	-- UI Information
	IF Not Exists (SELECT 'X'
	FROM	ep_ui_mst (nolock)
	WHERE	customer_name		=	@CustomerID
	AND		project_name		=	@ProjectID	
	AND		component_name		=	@ComponentName
	AND 	Activity_Name		=	@ActivityName
	AND		UI_Name				=	@UIName
	)	
	BEGIN
		INSERT INTO ep_ui_mst						
						(customer_name,			project_name,		process_name,		component_name,			
						activity_name,			ui_name,			req_no,				ui_type,			
						state_processing,		callout_type,		Layout,				ui_subtype,		
						TabPosition,			tab_height,			TabRotation,
						ui_sysid,				ui_descr,			IsGlance,		
						SmartHide,			
						IsDesktop,			
						DeviceType,			
						DBName,					Timestamp,			CreatedBy,			wrkreqno,			
						CreatedDate,			ModIFiedBy,			ModIFiedDate,		current_req_no,
						grid_type)
					
		SELECT
						ui.CustomerID,			ui.ProjectID,		ui.ProcessName,		ui.ComponentName,		
						ui.ActivityName,		ui.UIName,			@tmp_reqno,			ui.UIType,			
						StateReqd,				CalloutType,		UILayout,			UISubType,			
						TabPosition,			ISNULL(TabHeight,400),				TabRotation,
						@GUID,					@tmp_UIDescription,	'Y',
						CASE SmartHideReqd
								WHEN 'Yes' then 'Y'
								ELSE 'N'
								END									'SmartHide',
						CASE DeviceType		
								WHEN	'Desktop' Then 'Y'
								ELSE	'N'	
								END									'IsDesktop',			
						CASE DeviceType	
								WHEN	'Phone'		Then 'P'
								WHEN	'Tablet'	Then 'T'
								ELSE	''	
								END									'DeviceType',			
						DBName,					1,					@ctxt_user,			@DocNo,	
						@ngplf_sysdate,			@ctxt_user,			@ngplf_sysdate,		@DocNo,
						'HTM'
		FROM	ngplf_wr_userinterface_info ui (nolock) LEFT OUTER JOIN
				ngplf_wr_uitab	 tab (nolock)

		ON		ui.CustomerID		= tab.CustomerID
		AND		ui.ProjectID		= tab.ProjectID
		AND		ui.ProcessName		= tab.ProcessName
		AND		ui.ComponentName	= tab.ComponentName
		AND		ui.ActivityName		= tab.ActivityName
		AND		ui.UIName			= tab.UIName
	--	AND		ui.DocNo			= tab.DocNo

		WHERE	ui.CustomerID		= @CustomerID
		AND		ui.ProjectID		= @ProjectID
		AND		ui.ProcessName		= @ProcessName
		AND		ui.ComponentName	= @ComponentName
		AND 	ui.ActivityName		= @ActivityName
		AND		ui.UIName			= @UIName
	--	AND		ui.DocNo			= @Docno
	END
	ELSE
	BEGIN
		UPDATE ui SET
						ui_type						= nui.UIType,
						state_processing			= nui.StateReqd,	
						callout_type				= nui.CalloutType,		
						Layout						= nui.UILayout,				
						ui_subtype					= nui.UISubType,		
						IsGlance					= 'Y',		
						SmartHide					= CASE nui.SmartHideReqd
														WHEN 'Yes' then 'Y' ELSE 'N' END	,			
						IsDesktop					= CASE nui.DeviceType		
														WHEN	'Desktop' Then 'Y' ELSE	'N'	 END	,			
						DeviceType					= CASE nui.DeviceType	
															WHEN	'Phone'		Then 'P'
															WHEN	'Tablet'	Then 'T' ELSE	''	END	,			
						HideIlbotitlemenu_req		= CASE nui.ILBOTitleMenuReqd
														WHEN 'No' then 'Y' ELSE 'N' END	,	
					--	wrkreqno					= @DocNo,							
						ModIFiedBy					= @ctxt_user,			
						ModIFiedDate				= getdate(),		
						current_req_no				= @DocNo
		FROM	ep_ui_mst ui (nolock),
				ngplf_wr_userinterface_info nui (nolock)
		WHERE	ui.customer_name	= nui.CustomerID
		AND		ui.project_name		= nui.ProjectID
		AND		ui.process_name		= nui.ProcessName
		AND		ui.component_name	= nui.ComponentName
		AND		ui.activity_name	= nui.ActivityName
		AND		ui.ui_name			= nui.UIName

		AND		ui.customer_name	= @CustomerID
		AND		ui.project_name		= @ProjectID
		AND		ui.process_name		= @ProcessName
		AND		ui.component_name	= @ComponentName
		AND 	ui.activity_name	= @ActivityName
		AND		ui.ui_name			= @UIName
		--AND		ui.req_no			= @Docno

		UPDATE ui SET						
						Layout			= met.parameter_code,
						ModIFiedBy		= @ctxt_user,			
						ModIFiedDate	= getdate()
		FROM	ep_ui_mst ui (nolock),
				ep_device_quick_code_met met (nolock)
		WHERE	ui.customer_name		= @CustomerID
		AND		ui.project_name			= @ProjectID
		AND		ui.process_name			= @ProcessName
		AND		ui.component_name		= @ComponentName
		AND 	ui.activity_name		= @ActivityName
		AND		ui.ui_name				= @UIName
		--AND		ui.req_no				= @Docno
		
		AND		met.parameter_type	= 'UILayout'
		AND		met.parameter_text	= ui.Layout
	END

	-- To Transfer the pages from NGPLF to Platform
	EXEC	ngplf_transfer_page 
							@ctxt_language		= @ctxt_language,
							@ctxt_ouinstance	= @ctxt_ouinstance,
							@ctxt_user			= @ctxt_user, 
							@ctxt_role			= @ctxt_role, 
							@CustomerID			= @CustomerID,
							@ProjectID			= @ProjectID,
							@ProcessName		= @ProcessName,
							@ComponentName		= @ComponentName,
							@Docno				= @Docno,
							@ActivityName		= @ActivityName,
							@UIName				= @UIName,
							@GUID				= @GUID
	
	-- To Transfer the Sections from NGPLF to Platform
	EXEC	ngplf_transfer_section
							@ctxt_language		= @ctxt_language,
							@ctxt_ouinstance	= @ctxt_ouinstance,
							@ctxt_user			= @ctxt_user, 
							@ctxt_role			= @ctxt_role, 
							@CustomerID			= @CustomerID,
							@ProjectID			= @ProjectID,
							@ProcessName		= @ProcessName,
							@ComponentName		= @ComponentName,
							@Docno				= @Docno,
							@ActivityName		= @ActivityName,
							@UIName				= @UIName,
							@GUID				= @GUID
		--Code Added for Defect ID : TECH-39534 Starts
				Exec	plf_section_control_movement  
								@ctxt_language		= @ctxt_language, 
								@ctxt_ouinstance	= @ctxt_ouinstance , 
								@ctxt_user			= @ctxt_user, 
								@ctxt_role			= @ctxt_role, 
								@CustomerID			= @CustomerID, 
								@ProjectID			= @ProjectID, 
								@ProcessName		= @ProcessName , 
								@ComponentName		= @ComponentName,  
								@Docno				= @DocNo,
								@ActivityName		= @ActivityName,         
								@UIName				= @UIName,   
								@GUID				= @GUID, 
								@uilayoutjson		= ''

	-- To Delete the Grid Column/Controls/Sections/Pages marked for Deletion
	EXEC	ngplf_delete_plfnodes 
						@ctxt_language		= @ctxt_language,
						@ctxt_ouinstance	= @ctxt_ouinstance,
						@ctxt_user			= @ctxt_user, 
						@ctxt_role			= @ctxt_role, 
						@CustomerID			= @CustomerID,
						@ProjectID			= @ProjectID,
						@ProcessName		= @ProcessName,
						@ComponentName		= @ComponentName,
						@Docno				= @Docno,
						@ActivityName		= @ActivityName,
						@UIName				= @UIName,
						@GUID				= @GUID	

		--Code Added for Defect ID : TECH-39534 Ends
-- To Transfer the Controls from NGPLF to Platform
	EXEC	ngplf_transfer_control
							@ctxt_language		= @ctxt_language,
							@ctxt_ouinstance	= @ctxt_ouinstance,
							@ctxt_user			= @ctxt_user, 
							@ctxt_role			= @ctxt_role, 
							@CustomerID			= @CustomerID,
							@ProjectID			= @ProjectID,
							@ProcessName		= @ProcessName,
							@ComponentName		= @ComponentName,
							@Docno				= @Docno,
							@ActivityName		= @ActivityName,
							@UIName				= @UIName,
							@GUID				= @GUID
	
-- To Transfer the Grid Columns from NGPLF to Platform
	EXEC	ngplf_transfer_gridcolumn
							@ctxt_language		= @ctxt_language,
							@ctxt_ouinstance	= @ctxt_ouinstance,
							@ctxt_user			= @ctxt_user, 
							@ctxt_role			= @ctxt_role, 
							@CustomerID			= @CustomerID,
							@ProjectID			= @ProjectID,
							@ProcessName		= @ProcessName,
							@ComponentName		= @ComponentName,
							@Docno				= @Docno,
							@ActivityName		= @ActivityName,
							@UIName				= @UIName,
							@GUID				= @GUID

-- To Transfer the Radio Buttons & Enumerated Combos from NGPLF to Platform
	EXEC	ngplf_transfer_radio_enum
							@ctxt_language		= @ctxt_language,
							@ctxt_ouinstance	= @ctxt_ouinstance,
							@ctxt_user			= @ctxt_user, 
							@ctxt_role			= @ctxt_role, 
							@CustomerID			= @CustomerID,
							@ProjectID			= @ProjectID,
							@ProcessName		= @ProcessName,
							@ComponentName		= @ComponentName,
							@Docno				= @Docno,
							@ActivityName		= @ActivityName,
							@UIName				= @UIName,
							@GUID				= @GUID

-- To Transfer the ListEdit Contorls from NGPLF to Platform
	EXEC	ngplf_transfer_listedit
							@ctxt_language		= @ctxt_language,
							@ctxt_ouinstance	= @ctxt_ouinstance,
							@ctxt_user			= @ctxt_user, 
							@ctxt_role			= @ctxt_role, 
							@CustomerID			= @CustomerID,
							@ProjectID			= @ProjectID,
							@ProcessName		= @ProcessName,
							@ComponentName		= @ComponentName,
							@Docno				= @Docno,
							@ActivityName		= @ActivityName,
							@UIName				= @UIName,
							@GUID				= @GUID
							
-- To Transfer Chart Contorls from NGPLF to Platform
	EXEC	ngplf_transfer_chart
							@ctxt_language		= @ctxt_language,
							@ctxt_ouinstance	= @ctxt_ouinstance,
							@ctxt_user			= @ctxt_user, 
							@ctxt_role			= @ctxt_role, 
							@CustomerID			= @CustomerID,
							@ProjectID			= @ProjectID,
							@ProcessName		= @ProcessName,
							@ComponentName		= @ComponentName,
							@Docno				= @Docno,
							@ActivityName		= @ActivityName,
							@UIName				= @UIName,
							@GUID				= @GUID

-- To Transfer Pivot Contorls from NGPLF to Platform
	EXEC	ngplf_transfer_pivot
							@ctxt_language		= @ctxt_language,
							@ctxt_ouinstance	= @ctxt_ouinstance,
							@ctxt_user			= @ctxt_user, 
							@ctxt_role			= @ctxt_role, 
							@CustomerID			= @CustomerID,
							@ProjectID			= @ProjectID,
							@ProcessName		= @ProcessName,
							@ComponentName		= @ComponentName,
							@Docno				= @Docno,
							@ActivityName		= @ActivityName,
							@UIName				= @UIName,
							@GUID				= @GUID

-- To transfer column group information
	EXEC	ngplf_transfer_columngroup
							@ctxt_language		= @ctxt_language,
							@ctxt_ouinstance	= @ctxt_ouinstance,
							@ctxt_user			= @ctxt_user, 
							@ctxt_role			= @ctxt_role, 
							@CustomerID			= @CustomerID,
							@ProjectID			= @ProjectID,
							@ProcessName		= @ProcessName,
							@ComponentName		= @ComponentName,
							@Docno				= @Docno,
							@ActivityName		= @ActivityName,
							@UIName				= @UIName,
							@GUID				= @GUID

-- To transfer grid extension information

	EXEC	ngplf_transfer_gridextension
							@ctxt_language		= @ctxt_language,
							@ctxt_ouinstance	= @ctxt_ouinstance,
							@ctxt_user			= @ctxt_user, 
							@ctxt_role			= @ctxt_role, 
							@CustomerID			= @CustomerID,
							@ProjectID			= @ProjectID,
							@ProcessName		= @ProcessName,
							@ComponentName		= @ComponentName,
							@Docno				= @Docno,
							@ActivityName		= @ActivityName,
							@UIName				= @UIName,
							@GUID				= @GUID

-- To populate the Hidden Views
	insert into de_hidden_view 
					(customer_name,				project_name,				process_name,					component_name,				
					activity_name,				ui_name,					page_name,						section_name,			
					control_bt_synonym,			hidden_view_bt_synonym,		transfer_flag,					hidden_view_sysid,		
					control_sysid,				timestamp,					createdby, 						createddate,			
					modIFiedby,					modIFieddate,				control_id,						view_name, 
					new_control_bt_synonym,		HIDDEN_VIEW_SOURCE,			ecrno,							IsGlance)  
	SELECT			
					hdn.CustomerID,				hdn.ProjectID,				hdn.ProcessName,				hdn.ComponentName,				
					hdn.ActivityName,			hdn.UIName,					hdn.PageName,					hdn.SectionName,			
					ctl.BTSynonymName,			hdn.BTSynonymName,			'N',							@GUID,		
					@GUID,						1,							@ctxt_user, 					@ngplf_sysdate,			
					@ctxt_user,					@ngplf_sysdate,				ctl.ControlName,--hdn.AssociatedControlName,		
					hdn.AssociatedViewName, 
					hdn.BTSynonymName,			NULL,						@tmp_reqno,						'Y'
	FROM	ngplf_wr_system_entity hdn (nolock),
			ngplf_wr_controlcolumn_vw ctl (nolock)
	WHERE	hdn.CustomerID		= @CustomerID
	AND		hdn.ProjectID		= @ProjectID
	AND		hdn.ProcessName		= @ProcessName
	AND		hdn.ComponentName	= @ComponentName
	AND 	hdn.ActivityName	= @ActivityName
	AND		hdn.UIName			= @UIName
--	AND		hdn.DocNo			= @Docno
	
	AND		hdn.CustomerID		= ctl.CustomerID
	AND		hdn.ProjectID		= ctl.ProjectID
	AND		hdn.ProcessName		= ctl.ProcessName
	AND		hdn.ComponentName	= ctl.ComponentName
	AND		hdn.ActivityName	= ctl.ActivityName
	AND		hdn.UIName			= ctl.UIName	
	AND		hdn.PageName		= ctl.PageName
	AND		hdn.SectionName		= ctl.SectionName
	AND		hdn.ControlName		= ctl.ControlName	
	AND		hdn.ViewName		= ctl.ViewName
	AND		hdn.DerivedEntity	= 'HiddenView'
	AND		hdn.DerivedFor	NOT IN ('SegmentButton','Enum','EditMask', 'HiddenView','StateEnabled','treegrid','tree')

	AND		NOT EXISTS (SELECT 'X'
						FROM	de_hidden_view (nolock)
						WHERE	customer_name			= hdn.CustomerID
						AND		project_name			= hdn.ProjectID
						AND		process_name			= hdn.ProcessName
						AND		component_name			= hdn.ComponentName
						AND		activity_name			= hdn.ActivityName
						AND		ui_name					= hdn.UIName
						AND		page_name				= hdn.PageName
						AND		section_name			= hdn.SectionName						
						AND		hidden_view_bt_synonym	= hdn.BTSynonymName
						AND		control_id				= ctl.ControlName--hdn.AssociatedControlName
						AND		view_name				= hdn.AssociatedViewName
						)


	-- Added on 11th Sep
	---- Task Information
	INSERT INTO ep_action_mst
					(customer_name,			project_name,			process_name,			component_name,		
					activity_name,			ui_name,				page_bt_synonym,		req_no,				
					task_name,				task_descr,				task_seq,				task_pattern,	-- ??	
					primary_control_bts,	Act_flag,				task_type,				Timestamp,			
					CreatedBy,				CreatedDate,			ModIFiedBy,				ModIFiedDate,
					wrkreqno--,				TargetComponent,		TargetActivity,			TargetILBO,
					--TargetSection,			TargetHeight,			TargetWidth	
					)
	SELECT 
					tsk.CustomerID,			tsk.ProjectID,			tsk.ProcessName,		tsk.ComponentName,		
					tsk.ActivityName,		tsk.UIName,				ctl.PageName,			@tmp_reqno,				
					tsk.TaskName,			tsk.TaskDescription,	1,						TaskPattern,		
					BTSynonymName,			ActiveFlag,				TaskType,				1,			
					@ctxt_user,				@ngplf_sysdate,			@ctxt_user,				@ngplf_sysdate,
					@tmp_reqno
	FROM	ngplf_wr_task tsk (nolock),
			ngplf_wr_controlcolumn_vw ctl (nolock)
	WHERE	tsk.CustomerID		= @CustomerID
	AND		tsk.ProjectID		= @ProjectID
	AND		tsk.ProcessName		= @ProcessName
	AND		tsk.ComponentName	= @ComponentName
	AND 	tsk.ActivityName	= @ActivityName
	AND		tsk.UIName			= @UIName
--	AND		tsk.DocNo			= @Docno

	AND		tsk.CustomerID		= ctl.CustomerID
	AND		tsk.ProjectID		= ctl.ProjectID
	AND		tsk.ProcessName		= ctl.ProcessName
	AND		tsk.ComponentName	= ctl.ComponentName
	AND		tsk.ActivityName	= ctl.ActivityName
	AND		tsk.UIName			= ctl.UIName	
	AND		tsk.TriggeringControlName= ctl.ControlName	
	AND		tsk.TriggeringViewName= ctl.ViewName
	AND		NOT EXISTS (SELECT 'X'
						FROM	ep_action_mst (nolock)
						WHERE	customer_name	= tsk.CustomerID
						AND		project_name	= tsk.ProjectID
						AND		process_name	= tsk.ProcessName
						AND		component_name	= tsk.ComponentName
						AND		activity_name	= tsk.ActivityName
						AND		ui_name			= tsk.UIName
						AND		task_name		= tsk.TaskName )
	UNION
		SELECT 
					tsk.CustomerID,			tsk.ProjectID,			tsk.ProcessName,		tsk.ComponentName,		
					tsk.ActivityName,		tsk.UIName,				ctl.PageName,			@tmp_reqno,				
					tsk.TaskName,			tsk.TaskDescription,	1,						TaskPattern,		
					BTSynonymName,			ActiveFlag,				TaskType,				1,			
					@ctxt_user,				@ngplf_sysdate,			@ctxt_user,				@ngplf_sysdate,
					@tmp_reqno
	FROM	ngplf_wr_task tsk (nolock),
			ngplf_wr_control ctl (nolock)
	WHERE	tsk.CustomerID		= @CustomerID
	AND		tsk.ProjectID		= @ProjectID
	AND		tsk.ProcessName		= @ProcessName
	AND		tsk.ComponentName	= @ComponentName
	AND 	tsk.ActivityName	= @ActivityName
	AND		tsk.UIName			= @UIName
--	AND		tsk.DocNo			= @Docno

	AND		tsk.CustomerID		= ctl.CustomerID
	AND		tsk.ProjectID		= ctl.ProjectID
	AND		tsk.ProcessName		= ctl.ProcessName
	AND		tsk.ComponentName	= ctl.ComponentName
	AND		tsk.ActivityName	= ctl.ActivityName
	AND		tsk.UIName			= ctl.UIName	
	AND		tsk.TriggeringControlName= ctl.ControlName	
	AND		tsk.TriggeringViewName= ctl.ViewName
	AND		NOT EXISTS (SELECT 'X'
						FROM	ep_action_mst (nolock)
						WHERE	customer_name	= tsk.CustomerID
						AND		project_name	= tsk.ProjectID
						AND		process_name	= tsk.ProcessName
						AND		component_name	= tsk.ComponentName
						AND		activity_name	= tsk.ActivityName
						AND		ui_name			= tsk.UIName
						AND		task_name		= tsk.TaskName )
	UNION
	SELECT 
					tsk.CustomerID,			tsk.ProjectID,			tsk.ProcessName,		tsk.ComponentName,		
					tsk.ActivityName,		tsk.UIName,				'[mainscreen]',			@tmp_reqno,				
					tsk.TaskName,			tsk.TaskDescription,	1,						TaskPattern,		
					'[None]',			ActiveFlag,				TaskType,				1,			
					@ctxt_user,				@ngplf_sysdate,			@ctxt_user,				@ngplf_sysdate,
					@tmp_reqno
	FROM	ngplf_wr_task tsk (nolock)
	WHERE	tsk.CustomerID		= @CustomerID
	AND		tsk.ProjectID		= @ProjectID
	AND		tsk.ProcessName		= @ProcessName
	AND		tsk.ComponentName	= @ComponentName
	AND 	tsk.ActivityName	= @ActivityName
	AND		tsk.UIName			= @UIName
---	AND		tsk.DocNo			= @Docno
	AND		tsk.TriggeringControlName= '[None]'
	AND		tsk.TriggeringViewName= '[None]'

	AND		NOT EXISTS (SELECT 'X'
						FROM	ep_action_mst (nolock)
						WHERE	customer_name	= tsk.CustomerID
						AND		project_name	= tsk.ProjectID
						AND		process_name	= tsk.ProcessName
						AND		component_name	= tsk.ComponentName
						AND		activity_name	= tsk.ActivityName
						AND		ui_name			= tsk.UIName
						AND		task_name		= tsk.TaskName )


	INSERT INTO ep_action_mst
					(customer_name,			project_name,			process_name,			component_name,		
					activity_name,			ui_name,				page_bt_synonym,		req_no,				
					task_name,				task_descr,				task_seq,				task_pattern,	-- ??	
					primary_control_bts,	Act_flag,				task_type,				Timestamp,			
					CreatedBy,				CreatedDate,			ModIFiedBy,				ModIFiedDate,
					wrkreqno--,				TargetComponent,		TargetActivity,			TargetILBO,
					--TargetSection,			TargetHeight,			TargetWidth	
					)

	SELECT 
					tsk.CustomerID,			tsk.ProjectID,			tsk.ProcessName,		tsk.ComponentName,		
					tsk.ActivityName,		tsk.UIName,				tmp.PageName,			@tmp_reqno,				
					tsk.TaskName,			tsk.TaskDescription,	1,						TaskPattern,		
					--ctl.BTSynonymName,		ActiveFlag,				tsk.TaskType,				1,			
					tmp.ControlName+'_'+tmp.ActionName,	ActiveFlag,	tsk.TaskType,			1,			
					@ctxt_user,				@ngplf_sysdate,			@ctxt_user,				@ngplf_sysdate,
					@tmp_reqno
	FROM	ngplf_wr_task tsk (nolock),
			ngplf_wr_template_action tmp (nolock),
			ngplf_wr_control ctl (nolock)
	WHERE	tsk.CustomerID		= @CustomerID
	AND		tsk.ProjectID		= @ProjectID
	AND		tsk.ProcessName		= @ProcessName
	AND		tsk.ComponentName	= @ComponentName
	AND 	tsk.ActivityName	= @ActivityName
	AND		tsk.UIName			= @UIName
--	AND		tsk.DocNo			= @Docno

	AND		tsk.CustomerID		= tmp.CustomerID
	AND		tsk.ProjectID		= tmp.ProjectID
	AND		tsk.ProcessName		= tmp.ProcessName
	AND		tsk.ComponentName	= tmp.ComponentName
	AND		tsk.ActivityName	= tmp.ActivityName
	AND		tsk.UIName			= tmp.UIName	
	AND		tsk.TriggeringControlName= tmp.ControlName	
	AND		tsk.TriggeringViewName= tmp.ActionName	
	AND		tsk.TaskName		= tmp.TaskName
	

	AND		ctl.CustomerID		= tmp.CustomerID
	AND		ctl.ProjectID		= tmp.ProjectID
	AND		ctl.ProcessName		= tmp.ProcessName
	AND		ctl.ComponentName	= tmp.ComponentName
	AND		ctl.ActivityName	= tmp.ActivityName
	AND		ctl.UIName			= tmp.UIName	
	AND		ctl.PageName		= tmp.PageName
	AND		ctl.SectionName		= tmp.SectionName
	AND		ctl.ControlName		= tmp.ControlName
	AND		NOT EXISTS (SELECT 'X'
						FROM	ep_action_mst (nolock)
						WHERE	customer_name	= tsk.CustomerID
						AND		project_name	= tsk.ProjectID
						AND		process_name	= tsk.ProcessName
						AND		component_name	= tsk.ComponentName
						AND		activity_name	= tsk.ActivityName
						AND		ui_name			= tsk.UIName
						AND		task_name		= tsk.TaskName )

	INSERT INTO ep_action_mst
					(customer_name,			project_name,			process_name,			component_name,		
					activity_name,			ui_name,				page_bt_synonym,		req_no,				
					task_name,				task_descr,				task_seq,				task_pattern,	
					primary_control_bts,	Act_flag,				task_type,				Timestamp,			
					CreatedBy,				CreatedDate,			ModIFiedBy,				ModIFiedDate,
					wrkreqno
					)

	SELECT 
					tsk.CustomerID,			tsk.ProjectID,			tsk.ProcessName,		tsk.ComponentName,		
					tsk.ActivityName,		tsk.UIName,				pag.PageName,			@tmp_reqno,				
					tsk.TaskName,			tsk.TaskDescription,	1,						TaskPattern,							
					pag.PageName,			ActiveFlag,				tsk.TaskType,			1,			
					@ctxt_user,				@ngplf_sysdate,			@ctxt_user,				@ngplf_sysdate,
					@tmp_reqno
	FROM	ngplf_wr_task tsk (nolock),
			ngplf_wr_page pag (nolock)
	WHERE	tsk.CustomerID		= @CustomerID
	AND		tsk.ProjectID		= @ProjectID
	AND		tsk.ProcessName		= @ProcessName
	AND		tsk.ComponentName	= @ComponentName
	AND 	tsk.ActivityName	= @ActivityName
	AND		tsk.UIName			= @UIName
--	AND		tsk.DocNo			= @Docno

	AND		tsk.CustomerID		= pag.CustomerID
	AND		tsk.ProjectID		= pag.ProjectID
	AND		tsk.ProcessName		= pag.ProcessName
	AND		tsk.ComponentName	= pag.ComponentName
	AND		tsk.ActivityName	= pag.ActivityName
	AND		tsk.UIName			= pag.UIName	
	AND		tsk.TriggeringControlName= pag.pagename	
	AND		tsk.TriggeringViewName= pag.pagename	
	
	
	AND		NOT EXISTS (SELECT 'X'
						FROM	ep_action_mst (nolock)
						WHERE	customer_name	= tsk.CustomerID
						AND		project_name	= tsk.ProjectID
						AND		process_name	= tsk.ProcessName
						AND		component_name	= tsk.ComponentName
						AND		activity_name	= tsk.ActivityName
						AND		ui_name			= tsk.UIName
						AND		task_name		= tsk.TaskName )


	INSERT INTO ep_action_mst_lng_extn
					(customer_name,			project_name,			process_name,			component_name,		
					activity_name,			ui_name,				page_bt_synonym,		req_no,				
					task_name,				task_descr,				task_seq,				task_pattern,	
					task_type,				primary_control_bts,	Timestamp,				languageid,
					CreatedBy,				CreatedDate,			ModIFiedBy,				ModIFiedDate,
					wrkreqno)
	SELECT	distinct
					lng.CustomerID,			lng.ProjectID,			lng.ProcessName,		lng.ComponentName,		
					lng.ActivityName,		lng.UIName,				ctl.PageName,			@tmp_reqno,				
					lng.TaskName,			lng.TaskDescription,	1,						tsk.TaskPattern,	
					tsk.TaskType,			BTSynonymName,			1,						languageid,
					@ctxt_user,				@ngplf_sysdate,			@ctxt_user,				@ngplf_sysdate,
					@tmp_reqno
	FROM	ngplf_wr_task_local_info lng (nolock),
			ngplf_wr_task	tsk (nolock),
			ngplf_wr_controlcolumn_vw ctl (nolock)
	WHERE	lng.CustomerID		= @CustomerID
	AND		lng.ProjectID		= @ProjectID
	AND		lng.ProcessName		= @ProcessName
	AND		lng.ComponentName	= @ComponentName
	AND 	lng.ActivityName	= @ActivityName
	AND		lng.UIName			= @UIName
--	AND		lng.DocNo			= @Docno

	AND		lng.CustomerID		= tsk.CustomerID
	AND		lng.ProjectID		= tsk.ProjectID	
	AND		lng.ProcessName		= tsk.ProcessName
	AND		lng.ComponentName	= tsk.ComponentName
	AND		lng.ActivityName	= tsk.ActivityName
	AND		lng.UIName			= tsk.UIName
	AND		lng.TaskName		= tsk.TaskName
	

	AND		lng.CustomerID		= ctl.CustomerID
	AND		lng.ProjectID		= ctl.ProjectID
	AND		lng.ProcessName		= ctl.ProcessName
	AND		lng.ComponentName	= ctl.ComponentName
	AND		lng.ActivityName	= ctl.ActivityName
	AND		lng.UIName			= ctl.UIName	
	--AND		tsk.PageName		= ctl.PageName
	AND		tsk.TriggeringControlName= ctl.ControlName	
	AND		tsk.TriggeringViewName= ctl.ViewName	
	AND		lng.LanguageID		=	@ctxt_language
	AND		NOT EXISTS (SELECT 'X'
						FROM	ep_action_mst_lng_extn (nolock)
						WHERE	customer_name	= lng.CustomerID
						AND		project_name	= lng.ProjectID
						AND		process_name	= lng.ProcessName
						AND		component_name	= lng.ComponentName
						AND		activity_name	= lng.ActivityName
						AND		ui_name			= lng.UIName
						AND		task_name		= lng.TaskName
						AND		languageid		= lng.LanguageID )
	UNION
	SELECT	distinct
					lng.CustomerID,			lng.ProjectID,			lng.ProcessName,		lng.ComponentName,		
					lng.ActivityName,		lng.UIName,				'[mainscreen]',			@tmp_reqno,				
					lng.TaskName,			lng.TaskDescription,	1,						tsk.TaskPattern,	
					tsk.TaskType,			'[None]',			1,						languageid,
					@ctxt_user,				@ngplf_sysdate,			@ctxt_user,				@ngplf_sysdate,
					@tmp_reqno
	FROM	ngplf_wr_task_local_info lng (nolock),
			ngplf_wr_task	tsk (nolock)
	WHERE	lng.CustomerID		= @CustomerID
	AND		lng.ProjectID		= @ProjectID
	AND		lng.ProcessName		= @ProcessName
	AND		lng.ComponentName	= @ComponentName
	AND 	lng.ActivityName	= @ActivityName
	AND		lng.UIName			= @UIName
--	AND		lng.DocNo			= @Docno

	AND		lng.CustomerID		= tsk.CustomerID
	AND		lng.ProjectID		= tsk.ProjectID	
	AND		lng.ProcessName		= tsk.ProcessName
	AND		lng.ComponentName	= tsk.ComponentName
	AND		lng.ActivityName	= tsk.ActivityName
	AND		lng.UIName			= tsk.UIName
	AND		lng.TaskName		= tsk.TaskName
	AND		lng.LanguageID		=	@ctxt_language
	AND		tsk.TriggeringControlName= '[None]'
	AND		tsk.TriggeringViewName= '[None]'

	AND		NOT EXISTS (SELECT 'X'
						FROM	ep_action_mst_lng_extn (nolock)
						WHERE	customer_name	= lng.CustomerID
						AND		project_name	= lng.ProjectID
						AND		process_name	= lng.ProcessName
						AND		component_name	= lng.ComponentName
						AND		activity_name	= lng.ActivityName
						AND		ui_name			= lng.UIName
						AND		task_name		= lng.TaskName
						AND		languageid		= lng.LanguageID )

	UNION
	SELECT	distinct
					lng.CustomerID,			lng.ProjectID,			lng.ProcessName,		lng.ComponentName,		
					lng.ActivityName,		lng.UIName,				pag.PageName,			@tmp_reqno,				
					lng.TaskName,			lng.TaskDescription,	1,						tsk.TaskPattern,	
					tsk.TaskType,			BTSynonymName,			1,						languageid,
					@ctxt_user,				@ngplf_sysdate,			@ctxt_user,				@ngplf_sysdate,
					@tmp_reqno
	FROM	ngplf_wr_task_local_info lng (nolock),
			ngplf_wr_task	tsk (nolock),
			ngplf_wr_page pag (nolock)
	WHERE	lng.CustomerID		= @CustomerID
	AND		lng.ProjectID		= @ProjectID
	AND		lng.ProcessName		= @ProcessName
	AND		lng.ComponentName	= @ComponentName
	AND 	lng.ActivityName	= @ActivityName
	AND		lng.UIName			= @UIName
--	AND		lng.DocNo			= @Docno

	AND		lng.CustomerID		= tsk.CustomerID
	AND		lng.ProjectID		= tsk.ProjectID	
	AND		lng.ProcessName		= tsk.ProcessName
	AND		lng.ComponentName	= tsk.ComponentName
	AND		lng.ActivityName	= tsk.ActivityName
	AND		lng.UIName			= tsk.UIName
	AND		lng.TaskName		= tsk.TaskName
	

	AND		lng.CustomerID		= pag.CustomerID
	AND		lng.ProjectID		= pag.ProjectID
	AND		lng.ProcessName		= pag.ProcessName
	AND		lng.ComponentName	= pag.ComponentName
	AND		lng.ActivityName	= pag.ActivityName
	AND		lng.UIName			= pag.UIName		
	AND		tsk.TriggeringControlName= pag.PageName	
	AND		tsk.TriggeringViewName= pag.PageName	
	AND		lng.LanguageID		=	@ctxt_language
	AND		NOT EXISTS (SELECT 'X'
						FROM	ep_action_mst_lng_extn (nolock)
						WHERE	customer_name	= lng.CustomerID
						AND		project_name	= lng.ProjectID
						AND		process_name	= lng.ProcessName
						AND		component_name	= lng.ComponentName
						AND		activity_name	= lng.ActivityName
						AND		ui_name			= lng.UIName
						AND		task_name		= lng.TaskName
						AND		languageid		= lng.LanguageID )
	--task_type_starts --TECH-75147
	  IF EXISTS(   
   SELECT  'X'
   FROM ngplf_wr_task (nolock)  
   WHERE CustomerID   = @CustomerID  
   AND  ProjectID   = @ProjectID  
   AND  ProcessName   = @ProcessName  
   AND  ComponentName  = @ComponentName      
   AND  ActivityName  = @ActivityName  
   AND  UIName    = @UIName  
   AND  Tasktype   = 'Report' )
   begin 
   update mst
  set mst.task_type = wr.tasktype
  from ep_action_mst mst(nolock),
  ngplf_wr_task wr(nolock)
  where mst.customer_name = wr.CustomerID
  and mst.project_name = wr.ProjectID
  and mst.process_name = wr.processname
  and mst.component_name =wr.componentname
  and mst.activity_name = wr.activityname
  and mst.ui_name = wr.uiname
  and mst.task_name = wr.taskname
  and  mst.customer_name = @CustomerID 
  and mst.project_name = @ProjectID  
  and mst.process_name = @ProcessName  
  and mst.component_name =@ComponentName  
  and mst.activity_name = @ActivityName  
  and mst.ui_name = @UIName 
  and wr.Tasktype   = 'Report'  
   end

   --task_type_ends  --TECH-75147
	-- To Update Popup, CallOut & smart View Section Details in Action Table
	SET		@tmp_pagename		= ''
	SET		@tmp_sectionname	= ''	
	SET		@tmp_ControlName	= ''
	SET		@tmp_viewname		= ''
	SET		@tmp_taskname		= ''

	DECLARE getPopups CURSOR FOR
	SELECT	PageName,		SectionName, 	ControlName,	ViewName,
			IsAutoClose,	TargetSection,	TargetWidth,	TargetHeight
	FROM	ngplf_wr_common_properties (nolock)
	WHERE	CustomerID		= @CustomerID
	AND		ProjectID		= @ProjectID
	AND		ProcessName		= @ProcessName
	AND		ComponentName	= @ComponentName				
	AND		ActivityName	= @ActivityName
	AND		UIName			= @UIName
	AND		HasPopup		= 'yes'
	ORDER BY PageName,	SectionName, 	ControlName,	ViewName

	OPEN getPopups
	
	FETCH NEXT FROM getPopups into 
				@tmp_pagename,	@tmp_sectionname,	@tmp_ControlName,	@tmp_viewname,
				@IsAutoClose,	@TargetSection,		@TargetWidth,		@TargetHeight
			
	WHILE @@FETCH_STATUS = 0
	BEGIN	
		
			SELECT  @tmp_pagename		= PageName,
					@tmp_popup_section	= sectionname,
					@PopupStyle			= PopupStyle,
					@IsClosable			= IsClosable
			FROM	ngplf_wr_Section (nolock)
			WHERE	CustomerID			= @CustomerID
			AND		ProjectID			= @ProjectID
			AND		ProcessName			= @ProcessName
			AND		ComponentName		= @ComponentName				
			AND		ActivityName		= @ActivityName
			AND		UIName				= @UIName
			AND		btsynonymname		= @TargetSection -- check
			AND		SectionType			= 'Popup'

			--select 'tt', @tmp_pagename, @tmp_popup_section, @PopupStyle,@IsClosable

			SELECT	@tmp_taskname	= TaskName
			FROM	ngplf_wr_task (nolock)
			WHERE	CustomerID		= @CustomerID
			AND		ProjectID		= @ProjectID
			AND		ProcessName		= @ProcessName
			AND		ComponentName	= @ComponentName				
			AND		ActivityName	= @ActivityName
			AND		UIName			= @UIName
			AND		TriggeringControlName = @tmp_ControlName
			AND		TriggeringViewName	= @tmp_viewname

			UPDATE ep_action_mst SET
							PopUp_page_bt_synonym	= @tmp_pagename,
							PopUp_section			= @tmp_popup_section,
							PopUp_close				= @IsClosable,
							--Popup_onclick_close		= @IsAutoClose,
							Popup_onclick_close		= case @IsAutoClose when 'yes' THEN '1' when 'no' THEN '0' ELSE NULL END,
							sectionlaunchtype		= case @PopupStyle WHEN 'Popup' THEN ''
																	ELSE @PopupStyle
														END
			WHERE	customer_name		= @CustomerID
			AND		project_name		= @ProjectID
			AND		process_name		= @ProcessName
			AND		component_name		= @ComponentName				
			AND		activity_name		= @ActivityName
			AND		ui_name				= @UIName
			AND		task_name			= @tmp_taskname

		FETCH NEXT FROM getPopups into 
				@tmp_pagename, @tmp_sectionname,	@tmp_ControlName,	@tmp_viewname,
				@IsAutoClose,	@TargetSection,		@TargetWidth,		@TargetHeight
	END
	CLOSE getPopups
	DEALLOCATE getPopups


	DELETE 
	FROM	ep_action_mst
	WHERE	customer_name		=	@CustomerID
	AND		project_name		=	@ProjectID
	AND		process_name		=	@ProcessName
	AND		component_name		=	@ComponentName
	AND		activity_name		=	@ActivityName
	AND		ui_name				=	@UIName
	AND		primary_control_bts <>	'[None]'
	AND		task_name NOT IN (SELECT DISTINCT TaskName
							FROM	ngplf_wr_task (nolock)
							WHERE	CustomerID		= @CustomerID
							AND		ProjectID		= @ProjectID
							AND		ProcessName		= @ProcessName
							AND		ComponentName	= @ComponentName
							AND 	ActivityName	= @ActivityName
							AND		UIName			= @UIName							
							)

	DELETE 
	FROM	ep_action_mst_lng_extn
	WHERE	customer_name	= @CustomerID
	AND		project_name	= @ProjectID
	AND		process_name	= @ProcessName
	AND		component_name	= @ComponentName
	AND		activity_name	= @ActivityName
	AND		ui_name			= @UIName
	AND		primary_control_bts <>	'[None]'
	AND		task_name NOT IN (SELECT DISTINCT TaskName
							FROM	ngplf_wr_task_local_info (nolock)
							WHERE	CustomerID		= @CustomerID
							AND		ProjectID		= @ProjectID
							AND		ProcessName		= @ProcessName
							AND		ComponentName	= @ComponentName
							AND 	ActivityName	= @ActivityName
							AND		UIName			= @UIName							
							)

	---------- Task Information
	------INSERT INTO ep_action_mst
	------				(customer_name,			project_name,			process_name,			component_name,		
	------				activity_name,			ui_name,				page_bt_synonym,		req_no,				
	------				task_name,				task_descr,				task_seq,				task_pattern,	-- ??	
	------				primary_control_bts,	Act_flag,				task_type,				Timestamp,			
	------				CreatedBy,				CreatedDate,			ModIFiedBy,				ModIFiedDate,
	------				wrkreqno--,				TargetComponent,		TargetActivity,			TargetILBO,
	------				--TargetSection,			TargetHeight,			TargetWidth	
	------				)
	------SELECT 
	------				tsk.CustomerID,			tsk.ProjectID,			tsk.ProcessName,		tsk.ComponentName,		
	------				tsk.ActivityName,		tsk.UIName,				ctl.PageName,			@tmp_reqno,				
	------				tsk.TaskName,			tsk.TaskDescription,	1,						TaskPattern,		
	------				BTSynonymName,			ActiveFlag,				TaskType,				1,			
	------				@User,					@ngplf_sysdate,			@User,					@ngplf_sysdate,
	------				@Docno
	------FROM	ngplf_wr_task tsk (nolock),
	------		ngplf_wr_control ctl (nolock)
	------WHERE	tsk.CustomerID		= @CustomerID
	------AND		tsk.ProjectID		= @ProjectID
	------AND		tsk.ProcessName		= @ProcessName
	------AND		tsk.ComponentName	= @ComponentName
	------AND 	tsk.ActivityName	= @ActivityName
	------AND		tsk.UIName			= @UIName
	------AND		tsk.DocNo			= @Docno

	------AND		tsk.CustomerID		= ctl.CustomerID
	------AND		tsk.ProjectID		= ctl.ProjectID
	------AND		tsk.ProcessName		= ctl.ProcessName
	------AND		tsk.ComponentName	= ctl.ComponentName
	------AND		tsk.ActivityName	= ctl.ActivityName
	------AND		tsk.UIName			= ctl.UIName
	------AND		tsk.DocNo			= ctl.DocNo
	--------AND		tsk.PageName		= ctl.PageName
	------AND		tsk.TriggeringControlName= ctl.ControlName	
	------AND		tsk.TriggeringViewName= ctl.ViewName
	------AND		tsk.TaskType not in ('Init')	

	------INSERT INTO ep_action_mst_lng_extn
	------				(customer_name,			project_name,			process_name,			component_name,		
	------				activity_name,			ui_name,				page_bt_synonym,		req_no,				
	------				task_name,				task_descr,				task_seq,				task_pattern,	
	------				task_type,				primary_control_bts,	Timestamp,				languageid,
	------				CreatedBy,				CreatedDate,			ModIFiedBy,				ModIFiedDate,
	------				wrkreqno)
	------SELECT	distinct
	------				lng.CustomerID,			lng.ProjectID,			lng.ProcessName,		lng.ComponentName,		
	------				lng.ActivityName,		lng.UIName,				ctl.PageName,			@tmp_reqno,				
	------				lng.TaskName,			lng.TaskDescription,	1,						tsk.TaskPattern,	
	------				tsk.TaskType,			BTSynonymName,			1,						languageid,
	------				@User,					@ngplf_sysdate,			@User,					@ngplf_sysdate,
	------				@Docno
	------FROM	ngplf_wr_task_local_info lng (nolock),
	------		ngplf_wr_task	tsk (nolock),
	------		ngplf_wr_control ctl (nolock)
	------WHERE	lng.CustomerID		= @CustomerID
	------AND		lng.ProjectID		= @ProjectID
	------AND		lng.ProcessName		= @ProcessName
	------AND		lng.ComponentName	= @ComponentName
	------AND 	lng.ActivityName	= @ActivityName
	------AND		lng.UIName			= @UIName
	------AND		lng.DocNo			= @Docno

	------AND		lng.CustomerID		= tsk.CustomerID
	------AND		lng.ProjectID		= tsk.ProjectID
	------AND		lng.DocNo			= tsk.DocNo
	------AND		lng.ProcessName		= tsk.ProcessName
	------AND		lng.ComponentName	= tsk.ComponentName
	------AND		lng.ActivityName	= tsk.ActivityName
	------AND		lng.UIName			= tsk.UIName
	------AND		lng.TaskName		= tsk.TaskName
	

	------AND		lng.CustomerID		= ctl.CustomerID
	------AND		lng.ProjectID		= ctl.ProjectID
	------AND		lng.ProcessName		= ctl.ProcessName
	------AND		lng.ComponentName	= ctl.ComponentName
	------AND		lng.ActivityName	= ctl.ActivityName
	------AND		lng.UIName			= ctl.UIName
	------AND		lng.DocNo			= ctl.DocNo
	--------AND		tsk.PageName		= ctl.PageName
	------AND		tsk.TriggeringControlName= ctl.ControlName	
	------AND		tsk.TriggeringViewName= ctl.ViewName
	------AND		tsk.TaskType not in ('Init')
	------AND		lng.LanguageID		=	@ctxt_language
	

	------INSERT INTO ep_action_mst
	------				(customer_name,			project_name,			process_name,			component_name,		
	------				activity_name,			ui_name,				page_bt_synonym,		req_no,				
	------				task_name,				task_descr,				task_seq,				task_pattern,	-- ??	
	------				primary_control_bts,	Act_flag,				task_type,				Timestamp,			
	------				CreatedBy,				CreatedDate,			ModIFiedBy,				ModIFiedDate)
	------SELECT 
	------				tsk.CustomerID,			tsk.ProjectID,			tsk.ProcessName,		tsk.ComponentName,		
	------				tsk.ActivityName,		tsk.UIName,				ctl.PageName,			@tmp_reqno,				
	------				tsk.TaskName,			tsk.TaskDescription,	1,						TaskPattern,		
	------				BTSynonymName,			ActiveFlag,				TaskType,				1,			
	------				@User,					@ngplf_sysdate,			@User,					@ngplf_sysdate
	------FROM	ngplf_wr_task tsk (nolock),
	------		ngplf_wr_gridcolumn ctl (nolock)
	------WHERE	tsk.CustomerID		= @CustomerID
	------AND		tsk.ProjectID		= @ProjectID
	------AND		tsk.ProcessName		= @ProcessName
	------AND		tsk.ComponentName	= @ComponentName
	------AND 	tsk.ActivityName	= @ActivityName
	------AND		tsk.UIName			= @UIName
	------AND		tsk.DocNo			= @Docno

	------AND		tsk.CustomerID		= ctl.CustomerID
	------AND		tsk.ProjectID		= ctl.ProjectID
	------AND		tsk.ProcessName		= ctl.ProcessName
	------AND		tsk.ComponentName	= ctl.ComponentName
	------AND		tsk.ActivityName	= ctl.ActivityName
	------AND		tsk.UIName			= ctl.UIName
	------AND		tsk.DocNo			= ctl.DocNo		
	--------AND		tsk.PageName		= ctl.PageName
	------AND		tsk.TriggeringControlName= ctl.ControlName	
	------AND		tsk.TriggeringViewName= ctl.ViewName
	------AND		tsk.TaskType not in ('Init')	
	

	------INSERT INTO ep_action_mst_lng_extn
	------				(customer_name,			project_name,			process_name,			component_name,		
	------				activity_name,			ui_name,				page_bt_synonym,		req_no,				
	------				task_name,				task_descr,				task_seq,				task_pattern,	
	------				task_type,				primary_control_bts,	languageid,				Timestamp,			
	------				CreatedBy,				CreatedDate,			ModIFiedBy,				ModIFiedDate)
	------SELECT 
	------				lng.CustomerID,			lng.ProjectID,			lng.ProcessName,		lng.ComponentName,		
	------				lng.ActivityName,		lng.UIName,				ctl.PageName,			@tmp_reqno,				
	------				lng.TaskName,			lng.TaskDescription,	1,						tsk.TaskPattern,	
	------				tsk.TaskType,			BTSynonymName,			languageid,				1,			
	------				@User,					@ngplf_sysdate,			@User,					@ngplf_sysdate
	------FROM	ngplf_wr_task_local_info lng (nolock),
	------		ngplf_wr_task tsk (nolock),
	------		ngplf_wr_gridcolumn ctl (nolock)
	------WHERE	lng.CustomerID		= @CustomerID
	------AND		lng.ProjectID		= @ProjectID
	------AND		lng.ProcessName		= @ProcessName
	------AND		lng.ComponentName	= @ComponentName
	------AND 	lng.ActivityName	= @ActivityName
	------AND		lng.UIName			= @UIName
	------AND		lng.DocNo			= @Docno

	------AND		lng.CustomerID		= ctl.CustomerID
	------AND		lng.ProjectID		= ctl.ProjectID
	------AND		lng.ProcessName		= ctl.ProcessName
	------AND		lng.ComponentName	= ctl.ComponentName
	------AND		lng.ActivityName	= ctl.ActivityName
	------AND		lng.UIName			= ctl.UIName
	------AND		lng.DocNo			= ctl.DocNo

	------AND		lng.CustomerID		= tsk.CustomerID
	------AND		lng.ProjectID		= tsk.ProjectID
	------AND		lng.DocNo			= tsk.DocNo
	------AND		lng.ProcessName		= tsk.ProcessName
	------AND		lng.ComponentName	= tsk.ComponentName
	------AND		lng.ActivityName	= tsk.ActivityName
	------AND		lng.UIName			= tsk.UIName
	------AND		lng.TaskName		= tsk.TaskName
	------AND		tsk.TriggeringControlName= ctl.ControlName	
	------AND		tsk.TriggeringViewName= ctl.ViewName
	--------AND		tsk.PageName		= ctl.PageName
	------AND		tsk.TaskType not in ('Init')
	------AND		lng.LanguageID		=	@ctxt_language
	
	--INSERT INTO maint_rvw20appdb.dbo.ep_action_mst
	--				(customer_name,			project_name,			process_name,			component_name,		
	--				activity_name,			ui_name,				page_bt_synonym,		req_no,				
	--				task_name,				task_descr,				task_seq,				task_pattern,	-- ??	
	--				primary_control_bts,	Act_flag,				task_type,				Timestamp,			
	--				CreatedBy,				CreatedDate,			ModIFiedBy,				ModIFiedDate)
	--SELECT 
	--				tsk.CustomerID,			tsk.ProjectID,			tsk.ProcessName,		tsk.ComponentName,		
	--				tsk.ActivityName,		tsk.UIName,				tsk.PageName,			@tmp_reqno,				
	--				tsk.TaskName,			tsk.TaskDescription,	1,						TaskPattern,		
	--				'[None]',				ActiveFlag,				TaskType,				1,			
	--				@User,					getdate(),				@User,				getdate()
	--FROM	ngplf_wr_task tsk (nolock)	
	--WHERE	tsk.CustomerID		= @CustomerID
	--AND		tsk.ProjectID		= @ProjectID
	--AND		tsk.ProcessName		= @ProcessName
	--AND		tsk.ComponentName	= @ComponentName
	--AND 	tsk.ActivityName	= @ActivityName
	--AND		tsk.UIName			= @UIName
	--AND		tsk.WorkRequest		= @Docno	
	--ANd		tsk.TaskType in ('Fetch')

	
	------INSERT INTO ep_action_mst
	------				(customer_name,			project_name,			process_name,			component_name,		
	------				activity_name,			ui_name,				page_bt_synonym,		req_no,				
	------				task_name,				task_descr,				task_seq,				task_pattern,	-- ??	
	------				primary_control_bts,	Act_flag,				task_type,				Timestamp,			
	------				CreatedBy,				CreatedDate,			ModIFiedBy,				ModIFiedDate)
	------SELECT 
	------				tsk.CustomerID,			tsk.ProjectID,			tsk.ProcessName,		tsk.ComponentName,		
	------				tsk.ActivityName,		tsk.UIName,				'[mainscreen]',			@tmp_reqno,				
	------				tsk.TaskName,			tsk.TaskDescription,	1,						TaskPattern,		
	------				'[None]',				ActiveFlag,				TaskType,				1,			
	------				@User,					@ngplf_sysdate,			@User,					@ngplf_sysdate
	------FROM	ngplf_wr_task tsk (nolock)	
	------WHERE	tsk.CustomerID		= @CustomerID
	------AND		tsk.ProjectID		= @ProjectID
	------AND		tsk.ProcessName		= @ProcessName
	------AND		tsk.ComponentName	= @ComponentName
	------AND 	tsk.ActivityName	= @ActivityName
	------AND		tsk.UIName			= @UIName
	------AND		tsk.DocNo			= @Docno	
	------AND		tsk.TaskType		in ('Init', 'Fetch')

	------INSERT INTO ep_action_mst_lng_extn
	------				(customer_name,			project_name,			process_name,			component_name,		
	------				activity_name,			ui_name,				page_bt_synonym,		req_no,				
	------				task_name,				task_descr,				task_seq,				task_pattern,		
	------				task_type,				primary_control_bts,	Languageid,				Timestamp,			
	------				CreatedBy,				CreatedDate,			ModIFiedBy,				ModIFiedDate)
	------SELECT 
	------				tsk.CustomerID,			tsk.ProjectID,			tsk.ProcessName,		tsk.ComponentName,		
	------				tsk.ActivityName,		tsk.UIName,				'[mainscreen]',			@tmp_reqno,				
	------				tsk.TaskName,			tsk.TaskDescription,	1,						tsk.TaskPattern,	
	------				tsk.TaskType,			'[None]',				Languageid,				1,			
	------				@User,					@ngplf_sysdate,			@User,					@ngplf_sysdate
	------FROM	ngplf_wr_task_local_info lng (nolock),
	------		ngplf_wr_task	tsk (nolock)
	------WHERE	lng.CustomerID		= @CustomerID
	------AND		lng.ProjectID		= @ProjectID
	------AND		lng.ProcessName		= @ProcessName
	------AND		lng.ComponentName	= @ComponentName
	------AND 	lng.ActivityName	= @ActivityName
	------AND		lng.UIName			= @UIName
	------AND		lng.DocNo			= @Docno	
	------AND		tsk.TaskType		in ('Init', 'Fetch')
	------AND		lng.LanguageID		=	@ctxt_language

	------AND		lng.CustomerID		= tsk.CustomerID
	------AND		lng.ProjectID		= tsk.ProjectID
	------AND		lng.DocNo			= tsk.DocNo
	------AND		lng.ProcessName		= tsk.ProcessName
	------AND		lng.ComponentName	= tsk.ComponentName
	------AND		lng.ActivityName	= tsk.ActivityName
	------AND		lng.UIName			= tsk.UIName
	------AND		lng.TaskName		= tsk.TaskName

		--SELECT 'in1', * FROM maint_rvw20appdb.dbo.ep_action_mst (nolock) where ui_name = @UIName
	---- Task Information
	--UPDATE tsk set
	--			CASE RENDERAS	
	--				WHEN 'QRCode' then 
						
	--					tsk.QR_sourceCtrl		= btl.			
	--					tsk.QR_targetCtrl		= 
	--					tsk.QR_sourceCtrl_Page	=,	
	--					tsk.QR_targetCtrl_Page	= ,		
	--					tsk.Barcode_sourceCtrl	= ,		
	--					tsk.Barcode_targetCtrl	= ,		
	--					tsk.Barcode_sourceCtrl_Page = 
	--					tsk.Barcode_targetCtrl_Page	=
	--					tsk.browse_control			= ,			
	--					tsk.browse_control_Page		= 
	--FROM	ep_action_mst tsk ,
	--		ngplf_wr_buttonlink btl 
	--WHERE	tsk.CustomerID		= @CustomerID
	--AND		tsk.ProjectID		= @ProjectID
	--AND		tsk.ProcessName		= @ProcessName
	--AND		tsk.ComponentName	= @ComponentName
	--AND 	tsk.ActivityName	= @ActivityName
	--AND		tsk.UIName			= @UIName
	--AND		tsk.WorkRequest		= @Docno

	--AND		tsk.CustomerID		= ctl.CustomerID
	--AND		tsk.ProjectID		= ctl.ProjectID
	--AND		tsk.ProcessName		= ctl.ProcessName
	--AND		tsk.ComponentName	= ctl.ComponentName
	--AND		tsk.ActivityName	= ctl.ActivityName
	--AND		tsk.UIName			= ctl.UIName
	--AND		tsk.WorkRequest		= ctl.WorkRequest

	--AND		tsk.PageName		= ctl.PageName
	--AND		tsk.SectionName		= ctl.SectionName
	--AND		tsk.ControlName		= ctl.ControlName	
	--AND		tsk.ViewName		= ctl.ViewName							
	
	-- Slider Control Information is not required since all these columns refer the control type attributes

	-- glossary Information

		INSERT INTO ep_component_glossary_mst (
					customer_name,					project_name,			process_name,			component_name,			
					bt_synonym_name,				req_no,					bt_synonym_caption,		data_type,			
					Length,							bt_synonym_doc,			bt_name,				Timestamp,
					CreatedBy,						CreatedDate,			ModIFiedBy,				ModIFiedDate,
					wrkreqno,						glossary_sysid,			IsGlance)
		SELECT	DISTINCT
					CustomerID,						ProjectID,				ProcessName,			ComponentName,			
					BTSynonymName,					@tmp_reqno,				BTSynonymCaption,		ISNULL(DataType, 'Char'),			
					ISNULL(DataTypeLength,60),		BTSynDocumentation,		BTName,					1,
					@ctxt_user,						@ngplf_sysdate,			@ctxt_user,				@ngplf_sysdate,
					@tmp_reqno	,					@guid,					'Y'
		FROM	ngplf_wr_glossary glo (NOLOCK)
		WHERE	CustomerID		= @CustomerID
		AND		ProjectID		= @ProjectID
		AND		ProcessName		= @ProcessName
		AND		ComponentName	= @ComponentName
		AND		not exists (SELECT 'X'
							FROM	ep_component_glossary_mst (nolock)
							WHERE	Customer_name		=	@CustomerID
							AND		Project_name		=	@ProjectID
							AND		Process_Name		=	@ProcessName
							AND		Component_Name		=	@ComponentName
	
							AND 	Customer_name		=	glo.CustomerID
							AND		Project_name		=	glo.ProjectID
							AND		Process_Name		=	glo.ProcessName
							AND		Component_Name		=	glo.ComponentName
							AND		BT_Synonym_Name		=	glo.BTSynonymName)


		--INSERT INTO ep_component_glossary_mst_lng_extn(
		--			customer_name,				project_name,			process_name,			component_name,			
		--			bt_synonym_name,			LanguageID,				req_no,					bt_synonym_caption,	
		--			bt_synonym_doc,				Timestamp,				CreatedBy,				CreatedDate,		
		--			ModIFiedBy,					ModIFiedDate,			data_type,				Length,
		--			wrkreqno,					glossary_sysid)
		--SELECT	DISTINCT
		--			CustomerID,					ProjectID,				ProcessName,			ComponentName,			
		--			BTSynonymName,				LanguageID,				@tmp_reqno,				BTSynonymCaption,	
		--			BTSynDocumentation,			1,						@ctxt_user,				@ngplf_sysdate,				
		--			@ctxt_user,					@ngplf_sysdate,			'Char',					60,
		--			@tmp_reqno,					@guid
		--FROM	 ngplf_wr_glossary_local_info lng (NOLOCK)
		--WHERE	CustomerID		= @CustomerID
		--AND		ProjectID		= @ProjectID
		--AND		ProcessName		= @ProcessName
		--AND		ComponentName	= @ComponentName
		--AND		LanguageID		= @Ctxt_Language
		--AND		not exists (SELECT 'X'
		--					FROM	ep_component_glossary_mst_lng_extn (nolock)
		--					WHERE	Customer_name		=	@CustomerID
		--					AND		Project_name		=	@ProjectID
		--					AND		Process_Name		=	@ProcessName
		--					AND		Component_Name		=	@ComponentName
		--					AND		LanguageID			=	@Ctxt_Language
							
		--					AND		LanguageID			=	lng.LanguageID
		--					AND 	Customer_name		=	lng.CustomerID
		--					AND		Project_name		=	lng.ProjectID
		--					AND		Process_Name		=	lng.ProcessName
		--					AND		Component_Name		=	lng.ComponentName
		--					AND		BT_Synonym_Name		=	lng.BTSynonymName)


		UPDATE	pg SET	
					pg.bt_synonym_caption	= ng.BTSynonymCaption,
					pg.data_type			= ng.DataType,
					pg.length				= ng.DataTypeLength,
					ModIFiedBy				= @ctxt_user,			
					ModIFiedDate			= getdate()	
		FROM	ep_component_glossary_mst pg ,
				ngplf_wr_glossary ng 
		WHERE	pg.Customer_name	=	ng.CustomerID
		AND		pg.Project_name		=	ng.ProjectID
		AND		pg.Process_Name		=	ng.ProcessName
		AND		pg.Component_Name	=	ng.ComponentName
		AND		pg.bt_synonym_name	=	ng.BTSynonymName

		AND		pg.Customer_name	=	@CustomerID
		AND		pg.Project_name		=	@ProjectID
		AND		pg.Process_Name		=	@ProcessName
		AND		pg.Component_Name	=	@ComponentName
		AND		exists (SELECT 'X'
							FROM	ep_component_glossary_mst (nolock)
							WHERE	Customer_name		=	@CustomerID
							AND		Project_name		=	@ProjectID
							AND		Process_Name		=	@ProcessName
							AND		Component_Name		=	@ComponentName
	
							AND 	Customer_name		=	ng.CustomerID
							AND		Project_name		=	ng.ProjectID
							AND		Process_Name		=	ng.ProcessName
							AND		Component_Name		=	ng.ComponentName
							AND		bt_synonym_name		=	ng.btsynonymname
							AND		(bt_synonym_caption	<>	ng.btsynonymcaption or data_type <> ng.datatype or length <> ng.DataTypeLength )
							)

		--UPDATE	pg SET	
		--			pg.bt_synonym_caption	= gl.BTSynonymCaption,
		--			pg.data_type			= gl.DataType,
		--			pg.length				= gl.DataTypeLength,
		--			ModIFiedBy				= @ctxt_user,			
		--			ModIFiedDate			= getdate()	
		--FROM	ep_component_glossary_mst_lng_extn pg ,
		--		ngplf_wr_glossary gl
		--WHERE	pg.Customer_name	=	gl.CustomerID
		--AND		pg.Project_name		=	gl.ProjectID
		--AND		pg.Process_Name		=	gl.ProcessName
		--AND		pg.Component_Name	=	gl.ComponentName
		--AND		pg.bt_synonym_name	=	gl.BTSynonymName

		--AND		pg.Customer_name	=	@CustomerID
		--AND		pg.Project_name		=	@ProjectID
		--AND		pg.Process_Name		=	@ProcessName
		--AND		pg.Component_Name	=	@ComponentName
		----AND		pg.languageid		=	@ctxt_language

		--AND		exists (SELECT 'X'
		--					FROM	ep_component_glossary_mst_lng_extn (nolock)
		--					WHERE	Customer_name		=	@CustomerID
		--					AND		Project_name		=	@ProjectID
		--					AND		Process_Name		=	@ProcessName
		--					AND		Component_Name		=	@ComponentName

		--					AND 	Customer_name		=	gl.CustomerID
		--					AND		Project_name		=	gl.ProjectID
		--					AND		Process_Name		=	gl.ProcessName
		--					AND		Component_Name		=	gl.ComponentName
		--					AND		bt_synonym_name		=	gl.btsynonymname

		--					AND		(	(bt_synonym_caption	<>	gl.btsynonymcaption) or (data_type <> gl.datatype) or (length <> gl.DataTypeLength) )
		--					AND		languageid			=	pg.languageid	)


--		UPDATE pg SET pg.bt_synonym_caption  =  ng.BTSynonymCaption
--FROM   ep_component_glossary_mst pg ,
--       ngplf_wr_glossary ng 
--WHERE  pg.Customer_name     =      ng.CustomerID
--AND    pg.Project_name      =      ng.ProjectID
--AND    pg.Process_Name      =      ng.ProcessName
--AND    pg.Component_Name    =      ng.ComponentName
--AND    pg.bt_synonym_name   =      ng.BTSynonymName
--AND    not exists (  SELECT 'X'
--                                  FROM   ep_component_glossary_mst (nolock)
--                                  WHERE  Customer_name        =      @CustomerID
--                                  AND    Project_name         =      @ProjectID
--                                  AND    Process_Name         =        @ProcessName
--                                  AND    Component_Name             =      @ComponentName
       
--                    AND    Customer_name        =             ng.CustomerID
--                    AND    Project_name         =       ng.ProjectID
--                    AND    Process_Name         =       ng.ProcessName
--                    AND    Component_Name       =       ng.ComponentName
--                    AND    bt_synonym_name      =       ng.BTSynonymName)

	--END

--Traversal information



	------INSERT INTO ep_template_action
	------					(CustomerID,			ProjectID,				DocNo,				ProcessName,			
	------					ComponentName,			ActivityName,			UIName,				PageName,				
	------					SectionName,			ControlName,			ViewName,			TemplateID,				
	------					SequenceNumber,			ActionName,				ActionType,			ActionPrefix,
	------					ActionParams,			TaskName,				TaskType,			SampleData,			
	------					ModeFlag,				GlanceID,				Timestamp,			CreatedBy,			
	------					CreatedDate,			ModifiedBy,				ModifiedDate
	------					)
	------SELECT DISTINCT
	------					CustomerID,				ProjectID,				@tmp_reqno,			@ProcessName,			
	------					ComponentName,			ActivityName,			UIName,				PageName,				
	------					SectionName,			ControlName,			ViewName,			TemplateID,				
	------					SequenceNumber,			ActionName,				ActionType,			ActionPrefix,
	------					ActionParams,			TaskName,				TaskType,			SampleData,			
	------					ModeFlag,				GlanceID,				Timestamp,			@ctxt_user,			
	------					@ngplf_sysdate,			@ctxt_user,				@ngplf_sysdate
	------FROM	ngplf_wr_template_action tpl (nolock)
	------WHERE	CustomerID		= @CustomerID
	------AND		ProjectID		= @ProjectID	
	------AND		ComponentName	= @ComponentName
	------AND 	ActivityName	= @ActivityName
	------AND		UIName			= @UIName
	------AND		DocNo			= @tmp_reqno
	--------AND		GUID			= @GUID
	--------AND		ModeFlag		= 'I'

	------AND		NOT EXISTS (SELECT 'X'
	------				FROM	ep_template_action (nolock)
	------				WHERE	CustomerID			= tpl.CustomerID
	------				AND		ProjectID			= tpl.ProjectID					
	------				AND		ComponentName		= tpl.ComponentName
	------				AND 	ActivityName		= tpl.ActivityName
	------				AND		UIName				= tpl.UIName
	------				AND		PageName			= tpl.PageName
	------				AND		SectionName			= tpl.SectionName	
	------				AND		ControlName			= tpl.ControlName
	------				AND		ViewName			= tpl.ViewName	
	------				AND		TemplateID			= tpl.TemplateID
	------				AND		ActionName			= tpl.ActionName										
	------				)

		INSERT INTO ep_ui_traversal_dtl
							(Customer_name,				Project_name,				Process_Name,			Component_Name,		
							Activity_Name,				UI_Name,					page_bt_synonym,		section_bt_synonym,		
							control_bt_synonym,			req_no,						Timestamp,				CreatedBy,
							CreatedDate,				ModIFiedBy,					ModIFiedDate,			trvsl_seq,
							ui_page_sysid,				link_type,					wrkreqno,				treaversal_sysid,
							---linked_component,			linked_activity,			linked_ui,				
							LinkLaunchType	)

		SELECT	DISTINCT 
							trav.CustomerID,			trav.ProjectID,				trav.ProcessName,		trav.ComponentName,		
							trav.ActivityName,			trav.UIName,				trav.PageName,			trav.SectionName,		
							ctl.BTSynonymName,			'Base',						1,						@ctxt_user,
							@ngplf_sysdate,				@ctxt_user,					@ngplf_sysdate,			0,
							@GUID	,					LaunchType,					@Docno,					@GUID,
							--TargetComponent,			TargetActivity,				TargetUIName,			
							LaunchMode						
		FROM	ngplf_wr_controlcolumn_vw ctl(NOLOCK),
				ngplf_wr_traversal trav (nolock)
		WHERE	ctl.CustomerID			=	@CustomerID
		AND		ctl.ProjectID			=	@ProjectID
		AND		ctl.ProcessName			=	@ProcessName
		AND		ctl.ComponentName		=	@ComponentName
		AND 	ctl.ActivityName		=	@ActivityName
		AND		ctl.UIName				=	@UIName
	--	AND		ctl.DocNo				=	@Docno
				
		AND		ctl.CustomerID			=	trav.CustomerID
		AND		ctl.ProjectID			=	trav.ProjectID
		AND		ctl.ProcessName			=	trav.ProcessName
		AND		ctl.ComponentName		=	trav.ComponentName
		AND		ctl.UIName				=	trav.UIName
		AND		ctl.ControlName			=	trav.ControlName
		AND		ctl.ViewName			=	trav.viewname
		AND		NOT EXISTS ( SELECT 'X'
							FROM	ep_ui_traversal_dtl (nolock)
							WHERE	customer_name			= trav.CustomerID
							AND		project_name			= trav.ProjectID
							AND		process_name			= trav.ProcessName
							AND		component_name			= trav.ComponentName
							AND		activity_name			= trav.ActivityName
							AND		ui_name					= trav.UIName
							AND		page_bt_synonym			= trav.PageName
							AND		section_bt_synonym		= trav.SectionName
							AND		control_bt_synonym		= ctl.BTSynonymName
							AND		link_type				= trav.Launchtype
							)
			UNION
		SELECT	DISTINCT 
							trav.CustomerID,			trav.ProjectID,				trav.ProcessName,		trav.ComponentName,		
							trav.ActivityName,			trav.UIName,				trav.PageName,			trav.SectionName,		
							trav.ControlName+'_'+tpl.ActionName,'Base',				1,						@ctxt_user,
							@ngplf_sysdate,				@ctxt_user,					@ngplf_sysdate,			0,
							@GUID	,					LaunchType,					@Docno,					@GUID,
							--TargetComponent,			TargetActivity,				TargetUIName,			
							LaunchMode						
		FROM	ngplf_wr_template_action tpl(NOLOCK),
				ngplf_wr_traversal trav (nolock)
		WHERE	tpl.CustomerID			=	@CustomerID
		AND		tpl.ProjectID			=	@ProjectID
		AND		tpl.ProcessName			=	@ProcessName
		AND		tpl.ComponentName		=	@ComponentName
		AND 	tpl.ActivityName		=	@ActivityName
		AND		tpl.UIName				=	@UIName
	--	AND		tpl.DocNo				=	@Docno
				
		AND		tpl.CustomerID			=	trav.CustomerID
		AND		tpl.ProjectID			=	trav.ProjectID
		AND		tpl.ProcessName			=	trav.ProcessName
		AND		tpl.ComponentName		=	trav.ComponentName
		AND		tpl.UIName				=	trav.UIName
		AND		tpl.ControlName			=	trav.ControlName
		AND		tpl.ActionName			=	trav.viewname
		AND		NOT EXISTS ( SELECT 'X'
							FROM	ep_ui_traversal_dtl (nolock)
							WHERE	customer_name			= trav.CustomerID
							AND		project_name			= trav.ProjectID
							AND		process_name			= trav.ProcessName
							AND		component_name			= trav.ComponentName
							AND		activity_name			= trav.ActivityName
							AND		ui_name					= trav.UIName
							AND		page_bt_synonym			= trav.PageName
							AND		section_bt_synonym		= trav.SectionName
							AND		control_bt_synonym		= tpl.controlname+'_'+tpl.ActionName 
							AND		link_type				= trav.Launchtype	)	

		END

		UPDATE	a
		SET		a.ExtensionReqd	=	'Y' 
		FROM	ep_ui_control_dtl a (NOLOCK),
				ep_ui_grid_dtl b (NOLOCK)
			WHERE	a.customer_name		=	b.customer_name
			AND		a.project_name		=	b.project_name
			AND		a.process_name		=	b.process_name
			AND		a.component_name	=	b.component_name
			AND		a.activity_name		=	b.activity_name
			AND		a.ui_name			=	b.ui_name
			AND		a.Page_Bt_Synonym	=	b.Page_bt_synonym
			AND		a.Section_bt_synonym= b.Section_bt_synonym
			AND		a.Control_ID		=	b.Control_ID
			AND		b.column_type		=	'extension'

			AND		a.customer_name		=	@CustomerID
			AND		a.project_name		=	@ProjectID
			AND		a.process_name		=	@ProcessName
			AND		a.component_name	=	@ComponentName
			AND		a.activity_name		=	@ActivityName
			AND		a.ui_name			=	@UIName

	------INSERT INTO ep_ui_traversal_dtl
	------				(Customer_name,					Project_name,				Process_Name,			Component_Name,		
	------				Activity_Name,					UI_Name,					page_bt_synonym,		section_bt_synonym,		
	------				control_bt_synonym,				req_no,						Timestamp,				CreatedBy,
	------				CreatedDate,					ModIFiedBy,					ModIFiedDate,			trvsl_seq,
	------				ui_page_sysid,					link_type,					wrkreqno,				treaversal_sysid	)

	------		SELECT	distinct 
	------					trav.CustomerID,			trav.ProjectID,				trav.ProcessName,			trav.ComponentName,		
	------					trav.ActivityName,			trav.UIName,				trav.PageName,				trav.SectionName,		
	------					ctl.BTSynonymName,			'Base',						1,							@ctxt_user,
	------					@ngplf_sysdate,				@ctxt_user,					@ngplf_sysdate,				0,
	------					@GUID	,					LaunchMode,					@Docno,						@GUID						
	------		FROM	ngplf_wr_control ctl(NOLOCK),
	------				ngplf_wr_traversal trav (nolock)
	------		WHERE	ctl.CustomerID			=	@CustomerID
	------		AND		ctl.ProjectID			=	@ProjectID
	------		AND		ctl.ProcessName			=	@ProcessName
	------		AND		ctl.ComponentName		=	@ComponentName
	------		AND 	ctl.ActivityName		=	@ActivityName
	------		AND		ctl.UIName				=	@UIName
	------		AND		ctl.DocNo				=	@Docno
				
	------		AND		ctl.CustomerID			=	trav.CustomerID
	------		AND		ctl.ProjectID			=	trav.ProjectID
	------		AND		ctl.ProcessName			=	trav.ProcessName
	------		AND		ctl.ComponentName		=	trav.ComponentName
	------		and		ctl.UIName				=	trav.UIName
	------		and		ctl.ControlName			=	trav.ControlName
	------		and		ctl.ViewName			=	trav.viewname
			
	------		UNION
	------		SELECT	distinct
	------						trav.CustomerID,				trav.ProjectID,				trav.ProcessName,			trav.ComponentName,		
	------						trav.ActivityName,				trav.UIName,				trav.PageName,				trav.SectionName,		
	------						ctl.BTSynonymName,				'Base',						1,							@ctxt_user,
	------						@ngplf_sysdate,					@ctxt_user,					@ngplf_sysdate,				0,
	------						@GUID	,						LaunchMode,					@Docno,						@GUID
	------		FROM	ngplf_wr_gridcolumn ctl(NOLOCK),
	------				ngplf_wr_traversal trav (nolock)
	------		WHERE	ctl.CustomerID			=	@CustomerID
	------		AND		ctl.ProjectID			=	@ProjectID
	------		AND		ctl.ProcessName			=	@ProcessName
	------		AND		ctl.ComponentName		=	@ComponentName
	------		AND 	ctl.ActivityName		=	@ActivityName
	------		AND		ctl.UIName				=	@UIName
	------		AND		ctl.DocNo				=	@Docno
				
	------		AND		ctl.CustomerID			=	trav.CustomerID
	------		AND		ctl.ProjectID			=	trav.ProjectID
	------		AND		ctl.ProcessName			=	trav.ProcessName
	------		AND		ctl.ComponentName		=	trav.ComponentName
	------		ANd		ctl.UIName				=	trav.UIName
	------		and		ctl.ControlName			=	trav.ControlName
	------		and		ctl.ViewName			=	trav.viewname

	--UPDATE tra SET
	--			linked_component		= ngtra.LinkedComponent,
	--			linked_activity			= ngtra.LinkedActivity,
	--			linked_ui				= ngtra.LinkedUI,
	--			link_type				= ngtra.LinkType,
	--			LinkLaunchType			= ngtra.LinkLaunchType,
	--			Width					= ngtra.Width,
	--			Height					= ngtra.Height
	--FROM	ep_ui_traversal_dtl tra,
	--		ngplf_ep_ui_traversal_dtl ngtra
	--WHERE	tra.Customer_name			=	@CustomerID
	--AND		tra.Project_name			=	@ProjectID
	--AND		tra.Process_Name			=	@ProcessName
	--AND		tra.Component_Name		=	@ComponentName
	--AND 	tra.Activity_Name		=	@ActivityName
	--AND		tra.UI_Name				=	@UIName
	----AND		tra.WorkRequest			=	@Docno	
										
	--AND		tra.Customer_name			=	ngtra.CustomerID
	--AND		tra.Project_name			=	ngtra.ProjectID
	--AND		tra.Process_Name			=	ngtra.ProcessName
	--AND		tra.Component_Name		=	ngtra.ComponentName
	--AND		tra.Activity_Name		=	ngtra.ActivityName
	--ANd		tra.UI_Name				=	ngtra.UIName
	--and		tra.section_bt_synonym	=	ngtra.SectionName
	--and		tra.control_bt_synonym	=	ngtra.BTSynonymName

	
	

	
	--To Populate the Hidden Views for Meta Data Based Links 
	--Exec	ngplf_MetaDataBasedLink_hdnview
	--			@ctxt_language		= @ctxt_language,
	--			@ctxt_ouinstance	= @ctxt_ouinstance,
	--			@ctxt_user			= @ctxt_user,
	--			@ctxt_role			= @ctxt_role,
	--			@CustomerID			= @CustomerID, 
	--			@ProjectID			= @ProjectID,
	--			@ProcessName		= @ProcessName,
	--			@ComponentName		= @ComponentName,				
	--			@ActivityName		= @ActivityName,
	--			@UIName				= @UIName,
	--			@Docno				= @Docno,
	--			@GUID				= @GUID



	SET NOCOUNT OFF
END 
GO

IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'ngplf_ngplf_plf_transferdata' AND TYPE = 'P')
	GRANT EXEC ON ngplf_ngplf_plf_transferdata TO PUBLIC
GO	


