if exists ( Select 'y' from sysobjects where name = 'EP_Layout_SP_InitSec_Ori' and type = 'P')
    begin
        drop proc EP_Layout_SP_InitSec_Ori
    end
go


/*********************************************************************************/
/* Procedure					: EP_Layout_SP_InitSec_Ori						 */
/* Description					: 												 */
/*********************************************************************************/
/* Project						: 												 */
/* EcrNo						: Prw_ECR_00										 */
/* Version						: 												 */
/*********************************************************************************/
/* Referenced					: 												 */
/* Tables						: 												 */
/*********************************************************************************/
/* Development history			: 												 */
/*********************************************************************************/
/* Author						: ModelExplorer												 */
/* Date							: Nov  2 2022  7:54PM							 */
/*********************************************************************************/
/* Modification History			: 												 */
/*********************************************************************************/
/* Modified By					: Ponmalar A									 */
/* Date							: 02-Dec-2022									 */
/* DefectID						: TECH-75230									 */
/*********************************************************************************/

Create Procedure EP_Layout_SP_InitSec_Ori
	@ctxt_language      	ctxt_language, --Input 
	@ctxt_ouinstance    	ctxt_ouinstance, --Input 
	@ctxt_service       	ctxt_service, --Input 
	@ctxt_user          	ctxt_user, --Input 
	@engg_component     	engg_description, --Input 
	@engg_customer_name 	engg_name, --Input 
	@engg_process_descr 	engg_description, --Input 
	@engg_project_name  	engg_name, --Input 
	@engg_req_no        	engg_name, --Input 
	@m_errorid          	int output --To Return Execution Status
as
Begin
	-- nocount should be switched on to prevent phantom rows
	Set nocount on

	-- @m_errorid should be 0 to Indicate Success
	Set @m_errorid = 0

	-- declaration of temporary variables


	-- temporary and formal parameters mapping

	Set @ctxt_service        = ltrim(rtrim(@ctxt_service))
	Set @ctxt_user           = ltrim(rtrim(@ctxt_user))
	Set @engg_component      = ltrim(rtrim(@engg_component))
	Set @engg_customer_name  = ltrim(rtrim(@engg_customer_name))
	Set @engg_process_descr  = ltrim(rtrim(@engg_process_descr))
	Set @engg_project_name   = ltrim(rtrim(@engg_project_name))
	Set @engg_req_no         = ltrim(rtrim(@engg_req_no))

	-- null checking

	IF @ctxt_language = -915
		Select @ctxt_language = null  

	IF @ctxt_ouinstance = -915
		Select @ctxt_ouinstance = null  

	IF @ctxt_service = '~#~' 
		Select @ctxt_service = null  

	IF @ctxt_user = '~#~' 
		Select @ctxt_user = null  

	IF @engg_component = '~#~' 
		Select @engg_component = null  

	IF @engg_customer_name = '~#~' 
		Select @engg_customer_name = null  

	IF @engg_process_descr = '~#~' 
		Select @engg_process_descr = null  

	IF @engg_project_name = '~#~' 
		Select @engg_project_name = null  

	IF @engg_req_no = '~#~' 
		Select @engg_req_no = null  

	SELECT	''					'orientation'
	UNION
	SELECT	quick_code_value	'orientation' 
	FROM ep_quick_code_mst (NOLOCK)
	WHERE	quick_code_type	=	'Orientation'

	/* 
	-- OutputList
	Select
		null 'orientation', 
	*/

	Set nocount off
End


