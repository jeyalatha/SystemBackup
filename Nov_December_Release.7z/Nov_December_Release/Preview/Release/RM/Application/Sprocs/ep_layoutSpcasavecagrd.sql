IF EXISTS ( SELECT 'y' from sysobjects WHERE name = 'ep_layoutSpcasavecagrd' AND type = 'P')
    BEGIN
        DROP PROC ep_layoutSpcasavecagrd
    END
GO
/********************************************************************************************/
/* Procedure					: ep_layoutSpcasavecagrd									*/
/* Description					: 															*/
/********************************************************************************************/
/* Referenced					:															*/
/* Tables						:															*/
/********************************************************************************************/
/* Development history			:															*/
/********************************************************************************************/
/* Author						:	Ponmalar A/Priyadharshini U 							*/
/* Date							:	08/06/22				 								*/
/* Defect ID					:	TECH-69624												*/
/* Description					:	Custom border, Custom actions and Responsive layout		*/
/********************************************************************************************/
/* Modified by					:	Ponmalar A												*/
/* Modified on					:	11-July-22				 								*/
/* Defect ID					:	TECH-70687												*/
/* Description					:	Tool and Toolbars										*/
/********************************************************************************************/
/* Modified by  : Ponmalar A		 Date: 29-Sep-2022		Defect ID : TECH-73216			*/
/********************************************************************************************/
/* Modified by  : Ponmalar A		 Date: 01-Dec-2022		Defect ID : TECH-75230			*/
/********************************************************************************************/
CREATE Procedure ep_layoutSpcasavecagrd
	@ctxt_ouinstance           	ctxt_ouinstance, --Input 
	@ctxt_user                 	ctxt_user, --Input 
	@ctxt_language             	ctxt_language, --Input 
	@ctxt_service              	ctxt_service, --Input 
	@engg_act_descr            	engg_description, --Input 
	@engg_component            	engg_description, --Input 
	@engg_cont_page_bts        	engg_name, --Input 
	@engg_cont_sec_bts         	engg_name, --Input 
	@engg_custact_actdesc      	engg_description, --Input 
	@engg_custact_actionseq    	engg_seqno, --Input 
	@engg_custact_actiontype   	engg_name, --Input 
	@engg_custact_actname      	engg_name, --Input 
	@engg_custact_cntrbtsyn    	engg_name, --Input 
	@engg_custact_ctrlname     	engg_name, --Input 
	@engg_custact_iconclass    	engg_name, --Input 
	@engg_custact_iconposition 	engg_name, --Input 
	@engg_custact_pagename     	engg_name, --Input 
	@engg_custact_secname      	engg_name, --Input 
	@engg_custact_tooltip      	engg_name, --Input 
	@engg_custact_width        	engg_seqno, --Input 
	@engg_customer_name        	engg_name, --Input 
	@engg_process_descr        	engg_description, --Input 
	@engg_project_name         	engg_name, --Input 
	@engg_req_no               	engg_name, --Input 
	@engg_ui_descr             	engg_description, --Input 
	@engg_custact_hdnctrl		engg_name,
	@modeflag                  	modeflag, --Input 
	@fprowno                   	rowno, --Input/Output
	@m_errorid                 	int output --To Return Execution Status
as
Begin
	-- nocount should be switched on to prevent phantom rows
	Set nocount on

	-- @m_errorid should be 0 to Indicate Success
	Set @m_errorid = 0

	-- declaration of temporary variables


	-- temporary and formal parameters mapping

	Set @ctxt_user                  = ltrim(rtrim(@ctxt_user))
	Set @ctxt_service               = ltrim(rtrim(@ctxt_service))
	Set @engg_act_descr             = ltrim(rtrim(@engg_act_descr))
	Set @engg_component             = ltrim(rtrim(@engg_component))
	Set @engg_cont_page_bts         = ltrim(rtrim(@engg_cont_page_bts))
	Set @engg_cont_sec_bts          = ltrim(rtrim(@engg_cont_sec_bts))
	Set @engg_custact_actdesc       = ltrim(rtrim(@engg_custact_actdesc))
	Set @engg_custact_actiontype    = ltrim(rtrim(@engg_custact_actiontype))
	Set @engg_custact_actname       = ltrim(rtrim(@engg_custact_actname))
	Set @engg_custact_cntrbtsyn     = ltrim(rtrim(@engg_custact_cntrbtsyn))
	Set @engg_custact_ctrlname      = ltrim(rtrim(@engg_custact_ctrlname))
	Set @engg_custact_iconclass     = ltrim(rtrim(@engg_custact_iconclass))
	Set @engg_custact_iconposition  = ltrim(rtrim(@engg_custact_iconposition))
	Set @engg_custact_pagename      = ltrim(rtrim(@engg_custact_pagename))
	Set @engg_custact_secname       = ltrim(rtrim(@engg_custact_secname))
	Set @engg_custact_tooltip       = ltrim(rtrim(@engg_custact_tooltip))
	Set @engg_customer_name         = ltrim(rtrim(@engg_customer_name))
	Set @engg_process_descr         = ltrim(rtrim(@engg_process_descr))
	Set @engg_project_name          = ltrim(rtrim(@engg_project_name))
	Set @engg_req_no                = ltrim(rtrim(@engg_req_no))
	Set @engg_ui_descr              = ltrim(rtrim(@engg_ui_descr))
	Set @modeflag                   = ltrim(rtrim(@modeflag))

	-- null checking

	IF @ctxt_ouinstance = -915
		Select @ctxt_ouinstance = null  

	IF @ctxt_user = '~#~' 
		Select @ctxt_user = null  

	IF @ctxt_language = -915
		Select @ctxt_language = null  

	IF @ctxt_service = '~#~' 
		Select @ctxt_service = null  

	IF @engg_act_descr = '~#~' 
		Select @engg_act_descr = null  

	IF @engg_component = '~#~' 
		Select @engg_component = null  

	IF @engg_cont_page_bts = '~#~' 
		Select @engg_cont_page_bts = null  

	IF @engg_cont_sec_bts = '~#~' 
		Select @engg_cont_sec_bts = null  

	IF @engg_custact_actdesc = '~#~' 
		Select @engg_custact_actdesc = null  

	IF @engg_custact_actionseq = -915
		Select @engg_custact_actionseq = null  

	IF @engg_custact_actiontype = '~#~' 
		Select @engg_custact_actiontype = null  

	IF @engg_custact_actname = '~#~' 
		Select @engg_custact_actname = null  

	IF @engg_custact_cntrbtsyn = '~#~' 
		Select @engg_custact_cntrbtsyn = null  

	IF @engg_custact_ctrlname = '~#~' 
		Select @engg_custact_ctrlname = null  

	IF @engg_custact_iconclass = '~#~' 
		Select @engg_custact_iconclass = null  

	IF @engg_custact_iconposition = '~#~' 
		Select @engg_custact_iconposition = null  

	IF @engg_custact_pagename = '~#~' 
		Select @engg_custact_pagename = null  

	IF @engg_custact_secname = '~#~' 
		Select @engg_custact_secname = null  

	IF @engg_custact_tooltip = '~#~' 
		Select @engg_custact_tooltip = null  

	IF @engg_custact_width = -915
		Select @engg_custact_width = null  

	IF @engg_customer_name = '~#~' 
		Select @engg_customer_name = null  

	IF @engg_process_descr = '~#~' 
		Select @engg_process_descr = null  

	IF @engg_project_name = '~#~' 
		Select @engg_project_name = null  

	IF @engg_req_no = '~#~' 
		Select @engg_req_no = null  

	IF @engg_ui_descr = '~#~' 
		Select @engg_ui_descr = null  

	IF @modeflag = '~#~' 
		Select @modeflag = null  

	IF @fprowno = -915
		Select @fprowno = null  

	 DECLARE @tmp_proc_name				engg_name,  
			 @tmp_comp_name				engg_name,  
			 @tmp_act_name				engg_name,  
			 @tmp_ui_name				engg_name,
			 @tmp_ctrl_id				engg_name,
			 @tmp_view_name				engg_name,
			 @engg_base_Req_no			engg_name,  
			 @sysdate					engg_Datetime,
			 @tmp_compprefix			engg_name,
			 @tmp_pageprefix			engg_name,
			 @tmp_ctlprefix				engg_name,
			 @tmp_secprefix				engg_name,  ----27jun2022
			 @tmp_taskname				engg_name,
			 @tmp_taskdesc				engg_description,
			 @tmp_tasksuffix			engg_code,
			 @tmp_ctl					engg_name,
			 @editable					engg_flag,
			 @visible					engg_flag,
			 @control_id				engg_name,
			 @ActCtrl_page_prefix		engg_name,
			 @taskseq					engg_seqno,
			 @linktype					engg_code,
			 @vorder					engg_seqno,
			 @horder					engg_seqno,
			 @control_doc				engg_description

 	 SET    @sysdate	=	GETDATE()  
	 SELECT @fprowno	=	@fprowno + 1  

	 SELECT @engg_base_Req_no = 'BASE'

	 SELECT @tmp_proc_name = RTRIM(process_name),
			@tmp_comp_name = RTRIM(component_name),
			@tmp_act_name  = RTRIM(activity_name),
			@tmp_ui_name   = RTRIM(ui_name)
	FROM ep_ui_req_dtl WITH (NOLOCK)
	WHERE	customer_name		= RTRIM(@engg_customer_name)
	AND		project_name		= RTRIM(@engg_project_name)
	AND		req_no				= RTRIM(@engg_req_no)
	AND		process_descr		= RTRIM(@engg_process_descr)
	AND		component_descr		= RTRIM(@engg_component)
	AND		activity_descr		= RTRIM(@engg_act_descr)
	AND		ui_descr			= RTRIM(@engg_ui_descr)

	SELECT  @tmp_ctrl_id	= control_id,
			@tmp_view_name	= view_name
	FROM ep_ui_control_dtl WITH (NOLOCK)
	WHERE	customer_name		=	 RTRIM(@engg_customer_name)
	AND		project_name		=	 RTRIM(@engg_project_name)
	AND		req_no				=	 RTRIM(@engg_base_Req_no)
	AND		process_name		=	 RTRIM(@tmp_proc_name)
	AND		component_name		=	 RTRIM(@tmp_comp_name)
	AND		activity_name		=	 RTRIM(@tmp_act_name)
	AND		ui_name				=	 RTRIM(@tmp_ui_name)
	AND		page_bt_synonym		=	 RTRIM(@engg_custact_pagename)
	AND		section_bt_synonym	=	 RTRIM(@engg_custact_secname)
	AND		control_bt_synonym	=	 RTRIM(@engg_custact_ctrlname)

	SELECT	@tmp_compprefix	= current_value
	FROM	es_comp_param_mst (NOLOCK)
	WHERE	customer_name	= @engg_customer_name
	AND		project_name	= @engg_project_name
	AND		process_name	= @tmp_proc_name
	AND		component_name	= @tmp_comp_name
	AND		param_category	= 'compprefix'

	SELECT	@tmp_pageprefix		= page_prefix
	FROM	ep_ui_page_dtl (NOLOCK)
	WHERE	customer_name		= @engg_customer_name
	AND		project_name		= @engg_project_name
	AND		process_name		= @tmp_proc_name
	AND		component_name		= @tmp_comp_name				
	AND		activity_name		= @tmp_act_name
	AND		ui_name				= @tmp_ui_name	
	AND		page_bt_synonym		= @engg_custact_pagename

	--27jun2022
	SELECT @tmp_secprefix		= section_prefix
	FROM	ep_ui_section_dtl (NOLOCK)
	WHERE	customer_name		= @engg_customer_name
	AND		project_name		= @engg_project_name
	AND		process_name		= @tmp_proc_name
	AND		component_name		= @tmp_comp_name				
	AND		activity_name		= @tmp_act_name
	AND		ui_name				= @tmp_ui_name	
	AND		page_bt_synonym		= @engg_custact_pagename
	AND		section_bt_synonym	= RTRIM(@engg_custact_secname)
	--27jun2022

	SELECT	@tmp_ctlprefix		= control_prefix
	FROM	ep_ui_control_dtl (NOLOCK)
	WHERE	customer_name		= @engg_customer_name
	AND		project_name		= @engg_project_name
	AND		process_name		= @tmp_proc_name
	AND		component_name		= @tmp_comp_name				
	AND		activity_name		= @tmp_act_name
	AND		ui_name				= @tmp_ui_name	
	AND		page_bt_synonym		= @engg_custact_pagename
	AND		section_bt_synonym	= RTRIM(@engg_custact_secname)
	AND		control_bt_synonym	= RTRIM(@engg_custact_ctrlname)
	

	IF ISNULL (@engg_custact_actiontype ,'' ) = ''   
	BEGIN  
       RAISERROR('Action Type cannot be blank at rowno : %i.',16,1,@fprowno)  
       RETURN  
	END  

	IF ISNULL (@engg_custact_actionseq ,'' ) = ''   
	BEGIN  
       RAISERROR('Action Sequence cannot be blank at rowno : %i.',16,1,@fprowno)  
       RETURN  
	END  

	IF ISNULL (@engg_custact_cntrbtsyn ,'' ) = ''   
	BEGIN  
       RAISERROR('Control BT Synonym cannot be blank at rowno : %i.',16,1,@fprowno)  
       RETURN  
	END  

	SELECT @tmp_ctl = CASE WHEN @engg_custact_actiontype = 'Trans' THEN 'Button'
						   WHEN @engg_custact_actiontype = 'Help'  THEN 'Edit'
					  ELSE 'Link' END

	IF ISNULL(@engg_custact_hdnctrl,'')='Control'  --TECH-70687
	BEGIN

	SELECT @vorder	=	ISNULL(MAX(vorder),0)+1
	FROM   ep_ui_control_dtl WITH (NOLOCK)
	WHERE	customer_name	= 	@engg_customer_name
	AND		project_name	=	@engg_project_name
	AND		req_no			=   @engg_base_req_no
	AND		process_name	=	@tmp_proc_name
	AND		component_name	=   @tmp_comp_name
	AND		activity_name	=   @tmp_act_name
	AND		ui_name			=   @tmp_ui_name
	AND		page_bt_synonym =	@engg_custact_pagename
	AND		section_bt_synonym =	@engg_custact_secname
	AND     Horder			=	501
	
	END
	--TECH-70687
	ELSE IF ISNULL(@engg_custact_hdnctrl,'')='Section'
	BEGIN

	SELECT @vorder	=	ISNULL(MAX(vorder),0)+1
	FROM   ep_ui_control_dtl WITH (NOLOCK)
	WHERE	customer_name	= 	@engg_customer_name
	AND		project_name	=	@engg_project_name
	AND		req_no			=   @engg_base_req_no
	AND		process_name	=	@tmp_proc_name
	AND		component_name	=   @tmp_comp_name
	AND		activity_name	=   @tmp_act_name
	AND		ui_name			=   @tmp_ui_name
	AND		page_bt_synonym =	@engg_custact_pagename
	AND		section_bt_synonym =	@engg_custact_secname
	AND     Horder			=	601
	
	END
	--TECH-70687

	SELECT @horder = CASE WHEN @engg_custact_hdnctrl	=	'Control' THEN 501				--TECH-70687
						  WHEN @engg_custact_hdnctrl	=	'Section' THEN 601	END

	SELECT @control_doc = CASE WHEN @engg_custact_hdnctrl	=	'Control' THEN  'System generated for Custom Action'			--TECH-70687
							   WHEN @engg_custact_hdnctrl	=	'Section' THEN  'System generated for Title Action'	END

	
	IF ISNULL(@modeflag,'') IN ('I','X')
	BEGIN
	exec ep_controlid_generation  
				@customer_name		=	@engg_customer_name,
				@project_name		=	@engg_project_name,
				@req_no				=	@engg_base_req_no,
				@process_name		=	@tmp_proc_name,
				@component_name		=	@tmp_comp_name,
				@activity_name		=	@tmp_act_name,
				@ui_name			=	@tmp_ui_name,
				@ctrl_bt_synonym	=	@engg_custact_cntrbtsyn,
				@base_ctrl_type		=	@tmp_ctl, 
				@edit_req			=	'Y', 
				@visible			=	'Y',  
				@control_id			=	@control_id output 
				

	EXEC engg_gen_prefix_id 
			@customer_name			=	@engg_customer_name,	
			@project_name			=	@engg_project_name,		
			@component_name			=	@tmp_comp_name,		
			@activity_name			=	@tmp_act_name,		
			@ui_name				=	@tmp_ui_name,	
			@ctrl_page_name			=	@engg_custact_cntrbtsyn,		
			@context				=	'C',
			@length					=	6,						
			@ctrl_page_id			=	@ActCtrl_page_prefix output
	
	EXEC  EP_UI_CONTROL_DTL_SP_INS
			@CTXT_LANGUAGE_IN			= @ctxt_Language,
			@CTXT_OUINSTANCE_IN			= @ctxt_OUInstance,
			@CTXT_SERVICE_IN			= @ctxt_Service,
			@CTXT_USER_IN				= @ctxt_User,
			@CUSTOMER_NAME_IN			= @engg_customer_name,
			@PROJECT_NAME_IN			= @engg_project_name,
			@REQ_NO_IN					= 'BASE',
			@PROCESS_NAME_IN			= @tmp_proc_name,
			@COMPONENT_NAME_IN			= @tmp_comp_name,
			@ACTIVITY_NAME_IN			= @tmp_act_name,
			@UI_NAME_IN					= @tmp_ui_name,
			@PAGE_BT_SYNONYM_IN			= @engg_custact_pagename,
			@SECTION_BT_SYNONYM_IN		= @engg_custact_secname,
			@CONTROL_BT_SYNONYM_IN		= @engg_custact_cntrBTsyn,
			@CONTROL_ID_IN				= @control_id,
			@CONTROL_TYPE_IN			= @tmp_ctl,
			@VISISBLE_LENGTH_IN			= 20,
			@HORDER_IN					= @horder,
			@VORDER_IN					= @vorder,
			@ORDER_SEQ_IN				= 1,
			@DATA_COLUMN_WIDTH_IN		= 0,
			@LABEL_COLUMN_WIDTH_IN		= 0,
			@PROTO_TOOLTIP_IN			= NULL,
			@SAMPLE_DATA_IN				= NULL,
			@CONTROL_DOC_IN				= @control_doc,
			@CONTROL_PREFIX_IN			= @ActCtrl_page_prefix,
			@LABEL_CONTROL_ID_IN		= '',
			@label_column_scalemode_in	= NULL,					
			@data_column_scalemode_in	= NULL,
			@engg_label_class_in		= NULL,
			@engg_control_class_in		= NULL,
			@engg_label_image_class_in	= NULL,
			@engg_control_image_class_in= NULL,
			@engg_tab_sequence_in		= 0,
			@engg_tab_stopforhelp_in	= 0,
			@TIMESTAMP_IN				= 1,
			@engg_req_no				= 'BASE',
			@user_pref					= 'Y',
			@freezecount				= NULL,
			@Engg_cont_Ctrlimg			= NULL,
			@Engg_cont_rowspan			= NULL,
			@Engg_cont_colspan			= NULL,
			@engg_cont_tempid			= NULL,
			@ctrl_temp_cat				= NULL,
			@ctrl_temp_specific			= NULL,
			@AccessKey					= NULL,
			@Icon_class					= NULL,
			@Icon_position				= NULL,
			@Cont_class_ext6			= NULL,
			@engg_dynamicstyle			= 0,
			@engg_imageasdata			= 0,
			@engg_extnreqd				= '',  
			@engg_MSC_Ass_control		= NULL,
			@Engg_cont_forresponsive	= NULL,
			@engg_cont_control_format	= NULL,	--TECH-73216
			@ButtonNature				= NULL,	--TECH-75230
			@InlineStyle				= NULL,	--TECH-75230
			@M_ERRORID					= @m_errorid OUTPUT

	EXEC ep_component_glossary_mst_sp_ins
			@CTXT_LANGUAGE_IN			=	@ctxt_language, 
			@CTXT_OUINSTANCE_IN			=	@ctxt_ouinstance, 
			@CTXT_SERVICE_IN			=	@ctxt_service, 
			@CTXT_USER_IN				=	@ctxt_user, 
			@CUSTOMER_NAME_IN			=	@engg_customer_name,
			@PROJECT_NAME_IN			=	@engg_project_name, 
			@REQ_NO_IN					=	@engg_base_req_no, 
			@PROCESS_NAME_IN			=	@tmp_proc_name, 
			@COMPONENT_NAME_IN			=	@tmp_comp_name, 
			@BT_SYNONYM_NAME_IN			=	@engg_custact_cntrBTsyn,
			@REF_BT_SYNONYM_NAME_IN		=	null, 
			@DATA_TYPE_IN				=	'Char', 
			@LENGTH_IN					=	60 , 
			@BT_SYNONYM_CAPTION_IN		=	@engg_custact_cntrBTsyn , 
			@BT_SYNONYM_DOC_IN			=	@engg_custact_cntrBTsyn ,
			@BT_NAME_IN					=	'' ,
			@SYNONYM_STATUS_IN			=	'U',
			@SINGLEINST_SAMPLE_DATA_IN	=	'',
			@MULTIINST_SAMPLE_DATA_IN	=	'', 
			@TIMESTAMP_IN				=	1,
			@ENGG_REQ_NO				=	@engg_req_no, 
			@M_ERRORID					=	@m_errorid out


		END

	If @engg_custact_actiontype	= 'Trans'
		SELECT @tmp_tasksuffix	= 'Tr'

	ELSE If @engg_custact_actiontype	= 'Help'
		SELECT @tmp_tasksuffix	= 'Hp'

	ELSE If @engg_custact_actiontype	= 'Link'
		SELECT @tmp_tasksuffix	= 'Lk'

	IF ISNULL( @engg_custact_hdnctrl,'')	=	'Control'
	BEGIN
	SET @tmp_taskname	= ISNULL(@tmp_compprefix,'') + ISNULL(@tmp_pageprefix,'') + ISNULL(@tmp_ctlprefix,'') + ISNULL(@ActCtrl_page_prefix,'') + ISNULL(@tmp_tasksuffix,'')
	SET @tmp_taskdesc	= 'Custom Action for the Control ' + isnull(@engg_custact_ctrlname,'') + ' - ' + isnull(@engg_custact_cntrbtsyn,'')
	END

	--TECH-70687
	IF ISNULL( @engg_custact_hdnctrl,'')	=	'Section'
	BEGIN
	SET @tmp_taskname	= ISNULL(@tmp_compprefix,'') + ISNULL(@tmp_pageprefix,'') + ISNULL(@tmp_secprefix,'') + ISNULL(@ActCtrl_page_prefix,'') + ISNULL(@tmp_tasksuffix,'')
	SET @tmp_taskdesc	= 'Title Action for the Section ' + isnull(@engg_custact_secname,'') + ' - ' + isnull(@engg_custact_cntrbtsyn,'')
	END
	--TECH-70687

	SELECT @taskseq = isnull(max(task_seq), 0) + 1
    FROM ep_Action_mst(NOLOCK)
    WHERE customer_name = @engg_customer_name
    AND project_name 	= @engg_project_name
    AND req_no 			= @engg_base_req_no
    AND process_name 	= @tmp_proc_name
    AND component_name 	= @tmp_comp_name
    AND activity_name 	= @tmp_act_name
    AND ui_name 		= @tmp_ui_name

	SELECT @linktype = CASE WHEN @engg_custact_actiontype	= 'Help' THEN 'Hlp' 
							WHEN @engg_custact_actiontype	= 'Link' THEN 'Lnk' 
							WHEN @engg_custact_actiontype	= 'Trans' THEN 'Lnk' END

	IF ISNULL(@modeflag,'') IN ('I','X')
	BEGIN
	EXEC ep_action_mst_sp_ins 
		@CTXT_LANGUAGE_IN	=	@ctxt_language,
		@CTXT_OUINSTANCE_IN	=	@ctxt_ouinstance,
		@CTXT_SERVICE_IN	=	@ctxt_service,
		@CTXT_USER_IN		=	@ctxt_user,
		@CUSTOMER_NAME_IN	=	@engg_customer_name,
		@PROJECT_NAME_IN	=	@engg_project_name,
		@REQ_NO_IN			=	'BASE',
		@PROCESS_NAME_IN	=	@tmp_proc_name,
		@COMPONENT_NAME_IN	=	@tmp_comp_name,
		@ACTIVITY_NAME_IN	=	@tmp_act_name,
		@UI_NAME_IN			=	@tmp_ui_name,
		@PAGE_BT_SYNONYM_IN	=	@engg_custact_pagename,
		@TASK_NAME_IN		=	@tmp_taskname,
		@TASK_DESCR_IN		=	@tmp_taskdesc,
		@TASK_SEQ_IN		=	@taskseq, 
		@TASK_PATTERN_IN	=	@engg_custact_actiontype,
		@PRIMARY_CONTROL_BTS_IN	=	@engg_custact_cntrbtsyn, 
		@BASE_TASK_TYPE_IN	=	@engg_custact_actiontype,
		@TIMESTAMP_IN		=	1,
		@engg_req_no		=	@engg_req_no,
		@M_ERRORID			=	@m_errorid OUTPUT

	IF @engg_custact_actiontype IN ('Help','Link')
	BEGIN

	EXEC ep_ui_traversal_dtl_sp_ins  
		@CTXT_LANGUAGE_IN		=	@ctxt_language,
		@CTXT_OUINSTANCE_IN		=	@ctxt_ouinstance,
		@CTXT_SERVICE_IN		=	@ctxt_service,
		@CTXT_USER_IN			=	@ctxt_user,
		@CUSTOMER_NAME_IN		=	@engg_customer_name,
		@PROJECT_NAME_IN		=	@engg_project_name,
		@REQ_NO_IN				=	'BASE',
		@PROCESS_NAME_IN		=	@tmp_proc_name,
		@COMPONENT_NAME_IN		=	@tmp_comp_name,
		@ACTIVITY_NAME_IN		=	@tmp_act_name,
		@UI_NAME_IN				=	@tmp_ui_name,
		@PAGE_BT_SYNONYM_IN		=	@engg_custact_pagename,
		@SECTION_BT_SYNONYM_IN	=	@engg_custact_secname,
		@CONTROL_BT_SYNONYM_IN	=	@engg_custact_cntrbtsyn,
		@LINK_TYPE_IN			=	@linktype,
		@LINKED_COMPONENT_IN	=	'',
		@LINKED_ACTIVITY_IN		=	'',
		@LINKED_UI_IN			=	'',
		@engg_links_asso_ctrl	=	'',
		@TIMESTAMP_IN			=	1,
		@engg_req_no			=	@engg_req_no,
		@Engg_links_width		=	'',
		@engg_links_height		=	'',
		@engg_toolbar_notreq	=	'',
		@engg_launch_type		=	'',
		@M_ERRORID				=	@m_errorid out
	END

END		

	IF ISNULL (@modeflag ,'' ) IN ('I','X')
	BEGIN
	IF ISNULL( @engg_custact_hdnctrl,'')	=	'Control'
	BEGIN
		IF NOT EXISTS( SELECT 'X' 
					   FROM    ep_ui_control_customaction WITH (NOLOCK)
					   WHERE   Customer_Name		=	RTRIM(@engg_customer_name)
					   AND     Project_Name			=	RTRIM(@engg_project_name)
					   AND	   Req_No				=	RTRIM(@engg_base_Req_no)
					   AND     Process_Name			=	RTRIM(@tmp_proc_name)
					   AND     component_name		=   RTRIM(@tmp_comp_name)
					   AND     activity_name		=	RTRIM(@tmp_act_name)
					   AND     ui_name				=	RTRIM(@tmp_ui_name )
					   AND     Page_BT_Synonym		=	RTRIM(@engg_custact_pagename)
					   AND     section_bt_synonym	=	RTRIM(@engg_custact_secname) 
					   AND     control_bt_synonym	=	RTRIM(@engg_custact_ctrlname)
					   AND     ActionControlBTSynonym=	RTRIM(@engg_custact_cntrbtsyn) )
		BEGIN
		
				INSERT INTO ep_ui_control_customaction
								( customer_name,				project_name,			req_no,						process_name,
								  component_name,				activity_name,			ui_name,					page_bt_synonym,
								  section_bt_synonym,			control_bt_synonym,		ActionControlBTSynonym,		Control_ID,
								  View_Name,					ActionType,				ActionSequence,				IconClass,
								  IconPosition,					
								  Width,					ToolTip,					ActionName,
								  ActionDescription,			ActionControlID,		ActionViewName,				Createdby,
								  Createddate,					Modifiedby,				Modifieddate )
				VALUES
				              (  @engg_customer_name,			@engg_project_name ,		@engg_base_Req_no,			@tmp_proc_name,
							     @tmp_comp_name,				@tmp_act_name,				@tmp_ui_name,				@engg_custact_pagename,
								 @engg_custact_secname,			@engg_custact_ctrlname,		@engg_custact_cntrbtsyn,	@tmp_ctrl_id,
								 @tmp_view_name,				@engg_custact_actiontype,	@engg_custact_actionseq,	@engg_custact_iconclass,
								 UPPER(SUBSTRING(@engg_custact_iconposition,1,1))+LOWER(REPLACE(@engg_custact_iconposition,SUBSTRING(@engg_custact_iconposition,1,1),'')),	
								 @engg_custact_width,		@engg_custact_tooltip,		@tmp_taskname,
								 @tmp_taskdesc,					@control_id,				@control_id,				@ctxt_user,
								 @sysdate,						@ctxt_user,					@sysdate)
				
				UPDATE ep_ui_control_dtl
				SET	   HasCustomAction = 'Y'
				FROM    ep_ui_control_dtl a WITH (NOLOCK)
				JOIN	ep_ui_control_customaction b WITH (NOLOCK)
				ON		a.customer_name			=	b.customer_name
				AND		a.project_name			=	b.project_name
				AND		a.req_no				=	b.Req_No
				AND     a.process_name			=	b.process_name
				AND		a.component_name		=	b.component_name
				AND		a.activity_name			=	b.activity_name
				AND		a.ui_name				=	b.ui_name
				AND		a.page_bt_synonym		=	b.page_bt_synonym
				AND		a.section_bt_synonym	=	b.section_bt_synonym
				AND		a.control_bt_synonym	=	b.control_bt_synonym
				WHERE   b.Customer_Name			=	RTRIM(@engg_customer_name)
				AND     b.Project_Name			=	RTRIM(@engg_project_name)
				AND	    b.Req_No				=	RTRIM(@engg_base_Req_no)
				AND     b.Process_Name			=	RTRIM(@tmp_proc_name)
				AND     b.component_name		=   RTRIM(@tmp_comp_name)
				AND     b.activity_name			=	RTRIM(@tmp_act_name)
				AND     b.ui_name				=	RTRIM(@tmp_ui_name )
				AND     b.Page_BT_Synonym		=	RTRIM(@engg_custact_pagename)
				AND     b.section_bt_synonym	=	RTRIM(@engg_custact_secname) 
				AND     b.control_bt_synonym	=	RTRIM(@engg_custact_ctrlname)
			END
		END

		--TECH-70687
		ELSE IF ISNULL( @engg_custact_hdnctrl,'')	=	'Section'
		BEGIN
		IF NOT EXISTS( SELECT 'X' 
					   FROM    ep_ui_section_titleaction WITH (NOLOCK)
					   WHERE   Customer_Name		=	RTRIM(@engg_customer_name)
					   AND     Project_Name			=	RTRIM(@engg_project_name)
					   AND	   Req_No				=	RTRIM(@engg_base_Req_no)
					   AND     Process_Name			=	RTRIM(@tmp_proc_name)
					   AND     component_name		=   RTRIM(@tmp_comp_name)
					   AND     activity_name		=	RTRIM(@tmp_act_name)
					   AND     ui_name				=	RTRIM(@tmp_ui_name )
					   AND     Page_BT_Synonym		=	RTRIM(@engg_custact_pagename)
					   AND     section_bt_synonym	=	RTRIM(@engg_custact_secname) 
					   AND     TitleControlBTSynonym=	RTRIM(@engg_custact_cntrbtsyn) )
		BEGIN
		
				INSERT INTO ep_ui_section_titleaction
								( customer_name,				project_name,			req_no,						process_name,
								  component_name,				activity_name,			ui_name,					page_bt_synonym,
								  section_bt_synonym,			TitleControlBTSynonym,	ActionType,					ActionSequence,				IconClass,
								  IconPosition,					Width,					ToolTip,					ActionName,
								  ActionDescription,			ActionControlID,		ActionViewName,				Createdby,
								  Createddate,					Modifiedby,				Modifieddate,			    TitleAction )
				VALUES
				              (  @engg_customer_name,			@engg_project_name ,		@engg_base_Req_no,			@tmp_proc_name,
							     @tmp_comp_name,				@tmp_act_name,				@tmp_ui_name,				@engg_custact_pagename,
								 @engg_custact_secname,			@engg_custact_cntrbtsyn,	@engg_custact_actiontype,	@engg_custact_actionseq,	@engg_custact_iconclass,
								 UPPER(SUBSTRING(@engg_custact_iconposition,1,1))+LOWER(REPLACE(@engg_custact_iconposition,SUBSTRING(@engg_custact_iconposition,1,1),'')),	@engg_custact_width,		@engg_custact_tooltip,		@tmp_taskname,
								 @tmp_taskdesc,					@control_id,				@control_id,				@ctxt_user,
								 @sysdate,						@ctxt_user,					@sysdate,					'Y')
				
				UPDATE ep_ui_section_dtl
				SET	   HasTitleAction = 'Y'
				FROM    ep_ui_section_dtl a WITH (NOLOCK)
				JOIN	ep_ui_section_titleaction b WITH (NOLOCK)
				ON		a.customer_name			=	b.customer_name
				AND		a.project_name			=	b.project_name
				AND		a.req_no				=	b.Req_No
				AND     a.process_name			=	b.process_name
				AND		a.component_name		=	b.component_name
				AND		a.activity_name			=	b.activity_name
				AND		a.ui_name				=	b.ui_name
				AND		a.page_bt_synonym		=	b.page_bt_synonym
				AND		a.section_bt_synonym	=	b.section_bt_synonym
				WHERE   b.Customer_Name			=	RTRIM(@engg_customer_name)
				AND     b.Project_Name			=	RTRIM(@engg_project_name)
				AND	    b.Req_No				=	RTRIM(@engg_base_Req_no)
				AND     b.Process_Name			=	RTRIM(@tmp_proc_name)
				AND     b.component_name		=   RTRIM(@tmp_comp_name)
				AND     b.activity_name			=	RTRIM(@tmp_act_name)
				AND     b.ui_name				=	RTRIM(@tmp_ui_name )
				AND     b.Page_BT_Synonym		=	RTRIM(@engg_custact_pagename)
				AND     b.section_bt_synonym	=	RTRIM(@engg_custact_secname) 
			
		END
	END  
	END

	IF ISNULL (@modeflag ,'' ) IN ('U','Y')
	BEGIN
	IF ISNULL( @engg_custact_hdnctrl,'')	=	'Control'
	BEGIN

		IF  EXISTS( SELECT 'X' 
					FROM    ep_ui_control_customaction WITH (NOLOCK)
					WHERE   Customer_Name			=	RTRIM(@engg_customer_name)
					AND     Project_Name			=	RTRIM(@engg_project_name)
					AND		Req_No					=	RTRIM(@engg_base_Req_no)
					AND     Process_Name			=	RTRIM(@tmp_proc_name)
					AND     component_name			=   RTRIM(@tmp_comp_name)
					AND     activity_name			=	RTRIM(@tmp_act_name)
					AND     ui_name					=	RTRIM(@tmp_ui_name )
					AND     Page_BT_Synonym			=	RTRIM(@engg_custact_pagename)
					AND     section_bt_synonym		=	RTRIM(@engg_custact_secname) 
					AND     control_bt_synonym		=	RTRIM(@engg_custact_ctrlname)
					AND     ActionControlBTSynonym	=	RTRIM(@engg_custact_cntrbtsyn))
		BEGIN
		        UPDATE ep_ui_control_customaction
				       SET ActionSequence		=	@engg_custact_actionseq,
						   ModifiedBy			=   @ctxt_user,
						   ModifiedDate			=   @sysdate

			    WHERE   Customer_Name			=	RTRIM(@engg_customer_name)
				AND     Project_Name			=	RTRIM(@engg_project_name)
				AND		Req_No					=	RTRIM(@engg_base_Req_no)
				AND     Process_Name			=	RTRIM(@tmp_proc_name)
				AND     component_name			=   RTRIM(@tmp_comp_name)
				AND     activity_name			=	RTRIM(@tmp_act_name)
				AND     ui_name					=	RTRIM(@tmp_ui_name )
				AND     Page_BT_Synonym			=	RTRIM(@engg_custact_pagename)
				AND     section_bt_synonym		=	RTRIM(@engg_custact_secname) 
				AND     control_bt_synonym		=	RTRIM(@engg_custact_ctrlname)
				AND     ActionControlBTSynonym	=	RTRIM(@engg_custact_cntrbtsyn)
		END
	END
	--TECH-70687
	ELSE IF ISNULL( @engg_custact_hdnctrl,'')	=	'Section'
	BEGIN

		IF  EXISTS( SELECT 'X' 
					FROM    ep_ui_section_Titleaction WITH (NOLOCK)
					WHERE   Customer_Name			=	RTRIM(@engg_customer_name)
					AND     Project_Name			=	RTRIM(@engg_project_name)
					AND		Req_No					=	RTRIM(@engg_base_Req_no)
					AND     Process_Name			=	RTRIM(@tmp_proc_name)
					AND     component_name			=   RTRIM(@tmp_comp_name)
					AND     activity_name			=	RTRIM(@tmp_act_name)
					AND     ui_name					=	RTRIM(@tmp_ui_name )
					AND     Page_BT_Synonym			=	RTRIM(@engg_custact_pagename)
					AND     section_bt_synonym		=	RTRIM(@engg_custact_secname) 
					AND     TitleControlBTSynonym	=	RTRIM(@engg_custact_cntrbtsyn))
		BEGIN
		        UPDATE ep_ui_section_Titleaction
				       SET ActionSequence		=	@engg_custact_actionseq,
						   ModifiedBy			=   @ctxt_user,
						   ModifiedDate			=   @sysdate

			    WHERE   Customer_Name			=	RTRIM(@engg_customer_name)
				AND     Project_Name			=	RTRIM(@engg_project_name)
				AND		Req_No					=	RTRIM(@engg_base_Req_no)
				AND     Process_Name			=	RTRIM(@tmp_proc_name)
				AND     component_name			=   RTRIM(@tmp_comp_name)
				AND     activity_name			=	RTRIM(@tmp_act_name)
				AND     ui_name					=	RTRIM(@tmp_ui_name )
				AND     Page_BT_Synonym			=	RTRIM(@engg_custact_pagename)
				AND     section_bt_synonym		=	RTRIM(@engg_custact_secname) 
				AND     TitleControlBTSynonym	=	RTRIM(@engg_custact_cntrbtsyn)
		END

	END
	END

	IF ISNULL (@modeflag ,'' )	=	'D'
	BEGIN
		IF  EXISTS( SELECT 'X' 
					FROM    ep_ui_control_customaction WITH (NOLOCK)
					WHERE   Customer_Name			=	RTRIM(@engg_customer_name)
					AND     Project_Name			=	RTRIM(@engg_project_name)
					AND		Req_No					=	RTRIM(@engg_base_Req_no)
					AND     Process_Name			=	RTRIM(@tmp_proc_name)
					AND     component_name			=   RTRIM(@tmp_comp_name)
					AND     activity_name			=	RTRIM(@tmp_act_name)
					AND     ui_name					=	RTRIM(@tmp_ui_name )
					AND     Page_BT_Synonym			=	RTRIM(@engg_custact_pagename)
					AND     section_bt_synonym		=	RTRIM(@engg_custact_secname) 
					AND     control_bt_synonym		=	RTRIM(@engg_custact_ctrlname)
					AND     ActionControlBTSynonym	=	RTRIM(@engg_custact_cntrbtsyn))
		BEGIN
					DELETE 
					FROM    ep_ui_control_customaction
					WHERE   Customer_Name			=	RTRIM(@engg_customer_name)
					AND     Project_Name			=	RTRIM(@engg_project_name)
					AND		Req_No					=	RTRIM(@engg_base_Req_no)
					AND     Process_Name			=	RTRIM(@tmp_proc_name)
					AND     component_name			=   RTRIM(@tmp_comp_name)
					AND     activity_name			=	RTRIM(@tmp_act_name)
					AND     ui_name					=	RTRIM(@tmp_ui_name )
					AND     Page_BT_Synonym			=	RTRIM(@engg_custact_pagename)
					AND     section_bt_synonym		=	RTRIM(@engg_custact_secname) 
					AND     control_bt_synonym		=	RTRIM(@engg_custact_ctrlname)
					AND     ActionControlBTSynonym	=	RTRIM(@engg_custact_cntrbtsyn)


					DELETE 
					FROM    ep_ui_control_dtl
					WHERE   Customer_Name			=	RTRIM(@engg_customer_name)
					AND     Project_Name			=	RTRIM(@engg_project_name)
					AND		Req_No					=	RTRIM(@engg_base_Req_no)
					AND     Process_Name			=	RTRIM(@tmp_proc_name)
					AND     component_name			=   RTRIM(@tmp_comp_name)
					AND     activity_name			=	RTRIM(@tmp_act_name)
					AND     ui_name					=	RTRIM(@tmp_ui_name )
					AND     Page_BT_Synonym			=	RTRIM(@engg_custact_pagename)
					AND     section_bt_synonym		=	RTRIM(@engg_custact_secname) 
					AND     control_bt_synonym		=	RTRIM(@engg_custact_cntrbtsyn)

					DELETE 
					FROM    ep_action_mst_lng_extn
					WHERE   customer_name			=	RTRIM(@engg_customer_name)
					AND     Project_Name			=	RTRIM(@engg_project_name)
					AND     Process_Name			=	RTRIM(@tmp_proc_name)
					AND     component_name			=   RTRIM(@tmp_comp_name)
					AND     activity_name			=	RTRIM(@tmp_act_name)
					AND     ui_name					=	RTRIM(@tmp_ui_name )
					AND     Page_BT_Synonym			=	RTRIM(@engg_custact_pagename)
					AND     task_name				=	RTRIM(@tmp_taskname) 

					DELETE 
					FROM    ep_action_mst
					WHERE   Customer_Name			=	RTRIM(@engg_customer_name)
					AND     Project_Name			=	RTRIM(@engg_project_name)
					AND		Req_No					=	RTRIM(@engg_base_Req_no)
					AND     Process_Name			=	RTRIM(@tmp_proc_name)
					AND     component_name			=   RTRIM(@tmp_comp_name)
					AND     activity_name			=	RTRIM(@tmp_act_name)
					AND     ui_name					=	RTRIM(@tmp_ui_name )
					AND     Page_BT_Synonym			=	RTRIM(@engg_custact_pagename)
					AND     primary_control_bts		=	RTRIM(@engg_custact_cntrbtsyn) 

					DELETE 
					FROM    ep_ui_traversal_dtl
					WHERE   Customer_Name			=	RTRIM(@engg_customer_name)
					AND     Project_Name			=	RTRIM(@engg_project_name)
					AND		Req_No					=	RTRIM(@engg_base_Req_no)
					AND     Process_Name			=	RTRIM(@tmp_proc_name)
					AND     component_name			=   RTRIM(@tmp_comp_name)
					AND     activity_name			=	RTRIM(@tmp_act_name)
					AND     ui_name					=	RTRIM(@tmp_ui_name )
					AND     Page_BT_Synonym			=	RTRIM(@engg_custact_pagename)
					AND     section_bt_synonym		=	RTRIM(@engg_custact_secname) 
					AND     control_bt_synonym		=	RTRIM(@engg_custact_cntrbtsyn)

			END
				IF NOT EXISTS
				(SELECT 'X' 
				 FROM    ep_ui_control_customaction WITH (NOLOCK)
				 WHERE   Customer_Name			=	RTRIM(@engg_customer_name)
				 AND     Project_Name			=	RTRIM(@engg_project_name)
				 AND	 Req_No					=	RTRIM(@engg_base_Req_no)
				 AND     Process_Name			=	RTRIM(@tmp_proc_name)
				 AND     component_name			=   RTRIM(@tmp_comp_name)
				 AND     activity_name			=	RTRIM(@tmp_act_name)
				 AND     ui_name				=	RTRIM(@tmp_ui_name )
				 AND     Page_BT_Synonym		=	RTRIM(@engg_custact_pagename)
				 AND     section_bt_synonym		=	RTRIM(@engg_custact_secname) 
				 AND     control_bt_synonym		=	RTRIM(@engg_custact_ctrlname))
				BEGIN
					UPDATE ep_ui_control_dtl
					SET	   HasCustomAction = 'N'
					WHERE   Customer_Name			=	RTRIM(@engg_customer_name)
					AND     Project_Name			=	RTRIM(@engg_project_name)
					AND	    Req_No					=	RTRIM(@engg_base_Req_no)
					AND     Process_Name			=	RTRIM(@tmp_proc_name)
					AND     component_name			=   RTRIM(@tmp_comp_name)
					AND     activity_name			=	RTRIM(@tmp_act_name)
					AND     ui_name					=	RTRIM(@tmp_ui_name )
					AND     Page_BT_Synonym			=	RTRIM(@engg_custact_pagename)
					AND     section_bt_synonym		=	RTRIM(@engg_custact_secname) 
					AND     control_bt_synonym		=	RTRIM(@engg_custact_ctrlname)	
				END	
					
		--TECH-70687
				IF  EXISTS( SELECT 'X' 
				FROM    ep_ui_section_Titleaction WITH (NOLOCK)
				WHERE   Customer_Name			=	RTRIM(@engg_customer_name)
				AND     Project_Name			=	RTRIM(@engg_project_name)
				AND		Req_No					=	RTRIM(@engg_base_Req_no)
				AND     Process_Name			=	RTRIM(@tmp_proc_name)
				AND     component_name			=   RTRIM(@tmp_comp_name)
				AND     activity_name			=	RTRIM(@tmp_act_name)
				AND     ui_name					=	RTRIM(@tmp_ui_name )
				AND     Page_BT_Synonym			=	RTRIM(@engg_custact_pagename)
				AND     section_bt_synonym		=	RTRIM(@engg_custact_secname) 
				AND     TitleControlBTSynonym	=	RTRIM(@engg_custact_cntrbtsyn))
				BEGIN
					DELETE 
					FROM    ep_ui_section_Titleaction
					WHERE   Customer_Name			=	RTRIM(@engg_customer_name)
					AND     Project_Name			=	RTRIM(@engg_project_name)
					AND		Req_No					=	RTRIM(@engg_base_Req_no)
					AND     Process_Name			=	RTRIM(@tmp_proc_name)
					AND     component_name			=   RTRIM(@tmp_comp_name)
					AND     activity_name			=	RTRIM(@tmp_act_name)
					AND     ui_name					=	RTRIM(@tmp_ui_name )
					AND     Page_BT_Synonym			=	RTRIM(@engg_custact_pagename)
					AND     section_bt_synonym		=	RTRIM(@engg_custact_secname) 
					AND     TitleControlBTSynonym	=	RTRIM(@engg_custact_cntrbtsyn)

					DELETE 
					FROM    ep_ui_control_dtl
					WHERE   Customer_Name			=	RTRIM(@engg_customer_name)
					AND     Project_Name			=	RTRIM(@engg_project_name)
					AND		Req_No					=	RTRIM(@engg_base_Req_no)
					AND     Process_Name			=	RTRIM(@tmp_proc_name)
					AND     component_name			=   RTRIM(@tmp_comp_name)
					AND     activity_name			=	RTRIM(@tmp_act_name)
					AND     ui_name					=	RTRIM(@tmp_ui_name )
					AND     Page_BT_Synonym			=	RTRIM(@engg_custact_pagename)
					AND     section_bt_synonym		=	RTRIM(@engg_custact_secname) 
					AND     control_bt_synonym		=	RTRIM(@engg_custact_cntrbtsyn)

					DELETE 
					FROM    ep_action_mst_lng_extn
					WHERE   customer_name			=	RTRIM(@engg_customer_name)
					AND     Project_Name			=	RTRIM(@engg_project_name)
					AND     Process_Name			=	RTRIM(@tmp_proc_name)
					AND     component_name			=   RTRIM(@tmp_comp_name)
					AND     activity_name			=	RTRIM(@tmp_act_name)
					AND     ui_name					=	RTRIM(@tmp_ui_name )
					AND     Page_BT_Synonym			=	RTRIM(@engg_custact_pagename)
					AND     task_name				=	RTRIM(@tmp_taskname) 

					DELETE 
					FROM    ep_action_mst
					WHERE   Customer_Name			=	RTRIM(@engg_customer_name)
					AND     Project_Name			=	RTRIM(@engg_project_name)
					AND		Req_No					=	RTRIM(@engg_base_Req_no)
					AND     Process_Name			=	RTRIM(@tmp_proc_name)
					AND     component_name			=   RTRIM(@tmp_comp_name)
					AND     activity_name			=	RTRIM(@tmp_act_name)
					AND     ui_name					=	RTRIM(@tmp_ui_name )
					AND     Page_BT_Synonym			=	RTRIM(@engg_custact_pagename)
					AND     primary_control_bts		=	RTRIM(@engg_custact_cntrbtsyn) 

					DELETE 
					FROM    ep_ui_traversal_dtl
					WHERE   Customer_Name			=	RTRIM(@engg_customer_name)
					AND     Project_Name			=	RTRIM(@engg_project_name)
					AND		Req_No					=	RTRIM(@engg_base_Req_no)
					AND     Process_Name			=	RTRIM(@tmp_proc_name)
					AND     component_name			=   RTRIM(@tmp_comp_name)
					AND     activity_name			=	RTRIM(@tmp_act_name)
					AND     ui_name					=	RTRIM(@tmp_ui_name )
					AND     Page_BT_Synonym			=	RTRIM(@engg_custact_pagename)
					AND     section_bt_synonym		=	RTRIM(@engg_custact_secname) 
					AND     control_bt_synonym		=	RTRIM(@engg_custact_cntrbtsyn)

				END

				IF NOT EXISTS
				(SELECT 'X' 
				 FROM    ep_ui_section_Titleaction WITH (NOLOCK)
				 WHERE   Customer_Name			=	RTRIM(@engg_customer_name)
				 AND     Project_Name			=	RTRIM(@engg_project_name)
				 AND	 Req_No					=	RTRIM(@engg_base_Req_no)
				 AND     Process_Name			=	RTRIM(@tmp_proc_name)
				 AND     component_name			=   RTRIM(@tmp_comp_name)
				 AND     activity_name			=	RTRIM(@tmp_act_name)
				 AND     ui_name				=	RTRIM(@tmp_ui_name )
				 AND     Page_BT_Synonym		=	RTRIM(@engg_custact_pagename)
				 AND     section_bt_synonym		=	RTRIM(@engg_custact_secname) 
				 )
				BEGIN
					UPDATE ep_ui_section_dtl
					SET	   HasTitleAction = 'N'
					WHERE   Customer_Name			=	RTRIM(@engg_customer_name)
					AND     Project_Name			=	RTRIM(@engg_project_name)
					AND	    Req_No					=	RTRIM(@engg_base_Req_no)
					AND     Process_Name			=	RTRIM(@tmp_proc_name)
					AND     component_name			=   RTRIM(@tmp_comp_name)
					AND     activity_name			=	RTRIM(@tmp_act_name)
					AND     ui_name					=	RTRIM(@tmp_ui_name )
					AND     Page_BT_Synonym			=	RTRIM(@engg_custact_pagename)
					AND     section_bt_synonym		=	RTRIM(@engg_custact_secname) 
				END	
		--TECH-70687
	END
	
 SELECT @fprowno  'fprowno'    
  

	/* 
	-- OutputList
	Select
		null 'fprowno', 
	*/

	Set nocount off
End
GO

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_layoutSpcasavecagrd' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON ep_layoutSpcasavecagrd TO PUBLIC
END
GO

