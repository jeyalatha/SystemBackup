IF EXISTS  (SELECT 'X' FROM SYSOBJECTS WHERE NAME ='ep_layout_sp_defsecscml' AND TYPE = 'P')
    BEGIN
        DROP PROC ep_layout_sp_defsecscml
    END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		ep_layout_sp_defsecscml.sql
********************************************************************************/
/*      V E R S I O N      :  PNR2.0_1403    */
/*      Released By        :  Development Team    */
/*      Release Comments   :  For DotNet Migration, Naming convention has been changed  for some of the out parameters by using Stub Generator.Comments will not be there for this Request ID.    */
/*      V E R S I O N      :  2.0.4    */
/*      Released By        :  Ptech    */
/*      Release Comments   :  Released On 30-September-2004    */
/*      V E R S I O N      :  2.0.2    */
/*      Released By        :  PTech    */
/*      Release Comments   :  Released on  22-Jan-2004    */
/********************************************************************************/
/* procedure      ep_layout_sp_defsecscml                                       */
/* description                                                                  */
/********************************************************************************/
/* project        Preview                                                       */
/* version                                                                      */
/********************************************************************************/
/* referenced                                                                   */
/* tables                                                                       */
/********************************************************************************/
/* development history                                                          */
/********************************************************************************/
/* author         Shafina Begum.B                                               */
/* date           1/ 12/ 2003                                                   */
/********************************************************************************/
/* modification history                                                         */
/********************************************************************************/
/* modified by                                                                  */
/* date                                                                         */
/* description                                                                  */
/********************************************************************************/
/* Modified by	:	VimalKumar R 												*/
/* Modified on	:	08/06/22				 									*/
/* Defect ID	:	TECH-69624													*/
/* Description	:	Custom border, Custom actions and Responsive layout			*/
/********************************************************************************/
/* Modified by	:	VimalKumar R 												*/
/* Modified on	:	02/11/22				 									*/
/* Defect ID	:	TECH-75230													*/
/* Description	:	Platform Release for the Month of Nov'22					*/
/********************************************************************************/
CREATE PROCEDURE ep_layout_sp_defsecscml
	@ctxt_language_in engg_ctxt_language,
	@ctxt_ouinstance_in engg_ctxt_ouinstance,
	@ctxt_service_in engg_ctxt_service,
	@ctxt_user_in engg_ctxt_user,
	@engg_act_descr_in engg_description,
	@engg_component_in engg_description,
	@engg_cont_page_bts_in engg_name,
	@engg_customer_name_in engg_name,
	@engg_enum_page_bts_in engg_name,
	@engg_grid_page_bts_in engg_name,
	@engg_lay_page_bts_in engg_name,
	@engg_process_descr_in engg_description,
	@engg_project_name_in engg_name,
	@engg_radpage_bts_in engg_name,
	@engg_req_no_in engg_name,
	@engg_rf_act_in engg_description,
	@engg_rf_comp_in engg_description,
	@engg_rf_ui_in engg_description,
	@engg_sec_bord_req_in engg_flag,
	@engg_sec_btsynname_in engg_name,
	@engg_sec_descr_in engg_description,
	@engg_sec_page_bts_in engg_name,
	@engg_sec_title_align_in engg_name,
	@engg_sec_title_req_in engg_flag,
	@engg_sec_visible_in engg_flag,
	@engg_sect_doc_in engg_documentation,
	@engg_ui_descr_in engg_description,
	@guid_in engg_guid,
	@modeflag_in engg_modeflag,
	@fprowno_io engg_rowno,
	@engg_sect_forresponsive engg_seqno,	--Code added for TECH-69624 on 01June2022
	@engg_sec_customborder	   engg_code, --Input	--Code added for TECH-69624 on 01June2022
	@Orientation		engg_name,		--Code Added for TECH-75230
	@m_errorid INT OUTPUT
AS
BEGIN
	SET NOCOUNT ON

	--declaration of temporary variables
	DECLARE @ctxt_language engg_ctxt_language
	DECLARE @ctxt_ouinstance engg_ctxt_ouinstance
	DECLARE @ctxt_service engg_ctxt_service
	DECLARE @ctxt_user engg_ctxt_user
	DECLARE @engg_act_descr engg_description
	DECLARE @engg_component engg_description
	DECLARE @engg_cont_page_bts engg_name
	DECLARE @engg_customer_name engg_name
	DECLARE @engg_enum_page_bts engg_name
	DECLARE @engg_grid_page_bts engg_name
	DECLARE @engg_lay_page_bts engg_name
	DECLARE @engg_process_descr engg_description
	DECLARE @engg_project_name engg_name
	DECLARE @engg_radpage_bts engg_name
	DECLARE @engg_req_no engg_name
	DECLARE @engg_rf_act engg_description
	DECLARE @engg_rf_comp engg_description
	DECLARE @engg_rf_ui engg_description
	DECLARE @engg_sec_bord_req engg_flag
	DECLARE @engg_sec_btsynname engg_name
	DECLARE @engg_sec_descr engg_description
	DECLARE @engg_sec_page_bts engg_name
	DECLARE @engg_sec_title_align engg_name
	DECLARE @engg_sec_title_req engg_flag
	DECLARE @engg_sec_visible engg_flag
	DECLARE @engg_sect_doc engg_documentation
	DECLARE @engg_ui_descr engg_description
	DECLARE @guid engg_guid
	DECLARE @modeflag engg_modeflag
	DECLARE @fprowno engg_rowno

	--temporary and formal parameters mapping
	SELECT @ctxt_language = @ctxt_language_in

	SELECT @ctxt_ouinstance = @ctxt_ouinstance_in

	SELECT @ctxt_service = ltrim(rtrim(@ctxt_service_in))

	SELECT @ctxt_user = ltrim(rtrim(@ctxt_user_in))

	SELECT @engg_act_descr = ltrim(rtrim(@engg_act_descr_in))

	SELECT @engg_component = ltrim(rtrim(@engg_component_in))

	SELECT @engg_cont_page_bts = ltrim(rtrim(@engg_cont_page_bts_in))

	SELECT @engg_customer_name = ltrim(rtrim(@engg_customer_name_in))

	SELECT @engg_enum_page_bts = ltrim(rtrim(@engg_enum_page_bts_in))

	SELECT @engg_grid_page_bts = ltrim(rtrim(@engg_grid_page_bts_in))

	SELECT @engg_lay_page_bts = ltrim(rtrim(@engg_lay_page_bts_in))

	SELECT @engg_process_descr = ltrim(rtrim(@engg_process_descr_in))

	SELECT @engg_project_name = ltrim(rtrim(@engg_project_name_in))

	SELECT @engg_radpage_bts = ltrim(rtrim(@engg_radpage_bts_in))

	SELECT @engg_req_no = ltrim(rtrim(@engg_req_no_in))

	SELECT @engg_rf_act = ltrim(rtrim(@engg_rf_act_in))

	SELECT @engg_rf_comp = ltrim(rtrim(@engg_rf_comp_in))

	SELECT @engg_rf_ui = ltrim(rtrim(@engg_rf_ui_in))

	SELECT @engg_sec_bord_req = ltrim(rtrim(@engg_sec_bord_req_in))

	SELECT @engg_sec_btsynname = ltrim(rtrim(@engg_sec_btsynname_in))

	SELECT @engg_sec_descr = ltrim(rtrim(@engg_sec_descr_in))

	SELECT @engg_sec_page_bts = ltrim(rtrim(@engg_sec_page_bts_in))

	SELECT @engg_sec_title_align = ltrim(rtrim(@engg_sec_title_align_in))

	SELECT @engg_sec_title_req = ltrim(rtrim(@engg_sec_title_req_in))

	SELECT @engg_sec_visible = ltrim(rtrim(@engg_sec_visible_in))

	SELECT @engg_sect_doc = ltrim(rtrim(@engg_sect_doc_in))

	SELECT @engg_ui_descr = ltrim(rtrim(@engg_ui_descr_in))

	SELECT @engg_sect_forresponsive = ltrim(rtrim(@engg_sect_forresponsive))

	SELECT @Orientation = ltrim(rtrim(@Orientation))		--Code Added for TECH-75230

	SELECT @guid = ltrim(rtrim(@guid_in))

	SELECT @modeflag = ltrim(rtrim(@modeflag_in))

	SELECT @fprowno = @fprowno_io

	--null checking
	IF @ctxt_language = - 915
		SELECT @ctxt_language = NULL

	IF @ctxt_ouinstance = - 915
		SELECT @ctxt_ouinstance = NULL

	IF @ctxt_service = '~#~'
		SELECT @ctxt_service = NULL

	IF @ctxt_user = '~#~'
		SELECT @ctxt_user = NULL

	IF @engg_act_descr = '~#~'
		SELECT @engg_act_descr = NULL

	IF @engg_component = '~#~'
		SELECT @engg_component = NULL

	IF @engg_cont_page_bts = '~#~'
		SELECT @engg_cont_page_bts = NULL

	IF @engg_customer_name = '~#~'
		SELECT @engg_customer_name = NULL

	IF @engg_enum_page_bts = '~#~'
		SELECT @engg_enum_page_bts = NULL

	IF @engg_grid_page_bts = '~#~'
		SELECT @engg_grid_page_bts = NULL

	IF @engg_lay_page_bts = '~#~'
		SELECT @engg_lay_page_bts = NULL

	IF @engg_process_descr = '~#~'
		SELECT @engg_process_descr = NULL

	IF @engg_project_name = '~#~'
		SELECT @engg_project_name = NULL

	IF @engg_radpage_bts = '~#~'
		SELECT @engg_radpage_bts = NULL

	IF @engg_req_no = '~#~'
		SELECT @engg_req_no = NULL

	IF @engg_rf_act = '~#~'
		SELECT @engg_rf_act = NULL

	IF @engg_rf_comp = '~#~'
		SELECT @engg_rf_comp = NULL

	IF @engg_rf_ui = '~#~'
		SELECT @engg_rf_ui = NULL

	IF @engg_sec_bord_req = '~#~'
		SELECT @engg_sec_bord_req = NULL

	IF @engg_sec_btsynname = '~#~'
		SELECT @engg_sec_btsynname = NULL

	IF @engg_sec_descr = '~#~'
		SELECT @engg_sec_descr = NULL

	IF @engg_sec_page_bts = '~#~'
		SELECT @engg_sec_page_bts = NULL

	IF @engg_sec_title_align = '~#~'
		SELECT @engg_sec_title_align = NULL

	IF @engg_sec_title_req = '~#~'
		SELECT @engg_sec_title_req = NULL

	IF @engg_sec_visible = '~#~'
		SELECT @engg_sec_visible = NULL

	IF @engg_sect_doc = '~#~'
		SELECT @engg_sect_doc = NULL

	IF @engg_ui_descr = '~#~'
		SELECT @engg_ui_descr = NULL

	IF @guid = '~#~'
		SELECT @guid = NULL

	IF @modeflag = '~#~'
		SELECT @modeflag = NULL

	IF @fprowno = - 915
		SELECT @fprowno = NULL

	IF @engg_sect_forresponsive = - 915
		SELECT @engg_sect_forresponsive = NULL	--Code added for TECH-69624

	IF @Orientation = '~#~'
		SELECT @Orientation = NULL	--Code Added for TECH-75230
		

	--errors mapped
	--output parameters
	--	select  null     'fprowno_io' /* DOTNET Migration Tool Changes */ 
	SET NOCOUNT OFF
END

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_layout_sp_defsecscml' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON ep_layout_sp_defsecscml TO PUBLIC
END
GO
