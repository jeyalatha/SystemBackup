IF EXISTS  (SELECT 'X' FROM SYSOBJECTS WHERE NAME ='ep_layout_sp_defctlcnml' AND TYPE = 'P')
    BEGIN
        DROP PROC ep_layout_sp_defctlcnml
    END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		ep_layout_sp_defctlcnml.sql
********************************************************************************/
/*      V E R S I O N      :  PNR2.0_1403    */
/*      Released By        :  Development Team    */
/*      Release Comments   :  For DotNet Migration, Naming convention has been changed  for some of the out parameters by using Stub Generator.Comments will not be there for this Request ID.    */
/*      V E R S I O N      :  2.0.4    */
/*      Released By        :  Ptech    */
/*      Release Comments   :  Released On 30-September-2004    */
/*      V E R S I O N      :  2.0.2    */
/*      Released By        :  PTech    */
/*      Release Comments   :  Released on  22-Jan-2004    */
/********************************************************************************/
/* procedure      ep_layout_sp_defctlcnml                                       */
/* description                                                                  */
/********************************************************************************/
/* project        Preview                                                       */
/* version                                                                      */
/********************************************************************************/
/* referenced                                                                   */
/* tables                                                                       */
/********************************************************************************/
/* development history                                                          */
/********************************************************************************/
/* author         Shafina Begum.B                                               */
/* date           1/ 12/ 2003                                                   */
/********************************************************************************/
/* modification history                                                         */
/********************************************************************************/
/* modified by			Date				Defect ID							*/
/* Veena U				08-Jun-2016			PLF2.0_18487						*/
/* Modified by : Rajeswari M/Priyadharshini U Date: 28-Jul-2021  Defect ID : TECH-60451    */
/* TECH-60451  : Launching Help&Link UIs, Popup sections and Grid Extensions in Side Drawer*/
/* TECH-63527  : Associate Control added in ep_ui_control_dtl for Multiselectcombo*/ 
/********************************************************************************/
/* Modified by	:	VimalKumar R 												*/
/* Modified on	:	08/06/22				 									*/
/* Defect ID	:	TECH-69624													*/
/* Description	:	Custom border, Custom actions and Responsive layout			*/
/********************************************************************************/
/* Modified by    :    Ponmalar A                                               */
/* Modified on    :    02/12/22                                                 */
/* Defect ID      :    TECH-75230												*/
/* Description    : Platform Release for the Month of Nov'22				    */
/********************************************************************************/
CREATE PROCEDURE ep_layout_sp_defctlcnml
	@ctxt_language_in engg_ctxt_language,
	@ctxt_ouinstance_in engg_ctxt_ouinstance,
	@ctxt_service_in engg_ctxt_service,
	@ctxt_user_in engg_ctxt_user,
	@engg_act_descr_in engg_description,
	@engg_component_in engg_description,
	@engg_cont_btsynname_in engg_name,
	@engg_cont_datawidth_in engg_flag,
	@engg_cont_descr_in engg_description,
	@engg_cont_doc_in engg_documentation,
	@engg_cont_elem_type_in engg_description,
	@engg_cont_horder_in engg_seqno,
	@engg_cont_labwidth_in engg_flag,
	@engg_cont_page_bts_in engg_name,
	@engg_cont_samp_data_in engg_documentation,
	@engg_cont_sec_bts_in engg_name,
	@engg_cont_sequence_in engg_seqno,
	@engg_cont_tooltip_in engg_documentation,
	@engg_cont_vis_length_in engg_length,
	@engg_cont_vorder_in engg_seqno,
	@engg_customer_name_in engg_name,
	@engg_enum_page_bts_in engg_name,
	@engg_enum_sec_bts_in engg_name,
	@engg_grid_page_bts_in engg_name,
	@engg_grid_sec_bts_in engg_name,
	@engg_process_descr_in engg_description,
	@engg_project_name_in engg_name,
	@engg_radpage_bts_in engg_name,
	@engg_radsec_bts_in engg_name,
	@engg_req_no_in engg_name,
	@engg_rf_act_in engg_description,
	@engg_rf_comp_in engg_description,
	@engg_rf_ui_in engg_description,
	@engg_ui_descr_in engg_description,
	@guid_in engg_guid,
	@modeflag_in engg_modeflag,
	@fprowno_io engg_rowno,
	@ctrl_temp_cat engg_name, --Input 
	@ctrl_temp_specific engg_documentation, --Input 
	@m_errorid INT OUTPUT,
	 --code added on 19th July 2021
	@engg_extnreqd			engg_seqno,   --Input
	@engg_extension			engg_code,     --Input
	@engg_MSC_Ass_control	engg_name,	--Input
	@engg_cont_customborder	engg_code,	--Input	--Code added for TECH-69624	
	@engg_cont_customaction	engg_code,	--Input	--Code added for TECH-69624
	@Engg_cont_forresponsive engg_seqno, --Input	--Code Added for TECH-69624
	@ButtonNature			engg_name,	--Code added for TECH-75230
	@InlineStyle			engg_nvarchar_max	--Code added for TECH-75230
AS
BEGIN
	SET NOCOUNT ON

	--declaration of temporary variables
	DECLARE @ctxt_language engg_ctxt_language
	DECLARE @ctxt_ouinstance engg_ctxt_ouinstance
	DECLARE @ctxt_service engg_ctxt_service
	DECLARE @ctxt_user engg_ctxt_user
	DECLARE @engg_act_descr engg_description
	DECLARE @engg_component engg_description
	DECLARE @engg_cont_btsynname engg_name
	DECLARE @engg_cont_datawidth engg_flag
	DECLARE @engg_cont_descr engg_description
	DECLARE @engg_cont_doc engg_documentation
	DECLARE @engg_cont_elem_type engg_description
	DECLARE @engg_cont_horder engg_seqno
	DECLARE @engg_cont_labwidth engg_flag
	DECLARE @engg_cont_page_bts engg_name
	DECLARE @engg_cont_samp_data engg_documentation
	DECLARE @engg_cont_sec_bts engg_name
	DECLARE @engg_cont_sequence engg_seqno
	DECLARE @engg_cont_tooltip engg_documentation
	DECLARE @engg_cont_vis_length engg_length
	DECLARE @engg_cont_vorder engg_seqno
	DECLARE @engg_customer_name engg_name
	DECLARE @engg_enum_page_bts engg_name
	DECLARE @engg_enum_sec_bts engg_name
	DECLARE @engg_grid_page_bts engg_name
	DECLARE @engg_grid_sec_bts engg_name
	DECLARE @engg_process_descr engg_description
	DECLARE @engg_project_name engg_name
	DECLARE @engg_radpage_bts engg_name
	DECLARE @engg_radsec_bts engg_name
	DECLARE @engg_req_no engg_name
	DECLARE @engg_rf_act engg_description
	DECLARE @engg_rf_comp engg_description
	DECLARE @engg_rf_ui engg_description
	DECLARE @engg_ui_descr engg_description
	DECLARE @guid engg_guid
	DECLARE @modeflag engg_modeflag
	DECLARE @fprowno engg_rowno

	--temporary and formal parameters mapping
	SELECT @ctxt_language = @ctxt_language_in

	SELECT @ctxt_ouinstance = @ctxt_ouinstance_in

	SELECT @ctxt_service = ltrim(rtrim(@ctxt_service_in))

	SELECT @ctxt_user = ltrim(rtrim(@ctxt_user_in))

	SELECT @engg_act_descr = ltrim(rtrim(@engg_act_descr_in))

	SELECT @engg_component = ltrim(rtrim(@engg_component_in))

	SELECT @engg_cont_btsynname = ltrim(rtrim(@engg_cont_btsynname_in))

	SELECT @engg_cont_datawidth = ltrim(rtrim(@engg_cont_datawidth_in))

	SELECT @engg_cont_descr = ltrim(rtrim(@engg_cont_descr_in))

	SELECT @engg_cont_doc = ltrim(rtrim(@engg_cont_doc_in))

	SELECT @engg_cont_elem_type = ltrim(rtrim(@engg_cont_elem_type_in))

	SELECT @engg_cont_horder = @engg_cont_horder_in

	SELECT @engg_cont_labwidth = ltrim(rtrim(@engg_cont_labwidth_in))

	SELECT @engg_cont_page_bts = ltrim(rtrim(@engg_cont_page_bts_in))

	SELECT @engg_cont_samp_data = ltrim(rtrim(@engg_cont_samp_data_in))

	SELECT @engg_cont_sec_bts = ltrim(rtrim(@engg_cont_sec_bts_in))

	SELECT @engg_cont_sequence = @engg_cont_sequence_in

	SELECT @engg_cont_tooltip = ltrim(rtrim(@engg_cont_tooltip_in))

	SELECT @engg_cont_vis_length = @engg_cont_vis_length_in

	SELECT @engg_cont_vorder = @engg_cont_vorder_in

	SELECT @engg_customer_name = ltrim(rtrim(@engg_customer_name_in))

	SELECT @engg_enum_page_bts = ltrim(rtrim(@engg_enum_page_bts_in))

	SELECT @engg_enum_sec_bts = ltrim(rtrim(@engg_enum_sec_bts_in))

	SELECT @engg_grid_page_bts = ltrim(rtrim(@engg_grid_page_bts_in))

	SELECT @engg_grid_sec_bts = ltrim(rtrim(@engg_grid_sec_bts_in))

	SELECT @engg_process_descr = ltrim(rtrim(@engg_process_descr_in))

	SELECT @engg_project_name = ltrim(rtrim(@engg_project_name_in))

	SELECT @engg_radpage_bts = ltrim(rtrim(@engg_radpage_bts_in))

	SELECT @engg_radsec_bts = ltrim(rtrim(@engg_radsec_bts_in))

	SELECT @engg_req_no = ltrim(rtrim(@engg_req_no_in))

	SELECT @engg_rf_act = ltrim(rtrim(@engg_rf_act_in))

	SELECT @engg_rf_comp = ltrim(rtrim(@engg_rf_comp_in))

	SELECT @engg_rf_ui = ltrim(rtrim(@engg_rf_ui_in))

	SELECT @engg_ui_descr = ltrim(rtrim(@engg_ui_descr_in))

	SELECT @guid = ltrim(rtrim(@guid_in))

	SELECT @modeflag = ltrim(rtrim(@modeflag_in))

	SELECT @fprowno = @fprowno_io

	--null checking
	IF @ctxt_language = - 915
		SELECT @ctxt_language = NULL

	IF @ctxt_ouinstance = - 915
		SELECT @ctxt_ouinstance = NULL

	IF @ctxt_service = '~#~'
		SELECT @ctxt_service = NULL

	IF @ctxt_user = '~#~'
		SELECT @ctxt_user = NULL

	IF @engg_act_descr = '~#~'
		SELECT @engg_act_descr = NULL

	IF @engg_component = '~#~'
		SELECT @engg_component = NULL

	IF @engg_cont_btsynname = '~#~'
		SELECT @engg_cont_btsynname = NULL

	IF @engg_cont_datawidth = '~#~'
		SELECT @engg_cont_datawidth = NULL

	IF @engg_cont_descr = '~#~'
		SELECT @engg_cont_descr = NULL

	IF @engg_cont_doc = '~#~'
		SELECT @engg_cont_doc = NULL

	IF @engg_cont_elem_type = '~#~'
		SELECT @engg_cont_elem_type = NULL

	IF @engg_cont_horder = - 915
		SELECT @engg_cont_horder = NULL

	IF @engg_cont_labwidth = '~#~'
		SELECT @engg_cont_labwidth = NULL

	IF @engg_cont_page_bts = '~#~'
		SELECT @engg_cont_page_bts = NULL

	IF @engg_cont_samp_data = '~#~'
		SELECT @engg_cont_samp_data = NULL

	IF @engg_cont_sec_bts = '~#~'
		SELECT @engg_cont_sec_bts = NULL

	IF @engg_cont_sequence = - 915
		SELECT @engg_cont_sequence = NULL

	IF @engg_cont_tooltip = '~#~'
		SELECT @engg_cont_tooltip = NULL

	IF @engg_cont_vis_length = - 915
		SELECT @engg_cont_vis_length = NULL

	IF @engg_cont_vorder = - 915
		SELECT @engg_cont_vorder = NULL

	IF @engg_customer_name = '~#~'
		SELECT @engg_customer_name = NULL

	IF @engg_enum_page_bts = '~#~'
		SELECT @engg_enum_page_bts = NULL

	IF @engg_enum_sec_bts = '~#~'
		SELECT @engg_enum_sec_bts = NULL

	IF @engg_grid_page_bts = '~#~'
		SELECT @engg_grid_page_bts = NULL

	IF @engg_grid_sec_bts = '~#~'
		SELECT @engg_grid_sec_bts = NULL

	IF @engg_process_descr = '~#~'
		SELECT @engg_process_descr = NULL

	IF @engg_project_name = '~#~'
		SELECT @engg_project_name = NULL

	IF @engg_radpage_bts = '~#~'
		SELECT @engg_radpage_bts = NULL

	IF @engg_radsec_bts = '~#~'
		SELECT @engg_radsec_bts = NULL

	IF @engg_req_no = '~#~'
		SELECT @engg_req_no = NULL

	IF @engg_rf_act = '~#~'
		SELECT @engg_rf_act = NULL

	IF @engg_rf_comp = '~#~'
		SELECT @engg_rf_comp = NULL

	IF @engg_rf_ui = '~#~'
		SELECT @engg_rf_ui = NULL

	IF @engg_ui_descr = '~#~'
		SELECT @engg_ui_descr = NULL

	IF @guid = '~#~'
		SELECT @guid = NULL

	IF @modeflag = '~#~'
		SELECT @modeflag = NULL

	IF @fprowno = - 915
		SELECT @fprowno = NULL

	IF @engg_extnreqd = -915
		SELECT @engg_extnreqd = NULL

	IF @engg_extension = '~#~'
		SELECT @engg_extension = NULL ---Code added for TECH-60451

	IF @engg_MSC_Ass_control = '~#~'
		SELECT @engg_MSC_Ass_control = NULL ---Code added for TECH-63527

	IF @Engg_cont_forresponsive = - 915
		SELECT @Engg_cont_forresponsive = NULL	--Code added for TECH-69624

	IF @ButtonNature = '~#~'
		SELECT @ButtonNature = NULL	--Code added for TECH-75230

	IF @InlineStyle = '~#~'
		SELECT @InlineStyle = NULL	--Code added for TECH-75230

	--errors mapped
	--output parameters
	--	select  null     'fprowno_io' /* DOTNET Migration Tool Changes */ 
	SET NOCOUNT OFF
END
GO

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_layout_sp_defctlcnml' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON ep_layout_sp_defctlcnml TO PUBLIC
END
GO


