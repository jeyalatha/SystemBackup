IF EXISTS  (SELECT 'X' FROM SYSOBJECTS WHERE NAME ='ep_maireeSpFetchengcolspO' AND TYPE = 'P')
    Begin
        Drop PROC ep_maireeSpFetchengcolspO
    End
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		ep_maireeSpFetchengcolspO.sql
********************************************************************************/
/******************************************************************************/
/* Procedure					: ep_maireeSpFetchengcolspO								 */
/* Description					: 								 */
/******************************************************************************/
/* Project						: 								 */
/* EcrNo						: 								 */
/* Version						: 								 */
/******************************************************************************/
/* Referenced					: 								 */
/* Tables						: 								 */
/******************************************************************************/
/* Development history			: 								 */
/******************************************************************************/
/* Author						: ModelExplorer								 */
/* Date							: May 13 2016  5:07PM								 */
/******************************************************************************/
/* Modification History			: 								 */
/******************************************************************************/
/* modified by			Date				Defect ID							*/
/* Veena U				08-Jun-2016			PLF2.0_18487						*/
/********************************************************************************/
/* Modified by : Jeya Latha K/Ganesh Prabhu S	for callid TECH-7349				*/
/* Modified on : 14-03-2017				 											*/
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and New Feature Organization chart */
/***********************************************************************************/
/* Modified by : Ganesh Prabhu S/Ranjitha R      for callid  TECH-10118                   */
/* Modified on : 30-May-2017                                                                                        */
/* Description : Platform Feature Release                                                              */
/***********************************************************************************************/
/* Modified by    :    VimalKumar R                                                            */
/* Modified on    :    03/11/22                                                                */
/* Defect ID      :    TECH-73052															   */
/* Description    :    Need new column- Column caption from Respective grid controls-In column
                       grouping tab in addition with existing Column name/synonym.             */
/***********************************************************************************************/
CREATE PROCEDURE ep_maireeSpFetchengcolspO
	@ctxt_ouinstance ctxt_ouinstance, --Input 
	@ctxt_user ctxt_user, --Input 
	@ctxt_language ctxt_language, --Input 
	@ctxt_service ctxt_service, --Input 
	@engg_act_descr engg_description, --Input 
	@engg_component engg_description, --Input 
	@engg_control_name engg_name, --Input 
	@engg_customer_name engg_name, --Input 
	@engg_group_caption engg_description, --Input 
	@engg_group_name engg_name, --Input 
	@engg_group_seq engg_seqno, --Input 
	@engg_page_name engg_name, --Input 
	@engg_process_descr engg_description, --Input 
	@engg_project_name engg_name, --Input 
	@engg_req_no engg_name, --Input 
	@engg_sect_name engg_name, --Input 
	@engg_ui_descr engg_description, --Input 
	@fprowno rowno, --Input/Output
	@m_errorid INT OUTPUT --To Return Execution Status
AS
BEGIN
	-- nocount should be switched on to prevent phantom rows
	SET NOCOUNT ON
	-- @m_errorid should be 0 to Indicate Success
	SET @m_errorid = 0
	--declaration of temporary variables
	--temporary and formal parameters mapping
	SET @ctxt_user = ltrim(rtrim(@ctxt_user))
	SET @ctxt_service = ltrim(rtrim(@ctxt_service))
	SET @engg_act_descr = ltrim(rtrim(@engg_act_descr))
	SET @engg_component = ltrim(rtrim(@engg_component))
	SET @engg_control_name = ltrim(rtrim(@engg_control_name))
	SET @engg_customer_name = ltrim(rtrim(@engg_customer_name))
	SET @engg_group_caption = ltrim(rtrim(@engg_group_caption))
	SET @engg_group_name = ltrim(rtrim(@engg_group_name))
	SET @engg_page_name = ltrim(rtrim(@engg_page_name))
	SET @engg_process_descr = ltrim(rtrim(@engg_process_descr))
	SET @engg_project_name = ltrim(rtrim(@engg_project_name))
	SET @engg_req_no = ltrim(rtrim(@engg_req_no))
	SET @engg_sect_name = ltrim(rtrim(@engg_sect_name))
	SET @engg_ui_descr = ltrim(rtrim(@engg_ui_descr))

	--null checking
	IF @ctxt_ouinstance = - 915
		SELECT @ctxt_ouinstance = NULL

	IF @ctxt_user = '~#~'
		SELECT @ctxt_user = NULL

	IF @ctxt_language = - 915
		SELECT @ctxt_language = NULL

	IF @ctxt_service = '~#~'
		SELECT @ctxt_service = NULL

	IF @engg_act_descr = '~#~'
		SELECT @engg_act_descr = NULL

	IF @engg_component = '~#~'
		SELECT @engg_component = NULL

	IF @engg_control_name = '~#~'
		SELECT @engg_control_name = NULL

	IF @engg_customer_name = '~#~'
		SELECT @engg_customer_name = NULL

	IF @engg_group_caption = '~#~'
		SELECT @engg_group_caption = NULL

	IF @engg_group_name = '~#~'
		SELECT @engg_group_name = NULL

	IF @engg_group_seq = - 915
		SELECT @engg_group_seq = NULL

	IF @engg_page_name = '~#~'
		SELECT @engg_page_name = NULL

	IF @engg_process_descr = '~#~'
		SELECT @engg_process_descr = NULL

	IF @engg_project_name = '~#~'
		SELECT @engg_project_name = NULL

	IF @engg_req_no = '~#~'
		SELECT @engg_req_no = NULL

	IF @engg_sect_name = '~#~'
		SELECT @engg_sect_name = NULL

	IF @engg_ui_descr = '~#~'
		SELECT @engg_ui_descr = NULL

	IF @fprowno = - 915
		SELECT @fprowno = NULL

	DECLARE @tmp_proc engg_name,
		@tmp_comp engg_name,
		@tmp_act engg_name,
		@tmp_ui engg_name,
		@seqno engg_seqno,
		@sequence engg_seqno

	SELECT @tmp_proc = rtrim(process_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_req_no)
		AND process_descr = rtrim(@engg_process_descr)

	SELECT @tmp_comp = rtrim(component_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_descr = rtrim(@engg_component)

	SELECT TOP 1 @tmp_act = rtrim(activity_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp)
		AND activity_descr = RTRIM(@engg_act_descr)

	SELECT TOP 1 @tmp_ui = rtrim(ui_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND process_name = rtrim(@tmp_proc)
		AND req_no = rtrim(@engg_req_no)
		AND component_name = rtrim(@tmp_comp)
		AND activity_name = rtrim(@tmp_act)
		AND ui_descr = RTRIM(@engg_ui_descr)

	SELECT @seqno = MAX(sequenceno)
	FROM ep_ui_column_group_mapping(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp)
		AND activity_name = rtrim(@tmp_act)
		AND ui_name = rtrim(@tmp_ui)
		AND page_bt_synonym = rtrim(@engg_page_name)
		AND section_bt_synonym = rtrim(@engg_Sect_name)
		AND grid_control_bt_synonym = RTRIM(@engg_control_name)
		AND group_name = RTRIM(@engg_group_name)

	SELECT @sequence = count(DISTINCT column_bt_synonym)
	FROM ep_ui_grid_dtl grd(NOLOCK)
	WHERE grd.customer_name = rtrim(@engg_customer_name)
		AND grd.project_name = rtrim(@engg_project_name)
		AND grd.process_name = rtrim(@tmp_proc)
		AND grd.component_name = rtrim(@tmp_comp)
		AND grd.activity_name = rtrim(@tmp_act)
		AND grd.ui_name = rtrim(@tmp_ui)
		AND grd.page_bt_synonym = rtrim(@engg_page_name)
		AND grd.section_bt_synonym = rtrim(@engg_Sect_name)
		AND grd.control_bt_synonym = RTRIM(@engg_control_name)
		AND isnull(grd.visible, 'No') = 'YES'
		AND grd.column_bt_synonym NOT IN (
			SELECT DISTINCT column_bt_synonym
			FROM ep_ui_column_group_mapping(NOLOCK)
			WHERE customer_name = rtrim(@engg_customer_name)
				AND project_name = rtrim(@engg_project_name)
				AND process_name = rtrim(@tmp_proc)
				AND component_name = rtrim(@tmp_comp)
				AND activity_name = rtrim(@tmp_act)
				AND ui_name = rtrim(@tmp_ui)
				AND page_bt_synonym = rtrim(@engg_page_name)
				AND section_bt_synonym = rtrim(@engg_Sect_name)
				AND grid_control_bt_synonym = RTRIM(@engg_control_name)
			)

	SELECT DISTINCT colgrp.column_bt_synonym 'engg_col_or_group',
		mapped_entity 'engg_mapped_entity',
		1 'engg_ui_map',
		SequenceNo 'engg_map_seq',
		--Code Added for TECH-73052 starts
		mst.bt_synonym_caption 'engg_col_caption'  
	FROM ep_ui_column_group_mapping colgrp(NOLOCK)
	join ep_component_glossary_mst	mst(nolock)
		on  colgrp.customer_name = mst.customer_name
		and	colgrp.project_name = mst.project_name
		and	colgrp.process_name = mst.process_name
		and	colgrp.component_name = mst.component_name
		and colgrp.column_bt_synonym = mst.bt_synonym_name
		--Code Added for TECH-73052 ends
	WHERE colgrp.customer_name = rtrim(@engg_customer_name)
		AND colgrp.project_name = rtrim(@engg_project_name)
		AND colgrp.process_name = rtrim(@tmp_proc)
		AND colgrp.component_name = rtrim(@tmp_comp)
		AND colgrp.activity_name = rtrim(@tmp_act)
		AND colgrp.ui_name = rtrim(@tmp_ui)
		AND colgrp.page_bt_synonym = rtrim(@engg_page_name)
		AND colgrp.section_bt_synonym = rtrim(@engg_Sect_name)
		AND colgrp.grid_control_bt_synonym = RTRIM(@engg_control_name)
		AND colgrp.group_name = RTRIM(@engg_group_name)
	
	UNION
	
	SELECT DISTINCT column_bt_synonym 'engg_col_or_group',
		'Column' 'engg_mapped_entity',
		0 'engg_ui_map',
		isnull(@seqno, 0) + ROW_NUMBER() OVER (
			ORDER BY Column_bt_synonym
			) 'engg_map_seq',
			--Code Added for TECH-73052 starts
	bt_synonym_caption   'engg_col_caption' 
	FROM ep_ui_grid_dtl grd(NOLOCK)
	join ep_component_glossary_mst	mst(nolock)
		on grd.customer_name = mst.customer_name
		and	grd.project_name = mst.project_name
		and	grd.process_name = mst.process_name
		and	grd.component_name = mst.component_name
		and grd.column_bt_synonym = mst.bt_synonym_name
		--Code Added for TECH-73052 ends
	WHERE grd.customer_name = rtrim(@engg_customer_name)
		AND grd.project_name = rtrim(@engg_project_name)
		AND grd.process_name = rtrim(@tmp_proc)
		AND grd.component_name = rtrim(@tmp_comp)
		AND grd.activity_name = rtrim(@tmp_act)
		AND grd.ui_name = rtrim(@tmp_ui)
		AND grd.page_bt_synonym = rtrim(@engg_page_name)
		AND grd.section_bt_synonym = rtrim(@engg_Sect_name)
		AND grd.control_bt_synonym = RTRIM(@engg_control_name)
		AND isnull(grd.visible, 'No') = 'YES'
		AND grd.column_bt_synonym NOT IN (
			SELECT DISTINCT column_bt_synonym
			FROM ep_ui_column_group_mapping(NOLOCK)
			WHERE customer_name = rtrim(@engg_customer_name)
				AND project_name = rtrim(@engg_project_name)
				AND process_name = rtrim(@tmp_proc)
				AND component_name = rtrim(@tmp_comp)
				AND activity_name = rtrim(@tmp_act)
				AND ui_name = rtrim(@tmp_ui)
				AND page_bt_synonym = rtrim(@engg_page_name)
				AND section_bt_synonym = rtrim(@engg_Sect_name)
				AND grid_control_bt_synonym = RTRIM(@engg_control_name)
			)
	
	UNION
	
	SELECT DISTINCT Group_name 'engg_col_or_group',
		'Group' 'engg_mapped_entity',
		0 'engg_ui_map',
		isnull(@seqno, 0) + isnull(@sequence, 0) + ROW_NUMBER() OVER (
			ORDER BY group_name
			) 'engg_map_seq',
		Group_caption 'engg_col_caption' --Code Added for TECH-73052
	FROM ep_ui_columngroup(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp)
		AND activity_name = rtrim(@tmp_act)
		AND ui_name = rtrim(@tmp_ui)
		AND page_bt_synonym = rtrim(@engg_page_name)
		AND section_bt_synonym = rtrim(@engg_Sect_name)
		AND grid_control_bt_synonym = RTRIM(@engg_control_name)
		AND group_name <> RTRIM(@engg_group_name)
		AND group_name <> 'GridControl'
		AND group_name NOT IN (
			SELECT DISTINCT column_bt_synonym
			FROM ep_ui_column_group_mapping(NOLOCK)
			WHERE customer_name = rtrim(@engg_customer_name)
				AND project_name = rtrim(@engg_project_name)
				AND process_name = rtrim(@tmp_proc)
				AND component_name = rtrim(@tmp_comp)
				AND activity_name = rtrim(@tmp_act)
				AND ui_name = rtrim(@tmp_ui)
				AND page_bt_synonym = rtrim(@engg_page_name)
				AND section_bt_synonym = rtrim(@engg_Sect_name)
				AND grid_control_bt_synonym = RTRIM(@engg_control_name)
			)
		AND group_name NOT IN (
			SELECT DISTINCT Group_name
			FROM ep_ui_column_group_mapping(NOLOCK)
			WHERE customer_name = rtrim(@engg_customer_name)
				AND project_name = rtrim(@engg_project_name)
				AND process_name = rtrim(@tmp_proc)
				AND component_name = rtrim(@tmp_comp)
				AND activity_name = rtrim(@tmp_act)
				AND ui_name = rtrim(@tmp_ui)
				AND page_bt_synonym = rtrim(@engg_page_name)
				AND section_bt_synonym = rtrim(@engg_Sect_name)
				AND grid_control_bt_synonym = RTRIM(@engg_control_name)
				AND column_bt_synonym = RTRIM(@engg_group_name)
			)
	ORDER BY 3 DESC,
		4,
		2,
		1



	/* 
	--OutputList
		Select
		null 'fprowno', 
		null 'engg_col_or_group', 
		null 'engg_mapped_entity', 
		null 'engg_map_seq', 
		null 'engg_ui_map', 
	*/
	SET NOCOUNT OFF
END

GO
IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_maireeSpFetchengcolspO' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON  ep_maireeSpFetchengcolspO TO PUBLIC
END
GO