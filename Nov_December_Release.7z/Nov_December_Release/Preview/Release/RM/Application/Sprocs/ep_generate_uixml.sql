IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_generate_uixml' AND TYPE = 'P')
BEGIN
	DROP PROC ep_generate_uixml                                                                                               
END
GO
--WARNING! ERRORS ENCOUNTERED DURING SQL PARSING!
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		ep_generate_uixml.sql
********************************************************************************/
/*      V E R S I O N      :  PNR2.0_25308    */
/*      Released By        :  Development Team    */
/*      Release Comments   :  Phase 4 Release    */
/************************************************************************************
procedure name and id   ep_generate_uixml
description             load the hidden combo after genereate preview
name of the author      vasu k
date created            23-Oct-2003
query file name         ep_generate_uixml.sql
modifications history
--------------------------------------------------------------------------------------
modified by             Ramachandran.T
modified date           25 Dec 2003
modified purpose        Request no is removed in all the where clause

Ramachandran.T
26 Dec 2003
All the key columns in the generated xml files is converted to
upper case

Senthil Kumar s4
26 Apr 2005
PNR2.0_2162 - While generating the HTMs using the Engineering Dashboard tool,
some of the HTMs are not getting generated. Need Help. very urgent..
************************************************************************************/
/*
Modification  : Ganesh on 15/06/05
Bugid    : PNR2.0_2882
Bug Descr  : When help is taken ,data is not getting transferred back to the parent screen.
*/
/********************************************************************************/
/* modification history                                                         */
/* Modified by : Ganesh for callid PNR2.0_3023         */
/* Modified on : 24/06/2005              */
/* Description : For the Edit control defined in the hidden section , the horder & vorder was not properly set. */
/********************************************************************************/
/* modification history                                                         */
/* Modified by : Ganesh for callid PNR2.0_3762         */
/* Modified on : 05/09/2005              */
/* Description : Multi line Shrink is to be handled in Preview Generation. */
/********************************************************************************/
/* modification history                                                         */
/* Modified by : Balaji S for callid PNR2.0_4146          */
/* Modified on : 06/09/2005              */
/* Description : In RumTime HTml,the trail bar at the bottom is wrapped and right aligned */
/********************************************************************************/
/*Modification  : Lavanya on 24/10/2005
Bugid   :Platform_2.0.3.1_27
Bug Descr : In Specify Layout i have given one new section itz getting saved but not able to generate the preview.
*/
/********************************************************************************/
/* modification history                                                         */
/* Modified by : Ganesh for callid PNR2.0_4395          */
/* Modified on : 26/09/2005              */
/* Description : Tab Index not in sequence.          */
/********************************************************************************/
/* modification history                                                         */
/* Modified by : Ganesh for callid PNR2.0_4658          */
/* Modified on : 16th Nov 2005              */
/* Description : The table ep_genxml_tmp is to be get cleaned up.    */
/********************************************************************************/
/* modification history                                                   */
/* Modified by : Balaji for callid PNR2.0_4719          */
/* Modified on : 21th Nov 2005              */
/* Description : Html Generation Should be ui level.       */
/********************************************************************************/
/* modification history                                                         */
/* Modified by : Balaji for callid PNR2.0_4780          */
/* Modified on : 25th Nov 2005              */
/* Description : Html is not getting Generated for Some of the Uis.    */
/********************************************************************************/
/* modification history                                                         */
/* Modified by : Sangeetha L for callid PNR2.0_5812        */
/* Modified on : 30th Jan 2006              */
/* Description : Page Prefix tag is added in page Node       */
/********************************************************************************/
/* Modified by : Sangeetha L for             */
/* Modified on : 24th Feb 2006              */
/* Description : PNR2.0_6595             */
/********************************************************************************/
/* Modified by : Balaji S for BugId : PNR2.0_7273        */
/* Modified on : 20 Mar 2006              */
/* Description : Adding Section Height,Width,Height scale Mode,Width scale Mode */
/********************************************************************************/
/* Modified by : Anuradha M for BugId : PNR2.0_7393        */
/* Modified on : 22 Mar 2006              */
/* Description : To handle the combo with interger datatype      */
/********************************************************************************/
/* modification history                                                         */
/* Modified by : Balaji S for callid PNR2.0_7420        */
/* Modified on : 23 Mar 2006              */
/* Description : For Tree Section,Label & width scale mode should be Pixel only */
/********************************************************************************/
/* modification history                                                         */
/* Modified by : Balaji S for callid PNR2.0_7461        */
/* Modified on : 24 Mar 2006              */
/* Description : For Offline Package Service,configuration Tag has to be removed from xml. */
/********************************************************************************/
/* Modified by :Sangeetha L for callid PNR2.0_7668        */
/* Modified on : 03 Apr 2006              */
/* Description : Activity Tag is Coming as Null         */
/********************************************************************************/
/* Modified by :Gowrisankar M for callid PNR2.0_7691       */
/* Modified on : 04-Apr-2006              */
/* Description : Newly added columns are not generated for preview    */
/********************************************************************************/
/* Modified by : Balaji S for callid PNR2.0_8069        */
/* Modified on : 20 Apr 2006              */
/* Description : Language id attribute has to be included in Activity Tag.  */
/********************************************************************************/
/* Modified by : Anuradha M for callid PNR2.0_7964    */
/* Modified on : 25-Apr-2006        */
/* Description : Tab index not getting generated properly if parent section is defined */
/********************************************************************************/
/* Modified by :Sangeetha L for callid PNR2.0_8351        */
/* Modified on : 08 May 2006              */
/********************************************************************************/
/* Modified by : Balaji S for callid PNR2.0_8748        */
/* Modified on : 01 Jun 2006              */
/* Description : Tool Tip should be come in like what we have given.   */
/********************************************************************************/
/* Modified by : kiruthika R for callid PNR2.0_8637        */
/* Modified on : 03 june 2006              */
/********************************************************************************/
/* modified by     Balaji S                                                      */
/* date            21 June 2006                                                  */
/* description     BugId :PNR2.0_8896                                            */
/********************************************************************************/
/* modified by     Balaji S                                                      */
/* date            23 June 2006                                                  */
/* description     BugId :PNR2.0_9025                                            */
/********************************************************************************/
/* modified by     kiruthika R                                                      */
/* date            29 June 2006                                                  */
/* description     BugId :PNR2.0_9189                                            */
/********************************************************************************/
/* modified by  : Balaji S                                                    */
/* date         : 29-JUN-2006                                                    */
/* Bug Id  : PNR2.0_9131       */
/* Description  : New Base Control Type Label */
/********************************************************************************/
/* modified by  : Balaji S                                                     */
/* date         : 06-JUL-2006                                                   */
/* Bug Id   : PNR2.0_9320             */
/* Description  : Horder,Vorder is duplicating for tab control     */
/********************************************************************************/
/* modified by  : Balaji S                                                     */
/* date         : 11-JUL-2006                                                   */
/* Bug Id   : PNR2.0_9414             */
/* Description  : Label Control is not displaying        */
/********************************************************************************/
/* modified by  : Balaji S                                                     */
/* date         : 27-JUL-2006                                                   */
/* Bug Id   : PNR2.0_9660             */
/* Description  : for button,visible length should be defaulted to 20   */
/********************************************************************************/
/* modified by  : kiruthika R                                                   */
/* date         : 03-Aug-2006                                                    */
/* Bug Id   : PNR2.0_9777             */
/********************************************************************************/
/* modified by  : Balaji S                                                     */
/* date         : 17-Oct-2006                                                   */
/* Bug Id   : PNR2.0_10535              */
/********************************************************************************/
/* modified by  : Balaji S                                                     */
/* date         : 01-Nov-2006                                                   */
/* Bug Id   : PNR2.0_10741              */
/********************************************************************************/
/* modified by  : Anuradha M                                                    */
/* date         : 08-Nov-2006                                                   */
/* Bug Id   : PNR2.0_10874              */
/********************************************************************************/
/* modified by  : Balaji S                                               */
/* date         : 27-Nov-2006                                                   */
/* Bug Id   : PNR2.0_11183              */
/********************************************************************************/
/* Modified by : Chanheetha N A             */
/* Modified on : 28-Nov-2006              */
/* Bug ID      : PNR2.0_11203             */
/********************************************************************************/
/* Modified by : Balaji S              */
/* Modified on : 01-Dec-2006              */
/* Bug ID      : PNR2.0_11270              */
/********************************************************************************/
/* Modified by : Balaji S              */
/* Modified on : 06-Dec-2006              */
/* Bug ID      : PNR2.0_11293              */
/********************************************************************************/
/* Modified by : Balaji S              */
/* Modified on : 28-Dec-2006              */
/* Bug ID      : PNR2.0_11597              */
/********************************************************************************/
/* Modified by : Balaji S              */
/* Modified on : 08-Jan-2007              */
/* Bug ID      : PNR2.0_11746               */
/********************************************************************************/
/* Modified by : Balaji S              */
/* Modified on : 13-Jan-2007              */
/* Bug ID      : PNR2.0_12227               */
/********************************************************************************/
/* Modified by : Anuradha M              */
/* Modified on : 15-Mar-2007              */
/* Bug ID      : PNR2.0_12645               */
/********************************************************************************/
/* Modified by : Balaji S              */
/* Modified on : 27-apr-2007              */
/* Bug ID      : PNR2.0_13438               */
/********************************************************************************/
/* Modified by : Balaji S              */
/* Modified on : 07-May-2007              */
/* Bug ID      : PNR2.0_13541               */
/********************************************************************************/
/* modified by  : kiruthika R                                                   */
/* date         : 27-Jun-2007                                                    */
/* Bug Id   : PNR2.0_14287             */
/********************************************************************************/
/* Modified by : Balaji S              */
/* Modified on : 29-jun-2007              */
/* Bug ID      : PNR2.0_14336               */
/********************************************************************************/
/* modified by  : kiruthika R                                                   */
/* date         : 03-Jul-2007                                                  */
/* Bug Id   : PNR2.0_14358             */
/********************************************************************************/
/* modified by  : kiruthika R                                                   */
/* date         : 16-Jul-2007                                                  */
/* Bug Id  : PNR2.0_14487       */
/********************************************************************************/
/* modified by  : Balaji S                                                      */
/* date         : 20-Jul-2007                                                  */
/* Bug Id  : PNR2.0_14590       */
/********************************************************************************/
/* modified by  : kiruthika R                                                   */
/* date         : 23-Jul-2007                                                  */
/* Bug Id   : PNR2.0_14628             */
/********************************************************************************/
/* modified by  : Balaji S                                                      */
/* date         : 08-Jul-2007                                                  */
/* Bug Id  : PNR2.0_14879        */
/********************************************************************************/
/* modified by  : Balaji S                                                      */
/* date         : 17-Sep-2007                                                  */
/* Bug Id  : PNR2.0_15338        */
/********************************************************************************/
/* modified by  : kiruthika R                                                   */
/* date         : 17-Oct-2007                                                  */
/* Bug Id   : PNR2.0_15700             */
/********************************************************************************/
/* modified by  : kiruthika R                                                   */
/* date         : 29-Nov-2007                                                  */
/* Bug Id  : PNR2.0_16123              */
/********************************************************************************/
/* modified by  : Balaji S                                                      */
/* date         : 17-Jan-2008                                                  */
/* Bug Id  : PNR2.0_16478               */
/********************************************************************************/
/* modified by  : Balaji S                                                      */
/* date         : 28-Jan-2008                                                  */
/* Bug Id   : PNR2.0_16619              */
/********************************************************************************/
/* modified by  : Chanheetha N A                                                */
/* date         : 23-Apr-2008                                                  */
/* Bug Id  : PNR2.0_17707               */
/********************************************************************************/
/* Modified by  : Gowrisankar for PNR2.0_17733                                  */
/* Date         : 24-Apr-2008                                                   */
/* Description : Modifying varchar datatypes to nvarchar datatypes    */
/********************************************************************************/
/* Modified by  : S.Sivakumar For PNR2.0_17856                                  */
/* Date         : 08-MAY-2008                                                   */
/* Description : 1.To specify separate Class for Filler controls    */
/*     2.To specify whether lines needed above and below OK Button */
/*     3.To avoid white spaces above OK Button for Help screens. */
/********************************************************************************/
/* Modified by  :  N A Chanheetha                                     */
/* Date         :  20-May-2008                                                 */
/* Description : Provision for aligning the checkbox caption to right   */
/* Bug Id  :  PNR2.0_17974             */
/********************************************************************************/
/* modified by  : Jeya Latha K                                                  */
/* date         : 25-Apr-2008                                                   */
/* Bug Id    : PNR2.0_1476                     */
/********************************************************************************/
/* modified by  : Feroz                                                    */
/* date         : 02-May-2008                                                  */
/* Description : Inplace Calendar and Edit Mask Feature added     */
/********************************************************************************/
/* modified by  : Jeya Latha K                                                  */
/* date         : 13-May-2008                                                   */
/* Bug Id   : For Access Key Feature           */
/********************************************************************************/
/* Modified by  :  Gopinath S             */
/* Date         :  12-june-2008                                      */
/* Description :  For controls of type Filler2,        */
/*     two vertical orders are not derived for certain sections.   */
/* Bug Id  :  PNR2.0_18194
/********************************************************************************/
/* Modified by  :  Sangeetha G                      */
/* Date         :  14-july-2008                                                 */
/* Description  :  Active tab page colour should be different.    */
/*            Page Class to be captured in Preview level. */
/* Bug Id   :  PNR2.0_18516                  */
/********************************************************************************/            */
/* modified by  : Jeya Latha K                                                  */
/* date         : 21-Jul-2008                                                   */
/* Bug Id   : PNR2.0_18629       */
/********************************************************************************/
/* modified by  : Anuradha M                                                    */
/* date         : 28-Jul-2008                                                   */
/* Bug Id   : PNR2.0_18732       */
/* Bug Desc   : UI type Main Modify to be checked for the activity  */
/********************************************************************************/
/* modified by  : Jeya Latha K                                                  */
/* date         : 08-Sep-2008                                                  */
/* Bug Id    : PNR2.0_19279 (StatusMessage, ConfirmationMessage, CVS, Manual*/
/*    Report and ExcelReport attributes have been added for tasks. */
/**********************************************************************************************/
/* modified by  : Sangeetha G                                                                */
/* date         : 30-Sep-2008                                                          */
/* Bug Id   : PNR2.0_19426                       */
/* Bug Desc     : Cannot insert the value NULL into column 'gen_xml', table                   */
/*                'rvw20appdb.dbo.ep_genxml_tmp'; column does not allow nulls                 */
/**********************************************************************************************/
/* modified by  : Praveen kumar A                                                                */
/* date         : 06-Oct-2008                                                          */
/* Bug Id  : PNR2.0_19525                       */
/* Bug Desc     : XML is not getting generated if Task Status meessage contains '&' symbol      */
/**********************************************************************************************/
/* modified by  : Jeya Latha K                                                                */
/* date         : 21-Oct-2008                                                          */
/* Bug Id    : PNR2.0_19757                       */
/* Bug Desc     : Manual report value is duplicated in generated XML.                    */
/**********************************************************************************************/
/* modified by  : Gopinath S                                                               */
/* date         : 14-Nov-2008                                                          */
/* Bug Id    : PNR2.0_19995                      */
/* Bug Desc     : while using the tab key to forward the cursor should not stop on the search buttons  */
/**********************************************************************************************/
/* modified by  : Sangeetha  G                                                               */
/* date         : 24-Nov-2008                                                                */
/* Bug Id       : PNR2.0_20049                                 */
/* Bug Desc     : Ellipse property applicable only to controls of datatype char              */
/**********************************************************************************************/
/* modified by   : Feroz           */
/* date     : 26-nov-2008         */
/* BugId    : PNR2.0_1790          */
/************************************************************************/
/* modified by   : Feroz           */
/* date     : 20-Jan-2009         */
/* BugId    : PNR2.0_20730          */
/************************************************************************/
/* modified by   : Feroz           */
/* date     : 21-Jan-2009         */
/* BugId : PNR2.0_20754          */
/************************************************************************/
/* modified by  : Sangeetha G                                                      */
/* date         : 11-Feb-2009                                                                    */
/* Bug Id       : PNR2.0_20849                                        */
/* Bug Desc     : To include NoofLinesPerRow,RowHeight,Vscrollbar_Req,language settings property  */
/**************************************************************************************************/
/* modified by  : Gowrisankar M                                                       */
/* date         : 18-Feb-2009                                                                    */
/* Bug Id       : PNR2.0_21118                                              */
/* Modification : 1. To set value for AssociateTask property for Datahyperlinks       */
/*       2. For OK Button addition the control type Button to be made caps as BUTTON   */
/*       3. For all the joins in preview req_no has been added in where clause (Comments */
/*      would not be available in the lines where the this change has been made)   */
/**************************************************************************************************/
/* modified by  : Gowrisankar M                                                          */
/* date         : 25-Feb-2009                                                                    */
/* Bug Id       : PNR2.0_21234                                               */
/* Modification : 1. To exclude duplicate TabControl Sections in sections tag        */
/*       2. Unicode sample data to be handled              */
/**************************************************************************************************/
/* modified by  : Gowrisankar M                                                          */
/* date         : 13-Mar-2009                                                                    */
/* Bug Id       : PNR2.0_21450                                                */
/* Modification : Handling Tab Sequence defined by the user             */
/**************************************************************************************************/
/* modified by  : Sangeetha G                                                       */
/* date         : 15-Apr-2009                                                                    */
/* Bug Id       : PNR2.0_21576                                         */
/* Modification : To include the gridlite property for grid type controls       */
/**************************************************************************************************/
/* modified by  : Sangeetha G                                                       */
/* date         : 10-June-2009                                                                    */
/* Bug Id       : PNR2.0_22481                                        */
/* Modification : Tabindex  to  be  handled  for  Link and  grid control types      */
/********************************************************************************************************/
/* modified by    : Sangeetha G         */
/* date     : 22-June-2009        */
/* BugId    : PNR2.0_22560          */
/* Description    : To  handle the tab  index for OK  button in  help  uis.  */
/********************************************************************************************************/
/* modified by  : Feroz                                                */
/* date         : 04-Aug-2009                                                   */
/* Bug Id   : PNR2.0_2179             */
/* Description  : Phase 3 Features - ListEdit, AttachDocument, Image & DateHighlight */
/********************************************************************************/
/* modified by    : Sangeetha G         */
/* date     : 21-Aug-2009        */
/* BugId    : PNR2.0_23175         */
/* Description    : Excel Report preview not  working      */
/********************************************************************************************************/
/* Modified By     : Feroz           */
/* Date       : 26-Aug-2009         */
/* Description     : PNR2.0_23463          */
/******************************************************************************/
/* modified by   : Sangeetha G         */
/* date       : 03-Sep-2009        */
/* BugId      : PNR2.0_23635        */
/* Description   : Control type and  base ctrl type to be in  upper case       */
/********************************************************************************************************/
/* Modified By    : Feroz        */
/* Date     : 04-Sep-2009       */
/* Description    : PNR2.0_23654        */
/********************************************************************************************************/
/* Modified By    : Feroz        */
/* Date      : 15-Sep-2009       */
/* Description    : PNR2.0_23862        */
/********************************************************************************************************/
/* Modified By : Senthil Kumar S         */
/* Date  : 22-Sep-2009          */
/* BugId     : PNR2.0_23999                 */
/* Description : While generating preview, the multiline control not get displayed.   */
/********************************************************************************************************/
/* modified by   : Gopinath S                  */
/* date       : 23-Sep-2009                 */
/* BugId      : PNR2.0_24034                 */
/* Description   : Temporary table has to be created instead of table variable for list edit feature. */
/********************************************************************************************************/
/* modified by  : Gowrisankar M                               */
/* date        : 21-Dec-2009                                */
/* BugId       : PNR2.0_25330                                */
/* Description  : Decimal length variables to be defaulted for every iteration        */
/********************************************************************************************************/
/* modified by  : Sangeetha G                                */
/* date        : 6-Jan-2010                                */
/* BugId       : PNR2.0_25483                                */
/* Description  : State content in preview level       */
/********************************************************************************************************/
/* modified by  : Gopinath S                                */
/* date         : 11-Jan-2010                                */
/* BugId        : PNR2.0_25510                                */
/* Description  : Error on preview activity -There is already an object named '#maplist' in the database  */
/********************************************************************************************************/
/* modified by  : Feroz                                                */
/* date         : 19-Jan-2010                                                   */
/* Bug Id   : PNR2.0_25308             */
/* Description  : Phase 4 Features            */
/********************************************************************************************************/
/* Modified By     :  Jeya Latha K        */
/* Date       :  05-Feb-10         */
/* Description     :  BugID : PNR2.0_25842      */
/********************************************************************************************************/
/* Modified By     :  Jeya Latha K        */
/* Date       :  24-Feb-2010         */
/* Description     :  Bug ID PNR2.0_26058       */
/********************************************************************************************************/
/* modified by  : Senthil Kumar S            */
/* date         : 05-Apr-2010             */
/* BugId        : PNR2.0_26450             */
/* Description  : OK button Section not coming properly in help screens.  */
/********************************************************************************************************/
/* modified by  : Sangeeetha G             */
/* date         : 20-Apr-2010             */
/* BugId        : PNR2.0_26631             */
/* Description  : ListEdit did not work when handled across page within UI  */
/*************************************************************************************************************************/
/* Modified By     : Sangeetha G           */
/* Date      : 28-Apr-2010          */
/* Bug Id      : PNR2.0_26701           */
/* Description     : Column addition for ListEdit Resolve tables */
/*************************************************************************************************************************/
/* Modified by  : Makesh Prabu R            */
/* Date         : 05-April-2010             */
/* CaseID  : PNR2.0_26469             */
/* Description  : Change the Sourcesafe scripts to 90 compatible    */
/********************************************************************************/
/* Modified By      : Chanheetha N A               */
/* Date            : 14-May-2010             */
/* BugID       : PNR2.0_26860              */
/* Modified For      : Extra column to specify freezecount                   */
/********************************************************************************/
/* Modified By      : S.Sivakumar               */
/* Date            : 6-JUL-2010             */
/* BugID       : PNR2.0_27436              */
/* Modified For      : For Control Cursor, End Been Shifted after Deallocate */
/********************************************************************************/
/* Modified By      : Chanheetha N A                     */
/* Date            : 04-Aug-2010                   */
/* BugID       : PNR2.0_27796                  */
/* Description  : Attach document for htm environment       */
/************************************************************************************/
/* Modified By      : Kiruthika                          */
/* Date            : 24-Aug-2010                   */
/* BugID       : PNR2.0_27888                  */
/* Description  : State handling in proto                   */
/************************************************************************************/
/* Modified By      : Nagalakshmi                         */
/* Date            : 09-Sep-2010                   */
/* BugID       : PNR2.0_28269                  */
/* Description  : default state defined is not working in proto     */
/************************************************************************************/
/* Modified By      : Chanheetha N A                      */
/* Date            : 15-Sep-2010                    */
/* BugID       : PNR2.0_28319                   */
/* Description  : image upload for htm environment          */
/**********************************************************************************************/
/* Modified By      : Chanheetha N A                      */
/* Date            : 20-Sep-2010                    */
/* BugID       : PNR2.0_28365                   */
/* Description  : during generate preview new control is not visible        */
/**********************************************************************************************/
/* Modified By      : Sangeetha G                       */
/* Date            : 21-Sep-2010                     */
/* BugID       : PNR2.0_28376                    */
/* Description  : generate preview not working - Help UI        */
/**********************************************************************************************/
/* Modified By      : S.Sivakumar        */
/* Date            : 05-OCT-2010               */
/* BugID       : PNR2.0_28537              */
/* Description  : Bulk HTM Generation Failed Due To Null Value     */
/**********************************************************************************************/
/* Modified By      : Chanheetha N A                      */
/* Date            : 11-Oct-2010                    */
/* BugID       : PNR2.0_28642                   */
/* Description  : Section not aligned properly           */
/**********************************************************************************************/
/* Modified By      : Kiruthika R                              */
/* Date            : 21-Oct-2010                    */
/* BugID       : PNR2.0_28767                   */
/* Description  : OK button caption for multi language           */
/**********************************************************************************************/
/* Modified By      : Balaji D                  */
/* Date    : 01-Nov-2010                 */
/* BugID   : PNR2.0_28889                 */
/* Description  : While generating preview the feature'Gridlit required' was not visible.*/
/**********************************************************************************************/
/* Modified By      : Chanheetha N A              */
/* Date    : 09-May-2011               */
/* BugID   : PNR2.0_31178               */
/* Description  : control alignment change.            */
/********************************************************************************************/
/* Modified By      : Kiruthika R               */
/* Date    : 25-May-2011               */
/* BugID   : PNR2.0_31505               */
/* Description  : Check box control alignment change.         */
/********************************************************************************************/
/* modified by  : Balaji D                   */
/* modified on  : June 08 2011               */
/* Bug ID   : PNR2.0_31780                */
/* Case Desc  : Tree Grid Feature Enhancement.          */
/********************************************************************************************/
/* modified by  : Balaji D                   */
/* modified on  : Sep 02 2011               */
/* Bug ID   : PNR2.0_33145                */
/* Case Desc  : Proto is not generated in the UI format "Controls Under Captions"     */
/********************************************************************************************/
/* modified by  : Balaji D                   */
/* modified on  : Sep 12 2011               */
/* Bug ID   : PNR2.0_33305                */
/* Case Desc  : system launches proto but Pages are disappears immediately   */
/********************************************************************************************/
/* modified by  : Sangeetha G               */
/* date         : 16-September-2011             */
/* Bug ID  : PNR2.0_33378                     */
/* Description : To enable user to set pixel width of grid columns     */
/****************************************************************************************/
/* modified by  : Muthupandi S              */
/* date         : 16-September-2011             */
/* Bug ID  : PNR2.0_33389                     */
/* Description : page bt synonym condition added while getting sample data   */
/****************************************************************************************/
/* modified by  : Gankan G               */
/* date         : 26-Sep-2011               */
/* Bug ID  : PNR2.0_33556                     */
/* Description : To fire Default UI task on click of tree       */
/****************************************************************************************/
/* Modified By : Balaji D                 */
/* Date   : 13-Oct-2011               */
/* BugId  : PNR2.0_33805                */
/* Description : Error:There is already an object named '#state_page_dtl' in the database.*/
/****************************************************************************************/
/* modified by : Balaji D                         */
/* modified on : Dec 31 2011                     */
/* Bug ID  : PNR2.0_35383                         */
/* Case Desc : Modelling for Splitter Section.                */
/****************************************************************************************/
/* modified by   : Balaji D                            */
/* date    : 01-Apr-2012                           */
/* BugId   : PNR2.0_36309                           */
/* modified for  : Provision to Label-Link                               */
/****************************************************************************************/
/* modified by   : Balaji D                            */
/* date    : 21-Jun-2012                           */
/* BugId   : PLF2.0_00708                           */
/* modified for  : Adding state content generation sp                           */
/****************************************************************************************/
/* modified by   : Balaji D                            */
/* date    : 01-Apr-2012                           */
/* BugId   : PLF2.0_00961                           */
/* modified for  : PopUpSection,Button Right Align,Page/Button/Link Images.          */
/****************************************************************************************/
/* modified by   : Balaji D                            */
/* date    : 01-Aug-2012                           */
/* BugId   : PLF2.0_01208                           */
/* modified for  : Border Required for OK Section                                      */
/****************************************************************************************/
/* modified by  : Gankan G               */
/* date         : 03-Nov-2012                     */
/* Bug ID  : PLF2.0_03057               */
/* Description : Code Modified to inlucde new ISList Box property     */
/****************************************************************************************/
/* modified by  : Kiruthika R                */
/* date         : 06-Mar-2013                      */
/* Bug ID  : PLF2.0_03710                */
/* Description : Customlist implementation for header edit controls.     */
/****************************************************************************************/
/* modified by  : Gankan G               */
/* date         : 28-May-2013               */
/* Bug ID  : PLF2.0_04721               */
/* Description : Code modified to handle equal tabwidth       */
/****************************************************************************************/
/* modified by  : Shakthi P                                                     	 */
/* date         : 30 May 2014                                                 	     */
/* Bug Id       : PLF2.0_08470                                      	        	 */
/* Description  : Tooltip Not Required.ForceFit,Grid Column Caption Not Required 	 */
/* There is log of changes so,no modification History                            	 */
/*************************************************************************************/
/* modified by  :	Kanagavel														 */
/* date         :	13-Jun-2014												     	 */
/* Bug ID		:	PLF2.0_08772 													 */
/* Description	:	Validation has been added for section type map	*/
/* More changes, so, no modification history										*/
/*************************************************************************************/
/* modified by  : Loganayaki  P                      	 */
/* date         : 09/04/2014                                                 	     */
/* Bug Id       : PLF2.0_09523                                     	        	 */
/* Description  : Section Prefix Class not getting visibled in Preview 	 */
/*************************************************************************************/
/*	Modified by		: Ganesh prabhu S									 	*/
/*	Modified date	: 11-Aug-2014										    */
/*	Problem Code	: PLF2.0_09422											*/
/*	Description		: Vss Updation											*/
/********************************************************************************/
/* modified by  : Veena U   			                                        */
/* date         : Oct 10 2014			                                        */
/* BugId        : PLF2.0_09035													*/
/* description  : Model changes for rowspan,colspan,IsStatic,IsCallout 
				  in  layout level.												*/
/********************************************************************************/
/* Modified by  : Veena U                                                  */
/* Date         : 25-Feb-2015                                                  */
/* Call ID		: PLF2.0_11499                                                 */
/********************************************************************************/
/* Modified by  : Veena U                                                  */
/* Date         : 25-Feb-2015                                                  */
/* Call ID		: PLF2.0_11499                                                 */
/********************************************************************************/
/* Modified by  : Veena U	                                                  */
/* Date         : 07-Aug-2015                                                  */
/* Defect ID	: PLF2.0_14096                                                 */
/********************************************************************************/
/* Created by  	: Veena U                                                */
/* Date         : 13-April-2016                                                  */
/*Defect Id 	: PLF2.0_17570													*/
/********************************************************************************/
/* Created by  	: Kiruthika R                                                */
/* Date         : 26-May-2016                                                  */
/*Defect Id 	: PLF2.0_18487 (Newlineui implementation)						*/
/********************************************************************************/
/* modified by			Date				Defect ID							*/
/* Veena U				08-Jun-2016			PLF2.0_18487						*/
/********************************************************************************/
/* modified by                    Date                       Defect ID            */
/* Veena U                        15-Jun-2016                PLF2.0_18888         */
/**********************************************************************************/
/* modified by                    Date                       Defect ID            */
/* Loganayaki P                   19-oct-2016				 TECH-218         */
/**********************************************************************************/
/* Modified by : Jeya Latha K/Ganesh Prabhu S	for callid TECH-7349									*/
/* Modified on : 14-03-2017				 													*/
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and New Feature Organization chart       													*/
/***********************************************************************************/
/* Modified by  : Jeya Latha K		Date: 16-Aug-2017  Defect ID	:TECH-12776	*/
/* Modified by  : Jeya Latha K		Date: 4-Dec-2017   Defect ID	:TECH-16126	*/
/********************************************************************************/
/* Modified by  : JeyaLatha K		Date: 31-Jan-2018  Defect ID	: TECH-18349 */
/***************************************************************************************/
/* Modified by  : Venkatesan K	Date: 03-mar-2018  Defect ID : TECH-19895             */  
/* Description : Section collapse property disabled for  help screen ok section.      */
/***************************************************************************************/
/* Modified by  : JeyaLatha K		Date: 02-Apr-2018  Defect ID	: TECH-20326	   */
/***************************************************************************************/
/*Modified by	: Jeya Latha K   Defect ID: TECH-20897      On: 30-Apr-2018			   */
/***************************************************************************************/
/* Modified by	: Ganesh Prabhu S   Defect ID: TECH-23600       On: 30-june-2018	   */
/* Modified by	: Jeya Latha K      Defect ID: TECH-27286       On: 22-Oct-2018	       */
/* Modified By  : Jeya Latha K		Date: 08-Jan-2019			Defect ID: TECH-29822  */
/* Modified by  : Jeya Latha K		Date: 28-Jun-2019			Defect ID: TECH-35368 */
/* Modified by  : Jeya Latha K      Date: 30-Aug-2019			Defect ID: TECH-37471 */
/***************************************************************************************/
/* Modified by  : Jeya Latha K      Date: 01-Nov-2019			Defect ID: TECH-39534 */
/***************************************************************************************/
/* Modified by  : Jeya Latha K		 Date: 24-Apr-2020  Defect ID	:TECH-45546		   */
/* Modified by : Venkatesan K  	     Date: 06-May-2020   Defect ID : TECH-45828        */
/*Modified by	: Ganesh Prabhu S   Defect ID: TECH-46330      On: 16-May-2020		   */
/***************************************************************************************/
/* Modified by : Venkatesan K  	     Date: 29-May-2020   Defect ID : TECH-46646        */
/********************************************************************************/
/* Modified by  : Ganesh Prabhu S	Date: 05-Sept-2020  Defect ID : TECH-49262 */  
/***************************************************************************************/
/* modified by  : Muneeswari G															*/
/* Date         : 19-Mar-2021															*/
/* Defect ID	: TECH-56482															*/
/* Description  : Control name is not available against custom list node in preview level*/
/***************************************************************************************/
/* Modified by : Manoj S		     Date: 14-Apr-2021   Defect ID : TECH-56570        */
/* Modified by : Manoj S             Date: 14-Apr-2021   Defect ID : TECH-57347        */
/***************************************************************************************/
/* modified by  : Muneeswari G															*/
/* Date         : 17-June-2021															*/
/* Defect ID	: TECH-58883															*/
/* Description  : In preview level, "horder" is printed wrongly for button control with caption required as "yes" property.*/
/******************************************************************************************/
/* modified by  : Muneeswari G															 */
/* Date         : 09-Sep-2021															 */
/* Defect ID	: TECH-59801															 */
/* Description  : Validation for assorted controls if no columns are defined.			 */
/*****************************************************************************************/
/* modified by  : Manoj S																 */
/* Date         : 17-Dec-2021															 */
/* Defect ID	: TECH-64821															 */
/*****************************************************************************************/
/* modified by  : Muneeswari G															 */
/* Date         : 20-Jan-2022															 */
/* Defect ID	: TECH-65425															 */
/* Description  : Caption of list view is not getting updated in preview.				 */
/********************************************************************************************/
/* TECH-64197   : To identify incoming UI having GraphQL mapping or not.				 */ 
/*****************************************************************************************/
/* modified by  : Manoj S																 */
/* Date         : 02-May-2022															 */
/* Defect ID	: TECH-68512															 */
/*****************************************************************************************/
/* Modified by	:	Jeya Latha K/Ponmalar A												 */
/* Modified on	:	15-Jun-2022				 											 */
/* Defect ID	:	TECH-69624															 */
/* Description	:	Custom border, Custom actions and Responsive layout					 */
/*****************************************************************************************/
/* Modified by	:	Ponmalar A/Jeya Latha K												 */
/* Modified on	:	11-July-22				 											 */
/* Defect ID	:	TECH-70687															 */
/* Description	:	Tool and Toolbars													 */
/*****************************************************************************************/
/* Modified by  :   Ponmalar A															 */
/* Modified on	:	23-Aug-2022				 											 */
/* Defect ID	:	TECH-72114															 */
/* Description	:	Platform Modeling for Section Title Icon.							 */
/*					BadgeText Property for DataHyperLink Controls/Columns.				 */
/*					Top Inner option in UI Level.										 */
/*****************************************************************************************/
/* Modified by : Ponmalar A  	     Date: 01-Dec-2022   Defect ID : TECH-75230			 */
/*****************************************************************************************/
CREATE PROCEDURE ep_generate_uixml
	@ctxt_language_in engg_ctxt_language,
	@ctxt_ouinstance_in engg_ctxt_ouinstance,
	@ctxt_service_in engg_ctxt_service,
	@ctxt_user_in engg_ctxt_user,
	@engg_act_descr_in engg_description,
	@engg_actname_in engg_name,
	@engg_att_ui_cap_align_in engg_name,
	@engg_att_ui_format_in engg_description,
	@engg_att_ui_trail_bar_in engg_name,
	@engg_component_descr_in engg_description,
	@engg_customer_name_in engg_name,
	@engg_language_name_in engg_name,
	@engg_project_name_in engg_name,
	@engg_req_no_in engg_name,
	@engg_smartspan_in engg_flag,
	@engg_stylesheet_in engg_description,
	@engg_virdir_in engg_path,
	@guid_in engg_guid,
	@engg_ui_descr_in engg_description,
	@sample_data_from engg_name = 'Layout',
	@html_gen_path engg_description,
	@m_errorid engg_rowno OUTPUT
AS
BEGIN
	SET NOCOUNT ON

	--declaration of temporary variables
	DECLARE @ctxt_language engg_ctxt_language
	DECLARE @ctxt_ouinstance engg_ctxt_ouinstance
	DECLARE @ctxt_service engg_ctxt_service
	DECLARE @ctxt_user engg_ctxt_user
	DECLARE @engg_act_descr engg_description
	DECLARE @engg_actname engg_name
	DECLARE @engg_att_ui_cap_align engg_name
	DECLARE @engg_att_ui_format engg_description
	DECLARE @engg_att_ui_trail_bar engg_name
	DECLARE @engg_customer_name engg_name
	DECLARE @engg_language_name engg_name
	DECLARE @engg_project_name engg_name
	DECLARE @engg_req_no engg_name
	DECLARE @engg_smartspan engg_flag
	DECLARE @engg_stylesheet engg_description
	DECLARE @engg_virdir engg_path
	DECLARE @engg_ui_descr engg_description
	DECLARE @guid engg_guid
	declare @linkSection    	engg_flag
	declare @buttonSection    engg_flag
	declare @GanttSection    engg_flag
	declare @SectionRenderAs    engg_description	--Clde Added for Defect ID : TECH-39534
	DECLARE @StatusMessage engg_documentation
	DECLARE @ConfirmationMessage engg_documentation
	DECLARE @CVS engg_flag
	DECLARE @ExcelReport engg_flag
	DECLARE @pref_pagename engg_name
	DECLARE @Tree engg_flag
	DECLARE @Chart engg_flag
	DECLARE @FullTree engg_flag
	DECLARE @ManualReport engg_name
	DECLARE @freezecount engg_seqno --added for PNR2.0_26860
	DECLARE @task_name engg_name --code added by kiruthika for bugid :PNR2.0_27888 on 24-8-2010
	DECLARE @colspan engg_seqno -- code modified for the caseid : PNR2.0_28642
	DECLARE @ok_caption engg_description_lng -- code modified by kiruthika for bugid :PNR2.0_28767 on 21-oct-2010
	-- Modification for PNR2.0_17733 by Gowrisankar on 4-Apr-2008 starts; engg_description is replaced by engg_description_lng
	DECLARE @activity_name engg_name,
		@engg_component_descr engg_description_lng, --engg_description,
		@engg_component engg_name,
		@ui_sysid_tmp engg_sysid,
		@ui_name_tmp engg_name,
		@engg_ui_descr_tmp engg_description_lng, --engg_description,
		@ui_type_tmp engg_name,
		@ui_format_tmp engg_name,
		@caption_alignment_tmp engg_name,
		@trail_bar_tmp engg_name,
		@tab_height_tmp engg_rowno,
		@page_bt_synonym_tmp engg_name,
		@page_descr_tmp engg_description_lng, --engg_description,
		@mainpage_tmp engg_name,
		@oksectionname_tmp engg_name,
		@horder_tmp engg_rowno,
		@vorder_tmp engg_rowno,
		@section_bt_synonym_tmp engg_name,
		@section_descr_tmp engg_description_lng, --engg_description,
		@visible_flag_tmp engg_flag,
		@title_required_tmp engg_flag,
		@border_required_tmp engg_flag,
		@parent_section_tmp engg_name,
		@control_bt_synonym_tmp engg_name,
		@ctrl_descr_tmp engg_description_lng, --engg_description,
		@control_type_tmp engg_name,
		@base_ctrl_type_tmp engg_name,
		@proto_tooltip_tmp engg_description_lng, --engg_description,
		-- Code modified for PNR2.0_21234 on 25-Feb-2008 - starts
		@sample_data_tmp engg_documentation_lng, --engg_documentation
		-- Code modified for PNR2.0_21234 on 25-Feb-2008 - Ends
		@hiddensectrow_tmp engg_rowno,
		@oksectionrow_tmp engg_rowno,
		@visible_length_tmp engg_rowno,
		@mandatory_flag_tmp engg_flag,
		@editable_flag_tmp engg_flag,
		@caption_req_tmp engg_flag,
		@select_flag_tmp engg_flag,
		@zoom_req_tmp engg_flag,
		@help_req_tmp engg_flag,
		@ellipses_req_tmp engg_flag,
		@visible_rows_tmp engg_rowno,
		@data_column_width_tmp engg_seqno,
		@controldoc_tmp engg_documentation,
		@label_column_width_tmp engg_seqno,
		@column_bt_synonym_tmp engg_name,
		@col_descr_tmp engg_description_lng, --engg_description,
		@column_type_tmp engg_name,
		@column_no_tmp engg_rowno,
		@button_code_tmp engg_name,
		@seq_no_tmp engg_rowno,
		@button_caption_tmp engg_description_lng, --engg_description,
		@targetdir_tmp engg_description,
		@xmlpath_tmp engg_description,
		@default_flag_tmp engg_flag,
		@previous_section_tmp engg_name,
		@previous_horder_tmp engg_rowno,
		@previous_vorder_tmp engg_rowno,
		@position_vindex_tmp engg_rowno,
		@position_sindex_tmp engg_rowno,
		@position_hindex_tmp engg_rowno,
		@transformed_horder_tmp engg_rowno,
		@transformed_vorder_tmp engg_rowno,
		@transformed_seqno_tmp engg_rowno,
		@datatype_tmp engg_name,
		@datalength_tmp engg_rowno,
		@uitaskname_tmp engg_name,
		@controlid_tmp engg_name,
		--   @engg_process_name_tmp  engg_name,
		@process_name engg_name,
		@process_descr engg_description_lng, --engg_description,
		@link_name_tmp engg_name,
		@link_page_tmp engg_name,
		@link_section_tmp engg_name,
		@link_type_tmp engg_name,
		@linked_component_tmp engg_name,
		@linked_activity_tmp engg_name,
		@linked_ui_tmp engg_name,
		@LinkLaunchType engg_name,
		--   @engg_base_req_no   engg_name,
		--   @xml_seq_out    engg_rowno,
		@xml_seq_tmp engg_rowno,
		@cntincr_tmp engg_rowno,
		@prjsecrow engg_rowno,
		@caption_wrap_tmp engg_flag,
		@caption_position_tmp engg_name,
		@sectitle_align_tmp engg_name,
		@val engg_description_lng, --engg_description,
		@order_seq_tmp engg_rowno,
		@associated_task engg_name,
		@default_for_tmp engg_name,
		@ui_descr_tmp engg_description_lng, --engg_description,
		@task_name_tmp engg_name,
		@task_type_tmp engg_name,
		@task_descr_tmp engg_description_lng, --engg_description,
		-- Code modified for PNR2.0_21234 on 25-Feb-2008 - starts
		@default_sample_data_tmp engg_description_lng, --engg_description
		-- Code modified for PNR2.0_21234 on 25-Feb-2008 - Ends
		@task_seq_tmp engg_seqno,
		@task_pattern_tmp engg_name,
		@viewname_tmp engg_name,
		@primary_control_bts_tmp engg_name,
		@ctrl_position_tmp engg_name,
		@label_class_tmp engg_name,
		@ctrl_class_tmp engg_name,
		@delete_flag_tmp engg_flag,
		@entry_ui_tmp engg_name,
		@engg_function engg_name,
		@pubflag engg_flag,
		@activity_type engg_type,
		@password_char_tmp engg_flag,
		@task_img_tmp engg_name,
		@help_img_tmp engg_name,
		@radhorder_tmp engg_rowno,
		@radvorder_tmp engg_rowno,
		@task_descr_link_tmp engg_description_lng, --engg_description,
		@engg_act_descr_temp engg_description_lng, --engg_description,
		@decimal_length_ctrl engg_length,
		@decimal_length_grid engg_length,
		@language_code engg_name,
		@data_column_scalemode engg_prefix,
		@label_column_scalemode engg_prefix,
		@tab_seq_tmp engg_rowno,
		@xml_tree_seq engg_rowno,
		@tab_seq engg_name,
		@tab_sec_horder engg_rowno,
		@tab_sec_vorder engg_rowno,
		@set_first_tab NUMERIC(8, 0),
		@set_first_tab_grid NUMERIC(8, 0),
		@rtuitype engg_name,
		@engg_act_descr_lng engg_description_lng, --engg_description,
		@section_type_tmp engg_name,
		@html_text_area engg_flag,
		@spin_required engg_flag,
		@spin_up_image engg_description,
		@spin_down_image engg_description,
		@helptext engg_description,
		@vis_page engg_name,
		@vis_ctrl engg_name,
		@vis_col engg_name, /* PNR2.0_11203 */
		@vis_leng engg_seqno,
		@Sum_vis_leng engg_seqno,
		@filler_seq_no engg_length,
		@page_prefix engg_prefix,
		--Code Modified For BugId : PNR2.0_7273
		@section_height_tmp engg_seqno,
		@section_width_tmp engg_seqno,
		@section_heightscalemode_tmp engg_name,
		@section_widthscalemode_tmp engg_name,
		@associated_spin_task engg_name,
		@associated_spin_ctrl engg_name,
		--Code Modified For BugId : PNR2.0_7461
		@offlinepackage engg_seqno,
		@section_level engg_seqno,
		@value_tmp engg_description_lng, --engg_description,
		--code modified for bugId : PNR2.0_10741
		@report_reqd engg_flag,
		--Code Modified for bugid : PNR2.0_11183
		@modelsectioname_tmp engg_name,
		--code modified for bugId :  PNR2.0_11597
		@ocx_Name engg_name,
		@progid engg_name,
		@StateEnabled engg_name,
		@FillerClass engg_name, --Code Added For Bug_id PNR2.0_17856
		@PageClass engg_name,
		@SectionPrefixClass engg_name, --Code Added For BugId PNR2.0_18564
		-- Inplace Calendar and Edit Mask Feature added by Feroz -- Start
		@InPlaceCalendar engg_flag,
		@InPlaceCal_Display engg_flag,
		@EditMaskPattern engg_name,
		-- Inplace Calendar and Edit Mask Feature added by Feroz -- End
		@AccessKey engg_name,
		@auto_tab_stop engg_flag, -- code added by Gopinath S for the Bug ID PNR2.0_19995
		-- Parameter addition for  PNR2.0_20049  starts
		@data_type engg_name,
		@data_type_ctrl engg_name,
		@data_type_grid engg_name,
		-- Parameter addition for  PNR2.0_20049  ends
		-- Parameters addition for PNR2.0_20849 starts
		@lang_settings engg_documentation,
		@NoofLinesPerRow engg_flag,
		@RowHeight engg_flag,
		@Vscrollbar_Req engg_flag,
		@ServerName engg_name,
		@DatabaseName engg_name,
		-- Parameters addition for PNR2.0_20849 ends
		-- Code added by Feroz for extjs -- start -- PNR2.0_1790
		@extjs_values engg_documentation,
		@extjs_ctrl_type engg_name,
		@section_type engg_name,
		@extjs_base_ctrl engg_name,
		@type_prefix engg_type,
		@callout_task_tmp engg_flag,
		@pivot_prop_tmp engg_documentation,
		@callout_type engg_type,
		@page_type engg_type,
		-- Code added by Feroz for extjs -- End -- PNR2.0_1790
		-- Parameters addition for PNR2.0_21576 starts
		@gridlite engg_flag,
		-- Parameters addition for PNR2.0_21576 ends
		-- added By feroz
		@bulletlink_req engg_flag,
		@buttoncombo_req engg_flag,
		@dataascaption engg_flag,
		@associatedlist_req engg_flag,
		@onfocustask_req engg_flag,
		@listrefilltask_req engg_flag,
		@listedit_NoofColumns engg_seqno,
		@attach_document engg_flag,
		@image_upload engg_flag,
		@inplace_image engg_flag,
		@image_icon engg_flag,
		@image_row_height engg_seqno,
		@relative_url_path engg_description,
		@relative_document_path engg_description,
		@relative_image_path engg_description,
		@save_doc_content_to_db engg_flag,
		@save_image_content_to_db engg_flag,
		@onfocus_taskname engg_name,
		@associatedlist_name engg_name,
		@listrefill_taskname engg_name,
		@primary_search_column engg_name,
		@list_index_search engg_seqno,
		@hidden_view_name engg_name,
		@mapped_list_controlid engg_name,
		@mapped_list_viewname engg_name,
		@date_highlight_req engg_flag,
		@mapped_sec_controlid engg_name,
		@mapped_sec_viewname engg_name,
		@control_id_tmp engg_name,
		-- Added by Feroz For UI Toolbar start
		@group_task_name engg_name,
		@tb_display_seqno engg_seqno,
		@tb_class_name engg_name,
		@tb_display_text engg_description,
		@tb_caption_req engg_flag,
		@tb_control_req engg_flag,
		@tbg_group_task_name engg_name,
		@tbg_task_seqno engg_seqno,
		@tbg_class_name engg_name,
		@tbg_display_text engg_description,
		@tbg_control_req engg_flag,
		@toolbar_id engg_name,
		@tb_type engg_type,
		@tbg_type engg_type,
		@group_task_desc engg_description,
		@task_seqno_tmp engg_seqno,
		@group_name engg_name,
		@tbg_controlid engg_name,
		@tb_controlid engg_name,
		@tbg_viewname engg_name,
		@tb_viewname engg_name,
		-- Added by Feroz For UI Toolbar End
		-- Code Added for the Bug ID : PNR2.0_27796 starts
		@Lite_Attach engg_flag,
		@BrowseButton engg_flag,
		@DeleteButton engg_flag,
		@ProtoLaunchMode engg_flag,
		@renderas engg_name,
		@itk_req engg_flag,
		@rowexpander engg_flag,
		@gridtoform engg_flag,
		@icon_position engg_name,
		@IsGql		engg_flag,	@IsFilter	engg_flag,	@forresponsive	engg_name, 	@Sidebar	engg_flag,		--TECH-70687
		@TitleIcon	engg_name,	@BadgeText	engg_flag,	@labelname	engg_name,	@AutoHeight	engg_flag --TECH-72114

	-- Code Added for the Bug ID : PNR2.0_27796 ends
	--code added for the caseid : PNR2.0_28319 starts
	DECLARE @image_row_width engg_seqno
	DECLARE @image_preview_height engg_seqno
	DECLARE @image_preview_width engg_seqno
	DECLARE @image_preview_req engg_flag
	DECLARE @Accept_Type engg_name
	DECLARE @Lite_Attach_Image engg_flag
	--code added for the caseid : PNR2.0_28319 ends
	DECLARE @enablefiller engg_flag --code added for the caseid : PNR2.0_31178
	DECLARE @gridcollength engg_name /*Modification made by Sangeetha G for Bug id : PNR2.0_33378*/
	DECLARE @Section_Position engg_type --PNR2.0_35383
	DECLARE @LabelLink engg_flag --Code Added for the Bug ID PNR2.0_36309
		--Code added for Bug ID:PLF2.0_00961 starts
	DECLARE @page_image engg_name
	DECLARE @popup_page engg_name
	DECLARE @popup_section engg_name
	DECLARE @popup_close engg_flag
	DECLARE @captiontype engg_name
	DECLARE @controlstyle engg_name
	DECLARE @controlimage engg_name
	DECLARE @Image engg_name
	--Code added for Bug ID:PLF2.0_00961 ends
	DECLARE @IsListBox engg_name --PLF2.0_03057
	DECLARE @width_page engg_seqno --PLF2.0_04721
	DECLARE @Toolbar_Not_Req engg_name --shakthi
	DECLARE @ColumnBorder_Not_Req engg_name
	DECLARE @RowBorder_Not_Req engg_name
	DECLARE @PagenavigationOnly engg_name
	DECLARE @custom_styles engg_flag
	DECLARE @RowNo_Not_Req engg_name
	DECLARE @ButtonHome_Req engg_name
	DECLARE @ButtonPrevious_Req engg_name
	DECLARE @ExtType engg_name
	DECLARE @ColumnClass engg_name
	DECLARE @ColumnStyle engg_name
	DECLARE @NRowSpan engg_seqno
	DECLARE @NColSpan engg_seqno
	DECLARE @ControlColSpan engg_seqno
	DECLARE @ControlRowSpan engg_seqno
	DECLARE @ToolTip_Not_Req engg_name
	DECLARE @Forcefit engg_name
	DECLARE @columncaption_Not_Req engg_name
	DECLARE @Border_Not_Req engg_name
	DECLARE @IsModal engg_name
	DECLARE @Alternate_Color_Req engg_name
	DECLARE @Map_In_Req engg_name
	DECLARE @Map_Out_Req engg_name
	DECLARE @filesize engg_name
	----
	DECLARE @combo_control_bt_synonym_tmp engg_name,
		@link_control_bt_synonym_tmp engg_name,
		@link_control_caption_tmp engg_name,
		@display_seqno_tmp engg_seqno,
		@separatelink_req_tmp engg_name,
		@map_tmp engg_name,
		@associated_task_name_tmp engg_name,
		@combo_default engg_name,
		@control_task_type_tmp engg_name,
		---@isstatic engg_flag,
		@iscallout engg_flag,
		@section_collapse_mode engg_name,
		@section_collapseable engg_name,
		@section_prefix_class engg_name,
		-- @columnhdrclass engg_name,
		@SourceCtrl engg_name,
		@TargetCtrl engg_name,
		@controltype engg_name,
		@isbrowse engg_name,
		@qrflag engg_name,
		@barcodeflag engg_name,
		@width engg_seqno,
		@height engg_seqno,
		@Toolbar_notreq engg_seqno,
		@browse_control engg_name,
		@path_control engg_name,
		@btype engg_name,
		@tabposition engg_name,
		@postlaunchtask engg_name,
		@carousalnavigation engg_name,
		@iSDeviceInfo engg_flag,
		@Datagrid engg_flag,
		@Email engg_flag,
		@TemplateID engg_name,
		@Phone engg_flag,
		@StaticCaption engg_flag,
		@Orientation engg_name,
		@MoveFirst engg_flag,
		@Move_PrevSet engg_flag,
		@Move_Next engg_flag,
		@Move_NextSet engg_flag,
		@Move_Last engg_flag,
		@Carousel_Req engg_flag,
		@Wrapcount engg_seqno,
		@Box_Type engg_seqno,
		@CarouselNavigation engg_flag,
		@Move_Previous engg_flag,
		@colname engg_name, -- code modified by TECH-47452 for the defect id TECH-47452
		@listcontrol engg_flag,
		@col_caption_align engg_name,
		@ctrl_col_caption_align engg_name,
		@dg_section_bt_synonym engg_name,
		@RowIndicator engg_name,
		@Gridtoolbarstyle engg_name,
		@Gridheaderstyle engg_name,
		@preevent engg_flag,
		@postevent engg_flag,
		@SmartHide engg_flag,
		@New_Line_Ui engg_flag,
		@Isdevice engg_flag,
		@SectionIndicator engg_name,
		@IlboTitleReq engg_flag,
		@Exclude_Systemtabindex engg_flag,
		@TabType engg_name,
		@col_data_align engg_name,
		@ishijri engg_flag,
		@personalization engg_flag,
		@DeviceType engg_name,
		@TabStyle engg_name,
		@HeaderPosition engg_name,
		@TabRotation engg_name,
		@TabTitleStyle engg_name,
		@TabIconPosition engg_name,
		@PageLayout engg_name,
		@XYCoordinates engg_description,
		@ColumnLayWidth engg_description,
		@Region engg_name,
		@TitlePosition engg_name,
		@CollapseDir engg_name,
		@SectionLayout engg_name,
		@IsDesktop engg_flag,
		@IsPhone engg_flag,
		@IsTablet engg_flag,
		@Hide_Print engg_flag,
		@treeGrdNew engg_documentation,
		@hdrpersonalization engg_flag,
		@hidedefaults engg_flag,
		@UiLayout engg_name,
		@TemplateCat engg_name,
		@TemplateSpecific engg_documentation,
		@ExpandImageEvent engg_flag,
		@avn_download engg_flag,
		@systemspin engg_flag,
		@cell_spacing engg_seqno,
		@cell_padding engg_seqno,
		@isPivot engg_flag,
		@sectionlaunchtype engg_name,
		@smartviewsection engg_flag,
		@preserveposition engg_flag, -- code added for Defect ID	: TECH-18349
		@scan engg_flag,
		@autoselect engg_flag,
		@grporientation engg_doc_type
	DECLARE @alignbtn engg_flag

	SELECT @alignbtn = ''

	DECLARE @algnbtn_h_tmp engg_seqno,
		@algnbtn_v_tmp engg_seqno,
		@horder_1 engg_seqno,
		@vorder_1 engg_seqno,
		@enum_code_tmp engg_name,
		@enum_caption_tmp engg_description_lng,
		@ProcessingMessage engg_documentation,
		@associated_control engg_name,
		@ErrorLookup engg_flag,
		@FollowupTask engg_flag,
		@AssociatedML engg_documentation
	DECLARE @Associatedcontrol engg_name
	DECLARE @uicolspan engg_seqno,
		@nonuicolspan engg_seqno,
		--,@IsRatingControl	engg_flag,
		@RatingType engg_name,
		--@IsCaptcha			engg_flag,
		@CaptchaData engg_name,
		@Control_class_ext6 engg_name,
		@Icon_Class engg_name,
		@Control_cls_ext6 engg_name,
		@Popup_onclick_close engg_Flag
	DECLARE @depst_page engg_name,
		@depst_sec engg_name,
		@depst_page_tmp engg_name,
		@dep_state engg_flag ,--Added for PNR2.0_34596 
		@tmp_node	engg_name,
		@section_prefix		engg_name,		@DynamicStyleControlName engg_name, @setfocusevent	engg_name,			@leavefocusevent	engg_name,			
		@setfocuseventoccur	engg_flag,		@leavefocuseventoccur engg_flag,	@SpellCheckRequired	engg_flag,		@UPEEnabled			engg_flag,	
		@MoreEventName		engg_name,		@PaginationRequired	  engg_flag,	@IsMobile	engg_flag,				@UpdateTaskReqd		engg_flag,
		@DeleteTaskReqd		engg_flag,		@RowAlwaysExpanded	  engg_flag,	@Classprops engg_description,		@ImageType			engg_name,
		@itk_enum_cnt		engg_seqno,		@uisubtype			  engg_name,	@AssociatedUpdateTask	engg_name,	@AssociatedDeleteTask	engg_name,
		@DynamicFileUpload	engg_flag,		@DirectPrint		  engg_flag,	@titlebar_Search	engg_flag,		@SystemTask			engg_name,
		@SystemTaskType		engg_name,		@QuickTask			  engg_name,	@OfflineTask		engg_name

	--temporary and formal parameters mapping
	SELECT @ctxt_language = @ctxt_language_in

	SELECT @ctxt_ouinstance = @ctxt_ouinstance_in

	SELECT @ctxt_service = ltrim(rtrim(@ctxt_service_in))

	SELECT @ctxt_user = ltrim(rtrim(@ctxt_user_in))

	SELECT @engg_act_descr = ltrim(rtrim(@engg_act_descr_in))

	SELECT @engg_actname = ltrim(rtrim(@engg_actname_in))

	SELECT @engg_att_ui_cap_align = ltrim(rtrim(@engg_att_ui_cap_align_in))

	SELECT @engg_att_ui_format = ltrim(rtrim(@engg_att_ui_format_in))

	SELECT @engg_att_ui_trail_bar = ltrim(rtrim(@engg_att_ui_trail_bar_in))

	SELECT @engg_component_descr = ltrim(rtrim(@engg_component_descr_in))

	SELECT @engg_customer_name = ltrim(rtrim(@engg_customer_name_in))

	SELECT @engg_language_name = ltrim(rtrim(@engg_language_name_in))

	SELECT @engg_project_name = ltrim(rtrim(@engg_project_name_in))

	SELECT @engg_req_no = ltrim(rtrim(@engg_req_no_in))

	SELECT @engg_smartspan = ltrim(rtrim(@engg_smartspan_in))

	SELECT @engg_stylesheet = ltrim(rtrim(@engg_stylesheet_in))

	SELECT @engg_virdir = ltrim(rtrim(@engg_virdir_in))

	SELECT @guid = ltrim(rtrim(@guid_in))

	SELECT @engg_ui_descr = ltrim(rtrim(@engg_ui_descr_in))

	SELECT @entry_ui_tmp = ''

	SELECT @default_sample_data_tmp = ''

	SELECT @pubflag = 'C'

	SELECT @previous_horder_tmp = 0

	SELECT @previous_vorder_tmp = 0

	SELECT @tab_seq_tmp = 0

	--Code Modified For BugId : PNR2.0_7461
	SELECT @offlinepackage = 0

set @itk_enum_cnt = 0

	IF @ctxt_service_in = 'offlinepackage'
	BEGIN
		SELECT @offlinepackage = 1

		SELECT @ctxt_service_in = 'BulkGenerate'
	END

	--Code addition  for PNR2.0_20849 starts
	SELECT @ServerName = @@servername

	SELECT @DatabaseName = db_name()

	SELECT @ServerName = ltrim(rtrim(@ServerName))

	SELECT @DatabaseName = ltrim(rtrim(@DatabaseName))

	--Code addition  for PNR2.0_20849 ends
	IF @engg_req_no_in = '[Latest]'
		SELECT @engg_req_no = 'Base'
--Code addition  for PNR2.0_21576 starts
select @gridlite      = ltrim(rtrim(@gridlite))
--Code addition  for PNR2.0_21576 ends
	-- Check nulls for input parameters
	IF @engg_project_name IS NULL
	BEGIN
		SELECT @m_errorid = 1

		RAISERROR (
				'Invalid Project Name',
				16,
				4
				)

		RETURN
	END

	IF @engg_customer_name IS NULL
	BEGIN
		SELECT @m_errorid = 2

		RAISERROR (
				'Invalid Customer Name',
				16,
				4
				)

		RETURN
	END

	IF @engg_component_descr IS NULL
	BEGIN
		SELECT @m_errorid = 3

		RAISERROR (
				'Invalid Component Name',
				16,
				4
				)

		RETURN
	END

	-- Check component, project, customer existence
	IF NOT EXISTS (
			SELECT 'x'
			FROM ep_ui_req_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_req_no
				AND component_descr = @engg_component_descr
			)
	BEGIN
		SELECT @m_errorid = 4

		RAISERROR (
				'Component not found.',
				16,
				4
				)

		RETURN
	END

		

	-- code commented by Ganesh for PNR2.0_4658 on 16th Nov 2005
	--  if @engg_req_no_in = '[Latest]' and @ctxt_service_in = 'BulkGenerate'
	--  begin
	--   select @pubflag   = 'C',
	--    @engg_req_no  = 'Base'
	--  end
	IF @ctxt_service_in IN (
			'ep_prevw_sr_genui',
			'BulkGenerate'
			)
	BEGIN
		IF @engg_req_no_in = '[Latest]' --PNR2.0_2162   26/APR/2005
		BEGIN
			SELECT @process_name = process_name,
				@process_descr = process_descr,
				@engg_component = ltrim(rtrim(component_name)),
				@activity_name = activity_name,
				@pubflag = req_status
			FROM ep_ui_req_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND component_descr = @engg_component_descr
				AND activity_descr = @engg_act_descr
		END
		ELSE
		BEGIN
			SELECT @process_name = process_name,
				@process_descr = process_descr,
				@engg_component = ltrim(rtrim(component_name)),
				@activity_name = activity_name,
				@pubflag = req_status
			FROM ep_ui_req_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND component_descr = @engg_component_descr
				AND activity_descr = @engg_act_descr
				-- code added by Ganesh for the bugid :: PNR2.0_2045 on 21/4/2005
				AND req_no = @engg_req_no

			IF @process_name IS NULL
				OR @process_descr IS NULL
				OR @engg_component IS NULL
				OR @activity_name IS NULL
			BEGIN
				SELECT @process_name = process_name,
					@process_descr = process_descr,
					@engg_component = ltrim(rtrim(component_name)),
					@activity_name = activity_name,
					@pubflag = req_status
				FROM ep_ui_req_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND component_descr = @engg_component_descr
					AND activity_descr = @engg_act_descr
			END
		END

		IF @engg_req_no_in = '[Latest]'
			AND @ctxt_service_in = 'BulkGenerate'
		BEGIN
			SELECT @pubflag = 'C',
				@engg_req_no = 'Base'
		END

		
		--code Modified For BugId : PNR2.0_4719
		IF @ctxt_service_in IN ('BulkGenerate')
			AND @pubflag = 'P'
		BEGIN
			SELECT @ui_name_tmp = ui_name,@New_Line_Ui=ISNULL(New_Line_Ui,'N'),
			@TabType=ISNULL(Tab_Type,'N'),
			@SmartHide=ISNULL(SmartHide,'N'),@Isdevice=ISNULL(Is_device,'N'),
			@Ilbotitlereq=ISNULL(HideIlbotitlemenu_req,''),
			@Exclude_Systemtabindex = isnull(Exclude_Systemtabindex,'N'),
			@devicetype		= isnull(DeviceType,''),
			@TabStyle	= isnull(TabStyle,''),
			@IsDesktop	= isnull(IsDesktop,''),
			@Hide_Print= isnull(Hide_Print,'N'),
			@UiLayout	= ISNULL(Layout,''),
			@XYCoordinates	= ISNULL(XYCoordinates,''),
			@ColumnLayWidth	= ISNULL(ColumnLayWidth,''),
			@hdrpersonalization = ISNULL(personalization,''),
			@hidedefaults = ISNULL(hide_imp_defaults,''),
			@uisubtype		= isnull(ui_subtype,''),
			@titlebar_Search = isnull(titlebar_Search, ''),
			@Sidebar		= ISNULL(Sidebar,'N')  --TECH-70687
			FROM ep_published_ui_mst(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_req_no
				AND component_name = @engg_component
				AND activity_name = @activity_name
				--code Modified For bugId : PNR2.0_4780
				AND ui_descr = isnull(@engg_ui_descr, ui_descr)
		END
		ELSE
		BEGIN
			SELECT @ui_name_tmp = ui_name
			FROM ep_ui_mst(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND component_name = @engg_component
				AND activity_name = @activity_name
				--code Modified For bugId : PNR2.0_4780
				AND ui_descr = isnull(@engg_ui_descr, ui_descr)
		END

		SELECT @engg_stylesheet = @engg_stylesheet_in
	END
	ELSE IF @ctxt_service_in IN (
			'ep_layout_sr_prvw',
			'pmdeuimnsrgenpvw',
			'PMmnguiSrgenpvw',
			'PMmvscctSrgenpvw',
			'ep_ext_mnsrgenprw',
			'ep_lstedtsrgenprw',
			'ep_ui_tbrsrgenprw'
			) -- added by feroz for request id: PNR2.0_1790
	BEGIN
		SELECT @process_name = process_name,
			@process_descr = process_descr,
			@engg_component = ltrim(rtrim(component_name)),
			@activity_name = activity_name,
			@ui_name_tmp = ui_name
		FROM ep_ui_req_dtl(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND component_descr = @engg_component_descr
			AND activity_descr = @engg_act_descr
			AND ui_descr = @engg_ui_descr

		-- For Style Sheet
		SELECT @val = ''

		SELECT @val = current_value
		FROM es_comp_param_mst_vw(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND component_name = @engg_component
			AND param_type = 'CONFIG'
			AND param_category = 'StyleSheet'

		IF @val IS NULL
			OR @val = ''
			SELECT @engg_stylesheet = min(stylesheet_name)
			FROM es_comp_stylesheet_vw(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_req_no
				AND component_name = @engg_component
		ELSE
			SELECT @engg_stylesheet = @val

		-- For Smart Span
		SELECT @val = ''

		SELECT @ProtoLaunchMode = ''

		SELECT @ProtoLaunchMode = upper(current_value)
		FROM es_comp_param_mst_vw(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND req_no = 'Base'
			AND process_name = @process_name
			AND component_name = @engg_component
			AND param_type = 'CONFIG'
			AND param_category = 'PROTOGLAUNCHMODE'

		SELECT @val = current_value
		FROM es_comp_param_mst_vw(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND req_no = 'Base' -- Bug ID: PNR2.0_31178
			AND process_name = @process_name
			AND component_name = @engg_component
			AND param_type = 'UIFORMAT'
			AND param_category = 'Smartspan'

		IF @val IS NULL
			OR @val = ''
			SELECT @engg_smartspan = 'Yes'
		ELSE
			SELECT @engg_smartspan = @val

		-- Code added for the Bug ID: PNR2.0_31178 starts
		--To enable Filler
		SELECT @val = ''

		SELECT @val = current_value
		FROM es_comp_param_mst_vw(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND req_no = 'Base'
			AND process_name = @process_name
			AND component_name = @engg_component
			AND param_type = 'UIFORMAT'
			AND param_category = 'ENABLEFILLER'

		IF @val IS NULL
			OR @val = ''
			SELECT @enablefiller = 'No'
		ELSE
			SELECT @enablefiller = @val

		-- Code added for the Bug ID: PNR2.0_31178 ends
		-- getting caption format
		SELECT @val = ''

		SELECT @val = current_value
		FROM es_comp_param_mst_vw(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND req_no = @engg_req_no
			AND process_name = @process_name
			AND component_name = @engg_component
			AND param_type = 'UIFORMAT'
			AND param_category = 'CAPTIONFORMAT'

		-- getting caption alignment
		IF @val IS NULL
			OR @val = ''
			SELECT @engg_att_ui_format = min(quick_code_value)
			FROM ep_quick_code_mst(NOLOCK)
			WHERE quick_code_Type = 'UI_CAP_FMT_DEF'
				AND quick_code_value <> 'Default'
		ELSE
			SELECT @engg_att_ui_format = @val
	END

	--- for smart hide
	SELECT @ui_name_tmp = ui_name,
		@New_Line_Ui = ISNULL(New_Line_Ui, 'N'),
		@TabType = ISNULL(Tab_Type, 'N'),
		@SmartHide = ISNULL(SmartHide, 'N'),
		@Isdevice = ISNULL(Is_device, 'N'),
		@Ilbotitlereq = ISNULL(HideIlbotitlemenu_req, '') --,@Exclude_Systemtabindex = isnull(Exclude_Systemtabindex,'N') 
		,
		@Exclude_Systemtabindex = isnull(Exclude_Systemtabindex, 'N'),
		@devicetype = isnull(DeviceType, ''),
		@TabStyle = isnull(TabStyle, ''),
		@IsDesktop = isnull(IsDesktop, ''),
		@Hide_Print = isnull(Hide_Print, 'N'),
		@hdrpersonalization = ISNULL(personalization, ''),
		@hidedefaults = ISNULL(hide_imp_defaults, ''),
		@UiLayout = ISNULL(Layout, ''),
		@XYCoordinates = ISNULL(XYCoordinates, ''),
		@ColumnLayWidth = ISNULL(ColumnLayWidth, '')
	FROM ep_ui_mst(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		--and  ecrno   = @engg_req_no
		AND component_name = @engg_component
		AND activity_name = @activity_name
		--Code Modified For BugId : PNR2.0_4780
		AND ui_descr = isnull(@engg_ui_descr, ui_descr)

	--  and  ui_type  in ('Search','Main')
	/*Modification made by Sangeetha G for Bug id : PNR2.0_33378 Starts*/
	SELECT @gridcollength = ltrim(rtrim(current_value))
	FROM es_project_param_mst(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND param_category = 'gridcollength'
		AND param_text = 'Grid Column VisibleLength'
		AND param_type = 'UIFORMAT'

	IF isnull(@gridcollength, 0) IN (
			0,
			''
			)
		SELECT @gridcollength = '12'

	/*Modification made by Sangeetha G for Bug id : PNR2.0_33378 Ends*/
	SELECT @set_first_tab = NULL,
		@set_first_tab_grid = NULL

	-- code modified by shafina on 21-Apr-2004 for PREVIEWENG203SYS_000041
	-- validation for 0,0 order in Sections
	IF @ctxt_service_in IN (
			'EP_Prevw_Sr_GenUI',
			'EP_Prevw_Sr_View'
			)
		AND @pubflag = 'P' -- code modified by Ganesh for PNR2.0_4658 on 16th Nov 2005
	BEGIN
		-- code modified by shafina on 22-Nov-2004 for PREVIEWPF204SYS_000038 (Creating a new pages and not putting controls in any one of the page, then generate the preview. It is not throughing error but it generating with "Page cannot be displayed".)
		IF EXISTS (
				SELECT 'x'
				FROM ep_published_ui_page_dtl pg(NOLOCK)
				WHERE pg.customer_name = @engg_customer_name
					AND pg.project_name = @engg_project_name
					AND pg.req_no = @engg_req_no
					AND pg.process_name = @process_name
					AND pg.component_name = @engg_component
					AND pg.activity_name = @activity_name
					AND NOT EXISTS (
						SELECT 'x'
						FROM ep_published_ui_section_dtl sec(NOLOCK)
						WHERE pg.customer_name = sec.customer_name
							AND pg.project_name = sec.project_name
							AND pg.req_no = sec.req_no
							AND pg.process_name = sec.process_name
							AND pg.component_name = sec.component_name
							AND pg.activity_name = sec.activity_name
							AND pg.ui_name = sec.ui_name
							AND pg.page_bt_synonym = sec.page_bt_synonym
						)
				)
		BEGIN
			SELECT @m_errorid = 6

			--code Modified for bugId : PNR2.0_11746
			RAISERROR (
					'For Component : %s, Activity: %s, Section is not defined for one or more of the Pages.',
					16,
					1,
					@engg_component,
					@activity_name
					)

			RETURN
		END

		IF EXISTS (
				SELECT 'x'
				FROM ep_published_ui_section_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_req_no
					AND component_name = @engg_component
					AND activity_name = @activity_name
					AND (
						horder = 0
						OR vorder = 0
						)
				)
		BEGIN
			SELECT @m_errorid = 5

			--code Modified for bugId : PNR2.0_11746
			RAISERROR (
					'For Component : %s, Activity : %s, Page Layout is not defined for one or more of the pages.',
					16,
					1,
					@engg_component,
					@activity_name
					)

			RETURN
		END

		-- code modified by shafina on 14-Sep-2004 for PREVIEWENG203ACC_000100 (check for columns not defined for a grid control)
		IF EXISTS (
				SELECT 'x'
				FROM ep_published_ui_control_dtl ctrl(NOLOCK),
					es_comp_ctrl_type_mst_vw ctype(NOLOCK)
				WHERE ctrl.customer_name = ctype.customer_name
					AND ctrl.project_name = ctype.project_name
					AND ctrl.process_name = ctype.process_name
					AND ctrl.component_name = ctype.component_name
					AND ctrl.control_type = ctype.ctrl_type_name
					AND ctype.base_ctrl_type = 'Grid'
					AND ctrl.customer_name = @engg_customer_name
					AND ctrl.project_name = @engg_project_name
					AND ctrl.req_no = @engg_req_no
					AND ctrl.process_name = @process_name
					AND ctrl.component_name = @engg_component
					AND ctrl.activity_name = @activity_name
					AND NOT EXISTS (
						SELECT 'x'
						FROM ep_published_ui_grid_dtl grd(NOLOCK)
						WHERE ctrl.customer_name = grd.customer_name
							AND ctrl.project_name = grd.project_name
							AND ctrl.req_no = grd.req_no
							AND ctrl.process_name = grd.process_name
							AND ctrl.component_name = grd.component_name
							AND ctrl.activity_name = grd.activity_name
							AND ctrl.ui_name = grd.ui_name
							AND ctrl.page_bt_synonym = grd.page_bt_synonym
							AND ctrl.section_bt_synonym = grd.section_bt_synonym
							AND ctrl.control_bt_synonym = grd.control_bt_synonym
						)
				)
		BEGIN
			SELECT @m_errorid = 6

			--code Modified for bugId : PNR2.0_11746
			RAISERROR (
					'For Component %s, Activity %s, Columns are not defined for one or more of the Grid Controls.',
					16,
					1,
					@engg_component,
					@activity_name
					)

			RETURN
		END

		--Code added by 13026 for TECH-59801 starts

	IF EXISTS (
				SELECT 'x'
				FROM ep_published_ui_control_dtl ctrl(NOLOCK),
					es_comp_ctrl_type_mst_vw ctype(NOLOCK)
				WHERE ctrl.customer_name = ctype.customer_name
					AND ctrl.project_name = ctype.project_name
					AND ctrl.process_name = ctype.process_name
					AND ctrl.component_name = ctype.component_name
					AND ctrl.control_type = ctype.ctrl_type_name
					AND ctype.base_ctrl_type = 'Assorted'
					AND ctrl.customer_name = @engg_customer_name
					AND ctrl.project_name = @engg_project_name
					AND ctrl.req_no = @engg_req_no
					AND ctrl.process_name = @process_name
					AND ctrl.component_name = @engg_component
					AND ctrl.activity_name = @activity_name
					AND NOT EXISTS (
						SELECT 'x'
						FROM ep_published_ui_grid_dtl grd(NOLOCK)
						WHERE ctrl.customer_name = grd.customer_name
							AND ctrl.project_name = grd.project_name
							AND ctrl.req_no = grd.req_no
							AND ctrl.process_name = grd.process_name
							AND ctrl.component_name = grd.component_name
							AND ctrl.activity_name = grd.activity_name
							AND ctrl.ui_name = grd.ui_name
							AND ctrl.page_bt_synonym = grd.page_bt_synonym
							AND ctrl.section_bt_synonym = grd.section_bt_synonym
							AND ctrl.control_bt_synonym = grd.control_bt_synonym
						)
				)

			BEGIN
					
			RAISERROR (
					'For Component : %s, Activity : %s, Columns are not defined for assorted Controls.',
					16,
					1,
					@engg_component,
					@activity_name
					)

			RETURN
		
		END

	-- Code added by 13026 for TECH-59801 ends

		-- code modified by shafina on 30-Nov-2004 for PREVIEWPF204SYS_000040 (while Generating Preview, columns are not defined for a radio button(tab). Error message not raised.)
		IF EXISTS (
				SELECT 'x'
				FROM ep_published_ui_control_dtl ctrl(NOLOCK),
					es_comp_ctrl_type_mst_vw ctype(NOLOCK)
				WHERE ctrl.customer_name = ctype.customer_name
					AND ctrl.project_name = ctype.project_name
					AND ctrl.process_name = ctype.process_name
					AND ctrl.component_name = ctype.component_name
					AND ctrl.control_type = ctype.ctrl_type_name
					AND ctype.base_ctrl_type = 'RadioButton'
					AND ctrl.customer_name = @engg_customer_name
					AND ctrl.project_name = @engg_project_name
					AND ctrl.req_no = @engg_req_no
					AND ctrl.process_name = @process_name
					AND ctrl.component_name = @engg_component
					AND ctrl.activity_name = @activity_name
					AND NOT EXISTS (
						SELECT 'x'
						FROM ep_published_radio_button_dtl rd(NOLOCK)
						WHERE ctrl.customer_name = rd.customer_name
							AND ctrl.project_name = rd.project_name
							AND ctrl.req_no = rd.req_no
							AND ctrl.process_name = rd.process_name
							AND ctrl.component_name = rd.component_name
							AND ctrl.activity_name = rd.activity_name
							AND ctrl.ui_name = rd.ui_name
							AND ctrl.page_bt_synonym = rd.page_bt_synonym
							AND ctrl.section_bt_synonym = rd.section_bt_synonym
							AND ctrl.control_bt_synonym = rd.control_bt_synonym
						)
				)
		BEGIN
			SELECT @m_errorid = 6

			--code Modified for bugId : PNR2.0_11746
			RAISERROR (
					'For Component : %s, Activity : %s, Code is not defined for one or more of the Radio Button Controls.',
					16,
					1,
					@engg_component,
					@activity_name
					)

			RETURN
		END
	END
			-- code modified by shafina on 10-Sep-2004 for PREVIEWENG203SYS_000147
	ELSE IF @ctxt_service IN (
			'EP_Prevw_Sr_GenUI',
			'EP_Prevw_Sr_View'
			) -- code modified by Ganesh for PNR2.0_4658 on 16th Nov 2005
	BEGIN
		IF EXISTS (
				SELECT 'x'
				FROM ep_ui_page_dtl pg(NOLOCK)
				WHERE pg.customer_name = @engg_customer_name
					AND pg.project_name = @engg_project_name
					AND pg.req_no = @engg_req_no
					AND pg.process_name = @process_name
					AND pg.component_name = @engg_component
					AND pg.activity_name = @activity_name
					AND NOT EXISTS (
						SELECT 'x'
						FROM ep_ui_section_dtl sec(NOLOCK)
						WHERE pg.customer_name = sec.customer_name
							AND pg.project_name = sec.project_name
							AND pg.req_no = sec.req_no
							AND pg.process_name = sec.process_name
							AND pg.component_name = sec.component_name
							AND pg.activity_name = sec.activity_name
							AND pg.ui_name = sec.ui_name
							AND pg.page_bt_synonym = sec.page_bt_synonym
						)
				)
		BEGIN
			SELECT @m_errorid = 6

			--code Modified for bugId : PNR2.0_11746
			RAISERROR (
					'For Component : %s, Activity : %s, Section is not defined for one or more of the Pages.',
					16,
					1,
					@engg_component,
					@activity_name
					)

			RETURN
		END

		IF EXISTS (
				SELECT 'x'
				FROM ep_ui_section_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND component_name = @engg_component
					AND activity_name = @activity_name
					AND (
						horder = 0
						OR vorder = 0
						)
				)
		BEGIN
			SELECT @m_errorid = 5

			--code Modified for bugId : PNR2.0_11746
			RAISERROR (
					'For Component : %s, Activity : %s, Page Layout is not defined for one or more of the pages.',
					16,
					1,
					@engg_component,
					@activity_name
					)

			RETURN
		END

		IF EXISTS (
				SELECT 'x'
				FROM ep_ui_control_dtl ctrl(NOLOCK),
					es_comp_ctrl_type_mst_vw ctype(NOLOCK)
				WHERE ctrl.customer_name = ctype.customer_name
					AND ctrl.project_name = ctype.project_name
					AND ctrl.process_name = ctype.process_name
					AND ctrl.component_name = ctype.component_name
					AND ctrl.control_type = ctype.ctrl_type_name
					AND ctype.base_ctrl_type = 'Grid'
					AND ctrl.customer_name = @engg_customer_name
					AND ctrl.project_name = @engg_project_name
					AND ctrl.process_name = @process_name
					AND ctrl.component_name = @engg_component
					AND ctrl.activity_name = @activity_name
					AND NOT EXISTS (
						SELECT 'x'
						FROM ep_ui_grid_dtl grd(NOLOCK)
						WHERE ctrl.customer_name = grd.customer_name
							AND ctrl.project_name = grd.project_name
							AND ctrl.process_name = grd.process_name
							AND ctrl.component_name = grd.component_name
							AND ctrl.activity_name = grd.activity_name
							AND ctrl.ui_name = grd.ui_name
							AND ctrl.page_bt_synonym = grd.page_bt_synonym
							AND ctrl.section_bt_synonym = grd.section_bt_synonym
							AND ctrl.control_bt_synonym = grd.control_bt_synonym
						)
				)
		BEGIN
			SELECT @m_errorid = 6

			--code Modified for bugId : PNR2.0_11746
			RAISERROR (
					'For Component : %s, Activity : %s, Columns are not defined for one or more of the Grid Controls.',
					16,
					1,
					@engg_component,
					@activity_name
					)

			RETURN
		END

		IF EXISTS (
				SELECT 'x'
				FROM ep_ui_control_dtl ctrl(NOLOCK),
					es_comp_ctrl_type_mst_vw ctype(NOLOCK)
				WHERE ctrl.customer_name = ctype.customer_name
					AND ctrl.project_name = ctype.project_name
					AND ctrl.process_name = ctype.process_name
					AND ctrl.component_name = ctype.component_name
					AND ctrl.control_type = ctype.ctrl_type_name
					AND ctype.base_ctrl_type = 'RadioButton'
					AND ctrl.customer_name = @engg_customer_name
					AND ctrl.project_name = @engg_project_name
					AND ctrl.process_name = @process_name
					AND ctrl.component_name = @engg_component
					AND ctrl.activity_name = @activity_name
					AND NOT EXISTS (
						SELECT 'x'
						FROM ep_radio_button_dtl rd(NOLOCK)
						WHERE ctrl.customer_name = rd.customer_name
							AND ctrl.project_name = rd.project_name
							AND ctrl.process_name = rd.process_name
							AND ctrl.component_name = rd.component_name
							AND ctrl.activity_name = rd.activity_name
							AND ctrl.ui_name = rd.ui_name
							AND ctrl.page_bt_synonym = rd.page_bt_synonym
							AND ctrl.section_bt_synonym = rd.section_bt_synonym
							AND ctrl.control_bt_synonym = rd.control_bt_synonym
						)
				)
		BEGIN
			SELECT @m_errorid = 6

			--code Modified for bugId : PNR2.0_11746
			RAISERROR (
					'For Component : %s, Activity %s, Code is not defined for one or more of the Radio Button Controls.',
					16,
					1,
					@engg_component,
					@activity_name
					)

			RETURN
		END

		-- code modified by shafina on 14-Sep-2004 for PREVIEWENG203ACC_000100 (check for main ui existence in an activity)
		IF EXISTS (
				SELECT 's'
				FROM fw_bpt_activity_vw a(NOLOCK),
					fw_bpt_function_component_vw b(NOLOCK)
				WHERE a.CustomerID = b.CustomerID
					AND a.ProjectID = b.ProjectID
					AND a.BPID = b.BPID
					AND a.FunctionID = b.FunctionID
					AND b.CustomerID = @engg_customer_name
					AND b.ProjectID = @engg_project_name
					AND b.BPID = @process_name
					AND b.componentname = @engg_component
					AND a.CustomerID = @engg_customer_name
					AND a.ProjectID = @engg_project_name
					AND a.BPID = @process_name
					AND a.activityid = @activity_name
					AND a.ActivityType = 'USR'
				)
		BEGIN
			IF NOT EXISTS (
					SELECT 'x'
					FROM ep_ui_mst(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND component_name = @engg_component
						AND activity_name = @activity_name
						-- code modified for the Bug ID :: PNR2.0_18732 - start
						AND ui_type IN (
							'Main',
							'MainModify'
							)
					)
				-- code modified for the Bug ID :: PNR2.0_18732 - End
			BEGIN
				SELECT @m_errorid = 7

				RAISERROR (
						'Main UI does not exist for this activity',
						16,
						4
						)

				RETURN
			END
		END
	END

	IF @ctxt_service_in IN (
			'Ep_layot_sr_prvw',
			'pmdeuimnsrgenpvw',
			'PMmnguiSrgenpvw',
			'PMmvscctSrgenpvw',
			'BulkGenerate',
			'ep_ext_mnsrgenprw',
			'ep_lstedtsrgenprw',
			'ep_ui_tbrsrgenprw'
			)
		AND @pubflag = 'P' -- modified by feroz :PNR2.0_1790 -- code modified by Ganesh for PNR2.0_4658 on 16th Nov 2005
	BEGIN
		IF EXISTS (
				SELECT 'x'
				FROM ep_published_ui_page_dtl pg(NOLOCK)
				WHERE pg.customer_name = @engg_customer_name
					AND pg.project_name = @engg_project_name
					AND pg.req_no = @engg_req_no
					AND pg.process_name = @process_name
					AND pg.component_name = @engg_component
					AND pg.activity_name = @activity_name
					AND pg.ui_name = @ui_name_tmp
					AND NOT EXISTS (
						SELECT 'x'
						FROM ep_published_ui_section_dtl sec(NOLOCK)
						WHERE pg.customer_name = sec.customer_name
							AND pg.project_name = sec.project_name
							AND pg.req_no = sec.req_no
							AND pg.process_name = sec.process_name
							AND pg.component_name = sec.component_name
							AND pg.activity_name = sec.activity_name
							AND pg.ui_name = sec.ui_name
							AND pg.page_bt_synonym = sec.page_bt_synonym
						)
				)
		BEGIN
			SELECT @m_errorid = 6

			--code Modified for bugId : PNR2.0_11746
			RAISERROR (
					'For Component : %s, Activity : %s, Section is not defined for one or more of the Pages.',
					16,
					1,
					@engg_component,
					@activity_name
					)

			RETURN
		END

		IF EXISTS (
				SELECT 'x'
				FROM ep_published_ui_section_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_req_no
					AND component_name = @engg_component
					AND activity_name = @activity_name
					AND ui_name = @ui_name_tmp
					AND (
						horder = 0
						OR vorder = 0
						)
				)
		BEGIN
			SELECT @m_errorid = 5

			--code Modified for bugId : PNR2.0_11746
			RAISERROR (
					'For Component : %s, Activity : %s, Page Layout is not defined for one or more of the pages.',
					16,
					1,
					@engg_component,
					@activity_name
					)

			RETURN
		END

		IF EXISTS (
				SELECT 'x'
				FROM ep_published_ui_control_dtl ctrl(NOLOCK),
					es_comp_ctrl_type_mst_vw ctype(NOLOCK)
				WHERE ctrl.customer_name = ctype.customer_name
					AND ctrl.project_name = ctype.project_name
					AND ctrl.process_name = ctype.process_name
					AND ctrl.component_name = ctype.component_name
					AND ctrl.control_type = ctype.ctrl_type_name
					AND ctype.base_ctrl_type = 'Grid'
					AND ctrl.customer_name = @engg_customer_name
					AND ctrl.project_name = @engg_project_name
					AND ctrl.req_no = @engg_req_no
					AND ctrl.process_name = @process_name
					AND ctrl.component_name = @engg_component
					AND ctrl.activity_name = @activity_name
					AND ctrl.ui_name = @ui_name_tmp
					AND NOT EXISTS (
						SELECT 'x'
						FROM ep_published_ui_grid_dtl grd(NOLOCK)
						WHERE ctrl.customer_name = grd.customer_name
							AND ctrl.project_name = grd.project_name
							AND ctrl.req_no = grd.req_no
							AND ctrl.process_name = grd.process_name
							AND ctrl.component_name = grd.component_name
							AND ctrl.activity_name = grd.activity_name
							AND ctrl.ui_name = grd.ui_name
							AND ctrl.page_bt_synonym = grd.page_bt_synonym
							AND ctrl.section_bt_synonym = grd.section_bt_synonym
							AND ctrl.control_bt_synonym = grd.control_bt_synonym
						)
				)
		BEGIN
			SELECT @m_errorid = 6

			--code Modified for bugId : PNR2.0_11746
			RAISERROR (
					'For Component : %s, Activity : %s, Columns are not defined for one or more of the Grid Controls.',
					16,
					1,
					@engg_component,
					@activity_name
					)

			RETURN
		END

		IF EXISTS (
				SELECT 'x'
				FROM ep_published_ui_control_dtl ctrl(NOLOCK),
					es_comp_ctrl_type_mst_vw ctype(NOLOCK)
				WHERE ctrl.customer_name = ctype.customer_name
					AND ctrl.project_name = ctype.project_name
					AND ctrl.process_name = ctype.process_name
					AND ctrl.component_name = ctype.component_name
					AND ctrl.control_type = ctype.ctrl_type_name
					AND ctype.base_ctrl_type = 'RadioButton'
					AND ctrl.customer_name = @engg_customer_name
					AND ctrl.project_name = @engg_project_name
					AND ctrl.req_no = @engg_req_no
					AND ctrl.process_name = @process_name
					AND ctrl.component_name = @engg_component
					AND ctrl.activity_name = @activity_name
					AND ctrl.ui_name = @ui_name_tmp
					AND NOT EXISTS (
						SELECT 'x'
						FROM ep_published_radio_button_dtl rd(NOLOCK)
						WHERE ctrl.customer_name = rd.customer_name
							AND ctrl.project_name = rd.project_name
							AND ctrl.req_no = rd.req_no
							AND ctrl.process_name = rd.process_name
							AND ctrl.component_name = rd.component_name
							AND ctrl.activity_name = rd.activity_name
							AND ctrl.ui_name = rd.ui_name
							AND ctrl.page_bt_synonym = rd.page_bt_synonym
							AND ctrl.section_bt_synonym = rd.section_bt_synonym
							AND ctrl.control_bt_synonym = rd.control_bt_synonym
						)
				)
		BEGIN
			SELECT @m_errorid = 6

			--code Modified for bugId : PNR2.0_11746
			RAISERROR (
					'For Component : %s, Activity : %s, Code is not defined for one or more of the Radio Button Controls.',
					16,
					1,
					@engg_component,
					@activity_name
					)

			RETURN
		END
	END
	ELSE IF @ctxt_service IN (
			'Ep_layout_sr_prvw',
			'pmdeuimnsrgenpvw',
			'PMmnguiSrgenpvw',
			'PMmvscctSrgenpvw',
			'BulkGenerate',
			'ep_ext_mnsrgenprw',
			'ep_lstedtsrgenprw',
			'ep_ui_tbrsrgenprw'
			)
	BEGIN
		IF EXISTS (
				SELECT 'x'
				FROM ep_ui_page_dtl pg(NOLOCK)
				WHERE pg.customer_name = @engg_customer_name
					AND pg.project_name = @engg_project_name
					AND pg.req_no = @engg_req_no
					AND pg.process_name = @process_name
					AND pg.component_name = @engg_component
					AND pg.activity_name = @activity_name
					AND pg.ui_name = @ui_name_tmp
					AND NOT EXISTS (
						SELECT 'x'
						FROM ep_ui_section_dtl sec(NOLOCK)
						WHERE pg.customer_name = sec.customer_name
							AND pg.project_name = sec.project_name
							AND pg.req_no = sec.req_no
							AND pg.process_name = sec.process_name
							AND pg.component_name = sec.component_name
							AND pg.activity_name = sec.activity_name
							AND pg.ui_name = sec.ui_name
							AND pg.page_bt_synonym = sec.page_bt_synonym
						)
				)
		BEGIN
			SELECT @m_errorid = 6

			--code Modified for bugId : PNR2.0_11746
			RAISERROR (
					'For Component : %s, Activity %s, Section is not defined for one or more of the Pages.',
					16,
					1,
					@engg_component,
					@activity_name
					)

			RETURN
		END

		IF EXISTS (
				SELECT 'x'
				FROM ep_ui_section_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND component_name = @engg_component
					AND activity_name = @activity_name
					AND ui_name = @ui_name_tmp
					AND (
						horder = 0
						OR vorder = 0
						)
				)
		BEGIN
			SELECT @m_errorid = 5

			--code Modified for bugId : PNR2.0_11746
			RAISERROR (
					'For Component : %s, Activity : %s, Page Layout is not defined for one or more of the pages.',
					16,
					1,
					@engg_component,
					@activity_name
					)

			RETURN
		END

		IF EXISTS (
				SELECT 'x'
				FROM ep_ui_control_dtl ctrl(NOLOCK),
					es_comp_ctrl_type_mst_vw ctype(NOLOCK)
				WHERE ctrl.customer_name = ctype.customer_name
					AND ctrl.project_name = ctype.project_name
					AND ctrl.req_no = ctype.req_no
					AND ctrl.process_name = ctype.process_name
					AND ctrl.component_name = ctype.component_name
					AND ctrl.control_type = ctype.ctrl_type_name
					AND ctype.base_ctrl_type = 'Grid'
					AND ctrl.customer_name = @engg_customer_name
					AND ctrl.project_name = @engg_project_name
					AND ctrl.req_no = 'Base'
					AND ctrl.process_name = @process_name
					AND ctrl.component_name = @engg_component
					AND ctrl.activity_name = @activity_name
					AND ctrl.ui_name = @ui_name_tmp
					AND NOT EXISTS (
						SELECT 'x'
						FROM ep_ui_grid_dtl grd(NOLOCK)
						WHERE ctrl.customer_name = grd.customer_name
							AND ctrl.project_name = grd.project_name
							AND ctrl.req_no = grd.req_no
							AND ctrl.process_name = grd.process_name
							AND ctrl.component_name = grd.component_name
							AND ctrl.activity_name = grd.activity_name
							AND ctrl.ui_name = grd.ui_name
							AND ctrl.page_bt_synonym = grd.page_bt_synonym
							AND ctrl.section_bt_synonym = grd.section_bt_synonym
							AND ctrl.control_bt_synonym = grd.control_bt_synonym
						)
				)
		BEGIN
			SELECT @m_errorid = 6

			--code Modified for bugId : PNR2.0_11746
			RAISERROR (
					'For Component : %s, Activity : %s, Columns are not defined for one or more of the Grid Controls.',
					16,
					1,
					@engg_component,
					@activity_name
					)

			RETURN
		END

		--13026 Code added by 13026 for TECH-59801 starts

		
IF EXISTS (
				SELECT 'x'
				FROM ep_ui_control_dtl ctrl(NOLOCK),
					es_comp_ctrl_type_mst_vw ctype(NOLOCK)
				WHERE ctrl.customer_name = ctype.customer_name
					AND ctrl.project_name = ctype.project_name
					AND ctrl.req_no = ctype.req_no
					AND ctrl.process_name = ctype.process_name
					AND ctrl.component_name = ctype.component_name
					AND ctrl.control_type = ctype.ctrl_type_name
					AND ctype.base_ctrl_type = 'Assorted'
					AND ctrl.customer_name = @engg_customer_name
					AND ctrl.project_name = @engg_project_name
					AND ctrl.req_no = 'Base'
					AND ctrl.process_name = @process_name
					AND ctrl.component_name = @engg_component
					AND ctrl.activity_name = @activity_name
					AND ctrl.ui_name = @ui_name_tmp
					AND NOT EXISTS (
						SELECT 'x'
						FROM ep_ui_grid_dtl grd(NOLOCK)
						WHERE ctrl.customer_name = grd.customer_name
							AND ctrl.project_name = grd.project_name
							AND ctrl.req_no = grd.req_no
							AND ctrl.process_name = grd.process_name
							AND ctrl.component_name = grd.component_name
							AND ctrl.activity_name = grd.activity_name
							AND ctrl.ui_name = grd.ui_name
							AND ctrl.page_bt_synonym = grd.page_bt_synonym
							AND ctrl.section_bt_synonym = grd.section_bt_synonym
							AND ctrl.control_bt_synonym = grd.control_bt_synonym
						)
				)

			BEGIN
					
			RAISERROR (
					'For Component : %s, Activity : %s, Columns are not defined for assorted Controls.',
					16,
					1,
					@engg_component,
					@activity_name
					)

			RETURN
		
		END

		--Code added by 13026 for TECH-59801 ends

		IF EXISTS (
				SELECT 'x'
				FROM ep_ui_control_dtl ctrl(NOLOCK),
					es_comp_ctrl_type_mst_vw ctype(NOLOCK)
				WHERE ctrl.customer_name = ctype.customer_name
					AND ctrl.project_name = ctype.project_name
					AND ctrl.req_no = ctype.req_no
					AND ctrl.process_name = ctype.process_name
					AND ctrl.component_name = ctype.component_name
					AND ctrl.control_type = ctype.ctrl_type_name
					AND ctype.base_ctrl_type = 'RadioButton'
					AND ctrl.customer_name = @engg_customer_name
					AND ctrl.project_name = @engg_project_name
					AND ctrl.req_no = 'Base'
					AND ctrl.process_name = @process_name
					AND ctrl.component_name = @engg_component
					AND ctrl.activity_name = @activity_name
					AND ctrl.ui_name = @ui_name_tmp
					AND NOT EXISTS (
						SELECT 'x'
						FROM ep_radio_button_dtl rd(NOLOCK)
						WHERE ctrl.customer_name = rd.customer_name
							AND ctrl.project_name = rd.project_name
							AND ctrl.req_no = rd.req_no
							AND ctrl.process_name = rd.process_name
							AND ctrl.component_name = rd.component_name
							AND ctrl.activity_name = rd.activity_name
							AND ctrl.ui_name = rd.ui_name
							AND ctrl.page_bt_synonym = rd.page_bt_synonym
							AND ctrl.section_bt_synonym = rd.section_bt_synonym
							AND ctrl.control_bt_synonym = rd.control_bt_synonym
						)
				)
		BEGIN
			SELECT @m_errorid = 6

			--code Modified for bugId : PNR2.0_11746
			RAISERROR (
					'For Component : %s, Activity : %s, Code is not defined for one or more of the Radio Button Controls.',
					16,
					1,
					@engg_component,
					@activity_name
					)

			RETURN
		END
	END

	--Code added against TECH-218 starts
	IF EXISTS (
			SELECT 'x'
			FROM ep_new_ui_mst a(NOLOCK),
				ep_ui_mst b(NOLOCK)
			WHERE a.customer_name = rtrim(@engg_customer_name)
				AND a.project_name = rtrim(@engg_project_name)
				AND a.process_name = rtrim(@process_name)
				AND a.component_name = rtrim(@engg_component)
				AND a.activity_name = rtrim(@activity_name)
				AND a.ui_name = rtrim(@ui_name_tmp)
				AND a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.activity_name = b.activity_name
				AND a.ui_name = b.ui_name
				AND ISNULL(b.IsGlance, '') <> 'Y'
			)
	BEGIN
		EXEC ep_ui_layout_validation @engg_customer_name,
			@engg_project_name,
			@process_name,
			@engg_component,
			@activity_name,
			@ui_name_tmp,
			'',
			'',
			'Page',
			@ctxt_user_in
	END

	--Code added against TECH-218 ends
	SELECT @xml_seq_tmp = 0,
		@mainpage_tmp = '[MAINSCREEN]',
		@prjsecrow = 1,
		@m_errorid = 0

	-- Delete existing XML for the component
	DELETE ep_genxml_tmp
	WHERE guid = @guid

	--Code Added For Bug_id PNR2.0_17856 Starts here
	SELECT @FillerClass = isnull(current_value, '')
	FROM es_comp_param_mst_vw(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND param_category = 'FILLERCLASS'
		AND process_name = @process_name
		AND component_name = @engg_component

	--Code Added For Bug_id PNR2.0_17856 Ends here
	-- code added by Ganesh for the bugid :: PNR2.0_2349 on 09/05/05
	-- Html generation path was given as input
	IF @ctxt_service_in = 'BulkGenerate'
	BEGIN
		SELECT @xmlpath_tmp = isnull(@html_gen_path, '') + '\_proto_\' + @ui_name_tmp + '.xml',
			@targetdir_tmp = @html_gen_path + '\_proto_'
	END
	ELSE
	BEGIN
		SELECT @xmlpath_tmp = isnull(current_value, '') + '\_proto_\' + @ui_name_tmp + '.xml',
			@targetdir_tmp = current_value + '\_proto_'
		FROM es_comp_param_mst_vw(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND param_category = 'PROTOGENPATH'
			AND process_name = @process_name
			AND component_name = @engg_component
	END

	-- Entry Point UI
	IF @ctxt_service_in IN ('BulkGenerate')
		AND @pubflag = 'P'
	BEGIN
		SELECT @entry_ui_tmp = isnull(ui_name, '')
		FROM ep_published_ui_mst(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND req_no = @engg_req_no
			AND component_name = @engg_component
			AND activity_name = @activity_name
			AND ui_type IN (
				'Search',
				'Main',
				'MainModify'
				) --Modified for PNR2.0_26631
	END
	ELSE
	BEGIN
		SELECT @entry_ui_tmp = isnull(ui_name, '')
		FROM ep_ui_mst(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND component_name = @engg_component
			AND activity_name = @activity_name
			AND ui_type IN (
				'Search',
				'Main',
				'MainModify'
				) --Modified for PNR2.0_26631
	END

	IF @engg_language_name IS NULL
		SELECT @engg_language_name = 'English'

	-- Getting the Language Id
	SELECT @language_code = quick_code,
		@lang_settings = lang_settings -- Code added  for  PNR2.0_20849
	FROM ep_language_met(NOLOCK)
	WHERE quick_code_value = @engg_language_name
		AND quick_code_type = 'language_code'

	--code modified by kiruthika for bugid :PNR2.0_28767 on 21-oct-2010 starts
	IF EXISTS (
			SELECT 'x'
			FROM ep_quick_code_mst(NOLOCK)
			WHERE quick_code_type = 'Help_Caption'
				AND quick_code = convert(VARCHAR(3), @language_code)
			)
	BEGIN
		SELECT @ok_caption = quick_code_value
		FROM ep_quick_code_mst(NOLOCK)
		WHERE quick_code_type = 'Help_Caption'
			AND quick_code = convert(VARCHAR(3), @language_code)
	END
	ELSE
	BEGIN
		SELECT @ok_caption = convert(VARCHAR(3), @language_code) + '_' + 'OK'
	END

	Declare @ep_component_glossary_mst Table 
			(customer_name	VARCHAR(60),project_name VARCHAR(60),process_name VARCHAR(60),
			 component_name VARCHAR(60),bt_synonym_name VARCHAR(64), bt_synonym_caption engg_description_lng,req_no engg_name,
			 data_type engg_name, length engg_length, bt_name engg_name, singleinst_sample_data engg_documentation, multiinst_sample_data engg_documentation
			 PRIMARY KEY (customer_name,project_name,process_name,component_name,bt_synonym_name))

		INSERT INTO @ep_component_glossary_mst
			(customer_name,project_name,process_name,component_name,bt_synonym_name,
			bt_synonym_caption,req_no,data_type , length , bt_name , singleinst_sample_data , multiinst_sample_data)	
		select distinct a.customer_name,a.project_name,a.process_name,a.component_name,a.bt_synonym_name,a.bt_synonym_caption,req_no,data_type engg_name, length , bt_name , singleinst_sample_data , multiinst_sample_data
		from  ep_component_glossary_mst  a(nolock)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND req_no = 'base'
			AND process_name = @process_name
			AND component_name = @engg_component
		
	
		
	
	--code modified by kiruthika for bugid :PNR2.0_28767 on 21-oct-2010 ends
	-- code modified by shafina on 14-May-2004 for PREVIEWENG203ACC_000059
	IF @ctxt_service_in IN ('BulkGenerate')
		AND @pubflag = 'P'
	BEGIN

		Declare @ep_published_comp_glossary_mst Table 
			(customer_name	VARCHAR(60),project_name VARCHAR(60),process_name VARCHAR(60),
			 component_name VARCHAR(60),bt_synonym_name VARCHAR(64), bt_synonym_caption engg_description_lng,req_no engg_name,
			 			 data_type engg_name, length engg_length, bt_name engg_name, singleinst_sample_data engg_documentation, multiinst_sample_data engg_documentation
			 PRIMARY KEY (customer_name,project_name,process_name,component_name,bt_synonym_name,req_no))

		INSERT INTO @ep_published_comp_glossary_mst
			(customer_name,project_name,process_name,component_name,bt_synonym_name,bt_synonym_caption,req_no ,data_type , length , bt_name , singleinst_sample_data , multiinst_sample_data)	
		select a.customer_name,a.project_name,a.process_name,a.component_name,a.bt_synonym_name,a.bt_synonym_caption,req_no ,data_type , length , bt_name , singleinst_sample_data , multiinst_sample_data
		from  ep_published_comp_glossary_mst  a(nolock)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND req_no = @engg_req_no
			AND process_name = @process_name
			AND component_name = @engg_component
	

		SELECT @ui_descr_tmp = bt_synonym_caption
		FROM @ep_published_comp_glossary_mst
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND req_no = @engg_req_no
			AND process_name = @process_name
			AND component_name = @engg_component
			AND bt_synonym_name = @ui_name_tmp
			----AND languageid = @language_code
	END
	ELSE
	BEGIN
		SELECT @ui_descr_tmp = bt_synonym_caption
		FROM @ep_component_glossary_mst
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND req_no = 'base'
			AND process_name = @process_name
			AND component_name = @engg_component
			AND bt_synonym_name = @ui_name_tmp
			----AND languageid = @language_code
	END

	SELECT @ui_descr_tmp = replace(@ui_descr_tmp, '&', '&amp;')

	SELECT @ui_descr_tmp = replace(@ui_descr_tmp, '<', '&lt;')

	SELECT @ui_descr_tmp = replace(@ui_descr_tmp, '>', '&gt;')

	SELECT @ui_descr_tmp = replace(@ui_descr_tmp, '"', '&quot;')

	SELECT @engg_component_descr = bt_synonym_caption
	FROM @ep_component_glossary_mst
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND req_no = 'base'
		AND process_name = @process_name
		AND component_name = @engg_component
		AND bt_synonym_name = @engg_component
		----AND languageid = @language_code

	SELECT @engg_act_descr_lng = bt_synonym_caption
	FROM @ep_component_glossary_mst
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND req_no = 'base'
		AND process_name = @process_name
		AND component_name = @engg_component
		AND bt_synonym_name = @activity_name
		----AND languageid = @language_code

	SELECT @engg_component_descr = replace(@engg_component_descr, '&', '&amp;')

	SELECT @engg_component_descr = replace(@engg_component_descr, '<', '&lt;')

	SELECT @engg_component_descr = replace(@engg_component_descr, '>', '&gt;')

	SELECT @engg_component_descr = replace(@engg_component_descr, '"', '&quot;')

	SELECT @engg_act_descr_temp = replace(@engg_act_descr, '&', '&amp;')

	SELECT @engg_act_descr_temp = replace(@engg_act_descr_temp, '<', '&lt;')

	SELECT @engg_act_descr_temp = replace(@engg_act_descr_temp, '>', '&gt;')

	SELECT @engg_act_descr_temp = replace(@engg_act_descr_temp, '"', '&quot;')

	-- For Component Configuration Root Node
	--Code Modified For BugId : PNR2.0_7461
	IF @offlinepackage = 0
	BEGIN
		-- Code added for TECH-16126 Starts
		SELECT @devicetype = devicetype
		FROM ep_ui_mst(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND component_name = @engg_component
			AND activity_name = @activity_name
			AND ui_name = @engg_ui_descr_in

		IF isnull(@devicetype, '') IN (
				'P',
				'T',
				'B'
				)
		BEGIN
			SELECT @ProtoLaunchMode = 'mhub2'
		END

		-- Code added for TECH-16126 Ends
		SELECT @xml_seq_tmp = @xml_seq_tmp + 1

		INSERT INTO ep_genxml_tmp (
			customer_name,
			project_name,
			req_no,
			process_name,
			component_name,
			activity_name,
			guid,
			gen_xml,
			seq_no
			)
		VALUES (
			@engg_customer_name,
			@engg_project_name,
			@engg_req_no,
			@process_name,
			@engg_component,
			@activity_name,
			@guid,
			'<Configuration ComponentName="' + isnull(@engg_component, '') + '" ComponentDesc="' + isnull(@engg_component_descr, '') + '" ActivityName ="' + isnull(@activity_name, '') + '" ActivityDesc="' + isnull(@engg_act_descr_temp, '') + '" ILBOCode="' + isnull(@ui_name_tmp, '') + '" ILBODesc="' + isnull(@ui_descr_tmp, '') + '" TargetDirectory="' + isnull(@targetdir_tmp, '') + '" XMLPath="' + isnull(@xmlpath_tmp, '') + '" ProtoLaunchMode="' + isnull(upper(@ProtoLaunchMode), '') + '" Activity="Activity"></Configuration>',
			1
			)
	END

	SELECT @xml_seq_tmp = @xml_seq_tmp + 1

	INSERT INTO ep_genxml_tmp (
		customer_name,
		project_name,
		req_no,
		process_name,
		component_name,
		activity_name,
		guid,
		gen_xml,
		seq_no
		)
	VALUES (
		@engg_customer_name,
		@engg_project_name,
		@engg_req_no,
		@process_name,
		@engg_component,
		@activity_name,
		@guid,
		'<Activities>',
		@xml_seq_tmp
		)

	-- Fetch activities
	-- code modified by shafina on 24-Aug-2004 for PREVIEWENG203SYS_000133(The sytem activity name is appearing in the left pane on the  preview)
	-- code modified by Ramachandran T on 16-feb-2005 for PREVIEWPFSUPPORT_000011(For the given customer, project when the request number is selected, no HTMs are generated. The folder is created as 'Customer_Project_MANAPPAPR'. instead of CBK_LOS_MANAPPAPR)

	--PNR2.0_14628
	IF @engg_req_no = 'Base'
		DECLARE actcurs INSENSITIVE CURSOR
		FOR
		SELECT DISTINCT upper(activity_name),
			component_name
		FROM ep_ui_req_dtl(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND component_name = @engg_component
			AND activity_descr = @engg_act_descr
		ORDER BY upper(activity_name) ELSE

	BEGIN
		-- code modified by Ramachandran T on 16-feb-2005 for PREVIEWPFSUPPORT_000011(For the given customer, project when the request number is selected, no HTMs are generated. The folder is created as 'Customer_Project_MANAPPAPR'. instead of CBK_LOS_MANAPPAPR)
		--Code Modified for bugId : PNR2.0_14590
		--Code Modified For BugId : PNR2.0_7668
		IF EXISTS (
				SELECT 'x'
				FROM ep_ui_req_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_req_no
					AND component_name = @engg_component
					AND activity_name = @activity_name
				)
		BEGIN
			DECLARE actcurs INSENSITIVE CURSOR
			FOR
			SELECT DISTINCT upper(activity_name),
				component_name
			FROM ep_ui_req_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_req_no
				AND component_name = @engg_component
				--   and  activity_descr  = @engg_act_descr -- code modified by Gowrisankar for PNR2.0_7691 on 04-Apr-2006
				AND activity_name = @activity_name
			ORDER BY upper(activity_name)
		END
		ELSE
		BEGIN
			DECLARE actcurs INSENSITIVE CURSOR
			FOR
			SELECT DISTINCT upper(activity_name),
				component_name
			FROM ep_ui_req_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND component_name = @engg_component
				--   and  activity_descr  = @activity_name -- code modified by Gowrisankar for PNR2.0_7691 on 04-Apr-2006
				AND activity_name = @activity_name
			ORDER BY upper(activity_name)
		END
				--Code Modified For BugId : PNR2.0_7668
				-- code modified by Ramachandran T on 16-feb-2005 for PREVIEWPFSUPPORT_000011(For the given customer, project when the request number is selected, no HTMs are generated. The folder is created as 'Customer_Project_MANAPPAPR'. instead of CBK_LOS_MANAPPAPR)
	END

	-- code modified by Ramachandran T on 16-feb-2005 for PREVIEWPFSUPPORT_000011(For the given customer, project when the request number is selected, no HTMs are generated. The folder is created as 'Customer_Project_MANAPPAPR'. instead of CBK_LOS_MANAPPAPR)

	OPEN actcurs

	-- For each activity generate entries
	WHILE (1 = 1)
	BEGIN
		FETCH NEXT
		FROM actcurs
		INTO @activity_name,
			@engg_component

		IF @@fetch_status <> 0
			BREAK

		---- code added by Ganesh for the callid :: PNR2.0_3812 on 09/09/05
		--EXEC ep_glossary_insert_at_act_sp @ctxt_language,
		--	@ctxt_ouinstance,
		--	@ctxt_service,
		--	@ctxt_user,
		--	@engg_customer_name,
		--	@engg_project_name,
		--	@process_name,
		--	@engg_component,
		--	@activity_name,
		--	@engg_act_descr,
		--	@ui_name_tmp,
		--	@engg_ui_descr,
		--	@engg_req_no,
		--	@language_code,
		--	@pubflag,
		--	@m_errorid OUTPUT

		-- Getting Function ID
		SELECT @engg_function = FunctionID
		FROM Fw_BPT_Function_Component_Vw
		WHERE CustomerID = @engg_customer_name
			AND ProjectID = @engg_project_name
			AND BPID = @process_name
			AND ComponentName = @engg_component

		-- Getting Activity type
		--Code Modified for bugId : PNR2.0_11270
		SELECT @activity_type = upper(ActivityType)
		FROM fw_bpt_activity_vw(NOLOCK)
		WHERE CustomerID = @engg_customer_name
			AND ProjectID = @engg_project_name
			AND BPID = @process_name
			AND FunctionID = @engg_function
			AND ActivityID = @activity_name

		SELECT @process_descr = replace(@process_descr, '&', '&amp;')

		SELECT @process_descr = replace(@process_descr, '<', '&lt;')

		SELECT @process_descr = replace(@process_descr, '>', '&gt;')

		SELECT @process_descr = replace(@process_descr, '"', '&quot;')

		SELECT @engg_act_descr_lng = bt_synonym_caption
		FROM @ep_component_glossary_mst
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND req_no = 'base'
			AND process_name = @process_name
			AND component_name = @engg_component
			AND bt_synonym_name = @activity_name
			----AND languageid = @language_code

		--Code Added for bugId :  PNR2.0_14879
		IF @engg_act_descr_lng IS NULL
		BEGIN
			RAISERROR (
					'For languageid : %s, Component : %s, Activity: %s, synonym name %s  not found in glossary',
					16,
					1,
					@language_code,
					@engg_component,
					@activity_name,
					@activity_name
					)

			CLOSE actcurs

			DEALLOCATE actcurs

			RETURN
		END

		SELECT @engg_act_descr_lng = replace(@engg_act_descr_lng, '&', '&amp;')

		SELECT @engg_act_descr_lng = replace(@engg_act_descr_lng, '<', '&lt;')

		SELECT @engg_act_descr_lng = replace(@engg_act_descr_lng, '>', '&gt;')

		SELECT @engg_act_descr_lng = replace(@engg_act_descr_lng, '"', '&quot;')

		-- Insert Activity entry
		SELECT @xml_seq_tmp = @xml_seq_tmp + 1

		INSERT INTO ep_genxml_tmp (
			customer_name,
			project_name,
			req_no,
			process_name,
			component_name,
			activity_name,
			guid,
			gen_xml,
			seq_no
			)
		VALUES (
			@engg_customer_name,
			@engg_project_name,
			@engg_req_no,
			@process_name,
			@engg_component,
			@activity_name,
			@guid,
			'<Activity Name="' + ltrim(rtrim(@activity_name)) + '" ' + 'ActivityDescription="' + ltrim(rtrim(isnull(@engg_act_descr_lng, @activity_name))) + '" ' + 'ActivityType="' + ltrim(rtrim(isnull(@activity_type, 'USR'))) + '" ' + 'ProcessName="' + upper(isnull(@process_name, '')) + '" ' + 'ProcessDescription="' + isnull(@process_descr, '') + '" ' + 'ComponentName="' + ltrim(rtrim(@engg_component)) + '" ' + 'ComponentDescription="' + ltrim(rtrim(@engg_component_descr)) + '" ' + 'EntryPointUI="' + ltrim(rtrim(@entry_ui_tmp)) + '" ' + 'DisplaySequence="' + '0' + '" ' +
			--Code Added For BugId : PNR2.0_8069
			'LanguageId="' + @language_code + '" ' + 'Customer="' + ltrim(rtrim(@engg_customer_name)) + '" ' + 'Project="' + ltrim(rtrim(@engg_project_name)) + '" ' + 'Request="' + ltrim(rtrim(@engg_req_no)) + '" ' +
			--Code Addition for PNR2.0_20849 starts
			'LanguageSettings="' + ltrim(rtrim(isnull(@lang_settings, ''))) + '" ' + 'ServerName="' + ltrim(rtrim(isnull(@ServerName, ''))) + '" ' + 'DatabaseName="' + ltrim(rtrim(isnull(@DatabaseName, ''))) + '">',
			@xml_seq_tmp
			)

		--Code Addition for PNR2.0_20849 ends
		-- Set Wildcard filter for All UIs
		IF @engg_ui_descr IS NULL
			OR @engg_ui_descr = 'All'
			OR @engg_ui_descr = ''
			SELECT @engg_ui_descr = '%'

		-- Insert Base Entry for ILBOs
		SELECT @xml_seq_tmp = @xml_seq_tmp + 1

		INSERT INTO ep_genxml_tmp (
			customer_name,
			project_name,
			req_no,
			process_name,
			component_name,
			activity_name,
			guid,
			gen_xml,
			seq_no
			)
		VALUES (
			@engg_customer_name,
			@engg_project_name,
			@engg_req_no,
			@process_name,
			@engg_component,
			@activity_name,
			@guid,
			'<ILBOs>',
			@xml_seq_tmp
			)

		-- Fetch UIs
		IF @ctxt_service_in IN ('ep_prevw_sr_genui')
		BEGIN
			DECLARE uicurs INSENSITIVE CURSOR
			FOR
			SELECT ui_sysid,
				upper(ui_name),
				ui_descr,
				ui_type,
				ui_format,
				caption_alignment,
				trail_bar,
				tab_height,
				isnull(state_processing, 'No'),
				isnull(callout_type, 'None'),
				isnull(TabPosition, 'Top'),
				isnull(PostLaunchTask, 'No') -- added By Feroz for extjs -- PNR2.0_1790
				,
				isnull(HideIlbotitlemenu_req, '')
			FROM ep_ui_mst(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND component_name = @engg_component
				AND activity_name = @activity_name
			ORDER BY ui_name
		END
		ELSE IF @ctxt_service_in IN (
				'ep_layout_sr_prvw',
				'pmdeuimnsrgenpvw',
				'PMmnguiSrgenpvw',
				'PMmvscctSrgenpvw',
				'ep_ext_mnsrgenprw',
				'ep_lstedtsrgenprw',
				'ep_ui_tbrsrgenprw'
				)
		BEGIN
			DECLARE uicurs INSENSITIVE CURSOR
			FOR
			SELECT ui_sysid,
				upper(ui_name),
				ui_descr,
				ui_type,
				ui_format,
				caption_alignment,
				trail_bar,
				tab_height,
				isnull(state_processing, 'No'),
				isnull(callout_type, 'None'),
				isnull(TabPosition, 'Top'),
				isnull(PostLaunchTask, 'No'),
				isnull(HideIlbotitlemenu_req, '') -- added By Feroz for extjs -- PNR2.0_1790
			FROM ep_ui_mst(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND component_name = @engg_component
				AND activity_name = @activity_name
				AND ui_name = @ui_name_tmp
			ORDER BY ui_name
		END
		ELSE IF @ctxt_service_in IN ('BulkGenerate')
		BEGIN
			IF @pubflag = 'P'
			BEGIN
				DECLARE uicurs INSENSITIVE CURSOR
				FOR
				SELECT ui_sysid,
					upper(ui_name),
					ui_descr,
					ui_type,
					ui_format,
					caption_alignment,
					trail_bar,
					tab_height,
					isnull(state_processing, 'No'),
					isnull(callout_type, 'None'),
					isnull(TabPosition, 'Top'),
					isnull(PostLaunchTask, 'No') -- added By Feroz for extjs -- PNR2.0_1790
					,
					isnull(HideIlbotitlemenu_req, '')
				FROM ep_published_ui_mst(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_req_no
					AND component_name = @engg_component
					AND activity_name = @activity_name
					AND ui_descr = isnull(@engg_ui_descr_in, ui_descr)
				ORDER BY ui_name
			END
			ELSE
			BEGIN
				DECLARE uicurs INSENSITIVE CURSOR
				FOR
				SELECT ui_sysid,
					upper(ui_name),
					ui_descr,
					ui_type,
					ui_format,
					caption_alignment,
					trail_bar,
					tab_height,
					isnull(state_processing, 'No'),
					isnull(callout_type, 'None'),
					isnull(TabPosition, 'Top'),
					isnull(PostLaunchTask, 'No') -- added By Feroz for extjs -- PNR2.0_1790
					,
					isnull(HideIlbotitlemenu_req, '')
				FROM ep_ui_mst(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND component_name = @engg_component
					AND activity_name = @activity_name
					AND ui_descr = isnull(@engg_ui_descr_in, ui_descr)
				ORDER BY ui_name
			END
		END

		OPEN uicurs

		-- For each UI generate entries
		WHILE (1 = 1)
		BEGIN
			FETCH NEXT
			FROM uicurs
			INTO @ui_sysid_tmp,
				@ui_name_tmp,
				@engg_ui_descr_tmp,
				@ui_type_tmp,
				@ui_format_tmp,
				@caption_alignment_tmp,
				@trail_bar_tmp,
				@tab_height_tmp,
				@StateEnabled,
				@callout_type,
				@tabposition,
				@postlaunchtask,
				@Ilbotitlereq -- added By Feroz for extjs -- PNR2.0_1790

			IF @@fetch_status <> 0
				BREAK

			SELECT @cntincr_tmp = 0,
				@tab_seq_tmp = 0

			-- code modified by Ganesh for the bugid :: PNR2.0_2882
			SELECT @rtuitype = CASE @ui_type_tmp
					WHEN 'EntryPoint'
						THEN 1
					WHEN 'Main'
						THEN 2
					WHEN 'Modify'
						THEN 3
					WHEN 'MainModify'
						THEN 4
					WHEN 'MainView'
						THEN 5
					WHEN 'Others'
						THEN 6
					WHEN 'Security'
						THEN 7
					WHEN 'View'
						THEN 8
					WHEN 'Snapshot'
						THEN 9
					WHEN 'Help'
						THEN 6
					WHEN 'Search'
						THEN 1
					ELSE 6
					END

			-- Insert UI Entry
			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			--   if @engg_att_ui_format_in = 'Controls Beside Captions'
			--Code commented for the Bug ID: PNR2.0_33145 starts
			--if @engg_att_ui_format = 'Controls Beside Captions'
			-- select  @ui_format_tmp = 'BES'
			--else
			-- select @ui_format_tmp = 'UND'
			--Code commented for the Bug ID: PNR2.0_33145 ends
			-- Added By Feroz for Extjs Start -- PNR2.0_1790
			IF @callout_type IN (
					'Client',
					'Both'
					)
				SELECT @callout_type = 'Y'
			ELSE
				SELECT @callout_type = 'N'

			-- Added By Feroz for Extjs End -- PNR2.0_1790
			IF @StateEnabled = 'YES'
				SELECT @StateEnabled = 'Y'
			ELSE
				SELECT @StateEnabled = 'N'

			SELECT @engg_ui_descr_tmp = bt_synonym_caption
			FROM @ep_component_glossary_mst
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = 'Base'
				AND process_name = @process_name
				AND component_name = @engg_component
				AND bt_synonym_name = @ui_name_tmp
				----AND languageid = @language_code

			SELECT @engg_ui_descr_tmp = replace(@engg_ui_descr_tmp, '&', '&amp;')

			SELECT @engg_ui_descr_tmp = replace(@engg_ui_descr_tmp, '<', '&lt;')

			SELECT @engg_ui_descr_tmp = replace(@engg_ui_descr_tmp, '>', '&gt;')

			SELECT @engg_ui_descr_tmp = replace(@engg_ui_descr_tmp, '"', '&quot;')

			-- code modified by Anuradha M on 25-Apr-2006 for the Bug id :: PNR2.0_7964 -- Start
			-- code added by Ganesh for callid PNR2.0_4395 on 26/10/05
			--code Modified for bugId : PNR2.0_13438
			DECLARE @temp_tab_index1 TABLE (
				ui_name VARCHAR(60),
				page_bt_synonym VARCHAR(60),
				control_bt_synonym VARCHAR(60),
				parent_sec_h INT,
				parent_sec_v INT,
				sec_h INT,
				sec_v INT,
				horder INT,
				vorder INT,
				order_seq INT,
				count VARCHAR(60),
				basectrl VARCHAR(60),
				tab_index INT identity(1, 1)
				)

			-- code modified by Ganesh for PNR2.0_4658 on 16th Nov 2005
			IF @pubflag = 'C' -- code added by gopinath S for the Bug ID PNR2.0_19995
				--  if @engg_req_no = 'Base'
			BEGIN
				-- Code added for PNR2.0_21450 on 13-Mar-2009 - Begins
				INSERT INTO @temp_tab_index1 (
					ui_name,
					page_bt_synonym,
					control_bt_synonym,
					parent_sec_h,
					parent_sec_v,
					sec_h,
					sec_v,
					horder,
					vorder,
					order_seq,
					count,
					basectrl
					)
				SELECT a.ui_name,
					a.page_bt_synonym,
					a.control_bt_synonym,
					d.horder 'parent_sec_h',
					d.vorder 'parent_sec_v',
					b.horder 'sec_h',
					b.vorder 'sec_v',
					a.horder,
					a.vorder,
					order_seq,
					CASE a.page_bt_synonym
						WHEN '[mainscreen]'
							THEN 1
						ELSE 2
						END 'count',
					c.base_ctrl_type
				FROM ep_ui_control_dtl a(NOLOCK),
					es_comp_ctrl_type_mst c(NOLOCK),
					ep_ui_section_dtl b(NOLOCK)
				LEFT JOIN ep_ui_section_dtl d(NOLOCK) ON b.customer_name = d.customer_name
					AND b.project_name = d.project_name
					AND b.req_no = d.req_no
					AND b.process_name = d.process_name
					AND b.component_name = d.component_name
					AND b.ui_name = d.ui_name
					AND b.page_bt_synonym = d.page_bt_synonym
					AND b.parent_section = d.section_bt_synonym
				WHERE a.customer_name = b.customer_name
					AND a.project_name = b.project_name
					AND a.req_no = b.req_no
					AND a.process_name = b.process_name
					AND a.component_name = b.component_name
					AND a.activity_name = b.activity_name
					AND a.ui_name = b.ui_name
					AND a.page_bt_synonym = b.page_bt_synonym
					AND a.section_bt_synonym = b.section_bt_synonym
					AND c.customer_name = a.customer_name
					AND c.project_name = a.project_name
					AND c.req_no = a.req_no
					AND c.process_name = a.process_name
					AND c.component_name = a.component_name
					AND c.ctrl_type_name = a.control_type
					AND (
						editable_flag = 'Y'
						OR
						-- Code modification  for  PNR2.0_22481  starts
						base_ctrl_type IN (
							'CheckBox',
							'Button',
							'Combo',
							'RadioButton',
							'DataHyperLink',
							'Link',
							'grid'
							)
						)
					--and base_ctrl_type  <> 'Grid'
					-- Code modification  for  PNR2.0_22481  ends
					AND c.visisble_flag = 'Y'
					AND b.visisble_flag = 'Y'
					AND a.control_type NOT IN (
						'filler',
						'filler2'
						)
					AND a.customer_name = @engg_customer_name
					AND a.project_name = @engg_project_name
					AND a.req_no = 'Base'
					AND a.process_name = @process_name
					AND a.component_name = @engg_component
					AND a.activity_name = @activity_name
					AND a.ui_name = @ui_name_tmp
					AND isnull(a.tab_seq, '') <> ''
				ORDER BY a.tab_seq,
					'count',
					a.page_bt_synonym,
					'parent_sec_h',
					'parent_sec_v',
					'sec_h',
					'sec_v',
					a.horder,
					a.vorder,
					order_seq

				-- Code added for PNR2.0_21450 on 13-Mar-2009 - Ends
				INSERT INTO @temp_tab_index1 (
					ui_name,
					page_bt_synonym,
					control_bt_synonym,
					parent_sec_h,
					parent_sec_v,
					sec_h,
					sec_v,
					horder,
					vorder,
					order_seq,
					count,
					basectrl
					)
				SELECT a.ui_name,
					a.page_bt_synonym,
					a.control_bt_synonym,
					d.horder 'parent_sec_h',
					d.vorder 'parent_sec_v',
					b.horder 'sec_h',
					b.vorder 'sec_v',
					a.horder,
					a.vorder,
					order_seq,
					CASE a.page_bt_synonym
						WHEN '[mainscreen]'
							THEN 1
						ELSE 2
						END 'count',
					c.base_ctrl_type
				FROM ep_ui_control_dtl a(NOLOCK),
					es_comp_ctrl_type_mst c(NOLOCK),
					ep_ui_section_dtl b(NOLOCK)
				LEFT JOIN ep_ui_section_dtl d(NOLOCK) ON b.customer_name = d.customer_name
					AND b.project_name = d.project_name
					AND b.req_no = d.req_no
					AND b.process_name = d.process_name
					AND b.component_name = d.component_name
					AND b.ui_name = d.ui_name
					AND b.page_bt_synonym = d.page_bt_synonym
					AND b.parent_section = d.section_bt_synonym
				WHERE a.customer_name = b.customer_name
					AND a.project_name = b.project_name
					AND a.req_no = b.req_no
					AND a.process_name = b.process_name
					AND a.component_name = b.component_name
					AND a.activity_name = b.activity_name
					AND a.ui_name = b.ui_name
					AND a.page_bt_synonym = b.page_bt_synonym
					AND a.section_bt_synonym = b.section_bt_synonym
					AND c.customer_name = a.customer_name
					AND c.project_name = a.project_name
					AND c.req_no = a.req_no
					AND c.process_name = a.process_name
					AND c.component_name = a.component_name
					AND c.ctrl_type_name = a.control_type
					AND (
						editable_flag = 'Y'
						OR
						-- Code modification  for  PNR2.0_22481  starts
						base_ctrl_type IN (
							'CheckBox',
							'Button',
							'Combo',
							'RadioButton',
							'DataHyperLink',
							'Link',
							'grid'
							)
						)
					--and base_ctrl_type  <> 'Grid'
					-- Code modification  for  PNR2.0_22481  ends
					-- code modified by Ganesh for the callid :: PNR2.0_4412 on 26/10/05
					AND c.visisble_flag = 'Y'
					AND b.visisble_flag = 'Y'
					AND a.control_type NOT IN (
						'filler',
						'filler2'
						) -- code modified by Gopinath S for the Bug ID PNR2.0_19995
					AND a.customer_name = @engg_customer_name
					AND a.project_name = @engg_project_name
					AND a.req_no = 'Base' -- code added by Gopinath S for the Bug ID PNR2.0_19995
					AND a.process_name = @process_name
					AND a.component_name = @engg_component
					AND a.activity_name = @activity_name
					AND a.ui_name = @ui_name_tmp
					-- Code added for PNR2.0_21450 on 13-Mar-2009 - Begins
					AND isnull(a.tab_seq, '') = ''
				-- Code added for PNR2.0_21450 on 13-Mar-2009 - Ends
				--    and a.req_no   = @engg_req_no
				-- --    and   b.customer_name  *= d.customer_name
				-- --    and b.project_name  *= d.project_name
				-- --    and b.process_name  *= d.process_name
				-- --    and b.component_name *= d.component_name
				-- --    and b.ui_name  *= d.ui_name
				-- --    and b.page_bt_synonym *= d.page_bt_synonym
				-- --    and b.parent_section *= d.section_bt_synonym
				--code Commented for bugId : PNR2.0_13541
				--    union
				--    select a.ui_name,
				--     a.page_bt_synonym,
				--     d.column_bt_synonym,
				--     e.horder 'parent_sec_h',
				--     e.vorder 'parent_sec_v',
				--     b.horder 'sec_h',
				--     b.vorder 'sec_v',
				--     a.horder,
				--     a.vorder,
				--     order_seq,
				--     case a.page_bt_synonym
				--     when '[mainscreen]' then 1
				--     else 2
				--     end 'count',
				--     c.base_ctrl_type
				--    from ep_ui_control_dtl   a (nolock),
				--     es_comp_ctrl_type_mst   c (nolock),
				--     ep_ui_grid_dtl    d (nolock),
				--     ep_ui_section_dtl   b (nolock) left outer join
				--     ep_ui_section_dtl   e (nolock)
				--    on b.customer_name  = e.customer_name
				--    and b.project_name  = e.project_name
				--    and b.process_name  = e.process_name
				--    and b.component_name = e.component_name
				--    and b.ui_name  = e.ui_name
				--    and b.page_bt_synonym = e.page_bt_synonym
				--    and b.parent_section = e.section_bt_synonym
				--
				--    where a.customer_name  = b.customer_name
				--    and a.project_name  = b.project_name
				--    and a.process_name  = b.process_name
				--    and a.component_name = b.component_name
				--    and a.ui_name  = b.ui_name
				--    and a.activity_name  = b.activity_name
				--    and a.page_bt_synonym = b.page_bt_synonym
				--    and a.section_bt_synonym = b.section_bt_synonym
				--
				--    and d.customer_name  = a.customer_name
				--    and d.project_name  = a.project_name
				--    and d.process_name  = a.process_name
				-- and d.component_name = a.component_name
				--    and d.ui_name  = a.ui_name
				--    and d.activity_name  = a.activity_name
				--    and d.ui_name  = a.ui_name
				--    and d.page_bt_synonym = a.page_bt_synonym
				--    and d.section_bt_synonym = a.section_bt_synonym
				--    and d.control_bt_synonym = a.control_bt_synonym
				--
				--    and c.customer_name  = d.customer_name
				--    and c.project_name  = d.project_name
				--    and c.process_name  = d.process_name
				--    and c.component_name = d.component_name
				--    and c.ctrl_type_name = d.column_type
				--    and editable_flag  = 'Y'
				--    and c.visisble_flag  = 'Y'
				--    and b.visisble_flag  = 'Y'
				--
				--    and a.customer_name  = @engg_customer_name
				--    and a.project_name  = @engg_project_name
				--    and a.process_name  = @process_name
				--    and a.component_name = @engg_component
				--    and a.activity_name  = @activity_name
				--    and a.ui_name  = @ui_name_tmp
				--    and a.req_no  = @engg_req_no
				--    and   b.customer_name  *= e.customer_name
				--    and b.project_name  *= e.project_name
				--    and b.process_name  *= e.process_name
				--    and b.component_name *= e.component_name
				--    and b.ui_name  *= e.ui_name
				--    and b.page_bt_synonym *= e.page_bt_synonym
				--    and b.parent_section *= e.section_bt_synonym
				ORDER BY 'count',
					a.page_bt_synonym,
					'parent_sec_h',
					'parent_sec_v',
					'sec_h',
					'sec_v',
					a.horder,
					a.vorder,
					order_seq
			END
			ELSE
			BEGIN
				-- Code added for PNR2.0_21450 on 13-Mar-2009 - Begins
				INSERT INTO @temp_tab_index1 (
					ui_name,
					page_bt_synonym,
					control_bt_synonym,
					parent_sec_h,
					parent_sec_v,
					sec_h,
					sec_v,
					horder,
					vorder,
					order_seq,
					count,
					basectrl
					)
				SELECT a.ui_name,
					a.page_bt_synonym,
					a.control_bt_synonym,
					d.horder 'parent_sec_h',
					d.vorder 'parent_sec_v',
					b.horder 'sec_h',
					b.vorder 'sec_v',
					a.horder,
					a.vorder,
					order_seq,
					CASE a.page_bt_synonym
						WHEN '[mainscreen]'
							THEN 1
						ELSE 2
						END 'count',
					c.base_ctrl_type
				FROM ep_published_ui_control_dtl a(NOLOCK),
					es_comp_ctrl_type_mst c(NOLOCK),
					ep_published_ui_section_dtl b(NOLOCK)
				LEFT JOIN ep_published_ui_section_dtl d(NOLOCK) ON b.customer_name = d.customer_name
					AND b.project_name = d.project_name
					AND b.req_no = d.req_no
					AND b.process_name = d.process_name
					AND b.component_name = d.component_name
					AND b.ui_name = d.ui_name
					AND b.page_bt_synonym = d.page_bt_synonym
					AND b.parent_section = d.section_bt_synonym
				WHERE a.customer_name = b.customer_name
					AND a.project_name = b.project_name
					AND a.req_no = b.req_no
					AND a.process_name = b.process_name
					AND a.component_name = b.component_name
					AND a.activity_name = b.activity_name
					AND a.ui_name = b.ui_name
					AND a.page_bt_synonym = b.page_bt_synonym
					AND a.section_bt_synonym = b.section_bt_synonym
					AND c.customer_name = a.customer_name
					AND c.project_name = a.project_name
					AND c.process_name = a.process_name
					AND c.component_name = a.component_name
					AND c.ctrl_type_name = a.control_type
					AND (
						editable_flag = 'Y'
						OR
						-- Code modification  for  PNR2.0_22481  starts
						base_ctrl_type IN (
							'CheckBox',
							'Button',
							'Combo',
							'RadioButton',
							'DataHyperLink',
							'Link',
							'grid'
							)
						)
					--   and  base_ctrl_type  <> 'Grid'
					-- Code modification  for  PNR2.0_22481  ends
					AND c.visisble_flag = 'Y'
					AND b.visisble_flag = 'Y'
					AND a.control_type NOT IN (
						'filler',
						'filler2'
						)
					AND a.customer_name = @engg_customer_name
					AND a.project_name = @engg_project_name
					AND a.req_no = @engg_req_no
					AND a.process_name = @process_name
					AND a.component_name = @engg_component
					AND a.activity_name = @activity_name
					AND a.ui_name = @ui_name_tmp
					AND isnull(a.tab_seq, '') <> ''
				ORDER BY 'count',
					a.page_bt_synonym,
					'parent_sec_h',
					'parent_sec_v',
					'sec_h',
					'sec_v',
					a.horder,
					a.vorder,
					order_seq

				-- Code added for PNR2.0_21450 on 13-Mar-2009 - Ends
				INSERT INTO @temp_tab_index1 (
					ui_name,
					page_bt_synonym,
					control_bt_synonym,
					parent_sec_h,
					parent_sec_v,
					sec_h,
					sec_v,
					horder,
					vorder,
					order_seq,
					count,
					basectrl
					)
				SELECT a.ui_name,
					a.page_bt_synonym,
					a.control_bt_synonym,
					d.horder 'parent_sec_h',
					d.vorder 'parent_sec_v',
					b.horder 'sec_h',
					b.vorder 'sec_v',
					a.horder,
					a.vorder,
					order_seq,
					CASE a.page_bt_synonym
						WHEN '[mainscreen]'
							THEN 1
						ELSE 2
						END 'count',
					c.base_ctrl_type
				FROM ep_published_ui_control_dtl a(NOLOCK),
					es_comp_ctrl_type_mst c(NOLOCK),
					ep_published_ui_section_dtl b(NOLOCK)
				LEFT JOIN ep_published_ui_section_dtl d(NOLOCK) ON b.customer_name = d.customer_name
					AND b.project_name = d.project_name
					AND b.req_no = d.req_no
					AND b.process_name = d.process_name
					AND b.component_name = d.component_name
					AND b.ui_name = d.ui_name
					AND b.page_bt_synonym = d.page_bt_synonym
					AND b.parent_section = d.section_bt_synonym
				WHERE a.customer_name = b.customer_name
					AND a.project_name = b.project_name
					AND a.req_no = b.req_no
					AND a.process_name = b.process_name
					AND a.component_name = b.component_name
					AND a.activity_name = b.activity_name
					AND a.ui_name = b.ui_name
					AND a.page_bt_synonym = b.page_bt_synonym
					AND a.section_bt_synonym = b.section_bt_synonym
					AND c.customer_name = a.customer_name
					AND c.project_name = a.project_name
					AND c.process_name = a.process_name
					AND c.component_name = a.component_name
					AND c.ctrl_type_name = a.control_type
					AND (
						editable_flag = 'Y'
						OR
						-- Code modification  for  PNR2.0_22481  starts
						base_ctrl_type IN (
							'CheckBox',
							'Button',
							'Combo',
							'RadioButton',
							'DataHyperLink',
							'Link',
							'grid'
							)
						)
					--   and  base_ctrl_type  <> 'Grid'
					-- Code modification  for  PNR2.0_22481  ends
					-- code modified by Ganesh for the callid :: PNR2.0_4412 on 26/10/05
					AND c.visisble_flag = 'Y'
					AND b.visisble_flag = 'Y'
					AND a.control_type NOT IN (
						'filler',
						'filler2'
						) -- code modified by Gopinath S for the Bug ID PNR2.0_19995
					AND a.customer_name = @engg_customer_name
					AND a.project_name = @engg_project_name
					AND a.req_no = @engg_req_no
					AND a.process_name = @process_name
					AND a.component_name = @engg_component
					AND a.activity_name = @activity_name
					AND a.ui_name = @ui_name_tmp
					-- Code added for PNR2.0_21450 on 13-Mar-2009 - Begins
					AND isnull(a.tab_seq, '') = ''
				-- Code added for PNR2.0_21450 on 13-Mar-2009 - Ends
				--    and   b.customer_name  *= d.customer_name
				--    and b.project_name  *= d.project_name
				--    and b.process_name  *= d.process_name
				--    and b.component_name *= d.component_name
				--    and b.ui_name  *= d.ui_name
				--    and b.page_bt_synonym *= d.page_bt_synonym
				--    and b.parent_section *= d.section_bt_synonym
				--    and b.req_no  *= d.req_no
				--code Commented for bugId : PNR2.0_13541
				--    union
				--    select a.ui_name,
				--     a.page_bt_synonym,
				--     d.column_bt_synonym,
				--     e.horder 'parent_sec_h',
				--     e.vorder 'parent_sec_v',
				--     b.horder 'sec_h',
				--     b.vorder 'sec_v',
				--     a.horder,
				--     a.vorder,
				--     order_seq,
				--     case a.page_bt_synonym
				--     when '[mainscreen]' then 1
				--     else 2
				--     end 'count',
				--     c.base_ctrl_type
				--    from ep_published_ui_control_dtl  a (nolock),
				--      es_comp_ctrl_type_mst    c (nolock),
				--      ep_published_ui_grid_dtl   d (nolock),
				--      ep_published_ui_section_dtl  b (nolock) left outer join
				--      ep_published_ui_section_dtl  e (nolock)
				--    on   b.customer_name  = e.customer_name
				--    and  b.project_name  = e.project_name
				--    and  b.process_name  = e.process_name
				--    and  b.component_name = e.component_name
				--    and  b.ui_name   = e.ui_name
				--    and  b.page_bt_synonym = e.page_bt_synonym
				--    and  b.parent_section = e.section_bt_synonym
				--    and  b.req_no   = e.req_no
				--
				--  where a.customer_name  = b.customer_name
				--    and  a.project_name  = b.project_name
				--    and  a.process_name  = b.process_name
				--    and  a.component_name = b.component_name
				--    and  a.ui_name   = b.ui_name
				--    and  a.activity_name  = b.activity_name
				--    and  a.page_bt_synonym = b.page_bt_synonym
				--    and  a.section_bt_synonym = b.section_bt_synonym
				--    and  a.req_no   = b.req_no
				--
				--    and  d.customer_name  = a.customer_name
				--    and  d.project_name  = a.project_name
				--    and  d.process_name  = a.process_name
				--    and  d.component_name = a.component_name
				--    and  d.ui_name   = a.ui_name
				--    and  d.activity_name  = a.activity_name
				--    and  d.ui_name   = a.ui_name
				--    and  d.page_bt_synonym = a.page_bt_synonym
				--    and  d.section_bt_synonym = a.section_bt_synonym
				--    and  d.control_bt_synonym = a.control_bt_synonym
				--    and  d.req_no   = a.req_no
				--    and  c.customer_name  = d.customer_name
				--    and  c.project_name  = d.project_name
				--    and  c.process_name  = d.process_name
				--    and  c.component_name = d.component_name
				--    and  c.ctrl_type_name = d.column_type
				--    and  editable_flag  = 'Y'
				--    and  c.visisble_flag  = 'Y'
				--    and  b.visisble_flag  = 'Y'
				--    and  a.customer_name  = @engg_customer_name
				--    and  a.project_name  = @engg_project_name
				--    and  a.process_name  = @process_name
				--    and  a.component_name = @engg_component
				--    and  a.activity_name  = @activity_name
				--    and  a.ui_name   = @ui_name_tmp
				--    and  a.req_no   = @engg_req_no
				--
				--    and   b.customer_name  *= e.customer_name
				--    and b.project_name  *= e.project_name
				--    and b.process_name  *= e.process_name
				--    and b.component_name *= e.component_name
				--    and b.ui_name  *= e.ui_name
				--    and b.page_bt_synonym *= e.page_bt_synonym
				--    and b.parent_section *= e.section_bt_synonym
				--    and b.req_no  *= e.req_no
				ORDER BY 'count',
					a.page_bt_synonym,
					'parent_sec_h',
					'parent_sec_v',
					'sec_h',
					'sec_v',
					a.horder,
					a.vorder,
					order_seq
			END

			-- code modified by Anuradha M on 25-Apr-2006 for the Bug id :: PNR2.0_7964 -- end
			DELETE
			FROM @temp_tab_index1
			WHERE tab_index < (
					SELECT TOP 1 tab_index
					FROM @temp_tab_index1
					-- Code modification  for  PNR2.0_22481  starts
					WHERE basectrl NOT IN (
							'link',
							'DataHyperLink',
							'Button',
							'grid'
							)
					-- Code modification  for  PNR2.0_22481  ends
					ORDER BY tab_index
					)

			DECLARE @temp_tab_index TABLE (
				ui_name VARCHAR(60),
				page_bt_synonym VARCHAR(60),
				control_bt_synonym VARCHAR(60),
				parent_sec_h INT,
				parent_sec_v INT,
				sec_h INT,
				sec_v INT,
				horder INT,
				vorder INT,
				order_seq INT,
				count VARCHAR(60),
				basectrl VARCHAR(60),
				tab_index INT identity(1, 1)
				)

			IF @devicetype = 'P'
			BEGIN
				SELECT @IsPhone = 'Y',
					@IsTablet = 'N'
			END

			IF @devicetype = 'T'
			BEGIN
				SELECT @IsPhone = 'N',
					@IsTablet = 'Y'
			END

			IF @devicetype = 'B'
			BEGIN
				SELECT @IsPhone = 'Y',
					@IsTablet = 'Y'
			END

			--- 11537 starts
			DECLARE @page_mappedtask engg_name
			DECLARE @page_mapptasktype engg_name

			SELECT @page_mappedtask = ''

			SELECT @page_mapptasktype = ''

			SELECT @page_mappedtask = isnull(upper(Task_Onclick), '')
			FROM ep_ui_pageevents_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND component_name = @engg_component
				AND activity_name = @activity_name
				AND ui_name = @ui_name_tmp
				AND page_bt_synonym = @page_bt_synonym_tmp

			SELECT @page_mapptasktype = isnull(upper(task_type), '')
			FROM ep_action_mst (NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND component_name = @engg_component
				AND activity_name = @activity_name
				AND ui_name = @ui_name_tmp
				AND page_bt_synonym = @page_bt_synonym_tmp
				AND task_name = @page_mappedtask

			IF isnull(@page_mapptasktype, '') = ''
				AND isnull(@page_mappedtask, '') <> ''
				SELECT @page_mapptasktype = 'Trans'

			--- 11537 Ends
			INSERT INTO @temp_tab_index (
				ui_name,
				page_bt_synonym,
				control_bt_synonym,
				parent_sec_h,
				parent_sec_v,
				sec_h,
				sec_v,
				horder,
				vorder,
				order_seq,
				count,
				basectrl
				)
			SELECT ui_name,
				page_bt_synonym,
				control_bt_synonym,
				parent_sec_h,
				parent_sec_v,
				sec_h,
				sec_v,
				horder,
				vorder,
				order_seq,
				count,
				basectrl
			FROM @temp_tab_index1

			SELECT @ocx_Name = @ui_name_tmp + '.OCX'

			SELECT @progid = @ui_name_tmp + '.main_scr'

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'<ILBO Name="' + isnull(ltrim(rtrim(@ui_name_tmp)), '') + '" ' + 'ILBODescription="' + isnull(ltrim(rtrim(@engg_ui_descr_tmp)), '') + '" ' + 'ActivityName="' + isnull(ltrim(rtrim(@activity_name)), '') + '" ' + 'ComponentName="' + isnull(ltrim(rtrim(@engg_component)), '') + '" ' + 'UIType="' + isnull(ltrim(rtrim(@ui_type_tmp)), '') + '" ' + 'UIFormat="' + isnull(ltrim(rtrim(@ui_format_tmp)), '') + '" ' + 'TrailBar="' + isnull(ltrim(rtrim(@engg_att_ui_trail_bar_in)), '') + '" ' + 'StyleSheet="' + isnull
(ltrim(rtrim(@engg_stylesheet)), 'RSGlobalStyles') + '" ' + 'CaptionAlignment="' + isnull(ltrim(rtrim(@engg_att_ui_cap_align_in)), '') + '" ' + 'SmartSpan="' + isnull(ltrim(rtrim(@engg_smartspan)), '') + '" ' + 'TabHeight="' + isnull(ltrim(rtrim(CONVERT(VARCHAR, @tab_height_tmp))), 400) + '" ' + 'OCX_Name="' + isnull(ltrim(rtrim(@ocx_Name)), '') + '" ' + 'progid="' + isnull(ltrim(rtrim(@progid)), '') + '" ' + 'StateEnabled="' + isnull(ltrim(rtrim(@StateEnabled)), '') + '" ' + 'FillerClass="' + isnull(ltrim(rtrim(@FillerClass)), '') + '" ' + --Code Added For Bug_id PNR2.0_17856
				'BaseCallOut="' + isnull(ltrim(rtrim(@callout_type)), 'N') + '" ' + -- Added by Feroz for extjs -- PNR2.0_1790
				'RTUITYPE="' + isnull(ltrim(rtrim(@rtuitype)), '') + '" ' + 'GridColLength="' + isnull(ltrim(rtrim(@gridcollength)), '') + '" ' + /*Modification made by Sangeetha G for Bug id : PNR2.0_33378*/
				'EnableFiller="' + isnull(ltrim(rtrim(@enablefiller)), 'No') + '" ' + --Code Added For Bug_id: PNR2.0_31178
				'TabPosition="' + isnull(ltrim(rtrim(@tabposition)), 'Top') + '" ' + 'SmartHide="' + isnull(ltrim(rtrim(@SmartHide)), 'N') + '" ' + 'HideIlboTitleMenu="' + isnull(ltrim(rtrim(@Ilbotitlereq)), '') + '" ' + 'hdrpersonalization="' + isnull(ltrim(rtrim(@personalization)), 'N') + '" ' + 'Exclude_Systemtabindex="' + isnull(ltrim(rtrim(@Exclude_Systemtabindex)), '') + '" ' + 'Hide_Print="' + isnull(ltrim(rtrim(@Hide_Print)), '') + '" ' + 'IsDesktop="' + isnull(ltrim(rtrim(@IsDesktop)), '') + '" ' + 'IsPhone=
"' + isnull(ltrim(rtrim(@IsPhone)), '') + '" ' + 'IsTablet="' + isnull(ltrim(rtrim(@IsTablet)), '') + '" ' + 'UILayout="' + isnull(ltrim(rtrim(@UiLayout)), '') + '" ' + 'XYCoordinates="' + ltrim(rtrim(isnull(@XYCoordinates, ''))) + '" ' + 'ColumnLayWidth=
"' + ltrim(rtrim(isnull(@ColumnLayWidth, ''))) + '" ' + 'PostLaunchTask="' + isnull(ltrim(rtrim(@PostLaunchTask)), 'No') + '" ' +
				'IsGQL="'    + isnull(ltrim(rtrim(@IsGQL)),'No') + '" ' +	--	TECH-64197
				'TitlebarSearch="'    + isnull(ltrim(rtrim(@titlebar_Search)),'No') + '" ' +
				'Sidebar="'    + isnull(ltrim(rtrim(@Sidebar)),'N') + '" ' +			--TECH-70687
				'UISubType="'    + isnull(ltrim(rtrim(@uisubtype)),'') + '">',
				@xml_seq_tmp
				)

			-- Insert Base Entry for Pages
			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'<Pages>',
				@xml_seq_tmp
				)

			--  Code Modification  for  PNR2.0_18516 starts
			IF @ctxt_service_in IN ('BulkGenerate')
				AND @pubflag = 'P'
			BEGIN
				DECLARE pagecurs INSENSITIVE CURSOR
				FOR
				SELECT upper(page_bt_synonym),
					isnull(bt_synonym_caption, page_bt_synonym),
					horder,
					vorder,
					page_prefix,
					pg.PageClass,
					pg.page_Type,
					pg.pageimage,
					width -- Column added for the BugID PNR2.0_1790,PLF2.0_00961 --PLF2.0_04721
					,
					isnull(HeaderPosition, ''),
					isnull(TabRotation, ''),
					isnull(TabTitleStyle, ''),
					isnull(TabIconPosition, ''),
					isnull(PageLayout, ''),
					isnull(XYCoordinates, ''),
					isnull(ColumnLayWidth, '')
				FROM ep_published_ui_page_dtl pg(NOLOCK),
					@ep_published_comp_glossary_mst gls
				WHERE pg.customer_name = gls.customer_name
					AND pg.project_name = gls.project_name
					AND pg.req_no = gls.req_no
					AND pg.process_name = gls.process_name
					AND pg.component_name = gls.component_name
					AND pg.page_bt_synonym = gls.bt_synonym_name
					AND pg.customer_name = @engg_customer_name
					AND pg.project_name = @engg_project_name
					AND pg.req_no = @engg_req_no
					AND pg.component_name = @engg_component
					AND pg.activity_name = @activity_name
					AND pg.ui_name = @ui_name_tmp
					--AND gls.languageid = @language_code
				
				UNION
				
				SELECT '[MAINSCREEN]',
					'[MAINSCREEN]',
					horder,
					vorder,
					page_prefix,
					pg.PageClass,
					pg.page_Type,
					pg.pageimage,
					width -- Column added for the BugID PNR2.0_1790,PLF2.0_00961 --PLF2.0_04721
					,
					isnull(HeaderPosition, ''),
					isnull(TabRotation, ''),
					isnull(TabTitleStyle, ''),
					isnull(TabIconPosition, ''),
					isnull(PageLayout, ''),
					isnull(XYCoordinates, ''),
					isnull(ColumnLayWidth, '')
				FROM ep_published_ui_page_dtl pg(NOLOCK)
				WHERE pg.customer_name = @engg_customer_name
					AND pg.project_name = @engg_project_name
					AND pg.req_no = @engg_req_no
					AND pg.component_name = @engg_component
					AND pg.activity_name = @activity_name
					AND pg.ui_name = @ui_name_tmp
					AND pg.page_bt_synonym = '[MAINSCREEN]'
				ORDER BY horder,
					vorder
			END
			ELSE
			BEGIN
				DECLARE pagecurs INSENSITIVE CURSOR
				FOR
				SELECT upper(page_bt_synonym),
					isnull(bt_synonym_caption, page_bt_synonym),
					horder,
					vorder,
					page_prefix,
					pg.PageClass,
					pg.page_Type,
					pg.pageimage,
					width -- Column added for the BugID PNR2.0_1790,PLF2.0_00961--PLF2.0_04721
					,
					isnull(HeaderPosition, ''),
					isnull(TabRotation, ''),
					isnull(TabTitleStyle, ''),
					isnull(TabIconPosition, ''),
					isnull(PageLayout, ''),
					isnull(XYCoordinates, ''),
					isnull(ColumnLayWidth, '')
				FROM ep_ui_page_dtl pg(NOLOCK),
					@ep_component_glossary_mst gls
				--     where ui_sysid    = @ui_sysid_tmp
				WHERE pg.customer_name = @engg_customer_name
					AND pg.project_name = @engg_project_name
					AND pg.req_no = 'Base'
					AND pg.component_name = @engg_component
					AND pg.activity_name = @activity_name
					AND pg.ui_name = @ui_name_tmp
					AND pg.customer_name = gls.customer_name
					AND pg.project_name = gls.project_name
					AND pg.req_no = gls.req_no
					AND pg.process_name = gls.process_name
					AND pg.component_name = gls.component_name
					AND pg.page_bt_synonym = gls.bt_synonym_name
					AND gls.component_name = @engg_component
					--AND gls.languageid = @language_code
				
				UNION
				
				SELECT '[MAINSCREEN]',
					'[MAINSCREEN]',
					horder,
					vorder,
					page_prefix,
					pg.PageClass,
					pg.page_Type,
					pg.pageimage,
					width --Code added for Bug ID:PLF2.0_00961 --PLF2.0_04721
					,
					isnull(HeaderPosition, ''),
					isnull(TabRotation, ''),
					isnull(TabTitleStyle, ''),
					isnull(TabIconPosition, ''),
					isnull(PageLayout, ''),
					isnull(XYCoordinates, ''),
					isnull(ColumnLayWidth, '')
				FROM ep_ui_page_dtl pg(NOLOCK)
				WHERE pg.customer_name = @engg_customer_name
					AND pg.project_name = @engg_project_name
					AND pg.req_no = 'Base'
					AND pg.component_name = @engg_component
					AND pg.activity_name = @activity_name
					AND pg.ui_name = @ui_name_tmp
					AND pg.page_bt_synonym = '[MAINSCREEN]'
				ORDER BY horder,
					vorder
			END

			OPEN pagecurs

			-- For each Page generate entries
			WHILE (1 = 1)
			BEGIN
				FETCH NEXT
				FROM pagecurs
				INTO @page_bt_synonym_tmp,
					@page_descr_tmp,
					@horder_tmp,
					@vorder_tmp,
					@page_prefix,
					@PageClass,
					@page_type,
					@page_image,
					@width_page -- Column added for the BugID PNR2.0_1790,PLF2.0_00961 --PLF2.0_04721
					,
					@HeaderPosition,
					@TabRotation,
					@TabTitleStyle,
					@TabIconPosition,
					@PageLayout,
					@XYCoordinates,
					@ColumnLayWidth

				IF @@fetch_status <> 0
					BREAK

				SELECT @page_descr_tmp = replace(@page_descr_tmp, '&', '&amp;')

				SELECT @page_descr_tmp = replace(@page_descr_tmp, '<', '&lt;')

				SELECT @page_descr_tmp = replace(@page_descr_tmp, '>', '&gt;')

				SELECT @page_descr_tmp = replace(@page_descr_tmp, '"', '&quot;')

				--Code Modified For BugId : PNR2.0_6595
				-- Insert UI Page Entry
				SELECT @xml_seq_tmp = @xml_seq_tmp + 1

				IF isnull(@PageClass, '') = ''
					SET @PageClass = ''

				IF isnull(@page_type, '') = ''
					SET @page_type = 'Normal'

				INSERT INTO ep_genxml_tmp (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					activity_name,
					guid,
					gen_xml,
					seq_no
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@process_name,
					@engg_component,
					@activity_name,
					@guid,
					'<Page Name="' + ltrim(rtrim(@page_bt_synonym_tmp)) + '" ' + 'PageCaption="' + ltrim(rtrim(@page_descr_tmp)) + '" ' + 'ILBOName="' + ltrim(rtrim(@ui_name_tmp)) + '" ' + 'ActivityName="' + ltrim(rtrim(@activity_name)) + '" ' + 'ComponentName="' + ltrim(rtrim(@engg_component)) + '" ' + 'PagePrefix="' + ltrim(rtrim(@page_prefix)) + '" ' + 'PageClass="' + ltrim(rtrim(@PageClass)) + '" ' + 'PageType="' + ltrim(rtrim(@page_Type)) + '" ' + -- Column added for the BugID PNR2.0_1790
					'HOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, @horder_tmp), 3))) + '" ' + 'VOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, @vorder_tmp), 3))) + '" ' + 'MappedTask="' + ltrim(rtrim(isnull(@page_mappedtask, ''))) + '" ' + 'TaskType="' + ltrim(rtrim(isnull(@page_mapptasktype, ''))) + '" ' +
					--'PageImage="'           +ltrim(rtrim(isnull(@page_image,''))) + '"/>',@xml_seq_tmp) --Code added for Bug ID:PLF2.0_00961 --PLF2.0_04721
					'PageImage="' + ltrim(rtrim(isnull(@page_image, ''))) + '" ' + 'TabTitleStyle="' + ltrim(rtrim(isnull(@TabTitleStyle, ''))) + '" ' + 'TabIconPosition="' + ltrim(rtrim(isnull(@TabIconPosition, ''))) + '" ' + 'PageLayout="' + ltrim(rtrim(isnull(@PageLayout, ''))) + '" ' + 'XYCoordinates="' + ltrim(rtrim(isnull(@XYCoordinates, ''))) + '" ' + 'ColumnLayWidth="' + ltrim(rtrim(isnull(@ColumnLayWidth, ''))) + '" ' + 'Width="' + ltrim(rtrim(isnull(cast(@width_page AS VARCHAR), ''))) + '"/>',
					@xml_seq_tmp
					) --Code added for Bug ID:PLF2.0_04721
			END

			--  Code Modification  for  PNR2.0_18516 ends
			CLOSE pagecurs

			DEALLOCATE pagecurs

			-- Insert Closing entry for Pages
			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'</Pages>',
				@xml_seq_tmp
				)

			--Code added for Bug ID:PLF2.0_00961 starts
			CREATE TABLE #AlignBtn (
				activityname VARCHAR(60),
				ilbocode VARCHAR(60),
				pagename VARCHAR(60),
				sectionname VARCHAR(60),
				control_name VARCHAR(60),
				algnbtn_h INT,
				algnbtn_v INT,
				horder INT,
				vorder INT
				)

			-- Insert Base Entry for Sections
			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'<Sections>',
				@xml_seq_tmp
				)

			-- Getting Max Horder for PRJHDNSECTION
			IF @ctxt_service_in IN ('BulkGenerate')
				AND @pubflag = 'P'
			BEGIN
				SELECT @prjsecrow = isnull(max(horder), 0)
				FROM ep_published_ui_section_dtl sec(NOLOCK),
					@ep_published_comp_glossary_mst gls
				WHERE sec.customer_name = gls.customer_name
					AND sec.project_name = gls.project_name
					AND sec.req_no = gls.req_no
					AND sec.process_name = gls.process_name
					AND sec.component_name = gls.component_name
					AND sec.section_bt_synonym = gls.bt_synonym_name
					AND sec.customer_name = @engg_customer_name
					AND sec.project_name = @engg_project_name
					AND sec.req_no = @engg_req_no
					AND sec.process_name = @process_name
					AND sec.component_name = @engg_component
					AND sec.activity_name = @activity_name
					AND sec.ui_name = @ui_name_tmp
					AND sec.section_bt_synonym <> 'PRJHDNSECTION'
					AND sec.visisble_flag = 'Y' -- Added For Removing Space BUG_ID:PNR2.0_17856
					--AND gls.languageid = @language_code
			END
			ELSE
			BEGIN
				SELECT @prjsecrow = isnull(max(horder), 0)
				FROM ep_ui_section_dtl sec(NOLOCK),
					@ep_component_glossary_mst gls
				WHERE sec.customer_name = gls.customer_name
					AND sec.project_name = gls.project_name
					AND sec.req_no = gls.req_no
					AND sec.process_name = gls.process_name
					AND sec.component_name = gls.component_name
					AND sec.section_bt_synonym = gls.bt_synonym_name
					AND sec.customer_name = @engg_customer_name
					AND sec.project_name = @engg_project_name
					AND sec.req_no = 'Base'
					AND sec.process_name = @process_name
					AND sec.component_name = @engg_component
					AND sec.activity_name = @activity_name
					AND sec.ui_name = @ui_name_tmp
					AND sec.section_bt_synonym <> 'PRJHDNSECTION'
					AND sec.visisble_flag = 'Y' -- Added For Removing Space BUG_ID:PNR2.0_17856
					--AND gls.languageid = @language_code
			END

			IF @ui_type_tmp = 'Help'
			BEGIN
				SELECT @hiddensectrow_tmp = @prjsecrow + 2,
					@oksectionrow_tmp = @prjsecrow + 1
			END
			ELSE
			BEGIN
				SELECT @hiddensectrow_tmp = @prjsecrow + 1
			END

			--code modified for BugId : PNR2.0_8896
			IF @ctxt_service_in IN ('BulkGenerate')
				AND @pubflag = 'P'
			BEGIN
				IF EXISTS (
						SELECT 'x'
						FROM ep_published_ui_section_dtl(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND req_no = @engg_req_no
							AND component_name = @engg_component
							AND activity_name = @activity_name
							AND ui_name = @ui_name_tmp
							AND isnull(parent_section, '') <> ''
						)
				BEGIN
					-- For Generating Section Hierarcy
					EXEC ep_generate_sechierarchy @ctxt_language,
						@ctxt_ouinstance,
						@ctxt_service,
						@ctxt_user,
						@engg_customer_name,
						@engg_project_name,
						@engg_req_no,
						@process_name,
						@engg_component,
						@activity_name,
						@ui_name_tmp,
						@guid,
						@pubflag
				END
			END
			ELSE
			BEGIN
				IF EXISTS (
						SELECT 'x'
						FROM ep_ui_section_dtl(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND component_name = @engg_component
							AND activity_name = @activity_name
							AND ui_name = @ui_name_tmp
							AND isnull(parent_section, '') <> ''
						)
				BEGIN
					-- For Generating Section Hierarcy
					EXEC ep_generate_sechierarchy @ctxt_language,
						@ctxt_ouinstance,
						@ctxt_service,
						@ctxt_user,
						@engg_customer_name,
						@engg_project_name,
						@engg_req_no,
						@process_name,
						@engg_component,
						@activity_name,
						@ui_name_tmp,
						@guid,
						@pubflag
				END
			END

			-- Fetch Sections
			IF @ctxt_service_in IN ('BulkGenerate')
				AND @pubflag = 'P'
			BEGIN
				DECLARE seccurs INSENSITIVE CURSOR
				FOR
				SELECT upper(section_bt_synonym),
					isnull(bt_synonym_caption, section_bt_synonym),
					upper(ltrim(rtrim(visisble_flag))),
					upper(ltrim(rtrim(title_required))),
					upper(ltrim(rtrim(border_required))),
					upper(sec.parent_section),
					sec.horder,
					sec.vorder,
					upper(page_bt_synonym),
					isnull(title_alignment, 'LEFT'),
					upper(SECTION_TYPE),
					isnull(height, 0),
					--Code Modified For BugId : PNR2.0_7273
					isnull(width, 0),
					isnull(Section_height_Scalemode, 'px'),
					isnull(Section_width_Scalemode, 'px'),
					isnull(splitter_pos, '') --PNR2.0_35383,
					--,isnull(isstatic,'N'
					,
					isnull(sec.Associated_Control, ''),
					isnull(NColSpan, ''),
					isnull(NRowSpan, ''), --Code Added For BugId PNR2.0_18564,PNR2.0_35383,PLF2.0_18487	
					CASE 
						WHEN isnull(sec.section_collapsemode, '') = 'Col'
							THEN 'Y'
						WHEN isnull(sec.section_collapsemode, '') = 'Exp'
							THEN 'N'
						ELSE ''
						END,
					isnull(section_collapse, ''),
					isnull(SectionPrefixClass, ''),
					isnull(CarouselNavigation, 'N'),
					isnull(sec.cell_spacing, 0),
					isnull(sec.cell_padding, 0),
					isnull(Region, ''),
					isnull(TitlePosition, ''),
					isnull(CollapseDir, ''),
					isnull(SectionLayout, ''),
					isnull(XYCoordinates, ''),
					isnull(ColumnLayWidth, ''),
					 ISNULL(sec.TitleIcon,'')		--TECH-72114
				FROM ep_published_ui_section_dtl sec(NOLOCK),
					@ep_published_comp_glossary_mst gls
				WHERE sec.customer_name = gls.customer_name
					AND sec.project_name = gls.project_name
					AND sec.req_no = gls.req_no
					AND sec.process_name = gls.process_name
					AND sec.component_name = gls.component_name
					AND sec.section_bt_synonym = gls.bt_synonym_name
					AND sec.customer_name = @engg_customer_name
					AND sec.project_name = @engg_project_name
					AND sec.req_no = @engg_req_no
					AND sec.process_name = @process_name
					AND sec.component_name = @engg_component
					AND sec.activity_name = @activity_name
					AND sec.ui_name = @ui_name_tmp
					--Code Added For Bugid: PNR2.0_4146
					AND (
						sec.visisble_flag = 'Y'
						OR sec.section_type = 'PopUp'
						) --Code added for Bug ID:PLF2.0_00961
					--Code modified For PNR2.0_21234 on 25-Feb-2009 - Starts
					AND sec.section_bt_synonym NOT IN (
						'PRJHDNSECTION',
						'[tabcontrol]'
						) -- <>  'PRJHDNSECTION'
					--Code modified For PNR2.0_21234 on 25-Feb-2009 - Ends
					--AND gls.languageid = @language_code
					AND sec.section_type <> 'tree' --PLF2.0_03715 starts
					--order by sec.horder,sec.vorder
					---Hidden  grid section
				
				UNION
				
				SELECT upper(section_bt_synonym),
					'[TABCONTROL]',
					upper(ltrim(rtrim(visisble_flag))),
					upper(ltrim(rtrim(title_required))),
					upper(ltrim(rtrim(border_required))),
					upper(parent_section),
					horder,
					vorder,
					upper(page_bt_synonym),
					isnull(title_alignment, 'LEFT'),
					upper(SECTION_TYPE),
					isnull(height, 0),
					--Code Modified For BugId : PNR2.0_7273
					isnull(width, 0),
					isnull(Section_height_Scalemode, 'px'),
					isnull(Section_width_Scalemode, 'px'),
					isnull(splitter_pos, '') --PNR2.0_35383
					--,isnull(isstatic,'N')
					,
					isnull(sec.Associated_Control, ''),
					isnull(NColSpan, ''),
					isnull(NRowSpan, '') --Code Added For BugId PNR2.0_18564,PNR2.0_35383,PLF2.0_18487	
					,
					CASE 
						WHEN isnull(sec.section_collapsemode, '') = 'Col'
							THEN 'Y'
						WHEN isnull(sec.section_collapsemode, '') = 'Exp'
							THEN 'N'
						ELSE ''
						END,
					isnull(section_collapse, ''),
					isnull(SectionPrefixClass, ''),
					isnull(CarouselNavigation, 'N'),
					isnull(sec.cell_spacing, 0),
					isnull(sec.cell_padding, 0),
					isnull(Region, ''),
					isnull(TitlePosition, ''),
					isnull(CollapseDir, ''),
					isnull(SectionLayout, ''),
					isnull(XYCoordinates, ''),
					isnull(ColumnLayWidth, ''),
					 ISNULL(sec.TitleIcon,'')		--TECH-72114
				FROM ep_published_ui_section_dtl sec(NOLOCK)
				WHERE sec.customer_name = @engg_customer_name
					AND sec.project_name = @engg_project_name
					AND sec.req_no = @engg_req_no
					AND sec.process_name = @process_name
					AND sec.component_name = @engg_component
					AND sec.activity_name = @activity_name
					AND sec.ui_name = @ui_name_tmp
					AND sec.page_bt_synonym = '[MAINSCREEN]'
					AND sec.section_bt_synonym = '[TABCONTROL]'
				--order by sec.horder,sec.vorder
				
				UNION
				
				SELECT upper(sec.section_bt_synonym),
					isnull(gls.bt_synonym_caption, sec.section_bt_synonym),
					upper(ltrim(rtrim(sec.visisble_flag))),
					upper(ltrim(rtrim(sec.title_required))),
					upper(ltrim(rtrim(sec.border_required))),
					upper(sec.parent_section),
					sec.horder,
					sec.vorder,
					upper(sec.page_bt_synonym),
					isnull(sec.title_alignment, 'LEFT'),
					upper(sec.SECTION_TYPE),
					isnull(sec.height, 0),
					isnull(sec.width, 0),
					isnull(sec.Section_height_Scalemode, 'px'),
					isnull(sec.Section_width_Scalemode, 'px'),
					isnull(sec.splitter_pos, ''),
					isnull(con.control_id, ''),
					isnull(NColSpan, ''),
					isnull(NRowSpan, '') --Code Added For BugId PNR2.0_18564,PNR2.0_35383
					--,isnull(IsStatic,'N')
					,
					CASE 
						WHEN isnull(sec.section_collapsemode, '') = 'Col'
							THEN 'Y'
						WHEN isnull(sec.section_collapsemode, '') = 'Exp'
							THEN 'N'
						ELSE ''
						END,
					isnull(section_collapse, ''),
					isnull(SectionPrefixClass, ''),
					isnull(CarouselNavigation, 'N'),
					isnull(sec.cell_spacing, 0),
					isnull(sec.cell_padding, 0),
					isnull(Region, ''),
					isnull(TitlePosition, ''),
					isnull(CollapseDir, ''),
					isnull(SectionLayout, ''),
					isnull(XYCoordinates, ''),
					isnull(ColumnLayWidth, ''),
					 ISNULL(sec.TitleIcon,'')		--TECH-72114
				FROM ep_published_ui_section_dtl sec(NOLOCK),
					@ep_published_comp_glossary_mst gls,
					ep_published_ui_control_dtl con(NOLOCK)
				WHERE sec.customer_name = gls.customer_name
					AND sec.project_name = gls.project_name
					AND sec.req_no = gls.req_no
					AND sec.process_name = gls.process_name
					AND sec.component_name = gls.component_name
					AND sec.section_bt_synonym = gls.bt_synonym_name
					AND sec.customer_name = @engg_customer_name
					AND sec.project_name = @engg_project_name
					AND sec.req_no = @engg_req_no
					AND sec.component_name = @engg_component
					AND sec.activity_name = @activity_name
					AND sec.ui_name = @ui_name_tmp
					AND sec.section_bt_synonym NOT IN (
						'PRJHDNSECTION',
						'[tabcontrol]'
						)
					AND (
						sec.visisble_flag = 'Y'
						OR sec.section_type = 'PopUp'
						)
					--AND gls.languageid = @language_code
					AND sec.section_type = 'tree'
					AND sec.customer_name = con.customer_name
					AND sec.project_name = con.project_name
					AND sec.req_no = con.req_no
					AND sec.component_name = con.component_name
					AND sec.activity_name = con.activity_name
					AND sec.ui_name = con.ui_name
					AND sec.page_bt_synonym = con.page_bt_synonym
					AND sec.section_bt_synonym = con.section_bt_synonym
				--order by sec.horder,sec.vorder
				--PLF2.0_03715 ends
				-------------Hdn Grid   PLF2.0_18888    
				
				UNION
				
				SELECT upper(sec.section_bt_synonym),
					isnull(gls.bt_synonym_caption, sec.section_bt_synonym),
					upper(ltrim(rtrim(sec.visisble_flag))),
					upper(ltrim(rtrim(sec.title_required))),
					upper(ltrim(rtrim(sec.border_required))),
					upper(sec.parent_section),
					sec.horder,
					sec.vorder,
					upper(sec.page_bt_synonym),
					isnull(sec.title_alignment, 'LEFT'),
					upper(sec.SECTION_TYPE),
					isnull(sec.height, 0),
					isnull(sec.width, 0),
					isnull(sec.Section_height_Scalemode, 'px'),
					isnull(sec.Section_width_Scalemode, 'px'),
					isnull(sec.splitter_pos, ''),
					isnull(sec.Associated_Control, ''),
					isnull(NColSpan, ''),
					isnull(NRowSpan, ''), --Code Added For BugId PNR2.0_18564,PNR2.0_35383,PLF2.0_18487	
					--isnull(sec.IsStatic, 'N'),
					CASE 
						WHEN isnull(sec.section_collapsemode, '') = 'Col'
							THEN 'Y'
						WHEN isnull(sec.section_collapsemode, '') = 'Exp'
							THEN 'N'
						ELSE ''
						END,
					isnull(sec.section_collapse, ''),
					isnull(SectionPrefixClass, ''),
					isnull(CarouselNavigation, 'N'),
					isnull(sec.cell_spacing, 0),
					isnull(sec.cell_padding, 0),
					isnull(Region, ''),
					isnull(TitlePosition, ''),
					isnull(CollapseDir, ''),
					isnull(SectionLayout, ''),
					isnull(XYCoordinates, ''),
					isnull(ColumnLayWidth, ''),
					ISNULL(sec.TitleIcon,'')		--TECH-72114
				FROM ep_published_ui_section_dtl sec(NOLOCK),
					@ep_published_comp_glossary_mst gls,
					ep_published_ui_control_dtl ctrl(NOLOCK),
					es_comp_ctrl_type_mst ctype(NOLOCK)
				WHERE ctrl.customer_name = sec.customer_name
					AND sec.project_name = ctrl.project_name
					AND sec.req_no = ctrl.req_no
					AND sec.process_name = ctrl.process_name
					AND sec.component_name = ctrl.component_name
					AND sec.activity_name = ctrl.activity_name
					AND sec.ui_name = ctrl.ui_name
					AND sec.page_bt_synonym = ctrl.page_bt_synonym
					AND sec.section_bt_synonym = ctrl.section_bt_synonym
					AND ctrl.customer_name = ctype.customer_name
					AND ctrl.project_name = ctype.project_name
					AND ctrl.process_name = ctype.process_name
					AND ctrl.component_name = ctype.component_name
					AND ctrl.control_type = ctype.ctrl_type_name
					AND ctype.base_ctrl_type = 'Grid'
					AND sec.customer_name = gls.customer_name
					AND sec.project_name = gls.project_name
					AND sec.req_no = gls.req_no
					AND sec.process_name = gls.process_name
					AND sec.component_name = gls.component_name
					AND sec.section_bt_synonym = gls.bt_synonym_name
					AND sec.customer_name = @engg_customer_name
					AND sec.project_name = @engg_project_name
					AND sec.req_no = @engg_req_no
					AND sec.component_name = @engg_component
					AND sec.activity_name = @activity_name
					AND sec.ui_name = @ui_name_tmp
					AND sec.section_bt_synonym NOT IN (
						'PRJHDNSECTION',
						'[tabcontrol]'
						)
					AND sec.visisble_flag = 'N'
					--AND gls.languageid = @language_code
					AND sec.section_type <> 'tree'
				ORDER BY sec.horder,
					sec.vorder
			END
			ELSE
			BEGIN
				DECLARE seccurs INSENSITIVE CURSOR
				FOR
				SELECT upper(section_bt_synonym),
					isnull(bt_synonym_caption, section_bt_synonym),
					upper(ltrim(rtrim(visisble_flag))),
					upper(ltrim(rtrim(title_required))),
					upper(ltrim(rtrim(border_required))),
					upper(sec.parent_section),
					horder,
					vorder,
					upper(page_bt_synonym),
					isnull(title_alignment, 'LEFT'),
					upper(SECTION_TYPE),
					isnull(height, 0),
					--Code Modified For BugId : PNR2.0_7273
					isnull(width, 0),
					isnull(Section_height_Scalemode, 'px'),
					isnull(Section_width_Scalemode, 'px'),
					isnull(splitter_pos, '') --PNR2.0_35383
					--,isnull(isstatic,'N')
					,
					isnull(sec.Associated_Control, ''),
					isnull(NColSpan, ''),
					isnull(NRowSpan, '') --Code Added For BugId PNR2.0_18564,PNR2.0_35383,PLF2.0_18487	
					,
					CASE 
						WHEN isnull(sec.section_collapsemode, '') = 'Col'
							THEN 'Y'
						WHEN isnull(sec.section_collapsemode, '') = 'Exp'
							THEN 'N'
						ELSE ''
						END,
					isnull(section_collapse, ''),
					isnull(SectionPrefixClass, ''),
					isnull(CarouselNavigation, 'N'),
					isnull(sec.cell_spacing, 0),
					isnull(sec.cell_padding, 0),
					isnull(Region, ''),
					isnull(TitlePosition, ''),
					isnull(CollapseDir, ''),
					isnull(SectionLayout, ''),
					isnull(XYCoordinates, ''),
					isnull(ColumnLayWidth, ''),
					ISNULL(sec.TitleIcon,'')		--TECH-72114
				FROM ep_ui_section_dtl sec(NOLOCK),
					@ep_component_glossary_mst gls
				WHERE sec.customer_name = gls.customer_name
					AND sec.project_name = gls.project_name
					AND sec.req_no = gls.req_no
					AND sec.process_name = gls.process_name
					AND sec.component_name = gls.component_name
					AND sec.section_bt_synonym = gls.bt_synonym_name
					AND sec.customer_name = @engg_customer_name
					AND sec.project_name = @engg_project_name
					AND sec.req_no = 'Base'
					AND sec.process_name = @process_name
					AND sec.component_name = @engg_component
					AND sec.activity_name = @activity_name
					AND sec.ui_name = @ui_name_tmp
					--Code Added For Bugid: PNR2.0_4146
					AND (
						sec.visisble_flag = 'Y'
						OR sec.section_type = 'PopUp'
						) --Code added for Bug ID:PLF2.0_00961
					AND sec.section_bt_synonym NOT IN (
						'PRJHDNSECTION',
						'[tabcontrol]'
						) -- <>  'PRJHDNSECTION'
					--AND gls.languageid = @language_code
					AND sec.section_type <> 'tree'
				--order by sec.horder,sec.vorder 
				
				UNION
				
				-- code modified by Ganesh for the callid PNR2.0_3840 on 13/9/05
				SELECT upper(section_bt_synonym),
					'[TABCONTROL]',
					upper(ltrim(rtrim(visisble_flag))),
					upper(ltrim(rtrim(title_required))),
					upper(ltrim(rtrim(border_required))),
					upper(parent_section),
					horder,
					vorder,
					upper(page_bt_synonym),
					isnull(title_alignment, 'LEFT'),
					upper(SECTION_TYPE),
					isnull(height, 0),
					--Code Modified For BugId : PNR2.0_7273
					isnull(width, 0),
					isnull(Section_height_Scalemode, 'px'),
					isnull(Section_width_Scalemode, 'px'),
					isnull(splitter_pos, '') --PNR2.0_35383
					--,isnull(isstatic,'N')
					,
					isnull(sec.Associated_Control, ''),
					isnull(NColSpan, ''),
					isnull(NRowSpan, '') --Code Added For BugId PNR2.0_18564,PNR2.0_35383,PLF2.0_18487	
					,
					CASE 
						WHEN isnull(sec.section_collapsemode, '') = 'Col'
							THEN 'Y'
						WHEN isnull(sec.section_collapsemode, '') = 'Exp'
							THEN 'N'
						ELSE ''
						END,
					isnull(section_collapse, ''),
					isnull(SectionPrefixClass, ''),
					isnull(CarouselNavigation, 'N'),
					isnull(sec.cell_spacing, 0),
					isnull(sec.cell_padding, 0),
					isnull(Region, ''),
					isnull(TitlePosition, ''),
					isnull(CollapseDir, ''),
					isnull(SectionLayout, ''),
					isnull(XYCoordinates, ''),
					isnull(ColumnLayWidth, ''),
					ISNULL(sec.TitleIcon,'')		--TECH-72114
				FROM ep_ui_section_dtl sec(NOLOCK)
				WHERE sec.customer_name = @engg_customer_name
					AND sec.project_name = @engg_project_name
					AND sec.req_no = 'Base'
					AND sec.process_name = @process_name
					AND sec.component_name = @engg_component
					AND sec.activity_name = @activity_name
					AND sec.ui_name = @ui_name_tmp
					AND sec.page_bt_synonym = '[MAINSCREEN]'
					AND sec.section_bt_synonym = '[TABCONTROL]'
				--order by sec.horder, sec.vorder
				
				UNION
				
				SELECT upper(sec.section_bt_synonym),
					isnull(gls.bt_synonym_caption, sec.section_bt_synonym),
					upper(ltrim(rtrim(sec.visisble_flag))),
					upper(ltrim(rtrim(sec.title_required))),
					upper(ltrim(rtrim(sec.border_required))),
					upper(sec.parent_section),
					sec.horder,
					sec.vorder,
					upper(sec.page_bt_synonym),
					isnull(sec.title_alignment, 'LEFT'),
					upper(sec.SECTION_TYPE),
					isnull(sec.height, 0),
					isnull(sec.width, 0),
					isnull(sec.Section_height_Scalemode, 'px'),
					isnull(sec.Section_width_Scalemode, 'px'),
					isnull(sec.splitter_pos, ''),
					isnull(con.control_id, ''),
					isnull(NColSpan, ''),
					isnull(NRowSpan, '') --Code Added For BugId PNR2.0_18564,PNR2.0_35383
					--,isnull(IsStatic,'N')
					,
					CASE 
						WHEN isnull(sec.section_collapsemode, '') = 'Col'
							THEN 'Y'
						WHEN isnull(sec.section_collapsemode, '') = 'Exp'
							THEN 'N'
						ELSE ''
						END,
					isnull(section_collapse, ''),
					isnull(SectionPrefixClass, ''),
					isnull(CarouselNavigation, 'N'),
					isnull(sec.cell_spacing, 0),
					isnull(sec.cell_padding, 0),
					isnull(Region, ''),
					isnull(TitlePosition, ''),
					isnull(CollapseDir, ''),
					isnull(SectionLayout, ''),
					isnull(XYCoordinates, ''),
					isnull(ColumnLayWidth, ''),
					ISNULL(sec.TitleIcon,'')		--TECH-72114
				FROM ep_ui_section_dtl sec(NOLOCK),
					@ep_component_glossary_mst gls,
					ep_ui_control_dtl con(NOLOCK)
				WHERE sec.customer_name = gls.customer_name
					AND sec.project_name = gls.project_name
					AND sec.process_name = gls.process_name
					AND sec.component_name = gls.component_name
					AND sec.section_bt_synonym = gls.bt_synonym_name
					AND sec.customer_name = @engg_customer_name
					AND sec.project_name = @engg_project_name
					AND sec.component_name = @engg_component
					AND sec.activity_name = @activity_name
					AND sec.ui_name = @ui_name_tmp
					AND sec.section_bt_synonym NOT IN (
						'PRJHDNSECTION',
						'[tabcontrol]'
						)
					AND (
						sec.visisble_flag = 'Y'
						OR sec.section_type = 'PopUp'
						)
					--AND gls.languageid = @language_code
					AND sec.section_type = 'tree'
					AND sec.customer_name = con.customer_name
					AND sec.project_name = con.project_name
					AND sec.component_name = con.component_name
					AND sec.activity_name = con.activity_name
					AND sec.ui_name = con.ui_name
					AND sec.page_bt_synonym = con.page_bt_synonym
					AND sec.section_bt_synonym = con.section_bt_synonym
				ORDER BY sec.horder,
					sec.vorder -- TECH-14716
					--PLF2.0_03715 ends
					-- Below code commented by Venkatesan K For nonvisible section name is printing in sec tag starts
					-------------Hdn Grid   PLF2.0_18888    
					--Union
					--select upper(sec.section_bt_synonym),    isnull(gls.bt_synonym_caption,sec.section_bt_synonym),
					--upper(ltrim(rtrim(sec.visisble_flag))),  upper(ltrim(rtrim(sec.title_required))),
					--upper(ltrim(rtrim(sec.border_required))), upper(sec.parent_section),
					--sec.horder,        sec.vorder,
					--upper(sec.page_bt_synonym),     isnull(sec.title_alignment,'LEFT'),
					--upper(sec.SECTION_TYPE),     isnull(sec.height,0),
					--isnull(sec.width,0),      isnull(sec.Section_height_Scalemode,'px'),
					--isnull(sec.Section_width_Scalemode,'px'), isnull(sec.splitter_pos,''),isnull(sec.Associated_Control,''),isnull(NColSpan,''),isnull(NRowSpan,''),--Code Added For BugId PNR2.0_18564,PNR2.0_35383,PLF2.0_18487	
					----isnull(sec.IsStatic, 'N'),
					--case  when isnull(sec.section_collapsemode,'') = 'Col' then 'Y'
					--						  when isnull(sec.section_collapsemode,'') = 'Exp' then 'N'
					--						  else ''
					--						  end ,isnull(sec.section_collapse,''),isnull(SectionPrefixClass,''),isnull(CarouselNavigation,'N')
					--,isnull(sec.cell_spacing,0),isnull(sec.cell_padding,0)					
					--,isnull(Region,''),isnull(TitlePosition,''),isnull(CollapseDir,''),isnull(SectionLayout,''),isnull(XYCoordinates,''),isnull(ColumnLayWidth,'')	  
					--from ep_ui_section_dtl sec (nolock),
					--@ep_component_glossary_mst gls (nolock),
					--ep_ui_control_dtl ctrl(nolock),
					--es_comp_ctrl_type_mst	ctype(nolock)
					--where	ctrl.customer_name		= sec.customer_name
					--and  	sec.project_name		= ctrl.project_name
					--and  	sec.process_name		= ctrl.process_name
					--and  	sec.component_name  	= ctrl.component_name
					--and		sec.activity_name		= ctrl.activity_name
					--and		sec.ui_name				= ctrl.ui_name
					--and		sec.page_bt_synonym		= ctrl.page_bt_synonym
					--and		sec.section_bt_synonym	= ctrl.section_bt_synonym
					--and		ctrl.customer_name		= ctype.customer_name
					--and  	ctrl.project_name		= ctype.project_name
					--and  	ctrl.process_name		= ctype.process_name
					--and  	ctrl.component_name  	= ctype.component_name
					--and  	ctrl.control_type		= ctype.ctrl_type_name
					--and		ctype.base_ctrl_type	= 'Grid'
					--and		sec.customer_name		= gls.customer_name
					--and  	sec.project_name		= gls.project_name
					--and  	sec.process_name		= gls.process_name
					--and  	sec.component_name  	= gls.component_name
					--and  	sec.section_bt_synonym	= gls.bt_synonym_name
					--and  	sec.customer_name		= @engg_customer_name
					--and  	sec.project_name		= @engg_project_name
					--and  	sec.component_name		= @engg_component
					--and  	sec.activity_name		= @activity_name
					--and  	sec.ui_name				= @ui_name_tmp
					--and		sec.section_bt_synonym	not in ('PRJHDNSECTION','[tabcontrol]') 
					--and		sec.visisble_flag		= 'N'
					--and		gls.languageid			= @language_code
					--and		sec.section_type		<>'tree'
					--order by sec.horder,sec.vorder
					-- above code commented by Venkatesan K For nonvisible section name is printing in sec tag Ends
			END

			-- For each Section  generate entries
			OPEN seccurs

			WHILE (1 = 1)
			BEGIN
				FETCH NEXT
				FROM seccurs
				INTO @section_bt_synonym_tmp,
					@section_descr_tmp,
					@visible_flag_tmp,
					@title_required_tmp,
					@border_required_tmp,
					@parent_section_tmp,
					@horder_tmp,
					@vorder_tmp,
					@page_bt_synonym_tmp,
					@sectitle_align_tmp,
					@section_type_tmp,
					--Code Modified For BugId : PNR2.0_7273
					@section_height_tmp,
					@section_width_tmp,
					@section_heightscalemode_tmp,
					@section_widthscalemode_tmp,
					@Section_Position --PNR2.0_35383
					--,@isstatic
					,
					@AssociatedControl,
					@NColSpan,
					@NRowSpan --Code Added For BugId PNR2.0_18564,PNR2.0_35383 --PLF2.0_03715
					,
					@section_collapse_mode,
					@section_collapseable,
					@section_prefix_class,
					@CarouselNavigation,
					@cell_spacing,
					@cell_padding,
					@Region,
					@TitlePosition,
					@CollapseDir,
					@SectionLayout,
					@XYCoordinates,
					@ColumnLayWidth,
					@Titleicon --TECH-72114

				IF @@fetch_status <> 0
					BREAK

				SELECT @section_descr_tmp = replace(@section_descr_tmp, '&', '&amp;')

				SELECT @section_descr_tmp = replace(@section_descr_tmp, '<', '&lt;')

				SELECT @section_descr_tmp = replace(@section_descr_tmp, '>', '&gt;')

				SELECT @section_descr_tmp = replace(@section_descr_tmp, '"', '&quot;')

				-- code modified for the caseid : PNR2.0_28642 starts
				IF @pubflag = 'P'
				BEGIN
					SELECT @colspan = max(vorder) * 2
					FROM ep_published_ui_control_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_req_no
						AND process_name = @process_name
						AND component_name = @engg_component
						AND activity_name = @activity_name
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = @page_bt_synonym_tmp
						AND section_bt_synonym = @section_bt_synonym_tmp
				END
				ELSE
				BEGIN
					SELECT @colspan = max(vorder) * 2
					FROM ep_ui_control_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = 'Base'
						AND process_name = @process_name
						AND component_name = @engg_component
						AND activity_name = @activity_name
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = @page_bt_synonym_tmp
						AND section_bt_synonym = @section_bt_synonym_tmp
				END

				-- code modified for the caseid : PNR2.0_28642 ends
				--Code Modified for BugId : PNR2.0_7420
				--Code commented for BugId : PNR2.0_35383 starts
				/*if @section_type_tmp = 'Tree'
select @section_heightscalemode_tmp = 'px',
@section_widthscalemode_tmp  = 'px'*/
				--Code commented for BugId : PNR2.0_35383 starts
				----Code added for Bug ID:PLF2.0_00961 starts   
				SELECT @alignbtn = ''

				DECLARE @activityname_1 VARCHAR(60),
					@ilbocode_1 VARCHAR(60),
					@pagename_1 VARCHAR(60),
					@sectionname_1 VARCHAR(60),
					@control_name_1 VARCHAR(60),
					@algnbtn_h_1 INT,
					@algnbtn_v_1 INT

				IF EXISTS (
						SELECT '*'
						FROM ep_ui_control_dtl a(NOLOCK),
							es_comp_ctrl_type_mst b(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.process_name = @process_name
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							AND a.page_bt_synonym = @page_bt_synonym_tmp
							AND a.section_bt_synonym = @section_bt_synonym_tmp
							AND a.customer_name = b.customer_name
							AND a.project_name = b.project_name
							AND a.process_name = b.process_name
							AND a.component_name = b.component_name
							AND a.control_type = b.ctrl_type_name
							AND b.base_ctrl_type IN ('button')
						)
				BEGIN
					IF (
							(
								SELECT count(*)
								FROM ep_ui_control_dtl a(NOLOCK),
									es_comp_ctrl_type_mst b(NOLOCK)
								WHERE a.customer_name = @engg_customer_name
									AND a.project_name = @engg_project_name
									AND a.process_name = @process_name
									AND a.component_name = @engg_component
									AND a.activity_name = @activity_name
									AND a.ui_name = @ui_name_tmp
									AND a.page_bt_synonym = @page_bt_synonym_tmp
									AND a.section_bt_synonym = @section_bt_synonym_tmp
									AND a.customer_name = b.customer_name
									AND a.project_name = b.project_name
									AND a.process_name = b.process_name
									AND a.component_name = b.component_name
									AND a.control_type = b.ctrl_type_name
									AND (
										b.base_ctrl_type IN ('button')
										OR b.ctrl_type_name IN (
											'filler',
											'filler2'
											)
										)
								) = (
								SELECT count(*)
								FROM ep_ui_control_dtl c(NOLOCK)
								WHERE c.customer_name = @engg_customer_name
									AND c.project_name = @engg_project_name
									AND c.process_name = @process_name
									AND c.component_name = @engg_component
									AND c.activity_name = @activity_name
									AND c.ui_name = @ui_name_tmp
									AND c.page_bt_synonym = @page_bt_synonym_tmp
									AND c.section_bt_synonym = @section_bt_synonym_tmp
								)
							)
					BEGIN
						SELECT @alignbtn = 'Y'

						INSERT INTO #AlignBtn (
							activityname,
							ilbocode,
							pagename,
							sectionname,
							control_name,
							algnbtn_h,
							algnbtn_v,
							horder,
							vorder
							)
						SELECT DISTINCT activity_name,
							ui_name,
							page_bt_synonym,
							section_bt_synonym,
							control_bt_synonym,
							0,
							0,
							a.horder,
							a.vorder
						FROM ep_ui_control_dtl a(NOLOCK),
							es_comp_ctrl_type_mst b(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.process_name = @process_name
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							AND a.page_bt_synonym = @page_bt_synonym_tmp
							AND a.section_bt_synonym = @section_bt_synonym_tmp
							AND a.customer_name = b.customer_name
							AND a.project_name = b.project_name
							AND a.process_name = b.process_name
							AND a.component_name = b.component_name
							AND a.control_type = b.ctrl_type_name
							AND b.base_ctrl_type IN ('button')
						ORDER BY a.page_bt_synonym,
							a.section_bt_synonym,
							a.horder,
							a.vorder ASC

						SELECT @algnbtn_h_1 = 1,
							@algnbtn_v_1 = 1

						DECLARE align_btn INSENSITIVE CURSOR
						FOR
						SELECT DISTINCT activityname,
							ilbocode,
							pagename,
							sectionname,
							control_name,
							horder,
							vorder
						FROM #AlignBtn(NOLOCK)
						WHERE activityname = @activity_name
							AND ilbocode = @ui_name_tmp
							AND pagename = @page_bt_synonym_tmp
							AND sectionname = @section_bt_synonym_tmp
						ORDER BY horder,
							vorder

						OPEN align_btn

						WHILE (1 = 1)
						BEGIN -- cur   
							FETCH NEXT
							FROM align_btn
							INTO @activityname_1,
								@ilbocode_1,
								@pagename_1,
								@sectionname_1,
								@control_name_1,
								@horder_1,
								@vorder_1

							IF @@fetch_status <> 0
								BREAK

							IF @algnbtn_v_1 > 6
							BEGIN
								SELECT @algnbtn_h_1 = @algnbtn_h_1 + 1

								SELECT @algnbtn_v_1 = 1
							END

							UPDATE #AlignBtn
							SET algnbtn_h = @algnbtn_h_1,
								algnbtn_v = @algnbtn_v_1
							WHERE activityname = @activityname_1
								AND ilbocode = @ilbocode_1
								AND pagename = @pagename_1
								AND sectionname = @sectionname_1
								AND control_name = @control_name_1

							SELECT @algnbtn_v_1 = @algnbtn_v_1 + 1
						END -- cur   

						CLOSE align_btn

						DEALLOCATE align_btn
					END
				END

				--END --1
				----Code added for Bug ID:PLF2.0_00961 ends
				-- code modified for the caseid : PNR2.0_28642 starts
				SELECT @uicolspan = isnull(max(vorder), 0)
				FROM ep_ui_control_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @process_name
					AND component_name = @engg_component
					AND activity_name = @activity_name
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = @page_bt_synonym_tmp
					AND section_bt_synonym = @section_bt_synonym_tmp

				SELECT @nonuicolspan = isnull(max(vorder), 0)
				FROM de_non_ui_control(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @process_name
					AND component_name = @engg_component
					AND activity_name = @activity_name
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = @page_bt_synonym_tmp
					AND section_bt_synonym = @section_bt_synonym_tmp

				IF isnull(@uicolspan, 0) > isnull(@nonuicolspan, 0)
				BEGIN
					SELECT @colspan = @uicolspan * 2
				END
				ELSE
				BEGIN
					SELECT @colspan = @nonuicolspan * 2
				END

				-- code modified for the caseid : PNR2.0_28642 ends
				--Code Modified for BugId : PNR2.0_7420
				--Code commented for BugId : PNR2.0_35383 starts
				/*if @section_type_tmp = 'Tree'
select @section_heightscalemode_tmp = 'px',
@section_widthscalemode_tmp  = 'px'*/
				--Code commented for BugId : PNR2.0_35383 ends
				IF EXISTS (
						SELECT 'x'
						FROM ep_section_hierarchy(NOLOCK)
						WHERE guid = @guid
							AND customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @process_name
							AND component_name = @engg_component
							AND activity_name = @activity_name
							AND ui_name = @ui_name_tmp
							AND page_name = @page_bt_synonym_tmp
							AND section_name = @section_bt_synonym_tmp
						)
				BEGIN
					-- For Gettting Section Level
					SELECT @section_level = LEVEL
					FROM ep_section_hierarchy(NOLOCK)
					WHERE guid = @guid
						AND customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @process_name
						AND component_name = @engg_component
						AND activity_name = @activity_name
						AND ui_name = @ui_name_tmp
						AND page_name = @page_bt_synonym_tmp
						AND section_name = @section_bt_synonym_tmp
						AND req_no = @engg_req_no_in --code added for bugid : PNR2.0_18751
				END
				ELSE
				BEGIN
					SELECT @section_level = 0
				END

				SELECT @linkSection = 'N',
					@buttonSection = 'N',
					@GanttSection = 'N',
					@SectionRenderAs = '' --Code Added for Defect ID : TECH-39534

				IF EXISTS (
						SELECT '*'
						FROM ep_ui_section_dtl a(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.process_name = @process_name
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							AND a.page_bt_synonym = @page_bt_synonym_tmp
							AND a.section_bt_synonym = @section_bt_synonym_tmp
							AND NOT EXISTS (
								SELECT 'A'
								FROM ep_ui_control_dtl b(NOLOCK),
									es_comp_ctrl_type_mst c(NOLOCK)
								WHERE b.customer_name = a.customer_name
									AND b.project_name = a.project_name
									AND b.process_name = a.process_name
									AND b.component_name = a.component_name
									AND b.activity_name = a.activity_name
									AND b.ui_name = a.ui_name
									AND b.page_bt_synonym = a.page_bt_synonym
									AND b.section_bt_synonym = a.section_bt_synonym
									AND b.control_type NOT IN (
										'Filler',
										'Filler2'
										)
									AND c.customer_name = b.customer_name
									AND c.project_name = b.project_name
									AND c.process_name = b.process_name
									AND c.component_name = b.component_name
									AND c.ctrl_type_name = b.control_type
									AND c.base_ctrl_type <> 'Link'
								)
							AND EXISTS (
								SELECT 'A'
								FROM ep_ui_control_dtl d(NOLOCK)
								WHERE d.customer_name = a.customer_name
									AND d.project_name = a.project_name
									AND d.process_name = a.process_name
									AND d.component_name = a.component_name
									AND d.activity_name = a.activity_name
									AND d.ui_name = a.ui_name
									AND d.page_bt_synonym = a.page_bt_synonym
									AND d.section_bt_synonym = a.section_bt_synonym
								)
						)
				BEGIN
					SET @linkSection = 'Y'
				END

				IF EXISTS (
						SELECT '*'
						FROM ep_ui_section_dtl a(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.process_name = @process_name
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							AND a.page_bt_synonym = @page_bt_synonym_tmp
							AND a.section_bt_synonym = @section_bt_synonym_tmp
							AND NOT EXISTS (
								SELECT 'A'
								FROM ep_ui_control_dtl b(NOLOCK),
									es_comp_ctrl_type_mst c(NOLOCK)
								WHERE b.customer_name = a.customer_name
									AND b.project_name = a.project_name
									AND b.process_name = a.process_name
									AND b.component_name = a.component_name
									AND b.activity_name = a.activity_name
									AND b.ui_name = a.ui_name
									AND b.page_bt_synonym = a.page_bt_synonym
									AND b.section_bt_synonym = a.section_bt_synonym
									AND b.control_type NOT IN (
										'Filler',
										'Filler2'
										)
									AND c.customer_name = b.customer_name
									AND c.project_name = b.project_name
									AND c.process_name = b.process_name
									AND c.component_name = b.component_name
									AND c.ctrl_type_name = b.control_type
									AND c.base_ctrl_type <> 'Button'
								)
							AND EXISTS (
								SELECT 'A'
								FROM ep_ui_control_dtl d(NOLOCK)
								WHERE d.customer_name = a.customer_name
									AND d.project_name = a.project_name
									AND d.process_name = a.process_name
									AND d.component_name = a.component_name
									AND d.activity_name = a.activity_name
									AND d.ui_name = a.ui_name
									AND d.page_bt_synonym = a.page_bt_synonym
									AND d.section_bt_synonym = a.section_bt_synonym
								)
						)
					AND @enablefiller <> 'Yes' --condition modified for the Bug ID:PLF2.0_00708
				BEGIN
					SET @buttonSection = 'Y'
				END

				
if exists(select 'X'
from	ep_ui_section_dtl  sec (nolock)
where	sec.customer_name		= @engg_customer_name
and		sec.project_name		= @engg_project_name
and		sec.req_no				= @engg_req_no
and		sec.process_name		= @process_name
and		sec.component_name		= @engg_component
and		sec.activity_name		= @activity_name
and		sec.ui_name				= @ui_name_tmp
and		sec.page_bt_synonym		= @page_bt_synonym_tmp
and		sec.section_bt_synonym	= @section_bt_synonym_tmp

and  exists( select 'X'
from	ep_ui_control_dtl  ctl (nolock),
		es_comp_ctrl_type_mst  typ (nolock)
where	ctl.customer_name		= sec.customer_name
and		ctl.project_name		= sec.project_name
and		ctl.req_no				= sec.req_no
and		ctl.process_name		= sec.process_name
and		ctl.component_name		= sec.component_name
and		ctl.activity_name		= sec.activity_name
and		ctl.ui_name				= sec.ui_name
and		ctl.page_bt_synonym		= sec.page_bt_synonym
and		ctl.section_bt_synonym	= sec.section_bt_synonym

and		typ.customer_name		= ctl.customer_name
and		typ.project_name		= ctl.project_name
and		typ.process_name		= ctl.process_name
and		typ.component_name		= ctl.component_name
and		typ.ctrl_type_name		= ctl.control_type
and		typ.base_ctrl_type		= 'TreeGrid'
and		typ.renderAs			= 'Gantt'
and		ctl.control_type		not in('Filler', 'Filler2'))
)
begin 
	set @SectionRenderAs = 'Gantt' --Code Modified for Defect ID : TECH-39534
end
--Code added for Defect ID : TECH-39534 Starts
if exists(select 'X'
from	ep_ui_section_dtl  sec (nolock)
where	sec.customer_name		= @engg_customer_name
and		sec.project_name		= @engg_project_name
and		sec.req_no				= @engg_req_no
and		sec.process_name		= @process_name
and		sec.component_name		= @engg_component
and		sec.activity_name		= @activity_name
and		sec.ui_name				= @ui_name_tmp
and		sec.page_bt_synonym		= @page_bt_synonym_tmp
and		sec.section_bt_synonym	= @section_bt_synonym_tmp

and  exists( select 'X'
from	ep_ui_control_dtl  ctl (nolock),
		es_comp_ctrl_type_mst  typ (nolock)
where	ctl.customer_name		= sec.customer_name
and		ctl.project_name		= sec.project_name
and		ctl.req_no				= sec.req_no
and		ctl.process_name		= sec.process_name
and		ctl.component_name		= sec.component_name
and		ctl.activity_name		= sec.activity_name
and		ctl.ui_name				= sec.ui_name
and		ctl.page_bt_synonym		= sec.page_bt_synonym
and		ctl.section_bt_synonym	= sec.section_bt_synonym

and		typ.customer_name		= ctl.customer_name
and		typ.project_name		= ctl.project_name
and		typ.process_name		= ctl.process_name
and		typ.component_name		= ctl.component_name
and		typ.ctrl_type_name		= ctl.control_type
and		typ.base_ctrl_type		= 'Grid'
and		typ.renderAs			= 'CALENDAR_EVENT'
and		ctl.control_type		not in('Filler', 'Filler2'))
)
begin 
	set @SectionRenderAs = 'Calendar'

	SELECT	@AssociatedControl	= UPPER(ISNULL(Control_id,''))
	FROM	ep_ui_control_dtl (nolock)
	where	customer_name		= @engg_customer_name
	and		project_name		= @engg_project_name
	and		req_no				= @engg_req_no
	and		process_name		= @process_name
	and		component_name		= @engg_component
	and		activity_name		= @activity_name
	and		ui_name				= @ui_name_tmp
	and		page_bt_synonym		= @page_bt_synonym_tmp
	and		section_bt_synonym	= @section_bt_synonym_tmp
	and		control_type		= 'HiddenEdit'
end
--Code added for Defect ID : TECH-39534 Ends

				IF EXISTS (
						SELECT 'x'
						FROM ep_section_hierarchy(NOLOCK)
						WHERE guid = @guid
							AND customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @process_name
							AND component_name = @engg_component
							AND activity_name = @activity_name
							AND ui_name = @ui_name_tmp
							AND page_name = @page_bt_synonym_tmp
							AND section_name = @section_bt_synonym_tmp
						)
				BEGIN
					-- For Gettting Section Level
					SELECT @section_level = LEVEL
					FROM ep_section_hierarchy(NOLOCK)
					WHERE guid = @guid
						AND customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @process_name
						AND component_name = @engg_component
						AND activity_name = @activity_name
						AND ui_name = @ui_name_tmp
						AND page_name = @page_bt_synonym_tmp
						AND section_name = @section_bt_synonym_tmp
				END
				ELSE
				BEGIN
					SELECT @section_level = 0
				END

				-- Added By Feroz For Dynamic Section
				SELECT @mapped_sec_controlid = '',
					@mapped_sec_viewname = ''

				IF @section_type_tmp = 'Dynamic'
				BEGIN
					IF @pubflag = 'P'
					BEGIN
						SELECT @mapped_sec_controlid = controlid,
							@mapped_sec_viewname = viewname
						FROM ep_dynamic_sec_control_map(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND req_no = 'Base'
							AND process_name = @process_name
							AND component_name = @engg_component
							AND activity_name = @activity_name
							AND ui_name = @ui_name_tmp
							AND page_bt_synonym = @page_bt_synonym_tmp
							AND section_bt_synonym = @section_bt_synonym_tmp
					END
					ELSE
					BEGIN
						SELECT @mapped_sec_controlid = controlid,
							@mapped_sec_viewname = viewname
						FROM ep_published_dynamic_sec_control_map(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND req_no = @engg_req_no
							AND process_name = @process_name
							AND component_name = @engg_component
							AND activity_name = @activity_name
							AND ui_name = @ui_name_tmp
							AND page_bt_synonym = @page_bt_synonym_tmp
							AND section_bt_synonym = @section_bt_synonym_tmp
					END
				END

				-- Added By Feroz For Dynamic Section
				--Code Added for the Bug ID: PNR2.0_31780 starts
				IF @section_type_tmp = 'Tree Grid'
				BEGIN
					IF @pubflag = 'P'
					BEGIN
						SELECT @mapped_sec_controlid = b.control_id,
							@mapped_sec_viewname = b.view_name
						FROM ep_published_ui_section_dtl a(NOLOCK),
							ep_published_ui_control_dtl b(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.req_no = @engg_req_no
							AND a.process_name = @process_name
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							AND a.page_bt_synonym = @page_bt_synonym_tmp
							AND a.section_bt_synonym = @section_bt_synonym_tmp
							AND a.customer_name = b.customer_name
							AND a.project_name = b.project_name
							AND a.req_no = b.req_no
							AND a.process_name = b.process_name
							AND a.component_name = b.component_name
							AND a.activity_name = b.activity_name
							AND a.ui_name = b.ui_name
							AND b.page_bt_synonym = '[mainscreen]'
							AND b.section_bt_synonym = 'PrjhdnSection'
							AND b.control_bt_synonym = a.Associated_control
					END
					ELSE
					BEGIN
						SELECT @mapped_sec_controlid = b.control_id,
							@mapped_sec_viewname = b.view_name
						FROM ep_ui_section_dtl a(NOLOCK),
							ep_ui_control_dtl b(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.req_no = 'Base'
							AND a.process_name = @process_name
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							AND a.page_bt_synonym = @page_bt_synonym_tmp
							AND a.section_bt_synonym = @section_bt_synonym_tmp
							AND a.customer_name = b.customer_name
							AND a.project_name = b.project_name
							AND a.req_no = b.req_no
							AND a.process_name = b.process_name
							AND a.component_name = b.component_name
							AND a.activity_name = b.activity_name
							AND a.ui_name = b.ui_name
							AND b.page_bt_synonym = '[mainscreen]'
							AND b.section_bt_synonym = 'PrjhdnSection'
							AND b.control_bt_synonym = a.Associated_control
					END
				END

				-- Insert UI Entry
IF EXISTS ( SELECT 'X'
FROM	ep_ui_mst a (nolock)
WHERE	a.customer_name			=  	@engg_customer_name
and		a.project_name			=	@engg_project_name
and		a.req_no				=	@engg_req_no
and		a.process_name			=	@process_name
and		a.component_name		=	@engg_component
and		a.activity_name			= 	@activity_name
and		a.ui_name				=	@ui_name_tmp
and		a.devicetype			IN ('P', 'B', 'T'))
AND isnull(@AssociatedControl,'') <>'' -- 11537
begin
	select @AssociatedControl ='ML'+@AssociatedControl
--code Added for Defect ID : TECH-39534 Ends
end
else
if isnull(@AssociatedControl,'') <>'' -- 11537
	select @AssociatedControl =@AssociatedControl

				-- Added for TECH-46646 Starts
				select  @section_prefix	=	section_prefix,
						@forresponsive	=	CASE WHEN @section_bt_synonym_tmp = '[TABCONTROL]' THEN 'none'	--TECH-69624
												ELSE ISNULL(Convert(VARCHAR(10), ForResponsive), 'none')      
											END
				from  ep_ui_section_dtl (nolock)
				where customer_name  =   @engg_customer_name
				and  project_name  = @engg_project_name
				and  req_no		   = 'Base'
				and  process_name  = @process_name
				and  component_name  = @engg_component
				and  activity_name  = @activity_name
				and  ui_name    = @ui_name_tmp
				and  page_bt_synonym  =  @page_bt_synonym_tmp
				and  section_bt_synonym =  @section_bt_synonym_tmp
				
				IF	ISNULL(@sectionprefixclass,'') = 'Dynamic'
					SELECT @DynamicStyleControlName = 'hdn' + ISNULL(@section_prefix, '') + 'ds'
				--Added for TECH-46646 Ends

				--Code Added for the Bug ID: PNR2.0_31780 ends
				-- Insert UI Entry
				--code Modified For BugId :PNR2.0_5812
				SELECT @xml_seq_tmp = @xml_seq_tmp + 1

				INSERT INTO ep_genxml_tmp (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					activity_name,
					guid,
					gen_xml,
					seq_no
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@process_name,
					@engg_component,
					@activity_name,
					@guid,
					'<Section Name="' + ltrim(rtrim(@section_bt_synonym_tmp)) + '" ' + 'SectionCaption="' + ltrim(rtrim(@section_descr_tmp)) + '" ' + 'PageName="' + ltrim(rtrim(@page_bt_synonym_tmp)) + '" ' + 'ILBOName="' + ltrim(rtrim(@ui_name_tmp)) + '" ' + 'ActivityName="' + ltrim(rtrim(@activity_name)) + '" ' + 'ComponentName="' + ltrim(rtrim(@engg_component)) + '" ' + 'PagePrefix="' + ltrim(rtrim(@page_prefix)) + '" ' + 'ParentSection="' + ltrim(rtrim(@parent_section_tmp)) + '" ' + 'VisibleFlag="' + ltrim(rtrim(@visible_flag_tmp)) + '" ' + 'TitleRequired="' + ltrim(rtrim(@title_required_tmp)) + '" ' + 'BorderRequired="' + ltrim(rtrim(@border_required_tmp)) + '" ' + 'TitleAlignment="' + ltrim(rtrim(@sectitle_align_tmp)) + '" ' + 'SectionType="' + ltrim(rtrim(isnull(@section_type_tmp, ''))) + '" ' +
					--Code Modified For BugId : PNR2.0_7273
					'Height="' + ltrim(rtrim(isnull(@section_height_tmp, ''))) + '" ' + 'Width="' + ltrim(rtrim(isnull(@section_width_tmp, ''))) + '" ' + 'HeightScaleMode="' + ltrim(rtrim(isnull(@section_heightscalemode_tmp, 'px'))) + '" ' + 'WidthScaleMode="' + ltrim(rtrim(isnull(@section_widthscalemode_tmp, 'px'))) + '" ' + 'SectionLevel="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR(5), @section_level), 3))) + '" ' + 'HOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, @horder_tmp), 3))) + '" ' + 'VOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, @vorder_tmp), 3))) + '" ' + 'IsLinkSection="' + @linkSection + '" ' + 
					'IsButtonSection="' + @buttonSection + '" ' + 
					'RenderAs="'   + @SectionRenderAs + '" ' + --code Added for Defect ID : TECH-39534
					'MappedControlId="' + ltrim(rtrim(isnull(@mapped_sec_controlid, ''))) + '" ' + 'MappedViewName="'
 + ltrim(rtrim(isnull(@mapped_sec_viewname, ''))) + '" ' + 'Colspan="' + ltrim(rtrim(isnull(convert(VARCHAR(5), @colspan), ''))) + '" ' + 'AlignBtn="' + ltrim(rtrim(isnull(@alignbtn, ''))) + '" ' + --Code added for Bug ID:PLF2.0_00961
					'Position="' + ltrim(rtrim(isnull(@Section_Position, ''))) + '" ' + 'SectionPrefixClass="' + ltrim(rtrim(isnull(@section_prefix_class, ''))) + '" ' + 
					'AssociatedControl="' + ltrim(rtrim(isnull(@AssociatedControl, ''))) + '" ' + 'NColSpan="' + CONVERT
(VARCHAR, isnull(@NColSpan, ''), 4) + '" ' + 'NRowSpan="' + CONVERT(VARCHAR, isnull(@NRowSpan, ''), 4) + '" ' +
					--'IsStatic="'		+ ltrim(rtrim(isnull(@isstatic,'N')))+'"/>',@xml_seq_tmp) -- code modified for the caseid : PNR2.0_28642 ,PNR2.0_35383
					'SectionCollapseMode="' + ltrim(rtrim(isnull(@section_collapse_mode, ''))) + '" ' + 
					'SectionCollapseable="' + ltrim(rtrim(isnull(@section_collapseable, ''))) + '" ' + 
					'CellSpacing="' + isnull(cast(@cell_spacing AS VARCHAR(20)), 0) + '" ' + 
					'CellPadding="' + isnull(cast(@cell_padding AS VARCHAR(20)), 0) + '" ' + 
					'Region="' + isnull(cast(@Region AS VARCHAR(20)), 0) + '" ' + 
					'TitlePosition="' + isnull(cast(@TitlePosition AS VARCHAR(20)), 0) + '" ' + 
					'TitleIcon="'     + ltrim(rtrim(isnull(@TitleIcon,'')))  + '" ' +  --TECH-72114
					'CollapseDir="' + isnull(cast(@CollapseDir AS VARCHAR(20)), 0) + '" ' + 
					'SectionLayout="' + isnull(cast(@SectionLayout AS VARCHAR(20)), 0) + '" ' + 
					'XYCoordinates="' + isnull(cast(@XYCoordinates AS VARCHAR(20)), 0) + '" ' + 
					'ColumnLayWidth="' + isnull(cast(@ColumnLayWidth AS VARCHAR(20)), 0) + '" ' + 
					'CarouselNavigation="' + ltrim(rtrim(isnull(@CarouselNavigation, 'N'))) + '"/>',
					@xml_seq_tmp
					)
			END

			CLOSE seccurs

			DEALLOCATE seccurs

			-- In case of help ui add a new section
			IF @ui_type_tmp = 'HELP'
			BEGIN
				SELECT @xml_seq_tmp = @xml_seq_tmp + 1,
					@oksectionname_tmp = 'OKSECTION'

				--code starts -- Added by chanheetha N A -- border req for OKsection in help screen' -- PNR2.0_17707
				DECLARE @oksecbor_req engg_flag

				SELECT @oksecbor_req = CASE 
						WHEN isnull(current_value, 'YES') = 'YES'
							THEN 'Y' -- Code modified for the Bug ID:PLF2.0_01208
						ELSE 'N'
						END
				FROM es_comp_param_mst(NOLOCK)
				WHERE param_category = 'OKSECBORD'
					AND component_name = @engg_component

				IF isnull(@oksecbor_req, '') = ''
					SELECT @oksecbor_req = 'Y'

				--code end -- Added by chanheetha N A -- border req for OKsection in help screen' -- PNR2.0_17707
				SELECT @section_height_tmp = '', -- code added for BugID:PNR2.0_26450
					@section_width_tmp = ''

				INSERT INTO ep_genxml_tmp (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					activity_name,
					guid,
					gen_xml,
					seq_no
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@process_name,
					@engg_component,
					@activity_name,
					@guid,
					'<Section Name="' + @oksectionname_tmp + '" ' + 'SectionCaption="' + @oksectionname_tmp + '" ' + 'PageName="' + ltrim(rtrim(@mainpage_tmp)) + '" ' + 'ILBOName="' + ltrim(rtrim(@ui_name_tmp)) + '" ' + 'ActivityName="' + ltrim(rtrim(@activity_name)) + 
'" ' + 'ComponentName="' + ltrim(rtrim(@engg_component)) + '" ' + 'ParentSection="" ' + 'VisibleFlag="Y"  ' + 'TitleRequired="N" ' +
					--code starts -- Added by chanheetha N A -- border req for OKsection in help screen' -- PNR2.0_17707
					'BorderRequired="' + ltrim(rtrim(@oksecbor_req)) + '" ' +
					--code end -- Added by chanheetha N A -- border req for OKsection in help screen' -- PNR2.0_17707
					'TitleAlignment="' + ltrim(rtrim('LEFT')) + '" ' + 'SectionType="MAIN" ' +
					--Code Modified For BugId : PNR2.0_7273
					'Height="' + ltrim(rtrim(isnull(@section_height_tmp, ''))) + '" ' + 'Width="' + ltrim(rtrim(isnull(@section_width_tmp, ''))) + '" ' + 'HeightScaleMode="' + ltrim(rtrim(isnull(@section_heightscalemode_tmp, 'px'))) + '" ' + 'WidthScaleMode="' + ltrim(rtrim(isnull(@section_widthscalemode_tmp, 'px'))) + '" ' + 'HOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, @oksectionrow_tmp), 3))) + '" ' + 'VOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, 1), 3))) + '" ' + 'MappedControlId="' + ltrim(rtrim(isnull(@mapped_sec_controlid, ''))) + '" ' + 'MappedViewName="' + ltrim(rtrim(isnull(@mapped_sec_viewname, ''))) + '" ' + 'Colspan="' + ltrim(rtrim(isnull(convert(VARCHAR(5), @colspan), ''))) + '" ' + 'SectionPrefixClass="' + ltrim(rtrim(isnull(@section_prefix_class, ''))) + '" ' +
					--'IsStatic="'		+ ltrim(rtrim(isnull(@isstatic,'N')))+'"/>',@xml_seq_tmp) -- code modified for the caseid : PNR2.0_28642
					'SectionCollapseMode="' + ltrim(rtrim(isnull(@section_collapse_mode, 'N'))) + '" ' +  --11536 for the case id TECH-19895
					'SectionCollapseable="' + ltrim(rtrim(isnull(@section_collapseable, ''))) +
					'TitleIcon="'     + ltrim(rtrim(isnull(@TitleIcon,'')))  + '" ' +  --TECH-72114
					'"/>',
					@xml_seq_tmp
					)
			END

			-- For Hidden Section in each page
			IF @ctxt_service_in IN ('BulkGenerate')
				AND @pubflag = 'P'
			BEGIN
				DECLARE secpagecurs INSENSITIVE CURSOR
				FOR
				SELECT upper(page_bt_synonym),
					isnull(bt_synonym_caption, page_bt_synonym),
					horder,
					vorder
				FROM ep_published_ui_page_dtl pg(NOLOCK),
					@ep_published_comp_glossary_mst gls
				WHERE pg.customer_name = gls.customer_name
					AND pg.project_name = gls.project_name
					AND pg.req_no = gls.req_no
					AND pg.process_name = gls.process_name
					AND pg.component_name = gls.component_name
					AND pg.page_bt_synonym = gls.bt_synonym_name
					--code modified by kiruthika for bugid:PNR2.0_9189
					AND pg.activity_name = @activity_name
					AND pg.ui_name = @ui_name_tmp
					AND gls.customer_name = @engg_customer_name
					AND gls.project_name = @engg_project_name
					AND gls.req_no = @engg_req_no
					AND gls.process_name = @process_name
					AND gls.component_name = @engg_component
					--AND gls.languageid = @language_code
				
				UNION
				
				SELECT '[MAINSCREEN]',
					'[MAINSCREEN]',
					horder,
					vorder
				FROM ep_published_ui_page_dtl pg(NOLOCK)
				WHERE pg.customer_name = @engg_customer_name
					AND pg.project_name = @engg_project_name
					AND pg.req_no = @engg_req_no
					AND pg.process_name = @process_name
					AND pg.component_name = @engg_component
					AND pg.activity_name = @activity_name
					AND pg.ui_name = @ui_name_tmp
					AND pg.page_bt_synonym = '[MAINSCREEN]'
				ORDER BY horder,
					vorder
			END
			ELSE
			BEGIN
				DECLARE secpagecurs INSENSITIVE CURSOR
				FOR
				SELECT upper(page_bt_synonym),
					isnull(bt_synonym_caption, page_bt_synonym),
					horder,
					vorder
				FROM ep_ui_page_dtl pg(NOLOCK),
					@ep_component_glossary_mst gls
				--     where ui_sysid    = @ui_sysid_tmp
				WHERE pg.customer_name = @engg_customer_name
					AND pg.project_name = @engg_project_name
					AND pg.req_no = 'Base'
					AND pg.process_name = @process_name
					AND pg.component_name = @engg_component
					AND pg.activity_name = @activity_name
					AND pg.ui_name = @ui_name_tmp
					AND pg.customer_name = gls.customer_name
					AND pg.project_name = gls.project_name
					AND pg.req_no = gls.req_no
					AND pg.process_name = gls.process_name
					AND pg.component_name = gls.component_name
					AND pg.page_bt_synonym = gls.bt_synonym_name
					AND gls.customer_name = @engg_customer_name
					AND gls.project_name = @engg_project_name
					AND gls.req_no = 'Base'
					AND gls.process_name = @process_name
					AND gls.component_name = @engg_component
					--AND gls.languageid = @language_code
				
				UNION
				
				SELECT '[MAINSCREEN]',
					'[MAINSCREEN]',
					horder,
					vorder
				FROM ep_ui_page_dtl pg(NOLOCK)
				WHERE pg.customer_name = @engg_customer_name
					AND pg.project_name = @engg_project_name
					AND pg.req_no = 'Base'
					AND pg.process_name = @process_name
					AND pg.component_name = @engg_component
					AND pg.activity_name = @activity_name
					AND pg.ui_name = @ui_name_tmp
					AND pg.page_bt_synonym = '[MAINSCREEN]'
				ORDER BY horder,
					vorder
			END

			OPEN secpagecurs

			WHILE (1 = 1)
			BEGIN
				FETCH NEXT
				FROM secpagecurs
				INTO @page_bt_synonym_tmp,
					@page_descr_tmp,
					@horder_tmp,
					@vorder_tmp

				IF @@fetch_status <> 0
					BREAK

				SELECT @prjsecrow = 0

				IF @ctxt_service_in IN ('BulkGenerate')
					AND @pubflag = 'P'
				BEGIN
					--Code Modified for BugId : PNR2.0_9320
					SELECT @prjsecrow = isnull(max(horder), 0)
					FROM ep_published_ui_section_dtl sec(NOLOCK)
					WHERE sec.customer_name = @engg_customer_name
						AND sec.project_name = @engg_project_name
						AND sec.req_no = @engg_req_no
						AND sec.component_name = @engg_component
						AND sec.activity_name = @activity_name
						AND sec.ui_name = @ui_name_tmp
						AND sec.page_bt_synonym = @page_bt_synonym_tmp
						AND sec.section_bt_synonym <> 'PRJHDNSECTION'
						AND sec.visisble_flag = 'Y' -- Added For Removing Space Bug_id:PNR2.0_17856
						--      select @prjsecrow    = isnull(max(horder),0)
						--      from ep_published_ui_section_dtl sec (nolock),
						--        @ep_published_comp_glossary_mst gls (nolock)
						--      where sec.customer_name  = gls.customer_name
						--      and  sec.project_name  = gls.project_name
						--      and  sec.req_no    = gls.req_no
						--      and  sec.process_name  =  gls.process_name
						--      and  sec.component_name  =  gls.component_name
						--      and  sec.section_bt_synonym = gls.bt_synonym_name
						--      and  sec.customer_name  =   @engg_customer_name
						--      and  sec.project_name  = @engg_project_name
						--      and  sec.req_no    =  @engg_req_no
						--      and  sec.component_name  = @engg_component
						--      and  sec.activity_name  =  @activity_name
						--      and  sec.ui_name    =  @ui_name_tmp
						--      and  sec.page_bt_synonym  =  @page_bt_synonym_tmp
						--      and  sec.section_bt_synonym <>  'PRJHDNSECTION'
						--      and  gls.languageid   =  @language_code
				END
				ELSE
				BEGIN
					--Code Modified for BugId : PNR2.0_9320
					SELECT @prjsecrow = isnull(max(horder), 0)
					FROM ep_ui_section_dtl sec(NOLOCK)
					WHERE sec.customer_name = @engg_customer_name
						AND sec.project_name = @engg_project_name
						AND sec.component_name = @engg_component
						AND sec.activity_name = @activity_name
						AND sec.ui_name = @ui_name_tmp
						AND sec.page_bt_synonym = @page_bt_synonym_tmp
						AND sec.section_bt_synonym <> 'PRJHDNSECTION'
						AND sec.visisble_flag = 'Y' -- Added For Removing Space Bug_id:PNR2.0_17856
						--      select @prjsecrow    = isnull(max(horder),0)
						--      from ep_ui_section_dtl sec (nolock),
						--        @ep_component_glossary_mst gls (nolock)
						--      where sec.customer_name  = gls.customer_name
						--      and  sec.project_name  = gls.project_name
						--      and  sec.req_no    = gls.req_no
						--      and  sec.process_name  =  gls.process_name
						--      and  sec.component_name  =  gls.component_name
						--  and  sec.section_bt_synonym = gls.bt_synonym_name
						--      and  sec.customer_name  =   @engg_customer_name
						--      and  sec.project_name  = @engg_project_name
						--      and  sec.component_name  = @engg_component
						--      and  sec.activity_name  =  @activity_name
						--      and  sec.ui_name    =  @ui_name_tmp
						--      and  sec.page_bt_synonym  =  @page_bt_synonym_tmp
						--      and  sec.section_bt_synonym <>  'PRJHDNSECTION'
						--      and  gls.languageid   =  @language_code
				END

				SELECT @horder_tmp = @prjsecrow + 1

				SELECT @section_descr_tmp = replace(@section_descr_tmp, '&', '&amp;')

				SELECT @section_descr_tmp = replace(@section_descr_tmp, '<', '&lt;')

				SELECT @section_descr_tmp = replace(@section_descr_tmp, '>', '&gt;')

				SELECT @section_descr_tmp = replace(@section_descr_tmp, '"', '&quot;')

				IF @ctxt_service_in IN ('BulkGenerate')
					AND @pubflag = 'P'
				BEGIN
					-- code modified by Ganesh for the callid :: PNR2.0_3020 on 24/6/05
					IF EXISTS (
							SELECT 'x'
							FROM ep_published_ui_control_dtl ctrl(NOLOCK),
								es_comp_ctrl_type_mst_vw ctype(NOLOCK),
								ep_published_ui_section_dtl sec(NOLOCK)
							WHERE ctrl.customer_name = ctype.customer_name
								AND ctrl.project_name = ctype.project_name
								AND ctrl.process_name = ctype.process_name
								AND ctrl.component_name = ctype.component_name
								AND ctrl.control_type = ctype.ctrl_type_name
								AND ctrl.customer_name = sec.customer_name
								AND ctrl.project_name = sec.project_name
								AND ctrl.req_no = sec.req_no
								AND ctrl.process_name = sec.process_name
								AND ctrl.component_name = sec.component_name
								AND ctrl.activity_name = sec.activity_name
								AND ctrl.ui_name = sec.ui_name
								AND ctrl.page_bt_synonym = sec.page_bt_synonym
								AND ctrl.section_bt_synonym = sec.section_bt_synonym
								AND ctrl.customer_name = @engg_customer_name
								AND ctrl.project_name = @engg_project_name
								AND ctrl.process_name = @process_name
								AND ctrl.req_no = @engg_req_no
								AND ctrl.component_name = @engg_component
								AND ctrl.activity_name = @activity_name
								AND ctrl.ui_name = @ui_name_tmp
								AND ctrl.page_bt_synonym = @page_bt_synonym_tmp
								AND isnull(sec.section_type, 'MAIN') = 'MAIN'
								-- code modified by Ganesh for the bugid :: PNR2.0_3060 on 28/6/05
								AND (
									(
										ctype.visisble_flag = 'N'
										AND ctrl.control_type <> 'Filler'
										)
									OR (
										sec.visisble_flag = 'N'
										AND ctype.visisble_flag = 'Y'
										)
									)
							)
					BEGIN
						SELECT @section_bt_synonym_tmp = 'PRJHDNSECTION',
							@section_descr_tmp = 'PRJHDNSECTION',
							@parent_section_tmp = '',
							@visible_flag_tmp = 'N',
							@title_required_tmp = 'N',
							@border_required_tmp = 'N',
							@sectitle_align_tmp = 'LEFT',
							--Code Modified for bugId : PNR2.0_9025
							@section_widthscalemode_tmp = 'px',
							--@section_width_tmp   = 10
							@section_width_tmp = 0 -- code modified for bugid:PNR2.0_9777

						-- Insert UI Entry
						SELECT @xml_seq_tmp = @xml_seq_tmp + 1

						INSERT INTO ep_genxml_tmp (
							customer_name,
							project_name,
							req_no,
							process_name,
							component_name,
							activity_name,
							guid,
							gen_xml,
							seq_no
							)
						VALUES (
							@engg_customer_name,
							@engg_project_name,
							@engg_req_no,
							@process_name,
							@engg_component,
							@activity_name,
							@guid,
							'<Section Name="' + ltrim(rtrim(@section_bt_synonym_tmp)) + '" ' + 'SectionCaption="' + ltrim(rtrim(@section_descr_tmp)) + '" ' + 'PageName="' + ltrim(rtrim(@page_bt_synonym_tmp)) + '" ' + 'ILBOName="' + ltrim(rtrim(@ui_name_tmp)) + '" ' + 'ActivityName="' + ltrim(rtrim(@activity_name)) + '" ' + 'ComponentName="' + ltrim(rtrim(@engg_component)) + '" ' + 'ParentSection="' + ltrim(rtrim(@parent_section_tmp)) + '" ' + 'VisibleFlag="' + ltrim(rtrim(@visible_flag_tmp)) + '" ' + 'TitleRequired="' + ltrim
(rtrim(@title_required_tmp)) + '" ' + 'BorderRequired="' + ltrim(rtrim(@border_required_tmp)) + '" ' + 'TitleAlignment="' + ltrim(rtrim(@sectitle_align_tmp)) + '" ' + 'SectionType="MAIN" ' +
							--Code Modified For BugId : PNR2.0_7273
							'Height="' + ltrim(rtrim(isnull(@section_height_tmp, ''))) + '" ' + 'Width="' + ltrim(rtrim(isnull(@section_width_tmp, ''))) + '" ' + 'HeightScaleMode="' + ltrim(rtrim(isnull(@section_heightscalemode_tmp, 'px'))) + '" ' + 'WidthScaleMode="' + ltrim
(rtrim(isnull(@section_widthscalemode_tmp, 'px'))) + '" ' + 'HOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, @horder_tmp), 3))) + '" ' + 'VOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, 1), 3))) + '" ' + 'MappedControlId="' + ltrim(rtrim(isnull(@mapped_sec_controlid, ''))) + '" ' + 'MappedViewName="' + ltrim(rtrim(isnull(@mapped_sec_viewname, ''))) + '" ' + 'SectionPrefixClass="' + ltrim(rtrim(isnull(@section_prefix_class, ''))) + '" ' +
							--'IsStatic="'		+ ltrim(rtrim(isnull(@isstatic,'N')))+'"/>',@xml_seq_tmp)
							'SectionCollapseMode="' + ltrim(rtrim(isnull(@section_collapse_mode, ''))) + '" ' + 
							'SectionCollapseable="' + ltrim(rtrim(isnull(@section_collapseable, ''))) +
							'TitleIcon="'     + ltrim(rtrim(isnull(@TitleIcon,'')))  + '" ' +  --TECH-72114
							'"/>',
							@xml_seq_tmp
							)
					END
				END
				ELSE
				BEGIN
					IF EXISTS (
							SELECT 'x'
							FROM ep_ui_control_dtl ctrl(NOLOCK),
								es_comp_ctrl_type_mst_vw ctype(NOLOCK),
								ep_ui_section_dtl sec(NOLOCK)
							WHERE ctrl.customer_name = ctype.customer_name
								AND ctrl.project_name = ctype.project_name
								AND ctrl.process_name = ctype.process_name
								AND ctrl.component_name = ctype.component_name
								AND ctrl.control_type = ctype.ctrl_type_name
								AND ctrl.customer_name = sec.customer_name
								AND ctrl.project_name = sec.project_name
								AND ctrl.process_name = sec.process_name
								AND ctrl.component_name = sec.component_name
								AND ctrl.activity_name = sec.activity_name
								AND ctrl.ui_name = sec.ui_name
								AND ctrl.page_bt_synonym = sec.page_bt_synonym
								AND ctrl.section_bt_synonym = sec.section_bt_synonym
								AND ctrl.customer_name = @engg_customer_name
								AND ctrl.project_name = @engg_project_name
								AND ctrl.process_name = @process_name
								AND ctrl.component_name = @engg_component
								AND ctrl.activity_name = @activity_name
								AND ctrl.ui_name = @ui_name_tmp
								AND ctrl.page_bt_synonym = @page_bt_synonym_tmp
								AND isnull(sec.section_type, 'MAIN') = 'MAIN'
								AND (
									(
										ctype.visisble_flag = 'N'
										AND ctrl.control_type <> 'Filler'
										)
									OR (
										sec.visisble_flag = 'N'
										AND ctype.visisble_flag = 'Y'
										)
									)
							)
					BEGIN
						SELECT @section_bt_synonym_tmp = 'PRJHDNSECTION',
							@section_descr_tmp = 'PRJHDNSECTION',
							@parent_section_tmp = '',
							@visible_flag_tmp = 'N',
							@title_required_tmp = 'N',
							@border_required_tmp = 'N',
							@sectitle_align_tmp = 'LEFT',
							--Code Modified for bugId : PNR2.0_9025
							@section_widthscalemode_tmp = 'px',
							--@section_width_tmp   = 10
							@section_width_tmp = 0 -- code modified for bugid:PNR2.0_9777

						-- Insert UI Entry
						SELECT @xml_seq_tmp = @xml_seq_tmp + 1

						INSERT INTO ep_genxml_tmp (
							customer_name,
							project_name,
							req_no,
							process_name,
							component_name,
							activity_name,
							guid,
							gen_xml,
							seq_no
							)
						VALUES (
							@engg_customer_name,
							@engg_project_name,
							@engg_req_no,
							@process_name,
							@engg_component,
							@activity_name,
							@guid,
							'<Section Name="' + ltrim(rtrim(@section_bt_synonym_tmp)) + '" ' + 'SectionCaption="' + ltrim(rtrim(@section_descr_tmp)) + '" ' + 'PageName="' + ltrim(rtrim(@page_bt_synonym_tmp)) + '" ' + 'ILBOName="' + ltrim(rtrim(@ui_name_tmp)) + '" ' + 'ActivityName="' + ltrim(rtrim(@activity_name)) + '" ' + 'ComponentName="' + ltrim(rtrim(@engg_component)) + '" ' + 'ParentSection="' + ltrim(rtrim(@parent_section_tmp)) + '" ' + 'VisibleFlag="' + ltrim(rtrim(@visible_flag_tmp)) + '" ' + 'TitleRequired="' + ltrim
(rtrim(@title_required_tmp)) + '" ' + 'BorderRequired="' + ltrim(rtrim(@border_required_tmp)) + '" ' + 'TitleAlignment="' + ltrim(rtrim(@sectitle_align_tmp)) + '" ' + 'SectionType="MAIN" ' +
							--Code Modified For BugId : PNR2.0_7273
							'Height="' + ltrim(rtrim(isnull(@section_height_tmp, ''))) + '" ' + 'Width="' + ltrim(rtrim(isnull(@section_width_tmp, ''))) + '" ' + 'HeightScaleMode="' + ltrim(rtrim(isnull(@section_heightscalemode_tmp, 'px'))) + '" ' + 'WidthScaleMode="' + ltrim
(rtrim(isnull(@section_widthscalemode_tmp, 'px'))) + '" ' + 'HOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, @horder_tmp), 3))) + '" ' + 'VOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, 1), 3))) + '" ' + 'MappedControlId="' + ltrim(rtrim(isnull(@mapped_sec_controlid, ''))) + '" ' + 'MappedViewName="' + ltrim(rtrim(isnull(@mapped_sec_viewname, ''))) + '" ' + 'SectionPrefixClass="' + ltrim(rtrim(isnull(@section_prefix_class, ''))) + '" ' +
							--'IsStatic="'		+ ltrim(rtrim(isnull(@isstatic,'N')))+'"/>',@xml_seq_tmp)
							'SectionCollapseMode="' + ltrim(rtrim(isnull(@section_collapse_mode, ''))) + '" ' + 
							'SectionCollapseable="' + ltrim(rtrim(isnull(@section_collapseable, ''))) + '" ' + 
							'TitleIcon="'     + ltrim(rtrim(isnull(@TitleIcon,'')))  + '" ' +  --TECH-72114
							'CarouselNavigation="' + ltrim(rtrim(isnull(@CarouselNavigation, ''))) + '"/>',
							@xml_seq_tmp
							)
					END
				END
			END

			CLOSE secpagecurs

			DEALLOCATE secpagecurs

			-- Insert Closing entry for Sections
			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'</Sections>',
				@xml_seq_tmp
				)

			-- Added by feroz for list edit
			--declare #maplist table -- code modified by gopinath S for the call ID PNR2.0_24034
			CREATE TABLE #maplist -- code modified by gopinath S for the call ID PNR2.0_24034
				(
				activityname VARCHAR(60),
				ilbocode VARCHAR(60),
				controlid VARCHAR(60),
				viewname VARCHAR(60),
				listedit VARCHAR(60),
				instance INT
				)

			IF @pubflag = 'P'
				INSERT INTO #maplist -- code modified by gopinath S for the call ID PNR2.0_24034
				EXEC de_listedit_ctrl_map @engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@process_name,
					@engg_component,
					@pubflag,
					'Preview'
			ELSE
				INSERT INTO #maplist -- code modified by gopinath S for the call ID PNR2.0_24034
				EXEC de_listedit_ctrl_map @engg_customer_name,
					@engg_project_name,
					'Base',
					@process_name,
					@engg_component,
					@pubflag,
					'Preview'

			-- Added by feroz for list edit
			-- Insert Base Entry for Controls
			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'<Controls>',
				@xml_seq_tmp
				)

			-- code modified by shafina on 04-Aug-2004 for PREVIEWENG203ACC_000084
			-- Fetch Controls
			IF @ui_format_tmp = 'BES'
			BEGIN
				IF @ctxt_service_in IN ('BulkGenerate')
					AND @pubflag = 'P'
				BEGIN
					DECLARE ctrlcurs INSENSITIVE CURSOR
					FOR
					SELECT upper(control_bt_synonym),
						isnull(bt_synonym_caption, control_bt_synonym),
						upper(control_id),
						upper(isnull(data_type, 'char')),
						isnull(length, 20),
						isnull(control_type, ''),
						upper(base_ctrl_type),
						ctrl.horder,
						ctrl.vorder,
						isnull(visisble_length, 0),
						isnull(ctrl.proto_tooltip, ''),
						isnull(ctrl.sample_data, ''),
						upper(ctrl.page_bt_synonym) AS 'page_bt_synonym',
						upper(ctrl.section_bt_synonym) AS 'section_bt_synonym',
						upper(ltrim(rtrim(mandatory_flag))),
						upper(ltrim(rtrim(ctype.visisble_flag))),
						upper(ltrim(rtrim(editable_flag))),
						upper(ltrim(rtrim(caption_req))),
						upper(ltrim(rtrim(select_flag))),
						upper(ltrim(rtrim(zoom_req))),
						upper(ltrim(rtrim(help_req))),
						upper(ltrim(rtrim(ellipses_req))),
						isnull(visisble_rows, 0),
						isnull(data_column_width, 0),
						isnull(label_column_width, 0),
						upper(isnull(caption_wrap, 'Y')),
						upper(isnull(caption_alignment, 'LEFT')),
						upper(isnull(caption_position, 'LEFT')),
						isnull(control_doc, ''),
						isnull(ctrl.order_seq, 1) AS order_seq,
						upper(isnull(ctrl_position, 'LEFT')),
						upper(isnull(LabelClass, '')),
						upper(isnull(controlclass, '')),
						upper(isnull(delete_req, 'N')),
						upper(isnull(password_char, 'N')),
						upper(isnull(tskimg_class, '')),
						upper(isnull(hlpimg_class, '')),
						upper(isnull(data_column_scalemode, '%')),
						upper(isnull(label_column_scalemode, '%')),
						sec.horder,
						sec.vorder,
						upper(isnull(html_txt_area, 'N')),
						upper(isnull(Spin_required, 'N')),
						upper(isnull(spin_up_image, 'spinup.gif')),
						isnull(spin_down_image, 'spindown.gif'),
						--code modified for bugId : PNR2.0_10741
						isnull(report_req, 'N'),
						isnull(InPlace_Calendar, 'N'),
						isnull(EditMask, ''), -- Inplace Calendar and Edit Mask Feature added by Feroz
						isnull(AccessKey, ''), -- Added by Jeya
						-- Code addition for PNR2.0_20849 starts
						convert(VARCHAR, NoofLinesPerRow),
						isnull(convert(VARCHAR, RowHeight), ''),
						isnull(Vscrollbar_Req, 'N'),
						-- Code addition for PNR2.0_20849 ends
						-- Added By Feroz
						isnull(bulletlink_req, 'N'),
						isnull(buttoncombo_req, 'N'),
						isnull(associatedlist_req, 'N'),
						isnull(onfocustask_req, 'N'),
						isnull(listrefilltask_req, 'N'),
						isnull(dataascaption, 'N'),
						isnull(ListEdit_NoofColumns, 0),
						isnull(attach_document, 'N'),
						isnull(image_upload, 'N'),
						isnull(inplace_image, 'N'),
						isnull(image_row_height, 0),
						isnull(image_icon, 'N'),
						isnull(relative_url_path, ''),
						isnull(relative_document_path, ''),
						isnull(relative_image_path, ''),
						isnull(save_doc_content_to_db, 'N'),
						isnull(save_image_content_to_db, 'N'),
						isnull(Date_highlight, 'N'),
						-- Code addition for PNR2.0_21576 starts
						isnull(gridlite_req, 'N'),
						-- Code addition for PNR2.0_21576 ends
						isnull(freezecount, 0),
						isnull(Lite_Attach_Document, 'N'),
						isnull(Browse_Button_Enable, 'N'),
						isnull(Delete_Button_Enable, 'N'), --added for PNR2.0_26860 -- Code Modified for the Bug ID : PNR2.0_27796
						isnull(image_row_width, 0),
						isnull(image_preview_height, 0),
						isnull(image_preview_width, 0),
						isnull(image_preview_req, 'N'),
						isnull(Accpet_Type, ''),
						isnull(Lite_Attach_Image, 'N'), -- PNR2.0_28319
						isnull(Label_link, 'N'), --Code Added for the Bug ID PNR2.0_36309
						isnull(captiontype, 'Text'),
						isnull(controlstyle, 'Default'),
						isnull(controlimage, '') --Code added for Bug ID:PLF2.0_00961
						,
						isnull(IsListBox, ''),
						isnull(Toolbar_Not_Req, 'N'),
						isnull(ColumnBorder_Not_Req, 'N'),
						isnull(RowBorder_Not_Req, 'N'),
						isnull(PagenavigationOnly, 'N'),
						isnull(RowNO_Not_Req, 'N'),
						isnull(ButtonHome_Req, 'N'),
						isnull(ButtonPrevious_Req, 'N'),
						isnull(colspan, ''),
						isnull(rowspan, ''),
						isnull(ToolTip_Not_Req, 'N'),
						isnull(columncaption_Not_Req, 'N'),
						isnull(Border_Not_Req, 'N'),
						isnull(IsModal, 'N'),
						isnull(Alternate_Color_Req, 'N'),
						isnull(Map_In_Req, 'N'),
						isnull(Map_Out_Req, 'N') --PLF2.0_03057--shakthi
						,
						isnull(FileSize, ''),
						isnull(ISDeviceInfo, 'N'),
						isnull(Datagrid, 'N'),
						isnull(Email, 'N'),
						isnull(TemplateID, ''),
						isnull(Phone, 'N'),
						isnull(StaticCaption, 'N'),
						isnull(ctype.Orientation, 'Horizontal'), --TECH-75230
						isnull(Listcontrol, 'N'),
						isnull(ctype.col_caption_align, ''),
						isnull(ctype.Gridheaderstyle, ''),
						isnull(ctype.Gridtoolbarstyle, ''),
						isnull(ctype.preevent, ''),
						isnull(ctype.postevent, ''),
						isnull(ctype.ishijri, 'N'),
						isnull(ctype.avn_download, ''),
						isnull(ctype.spin_system_task, ''),
						isnull(ispivot, 'N'),
						isnull(TemplateCategory, ''),
						isnull(TemplateSpecific, ''),
						isnull(ctype.RatingType, ''),
						isnull(CaptchaData, ''),
						isnull(Control_class_ext6, ''),
						upper(isnull(renderas, '')),
						isnull(icon_class, ''),
						isnull(icon_position, ''),
						isnull(preserve_gridposition, '')
					FROM ep_published_ui_control_dtl ctrl(NOLOCK),
						ep_published_ui_section_dtl sec(NOLOCK),
						@ep_published_comp_glossary_mst gls,
						es_comp_ctrl_type_mst_vw ctype(NOLOCK)
					WHERE ctrl.customer_name = sec.customer_name
						AND ctrl.project_name = sec.project_name
						AND ctrl.req_no = sec.req_no
						AND ctrl.process_name = sec.process_name
						AND ctrl.component_name = sec.component_name
						AND ctrl.activity_name = sec.activity_name
						AND ctrl.ui_name = sec.ui_name
						AND ctrl.page_bt_synonym = sec.page_bt_synonym
						AND ctrl.section_bt_synonym = sec.section_bt_synonym
						AND ctrl.customer_name = gls.customer_name
						AND ctrl.project_name = gls.project_name
						AND ctrl.req_no = gls.req_no
						AND ctrl.process_name = gls.process_name
						AND ctrl.component_name = gls.component_name
						AND ctrl.control_bt_synonym = gls.bt_synonym_name
						AND ctrl.customer_name = ctype.customer_name
						AND ctrl.project_name = ctype.project_name
						AND ctrl.process_name = ctype.process_name
						AND ctrl.component_name = ctype.component_name
						AND ctrl.control_type = ctype.ctrl_type_name
						AND sec.customer_name = @engg_customer_name
						AND sec.project_name = @engg_project_name
						AND sec.req_no = @engg_req_no
						AND sec.process_name = @process_name
						AND sec.component_name = @engg_component
						AND sec.activity_name = @activity_name
						AND sec.ui_name = @ui_name_tmp
						--and  isnull(sec.section_type,'MAIN') = 'MAIN'
						AND (
							ctype.visisble_flag = 'Y'
							OR ctrl.control_type = 'Filler'
							)
						AND sec.visisble_flag = 'Y'
						--AND gls.languageid = @language_code
					
					UNION
					
					SELECT upper(ctrl.control_bt_synonym),
						isnull(bt_synonym_caption, ctrl.control_bt_synonym),
						upper(control_id),
						upper(isnull(data_type, 'char')),
						isnull(length, 20),
						isnull(control_type, ''),
						upper(base_ctrl_type),
						ctrl.horder,
						ctrl.vorder,
						isnull(visisble_length, 0),
						isnull(proto_tooltip, ''),
						isnull(sample_data, ''),
						upper(ctrl.page_bt_synonym) AS 'page_bt_synonym',
						upper(ctrl.section_bt_synonym) AS 'section_bt_synonym',
						'Y',
						'Y',
						'Y',
						'Y',
						'N',
						'N',
						'N',
						'N',
						'0',
						isnull(data_column_width, 0),
						isnull(label_column_width, 0),
						'Y',
						'LEFT',
						'LEFT',
						isnull(control_doc, ''),
						isnull(ctrl.order_seq, 1) AS order_seq,
						'LEFT',
						'',
						'',
						'N',
						'N',
						'',
						'',
						upper(isnull(data_column_scalemode, '%')),
						upper(isnull(label_column_scalemode, '%')),
						sec.horder,
						sec.vorder,
						'N',
						'N',
						'',
						'',
						--code modified for bugId : PNR2.0_10741
						'N',
						'N',
						'',
						isnull(AccessKey, ''), -- Added by Jeya
						-- Code addition for PNR2.0_20849 starts
						'',
						'',
						'',
						-- Code addition for PNR2.0_20849 ends
						-- Added By Feroz
						'N',
						'N',
						'N',
						'N',
						'N',
						'N',
						0,
						'N',
						'N',
						'N',
						0,
						'N',
						'',
						'',
						'',
						'N',
						'N',
						'N',
						-- Code addition for PNR2.0_21576 starts
						'',
						-- Code addition for PNR2.0_21576 ends
						isnull(freezecount, 0),
						'N',
						'N',
						'N', --added for PNR2.0_26860 -- Code Modified for the Bug ID : PNR2.0_27796
						0,
						0,
						0,
						'N',
						'',
						'N',
						'N', --PNR2.0_28319,PNR2.0_36309
						'',
						'',
						'' --Code added for Bug ID:PLF2.0_00961
						,
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'N',
						'N',
						'N',
						'',
						'N',
						'N',
						'Horizontal',
						'N',
						'',
						'',
						'',
						'',
						'' --PLF2.0_03057
						,
						'N',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						''
					FROM ep_published_ui_control_dtl ctrl(NOLOCK),
						ep_published_ui_section_dtl sec(NOLOCK),
						@ep_published_comp_glossary_mst gls,
						ep_published_comp_stat_ctrl_type_mst ctype(NOLOCK)
					WHERE ctrl.customer_name = sec.customer_name
						AND ctrl.project_name = sec.project_name
						AND ctrl.req_no = sec.req_no
						AND ctrl.process_name = sec.process_name
						AND ctrl.component_name = sec.component_name
						AND ctrl.activity_name = sec.activity_name
						AND ctrl.ui_name = sec.ui_name
						AND ctrl.page_bt_synonym = sec.page_bt_synonym
						AND ctrl.section_bt_synonym = sec.section_bt_synonym
						AND ctrl.customer_name = gls.customer_name
						AND ctrl.project_name = gls.project_name
						AND ctrl.req_no = gls.req_no
						AND ctrl.process_name = gls.process_name
						AND ctrl.component_name = gls.component_name
						AND ctrl.control_bt_synonym = gls.bt_synonym_name
						AND ctrl.customer_name = ctype.customer_name
						AND ctrl.project_name = ctype.project_name
						AND ctrl.process_name = ctype.process_name
						AND ctrl.req_no = ctype.req_no
						AND ctrl.component_name = ctype.component_name
						AND ctrl.control_type = ctype.ctrl_type_name
						AND sec.customer_name = @engg_customer_name
						AND sec.project_name = @engg_project_name
						AND sec.req_no = @engg_req_no
						AND sec.process_name = @process_name
						AND sec.component_name = @engg_component
						AND sec.activity_name = @activity_name
						AND sec.ui_name = @ui_name_tmp
						AND isnull(sec.section_type, 'MAIN') = 'MAIN'
						--AND gls.languageid = @language_code
					-- Added by Feroz For extjs start -- PNR2.0_1790
					
					UNION
					
					SELECT upper(control_bt_synonym),
						isnull(bt_synonym_caption, control_bt_synonym),
						upper(control_id),
						upper(isnull(data_type, 'char')),
						isnull(length, 20),
						isnull(control_type, ''),
						upper(base_ctrl_type),
						ctrl.horder,
						ctrl.vorder,
						isnull(visisble_length, 0),
						isnull(proto_tooltip, ''),
						isnull(sample_data, ''),
						upper(ctrl.page_bt_synonym) AS 'page_bt_synonym',
						upper(ctrl.section_bt_synonym) AS 'section_bt_synonym',
						upper(ltrim(rtrim(mandatory_flag))),
						upper(ltrim(rtrim(ctype.visisble_flag))),
						upper(ltrim(rtrim(editable_flag))),
						upper(ltrim(rtrim(caption_req))),
						upper(ltrim(rtrim(select_flag))),
						upper(ltrim(rtrim(zoom_req))),
						upper(ltrim(rtrim(help_req))),
						upper(ltrim(rtrim(ellipses_req))),
						isnull(visisble_rows, 0),
						isnull(data_column_width, 0),
						isnull(label_column_width, 0),
						upper(isnull(caption_wrap, 'Y')),
						upper(isnull(caption_alignment, 'LEFT')),
						upper(isnull(caption_position, 'LEFT')),
						isnull(control_doc, ''),
						isnull(ctrl.order_seq, 1) AS order_seq,
						upper(isnull(ctrl_position, 'LEFT')),
						upper(isnull(LabelClass, '')),
						upper(isnull(controlclass, '')),
						upper(isnull(delete_req, 'N')),
						upper(isnull(password_char, 'N')),
						upper(isnull(tskimg_class, '')),
						upper(isnull(hlpimg_class, '')),
						upper(isnull(data_column_scalemode, '%')),
						upper(isnull(label_column_scalemode, '%')),
						sec.horder,
						sec.vorder,
						upper(isnull(html_txt_area, 'N')),
						upper(isnull(Spin_required, 'N')),
						upper(isnull(spin_up_image, 'spinup.gif')),
						isnull(spin_down_image, 'spindown.gif'),
						--code modified for bugId : PNR2.0_10741
						isnull(report_req, 'N'),
						isnull(InPlace_Calendar, 'N'),
						isnull(EditMask, ''), -- Inplace Calendar and Edit Mask Feature added by Feroz
						isnull(AccessKey, ''), -- Added by Jeya
						-- Code addition for PNR2.0_20849 starts
						convert(VARCHAR, NoofLinesPerRow),
						isnull(convert(VARCHAR, RowHeight), ''),
						isnull(Vscrollbar_Req, 'N'),
						-- Added By Feroz
						isnull(bulletlink_req, 'N'),
						isnull(buttoncombo_req, 'N'),
						isnull(associatedlist_req, 'N'),
						isnull(onfocustask_req, 'N'),
						isnull(listrefilltask_req, 'N'),
						isnull(dataascaption, 'N'),
						isnull(ListEdit_NoofColumns, 0),
						isnull(attach_document, 'N'),
						isnull(image_upload, 'N'),
						isnull(inplace_image, 'N'),
						isnull(image_row_height, 0),
						isnull(image_icon, 'N'),
						isnull(relative_url_path, ''),
						isnull(relative_document_path, ''),
						isnull(relative_image_path, ''),
						isnull(save_doc_content_to_db, 'N'),
						isnull(save_image_content_to_db, 'N'),
						isnull(Date_highlight, 'N'),
						-- Code addition for PNR2.0_21576 starts
						isnull(gridlite_req, 'N'),
						-- Code addition for PNR2.0_21576 ends
						isnull(freezecount, 0),
						isnull(Lite_Attach_Document, 'N'),
						isnull(Browse_Button_Enable, 'N'),
						isnull(Delete_Button_Enable, 'N'), --added for PNR2.0_26860 -- Code Modified for the Bug ID : PNR2.0_27796
						isnull(image_row_width, 0),
						isnull(image_preview_height, 0),
						isnull(image_preview_width, 0),
						isnull(image_preview_req, 'N'),
						isnull(Accpet_Type, ''),
						isnull(Lite_Attach_Image, 'N'), -- PNR2.0_28319
						isnull(Label_link, 'N'), --Code Added for the Bug ID PNR2.0_36309
						isnull(captiontype, 'Text'),
						isnull(controlstyle, 'Default'),
						isnull(controlimage, '') --Code added for Bug ID:PLF2.0_00961
						,
						isnull(IsListBox, ''),
						isnull(Toolbar_Not_Req, 'N'),
						isnull(ColumnBorder_Not_Req, 'N'),
						isnull(RowBorder_Not_Req, 'N'),
						isnull(PagenavigationOnly, 'N'),
						isnull(RowNO_Not_Req, 'N'),
						isnull(ButtonHome_Req, 'N'),
						isnull(ButtonPrevious_Req, 'N'),
						isnull(colspan, ''),
						isnull(rowspan, ''),
						isnull(ToolTip_Not_Req, 'N'),
						isnull(columncaption_Not_Req, 'N'),
						isnull(Border_Not_Req, 'N'),
						isnull(IsModal, 'N'),
						isnull(Alternate_Color_Req, 'N'),
						isnull(Map_In_Req, 'N'),
						isnull(Map_Out_Req, 'N'),
						isnull(FileSize, ''),
						isnull(ISDeviceInfo, 'N'),
						isnull(Datagrid, 'N'),
						isnull(Email, 'N'),
						isnull(TemplateID, ''),
						isnull(Phone, 'N'),
						isnull(StaticCaption, 'N'),
						isnull(ctype.Orientation, 'Horizontal'), ----TECH-75230
						isnull(Listcontrol, 'N'),
						isnull(ctype.col_caption_align, ''),
						isnull(ctype.Gridheaderstyle, ''),
						isnull(ctype.Gridtoolbarstyle, ''),
						isnull(ctype.preevent, ''),
						isnull(ctype.postevent, '')
						--PLF2.0_03057
						,
						isnull(ctype.ishijri, 'N'),
						isnull(ctype.avn_download, ''),
						isnull(ctype.spin_system_task, ''),
						isnull(ispivot, 'N'),
						isnull(TemplateCategory, ''),
						isnull(TemplateSpecific, ''),
						isnull(ctype.RatingType, ''),
						isnull(CaptchaData, ''),
						isnull(Control_class_ext6, ''),
						upper(isnull(renderas, '')),
						isnull(icon_class, ''),
						isnull(icon_position, ''),
						isnull(preserve_gridposition, '')
					FROM ep_published_ui_control_dtl ctrl(NOLOCK),
						ep_published_ui_section_dtl sec(NOLOCK),
						@ep_published_comp_glossary_mst gls,
						es_comp_ctrl_type_mst_vw ctype(NOLOCK)
					WHERE ctrl.customer_name = sec.customer_name
						AND ctrl.project_name = sec.project_name
						AND ctrl.req_no = sec.req_no
						AND ctrl.process_name = sec.process_name
						AND ctrl.component_name = sec.component_name
						AND ctrl.activity_name = sec.activity_name
						AND ctrl.ui_name = sec.ui_name
						AND ctrl.page_bt_synonym = sec.page_bt_synonym
						AND ctrl.section_bt_synonym = sec.section_bt_synonym
						AND ctrl.customer_name = gls.customer_name
						AND ctrl.project_name = gls.project_name
						AND ctrl.req_no = gls.req_no
						AND ctrl.process_name = gls.process_name
						AND ctrl.component_name = gls.component_name
						AND ctrl.control_bt_synonym = gls.bt_synonym_name
						AND ctrl.customer_name = ctype.customer_name
						AND ctrl.project_name = ctype.project_name
						AND ctrl.process_name = ctype.process_name
						AND ctrl.component_name = ctype.component_name
						AND ctrl.control_type = ctype.ctrl_type_name
						AND sec.customer_name = @engg_customer_name
						AND sec.project_name = @engg_project_name
						AND sec.req_no = @engg_req_no
						AND sec.process_name = @process_name
						AND sec.component_name = @engg_component
						AND sec.activity_name = @activity_name
						AND sec.ui_name = @ui_name_tmp
						AND isnull(sec.section_type, 'MAIN') NOT IN (
							'MAIN',
							'TREE',
							'CHART'
							)
						AND ctype.visisble_flag = 'N'
						AND (
							sec.visisble_flag = 'Y'
							OR sec.section_type = 'PopUp'
							) --Code added for Bug ID:PLF2.0_00961
						--AND gls.languageid = @language_code
					
					UNION
					
					SELECT upper(control_bt_synonym),
						isnull(bt_synonym_caption, control_bt_synonym),
						upper(control_id),
						upper(isnull(data_type, 'char')),
						isnull(length, 20),
						isnull(control_type, ''),
						upper(base_ctrl_type),
						ctrl.horder,
						ctrl.vorder,
						isnull(visisble_length, 0),
						isnull(proto_tooltip, ''),
						isnull(sample_data, ''),
						upper(ctrl.page_bt_synonym) AS 'page_bt_synonym',
						upper(ctrl.section_bt_synonym) AS 'section_bt_synonym',
						upper(ltrim(rtrim(mandatory_flag))),
						upper(ltrim(rtrim(ctype.visisble_flag))),
						upper(ltrim(rtrim(editable_flag))),
						upper(ltrim(rtrim(caption_req))),
						upper(ltrim(rtrim(select_flag))),
						upper(ltrim(rtrim(zoom_req))),
						upper(ltrim(rtrim(help_req))),
						upper(ltrim(rtrim(ellipses_req))),
						isnull(visisble_rows, 0),
						isnull(data_column_width, 0),
						isnull(label_column_width, 0),
						upper(isnull(caption_wrap, 'Y')),
						upper(isnull(caption_alignment, 'LEFT')),
						upper(isnull(caption_position, 'LEFT')),
						isnull(control_doc, ''),
						isnull(ctrl.order_seq, 1) AS order_seq,
						upper(isnull(ctrl_position, 'LEFT')),
						upper(isnull(LabelClass, '')),
						upper(isnull(controlclass, '')),
						upper(isnull(delete_req, 'N')),
						upper(isnull(password_char, 'N')),
						upper(isnull(tskimg_class, '')),
						upper(isnull(hlpimg_class, '')),
						upper(isnull(data_column_scalemode, '%')),
						upper(isnull(label_column_scalemode, '%')),
						sec.horder,
						sec.vorder,
						upper(isnull(html_txt_area, 'N')),
						upper(isnull(Spin_required, 'N')),
						upper(isnull(spin_up_image, 'spinup.gif')),
						isnull(spin_down_image, 'spindown.gif'),
						--code modified for bugId : PNR2.0_10741
						isnull(report_req, 'N'),
						isnull(InPlace_Calendar, 'N'),
						isnull(EditMask, ''), -- Inplace Calendar and Edit Mask Feature added by Feroz
						isnull(AccessKey, ''), -- Added by Jeya
						-- Code addition for PNR2.0_20849 starts
						convert(VARCHAR, NoofLinesPerRow),
						isnull(convert(VARCHAR, RowHeight), ''),
						isnull(Vscrollbar_Req, 'N'),
						-- Code addition for PNR2.0_20849 ends
						-- Added By Feroz
						isnull(bulletlink_req, 'N'),
						isnull(buttoncombo_req, 'N'),
						isnull(associatedlist_req, 'N'),
						isnull(onfocustask_req, 'N'),
						isnull(listrefilltask_req, 'N'),
						isnull(dataascaption, 'N'),
						isnull(ListEdit_NoofColumns, 0),
						isnull(attach_document, 'N'),
						isnull(image_upload, 'N'),
						isnull(inplace_image, 'N'),
						isnull(image_row_height, 0),
						isnull(image_icon, 'N'),
						isnull(relative_url_path, ''),
						isnull(relative_document_path, ''),
						isnull(relative_image_path, ''),
						isnull(save_doc_content_to_db, 'N'),
						isnull(save_image_content_to_db, 'N'),
						isnull(Date_highlight, 'N'),
						-- Code addition for PNR2.0_21576 starts
						isnull(gridlite_req, 'N'),
						-- Code addition for PNR2.0_21576 ends
						isnull(freezecount, 0),
						isnull(Lite_Attach_Document, 'N'),
						isnull(Browse_Button_Enable, 'N'),
						isnull(Delete_Button_Enable, 'N'), --added for PNR2.0_26860 -- Code Modified for the Bug ID : PNR2.0_27796
						isnull(image_row_width, 0),
						isnull(image_preview_height, 0),
						isnull(image_preview_width, 0),
						isnull(image_preview_req, 'N'),
						isnull(Accpet_Type, ''),
						isnull(Lite_Attach_Image, 'N'), -- PNR2.0_28319
						isnull(Label_link, 'N'), --Code Added for the Bug ID PNR2.0_36309
						isnull(captiontype, 'Text'),
						isnull(controlstyle, 'Default'),
						isnull(controlimage, '') --Code added for Bug ID:PLF2.0_00961
						,
						isnull(IsListBox, ''),
						isnull(Toolbar_Not_Req, 'N'),
						isnull(ColumnBorder_Not_Req, 'N'),
						isnull(RowBorder_Not_Req, 'N'),
						isnull(PagenavigationOnly, 'N'),
						isnull(RowNO_Not_Req, 'N'),
						isnull(ButtonHome_Req, 'N'),
						isnull(ButtonPrevious_Req, 'N'),
						isnull(colspan, ''),
						isnull(rowspan, ''),
						isnull(ToolTip_Not_Req, 'N'),
						isnull(columncaption_Not_Req, 'N'),
						isnull(Border_Not_Req, 'N'),
						isnull(IsModal, 'N'),
						isnull(Alternate_Color_Req, 'N'), --PLF2.0_03057
						isnull(Map_In_Req, 'N'),
						isnull(Map_Out_Req, 'N'),
						isnull(FileSize, ''),
						isnull(ISDeviceInfo, 'N'),
						isnull(Datagrid, 'N'),
						isnull(Email, 'N'),
						isnull(TemplateID, ''),
						isnull(Phone, 'N'),
						isnull(StaticCaption, 'N'),
						isnull(ctype.Orientation, 'Horizontal'), ----TECH-75230
						isnull(Listcontrol, 'N'),
						isnull(ctype.col_caption_align, ''),
						isnull(ctype.Gridheaderstyle, ''),
						isnull(ctype.Gridtoolbarstyle, ''),
						isnull(ctype.preevent, ''),
						isnull(ctype.postevent, ''),
						isnull(ctype.ishijri, 'N'),
						isnull(ctype.avn_download, ''),
						isnull(ctype.spin_system_task, ''),
						isnull(ispivot, 'N'),
						isnull(TemplateCategory, ''),
						isnull(TemplateSpecific, ''),
						isnull(ctype.RatingType, ''),
						isnull(CaptchaData, ''),
						isnull(Control_class_ext6, ''),
						upper(isnull(renderas, '')),
						isnull(icon_class, ''),
						isnull(icon_position, ''),
						isnull(preserve_gridposition, '')
					FROM ep_published_ui_control_dtl ctrl(NOLOCK),
						ep_published_ui_section_dtl sec(NOLOCK),
						@ep_published_comp_glossary_mst gls,
						es_comp_ctrl_type_mst_vw ctype(NOLOCK)
					WHERE ctrl.customer_name = sec.customer_name
						AND ctrl.project_name = sec.project_name
						AND ctrl.req_no = sec.req_no
						AND ctrl.process_name = sec.process_name
						AND ctrl.component_name = sec.component_name
						AND ctrl.activity_name = sec.activity_name
						AND ctrl.ui_name = sec.ui_name
						AND ctrl.page_bt_synonym = sec.page_bt_synonym
						AND ctrl.section_bt_synonym = sec.section_bt_synonym
						AND ctrl.customer_name = gls.customer_name
						AND ctrl.project_name = gls.project_name
						AND ctrl.req_no = gls.req_no
						AND ctrl.process_name = gls.process_name
						AND ctrl.component_name = gls.component_name
						AND ctrl.control_bt_synonym = gls.bt_synonym_name
						AND ctrl.customer_name = ctype.customer_name
						AND ctrl.project_name = ctype.project_name
						AND ctrl.process_name = ctype.process_name
						AND ctrl.component_name = ctype.component_name
						AND ctrl.control_type = ctype.ctrl_type_name
						AND sec.customer_name = @engg_customer_name
						AND sec.project_name = @engg_project_name
						AND sec.req_no = @engg_req_no
						AND sec.process_name = @process_name
						AND sec.component_name = @engg_component
						AND sec.activity_name = @activity_name
						AND sec.ui_name = @ui_name_tmp
						AND isnull(sec.section_type, 'MAIN') = 'MAIN'
						AND ctype.visisble_flag = 'N'
						AND sec.visisble_flag = 'Y'
						AND ctype.is_extjs_control = 'y'
						--AND gls.languageid = @language_code
					-- Added by feroz for extjs End -- PNR2.0_1790
					--Code added for Bug ID:PLF2.0_00961 starts
					
					UNION
					
					SELECT upper(control_bt_synonym),
						isnull(bt_synonym_caption, control_bt_synonym),
						upper(control_id),
						upper(isnull(data_type, 'char')),
						isnull(length, 20),
						isnull(control_type, ''),
						upper(base_ctrl_type),
						ctrl.horder,
						ctrl.vorder,
						isnull(visisble_length, 0),
						isnull(proto_tooltip, ''),
						isnull(sample_data, ''),
						upper(ctrl.page_bt_synonym) AS 'page_bt_synonym',
						upper(ctrl.section_bt_synonym) AS 'section_bt_synonym',
						upper(ltrim(rtrim(mandatory_flag))),
						upper(ltrim(rtrim(ctype.visisble_flag))),
						upper(ltrim(rtrim(editable_flag))),
						upper(ltrim(rtrim(caption_req))),
						upper(ltrim(rtrim(select_flag))),
						upper(ltrim(rtrim(zoom_req))),
						upper(ltrim(rtrim(help_req))),
						upper(ltrim(rtrim(ellipses_req))),
						isnull(visisble_rows, 0),
						isnull(data_column_width, 0),
						isnull(label_column_width, 0),
						upper(isnull(caption_wrap, 'Y')),
						upper(isnull(caption_alignment, 'LEFT')),
						upper(isnull(caption_position, 'LEFT')),
						isnull(control_doc, ''),
						isnull(ctrl.order_seq, 1) AS order_seq,
						upper(isnull(ctrl_position, 'LEFT')),
						upper(isnull(LabelClass, '')),
						upper(isnull(controlclass, '')),
						upper(isnull(delete_req, 'N')),
						upper(isnull(password_char, 'N')),
						upper(isnull(tskimg_class, '')),
						upper(isnull(hlpimg_class, '')),
						upper(isnull(data_column_scalemode, '%')),
						upper(isnull(label_column_scalemode, '%')),
						sec.horder,
						sec.vorder,
						upper(isnull(html_txt_area, 'N')),
						upper(isnull(Spin_required, 'N')),
						upper(isnull(spin_up_image, 'spinup.gif')),
						isnull(spin_down_image, 'spindown.gif'),
						isnull(report_req, 'N'),
						isnull(InPlace_Calendar, 'N'),
						isnull(EditMask, ''),
						isnull(AccessKey, ''),
						convert(VARCHAR, NoofLinesPerRow),
						isnull(convert(VARCHAR, RowHeight), ''),
						isnull(Vscrollbar_Req, 'N'),
						isnull(bulletlink_req, 'N'),
						isnull(buttoncombo_req, 'N'),
						isnull(associatedlist_req, 'N'),
						isnull(onfocustask_req, 'N'),
						isnull(listrefilltask_req, 'N'),
						isnull(dataascaption, 'N'),
						isnull(ListEdit_NoofColumns, 0),
						isnull(attach_document, 'N'),
						isnull(image_upload, 'N'),
						isnull(inplace_image, 'N'),
						isnull(image_row_height, 0),
						isnull(image_icon, 'N'),
						isnull(relative_url_path, ''),
						isnull(relative_document_path, ''),
						isnull(relative_image_path, ''),
						isnull(save_doc_content_to_db, 'N'),
						isnull(save_image_content_to_db, 'N'),
						isnull(Date_highlight, 'N'),
						isnull(gridlite_req, 'N'),
						isnull(freezecount, 0),
						isnull(Lite_Attach_Document, 'N'),
						isnull(Browse_Button_Enable, 'N'),
						isnull(Delete_Button_Enable, 'N'),
						isnull(image_row_width, 0),
						isnull(image_preview_height, 0),
						isnull(image_preview_width, 0),
						isnull(image_preview_req, 'N'),
						isnull(Accpet_Type, ''),
						isnull(Lite_Attach_Image, 'N'),
						isnull(Label_link, 'N'),
						isnull(captiontype, 'Text'),
						isnull(controlstyle, 'Default'),
						isnull(controlimage, ''),
						isnull(IsListBox, ''),
						isnull(Toolbar_Not_Req, 'N'),
						isnull(ColumnBorder_Not_Req, 'N'),
						isnull(RowBorder_Not_Req, 'N'),
						isnull(PagenavigationOnly, 'N'),
						isnull(RowNO_Not_Req, 'N'),
						isnull(ButtonHome_Req, 'N'),
						isnull(ButtonPrevious_Req, 'N'),
						isnull(colspan, ''),
						isnull(rowspan, ''),
						isnull(ToolTip_Not_Req, 'N'),
						isnull(columncaption_Not_Req, 'N'),
						isnull(Border_Not_Req, 'N'),
						isnull(IsModal, 'N'),
						isnull(Alternate_Color_Req, 'N'), --PLF2.0_03057
						isnull(Map_In_Req, 'N'),
						isnull(Map_Out_Req, 'N'),
						isnull(FileSize, ''),
						isnull(ISDeviceInfo, 'N'),
						isnull(Datagrid, 'N'),
						isnull(Email, 'N'),
						isnull(TemplateID, ''),
						isnull(Phone, 'N'),
						isnull(StaticCaption, 'N'),
						isnull(ctype.Orientation, 'Horizontal'), --TECH-75230
						isnull(Listcontrol, 'N'),
						isnull(ctype.col_caption_align, ''),
						isnull(ctype.Gridheaderstyle, ''),
						isnull(ctype.Gridtoolbarstyle, ''),
						isnull(ctype.preevent, ''),
						isnull(ctype.postevent, ''),
						isnull(ctype.ishijri, 'N'),
						isnull(ctype.avn_download, ''),
						isnull(ctype.spin_system_task, ''),
						isnull(ispivot, 'N'),
						isnull(TemplateCategory, ''),
						isnull(TemplateSpecific, ''),
						isnull(ctype.RatingType, ''),
						isnull(CaptchaData, ''),
						isnull(Control_class_ext6, ''),
						upper(isnull(renderas, '')),
						isnull(icon_class, ''),
						isnull(icon_position, ''),
						isnull(preserve_gridposition, '')
					FROM ep_published_ui_control_dtl ctrl(NOLOCK),
						ep_published_ui_section_dtl sec(NOLOCK),
						@ep_published_comp_glossary_mst gls,
						es_comp_ctrl_type_mst_vw ctype(NOLOCK)
					WHERE ctrl.customer_name = sec.customer_name
						AND ctrl.project_name = sec.project_name
						AND ctrl.req_no = sec.req_no
						AND ctrl.process_name = sec.process_name
						AND ctrl.component_name = sec.component_name
						AND ctrl.activity_name = sec.activity_name
						AND ctrl.ui_name = sec.ui_name
						AND ctrl.page_bt_synonym = sec.page_bt_synonym
						AND ctrl.section_bt_synonym = sec.section_bt_synonym
						AND ctrl.customer_name = gls.customer_name
						AND ctrl.project_name = gls.project_name
						AND ctrl.req_no = gls.req_no
						AND ctrl.process_name = gls.process_name
						AND ctrl.component_name = gls.component_name
						AND ctrl.control_bt_synonym = gls.bt_synonym_name
						AND ctrl.customer_name = ctype.customer_name
						AND ctrl.project_name = ctype.project_name
						AND ctrl.process_name = ctype.process_name
						AND ctrl.component_name = ctype.component_name
						AND ctrl.control_type = ctype.ctrl_type_name
						AND sec.customer_name = @engg_customer_name
						AND sec.project_name = @engg_project_name
						AND sec.req_no = @engg_req_no
						AND sec.process_name = @process_name
						AND sec.component_name = @engg_component
						AND sec.activity_name = @activity_name
						AND sec.ui_name = @ui_name_tmp
						AND isnull(sec.section_type, 'MAIN') = 'PopUp'
						AND ctype.visisble_flag = 'N'
						--AND gls.languageid = @language_code
					--Code added for Bug ID:PLF2.0_00961 ends
					/* Code modified by Makesh Prabu R to change the scripts 90 compatible on 05-April-10 for the Case ID: PNR2.0_26469 -- Starts */
					ORDER BY page_bt_synonym,
						sec.horder,
						sec.vorder,
						section_bt_synonym,
						ctrl.horder,
						ctrl.vorder,
						order_seq
					/* Code modified by Makesh Prabu R to change the scripts 90 compatible on 05-April-10 for the Case ID: PNR2.0_26469 -- End */
					OPTION (
						HASH
					
					UNION
						) -- code modified for PNR2.0_12645
				END
				ELSE
				BEGIN
					DECLARE ctrlcurs INSENSITIVE CURSOR
					FOR
					SELECT upper(control_bt_synonym),
						isnull(bt_synonym_caption, control_bt_synonym),
						upper(control_id),
						upper(isnull(data_type, 'char')),
						isnull(length, 20),
						isnull(control_type, ''),
						upper(base_ctrl_type),
						ctrl.horder,
						ctrl.vorder,
						isnull(visisble_length, 0),
						isnull(proto_tooltip, ''),
						isnull(sample_data, ''),
						upper(ctrl.page_bt_synonym) AS 'page_bt_synonym',
						upper(ctrl.section_bt_synonym) AS 'section_bt_synonym',
						upper(ltrim(rtrim(mandatory_flag))),
						upper(ltrim(rtrim(ctype.visisble_flag))),
						upper(ltrim(rtrim(editable_flag))),
						upper(ltrim(rtrim(caption_req))),
						upper(ltrim(rtrim(select_flag))),
						upper(ltrim(rtrim(zoom_req))),
						upper(ltrim(rtrim(help_req))),
						upper(ltrim(rtrim(ellipses_req))),
						isnull(visisble_rows, 0),
						isnull(data_column_width, 0),
						isnull(label_column_width, 0),
						upper(isnull(caption_wrap, 'Y')),
						upper(isnull(caption_alignment, 'LEFT')),
						upper(isnull(caption_position, 'LEFT')),
						isnull(control_doc, ''),
						isnull(order_seq, 1) AS order_seq,
						upper(isnull(ctrl_position, 'LEFT')),
						upper(isnull(LabelClass, '')),
						upper(isnull(controlclass, '')),
						upper(isnull(delete_req, 'N')),
						upper(isnull(password_char, 'N')),
						upper(isnull(tskimg_class, '')),
						upper(isnull(hlpimg_class, '')),
						upper(isnull(data_column_scalemode, '%')),
						upper(isnull(label_column_scalemode, '%')),
						sec.horder,
						sec.vorder,
						upper(isnull(html_txt_area, 'N')),
						upper(isnull(Spin_required, 'N')),
						upper(isnull(spin_up_image, 'spinup.gif')),
						isnull(spin_down_image, 'spindown.gif'),
						--code modified for bugId : PNR2.0_10741
						isnull(report_req, 'N'),
						isnull(InPlace_Calendar, 'N'),
						isnull(EditMask, ''), -- Inplace Calendar and Edit Mask Feature added by Feroz
						isnull(AccessKey, ''), -- Added by Jeya
						-- Code addition for PNR2.0_20849 starts
						convert(VARCHAR, NoofLinesPerRow),
						isnull(convert(VARCHAR, RowHeight), ''),
						isnull(Vscrollbar_Req, 'N'),
						-- Code addition for PNR2.0_20849 ends
						-- Added By Feroz
						isnull(bulletlink_req, 'N'),
						isnull(buttoncombo_req, 'N'),
						isnull(associatedlist_req, 'N'),
						isnull(onfocustask_req, 'N'),
						isnull(listrefilltask_req, 'N'),
						isnull(dataascaption, 'N'),
						isnull(ListEdit_NoofColumns, 0),
						isnull(attach_document, 'N'),
						isnull(image_upload, 'N'),
						isnull(inplace_image, 'N'),
						isnull(image_row_height, 0),
						isnull(image_icon, 'N'),
						isnull(relative_url_path, ''),
						isnull(relative_document_path, ''),
						isnull(relative_image_path, ''),
						isnull(save_doc_content_to_db, 'N'),
						isnull(save_image_content_to_db, 'N'),
						isnull(Date_highlight, 'N'),
						-- Code addition for PNR2.0_21576 starts
						isnull(gridlite_req, 'N'),
						-- Code addition for PNR2.0_21576 ends
						isnull(freezecount, 0),
						isnull(Lite_Attach_Document, 'N'),
						isnull(Browse_Button_Enable, 'N'),
						isnull(Delete_Button_Enable, 'N'), --added for PNR2.0_26860 -- Code Modified for the Bug ID : PNR2.0_27796
						isnull(image_row_width, 0),
						isnull(image_preview_height, 0),
						isnull(image_preview_width, 0),
						isnull(image_preview_req, 'N'),
						isnull(Accpet_Type, ''),
						isnull(Lite_Attach_Image, 'N'), -- PNR2.0_28319
						isnull(Label_link, 'N'), --Code Added for the Bug ID PNR2.0_36309
						isnull(captiontype, 'Text'),
						isnull(controlstyle, 'Default'),
						isnull(controlimage, '') --Code added for Bug ID:PLF2.0_00961
						,
						isnull(IsListBox, ''),
						isnull(Toolbar_Not_Req, 'N'),
						isnull(ColumnBorder_Not_Req, 'N'),
						isnull(RowBorder_Not_Req, 'N'),
						isnull(PagenavigationOnly, 'N'),
						isnull(RowNO_Not_Req, 'N'),
						isnull(ButtonHome_Req, 'N'),
						isnull(ButtonPrevious_Req, 'N'),
						isnull(colspan, ''),
						isnull(rowspan, ''),
						isnull(ToolTip_Not_Req, 'N'),
						isnull(columncaption_Not_Req, 'N'),
						isnull(Border_Not_Req, 'N'),
						isnull(IsModal, 'N'),
						isnull(Alternate_Color_Req, 'N'), --PLF2.0_03057
						isnull(Map_In_Req, 'N'),
						isnull(Map_Out_Req, 'N'),
						isnull(FileSize, ''),
						isnull(ISDeviceInfo, 'N'),
						isnull(Datagrid, 'N'),
						isnull(Email, 'N'),
						isnull(TemplateID, ''),
						isnull(Phone, 'N'),
						isnull(StaticCaption, 'N'),
						isnull(ctype.Orientation, 'Horizontal'), --TECH-75230
						isnull(Listcontrol, 'N'),
						isnull(ctype.col_caption_align, ''),
						isnull(ctype.Gridheaderstyle, ''),
						isnull(ctype.Gridtoolbarstyle, ''),
						isnull(ctype.preevent, ''),
						isnull(ctype.postevent, ''),
						isnull(ctype.ishijri, 'N'),
						isnull(ctype.avn_download, ''),
						isnull(ctype.spin_system_task, ''),
						isnull(ispivot, 'N'),
						isnull(TemplateCategory, ''),
						isnull(TemplateSpecific, ''),
						isnull(ctype.RatingType, ''),
						isnull(CaptchaData, ''),
						isnull(Control_class_ext6, ''),
						upper(isnull(renderas, '')),
						isnull(icon_class, ''),
						isnull(icon_position, ''),
						isnull(preserve_gridposition, '')
					FROM ep_ui_control_dtl ctrl(NOLOCK),
						ep_ui_section_dtl sec(NOLOCK),
						@ep_component_glossary_mst gls,
						es_comp_ctrl_type_mst_vw ctype(NOLOCK)
					WHERE ctrl.customer_name = sec.customer_name
						AND ctrl.project_name = sec.project_name
						AND ctrl.req_no = sec.req_no
						AND ctrl.process_name = sec.process_name
						AND ctrl.component_name = sec.component_name
						AND ctrl.activity_name = sec.activity_name
						AND ctrl.ui_name = sec.ui_name
						AND ctrl.page_bt_synonym = sec.page_bt_synonym
						AND ctrl.section_bt_synonym = sec.section_bt_synonym
						AND ctrl.customer_name = gls.customer_name
						AND ctrl.project_name = gls.project_name
						AND ctrl.req_no = gls.req_no
						AND ctrl.process_name = gls.process_name
						AND ctrl.component_name = gls.component_name
						AND ctrl.control_bt_synonym = gls.bt_synonym_name
						AND ctrl.customer_name = ctype.customer_name
						AND ctrl.project_name = ctype.project_name
						AND ctrl.req_no = ctype.req_no
						AND ctrl.process_name = ctype.process_name
						AND ctrl.component_name = ctype.component_name
						AND ctrl.control_type = ctype.ctrl_type_name
						AND sec.customer_name = @engg_customer_name
						AND sec.project_name = @engg_project_name
						AND sec.req_no = 'Base'
						AND sec.process_name = @process_name
						AND sec.component_name = @engg_component
						AND sec.activity_name = @activity_name
						AND sec.ui_name = @ui_name_tmp
						--and  isnull(sec.section_type,'MAIN') = 'MAIN'
						AND (
							ctype.visisble_flag = 'Y'
							OR ctrl.control_type = 'Filler'
							)
						AND sec.visisble_flag = 'Y'
						--AND gls.languageid = @language_code
					
					UNION
					
					SELECT upper(control_bt_synonym),
						isnull(bt_synonym_caption, control_bt_synonym),
						upper(control_id),
						upper(isnull(data_type, 'char')),
						isnull(length, 20),
						isnull(control_type, ''),
						upper(base_ctrl_type),
						ctrl.horder,
						ctrl.vorder,
						isnull(visisble_length, 0),
						isnull(proto_tooltip, ''),
						isnull(sample_data, ''),
						upper(ctrl.page_bt_synonym) AS 'page_bt_synonym',
						upper(ctrl.section_bt_synonym) AS 'section_bt_synonym',
						'Y',
						'Y',
						'Y',
						'Y',
						'N',
						'N',
						'N',
						'N',
						'0',
						isnull(data_column_width, 0),
						isnull(label_column_width, 0),
						'Y',
						'LEFT',
						'LEFT',
						isnull(control_doc, ''),
						isnull(ctrl.order_seq, 1) AS order_seq,
						'LEFT',
						'',
						'',
						'N',
						'N',
						'',
						'',
						upper(isnull(data_column_scalemode, '%')),
						upper(isnull(label_column_scalemode, '%')),
						sec.horder,
						sec.vorder,
						'N',
						'N',
						'',
						'',
						--code modified for bugId : PNR2.0_10741
						'N',
						'N',
						'',
						isnull(AccessKey, ''), -- Added by Jeya
						-- Code addition for PNR2.0_20849 starts
						'',
						'',
						'',
						-- Code addition for PNR2.0_20849 ends
						-- Added By Feroz
						'N',
						'N',
						'N',
						'N',
						'N',
						'N',
						0,
						'N',
						'N',
						'N',
						0,
						'N',
						'',
						'',
						'',
						'N',
						'N',
						'N',
						-- Code addition for PNR2.0_21576 starts
						'',
						-- Code addition for PNR2.0_21576 ends
						isnull(freezecount, 0),
						'N',
						'N',
						'N', --added for PNR2.0_26860 -- Code Modified for the Bug ID : PNR2.0_27796
						0,
						0,
						0,
						'N',
						'',
						'N',
						'N', --PNR2.0_28319 ,PNR2.0_36309
						'',
						'',
						'' --Code added for Bug ID:PLF2.0_00961
						,
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'N',
						'N',
						'N',
						'',
						'N',
						'N',
						'Horizontal',
						'N',
						'',
						'',
						'',
						'',
						'',
						'N',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						''
					FROM ep_ui_control_dtl ctrl(NOLOCK),
						ep_ui_section_dtl sec(NOLOCK),
						@ep_component_glossary_mst gls,
						es_comp_stat_ctrl_type_mst ctype(NOLOCK)
					WHERE ctrl.customer_name = sec.customer_name
						AND ctrl.project_name = sec.project_name
						AND ctrl.req_no = sec.req_no
						AND ctrl.process_name = sec.process_name
						AND ctrl.component_name = sec.component_name
						AND ctrl.activity_name = sec.activity_name
						AND ctrl.ui_name = sec.ui_name
						AND ctrl.page_bt_synonym = sec.page_bt_synonym
						AND ctrl.section_bt_synonym = sec.section_bt_synonym
						AND ctrl.customer_name = gls.customer_name
						AND ctrl.project_name = gls.project_name
						AND ctrl.process_name = gls.process_name
						AND ctrl.component_name = gls.component_name
						AND ctrl.control_bt_synonym = gls.bt_synonym_name
						AND ctrl.customer_name = ctype.customer_name
						AND ctrl.project_name = ctype.project_name
						AND ctrl.process_name = ctype.process_name
						AND ctrl.component_name = ctype.component_name
						AND ctrl.control_type = ctype.ctrl_type_name
						AND sec.customer_name = @engg_customer_name
						AND sec.project_name = @engg_project_name
						AND sec.process_name = @process_name
						AND sec.component_name = @engg_component
						AND sec.activity_name = @activity_name
						AND sec.ui_name = @ui_name_tmp
						AND isnull(sec.section_type, 'MAIN') = 'MAIN'
						--AND gls.languageid = @language_code
					-- code added by feroz for extjs Start -- PNR2.0_1790
					
					UNION
					
					SELECT upper(control_bt_synonym),
						isnull(bt_synonym_caption, control_bt_synonym),
						upper(control_id),
						upper(isnull(data_type, 'char')),
						isnull(length, 20),
						isnull(control_type, ''),
						upper(base_ctrl_type),
						ctrl.horder,
						ctrl.vorder,
						isnull(visisble_length, 0),
						isnull(proto_tooltip, ''),
						isnull(sample_data, ''),
						upper(ctrl.page_bt_synonym) AS 'page_bt_synonym',
						upper(ctrl.section_bt_synonym) AS 'section_bt_synonym',
						upper(ltrim(rtrim(mandatory_flag))),
						upper(ltrim(rtrim(ctype.visisble_flag))),
						upper(ltrim(rtrim(editable_flag))),
						upper(ltrim(rtrim(caption_req))),
						upper(ltrim(rtrim(select_flag))),
						upper(ltrim(rtrim(zoom_req))),
						upper(ltrim(rtrim(help_req))),
						upper(ltrim(rtrim(ellipses_req))),
						isnull(visisble_rows, 0),
						isnull(data_column_width, 0),
						isnull(label_column_width, 0),
						upper(isnull(caption_wrap, 'Y')),
						upper(isnull(caption_alignment, 'LEFT')),
						upper(isnull(caption_position, 'LEFT')),
						isnull(control_doc, ''),
						isnull(order_seq, 1) AS order_seq,
						upper(isnull(ctrl_position, 'LEFT')),
						upper(isnull(LabelClass, '')),
						upper(isnull(controlclass, '')),
						upper(isnull(delete_req, 'N')),
						upper(isnull(password_char, 'N')),
						upper(isnull(tskimg_class, '')),
						upper(isnull(hlpimg_class, '')),
						upper(isnull(data_column_scalemode, '%')),
						upper(isnull(label_column_scalemode, '%')),
						sec.horder,
						sec.vorder,
						upper(isnull(html_txt_area, 'N')),
						upper(isnull(Spin_required, 'N')),
						upper(isnull(spin_up_image, 'spinup.gif')),
						isnull(spin_down_image, 'spindown.gif'),
						--code modified for bugId : PNR2.0_10741
						isnull(report_req, 'N'),
						isnull(InPlace_Calendar, 'N'),
						isnull(EditMask, ''), -- Inplace Calendar and Edit Mask Feature added by Feroz
						isnull(AccessKey, ''), -- Added by Jeya
						-- Code addition for PNR2.0_20849 starts
						convert(VARCHAR, NoofLinesPerRow),
						isnull(convert(VARCHAR, RowHeight), ''),
						isnull(Vscrollbar_Req, 'N'),
						-- Code addition for PNR2.0_20849 ends
						-- Added By Feroz
						isnull(bulletlink_req, 'N'),
						isnull(buttoncombo_req, 'N'),
						isnull(associatedlist_req, 'N'),
						isnull(onfocustask_req, 'N'),
						isnull(listrefilltask_req, 'N'),
						isnull(dataascaption, 'N'),
						isnull(ListEdit_NoofColumns, 0),
						isnull(attach_document, 'N'),
						isnull(image_upload, 'N'),
						isnull(inplace_image, 'N'),
						isnull(image_row_height, 0),
						isnull(image_icon, 'N'),
						isnull(relative_url_path, ''),
						isnull(relative_document_path, ''),
						isnull(relative_image_path, ''),
						isnull(save_doc_content_to_db, 'N'),
						isnull(save_image_content_to_db, 'N'),
						isnull(Date_highlight, 'N'),
						-- Code addition for PNR2.0_21576 starts
						isnull(gridlite_req, 'N'),
						-- Code addition for PNR2.0_21576 endsi am thinking of leaving early after asking mam
						isnull(freezecount, 0),
						isnull(Lite_Attach_Document, 'N'),
						isnull(Browse_Button_Enable, 'N'),
						isnull(Delete_Button_Enable, 'N'), --added for PNR2.0_26860 -- Code Modified for the Bug ID : PNR2.0_27796
						isnull(image_row_width, 0),
						isnull(image_preview_height, 0),
						isnull(image_preview_width, 0),
						isnull(image_preview_req, 'N'),
						isnull(Accpet_Type, ''),
						isnull(Lite_Attach_Image, 'N'), -- PNR2.0_28319
						isnull(Label_link, 'N'), --Code Added for the Bug ID PNR2.0_36309
						isnull(captiontype, 'Text'),
						isnull(controlstyle, 'Default'),
						isnull(controlimage, '') --Code added for Bui am thinking of leaving early after asking mamg ID:PLF2.0_00961
						,
						isnull(IsListBox, ''),
						isnull(Toolbar_Not_Req, 'N'),
						isnull(ColumnBorder_Not_Req, 'N'),
						isnull(RowBorder_Not_Req, 'N'),
						isnull(PagenavigationOnly, 'N'),
						isnull(RowNO_Not_Req, 'N'),
						isnull(ButtonHome_Req, 'N'),
						isnull(ButtonPrevious_Req, 'N'),
						isnull(colspan, ''),
						isnull(rowspan, ''),
						isnull(ToolTip_Not_Req, 'N'),
						isnull(columncaption_Not_Req, 'N'),
						isnull(Border_Not_Req, 'N'),
						isnull(IsModal, 'N'),
						isnull(Alternate_Color_Req, 'N'), --PLF2.0_03057
						isnull(Map_In_Req, 'N'),
						isnull(Map_Out_Req, 'N'),
						isnull(FileSize, ''),
						isnull(ISDeviceInfo, 'N'),
						isnull(Datagrid, 'N'),
						isnull(Email, 'N'),
						isnull(TemplateID, ''),
						isnull(Phone, 'N'),
						isnull(StaticCaption, 'N'),
						isnull(ctype.Orientation, 'Horizontal'), --TECH-75230
						isnull(Listcontrol, 'N'),
						isnull(ctype.col_caption_align, ''),
						isnull(ctype.Gridheaderstyle, ''),
						isnull(ctype.Gridtoolbarstyle, ''),
						isnull(ctype.preevent, ''),
						isnull(ctype.postevent, ''),
						isnull(ctype.ishijri, 'N'),
						isnull(ctype.avn_download, ''),
						isnull(ctype.spin_system_task, ''),
						isnull(ispivot, 'N'),
						isnull(TemplateCategory, ''),
						isnull(TemplateSpecific, ''),
						isnull(ctype.RatingType, ''),
						isnull(CaptchaData, ''),
						isnull(Control_class_ext6, ''),
						upper(isnull(renderas, '')),
						isnull(icon_class, ''),
						isnull(icon_position, ''),
						isnull(preserve_gridposition, '')
					FROM ep_ui_control_dtl ctrl(NOLOCK),
						ep_ui_section_dtl sec(NOLOCK),
						@ep_component_glossary_mst gls,
						es_comp_ctrl_type_mst_vw ctype(NOLOCK)
					WHERE ctrl.customer_name = sec.customer_name
						AND ctrl.project_name = sec.project_name
						AND ctrl.component_name = sec.component_name
						AND ctrl.activity_name = sec.activity_name
						AND ctrl.ui_name = sec.ui_name
						AND ctrl.page_bt_synonym = sec.page_bt_synonym
						AND ctrl.section_bt_synonym = sec.section_bt_synonym
						AND ctrl.customer_name = gls.customer_name
						AND ctrl.project_name = gls.project_name
						AND ctrl.req_no = gls.req_no
						AND ctrl.process_name = gls.process_name
						AND ctrl.component_name = gls.component_name
						AND ctrl.control_bt_synonym = gls.bt_synonym_name
						AND ctrl.customer_name = ctype.customer_name
						AND ctrl.project_name = ctype.project_name
						AND ctrl.process_name = ctype.process_name
						AND ctrl.component_name = ctype.component_name
						AND ctrl.control_type = ctype.ctrl_type_name
						AND sec.customer_name = @engg_customer_name
						AND sec.project_name = @engg_project_name
						AND sec.process_name = @process_name
						AND sec.component_name = @engg_component
						AND sec.activity_name = @activity_name
						AND sec.ui_name = @ui_name_tmp
						AND isnull(sec.section_type, 'MAIN') NOT IN (
							'MAIN',
							'TREE',
							'CHART'
							)
						AND ctype.visisble_flag = 'N'
						AND sec.visisble_flag = 'Y'
						--AND gls.languageid = @language_code
					
					UNION
					
					SELECT upper(control_bt_synonym),
						isnull(bt_synonym_caption, control_bt_synonym),
						upper(control_id),
						upper(isnull(data_type, 'char')),
						isnull(length, 20),
						isnull(control_type, ''),
						upper(base_ctrl_type),
						ctrl.horder,
						ctrl.vorder,
						isnull(visisble_length, 0),
						isnull(proto_tooltip, ''),
						isnull(sample_data, ''),
						upper(ctrl.page_bt_synonym) AS 'page_bt_synonym',
						upper(ctrl.section_bt_synonym) AS 'section_bt_synonym',
						upper(ltrim(rtrim(mandatory_flag))),
						upper(ltrim(rtrim(ctype.visisble_flag))),
						upper(ltrim(rtrim(editable_flag))),
						upper(ltrim(rtrim(caption_req))),
						upper(ltrim(rtrim(select_flag))),
						upper(ltrim(rtrim(zoom_req))),
						upper(ltrim(rtrim(help_req))),
						upper(ltrim(rtrim(ellipses_req))),
						isnull(visisble_rows, 0),
						isnull(data_column_width, 0),
						isnull(label_column_width, 0),
						upper(isnull(caption_wrap, 'Y')),
						upper(isnull(caption_alignment, 'LEFT')),
						upper(isnull(caption_position, 'LEFT')),
						isnull(control_doc, ''),
						isnull(order_seq, 1) AS order_seq,
						upper(isnull(ctrl_position, 'LEFT')),
						upper(isnull(LabelClass, '')),
						upper(isnull(controlclass, '')),
						upper(isnull(delete_req, 'N')),
						upper(isnull(password_char, 'N')),
						upper(isnull(tskimg_class, '')),
						upper(isnull(hlpimg_class, '')),
						upper(isnull(data_column_scalemode, '%')),
						upper(isnull(label_column_scalemode, '%')),
						sec.horder,
						sec.vorder,
						upper(isnull(html_txt_area, 'N')),
						upper(isnull(Spin_required, 'N')),
						upper(isnull(spin_up_image, 'spinup.gif')),
						isnull(spin_down_image, 'spindown.gif'),
						--code modified for bugId : PNR2.0_10741
						isnull(report_req, 'N'),
						isnull(InPlace_Calendar, 'N'),
						isnull(EditMask, ''), -- Inplace Calendar and Edit Mask Feature added by Feroz
						isnull(AccessKey, ''), -- Added by Jeya
						-- Code addition for PNR2.0_20849 starts
						convert(VARCHAR, NoofLinesPerRow),
						isnull(convert(VARCHAR, RowHeight), ''),
						isnull(Vscrollbar_Req, 'N'),
						-- Code addition for PNR2.0_20849 ends
						-- Added By Feroz
						isnull(bulletlink_req, 'N'),
						isnull(buttoncombo_req, 'N'),
						isnull(associatedlist_req, 'N'),
						isnull(onfocustask_req, 'N'),
						isnull(listrefilltask_req, 'N'),
						isnull(dataascaption, 'N'),
						isnull(ListEdit_NoofColumns, 0),
						isnull(attach_document, 'N'),
						isnull(image_upload, 'N'),
						isnull(inplace_image, 'N'),
						isnull(image_row_height, 0),
						isnull(image_icon, 'N'),
						isnull(relative_url_path, ''),
						isnull(relative_document_path, ''),
						isnull(relative_image_path, ''),
						isnull(save_doc_content_to_db, 'N'),
						isnull(save_image_content_to_db, 'N'),
						isnull(Date_highlight, 'N'),
						-- Code addition for PNR2.0_21576 starts
						isnull(gridlite_req, 'N'),
						-- Code addition for PNR2.0_21576 ends
						isnull(freezecount, 0),
						isnull(Lite_Attach_Document, 'N'),
						isnull(Browse_Button_Enable, 'N'),
						isnull(Delete_Button_Enable, 'N'), --added for PNR2.0_26860 -- Code Modified for the Bug ID : PNR2.0_27796
						isnull(image_row_width, 0),
						isnull(image_preview_height, 0),
						isnull(image_preview_width, 0),
						isnull(image_preview_req, 'N'),
						isnull(Accpet_Type, ''),
						isnull(Lite_Attach_Image, 'N'), -- PNR2.0_28319
						isnull(Label_link, 'N'), --Code Added for the Bug ID PNR2.0_36309
						isnull(captiontype, 'Text'),
						isnull(controlstyle, 'Default'),
						isnull(controlimage, '') --Code added for Bug ID:PLF2.0_00961
						,
						isnull(IsListBox, ''),
						isnull(Toolbar_Not_Req, 'N'),
						isnull(ColumnBorder_Not_Req, 'N'),
						isnull(RowBorder_Not_Req, 'N'),
						isnull(PagenavigationOnly, 'N'),
						isnull(RowNO_Not_Req, 'N'),
						isnull(ButtonHome_Req, 'N'),
						isnull(ButtonPrevious_Req, 'N'),
						isnull(colspan, ''),
						isnull(rowspan, ''),
						isnull(ToolTip_Not_Req, 'N'),
						isnull(columncaption_Not_Req, 'N'),
						isnull(Border_Not_Req, 'N'),
						isnull(IsModal, 'N'),
						isnull(Alternate_Color_Req, 'N'), --PLF2.0_03057
						isnull(Map_In_Req, 'N'),
						isnull(Map_Out_Req, 'N'),
						isnull(FileSize, ''),
						isnull(ISDeviceInfo, 'N'),
						isnull(Datagrid, 'N'),
						isnull(Email, 'N'),
						isnull(TemplateID, ''),
						isnull(Phone, 'N'),
						isnull(StaticCaption, 'N'),
						isnull(ctype.Orientation, 'Horizontal'), --TECH-75230
						isnull(Listcontrol, 'N'),
						isnull(ctype.col_caption_align, ''),
						isnull(ctype.Gridheaderstyle, ''),
						isnull(ctype.Gridtoolbarstyle, ''),
						isnull(ctype.preevent, ''),
						isnull(ctype.postevent, ''),
						isnull(ctype.ishijri, 'N'),
						isnull(ctype.avn_download, ''),
						isnull(ctype.spin_system_task, ''),
						isnull(ispivot, 'N'),
						isnull(TemplateCategory, ''),
						isnull(TemplateSpecific, ''),
						isnull(ctype.RatingType, ''),
						isnull(CaptchaData, ''),
						isnull(Control_class_ext6, ''),
						upper(isnull(renderas, '')),
						isnull(icon_class, ''),
						isnull(icon_position, ''),
						isnull(preserve_gridposition, '')
					FROM ep_ui_control_dtl ctrl(NOLOCK),
						ep_ui_section_dtl sec(NOLOCK),
						@ep_component_glossary_mst gls,
						es_comp_ctrl_type_mst_vw ctype(NOLOCK)
					WHERE ctrl.customer_name = sec.customer_name
						AND ctrl.project_name = sec.project_name
						AND ctrl.component_name = sec.component_name
						AND ctrl.activity_name = sec.activity_name
						AND ctrl.ui_name = sec.ui_name
						AND ctrl.page_bt_synonym = sec.page_bt_synonym
						AND ctrl.section_bt_synonym = sec.section_bt_synonym
						AND ctrl.customer_name = gls.customer_name
						AND ctrl.project_name = gls.project_name
						AND ctrl.req_no = gls.req_no
						AND ctrl.process_name = gls.process_name
						AND ctrl.component_name = gls.component_name
						AND ctrl.control_bt_synonym = gls.bt_synonym_name
						AND ctrl.customer_name = ctype.customer_name
						AND ctrl.project_name = ctype.project_name
						AND ctrl.process_name = ctype.process_name
						AND ctrl.component_name = ctype.component_name
						AND ctrl.control_type = ctype.ctrl_type_name
						AND sec.customer_name = @engg_customer_name
						AND sec.project_name = @engg_project_name
						AND sec.req_no = 'Base'
						AND sec.process_name = @process_name
						AND sec.component_name = @engg_component
						AND sec.activity_name = @activity_name
						AND sec.ui_name = @ui_name_tmp
						AND isnull(sec.section_type, 'MAIN') = 'MAIN'
						AND ctype.visisble_flag = 'N'
						AND sec.visisble_flag = 'Y'
						AND ctype.is_extjs_control = 'y'
						--AND gls.languageid = @language_code
					-- code addded By Feroz for Extjs End  -- PNR2.0_1790
					--Code added for Bug ID:PLF2.0_00961 starts
					
					UNION
					
					SELECT upper(control_bt_synonym),
						isnull(bt_synonym_caption, control_bt_synonym),
						upper(control_id),
						upper(isnull(data_type, 'char')),
						isnull(length, 20),
						isnull(control_type, ''),
						upper(base_ctrl_type),
						ctrl.horder,
						ctrl.vorder,
						isnull(visisble_length, 0),
						isnull(proto_tooltip, ''),
						isnull(sample_data, ''),
						upper(ctrl.page_bt_synonym) AS 'page_bt_synonym',
						upper(ctrl.section_bt_synonym) AS 'section_bt_synonym',
						upper(ltrim(rtrim(mandatory_flag))),
						upper(ltrim(rtrim(ctype.visisble_flag))),
						upper(ltrim(rtrim(editable_flag))),
						upper(ltrim(rtrim(caption_req))),
						upper(ltrim(rtrim(select_flag))),
						upper(ltrim(rtrim(zoom_req))),
						upper(ltrim(rtrim(help_req))),
						upper(ltrim(rtrim(ellipses_req))),
						isnull(visisble_rows, 0),
						isnull(data_column_width, 0),
						isnull(label_column_width, 0),
						upper(isnull(caption_wrap, 'Y')),
						upper(isnull(caption_alignment, 'LEFT')),
						upper(isnull(caption_position, 'LEFT')),
						isnull(control_doc, ''),
						isnull(order_seq, 1) AS order_seq,
						upper(isnull(ctrl_position, 'LEFT')),
						upper(isnull(LabelClass, '')),
						upper(isnull(controlclass, '')),
						upper(isnull(delete_req, 'N')),
						upper(isnull(password_char, 'N')),
						upper(isnull(tskimg_class, '')),
						upper(isnull(hlpimg_class, '')),
						upper(isnull(data_column_scalemode, '%')),
						upper(isnull(label_column_scalemode, '%')),
						sec.horder,
						sec.vorder,
						upper(isnull(html_txt_area, 'N')),
						upper(isnull(Spin_required, 'N')),
						upper(isnull(spin_up_image, 'spinup.gif')),
						isnull(spin_down_image, 'spindown.gif'),
						--code modified for bugId : PNR2.0_10741
						isnull(report_req, 'N'),
						isnull(InPlace_Calendar, 'N'),
						isnull(EditMask, ''), -- Inplace Calendar and Edit Mask Feature added by Feroz
						isnull(AccessKey, ''), -- Added by Jeya
						-- Code addition for PNR2.0_20849 starts
						convert(VARCHAR, NoofLinesPerRow),
						isnull(convert(VARCHAR, RowHeight), ''),
						isnull(Vscrollbar_Req, 'N'),
						-- Code addition for PNR2.0_20849 ends
						-- Added By Feroz
						isnull(bulletlink_req, 'N'),
						isnull(buttoncombo_req, 'N'),
						isnull(associatedlist_req, 'N'),
						isnull(onfocustask_req, 'N'),
						isnull(listrefilltask_req, 'N'),
						isnull(dataascaption, 'N'),
						isnull(ListEdit_NoofColumns, 0),
						isnull(attach_document, 'N'),
						isnull(image_upload, 'N'),
						isnull(inplace_image, 'N'),
						isnull(image_row_height, 0),
						isnull(image_icon, 'N'),
						isnull(relative_url_path, ''),
						isnull(relative_document_path, ''),
						isnull(relative_image_path, ''),
						isnull(save_doc_content_to_db, 'N'),
						isnull(save_image_content_to_db, 'N'),
						isnull(Date_highlight, 'N'),
						-- Code addition for PNR2.0_21576 starts
						isnull(gridlite_req, 'N'),
						-- Code addition for PNR2.0_21576 ends
						isnull(freezecount, 0),
						isnull(Lite_Attach_Document, 'N'),
						isnull(Browse_Button_Enable, 'N'),
						isnull(Delete_Button_Enable, 'N'), --added for PNR2.0_26860 -- Code Modified for the Bug ID : PNR2.0_27796
						isnull(image_row_width, 0),
						isnull(image_preview_height, 0),
						isnull(image_preview_width, 0),
						isnull(image_preview_req, 'N'),
						isnull(Accpet_Type, ''),
						isnull(Lite_Attach_Image, 'N'), -- PNR2.0_28319
						isnull(Label_link, 'N'), --Code Added for the Bug ID PNR2.0_36309
						isnull(captiontype, 'Text'),
						isnull(controlstyle, 'Default'),
						isnull(controlimage, ''),
						isnull(IsListBox, ''),
						isnull(Toolbar_Not_Req, 'N'),
						isnull(ColumnBorder_Not_Req, 'N'),
						isnull(RowBorder_Not_Req, 'N'),
						isnull(PagenavigationOnly, 'N'),
						isnull(RowNO_Not_Req, 'N'),
						isnull(ButtonHome_Req, 'N'),
						isnull(ButtonPrevious_Req, 'N'),
						isnull(colspan, ''),
						isnull(rowspan, ''),
						isnull(ToolTip_Not_Req, 'N'),
						isnull(columncaption_Not_Req, 'N'),
						isnull(Border_Not_Req, 'N'),
						isnull(IsModal, 'N'),
						isnull(Alternate_Color_Req, 'N'), --PLF2.0_03057
						isnull(Map_In_Req, 'N'),
						isnull(Map_Out_Req, 'N'),
						isnull(FileSize, ''),
						isnull(ISDeviceInfo, 'N'),
						isnull(Datagrid, 'N'),
						isnull(Email, 'N'),
						isnull(TemplateID, ''),
						isnull(Phone, 'N'),
						isnull(StaticCaption, 'N'),
						isnull(ctype.Orientation, 'Horizontal'),--TECH-75230
						isnull(Listcontrol, 'N'),
						isnull(ctype.col_caption_align, ''),
						isnull(ctype.Gridheaderstyle, ''),
						isnull(ctype.Gridtoolbarstyle, ''),
						isnull(ctype.preevent, ''),
						isnull(ctype.postevent, ''),
						isnull(ctype.ishijri, 'N'),
						isnull(ctype.avn_download, ''),
						isnull(ctype.spin_system_task, ''),
						isnull(ispivot, 'N'),
						isnull(TemplateCategory, ''),
						isnull(TemplateSpecific, ''),
						isnull(ctype.RatingType, ''),
						isnull(CaptchaData, ''),
						isnull(Control_class_ext6, ''),
						upper(isnull(renderas, '')),
						isnull(icon_class, ''),
						isnull(icon_position, ''),
						isnull(preserve_gridposition, '')
					FROM ep_ui_control_dtl ctrl(NOLOCK),
						ep_ui_section_dtl sec(NOLOCK),
						@ep_component_glossary_mst gls,
						es_comp_ctrl_type_mst_vw ctype(NOLOCK)
					WHERE ctrl.customer_name = sec.customer_name
						AND ctrl.project_name = sec.project_name
						AND ctrl.req_no = sec.req_no
						AND ctrl.process_name = sec.process_name
						AND ctrl.component_name = sec.component_name
						AND ctrl.activity_name = sec.activity_name
						AND ctrl.ui_name = sec.ui_name
						AND ctrl.page_bt_synonym = sec.page_bt_synonym
						AND ctrl.section_bt_synonym = sec.section_bt_synonym
						AND ctrl.customer_name = gls.customer_name
						AND ctrl.project_name = gls.project_name
						AND ctrl.req_no = gls.req_no
						AND ctrl.process_name = gls.process_name
						AND ctrl.component_name = gls.component_name
						AND ctrl.control_bt_synonym = gls.bt_synonym_name
						AND ctrl.customer_name = ctype.customer_name
						AND ctrl.project_name = ctype.project_name
						AND ctrl.req_no = ctype.req_no
						AND ctrl.process_name = ctype.process_name
						AND ctrl.component_name = ctype.component_name
						AND ctrl.control_type = ctype.ctrl_type_name
						AND sec.customer_name = @engg_customer_name
						AND sec.project_name = @engg_project_name
						AND sec.req_no = 'Base'
						AND sec.process_name = @process_name
						AND sec.component_name = @engg_component
						AND sec.activity_name = @activity_name
						AND sec.ui_name = @ui_name_tmp
						AND isnull(sec.section_type, 'MAIN') = 'PopUp'
						AND sec.visisble_flag = 'N'
						--AND gls.languageid = @language_code
					--Code added for Bug ID:PLF2.0_00961 ends
					/* Code modified by Makesh Prabu R to change the scripts 90 compatible on 05-April-10 for the Case ID: PNR2.0_26469 -- Starts */
					ORDER BY page_bt_synonym,
						sec.horder,
						sec.vorder,
						section_bt_synonym,
						ctrl.horder,
						ctrl.vorder,
						order_seq
					/* Code modified by Makesh Prabu R to change the scripts 90 compatible on 05-April-10 for the Case ID: PNR2.0_26469 -- End */
					OPTION (
						HASH
					
					UNION
						) -- code modified for PNR2.0_12645
				END
			END
			ELSE
			BEGIN
				IF @ctxt_service_in IN ('BulkGenerate')
					AND @pubflag = 'P'
				BEGIN
					DECLARE ctrlcurs INSENSITIVE CURSOR
					FOR
					SELECT upper(control_bt_synonym),
						isnull(bt_synonym_caption, control_bt_synonym),
						upper(control_id),
						upper(isnull(data_type, 'char')),
						isnull(length, 20),
						isnull(control_type, ''),
						upper(base_ctrl_type),
						ctrl.horder,
						ctrl.vorder,
						isnull(visisble_length, 0),
						isnull(proto_tooltip, ''),
						isnull(sample_data, ''),
						upper(ctrl.page_bt_synonym) AS 'page_bt_synonym',
						upper(ctrl.section_bt_synonym) AS 'section_bt_synonym',
						upper(ltrim(rtrim(mandatory_flag))),
						upper(ltrim(rtrim(ctype.visisble_flag))),
						upper(ltrim(rtrim(editable_flag))),
						upper(ltrim(rtrim(caption_req))),
						upper(ltrim(rtrim(select_flag))),
						upper(ltrim(rtrim(zoom_req))),
						upper(ltrim(rtrim(help_req))),
						upper(ltrim(rtrim(ellipses_req))),
						isnull(visisble_rows, 0),
						isnull(data_column_width, 0),
						isnull(label_column_width, 0),
						upper(isnull(caption_wrap, 'Y')),
						upper(isnull(caption_alignment, 'LEFT')),
						upper(isnull(caption_position, 'LEFT')),
						isnull(control_doc, ''),
						isnull(order_seq, 1) AS order_seq,
						upper(isnull(ctrl_position, 'LEFT')),
						upper(isnull(LabelClass, '')),
						upper(isnull(controlclass, '')),
						upper(isnull(delete_req, 'N')),
						upper(isnull(password_char, 'N')),
						upper(isnull(tskimg_class, '')),
						upper(isnull(hlpimg_class, '')),
						upper(isnull(data_column_scalemode, '%')),
						upper(isnull(label_column_scalemode, '%')),
						sec.horder,
						sec.vorder,
						upper(isnull(html_txt_area, 'N')),
						upper(isnull(Spin_required, 'N')),
						upper(isnull(spin_up_image, 'spinup.gif')),
						isnull(spin_down_image, 'spindown.gif'),
						--code modified for bugId : PNR2.0_10741
						isnull(report_req, 'N'),
						isnull(InPlace_Calendar, 'N'),
						isnull(EditMask, ''), -- Inplace Calendar and Edit Mask Feature added by Feroz
						isnull(AccessKey, ''), -- Added by Jeya
						-- Code addition for PNR2.0_20849 starts
						convert(VARCHAR, NoofLinesPerRow),
						isnull(convert(VARCHAR, RowHeight), ''),
						isnull(Vscrollbar_Req, 'N'),
						-- Code addition for PNR2.0_20849 ends
						-- Added By Feroz
						isnull(bulletlink_req, 'N'),
						isnull(buttoncombo_req, 'N'),
						isnull(associatedlist_req, 'N'),
						isnull(onfocustask_req, 'N'),
						isnull(listrefilltask_req, 'N'),
						isnull(dataascaption, 'N'),
						isnull(ListEdit_NoofColumns, 0),
						isnull(attach_document, 'N'),
						isnull(image_upload, 'N'),
						isnull(inplace_image, 'N'),
						isnull(image_row_height, 0),
						isnull(image_icon, 'N'),
						isnull(relative_url_path, ''),
						isnull(relative_document_path, ''),
						isnull(relative_image_path, ''),
						isnull(save_doc_content_to_db, 'N'),
						isnull(save_image_content_to_db, 'N'),
						isnull(Date_highlight, 'N'),
						-- Code addition for PNR2.0_21576 starts
						isnull(gridlite_req, 'N'),
						-- Code addition for PNR2.0_21576 ends
						isnull(freezecount, 0),
						isnull(Lite_Attach_Document, 'N'),
						isnull(Browse_Button_Enable, 'N'),
						isnull(Delete_Button_Enable, 'N'), --added for PNR2.0_26860 -- Code Modified for the Bug ID : PNR2.0_27796
						isnull(image_row_width, 0),
						isnull(image_preview_height, 0),
						isnull(image_preview_width, 0),
						isnull(image_preview_req, 'N'),
						isnull(Accpet_Type, ''),
						isnull(Lite_Attach_Image, 'N'), -- PNR2.0_28319
						isnull(Label_link, 'N'), --Code Added for the Bug ID PNR2.0_36309
						isnull(captiontype, 'Text'),
						isnull(controlstyle, 'Default'),
						isnull(controlimage, '') --Code added for Bug ID:PLF2.0_00961
						,
						isnull(IsListBox, ''),
						isnull(Toolbar_Not_Req, 'N'),
						isnull(ColumnBorder_Not_Req, 'N'),
						isnull(RowBorder_Not_Req, 'N'),
						isnull(PagenavigationOnly, 'N'),
						isnull(RowNO_Not_Req, 'N'),
						isnull(ButtonHome_Req, 'N'),
						isnull(ButtonPrevious_Req, 'N'),
						isnull(colspan, ''),
						isnull(rowspan, ''),
						isnull(ToolTip_Not_Req, 'N'),
						isnull(columncaption_Not_Req, 'N'),
						isnull(Border_Not_Req, 'N'),
						isnull(IsModal, 'N'),
						isnull(Alternate_Color_Req, 'N'), --PLF2.0_03057
						isnull(Map_In_Req, 'N'),
						isnull(Map_Out_Req, 'N'),
						isnull(FileSize, ''),
						isnull(ISDeviceInfo, 'N'),
						isnull(Datagrid, 'N'),
						isnull(Email, 'N'),
						isnull(TemplateID, ''),
						isnull(Phone, 'N'),
						isnull(StaticCaption, 'N'),
						isnull(ctype.Orientation, 'Horizontal'), --TECH-75230
						isnull(Listcontrol, 'N'),
						isnull(ctype.col_caption_align, ''),
						isnull(ctype.Gridheaderstyle, ''),
						isnull(ctype.Gridtoolbarstyle, ''),
						isnull(ctype.preevent, ''),
						isnull(ctype.postevent, ''),
						isnull(ctype.ishijri, 'N'),
						isnull(ctype.avn_download, ''),
						isnull(ctype.spin_system_task, ''),
						isnull(ispivot, 'N'),
						isnull(TemplateCategory, ''),
						isnull(TemplateSpecific, ''),
						isnull(ctype.RatingType, ''),
						isnull(CaptchaData, ''),
						isnull(Control_class_ext6, ''),
						upper(isnull(renderas, '')),
						isnull(icon_class, ''),
						isnull(icon_position, ''),
						isnull(preserve_gridposition, '')
					FROM ep_published_ui_control_dtl ctrl(NOLOCK),
						ep_published_ui_section_dtl sec(NOLOCK),
						@ep_published_comp_glossary_mst gls,
						es_comp_ctrl_type_mst_vw ctype(NOLOCK)
					WHERE ctrl.customer_name = sec.customer_name
						AND ctrl.project_name = sec.project_name
						AND ctrl.req_no = sec.req_no
						AND ctrl.process_name = sec.process_name
						AND ctrl.component_name = sec.component_name
						AND ctrl.activity_name = sec.activity_name
						AND ctrl.ui_name = sec.ui_name
						AND ctrl.page_bt_synonym = sec.page_bt_synonym
						AND ctrl.section_bt_synonym = sec.section_bt_synonym
						AND ctrl.customer_name = gls.customer_name
						AND ctrl.project_name = gls.project_name
						AND ctrl.req_no = gls.req_no
						AND ctrl.process_name = gls.process_name
						AND ctrl.component_name = gls.component_name
						AND ctrl.control_bt_synonym = gls.bt_synonym_name
						AND ctrl.customer_name = ctype.customer_name
						AND ctrl.project_name = ctype.project_name
						AND ctrl.process_name = ctype.process_name
						AND ctrl.component_name = ctype.component_name
						AND ctrl.control_type = ctype.ctrl_type_name
						AND sec.customer_name = @engg_customer_name
						AND sec.project_name = @engg_project_name
						AND sec.req_no = @engg_req_no
						AND sec.process_name = @process_name
						AND sec.component_name = @engg_component
						AND sec.activity_name = @activity_name
						AND sec.ui_name = @ui_name_tmp
						--and  isnull(sec.section_type,'MAIN') = 'MAIN'
						AND (
							ctype.visisble_flag = 'Y'
							OR ctrl.control_type = 'Filler'
							)
						AND sec.visisble_flag = 'Y'
						--AND gls.languageid = @language_code
					
					UNION
					
					SELECT upper(control_bt_synonym),
						isnull(bt_synonym_caption, control_bt_synonym),
						upper(control_id),
						upper(isnull(data_type, 'char')),
						isnull(length, 20),
						isnull(control_type, ''),
						upper(base_ctrl_type),
						ctrl.horder,
						ctrl.vorder,
						isnull(visisble_length, 0),
						isnull(proto_tooltip, ''),
						isnull(sample_data, ''),
						upper(ctrl.page_bt_synonym) AS 'page_bt_synonym',
						upper(ctrl.section_bt_synonym) AS 'section_bt_synonym',
						'Y',
						'Y',
						'Y',
						'Y',
						'N',
						'N',
						'N',
						'N',
						'0',
						isnull(data_column_width, 0),
						isnull(label_column_width, 0),
						'Y',
						'LEFT',
						'LEFT',
						isnull(control_doc, ''),
						isnull(ctrl.order_seq, 1) AS order_seq,
						'LEFT',
						'',
						'',
						'N',
						'N',
						'',
						'',
						upper(isnull(data_column_scalemode, '%')),
						upper(isnull(label_column_scalemode, '%')),
						sec.horder,
						sec.vorder,
						'N',
						'N',
						'',
						'',
						--code modified for bugId : PNR2.0_10741
						'N',
						'N',
						'',
						isnull(AccessKey, ''), -- Added by Jeya
						-- Code addition for PNR2.0_20849 starts
						'',
						'',
						'',
						-- Code addition for PNR2.0_20849 ends
						-- Added By Feroz
						'N',
						'N',
						'N',
						'N',
						'N',
						'N',
						0,
						'N',
						'N',
						'N',
						0,
						'N',
						'',
						'',
						'',
						'N',
						'N',
						'N',
						-- Code addition for PNR2.0_21576 starts
						'',
						-- Code addition for PNR2.0_21576 ends
						isnull(freezecount, 0),
						'N',
						'N',
						'N', --added for PNR2.0_26860 -- Code Modified for the Bug ID : PNR2.0_27796
						0,
						0,
						0,
						'N',
						'',
						'N',
						'N', --PNR2.0_28319,PNR2.0_36309
						'',
						'',
						'' --Code added for Bug ID:PLF2.0_00961
						,
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'N',
						'N',
						'N',
						'',
						'N',
						'N',
						'Horizontal',
						'N',
						'',
						'',
						'',
						'',
						'',
						'N',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						''
					FROM ep_published_ui_control_dtl ctrl(NOLOCK),
						ep_published_ui_section_dtl sec(NOLOCK),
						@ep_published_comp_glossary_mst gls,
						ep_published_comp_stat_ctrl_type_mst ctype(NOLOCK)
					WHERE ctrl.customer_name = sec.customer_name
						AND ctrl.project_name = sec.project_name
						AND ctrl.req_no = sec.req_no
						AND ctrl.process_name = sec.process_name
						AND ctrl.component_name = sec.component_name
						AND ctrl.activity_name = sec.activity_name
						AND ctrl.ui_name = sec.ui_name
						AND ctrl.page_bt_synonym = sec.page_bt_synonym
						AND ctrl.section_bt_synonym = sec.section_bt_synonym
						AND ctrl.customer_name = gls.customer_name
						AND ctrl.project_name = gls.project_name
						AND ctrl.req_no = gls.req_no
						AND ctrl.process_name = gls.process_name
						AND ctrl.component_name = gls.component_name
						AND ctrl.control_bt_synonym = gls.bt_synonym_name
						AND ctrl.customer_name = ctype.customer_name
						AND ctrl.project_name = ctype.project_name
						AND ctrl.req_no = ctype.req_no
						AND ctrl.process_name = ctype.process_name
						AND ctrl.component_name = ctype.component_name
						AND ctrl.control_type = ctype.ctrl_type_name
						AND sec.customer_name = @engg_customer_name
						AND sec.project_name = @engg_project_name
						AND sec.req_no = @engg_req_no
						AND sec.process_name = @process_name
						AND sec.component_name = @engg_component
						AND sec.activity_name = @activity_name
						AND sec.ui_name = @ui_name_tmp
						AND isnull(sec.section_type, 'MAIN') = 'MAIN'
						--AND gls.languageid = @language_code
					-- code added By Feroz for extjs -- start -- PNR2.0_1790
					
					UNION
					
					SELECT upper(control_bt_synonym),
						isnull(bt_synonym_caption, control_bt_synonym),
						upper(control_id),
						upper(isnull(data_type, 'char')),
						isnull(length, 20),
						isnull(control_type, ''),
						upper(base_ctrl_type),
						ctrl.horder,
						ctrl.vorder,
						isnull(visisble_length, 0),
						isnull(proto_tooltip, ''),
						isnull(sample_data, ''),
						upper(ctrl.page_bt_synonym) AS 'page_bt_synonym',
						upper(ctrl.section_bt_synonym) AS 'section_bt_synonym',
						upper(ltrim(rtrim(mandatory_flag))),
						upper(ltrim(rtrim(ctype.visisble_flag))),
						upper(ltrim(rtrim(editable_flag))),
						upper(ltrim(rtrim(caption_req))),
						upper(ltrim(rtrim(select_flag))),
						upper(ltrim(rtrim(zoom_req))),
						upper(ltrim(rtrim(help_req))),
						upper(ltrim(rtrim(ellipses_req))),
						isnull(visisble_rows, 0),
						isnull(data_column_width, 0),
						isnull(label_column_width, 0),
						upper(isnull(caption_wrap, 'Y')),
						upper(isnull(caption_alignment, 'LEFT')),
						upper(isnull(caption_position, 'LEFT')),
						isnull(control_doc, ''),
						isnull(order_seq, 1) AS order_seq,
						upper(isnull(ctrl_position, 'LEFT')),
						upper(isnull(LabelClass, '')),
						upper(isnull(controlclass, '')),
						upper(isnull(delete_req, 'N')),
						upper(isnull(password_char, 'N')),
						upper(isnull(tskimg_class, '')),
						upper(isnull(hlpimg_class, '')),
						upper(isnull(data_column_scalemode, '%')),
						upper(isnull(label_column_scalemode, '%')),
						sec.horder,
						sec.vorder,
						upper(isnull(html_txt_area, 'N')),
						upper(isnull(Spin_required, 'N')),
						upper(isnull(spin_up_image, 'spinup.gif')),
						isnull(spin_down_image, 'spindown.gif'),
						--code modified for bugId : PNR2.0_10741
						isnull(report_req, 'N'),
						isnull(InPlace_Calendar, 'N'),
						isnull(EditMask, ''), -- Inplace Calendar and Edit Mask Feature added by Feroz
						isnull(AccessKey, ''), -- Added by Jeya
						-- Code addition for PNR2.0_20849 starts
						convert(VARCHAR, NoofLinesPerRow),
						isnull(convert(VARCHAR, RowHeight), ''),
						isnull(Vscrollbar_Req, 'N'),
						-- Code addition for PNR2.0_20849 ends
						-- Added By Feroz
						isnull(bulletlink_req, 'N'),
						isnull(buttoncombo_req, 'N'),
						isnull(associatedlist_req, 'N'),
						isnull(onfocustask_req, 'N'),
						isnull(listrefilltask_req, 'N'),
						isnull(dataascaption, 'N'),
						isnull(ListEdit_NoofColumns, 0),
						isnull(attach_document, 'N'),
						isnull(image_upload, 'N'),
						isnull(inplace_image, 'N'),
						isnull(image_row_height, 0),
						isnull(image_icon, 'N'),
						isnull(relative_url_path, ''),
						isnull(relative_document_path, ''),
						isnull(relative_image_path, ''),
						isnull(save_doc_content_to_db, 'N'),
						isnull(save_image_content_to_db, 'N'),
						isnull(Date_highlight, 'N'),
						-- Code addition for PNR2.0_21576 starts
						isnull(gridlite_req, 'N'),
						-- Code addition for PNR2.0_21576 ends
						isnull(freezecount, 0),
						isnull(Lite_Attach_Document, 'N'),
						isnull(Browse_Button_Enable, 'N'),
						isnull(Delete_Button_Enable, 'N'), --added for PNR2.0_26860 -- Code Modified for the Bug ID : PNR2.0_27796
						isnull(image_row_width, 0),
						isnull(image_preview_height, 0),
						isnull(image_preview_width, 0),
						isnull(image_preview_req, 'N'),
						isnull(Accpet_Type, ''),
						isnull(Lite_Attach_Image, 'N'), -- PNR2.0_28319
						isnull(Label_link, 'N'), --Code Added for the Bug ID PNR2.0_36309
						isnull(captiontype, 'Text'),
						isnull(controlstyle, 'Default'),
						isnull(controlimage, '') --Code added for Bug ID:PLF2.0_00961
						,
						isnull(IsListBox, ''),
						isnull(Toolbar_Not_Req, 'N'),
						isnull(ColumnBorder_Not_Req, 'N'),
						isnull(RowBorder_Not_Req, 'N'),
						isnull(PagenavigationOnly, 'N'),
						isnull(RowNO_Not_Req, 'N'),
						isnull(ButtonHome_Req, 'N'),
						isnull(ButtonPrevious_Req, 'N'),
						isnull(colspan, ''),
						isnull(rowspan, ''),
						isnull(ToolTip_Not_Req, 'N'),
						isnull(columncaption_Not_Req, 'N'),
						isnull(Border_Not_Req, 'N'),
						isnull(IsModal, 'N'),
						isnull(Alternate_Color_Req, 'N'), --PLF2.0_03057
						isnull(Map_In_Req, 'N'),
						isnull(Map_Out_Req, 'N'),
						isnull(FileSize, ''),
						isnull(ISDeviceInfo, 'N'),
						isnull(Datagrid, 'N'),
						isnull(Email, 'N'),
						isnull(TemplateID, ''),
						isnull(Phone, 'N'),
						isnull(StaticCaption, 'N'),
						isnull(ctype.Orientation, 'Horizontal'), --TECH-75230
						isnull(Listcontrol, 'N'),
						isnull(ctype.col_caption_align, ''),
						isnull(ctype.Gridheaderstyle, ''),
						isnull(ctype.Gridtoolbarstyle, ''),
						isnull(ctype.preevent, ''),
						isnull(ctype.postevent, ''),
						isnull(ctype.ishijri, 'N'),
						isnull(ctype.avn_download, ''),
						isnull(ctype.spin_system_task, ''),
						isnull(ispivot, 'N'),
						isnull(TemplateCategory, ''),
						isnull(TemplateSpecific, ''),
						isnull(ctype.RatingType, ''),
						isnull(CaptchaData, ''),
						isnull(Control_class_ext6, ''),
						upper(isnull(renderas, '')),
						isnull(icon_class, ''),
						isnull(icon_position, ''),
						isnull(preserve_gridposition, '')
					FROM ep_published_ui_control_dtl ctrl(NOLOCK),
						ep_published_ui_section_dtl sec(NOLOCK),
						@ep_published_comp_glossary_mst gls,
						es_comp_ctrl_type_mst_vw ctype(NOLOCK)
					WHERE ctrl.customer_name = sec.customer_name
						AND ctrl.project_name = sec.project_name
						AND ctrl.req_no = sec.req_no
						AND ctrl.process_name = sec.process_name
						AND ctrl.component_name = sec.component_name
						AND ctrl.activity_name = sec.activity_name
						AND ctrl.ui_name = sec.ui_name
						AND ctrl.page_bt_synonym = sec.page_bt_synonym
						AND ctrl.section_bt_synonym = sec.section_bt_synonym
						AND ctrl.customer_name = gls.customer_name
						AND ctrl.project_name = gls.project_name
						AND ctrl.req_no = gls.req_no
						AND ctrl.process_name = gls.process_name
						AND ctrl.component_name = gls.component_name
						AND ctrl.control_bt_synonym = gls.bt_synonym_name
						AND ctrl.customer_name = ctype.customer_name
						AND ctrl.project_name = ctype.project_name
						AND ctrl.process_name = ctype.process_name
						AND ctrl.component_name = ctype.component_name
						AND ctrl.control_type = ctype.ctrl_type_name
						AND sec.customer_name = @engg_customer_name
						AND sec.project_name = @engg_project_name
						AND sec.req_no = @engg_req_no
						AND sec.process_name = @process_name
						AND sec.component_name = @engg_component
						AND sec.activity_name = @activity_name
						AND sec.ui_name = @ui_name_tmp
						AND isnull(sec.section_type, 'MAIN') NOT IN (
							'MAIN',
							'TREE',
							'CHART'
							)
						AND ctype.visisble_flag = 'N'
						AND sec.visisble_flag = 'Y'
						--AND gls.languageid = @language_code
					
					UNION
					
					SELECT upper(control_bt_synonym),
						isnull(bt_synonym_caption, control_bt_synonym),
						upper(control_id),
						upper(isnull(data_type, 'char')),
						isnull(length, 20),
						isnull(control_type, ''),
						upper(base_ctrl_type),
						ctrl.horder,
						ctrl.vorder,
						isnull(visisble_length, 0),
						isnull(proto_tooltip, ''),
						isnull(sample_data, ''),
						upper(ctrl.page_bt_synonym) AS 'page_bt_synonym',
						upper(ctrl.section_bt_synonym) AS 'section_bt_synonym',
						upper(ltrim(rtrim(mandatory_flag))),
						upper(ltrim(rtrim(ctype.visisble_flag))),
						upper(ltrim(rtrim(editable_flag))),
						upper(ltrim(rtrim(caption_req))),
						upper(ltrim(rtrim(select_flag))),
						upper(ltrim(rtrim(zoom_req))),
						upper(ltrim(rtrim(help_req))),
						upper(ltrim(rtrim(ellipses_req))),
						isnull(visisble_rows, 0),
						isnull(data_column_width, 0),
						isnull(label_column_width, 0),
						upper(isnull(caption_wrap, 'Y')),
						upper(isnull(caption_alignment, 'LEFT')),
						upper(isnull(caption_position, 'LEFT')),
						isnull(control_doc, ''),
						isnull(order_seq, 1) AS order_seq,
						upper(isnull(ctrl_position, 'LEFT')),
						upper(isnull(LabelClass, '')),
						upper(isnull(controlclass, '')),
						upper(isnull(delete_req, 'N')),
						upper(isnull(password_char, 'N')),
						upper(isnull(tskimg_class, '')),
						upper(isnull(hlpimg_class, '')),
						upper(isnull(data_column_scalemode, '%')),
						upper(isnull(label_column_scalemode, '%')),
						sec.horder,
						sec.vorder,
						upper(isnull(html_txt_area, 'N')),
						upper(isnull(Spin_required, 'N')),
						upper(isnull(spin_up_image, 'spinup.gif')),
						isnull(spin_down_image, 'spindown.gif'),
						--code modified for bugId : PNR2.0_10741
						isnull(report_req, 'N'),
						isnull(InPlace_Calendar, 'N'),
						isnull(EditMask, ''), -- Inplace Calendar and Edit Mask Feature added by Feroz
						isnull(AccessKey, ''), -- Added by Jeya
						-- Code addition for PNR2.0_20849 starts
						convert(VARCHAR, NoofLinesPerRow),
						isnull(convert(VARCHAR, RowHeight), ''),
						isnull(Vscrollbar_Req, 'N'),
						-- Code addition for PNR2.0_20849 ends
						-- Added By Feroz
						isnull(bulletlink_req, 'N'),
						isnull(buttoncombo_req, 'N'),
						isnull(associatedlist_req, 'N'),
						isnull(onfocustask_req, 'N'),
						isnull(listrefilltask_req, 'N'),
						isnull(dataascaption, 'N'),
						isnull(ListEdit_NoofColumns, 0),
						isnull(attach_document, 'N'),
						isnull(image_upload, 'N'),
						isnull(inplace_image, 'N'),
						isnull(image_row_height, 0),
						isnull(image_icon, 'N'),
						isnull(relative_url_path, ''),
						isnull(relative_document_path, ''),
						isnull(relative_image_path, ''),
						isnull(save_doc_content_to_db, 'N'),
						isnull(save_image_content_to_db, 'N'),
						isnull(Date_highlight, 'N'),
						-- Code addition for PNR2.0_21576 starts
						isnull(gridlite_req, 'N'),
						-- Code addition for PNR2.0_21576 ends
						isnull(freezecount, 0),
						isnull(Lite_Attach_Document, 'N'),
						isnull(Browse_Button_Enable, 'N'),
						isnull(Delete_Button_Enable, 'N'), --added for PNR2.0_26860 -- Code Modified for the Bug ID : PNR2.0_27796
						isnull(image_row_width, 0),
						isnull(image_preview_height, 0),
						isnull(image_preview_width, 0),
						isnull(image_preview_req, 'N'),
						isnull(Accpet_Type, ''),
						isnull(Lite_Attach_Image, 'N'), -- PNR2.0_28319
						isnull(Label_link, 'N'), --Code Added for the Bug ID PNR2.0_36309
						isnull(captiontype, 'Text'),
						isnull(controlstyle, 'Default'),
						isnull(controlimage, '') --Code added for Bug ID:PLF2.0_00961
						,
						isnull(IsListBox, ''),
						isnull(Toolbar_Not_Req, 'N'),
						isnull(ColumnBorder_Not_Req, 'N'),
						isnull(RowBorder_Not_Req, 'N'),
						isnull(PagenavigationOnly, 'N'),
						isnull(RowNO_Not_Req, 'N'),
						isnull(ButtonHome_Req, 'N'),
						isnull(ButtonPrevious_Req, 'N'),
						isnull(colspan, ''),
						isnull(rowspan, ''),
						isnull(ToolTip_Not_Req, 'N'),
						isnull(columncaption_Not_Req, 'N'),
						isnull(Border_Not_Req, 'N'),
						isnull(IsModal, 'N'),
						isnull(Alternate_Color_Req, 'N'), --PLF2.0_03057
						isnull(Map_In_Req, 'N'),
						isnull(Map_Out_Req, 'N'),
						isnull(FileSize, ''),
						isnull(ISDeviceInfo, 'N'),
						isnull(Datagrid, 'N'),
						isnull(Email, 'N'),
						isnull(TemplateID, ''),
						isnull(Phone, 'N'),
						isnull(StaticCaption, 'N'),
						isnull(ctype.Orientation, 'Horizontal'), --TECH-75230
						isnull(Listcontrol, 'N'),
						isnull(ctype.col_caption_align, ''),
						isnull(ctype.Gridheaderstyle, ''),
						isnull(ctype.Gridtoolbarstyle, ''),
						isnull(ctype.preevent, ''),
						isnull(ctype.postevent, ''),
						isnull(ctype.ishijri, 'N'),
						isnull(ctype.avn_download, ''),
						isnull(ctype.spin_system_task, ''),
						isnull(ispivot, 'N'),
						isnull(TemplateCategory, ''),
						isnull(TemplateSpecific, ''),
						isnull(ctype.RatingType, ''),
						isnull(CaptchaData, ''),
						isnull(Control_class_ext6, ''),
						upper(isnull(renderas, '')),
						isnull(icon_class, ''),
						isnull(icon_position, ''),
						isnull(preserve_gridposition, '')
					FROM ep_published_ui_control_dtl ctrl(NOLOCK),
						ep_published_ui_section_dtl sec(NOLOCK),
						@ep_published_comp_glossary_mst gls,
						es_comp_ctrl_type_mst_vw ctype(NOLOCK)
					WHERE ctrl.customer_name = sec.customer_name
						AND ctrl.project_name = sec.project_name
						AND ctrl.req_no = sec.req_no
						AND ctrl.process_name = sec.process_name
						AND ctrl.component_name = sec.component_name
						AND ctrl.activity_name = sec.activity_name
						AND ctrl.ui_name = sec.ui_name
						AND ctrl.page_bt_synonym = sec.page_bt_synonym
						AND ctrl.section_bt_synonym = sec.section_bt_synonym
						AND ctrl.customer_name = gls.customer_name
						AND ctrl.project_name = gls.project_name
						AND ctrl.req_no = gls.req_no
						AND ctrl.process_name = gls.process_name
						AND ctrl.component_name = gls.component_name
						AND ctrl.control_bt_synonym = gls.bt_synonym_name
						AND ctrl.customer_name = ctype.customer_name
						AND ctrl.project_name = ctype.project_name
						AND ctrl.process_name = ctype.process_name
						AND ctrl.component_name = ctype.component_name
						AND ctrl.control_type = ctype.ctrl_type_name
						AND sec.customer_name = @engg_customer_name
						AND sec.project_name = @engg_project_name
						AND sec.req_no = @engg_req_no
						AND sec.process_name = @process_name
						AND sec.component_name = @engg_component
						AND sec.activity_name = @activity_name
						AND sec.ui_name = @ui_name_tmp
						AND isnull(sec.section_type, 'MAIN') = 'MAIN'
						AND ctype.visisble_flag = 'N'
						AND sec.visisble_flag = 'Y'
						AND ctype.is_extjs_control = 'y'
						--AND gls.languageid = @language_code
					
					UNION
					
					SELECT upper(control_bt_synonym),
						isnull(bt_synonym_caption, control_bt_synonym),
						upper(control_id),
						upper(isnull(data_type, 'char')),
						isnull(length, 20),
						isnull(control_type, ''),
						upper(base_ctrl_type),
						ctrl.horder,
						ctrl.vorder,
						isnull(visisble_length, 0),
						isnull(proto_tooltip, ''),
						isnull(sample_data, ''),
						upper(ctrl.page_bt_synonym) AS 'page_bt_synonym',
						upper(ctrl.section_bt_synonym) AS 'section_bt_synonym',
						upper(ltrim(rtrim(mandatory_flag))),
						upper(ltrim(rtrim(ctype.visisble_flag))),
						upper(ltrim(rtrim(editable_flag))),
						upper(ltrim(rtrim(caption_req))),
						upper(ltrim(rtrim(select_flag))),
						upper(ltrim(rtrim(zoom_req))),
						upper(ltrim(rtrim(help_req))),
						upper(ltrim(rtrim(ellipses_req))),
						isnull(visisble_rows, 0),
						isnull(data_column_width, 0),
						isnull(label_column_width, 0),
						upper(isnull(caption_wrap, 'Y')),
						upper(isnull(caption_alignment, 'LEFT')),
						upper(isnull(caption_position, 'LEFT')),
						isnull(control_doc, ''),
						isnull(order_seq, 1) AS order_seq,
						upper(isnull(ctrl_position, 'LEFT')),
						upper(isnull(LabelClass, '')),
						upper(isnull(controlclass, '')),
						upper(isnull(delete_req, 'N')),
						upper(isnull(password_char, 'N')),
						upper(isnull(tskimg_class, '')),
						upper(isnull(hlpimg_class, '')),
						upper(isnull(data_column_scalemode, '%')),
						upper(isnull(label_column_scalemode, '%')),
						sec.horder,
						sec.vorder,
						upper(isnull(html_txt_area, 'N')),
						upper(isnull(Spin_required, 'N')),
						upper(isnull(spin_up_image, 'spinup.gif')),
						isnull(spin_down_image, 'spindown.gif'),
						--code modified for bugId : PNR2.0_10741
						isnull(report_req, 'N'),
						isnull(InPlace_Calendar, 'N'),
						isnull(EditMask, ''), -- Inplace Calendar and Edit Mask Feature added by Feroz
						isnull(AccessKey, ''), -- Added by Jeya
						-- Code addition for PNR2.0_20849 starts
						convert(VARCHAR, NoofLinesPerRow),
						isnull(convert(VARCHAR, RowHeight), ''),
						isnull(Vscrollbar_Req, 'N'),
						-- Code addition for PNR2.0_20849 ends
						-- Added By Feroz
						isnull(bulletlink_req, 'N'),
						isnull(buttoncombo_req, 'N'),
						isnull(associatedlist_req, 'N'),
						isnull(onfocustask_req, 'N'),
						isnull(listrefilltask_req, 'N'),
						isnull(dataascaption, 'N'),
						isnull(ListEdit_NoofColumns, 0),
						isnull(attach_document, 'N'),
						isnull(image_upload, 'N'),
						isnull(inplace_image, 'N'),
						isnull(image_row_height, 0),
						isnull(image_icon, 'N'),
						isnull(relative_url_path, ''),
						isnull(relative_document_path, ''),
						isnull(relative_image_path, ''),
						isnull(save_doc_content_to_db, 'N'),
						isnull(save_image_content_to_db, 'N'),
						isnull(Date_highlight, 'N'),
						-- Code addition for PNR2.0_21576 starts
						isnull(gridlite_req, 'N'),
						-- Code addition for PNR2.0_21576 ends
						isnull(freezecount, 0),
						isnull(Lite_Attach_Document, 'N'),
						isnull(Browse_Button_Enable, 'N'),
						isnull(Delete_Button_Enable, 'N'), --added for PNR2.0_26860 -- Code Modified for the Bug ID : PNR2.0_27796
						isnull(image_row_width, 0),
						isnull(image_preview_height, 0),
						isnull(image_preview_width, 0),
						isnull(image_preview_req, 'N'),
						isnull(Accpet_Type, ''),
						isnull(Lite_Attach_Image, 'N'), -- PNR2.0_28319
						isnull(Label_link, 'N'), --Code Added for the Bug ID PNR2.0_36309
						isnull(captiontype, 'Text'),
						isnull(controlstyle, 'Default'),
						isnull(controlimage, ''),
						isnull(IsListBox, ''),
						isnull(Toolbar_Not_Req, 'N'),
						isnull(ColumnBorder_Not_Req, 'N'),
						isnull(RowBorder_Not_Req, 'N'),
						isnull(PagenavigationOnly, 'N'),
						isnull(RowNO_Not_Req, 'N'),
						isnull(ButtonHome_Req, 'N'),
						isnull(ButtonPrevious_Req, 'N'),
						isnull(colspan, ''),
						isnull(rowspan, ''),
						isnull(ToolTip_Not_Req, 'N'),
						isnull(columncaption_Not_Req, 'N'),
						isnull(Border_Not_Req, 'N'),
						isnull(IsModal, 'N'),
						isnull(Alternate_Color_Req, 'N'), --PLF2.0_03057
						isnull(Map_In_Req, 'N'),
						isnull(Map_Out_Req, 'N'),
						isnull(FileSize, ''),
						isnull(ISDeviceInfo, 'N'),
						isnull(Datagrid, 'N'),
						isnull(Email, 'N'),
						isnull(TemplateID, ''),
						isnull(Phone, 'N'),
						isnull(StaticCaption, 'N'),
						isnull(ctype.Orientation, 'Horizontal'), --TECH-75230
						isnull(Listcontrol, 'N'),
						isnull(ctype.col_caption_align, ''),
						isnull(ctype.Gridheaderstyle, ''),
						isnull(ctype.Gridtoolbarstyle, ''),
						isnull(ctype.preevent, ''),
						isnull(ctype.postevent, ''),
						isnull(ctype.ishijri, 'N'),
						isnull(ctype.avn_download, ''),
						isnull(ctype.spin_system_task, ''),
						isnull(ispivot, 'N'),
						isnull(TemplateCategory, ''),
						isnull(TemplateSpecific, ''),
						isnull(ctype.RatingType, ''),
						isnull(CaptchaData, ''),
						isnull(Control_class_ext6, ''),
						upper(isnull(renderas, '')),
						isnull(icon_class, ''),
						isnull(icon_position, ''),
						isnull(preserve_gridposition, '')
					FROM ep_published_ui_control_dtl ctrl(NOLOCK),
						ep_published_ui_section_dtl sec(NOLOCK),
						@ep_published_comp_glossary_mst gls,
						es_comp_ctrl_type_mst_vw ctype(NOLOCK)
					WHERE ctrl.customer_name = sec.customer_name
						AND ctrl.project_name = sec.project_name
						AND ctrl.req_no = sec.req_no
						AND ctrl.process_name = sec.process_name
						AND ctrl.component_name = sec.component_name
						AND ctrl.activity_name = sec.activity_name
						AND ctrl.ui_name = sec.ui_name
						AND ctrl.page_bt_synonym = sec.page_bt_synonym
						AND ctrl.section_bt_synonym = sec.section_bt_synonym
						AND ctrl.customer_name = gls.customer_name
						AND ctrl.project_name = gls.project_name
						AND ctrl.req_no = gls.req_no
						AND ctrl.process_name = gls.process_name
						AND ctrl.component_name = gls.component_name
						AND ctrl.control_bt_synonym = gls.bt_synonym_name
						AND ctrl.customer_name = ctype.customer_name
						AND ctrl.project_name = ctype.project_name
						AND ctrl.process_name = ctype.process_name
						AND ctrl.component_name = ctype.component_name
						AND ctrl.control_type = ctype.ctrl_type_name
						AND sec.customer_name = @engg_customer_name
						AND sec.project_name = @engg_project_name
						AND sec.req_no = @engg_req_no
						AND sec.process_name = @process_name
						AND sec.component_name = @engg_component
						AND sec.activity_name = @activity_name
						AND sec.ui_name = @ui_name_tmp
						AND isnull(sec.section_type, 'MAIN') = 'PopUp'
						--AND gls.languageid = @language_code
					--Code added for Bug ID:PLF2.0_00961   ends
					/* Code modified by Makesh Prabu R to change the scripts 90 compatible on 05-April-10 for the Case ID: PNR2.0_26469 -- Starts */
					ORDER BY page_bt_synonym,
						sec.horder,
						sec.vorder,
						section_bt_synonym,
						ctrl.horder,
						ctrl.vorder,
						order_seq
					/* Code modified by Makesh Prabu R to change the scripts 90 compatible on 05-April-10 for the Case ID: PNR2.0_26469 -- End */
					OPTION (
						HASH
					
					UNION
						) -- code modified for PNR2.0_12645
				END
				ELSE
				BEGIN
					DECLARE ctrlcurs INSENSITIVE CURSOR
					FOR
					SELECT upper(control_bt_synonym),
						isnull(bt_synonym_caption, control_bt_synonym),
						upper(control_id),
						upper(isnull(data_type, 'char')),
						isnull(length, 20),
						isnull(control_type, ''),
						upper(base_ctrl_type),
						ctrl.horder,
						ctrl.vorder,
						isnull(visisble_length, 0),
						isnull(proto_tooltip, ''),
						isnull(sample_data, ''),
						upper(ctrl.page_bt_synonym) AS 'page_bt_synonym',
						upper(ctrl.section_bt_synonym) AS 'section_bt_synonym',
						upper(ltrim(rtrim(mandatory_flag))),
						upper(rtrim(ctype.visisble_flag)),
						upper(rtrim(editable_flag)),
						upper(rtrim(caption_req)),
						upper(rtrim(select_flag)),
						upper(rtrim(zoom_req)),
						upper(rtrim(help_req)),
						upper(rtrim(ellipses_req)),
						isnull(visisble_rows, 0),
						isnull(data_column_width, 0),
						isnull(label_column_width, 0),
						upper(isnull(caption_wrap, 'Y')),
						upper(isnull(caption_alignment, 'LEFT')),
						upper(isnull(caption_position, 'LEFT')),
						isnull(control_doc, ''),
						isnull(order_seq, 1) AS order_seq,
						upper(isnull(ctrl_position, 'LEFT')),
						upper(isnull(LabelClass, '')),
						upper(isnull(controlclass, '')),
						upper(isnull(delete_req, 'N')),
						upper(isnull(password_char, 'N')),
						upper(isnull(tskimg_class, '')),
						upper(isnull(hlpimg_class, '')),
						upper(isnull(data_column_scalemode, '%')),
						upper(isnull(label_column_scalemode, '%')),
						sec.horder,
						sec.vorder,
						upper(isnull(html_txt_area, 'N')),
						upper(isnull(Spin_required, 'N')),
						upper(isnull(spin_up_image, 'spinup.gif')),
						isnull(spin_down_image, 'spindown.gif'),
						--code modified for bugId : PNR2.0_10741
						isnull(report_req, 'N'),
						isnull(InPlace_Calendar, 'N'),
						isnull(EditMask, ''), -- Inplace Calendar and Edit Mask Feature added by Feroz
						isnull(AccessKey, ''), -- Added by Jeya
						-- Code addition for PNR2.0_20849 starts
						convert(VARCHAR, NoofLinesPerRow),
						isnull(convert(VARCHAR, RowHeight), ''),
						isnull(Vscrollbar_Req, 'N'),
						-- Code addition for PNR2.0_20849 ends
						-- Added By Feroz
						isnull(bulletlink_req, 'N'),
						isnull(buttoncombo_req, 'N'),
						isnull(associatedlist_req, 'N'),
						isnull(onfocustask_req, 'N'),
						isnull(listrefilltask_req, 'N'),
						isnull(dataascaption, 'N'),
						isnull(ListEdit_NoofColumns, 0),
						isnull(attach_document, 'N'),
						isnull(image_upload, 'N'),
						isnull(inplace_image, 'N'),
						isnull(image_row_height, 0),
						isnull(image_icon, 'N'),
						isnull(relative_url_path, ''),
						isnull(relative_document_path, ''),
						isnull(relative_image_path, ''),
						isnull(save_doc_content_to_db, 'N'),
						isnull(save_image_content_to_db, 'N'),
						isnull(Date_highlight, 'N'),
						-- Code addition for PNR2.0_21576 starts
						isnull(gridlite_req, 'N'),
						-- Code addition for PNR2.0_21576 ends
						isnull(freezecount, 0),
						isnull(Lite_Attach_Document, 'N'),
						isnull(Browse_Button_Enable, 'N'),
						isnull(Delete_Button_Enable, 'N'), --added for PNR2.0_26860 -- Code Modified for the Bug ID : PNR2.0_27796
						isnull(image_row_width, 0),
						isnull(image_preview_height, 0),
						isnull(image_preview_width, 0),
						isnull(image_preview_req, 'N'),
						isnull(Accpet_Type, ''),
						isnull(Lite_Attach_Image, 'N'), -- PNR2.0_28319
						isnull(Label_link, 'N'), --Code Added for the Bug ID PNR2.0_36309
						isnull(captiontype, 'Text'),
						isnull(controlstyle, 'Default'),
						isnull(controlimage, '') --Code added for Bug ID:PLF2.0_00961
						,
						isnull(IsListBox, ''),
						isnull(Toolbar_Not_Req, 'N'),
						isnull(ColumnBorder_Not_Req, 'N'),
						isnull(RowBorder_Not_Req, 'N'),
						isnull(PagenavigationOnly, 'N'),
						isnull(RowNO_Not_Req, 'N'),
						isnull(ButtonHome_Req, 'N'),
						isnull(ButtonPrevious_Req, 'N'),
						isnull(colspan, ''),
						isnull(rowspan, ''),
						isnull(ToolTip_Not_Req, 'N'),
						isnull(columncaption_Not_Req, 'N'),
						isnull(Border_Not_Req, 'N'),
						isnull(IsModal, 'N'),
						isnull(Alternate_Color_Req, 'N'), --PLF2.0_03057
						isnull(Map_In_Req, 'N'),
						isnull(Map_Out_Req, 'N'),
						isnull(FileSize, ''),
						isnull(ISDeviceInfo, 'N'),
						isnull(Datagrid, 'N'),
						isnull(Email, 'N'),
						isnull(TemplateID, ''),
						isnull(Phone, 'N'),
						isnull(StaticCaption, 'N'),
						isnull(ctype.Orientation, 'Horizontal'), --TECH-75230
						isnull(Listcontrol, 'N'),
						isnull(ctype.col_caption_align, ''),
						isnull(ctype.Gridheaderstyle, ''),
						isnull(ctype.Gridtoolbarstyle, ''),
						isnull(ctype.preevent, ''),
						isnull(ctype.postevent, ''),
						isnull(ctype.ishijri, 'N'),
						isnull(ctype.avn_download, ''),
						isnull(ctype.spin_system_task, ''),
						isnull(ispivot, 'N'),
						isnull(TemplateCategory, ''),
						isnull(TemplateSpecific, ''),
						isnull(ctype.RatingType, ''),
						isnull(CaptchaData, ''),
						isnull(Control_class_ext6, ''),
						upper(isnull(renderas, '')),
						isnull(icon_class, ''),
						isnull(icon_position, ''),
						isnull(preserve_gridposition, '')
					FROM ep_ui_control_dtl ctrl(NOLOCK),
						ep_ui_section_dtl sec(NOLOCK),
						@ep_component_glossary_mst gls,
						es_comp_ctrl_type_mst_vw ctype(NOLOCK)
					WHERE ctrl.customer_name = sec.customer_name
						AND ctrl.project_name = sec.project_name
						AND ctrl.req_no = sec.req_no
						AND ctrl.process_name = sec.process_name
						AND ctrl.component_name = sec.component_name
						AND ctrl.activity_name = sec.activity_name
						AND ctrl.ui_name = sec.ui_name
						AND ctrl.page_bt_synonym = sec.page_bt_synonym
						AND ctrl.section_bt_synonym = sec.section_bt_synonym
						AND ctrl.customer_name = gls.customer_name
						AND ctrl.project_name = gls.project_name
						AND ctrl.req_no = gls.req_no
						AND ctrl.process_name = gls.process_name
						AND ctrl.component_name = gls.component_name
						AND ctrl.control_bt_synonym = gls.bt_synonym_name
						AND ctrl.customer_name = ctype.customer_name
						AND ctrl.project_name = ctype.project_name
						AND ctrl.req_no = ctype.req_no
						AND ctrl.process_name = ctype.process_name
						AND ctrl.component_name = ctype.component_name
						AND ctrl.control_type = ctype.ctrl_type_name
						AND sec.customer_name = @engg_customer_name
						AND sec.project_name = @engg_project_name
						AND ctrl.req_no = 'Base'
						AND sec.process_name = @process_name
						AND sec.component_name = @engg_component
						AND sec.activity_name = @activity_name
						AND sec.ui_name = @ui_name_tmp
						--and  isnull(sec.section_type,'MAIN') = 'MAIN'
						AND (
							ctype.visisble_flag = 'Y'
							OR ctrl.control_type = 'Filler'
							)
						AND sec.visisble_flag = 'Y'
						--AND gls.languageid = @language_code
					
					UNION
					
					SELECT upper(control_bt_synonym),
						isnull(bt_synonym_caption, control_bt_synonym),
						upper(control_id),
						upper(isnull(data_type, 'char')),
						isnull(length, 20),
						isnull(control_type, ''),
						upper(base_ctrl_type),
						ctrl.horder,
						ctrl.vorder,
						isnull(visisble_length, 0),
						isnull(proto_tooltip, ''),
						isnull(sample_data, ''),
						upper(ctrl.page_bt_synonym) AS 'page_bt_synonym',
						upper(ctrl.section_bt_synonym) AS 'section_bt_synonym',
						'Y',
						'Y',
						'Y',
						'Y',
						'N',
						'N',
						'N',
						'N',
						'0',
						isnull(data_column_width, 0),
						isnull(label_column_width, 0),
						'Y',
						'LEFT',
						'LEFT',
						isnull(control_doc, ''),
						isnull(ctrl.order_seq, 1) AS order_seq,
						'LEFT',
						'',
						'',
						'N',
						'N',
						'',
						'',
						upper(isnull(data_column_scalemode, '%')),
						upper(isnull(label_column_scalemode, '%')),
						sec.horder,
						sec.vorder,
						'N',
						'N',
						'',
						'',
						--code modified for bugId : PNR2.0_10741
						'N',
						'N',
						'',
						isnull(AccessKey, ''), -- Added by Jeya
						-- Code addition for PNR2.0_20849 starts
						'',
						'',
						'',
						-- Code addition for PNR2.0_20849 ends
						-- Added By Feroz
						'N',
						'N',
						'N',
						'N',
						'N',
						'N',
						0,
						'N',
						'N',
						'N',
						0,
						'N',
						'',
						'',
						'',
						'N',
						'N',
						'N',
						-- Code addition for PNR2.0_21576 starts
						'',
						-- Code addition for PNR2.0_21576 ends
						isnull(freezecount, 0),
						'N',
						'N',
						'N', --added for PNR2.0_26860 -- Code Modified for the Bug ID : PNR2.0_27796
						0,
						0,
						0,
						'N',
						'',
						'N',
						'N', --PNR2.0_28319,PNR2.0_36309
						'',
						'',
						'' --Code added for Bug ID:PLF2.0_00961
						,
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'N',
						'N',
						'N',
						'',
						'N',
						'N',
						'Horizontal',
						'N',
						'',
						'',
						'',
						'',
						'',
						'N',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						''
					FROM ep_ui_control_dtl ctrl(NOLOCK),
						ep_ui_section_dtl sec(NOLOCK),
						@ep_component_glossary_mst gls,
						es_comp_stat_ctrl_type_mst ctype(NOLOCK)
					WHERE ctrl.customer_name = sec.customer_name
						AND ctrl.project_name = sec.project_name
						AND ctrl.req_no = sec.req_no
						AND ctrl.process_name = sec.process_name
						AND ctrl.component_name = sec.component_name
						AND ctrl.activity_name = sec.activity_name
						AND ctrl.ui_name = sec.ui_name
						AND ctrl.page_bt_synonym = sec.page_bt_synonym
						AND ctrl.section_bt_synonym = sec.section_bt_synonym
						AND ctrl.customer_name = gls.customer_name
						AND ctrl.project_name = gls.project_name
						AND ctrl.process_name = gls.process_name
						AND ctrl.component_name = gls.component_name
						AND ctrl.control_bt_synonym = gls.bt_synonym_name
						AND ctrl.customer_name = ctype.customer_name
						AND ctrl.project_name = ctype.project_name
						AND ctrl.process_name = ctype.process_name
						AND ctrl.component_name = ctype.component_name
						AND ctrl.control_type = ctype.ctrl_type_name
						AND sec.customer_name = @engg_customer_name
						AND sec.project_name = @engg_project_name
						AND sec.process_name = @process_name
						AND sec.component_name = @engg_component
						AND sec.activity_name = @activity_name
						AND sec.ui_name = @ui_name_tmp
						AND isnull(sec.section_type, 'MAIN') = 'MAIN'
						--AND gls.languageid = @language_code
					-- code added b y feroz for extjs -- Start  -- PNR2.0_1790
					
					UNION
					
					SELECT upper(control_bt_synonym),
						isnull(bt_synonym_caption, control_bt_synonym),
						upper(control_id),
						upper(isnull(data_type, 'char')),
						isnull(length, 20),
						isnull(control_type, ''),
						upper(base_ctrl_type),
						ctrl.horder,
						ctrl.vorder,
						isnull(visisble_length, 0),
						isnull(proto_tooltip, ''),
						isnull(sample_data, ''),
						upper(ctrl.page_bt_synonym) AS 'page_bt_synonym',
						upper(ctrl.section_bt_synonym) AS 'section_bt_synonym',
						upper(ltrim(rtrim(mandatory_flag))),
						upper(rtrim(ctype.visisble_flag)),
						upper(rtrim(editable_flag)),
						upper(rtrim(caption_req)),
						upper(rtrim(select_flag)),
						upper(rtrim(zoom_req)),
						upper(rtrim(help_req)),
						upper(rtrim(ellipses_req)),
						isnull(visisble_rows, 0),
						isnull(data_column_width, 0),
						isnull(label_column_width, 0),
						upper(isnull(caption_wrap, 'Y')),
						upper(isnull(caption_alignment, 'LEFT')),
						upper(isnull(caption_position, 'LEFT')),
						isnull(control_doc, ''),
						isnull(order_seq, 1) AS order_seq,
						upper(isnull(ctrl_position, 'LEFT')),
						upper(isnull(LabelClass, '')),
						upper(isnull(controlclass, '')),
						upper(isnull(delete_req, 'N')),
						upper(isnull(password_char, 'N')),
						upper(isnull(tskimg_class, '')),
						upper(isnull(hlpimg_class, '')),
						upper(isnull(data_column_scalemode, '%')),
						upper(isnull(label_column_scalemode, '%')),
						sec.horder,
						sec.vorder,
						upper(isnull(html_txt_area, 'N')),
						upper(isnull(Spin_required, 'N')),
						upper(isnull(spin_up_image, 'spinup.gif')),
						isnull(spin_down_image, 'spindown.gif'),
						--code modified for bugId : PNR2.0_10741
						isnull(report_req, 'N'),
						isnull(InPlace_Calendar, 'N'),
						isnull(EditMask, ''), -- Inplace Calendar and Edit Mask Feature added by Feroz
						isnull(AccessKey, ''), -- Added by Jeya
						-- Code addition for PNR2.0_20849 starts
						convert(VARCHAR, NoofLinesPerRow),
						isnull(convert(VARCHAR, RowHeight), ''),
						isnull(Vscrollbar_Req, 'N'),
						-- Code addition for PNR2.0_20849 ends
						-- Added By Feroz
						isnull(bulletlink_req, 'N'),
						isnull(buttoncombo_req, 'N'),
						isnull(associatedlist_req, 'N'),
						isnull(onfocustask_req, 'N'),
						isnull(listrefilltask_req, 'N'),
						isnull(dataascaption, 'N'),
						isnull(ListEdit_NoofColumns, 0),
						isnull(attach_document, 'N'),
						isnull(image_upload, 'N'),
						isnull(inplace_image, 'N'),
						isnull(image_row_height, 0),
						isnull(image_icon, 'N'),
						isnull(relative_url_path, ''),
						isnull(relative_document_path, ''),
						isnull(relative_image_path, ''),
						isnull(save_doc_content_to_db, 'N'),
						isnull(save_image_content_to_db, 'N'),
						isnull(Date_highlight, 'N'),
						-- Code addition for PNR2.0_21576 starts
						isnull(gridlite_req, 'N'),
						-- Code addition for PNR2.0_21576 ends
						isnull(freezecount, 0),
						isnull(Lite_Attach_Document, 'N'),
						isnull(Browse_Button_Enable, 'N'),
						isnull(Delete_Button_Enable, 'N'), --added for PNR2.0_26860 -- Code Modified for the Bug ID : PNR2.0_27796
						isnull(image_row_width, 0),
						isnull(image_preview_height, 0),
						isnull(image_preview_width, 0),
						isnull(image_preview_req, 'N'),
						isnull(Accpet_Type, ''),
						isnull(Lite_Attach_Image, 'N'), -- PNR2.0_28319
						isnull(Label_link, 'N'), --Code Added for the Bug ID PNR2.0_36309
						isnull(captiontype, 'Text'),
						isnull(controlstyle, 'Default'),
						isnull(controlimage, '') --Code added for Bug ID:PLF2.0_00961
						,
						isnull(IsListBox, ''),
						isnull(Toolbar_Not_Req, 'N'),
						isnull(ColumnBorder_Not_Req, 'N'),
						isnull(RowBorder_Not_Req, 'N'),
						isnull(PagenavigationOnly, 'N'),
						isnull(RowNO_Not_Req, 'N'),
						isnull(ButtonHome_Req, 'N'),
						isnull(ButtonPrevious_Req, 'N'),
						isnull(colspan, ''),
						isnull(rowspan, ''),
						isnull(ToolTip_Not_Req, 'N'),
						isnull(columncaption_Not_Req, 'N'),
						isnull(Border_Not_Req, 'N'),
						isnull(IsModal, 'N'),
						isnull(Alternate_Color_Req, 'N'), --PLF2.0_03057
						isnull(Map_In_Req, 'N'),
						isnull(Map_Out_Req, 'N'),
						isnull(FileSize, ''),
						isnull(ISDeviceInfo, 'N'),
						isnull(Datagrid, 'N'),
						isnull(Email, 'N'),
						isnull(TemplateID, ''),
						isnull(Phone, 'N'),
						isnull(StaticCaption, 'N'),
						isnull(ctype.Orientation, 'Horizontal'), --TECH-75230
						isnull(Listcontrol, 'N'),
						isnull(ctype.col_caption_align, ''),
						isnull(ctype.Gridheaderstyle, ''),
						isnull(ctype.Gridtoolbarstyle, ''),
						isnull(ctype.preevent, ''),
						isnull(ctype.postevent, ''),
						isnull(ctype.ishijri, 'N'),
						isnull(ctype.avn_download, ''),
						isnull(ctype.spin_system_task, ''),
						isnull(ispivot, 'N'),
						isnull(TemplateCategory, ''),
						isnull(TemplateSpecific, ''),
						isnull(ctype.RatingType, ''),
						isnull(CaptchaData, ''),
						isnull(Control_class_ext6, ''),
						upper(isnull(renderas, '')),
						isnull(icon_class, ''),
						isnull(icon_position, ''),
						isnull(preserve_gridposition, '')
					FROM ep_ui_control_dtl ctrl(NOLOCK),
						ep_ui_section_dtl sec(NOLOCK),
						@ep_component_glossary_mst gls,
						es_comp_ctrl_type_mst_vw ctype(NOLOCK)
					WHERE ctrl.customer_name = sec.customer_name
						AND ctrl.project_name = sec.project_name
						AND ctrl.component_name = sec.component_name
						AND ctrl.activity_name = sec.activity_name
						AND ctrl.ui_name = sec.ui_name
						AND ctrl.page_bt_synonym = sec.page_bt_synonym
						AND ctrl.section_bt_synonym = sec.section_bt_synonym
						AND ctrl.customer_name = gls.customer_name
						AND ctrl.project_name = gls.project_name
						AND ctrl.process_name = gls.process_name
						AND ctrl.req_no = gls.req_no
						AND ctrl.component_name = gls.component_name
						AND ctrl.control_bt_synonym = gls.bt_synonym_name
						AND ctrl.customer_name = ctype.customer_name
						AND ctrl.project_name = ctype.project_name
						AND ctrl.process_name = ctype.process_name
						AND ctrl.component_name = ctype.component_name
						AND ctrl.control_type = ctype.ctrl_type_name
						AND sec.customer_name = @engg_customer_name
						AND sec.project_name = @engg_project_name
						AND sec.process_name = @process_name
						AND sec.component_name = @engg_component
						AND sec.activity_name = @activity_name
						AND sec.ui_name = @ui_name_tmp
						AND isnull(sec.section_type, 'MAIN') NOT IN (
							'MAIN',
							'TREE',
							'CHART'
							)
						AND ctype.visisble_flag = 'N'
						AND sec.visisble_flag = 'Y'
						--AND gls.languageid = @language_code
					
					UNION
					
					SELECT upper(control_bt_synonym),
						isnull(bt_synonym_caption, control_bt_synonym),
						upper(control_id),
						upper(isnull(data_type, 'char')),
						isnull(length, 20),
						isnull(control_type, ''),
						upper(base_ctrl_type),
						ctrl.horder,
						ctrl.vorder,
						isnull(visisble_length, 0),
						isnull(proto_tooltip, ''),
						isnull(sample_data, ''),
						upper(ctrl.page_bt_synonym) AS 'page_bt_synonym',
						upper(ctrl.section_bt_synonym) AS 'section_bt_synonym',
						upper(ltrim(rtrim(mandatory_flag))),
						upper(rtrim(ctype.visisble_flag)),
						upper(rtrim(editable_flag)),
						upper(rtrim(caption_req)),
						upper(rtrim(select_flag)),
						upper(rtrim(zoom_req)),
						upper(rtrim(help_req)),
						upper(rtrim(ellipses_req)),
						isnull(visisble_rows, 0),
						isnull(data_column_width, 0),
						isnull(label_column_width, 0),
						upper(isnull(caption_wrap, 'Y')),
						upper(isnull(caption_alignment, 'LEFT')),
						upper(isnull(caption_position, 'LEFT')),
						isnull(control_doc, ''),
						isnull(order_seq, 1) AS order_seq,
						upper(isnull(ctrl_position, 'LEFT')),
						upper(isnull(LabelClass, '')),
						upper(isnull(controlclass, '')),
						upper(isnull(delete_req, 'N')),
						upper(isnull(password_char, 'N')),
						upper(isnull(tskimg_class, '')),
						upper(isnull(hlpimg_class, '')),
						upper(isnull(data_column_scalemode, '%')),
						upper(isnull(label_column_scalemode, '%')),
						sec.horder,
						sec.vorder,
						upper(isnull(html_txt_area, 'N')),
						upper(isnull(Spin_required, 'N')),
						upper(isnull(spin_up_image, 'spinup.gif')),
						isnull(spin_down_image, 'spindown.gif'),
						--code modified for bugId : PNR2.0_10741
						isnull(report_req, 'N'),
						isnull(InPlace_Calendar, 'N'),
						isnull(EditMask, ''), -- Inplace Calendar and Edit Mask Feature added by Feroz
						isnull(AccessKey, ''), -- Added by Jeya
						-- Code addition for PNR2.0_20849 starts
						convert(VARCHAR, NoofLinesPerRow),
						isnull(convert(VARCHAR, RowHeight), ''),
						isnull(Vscrollbar_Req, 'N'),
						-- Code addition for PNR2.0_20849 ends
						-- Added By Feroz
						isnull(bulletlink_req, 'N'),
						isnull(buttoncombo_req, 'N'),
						isnull(associatedlist_req, 'N'),
						isnull(onfocustask_req, 'N'),
						isnull(listrefilltask_req, 'N'),
						isnull(dataascaption, 'N'),
						isnull(ListEdit_NoofColumns, 0),
						isnull(attach_document, 'N'),
						isnull(image_upload, 'N'),
						isnull(inplace_image, 'N'),
						isnull(image_row_height, 0),
						isnull(image_icon, 'N'),
						isnull(relative_url_path, ''),
						isnull(relative_document_path, ''),
						isnull(relative_image_path, ''),
						isnull(save_doc_content_to_db, 'N'),
						isnull(save_image_content_to_db, 'N'),
						isnull(Date_highlight, 'N'),
						-- Code addition for PNR2.0_21576 starts
						isnull(gridlite_req, 'N'),
						-- Code addition for PNR2.0_21576 ends
						isnull(freezecount, 0),
						isnull(Lite_Attach_Document, 'N'),
						isnull(Browse_Button_Enable, 'N'),
						isnull(Delete_Button_Enable, 'N'), --added for PNR2.0_26860 -- Code Modified for the Bug ID : PNR2.0_27796
						isnull(image_row_width, 0),
						isnull(image_preview_height, 0),
						isnull(image_preview_width, 0),
						isnull(image_preview_req, 'N'),
						isnull(Accpet_Type, ''),
						isnull(Lite_Attach_Image, 'N'), -- PNR2.0_28319
						isnull(Label_link, 'N'), --Code Added for the Bug ID PNR2.0_36309
						isnull(captiontype, 'Text'),
						isnull(controlstyle, 'Default'),
						isnull(controlimage, '') --Code added for Bug ID:PLF2.0_00961
						,
						isnull(IsListBox, ''),
						isnull(Toolbar_Not_Req, 'N'),
						isnull(ColumnBorder_Not_Req, 'N'),
						isnull(RowBorder_Not_Req, 'N'),
						isnull(PagenavigationOnly, 'N'),
						isnull(RowNO_Not_Req, 'N'),
						isnull(ButtonHome_Req, 'N'),
						isnull(ButtonPrevious_Req, 'N'),
						isnull(colspan, ''),
						isnull(rowspan, ''),
						isnull(ToolTip_Not_Req, 'N'),
						isnull(columncaption_Not_Req, 'N'),
						isnull(Border_Not_Req, 'N'),
						isnull(IsModal, 'N'),
						isnull(Alternate_Color_Req, 'N'), --PLF2.0_03057
						isnull(Map_In_Req, 'N'),
						isnull(Map_Out_Req, 'N'),
						isnull(FileSize, ''),
						isnull(ISDeviceInfo, 'N'),
						isnull(Datagrid, 'N'),
						isnull(Email, 'N'),
						isnull(TemplateID, ''),
						isnull(Phone, 'N'),
						isnull(StaticCaption, 'N'),
						isnull(ctype.Orientation, 'Horizontal'), --TECH-75230
						isnull(Listcontrol, 'N'),
						isnull(ctype.col_caption_align, ''),
						isnull(ctype.Gridheaderstyle, ''),
						isnull(ctype.Gridtoolbarstyle, ''),
						isnull(ctype.preevent, ''),
						isnull(ctype.postevent, ''),
						isnull(ctype.ishijri, 'N'),
						isnull(ctype.avn_download, ''),
						isnull(ctype.spin_system_task, ''),
						isnull(ispivot, 'N'),
						isnull(TemplateCategory, ''),
						isnull(TemplateSpecific, ''),
						isnull(ctype.RatingType, ''),
						isnull(CaptchaData, ''),
						isnull(Control_class_ext6, ''),
						upper(isnull(renderas, '')),
						isnull(icon_class, ''),
						isnull(icon_position, ''),
						isnull(preserve_gridposition, '')
					FROM ep_ui_control_dtl ctrl(NOLOCK),
						ep_ui_section_dtl sec(NOLOCK),
						@ep_component_glossary_mst gls,
						es_comp_ctrl_type_mst_vw ctype(NOLOCK)
					WHERE ctrl.customer_name = sec.customer_name
						AND ctrl.project_name = sec.project_name
						AND ctrl.component_name = sec.component_name
						AND ctrl.activity_name = sec.activity_name
						AND ctrl.ui_name = sec.ui_name
						AND ctrl.page_bt_synonym = sec.page_bt_synonym
						AND ctrl.section_bt_synonym = sec.section_bt_synonym
						AND ctrl.customer_name = gls.customer_name
						AND ctrl.project_name = gls.project_name
						AND ctrl.process_name = gls.process_name
						AND ctrl.req_no = gls.req_no
						AND ctrl.component_name = gls.component_name
						AND ctrl.control_bt_synonym = gls.bt_synonym_name
						AND ctrl.customer_name = ctype.customer_name
						AND ctrl.project_name = ctype.project_name
						AND ctrl.process_name = ctype.process_name
						AND ctrl.component_name = ctype.component_name
						AND ctrl.control_type = ctype.ctrl_type_name
						AND sec.customer_name = @engg_customer_name
						AND sec.project_name = @engg_project_name
						AND ctrl.req_no = 'Base'
						AND sec.process_name = @process_name
						AND sec.component_name = @engg_component
						AND sec.activity_name = @activity_name
						AND sec.ui_name = @ui_name_tmp
						AND isnull(sec.section_type, 'MAIN') = 'MAIN'
						AND ctype.visisble_flag = 'N'
						AND sec.visisble_flag = 'Y'
						AND ctype.is_extjs_control = 'y'
						--AND gls.languageid = @language_code
					
					UNION
					
					SELECT upper(control_bt_synonym),
						isnull(bt_synonym_caption, control_bt_synonym),
						upper(control_id),
						upper(isnull(data_type, 'char')),
						isnull(length, 20),
						isnull(control_type, ''),
						upper(base_ctrl_type),
						ctrl.horder,
						ctrl.vorder,
						isnull(visisble_length, 0),
						isnull(proto_tooltip, ''),
						isnull(sample_data, ''),
						upper(ctrl.page_bt_synonym) AS 'page_bt_synonym',
						upper(ctrl.section_bt_synonym) AS 'section_bt_synonym',
						upper(ltrim(rtrim(mandatory_flag))),
						upper(rtrim(ctype.visisble_flag)),
						upper(rtrim(editable_flag)),
						upper(rtrim(caption_req)),
						upper(rtrim(select_flag)),
						upper(rtrim(zoom_req)),
						upper(rtrim(help_req)),
						upper(rtrim(ellipses_req)),
						isnull(visisble_rows, 0),
						isnull(data_column_width, 0),
						isnull(label_column_width, 0),
						upper(isnull(caption_wrap, 'Y')),
						upper(isnull(caption_alignment, 'LEFT')),
						upper(isnull(caption_position, 'LEFT')),
						isnull(control_doc, ''),
						isnull(order_seq, 1) AS order_seq,
						upper(isnull(ctrl_position, 'LEFT')),
						upper(isnull(LabelClass, '')),
						upper(isnull(controlclass, '')),
						upper(isnull(delete_req, 'N')),
						upper(isnull(password_char, 'N')),
						upper(isnull(tskimg_class, '')),
						upper(isnull(hlpimg_class, '')),
						upper(isnull(data_column_scalemode, '%')),
						upper(isnull(label_column_scalemode, '%')),
						sec.horder,
						sec.vorder,
						upper(isnull(html_txt_area, 'N')),
						upper(isnull(Spin_required, 'N')),
						upper(isnull(spin_up_image, 'spinup.gif')),
						isnull(spin_down_image, 'spindown.gif'),
						--code modified for bugId : PNR2.0_10741
						isnull(report_req, 'N'),
						isnull(InPlace_Calendar, 'N'),
						isnull(EditMask, ''), -- Inplace Calendar and Edit Mask Feature added by Feroz
						isnull(AccessKey, ''), -- Added by Jeya
						-- Code addition for PNR2.0_20849 starts
						convert(VARCHAR, NoofLinesPerRow),
						isnull(convert(VARCHAR, RowHeight), ''),
						isnull(Vscrollbar_Req, 'N'),
						-- Code addition for PNR2.0_20849 ends
						-- Added By Feroz
						isnull(bulletlink_req, 'N'),
						isnull(buttoncombo_req, 'N'),
						isnull(associatedlist_req, 'N'),
						isnull(onfocustask_req, 'N'),
						isnull(listrefilltask_req, 'N'),
						isnull(dataascaption, 'N'),
						isnull(ListEdit_NoofColumns, 0),
						isnull(attach_document, 'N'),
						isnull(image_upload, 'N'),
						isnull(inplace_image, 'N'),
						isnull(image_row_height, 0),
						isnull(image_icon, 'N'),
						isnull(relative_url_path, ''),
						isnull(relative_document_path, ''),
						isnull(relative_image_path, ''),
						isnull(save_doc_content_to_db, 'N'),
						isnull(save_image_content_to_db, 'N'),
						isnull(Date_highlight, 'N'),
						-- Code addition for PNR2.0_21576 starts
						isnull(gridlite_req, 'N'),
						-- Code addition for PNR2.0_21576 ends
						isnull(freezecount, 0),
						isnull(Lite_Attach_Document, 'N'),
						isnull(Browse_Button_Enable, 'N'),
						isnull(Delete_Button_Enable, 'N'), --added for PNR2.0_26860 -- Code Modified for the Bug ID : PNR2.0_27796
						isnull(image_row_width, 0),
						isnull(image_preview_height, 0),
						isnull(image_preview_width, 0),
						isnull(image_preview_req, 'N'),
						isnull(Accpet_Type, ''),
						isnull(Lite_Attach_Image, 'N'), -- PNR2.0_28319
						isnull(Label_link, 'N'), --Code Added for the Bug ID PNR2.0_36309
						isnull(captiontype, 'Text'),
						isnull(controlstyle, 'Default'),
						isnull(controlimage, ''),
						isnull(IsListBox, ''),
						isnull(Toolbar_Not_Req, 'N'),
						isnull(ColumnBorder_Not_Req, 'N'),
						isnull(RowBorder_Not_Req, 'N'),
						isnull(PagenavigationOnly, 'N'),
						isnull(RowNO_Not_Req, 'N'),
						isnull(ButtonHome_Req, 'N'),
						isnull(ButtonPrevious_Req, 'N'),
						isnull(colspan, ''),
						isnull(rowspan, ''),
						isnull(ToolTip_Not_Req, 'N'),
						isnull(columncaption_Not_Req, 'N'),
						isnull(Border_Not_Req, 'N'),
						isnull(IsModal, 'N'),
						isnull(Alternate_Color_Req, 'N'),
						isnull(Map_In_Req, 'N'),
						isnull(Map_Out_Req, 'N'),
						isnull(FileSize, '') --PLF2.0_03057
						,
						isnull(ISDeviceInfo, 'N'),
						isnull(Datagrid, 'N'),
						isnull(Email, 'N'),
						isnull(TemplateID, ''),
						isnull(Phone, 'N'),
						isnull(StaticCaption, 'N'),
						isnull(ctype.Orientation, 'Horizontal'), --TECH-75230
						isnull(Listcontrol, 'N'),
						isnull(ctype.col_caption_align, ''),
						isnull(ctype.Gridheaderstyle, ''),
						isnull(ctype.Gridtoolbarstyle, ''),
						isnull(ctype.preevent, ''),
						isnull(ctype.postevent, ''),
						isnull(ctype.ishijri, 'N'),
						isnull(ctype.avn_download, ''),
						isnull(ctype.spin_system_task, ''),
						isnull(ispivot, 'N'),
						isnull(TemplateCategory, ''),
						isnull(TemplateSpecific, ''),
						isnull(ctype.RatingType, ''),
						isnull(CaptchaData, ''),
						isnull(Control_class_ext6, ''),
						upper(isnull(renderas, '')),
						isnull(icon_class, ''),
						isnull(icon_position, ''),
						isnull(preserve_gridposition, '')
					FROM ep_ui_control_dtl ctrl(NOLOCK),
						ep_ui_section_dtl sec(NOLOCK),
						@ep_component_glossary_mst gls,
						es_comp_ctrl_type_mst_vw ctype(NOLOCK)
					WHERE ctrl.customer_name = sec.customer_name
						AND ctrl.project_name = sec.project_name
						AND ctrl.req_no = sec.req_no
						AND ctrl.process_name = sec.process_name
						AND ctrl.component_name = sec.component_name
						AND ctrl.activity_name = sec.activity_name
						AND ctrl.ui_name = sec.ui_name
						AND ctrl.page_bt_synonym = sec.page_bt_synonym
						AND ctrl.section_bt_synonym = sec.section_bt_synonym
						AND ctrl.customer_name = gls.customer_name
						AND ctrl.project_name = gls.project_name
						AND ctrl.req_no = gls.req_no
						AND ctrl.process_name = gls.process_name
						AND ctrl.component_name = gls.component_name
						AND ctrl.control_bt_synonym = gls.bt_synonym_name
						AND ctrl.customer_name = ctype.customer_name
						AND ctrl.project_name = ctype.project_name
						AND ctrl.req_no = ctype.req_no
						AND ctrl.process_name = ctype.process_name
						AND ctrl.component_name = ctype.component_name
						AND ctrl.control_type = ctype.ctrl_type_name
						AND sec.customer_name = @engg_customer_name
						AND sec.project_name = @engg_project_name
						AND ctrl.req_no = 'Base'
						AND sec.process_name = @process_name
						AND sec.component_name = @engg_component
						AND sec.activity_name = @activity_name
						AND sec.ui_name = @ui_name_tmp
						AND isnull(sec.section_type, 'MAIN') = 'PopUp'
						--AND gls.languageid = @language_code
					--Code added for Bug ID:PLF2.0_00961 ends
					/* Code modified by Makesh Prabu R to change the scripts 90 compatible on 05-April-10 for the Case ID: PNR2.0_26469 -- Starts */
					ORDER BY page_bt_synonym,
						sec.horder,
						sec.vorder,
						section_bt_synonym,
						ctrl.vorder,
						ctrl.horder,
						order_seq
					/* Code modified by Makesh Prabu R to change the scripts 90 compatible on 05-April-10 for the Case ID: PNR2.0_26469 -- End */
					OPTION (
						HASH
					
					UNION
						) -- code modified for PNR2.0_12645
				END
			END

			-- Set Previous Section Name as blank
			SELECT @previous_section_tmp = '',
				@position_vindex_tmp = 0,
				@position_hindex_tmp = 0,
				@position_sindex_tmp = 0

			-- For each Control generate entries
			OPEN ctrlcurs

			WHILE (1 = 1)
			BEGIN
				FETCH NEXT
				FROM ctrlcurs
				INTO @control_bt_synonym_tmp,
					@ctrl_descr_tmp,
					@controlid_tmp,
					@datatype_tmp,
					@datalength_tmp,
					@control_type_tmp,
					@base_ctrl_type_tmp,
					@horder_tmp,
					@vorder_tmp,
					@visible_length_tmp,
					@proto_tooltip_tmp,
					@sample_data_tmp,
					@page_bt_synonym_tmp,
					@section_bt_synonym_tmp,
					@mandatory_flag_tmp,
					@visible_flag_tmp,
					@editable_flag_tmp,
					@caption_req_tmp,
					@select_flag_tmp,
					@zoom_req_tmp,
					@help_req_tmp,
					@ellipses_req_tmp,
					@visible_rows_tmp,
					@data_column_width_tmp,
					@label_column_width_tmp,
					@caption_wrap_tmp,
					@caption_alignment_tmp,
					@caption_position_tmp,
					@controldoc_tmp,
					@order_seq_tmp,
					@ctrl_position_tmp,
					@label_class_tmp,
					@ctrl_class_tmp,
					@delete_flag_tmp,
					@password_char_tmp,
					@task_img_tmp,
					@help_img_tmp,
					@data_column_scalemode,
					@label_column_scalemode,
					@tab_sec_horder,
					@tab_sec_vorder,
					@html_text_area,
					@spin_required,
					@spin_up_image,
					@spin_down_image,
					--code modified for bugId : PNR2.0_10741
					@report_reqd,
					@InPlaceCalendar,
					@EditMaskPattern, -- Inplace Calendar and Edit Mask Feature added by Feroz
					@AccessKey,
					-- Code addition for PNR2.0_20849 starts
					@NoofLinesPerRow,
					@RowHeight,
					@Vscrollbar_Req,
					-- Code addition for PNR2.0_20849 ends
					-- Added By Feroz
					@bulletlink_req,
					@buttoncombo_req,
					@associatedlist_req,
					@onfocustask_req,
					@listrefilltask_req,
					@dataascaption,
					@listedit_NoofColumns,
					@attach_document,
					@image_upload,
					@inplace_image,
					@image_row_height,
					@image_icon,
					@relative_url_path,
					@relative_document_path,
					@relative_image_path,
					@save_doc_content_to_db,
					@save_image_content_to_db,
					@Date_highlight_req,
					-- Code addition for PNR2.0_21576 starts
					@gridlite,
					@freezecount,
					@Lite_Attach,
					@BrowseButton,
					@DeleteButton, --added for PNR2.0_26860 -- Code Modified for the Bug ID : PNR2.0_27796
					@image_row_width,
					@image_preview_height,
					@image_preview_width,
					@image_preview_req,
					@Accept_Type,
					@Lite_Attach_Image, --PNR2.0_28319
					-- Code addition for PNR2.0_21576 ends
					@Labellink, --Code Added for the Bug ID PNR2.0_36309
					@captiontype,
					@controlstyle,
					@controlimage --Code added for Bug ID:PLF2.0_00961
					,
					@IsListBox,
					@Toolbar_Not_Req,
					@ColumnBorder_Not_Req,
					@RowBorder_Not_Req,
					@PagenavigationOnly,
					@RowNo_Not_Req,
					@ButtonHome_Req,
					@ButtonPrevious_Req,
					@ControlColSpan,
					@ControlRowSpan,
					@ToolTip_Not_Req,
					@columncaption_Not_Req,
					@Border_Not_Req,
					@IsModal,
					@Alternate_Color_Req, --PLF2.0_03057--shakthi
					@map_in_req,
					@map_out_req,
					@filesize,
					@iSDeviceInfo,
					@Datagrid,
					@Email,
					@TemplateID,
					@Phone,
					@StaticCaption,
					@orientation,
					@listControl,
					@ctrl_col_caption_align,
					@Gridheaderstyle,
					@Gridtoolbarstyle,
					@preevent,
					@postevent,
					@ishijri,
					@avn_download,
					@systemspin,
					@ispivot,
					@TemplateCat,
					@TemplateSpecific,
					@RatingType,
					@CaptchaData,
					@Control_cls_ext6,
					@renderas,
					@icon_class,
					@icon_position,
					@preserveposition -- Code added for Defect ID	: TECH-18349

				--Code added for TECH-72114 starts
				 IF EXISTS (SELECT 'x'
				 FROM ep_ui_section_Titleaction a (NOLOCK)
				 WHERE a.customer_name				= @engg_customer_name
				 AND  a.project_name				= @engg_project_name
				-- AND  a.req_no						= @engg_req_no
				 AND  a.process_name				= @process_name
				 AND  a.component_name				= @engg_component
				 AND  a.activity_name				= @activity_name
				 AND  a.ui_name						= @ui_name_tmp
				 AND  a.page_bt_synonym				= @page_bt_synonym_tmp
				 AND  a.section_bt_synonym			= @section_bt_synonym_tmp
				 AND  a.TitleControlBTSynonym		= @control_bt_synonym_tmp )
				 BEGIN
				 SELECT @visible_flag_tmp = 'N'
				 END
				 --Code added for TECH-72114 ends

				IF @@fetch_status <> 0
					BREAK

If isnull(@base_ctrl_type_tmp,'') = 'Slider'
Begin
	select @renderas = 'RSSlider'
	Select @base_ctrl_type_tmp = 'RSSlider'
End

-- Added for the Defect ID: TECH-37471 Starts for Set & LEave Focus Events
set @setfocusevent			= ''
set @leavefocusevent		= ''
set @setfocuseventoccur		= ''
set @leavefocuseventoccur	= ''
set @SpellCheckRequired		= ''
set	@UPEEnabled				= ''
set @MoreEventName			= ''

select	@setfocusevent		= upper(isnull(task_name,''))
from	ep_action_mst (nolock)
where	customer_name		= @engg_customer_name
and		project_name		= @engg_project_name
and		req_no				= @engg_req_no
and		process_name		= @process_name
and		component_name		= @engg_component
and		activity_name		= @activity_name
and		ui_name				= @ui_name_tmp
and		page_bt_synonym		= @page_bt_synonym_tmp
and		primary_control_bts	= @control_bt_synonym_tmp
and		task_descr			like 'Set Focus Event For%'

select	@leavefocusevent	= upper(isnull(task_name,''))
from	ep_action_mst (nolock)
where	customer_name		= @engg_customer_name
and		project_name		= @engg_project_name
and		req_no				= @engg_req_no
and		process_name		= @process_name
and		component_name		= @engg_component
and		activity_name		= @activity_name
and		ui_name				= @ui_name_tmp
and		page_bt_synonym		= @page_bt_synonym_tmp
and		primary_control_bts	= @control_bt_synonym_tmp
and		task_descr			like 'Leave Focus Event For%'
-- Added for the Defect ID: TECH-37471 Ends for Set & LEave Focus Events

SELECT	@setfocuseventoccur		= isnull(SetFocusEventOccurence, ''),
		@leavefocuseventoccur	= isnull(LeaveFocusEventOccurence, ''),	
		@SpellCheckRequired		= ISNULL(IsSpellcheck, 'N'),
		@IsMobile				= ISNULL(IsMobile, 'N'),
		@PaginationRequired		= ISNULL(PaginationReqd, 'N'),
		@UpdateTaskReqd			= ISNULL(UpdateTaskReqd, 'N'),
		@DeleteTaskReqd			= ISNULL(DeleteTaskReqd, 'N'),
		@RowAlwaysExpanded		= ISNULL(RowAlwaysExpanded, 'N') --Added for TECH-46646
FROM	es_comp_ctrl_type_mst_extn (NOLOCK)
where	customer_name		= @engg_customer_name
and		project_name		= @engg_project_name
and		process_name		= @process_name
and		component_name		= @engg_component
and		ctrl_type_name		= @control_type_tmp

--Added for TECH-46646 Starts
SELECT @AssociatedUpdateTask = ''
SELECT @AssociatedDeleteTask = ''

IF ISNULL(@UpdateTaskReqd, 'N') = 'Y'
BEGIN
	SELECT	@AssociatedUpdateTask= upper(isnull(task_name,''))
	FROM	ep_Action_mst (nolock)
	where	customer_name		= @engg_customer_name
	and		project_name		= @engg_project_name
	and		req_no				= @engg_req_no
	and		process_name		= @process_name
	and		component_name		= @engg_component
	and		activity_name		= @activity_name
	and		ui_name				= @ui_name_tmp
	and		page_bt_synonym		= @page_bt_synonym_tmp
	and		primary_control_bts	= @control_bt_synonym_tmp
	and		task_descr			= 'AssociatedUpdateTask'
END
IF ISNULL(@DeleteTaskReqd, 'N') = 'Y'
BEGIN
	SELECT	@AssociatedDeleteTask= upper(isnull(task_name,''))
	FROM	ep_Action_mst (nolock)
	where	customer_name		= @engg_customer_name
	and		project_name		= @engg_project_name
	and		req_no				= @engg_req_no
	and		process_name		= @process_name
	and		component_name		= @engg_component
	and		activity_name		= @activity_name
	and		ui_name				= @ui_name_tmp
	and		page_bt_synonym		= @page_bt_synonym_tmp
	and		primary_control_bts	= @control_bt_synonym_tmp
	and		task_descr			= 'AssociatedDeleteTask'
END
--Added for TECH-46646 Ends


				SET @Control_cls_ext6 = ''
				SET @Icon_Class = ''

				SELECT @scan = isnull(scan, 'N'),
					@autoselect = isnull(autoselect, 'N')
				FROM es_comp_ctrl_type_mst_extn(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @process_name
					AND component_name = @engg_component
					AND ctrl_type_name = @control_type_tmp

				IF isnull(@scan, 'N') = 'Y'
					SELECT @renderas = 'SCAN'

				--if @base_ctrl_type_tmp ='grid'
				--declare @renderas1 engg_name
				--select @renderas1 =''
				--select	@renderas1	= isnull(renderas,'N')  -- 11537
				--		from    es_comp_ctrl_type_mst (nolock)
				--where   customer_name   = @engg_customer_name
				--and		project_name    = @engg_project_name
				--and		process_name    = @process_name
				--and		component_name  = @engg_component
				--and		ctrl_type_name	= @control_type_tmp
				--	If isnull(@renderas1,'N')	= 'CALENDAR'
				--	select @renderas1 = 'CALENDAR'

Declare @editmask	engg_flag
Declare @IsToggle	engg_flag

SET @editmask = ''
SET @IsToggle = ''

select	@editmask		= isnull(EditMask,'N')
from    es_comp_ctrl_type_mst (nolock)
where   customer_name   = @engg_customer_name
and		project_name    = @engg_project_name
and		process_name    = @process_name
and		component_name  = @engg_component
and		ctrl_type_name	= @control_type_tmp

-- Code Added for the Defect ID TECH-27286 Starts
select	@IsToggle		= isnull(IsToggle,'N')
from    es_comp_ctrl_type_mst_Extn (nolock)
where   customer_name   = @engg_customer_name
and		project_name    = @engg_project_name
and		process_name    = @process_name
and		component_name  = @engg_component
and		ctrl_type_name	= @control_type_tmp
and		base_ctrl_type	= 'CheckBox'

If isnull(@editmask,'N')	= 'Y'
	select @renderas = 'EDITMASK'
If isnull(@IsToggle,'N')	= 'Y'
	select @renderas = 'Toggle'
Else 
	select @renderas = @renderas
-- Code Added for the Defect ID TECH-27286 Ends

--TECH-72114

SELECT @BadgeText = ''

SELECT	@BadgeText		= ISNULL(BadgeText,'N') 
FROM    es_comp_ctrl_type_mst_Extn WITH (NOLOCK)
WHERE   customer_name   = @engg_customer_name
AND		project_name    = @engg_project_name
AND		process_name    = @process_name
AND		component_name  = @engg_component
AND		ctrl_type_name	= @control_type_tmp
AND		base_ctrl_type	= 'DataHyperLink'

IF ISNULL(@BadgeText,'')	= ''
	SELECT @BadgeText = 'N'

SELECT @AutoHeight = ''

SELECT	@AutoHeight		= ISNULL(AutoHeight,'N') 
FROM    es_comp_ctrl_type_mst_Extn WITH (NOLOCK)
WHERE   customer_name   = @engg_customer_name
AND		project_name    = @engg_project_name
AND		process_name    = @process_name
AND		component_name  = @engg_component
AND		ctrl_type_name	= @control_type_tmp
AND		base_ctrl_type	= 'Grid'

IF ISNULL(@AutoHeight,'')	= ''
	SELECT @AutoHeight = 'N'

--TECH-72114

				IF @base_ctrl_type_tmp IN ('grid')
				BEGIN
					IF EXISTS (
							SELECT 'x'
							FROM ep_published_ui_control_dtl a(NOLOCK),
								ep_published_calendar_configure b(NOLOCK)
							WHERE a.customer_name = @engg_customer_name
								AND a.project_name = @engg_project_name
								AND a.req_no = @engg_req_no
								AND a.process_name = @process_name
								AND a.component_name = @engg_component
								AND a.activity_name = @activity_name
								AND a.ui_name = @ui_name_tmp
								AND a.section_bt_synonym = @section_bt_synonym_tmp
								AND a.control_type = 'CalGrid'
								AND a.customer_name = b.customer_name
								AND a.project_name = b.project_name
								AND a.process_name = b.process_name
								AND a.component_name = b.component_name
								AND a.activity_name = b.activity_name
								AND a.ui_name = b.ui_name
								AND a.section_bt_synonym = b.section_name
								AND a.req_no = b.req_no
							)
					BEGIN
						SELECT @renderas = 'CALENDAR'
					END
				END

				IF isnull(@renderas, '') = ''
					SELECT @renderas = @base_ctrl_type_tmp

				--For Control Class implementation ext6
				IF @Control_class_ext6 <> ''
				BEGIN
					SET @Control_cls_ext6 = substring(@Control_class_ext6, 1, charindex('~', @Control_class_ext6) - 1)
					SET @Icon_Class = substring(@Control_class_ext6, charindex('~', @Control_class_ext6) + 1, len(@Control_class_ext6))
				END

				If @Control_class_ext6 <> '' and   charindex('~',@Control_cls_ext6) = 0 
							Set  @Control_cls_ext6   = @Control_class_ext6
				
				-- @Icon_Class case sensitive has been done here
				If @base_ctrl_type_tmp in ('button','link', 'Edit') --code Modified for Defect ID : TECH-39534
					Set @Classprops  = 'IconClass="'		+ isnull((@Icon_Class),'')  +'" ' + 
											  'IconPosition="'		+ isnull(@Icon_Position,'')  +'" ' +''
				else 
					Set @Classprops  = ''
			

				--Added for TECH-46646
				IF isnull(@Icon_Class,'') NOT IN ('', 'Dynamic') AND ISNULL(@Image_Icon , 'N')  = 'N'
				SELECT @ImageType = 'Static'
				ELSE IF isnull(@Icon_Class,'') = 'Dynamic' AND ISNULL(@Image_Icon , 'N')  = 'N'
				SELECT @ImageType = 'Dynamic'

				--For Home and previous button
				IF @ButtonHome_Req = 'Y'
					SELECT @extjs_values = ' ExtType="Home" ',
						@exttype = 'Home'
				ELSE IF @ButtonPrevious_Req = 'Y'
					SELECT @extjs_values = ' ExtType="Previous" ',
						@exttype = 'Previous'
				ELSE
					SELECT @exttype = '',
						@extjs_values = ''

				-- Start For Inplace Calender added by Feroz
				IF isnull(@InPlaceCalendar, 'N') = 'Y'
					AND @datatype_tmp = 'Date'
					SELECT @InPlaceCalendar = 'y'
				ELSE
					SELECT @InPlaceCalendar = 'n'

				IF isnull(@InPlaceCalendar, 'N') = 'Y'
					AND isnull(@editable_flag_tmp, 'N') = 'Y'
					SELECT @InPlaceCal_Display = 'y'
				ELSE
					SELECT @InPlaceCal_Display = 'n'

				-- end For Inplace Calender added by Feroz
				--Code added for Bug ID:PLF2.0_00961 starts
				SELECT @captiontype = replace(@captiontype, '&', '&amp;')

				SELECT @captiontype = replace(@captiontype, '<', '&lt;')

				SELECT @captiontype = replace(@captiontype, '>', '&gt;')

				SELECT @captiontype = replace(@captiontype, '"', '&quot;')

				SELECT @captiontype = CASE isnull(@controlstyle, '')
						WHEN 'Image'
							THEN ''
						ELSE @captiontype
						END

				--Code added for Bug ID:PLF2.0_00961 ends
				-- Added By feroz For Edit mask pattern -- start
				SELECT @EditMaskPattern = replace(@EditMaskPattern, '&', '&amp;')

				SELECT @EditMaskPattern = replace(@EditMaskPattern, '<', '&lt;')

				SELECT @EditMaskPattern = replace(@EditMaskPattern, '>', '&gt;')

				SELECT @EditMaskPattern = replace(@EditMaskPattern, '"', '&quot;')

				-- Added By feroz For Edit mask pattern -- end
				-- code added by gopinath S for the Bug ID PNR2.0_19995 starts here
				SELECT @auto_tab_stop = Auto_tab_stop
				FROM es_comp_ctrl_type_mst a(NOLOCK)
				WHERE a.customer_name = @engg_customer_name
					AND a.project_name = @engg_project_name
					AND a.process_name = @process_name
					AND a.component_name = @engg_component
					AND a.ctrl_type_name = @control_type_tmp

				-- code added by gopinath S for the Bug ID PNR2.0_19995 ens here
				-- For Spin Control
				SELECT @associated_spin_ctrl = '',
					@associated_spin_task = ''

				IF @spin_required = 'Y'
				BEGIN
					--Code Modified for bugid : PNR2.0_11183
					IF @spin_up_image = ''
						SELECT @spin_up_image = 'spinup.gif'

					IF @spin_down_image = ''
						SELECT @spin_down_image = 'spindown.gif'

					SELECT @spin_up_image = '../Themes/' + @engg_stylesheet + '/images/' + @spin_up_image,
						@spin_down_image = '../Themes/' + @engg_stylesheet + '/images/' + @spin_down_image

					IF @pubflag = 'P'
					BEGIN
						SELECT @associated_spin_ctrl = b.control_id
						FROM ep_published_spin_control_dtl a(NOLOCK),
							ep_published_ui_control_dtl b(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.req_no = @engg_req_no
							AND a.process_name = @process_name
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							AND a.page_bt_synonym = @page_bt_synonym_tmp
							AND a.control_bt_synonym = @control_bt_synonym_tmp
							AND a.customer_name = b.customer_name
							AND a.project_name = b.project_name
							AND a.req_no = b.req_no
							AND a.process_name = b.process_name
							AND a.component_name = b.component_name
							AND a.activity_name = b.activity_name
							AND a.ui_name = b.ui_name
							AND a.page_bt_synonym = b.page_bt_synonym
							AND a.spin_control_bt_synonym = b.control_bt_synonym

						SELECT @associated_spin_task = task_name
						FROM ep_published_action_mst(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND req_no = @engg_req_no
							AND process_name = @process_name
							AND component_name = @engg_component
							AND activity_name = @activity_name
							AND ui_name = @ui_name_tmp
							AND page_bt_synonym = @page_bt_synonym_tmp
							AND primary_control_bts = @associated_spin_ctrl
					END
					ELSE
					BEGIN
						SELECT @associated_spin_ctrl = b.control_id
						FROM ep_spin_control_dtl a(NOLOCK),
							ep_ui_control_dtl b(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.process_name = @process_name
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							AND a.page_bt_synonym = @page_bt_synonym_tmp
							AND a.control_bt_synonym = @control_bt_synonym_tmp
							AND a.customer_name = b.customer_name
							AND a.project_name = b.project_name
							AND a.process_name = b.process_name
							AND a.component_name = b.component_name
							AND a.activity_name = b.activity_name
							AND a.ui_name = b.ui_name
							AND a.page_bt_synonym = b.page_bt_synonym
							AND a.spin_control_bt_synonym = b.control_bt_synonym

						SELECT @associated_spin_task = task_name
						FROM ep_action_mst(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @process_name
							AND component_name = @engg_component
							AND activity_name = @activity_name
							AND ui_name = @ui_name_tmp
							AND page_bt_synonym = @page_bt_synonym_tmp
							AND primary_control_bts = @associated_spin_ctrl
					END
				END

				--Code added for Bug ID:PLF2.0_00961 starts
				IF @pubflag = 'P'
				BEGIN
					SELECT @popup_page = PopUp_page_bt_synonym,
						@popup_section = PopUp_section,
						@popup_close = upper(PopUp_close),
						@sectionlaunchtype = sectionlaunchtype -- added for SectionLaunch Type TECH-12776 
						--@iscallout = Case iscallout when 1 then 'Y' 
						--									Else 'N' End
					FROM ep_published_action_mst(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_req_no
						AND process_name = @process_name
						AND component_name = @engg_component
						AND activity_name = @activity_name
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = @page_bt_synonym_tmp
						AND primary_control_bts = @control_bt_synonym_tmp

					IF isnull(@sectionlaunchtype, '') = 'Callout'
						SELECT @iscallout = 'Y'
					ELSE IF isnull(@sectionlaunchtype, '') = 'SmartView'
						SELECT @smartviewsection = 'Y'
					ELSE IF isnull(@sectionlaunchtype, '') = ''
					BEGIN
						SELECT @iscallout = 'N'

						SELECT @smartviewsection = 'N'
					END

					IF NOT EXISTS (
							SELECT 'X'
							FROM ep_published_action_mst(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND req_no = @engg_req_no
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND page_bt_synonym = @page_bt_synonym_tmp
								AND primary_control_bts = @control_bt_synonym_tmp
							)
					BEGIN
						SELECT @popup_page = '',
							@popup_section = '',
							@popup_close = 0,
							@iscallout = 'N',
							@smartviewsection = 'N'
					END
				END
				ELSE
				BEGIN
					SELECT @popup_page = PopUp_page_bt_synonym,
						@popup_section = PopUp_section,
						@popup_close = upper(PopUp_close),
						@iscallout = CASE iscallout
							WHEN 1
								THEN 'Y'
							ELSE 'N'
							END
					FROM ep_action_mst(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @process_name
						AND component_name = @engg_component
						AND activity_name = @activity_name
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = @page_bt_synonym_tmp
						AND primary_control_bts = @control_bt_synonym_tmp

					IF NOT EXISTS (
							SELECT 'X'
							FROM ep_action_mst(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND page_bt_synonym = @page_bt_synonym_tmp
								AND primary_control_bts = @control_bt_synonym_tmp
							)
					BEGIN
						SELECT @popup_page = '',
							@popup_section = '',
							@popup_close = 0,
							@iscallout = 'N'
					END
				END

				--Code added for Bug ID:PLF2.0_00961 ends
				-- code added by Ganesh for the bugid PNR2.0_2026 on 18/4/05
				-- To include the tab index property
				SELECT @tab_seq_tmp = ''

				SELECT @tab_seq_tmp = tab_index
				FROM @temp_tab_index
				WHERE ui_name = @ui_name_tmp
					AND page_bt_synonym = @page_bt_synonym_tmp
					AND control_bt_synonym = @control_bt_synonym_tmp

				IF isnull(@tab_seq_tmp, '') = ''
				BEGIN
					SELECT @tab_seq = '',
						@tab_seq_tmp = '' -- code added by gopinath S for the Bug ID starts here
				END
				ELSE
				BEGIN
					SELECT @tab_seq = @tab_seq_tmp
				END

				SELECT @decimal_length_ctrl = NULL -- code added by Gowrisankar M on 21-Dec-2009 for PNR2.0_25330

				-- code added by Ganesh on 08/12/04 to Populate the decimal value for the numeric field
				IF @datatype_tmp = 'Numeric'
				BEGIN
					SELECT @decimal_length_ctrl = decimal_length
					FROM @ep_component_glossary_mst gls,
						de_business_term bts(NOLOCK),
						de_precision_type pt(NOLOCK)
					WHERE gls.customer_name = bts.customer_name
						AND gls.project_name = bts.project_name
						AND gls.process_name = bts.process_name
						AND gls.component_name = bts.component_name
						AND gls.bt_name = bts.bt_name
						AND bts.customer_name = pt.customer_name
						AND bts.project_name = pt.project_name
						AND bts.process_name = pt.process_name
						AND bts.component_name = pt.component_name
						AND bts.precision_type = pt.pt_name
						AND gls.customer_name = @engg_customer_name
						AND gls.project_name = @engg_project_name
						AND gls.process_name = @process_name
						AND gls.component_name = @engg_component
						AND gls.bt_synonym_name = @control_bt_synonym_tmp
						--AND gls.languageid = @language_code

					IF isnull(@decimal_length_ctrl, - 915) = - 915
					BEGIN
						SELECT @decimal_length_ctrl = 3
					END
				END
				ELSE
				BEGIN
					SELECT @decimal_length_ctrl = 0
				END

				SELECT @default_sample_data_tmp = ''

				--PNR2.0_16123
				IF @sample_data_from = 'Layout'
					AND @sample_data_tmp = ''
				BEGIN
					IF @base_ctrl_type_tmp IN (
							'Edit',
							'Button',
							'Links',
							'RadioButton',
							'CheckBox',
							'DataHyperLink'
							)
					BEGIN
						IF @ctxt_service_in IN ('BulkGenerate')
							AND @pubflag = 'P'
						BEGIN
							SELECT @sample_data_tmp = isnull(sample_data, '')
							FROM ep_published_ui_control_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND req_no = @engg_req_no
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND control_bt_synonym = @control_bt_synonym_tmp
								--and  languageid   =  @language_code
						END
						ELSE
						BEGIN
							SELECT @sample_data_tmp = isnull(sample_data, '')
							FROM ep_ui_control_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND req_no = 'Base'
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND control_bt_synonym = @control_bt_synonym_tmp
								--and  languageid   =  @language_code
						END
					END
					ELSE
					BEGIN
						IF @ctxt_service_in IN ('BulkGenerate')
							AND @pubflag = 'P'
						BEGIN
							SELECT @sample_data_tmp = isnull(sample_data, '')
							FROM ep_published_ui_control_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND req_no = @engg_req_no
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND control_bt_synonym = @control_bt_synonym_tmp
						END
						ELSE
						BEGIN
							SELECT @sample_data_tmp = isnull(sample_data, '')
							FROM ep_ui_control_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND req_no = 'Base'
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND control_bt_synonym = @control_bt_synonym_tmp
						END
					END
				END

				IF @sample_data_from = 'Glossary'
				BEGIN
					IF @base_ctrl_type_tmp IN (
							'Edit',
							'Button',
							'Links',
							'RadioButton',
							'CheckBox',
							'DataHyperLink'
							)
					BEGIN
						IF @ctxt_service_in IN ('BulkGenerate')
							AND @pubflag = 'P'
						BEGIN
							SELECT @sample_data_tmp = isnull(singleinst_sample_data, '')
							FROM @ep_published_comp_glossary_mst
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @process_name
								AND component_name = @engg_component
								AND req_no = @engg_req_no
								AND bt_synonym_name = @control_bt_synonym_tmp
								--AND languageid = @language_code
						END
						ELSE
						BEGIN
							SELECT @sample_data_tmp = isnull(singleinst_sample_data, '')
							FROM @ep_component_glossary_mst
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @process_name
								AND component_name = @engg_component
								AND req_no = @engg_req_no
								AND bt_synonym_name = @control_bt_synonym_tmp
								----AND languageid = @language_code
						END
					END
					ELSE
					BEGIN
						SELECT @sample_data_tmp = isnull(multiinst_sample_data, '')
						FROM @ep_component_glossary_mst
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @process_name
							AND component_name = @engg_component
							AND req_no = @engg_req_no
							AND bt_synonym_name = @control_bt_synonym_tmp
							----AND languageid = @language_code
					END
				END

				IF @ctxt_service_in IN ('BulkGenerate')
					AND @pubflag = 'P'
				BEGIN
					SELECT @default_sample_data_tmp = isnull(enum_caption, '')
					FROM ep_published_enum_value_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_req_no
						AND process_name = @process_name
						AND component_name = @engg_component
						AND activity_name = @activity_name
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = @page_bt_synonym_tmp
						AND section_bt_synonym = @section_bt_synonym_tmp
						AND control_bt_synonym = @control_bt_synonym_tmp
						AND default_flag = 'Y'
				END
				ELSE
				BEGIN
					SELECT @default_sample_data_tmp = isnull(enum_caption, '')
					FROM ep_enum_value_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @process_name
						AND component_name = @engg_component
						AND activity_name = @activity_name
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = @page_bt_synonym_tmp
						AND section_bt_synonym = @section_bt_synonym_tmp
						AND control_bt_synonym = @control_bt_synonym_tmp
						AND default_flag = 'Y'
				END

				-- For Static Control Types Sample Data Starts
				IF @pubflag = 'C'
				BEGIN
					IF EXISTS (
							SELECT 'x'
							FROM es_comp_stat_ctrl_type_mst(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @process_name
								AND component_name = @engg_component
								AND ctrl_type_name = @control_type_tmp
							)
					BEGIN
						SELECT @sample_data_tmp = dbo.engg_get_static_ctrl_values(@engg_customer_name, @engg_project_name, @engg_req_no, @process_name, @engg_component, @language_code, @control_type_tmp, @pubflag)

						SELECT @default_sample_data_tmp = dbo.engg_get_static_ctrl_def_value(@engg_customer_name, @engg_project_name, @engg_req_no, @process_name, @engg_component, @language_code, @control_type_tmp, @pubflag)
					END
				END
				ELSE IF @pubflag = 'P'
				BEGIN
					IF EXISTS (
							SELECT 'x'
							FROM ep_published_comp_stat_ctrl_type_mst(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND req_no = @engg_req_no
								AND process_name = @process_name
								AND component_name = @engg_component
								AND ctrl_type_name = @control_type_tmp
							)
					BEGIN
						SELECT @sample_data_tmp = dbo.engg_get_static_ctrl_values(@engg_customer_name, @engg_project_name, @engg_req_no, @process_name, @engg_component, @language_code, @control_type_tmp, @pubflag)

						SELECT @default_sample_data_tmp = dbo.engg_get_static_ctrl_def_value(@engg_customer_name, @engg_project_name, @engg_req_no, @process_name, @engg_component, @language_code, @control_type_tmp, @pubflag)
					END
				END

				-- For Static Control Types Sample Data Ends
				SELECT @default_sample_data_tmp = replace(@default_sample_data_tmp, '&', '&amp;')

				SELECT @default_sample_data_tmp = replace(@default_sample_data_tmp, '<', '&lt;')

				SELECT @default_sample_data_tmp = replace(@default_sample_data_tmp, '>', '&gt;')

				SELECT @default_sample_data_tmp = replace(@default_sample_data_tmp, '"', '&quot;')

				SELECT @ctrl_descr_tmp = replace(@ctrl_descr_tmp, '&', '&amp;')

				SELECT @ctrl_descr_tmp = replace(@ctrl_descr_tmp, '<', '&lt;')

				SELECT @ctrl_descr_tmp = replace(@ctrl_descr_tmp, '>', '&gt;')

				SELECT @ctrl_descr_tmp = replace(@ctrl_descr_tmp, '"', '&quot;')

				SELECT @sample_data_tmp = replace(@sample_data_tmp, '&', '&amp;')

				SELECT @sample_data_tmp = replace(@sample_data_tmp, '<', '&lt;')

				SELECT @sample_data_tmp = replace(@sample_data_tmp, '>', '&gt;')

				SELECT @sample_data_tmp = replace(@sample_data_tmp, '"', '&quot;')

				SELECT @controldoc_tmp = replace(@controldoc_tmp, '&', '&amp;')

				SELECT @controldoc_tmp = replace(@controldoc_tmp, '<', '&lt;')

				SELECT @controldoc_tmp = replace(@controldoc_tmp, '>', '&gt;')

				SELECT @controldoc_tmp = replace(@controldoc_tmp, '"', '&quot;')

				-- Check whether it is a new section
				IF @previous_section_tmp <> @section_bt_synonym_tmp
				BEGIN
					SELECT @position_vindex_tmp = 0,
						@position_hindex_tmp = 0,
						@position_sindex_tmp = 0
				END

				IF @ui_format_tmp = 'BES'
					AND @previous_horder_tmp <> @horder_tmp
				BEGIN
					SELECT @position_vindex_tmp = 0,
						@position_sindex_tmp = 0
				END

				IF @ui_format_tmp = 'BES'
					AND @previous_vorder_tmp <> @vorder_tmp
				BEGIN
					SELECT @position_sindex_tmp = 0
				END

				IF @ui_format_tmp = 'UND'
					AND @previous_horder_tmp <> @horder_tmp
				BEGIN
					SELECT @position_hindex_tmp = 0
				END

				--code modified for bugId : PNR2.0_10741
				IF @report_reqd = ''
					OR isnull(@report_reqd, '') = ''
					SELECT @report_reqd = 'N'

				IF @base_ctrl_type_tmp IN (
						'Edit',
						'Combo'
						)
					SELECT @default_for_tmp = 'UI'
				ELSE IF @base_ctrl_type_tmp IN ('Button')
					AND @report_reqd = 'N'
					SELECT @default_for_tmp = 'Trans'
				ELSE IF @base_ctrl_type_tmp IN ('Button')
					AND @report_reqd = 'Y'
					SELECT @default_for_tmp = 'Report'
				ELSE IF @base_ctrl_type_tmp IN ('Link')
					AND @report_reqd = 'N'
					-- Code modified by Anuradha on 08-Nov-2006 for the Bug ID :: PNR2.0_10874
					SELECT @default_for_tmp = 'Link'
				ELSE IF @base_ctrl_type_tmp IN ('Link')
					AND @report_reqd = 'Y'
					SELECT @default_for_tmp = 'Report'
						-- Code modified on 18-Feb-2009 for the Bug ID :: PNR2.0_21118 - Begins
				ELSE IF @base_ctrl_type_tmp IN ('Datahyperlink')
					AND @report_reqd = 'N'
					SELECT @default_for_tmp = 'Datahyperlink'
				ELSE IF @base_ctrl_type_tmp IN ('Datahyperlink')
					AND @report_reqd = 'Y'
					SELECT @default_for_tmp = 'Report'

				-- Code modified on 18-Feb-2009 for the Bug ID :: PNR2.0_21118 - Ends
				--Code addition  for  PNR2.0_20049  starts
				SELECT @data_type = ''

				SELECT @data_type = bts.data_type
				FROM @ep_component_glossary_mst gls,
					de_business_term bts(NOLOCK)
				WHERE gls.customer_name = bts.customer_name
					AND gls.project_name = bts.project_name
					AND gls.process_name = bts.process_name
					AND gls.component_name = bts.component_name
					AND gls.bt_name = bts.bt_name
					AND gls.customer_name = @engg_customer_name
					AND gls.project_name = @engg_project_name
					AND gls.req_no = 'Base'
					AND gls.process_name = @process_name
					AND gls.component_name = @engg_component
					AND gls.bt_synonym_name = @control_bt_synonym_tmp
					--AND gls.languageid = @language_code

				IF isnull(@data_type, '') = ''
				BEGIN
					SELECT @data_type = gls.data_type
					FROM @ep_component_glossary_mst gls
					WHERE gls.customer_name = @engg_customer_name
						AND gls.project_name = @engg_project_name
						AND gls.req_no = 'Base'
						AND gls.process_name = @process_name
						AND gls.component_name = @engg_component
						AND gls.bt_synonym_name = @control_bt_synonym_tmp
						--AND gls.languageid = @language_code
				END

				IF @data_type <> 'char'
					SELECT @ellipses_req_tmp = 'N'

				--Code addition  for  PNR2.0_20049  ends
				-- For Associated Task
				IF @ctxt_service_in IN ('BulkGenerate')
					AND @pubflag = 'P'
				BEGIN
					IF EXISTS (
							SELECT 'x'
							FROM ep_published_action_mst a(NOLOCK),
								es_comp_task_type_mst b(NOLOCK)
							WHERE a.customer_name = b.customer_name
								AND a.project_name = b.project_name
								AND a.component_name = b.component_name
								AND a.task_pattern = b.task_type_name
								AND a.customer_name = @engg_customer_name
								AND a.project_name = @engg_project_name
								AND a.req_no = @engg_req_no
								AND a.process_name = @process_name
								AND a.component_name = @engg_component
								AND a.activity_name = @activity_name
								AND a.ui_name = @ui_name_tmp
								AND a.page_bt_synonym = @page_bt_synonym_tmp
								AND a.primary_control_bts = @control_bt_synonym_tmp
								AND a.task_pattern = b.task_type_name
								AND a.task_type = @default_for_tmp
							)
					BEGIN
						SELECT @uitaskname_tmp = upper(task_name)
						FROM ep_published_action_mst a(NOLOCK),
							es_comp_task_type_mst b(NOLOCK)
						WHERE a.customer_name = b.customer_name
							AND a.project_name = b.project_name
							AND a.component_name = b.component_name
							AND a.task_pattern = b.task_type_name
							AND a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.req_no = @engg_req_no
							AND a.process_name = @process_name
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							AND a.page_bt_synonym = @page_bt_synonym_tmp
							AND a.primary_control_bts = @control_bt_synonym_tmp
							AND a.task_pattern = b.task_type_name
							AND a.task_type = @default_for_tmp
					END
					ELSE
					BEGIN
						SELECT @uitaskname_tmp = ''
					END
				END
				ELSE
				BEGIN
					IF EXISTS (
							SELECT 'x'
							FROM ep_action_mst a(NOLOCK),
								es_comp_task_type_mst b(NOLOCK)
							WHERE a.customer_name = b.customer_name
								AND a.project_name = b.project_name
								AND a.req_no = b.req_no
								AND a.component_name = b.component_name
								AND a.task_pattern = b.task_type_name
								AND a.customer_name = @engg_customer_name
								AND a.project_name = @engg_project_name
								AND a.process_name = @process_name
								AND a.component_name = @engg_component
								AND a.activity_name = @activity_name
								AND a.ui_name = @ui_name_tmp
								AND a.page_bt_synonym = @page_bt_synonym_tmp
								AND a.primary_control_bts = @control_bt_synonym_tmp
								AND a.task_pattern = b.task_type_name
								AND a.task_type = @default_for_tmp
							)
					BEGIN
						SELECT @uitaskname_tmp = upper(task_name)
						FROM ep_action_mst a(NOLOCK),
							es_comp_task_type_mst b(NOLOCK)
						WHERE a.customer_name = b.customer_name
							AND a.project_name = b.project_name
							AND a.req_no = b.req_no
							AND a.component_name = b.component_name
							AND a.task_pattern = b.task_type_name
							AND a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.process_name = @process_name
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							AND a.page_bt_synonym = @page_bt_synonym_tmp
							AND a.primary_control_bts = @control_bt_synonym_tmp
							AND a.task_pattern = b.task_type_name
							AND a.task_type = @default_for_tmp
					END
					ELSE
					BEGIN
						SELECT @uitaskname_tmp = ''
					END
				END

				-- code added by Ganesh for the callid :: PNR2.0_4355 on 24/10/05
				-- to handle the filler control added in the seq number
				SELECT @filler_seq_no = isnull(max(order_seq), '1')
				FROM ep_ui_control_dtl a(NOLOCK),
					ep_ui_section_dtl b(NOLOCK)
				WHERE a.customer_name = @engg_customer_name
					AND a.project_name = @engg_project_name
					AND a.req_no = 'Base'
					AND a.process_name = @process_name
					AND a.component_name = @engg_component
					AND a.activity_name = @activity_name
					AND a.ui_name = @ui_name_tmp
					AND a.page_bt_synonym = @page_bt_synonym_tmp
					AND a.section_bt_synonym = @section_bt_synonym_tmp -- code added for the bug id PNR2.0_18194
					AND a.customer_name = b.customer_name
					AND a.project_name = b.project_name
					AND a.req_no = b.req_no
					AND a.process_name = b.process_name
					AND a.component_name = b.component_name
					AND a.activity_name = b.activity_name
					AND a.ui_name = b.ui_name
					AND a.page_bt_synonym = b.page_bt_synonym
					AND a.section_bt_synonym = b.section_bt_synonym -- code added for the bug id PNR2.0_18194
					AND a.horder = @horder_tmp
					AND a.vorder = @vorder_tmp
					AND b.horder = @tab_sec_horder
					AND b.vorder = @tab_sec_vorder

				-- Code added by feroz for extjs -- start  -- PNR2.0_1790
				SELECT @extjs_base_ctrl = ''

				IF EXISTS (
						SELECT 'x'
						FROM ep_ui_section_dtl(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @process_name
							AND component_name = @engg_component
							AND activity_name = @activity_name
							AND ui_name = @ui_name_tmp
							AND page_bt_synonym = @page_bt_synonym_tmp
							AND section_bt_synonym = @section_bt_synonym_tmp
							AND section_type IN (
								'Text Scroller',
								'Formatted Text',
								'Report List',
								'Property Window',
								'Pivot',
								'Tree Grid',
								'IFrame',
								'RSS Feed'
								)
						)
				BEGIN -- 1
					SELECT @section_type = section_type
					FROM ep_ui_section_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @process_name
						AND component_name = @engg_component
						AND activity_name = @activity_name
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = @page_bt_synonym_tmp
						AND section_bt_synonym = @section_bt_synonym_tmp

					IF @pubflag = 'P'
					BEGIN -- 2
						-- Modified for bug id :PNR2.0_20754  by Feroz
						SELECT @extjs_values = ' ExtJs="Y" ExtType="' + Upper(@section_type) + '" ScrollDelay="' + convert(VARCHAR, isnull(Scroll_Delay, 0)) + '" ScrollBehaviour="' + isnull(Scroll_Behaviour, 0) + '" FadeDirection="' + isnull(Direction, '') + '" FadeDelay=
"' + convert(VARCHAR, isnull(Fade_Delay, 0)) + '" SectionHeight="' + convert(VARCHAR, isnull(Section_Height, 0)) + '" SectionWidth="' + convert(VARCHAR, isnull(Section_Width, 0)) + '" SectionClass="' + isnull(Section_Class, '') + '" ReportItemClass="' + isnull(Report_Item_Class, '') + '" PropertyClass="' + isnull(Property_Class, '') + '"  ValueClass="' + isnull(Value_Class, '') + '"',
							@section_bt_synonym_tmp = upper(section_bt_synonym),
							@sample_data_tmp = ''
						FROM ep_published_ext_js_section_dtl(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND req_no = @engg_req_no
							AND process_name = @process_name
							AND component_name = @engg_component
							AND activity_name = @activity_name
							AND ui_name = @ui_name_tmp
							AND page_bt_synonym = @page_bt_synonym_tmp
							AND section_bt_synonym = @section_bt_synonym_tmp

						SELECT @uitaskname_tmp = upper(isnull(RVW_Task, '')),
							@extjs_values = ' CalloutTask="' + CASE 
								WHEN callout_task = 0
									THEN 'N'
								ELSE 'Y'
								END + '"' + @extjs_values,
							@sample_data_tmp = sample_data
						FROM ep_published_ext_js_section_dtl(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND req_no = @engg_req_no
							AND process_name = @process_name
							AND component_name = @engg_component
							AND activity_name = @activity_name
							AND ui_name = @ui_name_tmp
							AND page_bt_synonym = @page_bt_synonym_tmp
							AND section_bt_synonym = @section_bt_synonym_tmp
							AND section_type IN (
								'IFrame',
								'RSS Feed'
								)
					END -- 2
					ELSE
					BEGIN -- 2
						-- Modified for bug id :PNR2.0_20754  by Feroz
						SELECT @extjs_values = ' ExtJs="Y" ExtType="' + upper(@section_type) + '" ScrollDelay="' + convert(VARCHAR, isnull(Scroll_Delay, 0)) + '" ScrollBehaviour="' + isnull(Scroll_Behaviour, 0) + '" FadeDirection="' + isnull(Direction, '') + '" FadeDelay="
' + convert(VARCHAR, isnull(Fade_Delay, 0)) + '" SectionHeight="' + convert(VARCHAR, isnull(Section_Height, 0)) + '" SectionWidth="' + convert(VARCHAR, isnull(Section_Width, 0)) + '" SectionClass="' + isnull(Section_Class, '') + '" ReportItemClass="' + isnull(Report_Item_Class, '') + '" PropertyClass="' + isnull(Property_Class, '') + '"  ValueClass="' + isnull(Value_Class, '') + '"',
							@section_bt_synonym_tmp = upper(section_bt_synonym),
							@sample_data_tmp = ''
						FROM ep_ext_js_section_dtl(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @process_name
							AND component_name = @engg_component
							AND activity_name = @activity_name
							AND ui_name = @ui_name_tmp
							AND page_bt_synonym = @page_bt_synonym_tmp
							AND section_bt_synonym = @section_bt_synonym_tmp

						SELECT @uitaskname_tmp = upper(isnull(RVW_Task, '')),
							@extjs_values = ' CalloutTask="' + CASE 
								WHEN callout_task = 0
									THEN 'N'
								ELSE 'Y'
								END + '"' + @extjs_values,
							@sample_data_tmp = sample_data
						FROM ep_ext_js_section_dtl(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @process_name
							AND component_name = @engg_component
							AND activity_name = @activity_name
							AND ui_name = @ui_name_tmp
							AND page_bt_synonym = @page_bt_synonym_tmp
							AND section_bt_synonym = @section_bt_synonym_tmp
							AND section_type IN (
								'IFrame',
								'RSS Feed'
								)
					END -- 2
				END -- 1

				IF EXISTS (
						SELECT 'x'
						FROM es_comp_ctrl_type_mst_vw(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @process_name
							AND component_name = @engg_component
							AND ctrl_type_name = @control_type_tmp
							AND Is_Extjs_Control = 'y'
						)
				BEGIN -- 1
					SELECT @extjs_ctrl_type = Extjs_Ctrl_type
					FROM es_comp_ctrl_type_mst_vw(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @process_name
						AND component_name = @engg_component
						AND ctrl_type_name = @control_type_tmp
						AND is_extjs_control = 'y'

					IF @extjs_ctrl_type IN (
							'TextType Writer',
							'Marquee Ticker',
							'EMail'
							)
					BEGIN -- For Lable contrl for Grid
						IF @caption_req_tmp = 'y'
							SELECT @extjs_base_ctrl = 'Edit'
					END -- For Lable contrl for Grid

					IF @extjs_ctrl_type IN (
							'TextType Writer',
							'Marquee Ticker',
							'EMail',
							'Bar Code'
							)
					BEGIN -- 2
						IF @pubflag = 'P'
						BEGIN -- 3
							SELECT @extjs_values = ' ExtJs="Y" ExtType="' + Upper(@extjs_ctrl_type) + '" TypeDelay="' + convert(VARCHAR, isnull(Type_Delay, 0)) + '" FadeDelay="' + convert(VARCHAR, isnull(Fade_Delay, 0)) + '" TypeDirection="' + isnull(Type_Direction, '') + '" 
FadeDirection="' + isnull(Fade_Direction, '') + '" Height="' + convert(VARCHAR, isnull(ctrl_height, 0)) + '" Width="' + convert(VARCHAR, isnull(ctrl_width, 0)) + '" LoopCount="' + convert(VARCHAR, isnull(Loop_Count, 0)) + '"',
								@ctrl_class_tmp = isnull(Control_Class, ''),
								@section_bt_synonym_tmp = Upper(section_bt_synonym),
								@sample_data_tmp = ''
							FROM ep_published_ext_js_control_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND req_no = @engg_req_no
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND page_bt_synonym = @page_bt_synonym_tmp
								AND section_bt_synonym = @section_bt_synonym_tmp
								AND control_bt_synonym = @control_bt_synonym_tmp

							SELECT @uitaskname_tmp = upper(isnull(RVW_Task, '')),
								@extjs_values = ' CalloutTask ="' + CASE 
									WHEN callout_task = 0
										THEN 'N'
									ELSE 'Y'
									END + '"' + @extjs_values,
								@sample_data_tmp = sample_data
							FROM ep_published_ext_js_control_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND req_no = @engg_req_no
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND page_bt_synonym = @page_bt_synonym_tmp
								AND section_bt_synonym = @section_bt_synonym_tmp
								AND control_bt_synonym = @control_bt_synonym_tmp -- Modified By Feroz For bug id :PNR2.0_20730
								AND feature_name = 'Bar Code'
						END -- 3
						ELSE
						BEGIN -- 3
							SELECT @extjs_values = ' ExtJs="Y" ExtType="' + Upper(@extjs_ctrl_type) + '" TypeDelay="' + convert(VARCHAR, isnull(Type_Delay, 0)) + '" FadeDelay="' + convert(VARCHAR, isnull(Fade_Delay, 0)) + '" TypeDirection="' + isnull(Type_Direction, '') + '" 
FadeDirection="' + isnull(Fade_Direction, '') + '" Height="' + convert(VARCHAR, isnull(ctrl_height, 0)) + '" Width="' + convert(VARCHAR, isnull(ctrl_width, 0)) + '" LoopCount="' + convert(VARCHAR, isnull(Loop_Count, 0)) + '"',
								@ctrl_class_tmp = isnull(Control_Class, ''),
								@section_bt_synonym_tmp = upper(section_bt_synonym),
								@sample_data_tmp = ''
							FROM ep_ext_js_control_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND page_bt_synonym = @page_bt_synonym_tmp
								AND section_bt_synonym = @section_bt_synonym_tmp
								AND control_bt_synonym = @control_bt_synonym_tmp

							SELECT @uitaskname_tmp = upper(isnull(RVW_Task, '')),
								@extjs_values = ' CalloutTask ="' + CASE 
									WHEN callout_task = 0
										THEN 'N'
									ELSE 'Y'
									END + '"' + @extjs_values,
								@sample_data_tmp = sample_data
							FROM ep_ext_js_control_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND page_bt_synonym = @page_bt_synonym_tmp
								AND section_bt_synonym = @section_bt_synonym_tmp
								AND control_bt_synonym = @control_bt_synonym_tmp -- Modified By Feroz For bug id :PNR2.0_20730
								AND feature_name = 'Bar Code'
						END -- 3
					END -- 2
				END -- 1
						-- Code added by feroz for extjs -- end -- PNR2.0_1790

				-- Code Added By Feroz For List edit
				SELECT @associatedlist_name = '',
					@onfocus_taskname = '',
					@listrefill_taskname = '',
					@hidden_view_name = '',
					@mapped_list_controlid = '',
					@mapped_list_viewname = ''

				IF isnull(@date_highlight_req, 'N') = 'Y'
				BEGIN
					IF @pubflag = 'P'
					BEGIN
						SELECT TOP 1 @associatedlist_name = Upper(a.listedit_controlid)
						FROM ep_published_date_highlight_control_map a(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.req_no = @engg_req_no
							AND a.process_name = @process_name
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							AND a.page_bt_synonym = @page_bt_synonym_tmp
							AND a.section_bt_synonym = @section_bt_synonym_tmp
							AND a.control_bt_synonym = @control_bt_synonym_tmp

						SELECT @mapped_list_controlid = upper(controlid),
							@mapped_list_viewname = upper(viewname)
						FROM #maplist -- code modified by gopinath S for the call ID PNR2.0_24034
						WHERE activityname = @activity_name
							AND ilbocode = @ui_name_tmp
							AND listedit = @associatedlist_name
					END
					ELSE
					BEGIN
						SELECT TOP 1 @associatedlist_name = Upper(a.listedit_controlid)
						FROM ep_date_highlight_control_map a(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.process_name = @process_name
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							AND a.page_bt_synonym = @page_bt_synonym_tmp
							AND a.section_bt_synonym = @section_bt_synonym_tmp
							AND a.control_bt_synonym = @control_bt_synonym_tmp

						SELECT @mapped_list_controlid = upper(controlid),
							@mapped_list_viewname = upper(viewname)
						FROM #maplist -- code modified by gopinath S for the call ID PNR2.0_24034
						WHERE activityname = @activity_name
							AND ilbocode = @ui_name_tmp
							AND listedit = @associatedlist_name
					END
				END

				IF @pubflag = 'P'
				BEGIN
					IF EXISTS (
							SELECT 'x'
							FROM ep_published_date_highlight_control_map a(NOLOCK)
							WHERE a.customer_name = @engg_customer_name
								AND a.project_name = @engg_project_name
								AND a.req_no = @engg_req_no
								AND a.process_name = @process_name
								AND a.component_name = @engg_component
								AND a.activity_name = @activity_name
								AND a.ui_name = @ui_name_tmp
								AND a.listedit_synonym = @control_bt_synonym_tmp
							)
						SELECT @base_ctrl_type_tmp = 'LISTEDIT'
				END
				ELSE
				BEGIN
					IF EXISTS (
							SELECT 'x'
							FROM ep_date_highlight_control_map a(NOLOCK)
							WHERE a.customer_name = @engg_customer_name
								AND a.project_name = @engg_project_name
								AND a.process_name = @process_name
								AND a.component_name = @engg_component
								AND a.activity_name = @activity_name
								AND a.ui_name = @ui_name_tmp
								AND a.listedit_synonym = @control_bt_synonym_tmp
							)
						SELECT @base_ctrl_type_tmp = 'LISTEDIT'
				END

				IF isnull(@associatedlist_req, 'N') = 'Y'
				BEGIN
					IF @pubflag = 'P'
					BEGIN
						SELECT TOP 1 @associatedlist_name = upper(b.listedit_controlid)
						FROM ep_published_listedit_control_map a(NOLOCK),
							ep_published_listedit_column_dtl b(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.req_no = @engg_req_no
							AND a.process_name = @process_name
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							AND a.page_bt_synonym = @page_bt_synonym_tmp
							AND a.section_bt_synonym = @section_bt_synonym_tmp
							AND a.mapped_bt_synonym = @control_bt_synonym_tmp
							AND a.customer_name = b.customer_name
							AND a.project_name = b.project_name
							AND a.req_no = b.req_no
							AND a.process_name = b.process_name
							AND a.component_name = b.component_name
							AND a.activity_name = b.activity_name
							AND a.ui_name = b.ui_name
							AND a.listedit_synonym = b.listedit_synonym

						SELECT @mapped_list_controlid = upper(controlid),
							@mapped_list_viewname = upper(viewname)
						FROM #maplist -- code modified by gopinath S for the call ID PNR2.0_24034
						WHERE activityname = @activity_name
							AND ilbocode = @ui_name_tmp
							AND listedit = @associatedlist_name

						IF isnull(@onfocustask_req, 'N') = 'Y'
							SELECT @onfocus_taskname = task_name
							FROM ep_published_action_mst(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND req_no = @engg_req_no
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND task_descr = 'List Edit Onfocus Task'
								AND primary_control_bts = @control_bt_synonym_tmp

						IF isnull(@listrefilltask_req, 'N') = 'Y'
							SELECT @listrefill_taskname = task_name
							FROM ep_published_action_mst(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND req_no = @engg_req_no
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND task_descr = 'List Edit Refill Task'
								AND primary_control_bts = @control_bt_synonym_tmp
					END
					ELSE
					BEGIN
						SELECT TOP 1 @associatedlist_name = upper(b.listedit_controlid)
						FROM ep_listedit_control_map a(NOLOCK),
							ep_listedit_column_dtl b(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.process_name = @process_name
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							AND a.page_bt_synonym = @page_bt_synonym_tmp
							AND a.section_bt_synonym = @section_bt_synonym_tmp
							AND a.mapped_bt_synonym = @control_bt_synonym_tmp
							AND a.customer_name = b.customer_name
							AND a.project_name = b.project_name
							AND a.process_name = b.process_name
							AND a.component_name = b.component_name
							AND a.activity_name = b.activity_name
							AND a.ui_name = b.ui_name
							AND a.listedit_synonym = b.listedit_synonym

						SELECT @mapped_list_controlid = upper(controlid),
							@mapped_list_viewname = upper(viewname)
						FROM #maplist -- code modified by gopinath S for the call ID PNR2.0_24034
						WHERE activityname = @activity_name
							AND ilbocode = @ui_name_tmp
							AND listedit = @associatedlist_name

						IF isnull(@onfocustask_req, 'N') = 'Y'
							SELECT @onfocus_taskname = task_name
							FROM ep_action_mst(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND task_descr = 'List Edit Onfocus Task'
								AND primary_control_bts = @control_bt_synonym_tmp

						IF isnull(@listrefilltask_req, 'N') = 'Y'
							SELECT @listrefill_taskname = task_name
							FROM ep_action_mst(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND task_descr = 'List Edit Refill Task'
								AND primary_control_bts = @control_bt_synonym_tmp
					END
				END

				IF @pubflag = 'P'
				BEGIN
					IF EXISTS (
							SELECT 'x'
							FROM ep_published_listedit_column_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND req_no = @engg_req_no
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND listedit_synonym = @control_bt_synonym_tmp
							)
						SELECT @base_ctrl_type_tmp = 'LISTEDIT'
				END
				ELSE
				BEGIN
					IF EXISTS (
							SELECT 'x'
							FROM ep_listedit_column_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND listedit_synonym = @control_bt_synonym_tmp
							)
						SELECT @base_ctrl_type_tmp = 'LISTEDIT'
				END

				IF EXISTS (
						SELECT 'x'
						FROM es_comp_ctrl_type_mst(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @process_name
							AND component_name = @engg_component
							AND ctrl_type_name = @control_type_tmp
							AND (
								isnull(attach_document, 'N') = 'Y'
								OR isnull(image_upload, 'N') = 'Y'
								)
						)
				BEGIN
					SELECT @hidden_view_name = Upper(view_name)
					FROM de_hidden_view(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @process_name
						AND component_name = @engg_component
						AND activity_name = @activity_name
						AND ui_name = @ui_name_tmp
						AND page_name = @page_bt_synonym_tmp
						AND section_name = @section_bt_synonym_tmp
						AND control_bt_synonym = @control_bt_synonym_tmp
				END

				-- Code Added By Feroz For List edit
				-- Modified By feroz for bug id :PNR2.0_23654
				SELECT @visible_rows_tmp = visisble_rows
				FROM es_comp_ctrl_type_mst(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @process_name
					AND component_name = @engg_component
					AND ctrl_type_name = @control_type_tmp
				-- Modified By feroz for bug id :PNR2.0_23654
				
				/* code commented for  TECH-57347
				--IF @control_type_tmp = 'DataHyperLink'
				--	SELECT @ctrl_descr_tmp = @sample_data_tmp
				code commented for TECH-57347 */

				-- Code Modified by Saravanan on 21/03/2005 for PNR No. PNR2.0_1522
				-- Insert Label Entry
				--if @base_ctrl_type_tmp in ('Edit','Combo','Checkbox','DataHyperLink') and @caption_req_tmp = 'Y'
				-- and @control_type_tmp not in ('Filler','Filler2')
				--Code Modified for bugid : PNR2.0_12227
				IF (
						@base_ctrl_type_tmp IN (
							'Edit',
							'Combo',
							'Checkbox',
							'radiobutton',
							'listview' ---- Code added by 13026 for TECH-65425
							)
						AND @caption_req_tmp = 'Y'
						)
					AND (
						@control_type_tmp NOT IN (
							'Filler',
							'Filler2'
							)
						)
					OR (
						@base_ctrl_type_tmp = 'DataHyperLink'
						AND @caption_req_tmp = 'Y'
						)
					OR (@extjs_base_ctrl = 'Edit') -- Added by Feroz For Extjs -- PNR2.0_1790
					-- Code Modified by Saravanan on 21/03/2005 for PNR No. PNR2.0_1522
					-- Code Modified by Balaji for bugid : PNR2.0_15338
				BEGIN
					IF @ui_format_tmp = 'BES'
					BEGIN
						SELECT @transformed_horder_tmp = @horder_tmp

						SELECT @transformed_vorder_tmp = @vorder_tmp + @position_vindex_tmp

						IF @order_seq_tmp > 1
						BEGIN
							SELECT @transformed_seqno_tmp = @order_seq_tmp + @position_sindex_tmp

							SELECT @position_sindex_tmp = @position_sindex_tmp + 1
						END
						ELSE
						BEGIN
							SELECT @transformed_seqno_tmp = @order_seq_tmp
						END
					END
					ELSE
					BEGIN
						SELECT @transformed_horder_tmp = (@horder_tmp * 2) - 1

						SELECT @transformed_vorder_tmp = @vorder_tmp

						SELECT @transformed_seqno_tmp = @order_seq_tmp --shakthi
					END

					-- 11537 starts
					/*

if @base_ctrl_type_tmp in ('grid')
begin
if exists (
select 'x'
from ep_published_ui_control_dtl a(nolock) , ep_published_calendar_configure b(nolock)
where	a.customer_name  =   @engg_customer_name
and		a.project_name  = @engg_project_name
and		a.req_no    =  @engg_req_no
and		a.process_name  = @process_name
and		a.component_name  = @engg_component
and		a.activity_name =  @activity_name
and		a.ui_name   =  @ui_name_tmp
and		a.section_bt_synonym  =  @section_bt_synonym_tmp
and		a.control_type ='CalGrid'
and  a.customer_name		=  b.customer_name	  
and  a.project_name			=  b.project_name		
and  a.process_name			=  b.process_name		
and  a.component_name		=  b.component_name	
and  a.activity_name		=  b.activity_name	
and  a.ui_name				=  b.ui_name			
and  a.section_bt_synonym	=  b.section_name 
and	 a.req_no				=  b.req_no)
begin 
select @renderas ='CALENDAR'
end

end
*/
					-- 11537 Ends
					SELECT @xml_seq_tmp = @xml_seq_tmp + 1

					SELECT @helptext = @ctrl_descr_tmp + ' - Datatype : ' + ltrim(rtrim(isnull(@datatype_tmp, ''))) + ' - MaxLength : ' + ltrim(rtrim(isnull(@datalength_tmp, '')))

					IF upper(isnull(@datatype_tmp, '')) = 'NUMERIC'
						SELECT @helptext = @helptext + ' - DecimalLength : ' + ltrim(rtrim(isnull(@datalength_tmp, '')))

-- Added for TECH-46646 Starts
select  @DynamicFileUpload	= ISNULL(Dynamicfileupload, 'N')
from    es_comp_ctrl_type_mst_extn (nolock)
where   customer_name		= @engg_customer_name
and		project_name		= @engg_project_name
and		process_name		= @process_name
and		component_name		= @engg_component
and		ctrl_type_name		= @control_type_tmp

IF ISNULL(@image_icon, 'N') = 'Y' AND ISNULL(@DynamicFileUpload,'N') = 'Y'
	SELECT @ImageType = 'Dynamic'
ELSE IF ISNULL(@image_icon, 'N') = 'Y' AND ISNULL(@relative_image_path,'') <> ''AND ISNULL(@DynamicFileUpload,'N') = 'N'
	SELECT @ImageType = 'Static'
ELSE IF ISNULL(@image_icon, 'N') = 'Y'
	SELECT @ImageType = ''
-- Added for TECH-46646 Ends

---- Code added for TECH-69624 starts

SELECT @forresponsive	=   ''

SELECT @forresponsive	=	ISNULL(Convert(VARCHAR(10), ForResponsive), 'none')
FROM	ep_ui_control_dtl (NOLOCK)
WHERE  customer_name		=  @engg_customer_name
and    project_name			=  @engg_project_name
and    req_no				=  @engg_req_no
and    process_name			=  @process_name
and    component_name		=  @engg_component
and    activity_name		=  @activity_name
and    ui_name				=  @ui_name_tmp
and    page_bt_synonym		=  @page_bt_synonym_tmp
and    control_bt_synonym	=  @control_bt_synonym_tmp

---- Code added for TECH-69624 Ends

					-- code added for bugid : PNR2.0_17974  starts     --
					IF (
							@base_ctrl_type_tmp = 'Checkbox'
							AND @caption_req_tmp = 'Y'
							AND @ctrl_position_tmp = 'Right'
							)
					BEGIN
						INSERT INTO ep_genxml_tmp (
							customer_name,
							project_name,
							req_no,
							process_name,
							component_name,
							activity_name,
							guid,
							gen_xml,
							seq_no
							)
						VALUES (
							@engg_customer_name,
							@engg_project_name,
							@engg_req_no,
							@process_name,
							@engg_component,
							@activity_name,
							@guid,
							'<Control Name="' + ltrim(rtrim(isnull(@controlid_tmp, ''))) + '" ' + 'RenderAs="' + ltrim(rtrim(isnull(@renderas, ''))) + '" ' + 'ControlCaption="' + ltrim(rtrim(isnull(@ctrl_descr_tmp, ''))) + '" ' + 'SectionName="' + ltrim(rtrim(isnull(@section_bt_synonym_tmp, ''))) + '" ' + 'PageName="' + ltrim(rtrim(isnull(@page_bt_synonym_tmp, ''))) + '" ' + 'ILBOName="' + ltrim(rtrim(isnull(@ui_name_tmp, ''))) + '" ' + 'ActivityName="' + ltrim(rtrim(isnull(@activity_name, ''))) + '" ' + 'ComponentName="' + ltrim(rtrim(isnull(@engg_component, ''))) + '" ' + 'ControlType="' + ltrim(rtrim(isnull(upper(@control_type_tmp), ''))) + '" ' + 'BaseControlType="' + ltrim(rtrim(isnull(upper(@base_ctrl_type_tmp), ''))) + '" ' + -- Code modification  for  PNR2.0_23635
							'DataType="' + CASE ltrim(rtrim(isnull(@base_ctrl_type_tmp, ''))) + '-' + ltrim(rtrim(isnull(@datatype_tmp, '')))
								WHEN 'COMBO-INTEGER'
									THEN ''
								ELSE ltrim(rtrim(isnull(@datatype_tmp, '')))
								END + '" ' + 'DataLength="' + CASE ltrim(rtrim(isnull(@base_ctrl_type_tmp, ''))) + '-' + ltrim(rtrim(isnull(@datatype_tmp, '')))
								WHEN 'COMBO-INTEGER'
									THEN ''
								ELSE ltrim(rtrim(isnull(@datalength_tmp, '')))
								END + '" ' + 'DecimalLength="' + CASE ltrim(rtrim(isnull(@base_ctrl_type_tmp, ''))) + '-' + ltrim(rtrim(isnull(@datatype_tmp, '')))
								WHEN 'COMBO-INTEGER'
									THEN ''
								ELSE isnull(convert(VARCHAR, @decimal_length_ctrl), '')
								END + '" ' + 'BTSynonym="' + ltrim(rtrim(isnull(@control_bt_synonym_tmp, ''))) + '" ' + 'VisibleLength="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@visible_length_tmp, 0)))) + '" ' + 'ProtoTooltip="' + ltrim(rtrim(isnull(@proto_tooltip_tmp, ''))) + '
" ' + 'SampleData="' + ltrim(rtrim(isnull(@sample_data_tmp, ''))) + '" ' + 'DefaultSampleData="' + ltrim(rtrim(isnull(@default_sample_data_tmp, ''))) + '" ' + 
--'HOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, isnull(@transformed_horder_tmp, 0)), 3))) + '" ' + 
--'VOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, isnull(@transformed_vorder_tmp, 0)), 3))) + '" ' + 
'HOrder="'     +CASE WHEN @ui_format_tmp = 'Top' THEN  ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR,isnull(@horder_tmp,0)),3)))     --TECH-72114
				ELSE  + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR,isnull(@transformed_horder_tmp,0)),3))) END  + '" ' + 
'VOrder="'     +CASE WHEN @ui_format_tmp = 'Top' THEN  ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR,isnull(@vorder_tmp,0)),3)))  --TECH-72114
				ELSE  + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR,isnull(@transformed_vorder_tmp,0)),3))) END  + '" ' +
'Mandatory="' + ltrim(rtrim(isnull(@mandatory_flag_tmp, ''))) + '" ' + 'Visible="' + ltrim(rtrim(isnull(@visible_flag_tmp, ''))) + '" '
 + 'Editable="' + ltrim(rtrim(isnull(@editable_flag_tmp, ''))) + '" ' + 'CaptionRequired="' + ltrim(rtrim(isnull(@caption_req_tmp, ''))) + '" ' + 'SelectFlag="' + ltrim(rtrim(isnull(@select_flag_tmp, ''))) + '" ' + 'DeleteFlag="' + ltrim(rtrim(isnull(@delete_flag_tmp, ''))) + '" ' + 'ZoomRequired="' + ltrim(
								rtrim(isnull(@zoom_req_tmp, ''))) + '" ' + 'HelpRequired="' + ltrim(rtrim(isnull(@help_req_tmp, ''))) + '" ' + 'EllipsesRequired="' + ltrim(rtrim(isnull(@ellipses_req_tmp, ''))) + '" ' + 'AssociatedTask="' + ltrim(rtrim(isnull(@uitaskname_tmp, '')
)) + '" ' + 'DataColumnWidth="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@data_column_width_tmp, 0)))) + '" ' + 'LabelColumnWidth="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@label_column_width_tmp, 0)))) + '" ' + 'DataColumnScaleMode="' + ltrim(rtrim(isnull(@data_column_scalemode, '%'))) + '" ' + 'LabelColumnScaleMode="' + ltrim(rtrim(isnull(@label_column_scalemode, '%'))) + '" ' + 'CaptionWrap="' + ltrim(rtrim(isnull(@caption_wrap_tmp, 'Y'))) + '" ' + 'CaptionAlignment="' + ltrim(rtrim(isnull(@caption_alignment_tmp, 'LEFT'))) + '" ' + 'CaptionPosition="' + ltrim(rtrim(isnull(@caption_position_tmp, 'LEFT'))) + '" ' + 'ControlPosition="' + ltrim(rtrim(isnull(@ctrl_position_tmp, 'LEFT'))) + '" ' + 'LabelClass="' + ltrim(rtrim(isnull(@label_class_tmp, ''))) + '" 
' + 'ControlClass="' + ltrim(rtrim(isnull(
										@ctrl_class_tmp, ''))) + '" ' + 'PasswordChar="' + ltrim(rtrim(isnull(@password_char_tmp, 'N'))) + '" ' + 'TaskImageClass="' + ltrim(rtrim(isnull(@task_img_tmp, ''))) + '" ' + 'HelpImageClass="' + ltrim(rtrim(isnull(@help_img_tmp, ''))) + '" ' +
 'Documentation="' + ltrim(rtrim(isnull(@controldoc_tmp, ''))) + '" ' + 'OrderSequence="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@transformed_seqno_tmp, 0)))) + '" ' + 'VisibleRows="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@visible_rows_tmp, 0)))) + '" ' + 
'HTMLTextArea="' + ltrim(rtrim(isnull(@html_text_area, 'N'))) + '" ' + 'SpinRequired="' + ltrim(rtrim(isnull(@spin_required, 'N'))) + '" ' + 'SpinUpImage="' + ltrim(rtrim(isnull(@spin_up_image, 'spinup.gif'))) + '" ' + 'SpinDownImage="' + ltrim(rtrim(isnull(@spin_down_image, 'spindown.gif'))) + '" ' + 'AssociatedSpinControl="' + ltrim(rtrim(isnull(@associated_spin_ctrl, ''))) + '" ' + 'AssociatedSpinTask="' + ltrim(rtrim(isnull(@associated_spin_task, ''))) + '" ' + 'HelpText="' + ltrim(rtrim(isnull(@helptext, ''))) + '" ' + 'ReportRequired="' + ltrim(
								rtrim(isnull(@report_reqd, ''))) + '" ' + 'ModelSectionName="' + ltrim(rtrim(isnull(@section_bt_synonym_tmp, ''))) + '" ' +
							-- Inplace Calendar and Edit Mask Feature added by Feroz -- Start
							'InPlaceCalendar="' + ltrim(rtrim(isnull(@InPlaceCalendar, 'n'))) + '" ' +
							-- Code modification for  PNR2.0_19426  starts
							'InCalDisplay="' + ltrim(rtrim(isnull(@InPlaceCal_Display, ''))) + '" ' +
							-- Code Modifed for the BugID PNR2.0_18629 Starts (XML Attribute name has been changed as EditMask from EditMaskPattern Since Preview20dll is having as 'EditMask')
							'EditMask="' + ltrim(rtrim(isnull(@EditMaskPattern, ''))) + '" ' +
							-- Code Modifed for the BugID PNR2.0_18629 Ends (XML Attribute name has been changed as EditMask from EditMaskPattern Since Preview20dll is having as 'EditMask')
							-- Inplace Calendar and Edit Mask Feature added by Feroz -- End
							'TabIndex="' + ltrim(rtrim(@tab_seq)) + '" ' + 'AccessKey="' + ltrim(rtrim(isnull(@AccessKey, ''))) + '" ' + -- Added by Jeya For AccessKey
							-- Code modification for  PNR2.0_19426  ends
							-- Code addition for PNR2.0_21576 starts
							--Code modified by Balaji D for Bug ID PNR2.0_28889 on 01-Nov-2010 starts
							'GridLite="' + ltrim(rtrim(isnull(@gridlite, 'N'))) + '" ' +
							--Code modified by Balaji D for Bug ID PNR2.0_28889 on 01-Nov-2010 end
							-- Code addition for PNR2.0_21576 ends
							-- Code addition for PNR2.0_20849 starts
							'NoofLinesPerRow="' + ltrim(rtrim(isnull(CONVERT(VARCHAR, @NoofLinesPerRow), ''))) + '" ' + 'RowHeight="' + ltrim(rtrim(isnull(CONVERT(VARCHAR, @RowHeight), ''))) + '" ' +
							-- Added By Feroz
							'BulletLink="' + ltrim(rtrim(isnull(@bulletlink_req, 'N'))) + '" ' + 'ButtonCombo="' + ltrim(rtrim(isnull(@buttoncombo_req, 'N'))) + '" ' + 'DataAsCaption="' + ltrim(rtrim(isnull(@dataascaption, 'N'))) + '" ' + 'AssociatedList="' + ltrim(rtrim(isnull(@associatedlist_name, ''))) + '" ' + 'OnFocusTask="' + ltrim(rtrim(isnull(@onfocus_taskname, ''))) + '" ' + 'ListRefillTask="' + ltrim(rtrim(isnull(@listrefill_taskname, ''))) + '" ' + 'MappedListControlID="' + ltrim(rtrim(isnull(@mapped_list_controlid
, ''))) + '" ' + 'MappedListViewName="' + ltrim(rtrim(isnull(@mapped_list_viewname, ''))) + '" ' + 'AttachDocument="' + ltrim(rtrim(isnull(@attach_document, 'N'))) + '" ' + 'ImageUpload="' + ltrim(rtrim(isnull(@image_upload, 'N'))) + '" ' + 'InplaceImage=
"' + ltrim(rtrim(isnull(@inplace_image, 'N'))) + '" ' + 'ImageIcon="' + ltrim(rtrim(isnull(@image_icon, 'N'))) + '" ' + 'ImageRowHeight="' + ltrim(rtrim(isnull(@image_row_height, '0'))) + '" ' + 'RelativeUrlPath="' + ltrim(rtrim(isnull(@relative_url_path,
 ''))) + '" ' + 'RelativeDocumentPath="' + ltrim(rtrim(
									isnull(@relative_document_path, ''))) + '" ' + 'RelativeImagePath="' + ltrim(rtrim(isnull(@relative_image_path, ''))) + '" ' + 'SaveDocContentToDb="' + ltrim(rtrim(isnull(@save_doc_content_to_db, 'N'))) + '" ' + 'SaveImageContentToDb="' + ltrim(rtrim(isnull(@save_image_content_to_db, 'N'))) + '" ' + 'DateHighlight="' + ltrim(rtrim(isnull(@date_highlight_req, 'N'))) + '" ' + 'LinkedHiddenViewName="' + ltrim(rtrim(isnull(@hidden_view_name, ''))) + '" ' + 'Vscrollbar_Req="' + ltrim(rtrim(isnull(@Vscrollbar_Req, 'N'))) + '" LiteAttach="' + Isnull(@Lite_Attach, 'N') + '" Browse_Button="' + Isnull(@BrowseButton, 'N') + '" Delete_Button="' + Isnull(@DeleteButton, 'N') + '" ' + --PNR2.0_28365 -- Code Modified For BUGID PNR2.0_28537
							'IsITK="N"  FC="' + CONVERT(VARCHAR, isnull(@freezecount, 0), 4) + '" ' +
							--code added for the caseid : PNR2.0_28319 starts
							'image_row_width="' + CONVERT(VARCHAR, isnull(@image_row_width, 0), 4) + '" ' + 'image_preview_height="' + CONVERT(VARCHAR, isnull(@image_preview_height, 0), 4) + '" ' + 'image_preview_width="' + CONVERT(VARCHAR, isnull(@image_preview_width, 0), 4)
 + '" ' + 'image_preview_req="' + isnull(@image_preview_req, 'N') + '" ' + 'Accept_Type="' + isnull(@Accept_Type, '') + '" ' + 'Lite_Attach_Image="' + isnull(@Lite_Attach_Image, 'N') + '" ' + --added for PNR2.0_26860 -- Code Modified for the Bug ID : PNR2.0_27796
							--code added for the caseid : PNR2.0_28319 ends
							-- Code addition for PNR2.0_20849 ends
							'LabelLink="' + isnull(@LabelLink, 'N') + '" ' + --Code Added for the Bug ID PNR2.0_36309
							--Code Added for the Bug ID: PLF2.0_00961 starts
							--'PopUpPage="'           +   isnull(@popup_page,'')                  +'" ' +
							--'PopUpSection="'        +   isnull(@popup_section,'')               +'" ' +
							--'PopUpClose="'          +   isnull(@popup_Close,'N')                +'" ' +
							'CaptionType="' + isnull(@captiontype, '') + '" ' + 'ControlStyle="' + isnull(@controlstyle, '') + '" ' + 'ControlImage="' + isnull(@controlimage, '') + '" ' + 'IsListBox="' + isnull(@IsListBox, '') + '" ' + 'Toolbar_Not_Req="' + isnull(@Toolbar_Not_Req, '') + '" ' + 'ColumnBorder_Not_Req="' + isnull(@ColumnBorder_Not_Req, '') + '" ' + 'RowBorder_Not_Req="' + isnull(@RowBorder_Not_Req, '') + '" ' + 'PageNavigation_Only="' + isnull(@PagenavigationOnly, '') + '" ' + 'RowNo_Not_Req="' + isnull(@RowNo_Not_Req, '') + '" ' + 'ExtType="' + isnull(@ExtType, '') + '" ' + 'ColSpan="' + CONVERT(VARCHAR, isnull(@ControlColSpan, ''), 4) + '" ' + 'RowSpan="' + CONVERT(VARCHAR, isnull(@ControlRowSpan, ''), 4) + '" ' + 'Tooltip_Not_Req="' + CONVERT(VARCHAR, isnull(@Tooltip_Not_Req, ''), 4) + '" ' + 'GridHeader_Not_Req="' + CONVERT(VARCHAR, isnull(@columncaption_Not_Req, ''), 4) + '" ' + 'Border_Not_Req="' + CONVERT(VARCHAR, isnull(@Border_Not_Req, ''), 4) + '" ' + 'IsModal="' + CONVERT(VARCHAR, isnull(@IsModal, ''), 4) + '" ' + 'Alternate_Color_Req="' + CONVERT(VARCHAR, isnull(@Alternate_Color_Req, ''), 4) + '" ' + 
							'Map_In_Req="' + CONVERT(VARCHAR, isnull(@Map_In_Req, ''), 4) + '" ' + 'Map_Out_Req="' + CONVERT(VARCHAR, isnull(@Map_Out_Req, ''), 4) + '" ' + 'IsCallout="' + isnull(@iscallout, '') + '" ' + 'SmartViewSection="' + isnull(@smartviewsection, '') + '" ' + 'SetScrollPosition="' + isnull(@preserveposition, '') + '" ' + -- added for Defect ID: TECH-18349
							'BadgeText="'				+ isnull(@BadgeText,'N')  +'" ' +			--TECH-72114
							'AutoHeight="'				+ isnull(@AutoHeight,'N')  +'" ' +			--TECH-72114
							'FileSize="' + isnull(@filesize, '') + '" />',
							@xml_seq_tmp
							)
							--Code Added for the Bug ID:PLF2.0_00961 ends
					END
					ELSE IF @ui_format_tmp <> 'top' --TECH-72114
					BEGIN
						-- code added for bugid : PNR2.0_17974  ends     --
						IF @auto_tab_stop = 'Y' -- code added by gopinath S for the Bug ID PNR2.0_19995
							SELECT @tab_seq_tmp = ''

						INSERT INTO ep_genxml_tmp (
							customer_name,
							project_name,
							req_no,
							process_name,
							component_name,
							activity_name,
							guid,
							gen_xml,
							seq_no
							)
						VALUES (
							@engg_customer_name,
							@engg_project_name,
							@engg_req_no,
							@process_name,
							@engg_component,
							@activity_name,
							@guid,
							'<Control Name="' + 'LBL' + ltrim(rtrim(isnull(@controlid_tmp, ''))) + '" ' + 'RenderAs="' + ltrim(rtrim(isnull(@renderas, ''))) + '" ' + 'ControlCaption="' + ltrim(rtrim(isnull(@ctrl_descr_tmp, ''))) + '" ' + 'SectionName="' + ltrim(rtrim(isnull(@section_bt_synonym_tmp, ''))) + '" ' + 'PageName="' + ltrim(rtrim(isnull(@page_bt_synonym_tmp, ''))) + '" ' + 'ILBOName="' + ltrim(rtrim(isnull(@ui_name_tmp, ''))) + '" ' + 'ActivityName="' + ltrim(rtrim(isnull(@activity_name, ''))) + '" ' + 'ComponentName="' + ltrim(rtrim(isnull(@engg_component, ''))) + '" ' + 'ControlType="' + ltrim(rtrim(isnull(upper(@control_type_tmp), ''))) + '" ' +
						-- code modified by Anuradha on 22-Mar-2006 for the Bug id :: PNR2.0_7393
							--       'DataType="'   + ltrim(rtrim(isnull(@datatype_tmp,'')))         + '" ' +
							--       'DataLength="'   + ltrim(rtrim(isnull(@datalength_tmp,'')))         + '" ' +
							--       'DecimalLength="'  + isnull(convert(varchar, @decimal_length_ctrl),'')       + '" ' +
							'DataType="' + CASE ltrim(rtrim(isnull(@base_ctrl_type_tmp, ''))) + '-' + ltrim(rtrim(isnull(@datatype_tmp, '')))
								WHEN 'COMBO-INTEGER'
									THEN ''
								ELSE ltrim(rtrim(isnull(@datatype_tmp, '')))
								END + '" ' + 'DataLength="' + CASE ltrim(rtrim(isnull(@base_ctrl_type_tmp, ''))) + '-' + ltrim(rtrim(isnull(@datatype_tmp, '')))
								WHEN 'COMBO-INTEGER'
									THEN ''
								ELSE ltrim(rtrim(isnull(@datalength_tmp, '')))
								END + '" ' + 'DecimalLength="' + CASE ltrim(rtrim(isnull(@base_ctrl_type_tmp, ''))) + '-' + ltrim(rtrim(isnull(@datatype_tmp, '')))
								WHEN 'COMBO-INTEGER'
									THEN ''
								ELSE isnull(convert(VARCHAR, @decimal_length_ctrl), '')
								END + '" ' +
							-- code modified by Anuradha on 22-Mar-2006 for the Bug id :: PNR2.0_7393
							'BTSynonym="' + ltrim(rtrim(isnull(@control_bt_synonym_tmp, ''))) + '" ' + 'BaseControlType="' + 'LABEL' + '" ' + -- Code modification  for  PNR2.0_23635
							'VisibleLength="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@visible_length_tmp, 0)))) + '" ' + 'ProtoTooltip="' + ltrim(rtrim(isnull(@proto_tooltip_tmp, ''))) + '" ' + 'SampleData="' + ltrim(rtrim(isnull(@sample_data_tmp, ''))) + '" ' + 'DefaultSampleData="' + ltrim(rtrim(isnull(@default_sample_data_tmp, ''))) + '" ' + 'HOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, isnull(@transformed_horder_tmp, 0)), 3))) + '" ' + 'VOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, isnull(@transformed_vorder_tmp, 0)), 3))) + '" ' + 'Mandatory="' + ltrim(rtrim(isnull(@mandatory_flag_tmp, ''))) + '" ' + 'Visible="' + ltrim(rtrim(isnull(@visible_flag_tmp, ''))) + '" ' + 'Editable="' + ltrim(rtrim(isnull(@editable_flag_tmp, ''))) + '" ' + 'CaptionRequired="' + ltrim(rtrim(isnull(@caption_req_tmp, ''))) + '" ' + 'SelectFlag="' + ltrim(rtrim(isnull(@select_flag_tmp, ''))) + '" ' + 'DeleteFlag="' + ltrim(rtrim(isnull(@delete_flag_tmp, ''))) + '" ' + 'ZoomRequired="' + ltrim(rtrim(isnull(@zoom_req_tmp, ''))) +
'" ' + 'HelpRequired="' + ltrim(rtrim(isnull(
										@help_req_tmp, ''))) + '" ' + 'EllipsesRequired="' + ltrim(rtrim(isnull(@ellipses_req_tmp, ''))) + '" ' + 'AssociatedTask="' + ltrim(rtrim(isnull(@uitaskname_tmp, ''))) + '" ' + 'DataColumnWidth="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@data_column_width_tmp, 0)))) + '" ' + 'LabelColumnWidth="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@label_column_width_tmp, 0)))) + '" ' + 'DataColumnScaleMode="' + ltrim(rtrim(isnull(@data_column_scalemode, '%'))) + '" ' + 'LabelColumnScaleMode="' + ltrim(rtrim(isnull(@label_column_scalemode, '%'))) + '" ' + 'CaptionWrap="' + ltrim(rtrim(isnull(@caption_wrap_tmp, 'Y'))) + '" ' + 'CaptionAlignment="' + ltrim(rtrim(isnull(@caption_alignment_tmp, 'LEFT'))) + '" ' + 'CaptionPosition="' + ltrim(rtrim(isnull(@caption_position_tmp, 'LEFT'))) + '" ' + 'ControlPosition="' + ltrim(rtrim(isnull(@ctrl_position_tmp, 'LEFT'))) + '" ' + 'LabelClass="' + ltrim(rtrim(isnull(@label_class_tmp, ''))) + '" ' + 'ControlClass="' + ltrim(rtrim(isnull(@ctrl_class_tmp, ''))) + '" ' + 'PasswordChar="' + ltrim(rtrim(isnull(
										@password_char_tmp, 'N'))) + '" ' + 'TaskImageClass="' + ltrim(rtrim(isnull(@task_img_tmp, ''))) + '" ' + 'HelpImageClass="' + ltrim(rtrim(isnull(@help_img_tmp, ''))) + '" ' + 'Documentation="' + ltrim(rtrim(isnull(@controldoc_tmp, ''))) + '" ' 
+
							-- code added for bugid : PNR2.0_17974  starts     --
							'OrderSequence="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@transformed_seqno_tmp, 0)))) + '" ' +
							--      'OrderSequence="'  + ltrim(rtrim(CONVERT(VARCHAR,isnull(@order_seq_tmp,0))))     + '" ' +
							-- code added for bugid : PNR2.0_17974  ends     --
							'VisibleRows="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@visible_rows_tmp, 0)))) + '" ' +
							-- code added by Ganesh for the callid :: PNR2.0_3812 on 09/09/05
							'HTMLTextArea="' + ltrim(rtrim(isnull(@html_text_area, 'N'))) + '" ' + 'SpinRequired="' + ltrim(rtrim(isnull(@spin_required, 'N'))) + '" ' + 'SpinUpImage="' + ltrim(rtrim(isnull(@spin_up_image, 'spinup.gif'))) + '" ' + 'SpinDownImage="' + ltrim(rtrim(isnull(@spin_down_image, 'spindown.gif'))) + '" ' + 'AssociatedSpinControl="' + ltrim(rtrim(isnull(@associated_spin_ctrl, ''))) + '" ' + 'AssociatedSpinTask="' + ltrim(rtrim(isnull(@associated_spin_task, ''))) + '" ' + 'HelpText="' + ltrim(rtrim(isnull
(@helptext, ''))) + '" ' +
							--code modified for bugId : PNR2.0_10741
							'ReportRequired="' + ltrim(rtrim(isnull(@report_reqd, ''))) + '" ' + 'ModelSectionName="' + ltrim(rtrim(isnull(@section_bt_synonym_tmp, ''))) + '" ' +
							-- Inplace Calendar and Edit Mask Feature added by Feroz -- Start
							'InPlaceCalendar="' + ltrim(rtrim(isnull(@InPlaceCalendar, 'n'))) + '" ' +
							-- Code modification for  PNR2.0_19426  starts
							'InCalDisplay="' + ltrim(rtrim(isnull(@InPlaceCal_Display, ''))) + '" ' + 'EditMask="' + ltrim(rtrim(isnull(@EditMaskPattern, ''))) + '" ' +
							-- Inplace Calendar and Edit Mask Feature added by Feroz -- End
							--       'TabIndex="'   + ltrim(rtrim(isnull(@tab_seq,0)))                    + '" '  +
							'TabIndex="' + ltrim(rtrim(@tab_seq_tmp)) + '" ' + -- code added by gopinath S for the Bug ID PNR2.0_19995
							'AccessKey="' + ltrim(rtrim(isnull(@AccessKey, ''))) + '" ' + -- Added by Jeya For AccessKey
							-- Code modification for  PNR2.0_19426  ends
							-- Code addition for PNR2.0_21576 starts
							--Code modified by Balaji D for Bug ID PNR2.0_28889 on 01-Nov-2010 starts
							'GridLite="' + ltrim(rtrim(isnull(@gridlite, 'N'))) + '" ' +
							--Code modified by Balaji D for Bug ID PNR2.0_28889 on 01-Nov-2010 end
							-- Code addition for PNR2.0_21576 ends
							-- code added for bugid : PNR2.0_17974  starts     --
							-- Code addition for PNR2.0_20849 starts
							'NoofLinesPerRow="' + ltrim(rtrim(isnull(@NoofLinesPerRow, ''))) + '" ' + 'RowHeight="' + ltrim(rtrim(isnull(@RowHeight, ''))) + '" ' +
							-- Added By Feroz
							'BulletLink="' + ltrim(rtrim(isnull(@bulletlink_req, 'N'))) + '" ' + 'ButtonCombo="' + ltrim(rtrim(isnull(@buttoncombo_req, 'N'))) + '" ' + 'DataAsCaption="' + ltrim(rtrim(isnull(@dataascaption, 'N'))) + '" ' + 'AssociatedList="' + ltrim(rtrim(isnull(@associatedlist_name, ''))) + '" ' + 'OnFocusTask="' + ltrim(rtrim(isnull(@onfocus_taskname, ''))) + '" ' + 'ListRefillTask="' + ltrim(rtrim(isnull(@listrefill_taskname, ''))) + '" ' + 'MappedListControlID="' + ltrim(rtrim(isnull(@mapped_list_controlid
, ''))) + '" ' + 'MappedListViewName="' + ltrim(rtrim(isnull(@mapped_list_viewname, ''))) + '" ' + 'AttachDocument="' + ltrim(rtrim(isnull(@attach_document, 'N'))) + '" ' + 
'ImageUpload="' + ltrim(rtrim(isnull(@image_upload, 'N'))) + '" ' + 'InplaceImage="' + ltrim(rtrim(isnull(@inplace_image, 'N'))) + '" ' + 
'ImageIcon="' + ltrim(rtrim(isnull(@image_icon, 'N'))) + '" ' + 
'ImageType="'   + ltrim(rtrim(isnull(@ImageType,'N')))             + '" ' +
'ImageRowHeight="' + ltrim(rtrim(isnull(@image_row_height, '0'))) + '" ' + 'RelativeUrlPath="' + ltrim(rtrim(isnull(@relative_url_path,
 ''))) + '" ' + 'RelativeDocumentPath="' + ltrim(rtrim(
									isnull(@relative_document_path, ''))) + '" ' + 'RelativeImagePath="' + ltrim(rtrim(isnull(@relative_image_path, ''))) + '" ' + 'SaveDocContentToDb="' + ltrim(rtrim(isnull(@save_doc_content_to_db, 'N'))) + '" ' + 'SaveImageContentToDb="' + ltrim(rtrim(isnull(@save_image_content_to_db, 'N'))) + '" ' + 'DateHighlight="' + ltrim(rtrim(isnull(@date_highlight_req, 'N'))) + '" ' + 'LinkedHiddenViewName="' + ltrim(rtrim(isnull(@hidden_view_name, ''))) + '" ' + 'Vscrollbar_Req="' + ltrim(rtrim(isnull(@Vscrollbar_Req, 'N'))) + '" LiteAttach="' + Isnull(@Lite_Attach, 'N') + '" Browse_Button="' + Isnull(@BrowseButton, 'N') + '" Delete_Button="' + Isnull(@DeleteButton, 'N') + '" ' + --PNR2.0_28365 -- Code Modified For BUGID PNR2.0_28537
							'IsITK="N"  FC="' + CONVERT(VARCHAR, isnull(@freezecount, 0), 4) + '" ' +
							--code added for the caseid : PNR2.0_28319 starts
							'image_row_width="' + CONVERT(VARCHAR, isnull(@image_row_width, 0), 4) + '" ' + 'image_preview_height="' + CONVERT(VARCHAR, isnull(@image_preview_height, 0), 4) + '" ' + 'image_preview_width="' + CONVERT(VARCHAR, isnull(@image_preview_width, 0), 4)
 + '" ' + 'image_preview_req="' + isnull(@image_preview_req, 'N') + '" ' + 'Accept_Type="' + isnull(@Accept_Type, '') + '" ' + 'Lite_Attach_Image="' + isnull(@Lite_Attach_Image, 'N') + '" ' + 'LabelLink="' + isnull(@LabelLink, 'N') + '" ' + -- added by feroz for req id : PNR2.0_1790,PNR2.0_26860,PNR2.0_27796,PNR2.0_36309
							-- Code addition for PNR2.0_20849 ends
							--code added for the caseid : PNR2.0_28319 ends
							--Code Added for the Bug ID: PLF2.0_00961 starts
							--'PopUpPage="'           +   isnull(@popup_page,'')                  +'" ' +
							--'PopUpSection="'        +   isnull(@popup_section,'')               +'" ' +
							--'PopUpClose="'          +   isnull(@popup_Close,'N')                +'" ' +
							'CaptionType="' + isnull(@captiontype, '') + '" ' + 'ControlStyle="' + isnull(@controlstyle, '') + '" ' + 'ControlImage="' + isnull(@controlimage, '') + '" ' + 'IsListBox="' + isnull(@IsListBox, '') + '" ' + 'Toolbar_Not_Req="' + isnull(@Toolbar_Not_Req, '') + '" ' + 'ColumnBorder_Not_Req="' + isnull(@ColumnBorder_Not_Req, '') + '" ' + 'RowBorder_Not_Req="' + isnull(@RowBorder_Not_Req, '') + '" ' + 'PageNavigation_Only="' + isnull(@PagenavigationOnly, '') + '" ' + 'RowNo_Not_Req="' + isnull(@RowNo_Not_Req, '') + '" ' +
							--'ExtType="'         +   isnull(@ExtType,'')  +'" ' +
							'ColSpan="' + CONVERT(VARCHAR, isnull(@ControlColSpan, ''), 4) + '" ' + 'RowSpan="' + CONVERT(VARCHAR, isnull(@ControlRowSpan, ''), 4) + '" ' + 'Tooltip_Not_Req="' + CONVERT(VARCHAR, isnull(@Tooltip_Not_Req, ''), 4) + '" ' + 'GridHeader_Not_Req="' 
+ CONVERT(VARCHAR, isnull(@columncaption_Not_Req, ''), 4) + '" ' + 'Border_Not_Req="' + CONVERT(VARCHAR, isnull(@Border_Not_Req, ''), 4) + '" ' + 'IsModal="' + CONVERT(VARCHAR, isnull(@IsModal, ''), 4) + '" ' + 'Alternate_Color_Req="' + CONVERT(VARCHAR, isnull(@Alternate_Color_Req, ''), 4) + '" ' + --PLF2.0_03057
							'Map_In_Req="' + CONVERT(VARCHAR, isnull(@Map_In_Req, ''), 4) + '" ' + 'Map_Out_Req="' + CONVERT(VARCHAR, isnull(@Map_Out_Req, ''), 4) + '" ' + 'IsCallout="' + isnull(@iscallout, '') + '" ' + 'SmartViewSection="' + isnull(@smartviewsection, '') + '" ' + 'AutoSelect="' + isnull(@autoselect, '') + '" ' + 'SetScrollPosition="' + isnull(@preserveposition, '') + '" ' + -- added for Defect ID: TECH-18349
							'IsPivot="' + isnull(@ispivot, 'N') + '" ' + 'TemplateCategory="' + isnull(@TemplateCat, '') + '" ' + 
							'TemplateSpecification="' + isnull(@TemplateSpecific, '') + '" ' + 
							'SetFocusEvent="'	+ isnull(@setfocusevent,'')	 +'" ' +  -- Added for TECH-37471 
							'LeaveFocusEvent="'	+ isnull(@leavefocusevent,'')	 +'" ' +  -- Added for TECH-37471 
							'SetFocusEventOccurence="'	+ isnull(@setfocuseventoccur,'')	 +'" ' +  
							'LeaveFocusEventOccurence="'	+ isnull(@leavefocuseventoccur,'')	 +'" ' +  
							'RatingType="' + ltrim(rtrim(isnull(lower(@RatingType), ''))) + '" ' + 
							'CaptchaData="' + ltrim(rtrim(isnull(lower(@CaptchaData), ''))) + '" ' + 
							'BadgeText="'				+ isnull(@BadgeText,'N')  +'" ' +   --TECH-72114
							'AutoHeight="'				+ isnull(@AutoHeight,'N')  +'" ' +   --TECH-72114
							'FileSize="' + isnull(@filesize, '') + '" />',
							@xml_seq_tmp
							)
							--Code Added for the Bug ID:PLF2.0_00961 ends
					END

					-- code added for bugid : PNR2.0_17974  ends     --
					IF @ui_format_tmp = 'BES'
					BEGIN
						SELECT @position_vindex_tmp = @position_vindex_tmp + 1
					END
				END

				--Code Modified For BugId : PNR2.0_9131
				IF (
						@caption_req_tmp = 'Y'
						AND @base_ctrl_type_tmp IN (
							'Button',
							'Link'
							)
						)
					AND @control_type_tmp <> 'Label'
					AND @base_ctrl_type_tmp <> 'label'
				BEGIN
					IF @ui_format_tmp = 'BES'
					BEGIN
						SELECT @position_vindex_tmp = @position_vindex_tmp + 1
					END
					ELSE IF @ui_format_tmp = 'UND'
					BEGIN
						SELECT @helptext = @ctrl_descr_tmp + ' - Datatype : ' + ltrim(rtrim(isnull(@datatype_tmp, ''))) + ' - MaxLength : ' + ltrim(rtrim(isnull(@datalength_tmp, '')))

						IF upper(isnull(@datatype_tmp, '')) = 'NUMERIC'
							SELECT @helptext = @helptext + ' - DecimalLength : ' + ltrim(rtrim(isnull(@datalength_tmp, '')))
						
						select @transformed_horder_tmp = (@horder_tmp * 2) - 1 --modified by 13026 for TECH-58883

						INSERT INTO ep_genxml_tmp (
							customer_name,
							project_name,
							req_no,
							process_name,
							component_name,
							activity_name,
							guid,
							gen_xml,
							seq_no
							)
						VALUES (
							@engg_customer_name,
							@engg_project_name,
							@engg_req_no,
							@process_name,
							@engg_component,
							@activity_name,
							@guid,
							'<Control Name="' + ltrim(rtrim(isnull('filler_' + @controlid_tmp, ''))) + '" ' + 'RenderAs="' + ltrim(rtrim(isnull(@renderas, ''))) + '" ' + 'ControlCaption="' + ltrim(rtrim(isnull(@ctrl_descr_tmp, ''))) + '" ' + 'SectionName="' + ltrim(rtrim(isnull(@section_bt_synonym_tmp, ''))) + '" ' + 'PageName="' + ltrim(rtrim(isnull(@page_bt_synonym_tmp, ''))) + '" ' + 'ILBOName="' + ltrim(rtrim(isnull(@ui_name_tmp, ''))) + '" ' + 'ActivityName="' + ltrim(rtrim(isnull(@activity_name, ''))) + '" ' + 'ComponentName="' + ltrim(rtrim(isnull(@engg_component, ''))) + '" ' + 'ControlType="' + ltrim(rtrim(isnull(upper('Filler'), ''))) + '" ' + 'BaseControlType="' + ltrim(rtrim(isnull('FILLER', ''))) + '" ' + -- Code modification  for  PNR2.0_23635
							--        'DataType="'   + ltrim(rtrim(isnull(@datatype_tmp,'')))         + '" ' +
							--        'DataLength="'   + ltrim(rtrim(isnull(@datalength_tmp,'')))         + '" ' +
							--        'DecimalLength="'  + isnull(convert(varchar, @decimal_length_ctrl),'')       + '" ' +
							-- code modified by Anuradha on 22-Mar-2006 for the Bug id :: PNR2.0_7393
							'DataType="' + CASE ltrim(rtrim(isnull(@base_ctrl_type_tmp, ''))) + '-' + ltrim(rtrim(isnull(@datatype_tmp, '')))
								WHEN 'COMBO-INTEGER'
									THEN ''
								ELSE ltrim(rtrim(isnull(@datatype_tmp, '')))
								END + '" ' + 'DataLength="' + CASE ltrim(rtrim(isnull(@base_ctrl_type_tmp, ''))) + '-' + ltrim(rtrim(isnull(@datatype_tmp, '')))
								WHEN 'COMBO-INTEGER'
									THEN ''
								ELSE ltrim(rtrim(isnull(@datalength_tmp, '')))
								END + '" ' + 'DecimalLength="' + CASE ltrim(rtrim(isnull(@base_ctrl_type_tmp, ''))) + '-' + ltrim(rtrim(isnull(@datatype_tmp, '')))
								WHEN 'COMBO-INTEGER'
									THEN ''
								ELSE isnull(convert(VARCHAR, @decimal_length_ctrl), '')
								END + '" ' +
							-- code modified by Anuradha on 22-Mar-2006 for the Bug id :: PNR2.0_7393
							'BTSynonym="' + ltrim(rtrim(isnull(@control_bt_synonym_tmp, ''))) + '" ' + 'VisibleLength="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@visible_length_tmp, 0)))) + '" ' + 'ProtoTooltip="' + ltrim(rtrim(isnull(@proto_tooltip_tmp, ''))) + '" ' + 'SampleData="' + ltrim(rtrim(isnull(@sample_data_tmp, ''))) + '" ' + 'DefaultSampleData="' + ltrim(rtrim(isnull(@default_sample_data_tmp, ''))) + '" ' + 'HOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, isnull(@transformed_horder_tmp + 1, 0)), 3))) + '" ' 
+ 'VOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, isnull(@vorder_tmp, 0)), 3))) + '" ' + 'Mandatory="' + ltrim(rtrim(isnull(@mandatory_flag_tmp, ''))) + '" ' + 'Visible="' + ltrim(rtrim(isnull(@visible_flag_tmp, ''))) + '" ' + 'Editable="' + ltrim(rtrim(isnull(@editable_flag_tmp, ''))) + '" ' + 'CaptionRequired="' + ltrim(rtrim(isnull(@caption_req_tmp, ''))) + '" ' + 'SelectFlag="' + ltrim(rtrim(isnull(@select_flag_tmp, ''))) + '" ' + 'DeleteFlag="' + ltrim(rtrim(isnull(@delete_flag_tmp, ''))) + 
'" ' + 'ZoomRequired="' + ltrim(rtrim(isnull(@zoom_req_tmp
										, ''))) + '" ' + 'HelpRequired="' + ltrim(rtrim(isnull(@help_req_tmp, ''))) + '" ' + 'EllipsesRequired="' + ltrim(rtrim(isnull(@ellipses_req_tmp, ''))) + '" ' + 'AssociatedTask="' + ltrim(rtrim(isnull(@uitaskname_tmp, ''))) + '" ' + 'DataColumnWidth="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@data_column_width_tmp, 0)))) + '" ' + 'LabelColumnWidth="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@label_column_width_tmp, 0)))) + '" ' + 'DataColumnScaleMode="' + ltrim(rtrim(isnull(@data_column_scalemode, '%
'))) + '" ' + 'LabelColumnScaleMode="' + ltrim(rtrim(isnull(@label_column_scalemode, '%'))) + '" ' + 'CaptionWrap="' + ltrim(rtrim(isnull(@caption_wrap_tmp, 'Y'))) + '" ' + 'CaptionAlignment="' + ltrim(rtrim(isnull(@caption_alignment_tmp, 'LEFT'))) + '" '
 + 'CaptionPosition="' + ltrim(rtrim(isnull(@caption_position_tmp, 'LEFT'))) + '" ' + 'ControlPosition="' + ltrim(rtrim(isnull(@ctrl_position_tmp, 'LEFT'))) + '" ' + 'LabelClass="' + ltrim(rtrim(isnull(@label_class_tmp, ''))) + '" ' + 'ControlClass="' + ltrim(rtrim(isnull(@ctrl_class_tmp, ''))) + 
							'" ' + 'PasswordChar="' + ltrim(rtrim(isnull(@password_char_tmp, 'N'))) + '" ' + 'TaskImageClass="' + ltrim(rtrim(isnull(@task_img_tmp, ''))) + '" ' + 'HelpImageClass="' + ltrim(rtrim(isnull(@help_img_tmp, ''))) + '" ' + 'Documentation="' + ltrim(rtrim(isnull(@controldoc_tmp, ''))) + '" ' + 'OrderSequence="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@order_seq_tmp, 0)))) + '" ' + 'VisibleRows="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@visible_rows_tmp, 0)))) + '" ' + 'HTMLTextArea="' + ltrim(rtrim(isnull(@html_text_area, 'N'))) + '" ' + 'SpinRequired="' + ltrim(rtrim(isnull(@spin_required, 'N'))) + '" ' + 'SpinUpImage="' + ltrim(rtrim(isnull(@spin_up_image, 'spinup.gif'))) + '" ' + 'SpinDownImage="' + ltrim(rtrim(isnull(@spin_down_image, 'spindown.gif')
)) + '" ' + 'AssociatedSpinControl="' + ltrim(rtrim(isnull(@associated_spin_ctrl, ''))) + '" ' + 'AssociatedSpinTask="' + ltrim(rtrim(isnull(@associated_spin_task, ''))) + '" ' + 'HelpText="' + ltrim(rtrim(isnull(@helptext, ''))) + '" ' +
							--code modified for bugId : PNR2.0_10741
							'ReportRequired="' + ltrim(rtrim(isnull(@report_reqd, ''))) + '" ' + 'ModelSectionName="' + ltrim(rtrim(isnull(@section_bt_synonym_tmp, ''))) + '" ' +
							-- Inplace Calendar and Edit Mask Feature added by Feroz -- Start
							'InPlaceCalendar="' + ltrim(rtrim(isnull(@InPlaceCalendar, 'n'))) + '" ' +
							-- Code modification for  PNR2.0_19426  starts
							'InCalDisplay="' + ltrim(rtrim(isnull(@InPlaceCal_Display, ''))) + '" ' + 'EditMask="' + ltrim(rtrim(isnull(@EditMaskPattern, ''))) + '" ' +
							-- Inplace Calendar and Edit Mask Feature added by Feroz -- End
							'TabIndex="' + ltrim(rtrim(@tab_seq)) + '" ' + 'AccessKey="' + ltrim(rtrim(isnull(@AccessKey, ''))) + '" ' + -- Added by Jeya For AccessKey
							-- Code modification for  PNR2.0_19426 ends
							-- Code addition for PNR2.0_21576 starts
							--Code modified by Balaji D for Bug ID PNR2.0_28889 on 01-Nov-2010 starts
							'GridLite="' + ltrim(rtrim(isnull(@gridlite, 'N'))) + '" ' +
							--Code modified by Balaji D for Bug ID PNR2.0_28889 on 01-Nov-2010 end
							-- Code addition for PNR2.0_21576 ends
							-- Code addition for PNR2.0_20849 starts
							'NoofLinesPerRow="' + ltrim(rtrim(isnull(@NoofLinesPerRow, ''))) + '" ' + 'RowHeight="' + ltrim(rtrim(isnull(@RowHeight, ''))) + '" ' +
							-- Added By Feroz
							'BulletLink="' + ltrim(rtrim(isnull(@bulletlink_req, 'N'))) + '" ' + 'ButtonCombo="' + ltrim(rtrim(isnull(@buttoncombo_req, 'N'))) + '" ' + 'DataAsCaption="' + ltrim(rtrim(isnull(@dataascaption, 'N'))) + '" ' + 'AssociatedList="' + ltrim(rtrim(isnull(@associatedlist_name, ''))) + '" ' + 'OnFocusTask="' + ltrim(rtrim(isnull(@onfocus_taskname, ''))) + '" ' + 'ListRefillTask="' + ltrim(rtrim(isnull(@listrefill_taskname, ''))) + '" ' + 'MappedListControlID="' + ltrim(rtrim(isnull(@mapped_list_controlid
, ''))) + '" ' + 'MappedListViewName="' + ltrim(rtrim(isnull(@mapped_list_viewname, ''))) + '" ' + 'AttachDocument="' + ltrim(rtrim(isnull(@attach_document, 'N'))) + '" ' + 'ImageUpload="' + ltrim(rtrim(isnull(@image_upload, 'N'))) + '" ' + 'InplaceImage=
"' + ltrim(rtrim(isnull(@inplace_image, 'N'))) + '" ' + 'ImageIcon="' + ltrim(rtrim(isnull(@image_icon, 'N'))) + '" ' + 
'ImageType="'   + ltrim(rtrim(isnull(@ImageType,'N')))             + '" ' +
'ImageRowHeight="' + ltrim(rtrim(isnull(@image_row_height, '0'))) + '" ' + 'RelativeUrlPath="' + ltrim(rtrim(isnull(@relative_url_path,
 ''))) + '" ' + 'RelativeDocumentPath="' + ltrim(rtrim(
									isnull(@relative_document_path, ''))) + '" ' + 'RelativeImagePath="' + ltrim(rtrim(isnull(@relative_image_path, ''))) + '" ' + 'SaveDocContentToDb="' + ltrim(rtrim(isnull(@save_doc_content_to_db, 'N'))) + '" ' + 'SaveImageContentToDb="' + ltrim(rtrim(isnull(@save_image_content_to_db, 'N'))) + '" ' + 'DateHighlight="' + ltrim(rtrim(isnull(@date_highlight_req, 'N'))) + '" ' + 'LinkedHiddenViewName="' + ltrim(rtrim(isnull(@hidden_view_name, ''))) + '" ' + 'Vscrollbar_Req="' + ltrim(rtrim(isnull(@Vscrollbar_Req, 'N'))) + '" LiteAttach="' + Isnull(@Lite_Attach, 'N') + '" Browse_Button="' + Isnull(@BrowseButton, 'N') + '" Delete_Button="' + Isnull(@DeleteButton, 'N') + '" ' + --PNR2.0_28365 -- Code Modified For BUGID PNR2.0_28537
							'IsITK="N"  FC="' + CONVERT(VARCHAR, isnull(@freezecount, 0), 4) + '" ' +
							--code added for the caseid : PNR2.0_28319 starts
							'image_row_width="' + CONVERT(VARCHAR, isnull(@image_row_width, 0), 4) + '" ' + 'image_preview_height="' + CONVERT(VARCHAR, isnull(@image_preview_height, 0), 4) + '" ' + 'image_preview_width="' + CONVERT(VARCHAR, isnull(@image_preview_width, 0), 4)
 + '" ' + 'image_preview_req="' + isnull(@image_preview_req, 'N') + '" ' + 'Accept_Type="' + isnull(@Accept_Type, '') + '" ' + 'Lite_Attach_Image="' + isnull(@Lite_Attach_Image, 'N') + '" ' + 'LabelLink="' + isnull(@LabelLink, 'N') + '" ' + --added for PNR2.0_26860, PNR2.0_27796,PNR2.0_36309
							-- Code addition for PNR2.0_20849 ends
							--code added for the caseid : PNR2.0_28319 ends
							--Code Added for the Bug ID: PLF2.0_00961 starts
							--'PopUpPage="'           +   isnull(@popup_page,'')                  +'" ' +
							--'PopUpSection="'        +   isnull(@popup_section,'')               +'" ' +
							--'PopUpClose="'          +   isnull(@popup_Close,'N')                +'" ' +
							'CaptionType="' + isnull(@captiontype, '') + '" ' + 'ControlStyle="' + isnull(@controlstyle, '') + '" ' + 'ControlImage="' + isnull(@controlimage, '') + '" ' + 'IsListBox="' + isnull(@IsListBox, '') + '" ' + 'Toolbar_Not_Req="' + isnull(@Toolbar_Not_Req, '') + '" ' + 'ColumnBorder_Not_Req="' + isnull(@ColumnBorder_Not_Req, '') + '" ' + 'RowBorder_Not_Req="' + isnull(@RowBorder_Not_Req, '') + '" ' + 'PageNavigation_Only="' + isnull(@PagenavigationOnly, '') + '" ' + 'RowNo_Not_Req="' + isnull(@RowNo_Not_Req, '') + '" ' + 'ExtType="' + isnull(@ExtType, '') + '" ' + 'ColSpan="' + CONVERT(VARCHAR, isnull(@ControlColSpan, ''), 4) + '" ' + 'RowSpan="' + CONVERT(VARCHAR, isnull(@ControlRowSpan, ''), 4) + '" ' + 'Tooltip_Not_Req="' + CONVERT(VARCHAR, isnull
(@Tooltip_Not_Req, ''), 4) + '" ' + 'GridHeader_Not_Req="' + CONVERT(VARCHAR, isnull(@columncaption_Not_Req, ''), 4) + '" ' + 'Border_Not_Req="' + CONVERT(VARCHAR, isnull(@Border_Not_Req, ''), 4) + '" ' + 'IsModal="' + CONVERT(VARCHAR, isnull(@IsModal, ''
), 4) + '" ' + 'Alternate_Color_Req="' + CONVERT(VARCHAR, isnull(@Alternate_Color_Req
									, ''), 4) + '" ' + 'Map_In_Req="' + CONVERT(VARCHAR, isnull(@Map_In_Req, ''), 4) + '" ' + 'Map_Out_Req="' + CONVERT(VARCHAR, isnull(@Map_Out_Req, ''), 4) + '" ' + 'IsCallout="' + isnull(@iscallout, '') + '" ' + 'SmartViewSection="' + isnull(@smartviewsection, '') + '" ' + 'SetScrollPosition="' + isnull(@preserveposition, '') + '" ' + -- added for Defect ID: TECH-18349
							'IsPivot="' + isnull(@ispivot, 'N') + '" ' + 'TemplateCategory="' + isnull(@TemplateCat, '') + '" ' + 
							'TemplateSpecification="' + isnull(@TemplateSpecific, '') + '" ' + 
							'BadgeText="'				+ isnull(@BadgeText,'N')  +'" ' +			--TECH-72114
							'AutoHeight="'				+ isnull(@AutoHeight,'N')  +'" ' +			--TECH-72114
							'FileSize="' + isnull(@filesize, '') + '" />',
							@xml_seq_tmp
							)

						--Code Added for the Bug ID:PLF2.0_00961 ends
						SELECT @position_hindex_tmp = @position_hindex_tmp + 1
					END
				END

				IF @ui_format_tmp = 'BES'
				BEGIN
					SELECT @transformed_horder_tmp = @horder_tmp

					--select @transformed_vorder_tmp = @vorder_tmp
					IF @order_seq_tmp <= 1
					BEGIN
						SELECT @transformed_vorder_tmp = @vorder_tmp + @position_vindex_tmp
					END
				END
				ELSE
				BEGIN
					IF @control_type_tmp IN ('Filler2')
						OR (
							@base_ctrl_type_tmp = 'line'
							AND @caption_req_tmp = 'Y'
							)
					BEGIN
						SELECT @transformed_horder_tmp = (@horder_tmp * 2) - 1

						SELECT @transformed_vorder_tmp = @vorder_tmp
					END
					ELSE IF @control_type_tmp IN ('Filler')
						OR (@caption_req_tmp = 'N')
						OR (@base_ctrl_type_tmp = 'Label')
						OR (@control_type_tmp = 'Label')
					BEGIN
						SELECT @transformed_horder_tmp = @horder_tmp

						SELECT @transformed_vorder_tmp = @vorder_tmp
					END
					ELSE
					BEGIN
						SELECT @transformed_horder_tmp = @horder_tmp * 2

						SELECT @transformed_vorder_tmp = @vorder_tmp
					END
				END

				IF @base_ctrl_type_tmp = 'Label'
					SELECT @control_type_tmp = 'lbl' + @controlid_tmp

				--Code Modified For BugId : PNR2.0_9414
				IF @control_type_tmp <> 'Label' --and @base_ctrl_type_tmp <> 'label'
				BEGIN
					IF @order_seq_tmp > 1
						AND @ui_format_tmp = 'BES'
					BEGIN
						SELECT @transformed_seqno_tmp = @order_seq_tmp + @position_sindex_tmp
					END
					ELSE
					BEGIN
						SELECT @transformed_seqno_tmp = @order_seq_tmp
					END

					-- Insert Control Entry
					SELECT @xml_seq_tmp = @xml_seq_tmp + 1

					SELECT @helptext = @ctrl_descr_tmp + ' - Datatype : ' + ltrim(rtrim(isnull(@datatype_tmp, ''))) + ' - MaxLength : ' + ltrim(rtrim(isnull(@datalength_tmp, '')))

					IF upper(isnull(@datatype_tmp, '')) = 'NUMERIC'
						SELECT @helptext = @helptext + ' - DecimalLength : ' + ltrim(rtrim(isnull(@datalength_tmp, '')))

					-- code added for bugid : PNR2.0_17974  starts     --
					IF (
							@base_ctrl_type_tmp = 'Checkbox'
							AND @caption_req_tmp = 'Y'
							AND @ctrl_position_tmp = 'Right'
							)
					BEGIN
						-- code added for bugid : PNR2.0_31505
						--select @caption_alignment_tmp = 'left'
						IF @auto_tab_stop = 'Y'
							SELECT @tab_seq_tmp = '' -- code added by gopinath S for the Bug ID PNR2.0_19995

						INSERT INTO ep_genxml_tmp (
							customer_name,
							project_name,
							req_no,
							process_name,
							component_name,
							activity_name,
							guid,
							gen_xml,
							seq_no
							)
						VALUES (
							@engg_customer_name,
							@engg_project_name,
							@engg_req_no,
							@process_name,
							@engg_component,
							@activity_name,
							@guid,
							'<Control Name="' + 'LBL' + ltrim(rtrim(isnull(@controlid_tmp, ''))) + '" ' + 'RenderAs="' + ltrim(rtrim(isnull(@renderas, ''))) + '" ' + 'ControlCaption="' + ltrim(rtrim(isnull(@ctrl_descr_tmp, ''))) + '" ' + 'SectionName="' + ltrim(rtrim(isnull(@section_bt_synonym_tmp, ''))) + '" ' + 'PageName="' + ltrim(rtrim(isnull(@page_bt_synonym_tmp, ''))) + '" ' + 'ILBOName="' + ltrim(rtrim(isnull(@ui_name_tmp, ''))) + '" ' + 'ActivityName="' + ltrim(rtrim(isnull(@activity_name, ''))) + '" ' + 'ComponentName="' + ltrim(rtrim(isnull(@engg_component, ''))) + '" ' + 'ControlType="' + ltrim(rtrim(isnull(upper(@control_type_tmp), ''))) + '" ' + 'DataType="' + CASE ltrim(rtrim(isnull(@base_ctrl_type_tmp, ''))) + '-' + ltrim(rtrim(isnull(@datatype_tmp, '')))
								WHEN 'COMBO-INTEGER'
									THEN ''
								ELSE ltrim(rtrim(isnull(@datatype_tmp, '')))
								END + '" ' + 'DataLength="' + CASE ltrim(rtrim(isnull(@base_ctrl_type_tmp, ''))) + '-' + ltrim(rtrim(isnull(@datatype_tmp, '')))
								WHEN 'COMBO-INTEGER'
									THEN ''
								ELSE ltrim(rtrim(isnull(@datalength_tmp, '')))
								END + '" ' + 'DecimalLength="' + CASE ltrim(rtrim(isnull(@base_ctrl_type_tmp, ''))) + '-' + ltrim(rtrim(isnull(@datatype_tmp, '')))
								WHEN 'COMBO-INTEGER'
									THEN ''
								ELSE isnull(convert(VARCHAR, @decimal_length_ctrl), '')
								END + '" ' + 'BTSynonym="' + ltrim(rtrim(isnull(@control_bt_synonym_tmp, ''))) + '" ' + 'BaseControlType="' + 'LABEL' + '" ' + -- Code modification  for  PNR2.0_23635
							'VisibleLength="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@visible_length_tmp, 0)))) + '" ' + 'ProtoTooltip="' + ltrim(rtrim(isnull(@proto_tooltip_tmp, ''))) + '" ' + 'SampleData="' + ltrim(rtrim(isnull(@sample_data_tmp, ''))) + '" ' + 'DefaultSampleData="' + ltrim(rtrim(isnull(@default_sample_data_tmp, ''))) + '" ' + 'HOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, isnull(@transformed_horder_tmp, 0)), 3))) + '" ' + 'VOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, isnull(@transformed_vorder_tmp, 0)), 3))) + '" ' + 'Mandatory="' + ltrim(rtrim(isnull(@mandatory_flag_tmp, ''))) + '" ' + 'Visible="' + ltrim(rtrim(isnull(@visible_flag_tmp, ''))) + '" ' + 'Editable="' + ltrim(rtrim(isnull(@editable_flag_tmp, ''))) + '" ' + 'CaptionRequired=
"' + ltrim(rtrim(isnull(@caption_req_tmp, ''))) + '" ' + 'SelectFlag="' + ltrim(rtrim(isnull(@select_flag_tmp, ''))) + '" ' + 'DeleteFlag="' + ltrim(rtrim(isnull(@delete_flag_tmp, ''))) + '" ' + 'ZoomRequired="' + ltrim(rtrim(isnull(@zoom_req_tmp, ''))) +
 '" ' + 'HelpRequired="' + ltrim(rtrim(isnull(
										@help_req_tmp, ''))) + '" ' + 'EllipsesRequired="' + ltrim(rtrim(isnull(@ellipses_req_tmp, ''))) + '" ' + 'AssociatedTask="' + ltrim(rtrim(isnull(@uitaskname_tmp, ''))) + '" ' + 'DataColumnWidth="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@data_column_width_tmp, 0)))) + '" ' + 'LabelColumnWidth="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@label_column_width_tmp, 0)))) + '" ' + 'DataColumnScaleMode="' + ltrim(rtrim(isnull(@data_column_scalemode, '%'))) + '" ' + 'LabelColumnScaleMode="' + ltrim(rtrim(isnull(@label_column_scalemode, '%'))) + '" ' + 'CaptionWrap="' + ltrim(rtrim(isnull(@caption_wrap_tmp, 'Y'))) + '" ' + 'CaptionAlignment="' + ltrim(rtrim(isnull(@caption_alignment_tmp, 'LEFT'))) + '" ' + 'CaptionPosition="' + ltrim(rtrim(isnull(@caption_position_tmp, 'LEFT'))) + '" ' + 'ControlPosition="' + ltrim(rtrim(isnull(@ctrl_position_tmp, 'LEFT'))) + '" ' + 'LabelClass="' + ltrim(rtrim(isnull(@label_class_tmp, ''))) + '" ' + 'ControlClass="' + ltrim(rtrim(isnull(@ctrl_class_tmp, ''))) + '" ' + 'PasswordChar="' + ltrim(rtrim(isnull(
										@password_char_tmp, 'N'))) + '" ' + 'TaskImageClass="' + ltrim(rtrim(isnull(@task_img_tmp, ''))) + '" ' + 'HelpImageClass="' + ltrim(rtrim(isnull(@help_img_tmp, ''))) + '" ' + 'Documentation="' + ltrim(rtrim(isnull(@controldoc_tmp, ''))) + '" ' 
+ 'OrderSequence="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@transformed_seqno_tmp, 0)))) + '" ' + 'VisibleRows="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@visible_rows_tmp, 0)))) + '" ' + 'HTMLTextArea="' + ltrim(rtrim(isnull(@html_text_area, 'N'))) + '" ' +
'SpinRequired="' + ltrim(rtrim(isnull(@spin_required, 'N'))) + '" ' + 'SpinUpImage="' + ltrim(rtrim(isnull(@spin_up_image, 'spinup.gif'))) + '" ' + 'SpinDownImage="' + ltrim(rtrim(isnull(@spin_down_image, 'spindown.gif'))) + '" ' + 'AssociatedSpinControl="' + ltrim(rtrim(isnull(@associated_spin_ctrl, ''))) + '" ' + 'AssociatedSpinTask="' + ltrim(rtrim(isnull(@associated_spin_task, ''))) + '" ' + 'HelpText="' + ltrim(rtrim(isnull(@helptext, ''))) + '" ' + 'ReportRequired="' + ltrim(rtrim(isnull(@report_reqd, ''))) + '" ' + 'ModelSectionName="' + ltrim(
								rtrim(isnull(@section_bt_synonym_tmp, ''))) + '" ' +
							-- Inplace Calendar and Edit Mask Feature added by Feroz -- Start
							'InPlaceCalendar="' + ltrim(rtrim(isnull(@InPlaceCalendar, 'n'))) + '" ' +
							-- Code modification for  PNR2.0_19426  starts
							'InCalDisplay="' + ltrim(rtrim(isnull(@InPlaceCal_Display, ''))) + '" ' + 'EditMask="' + ltrim(rtrim(isnull(@EditMaskPattern, ''))) + '" ' +
							-- Inplace Calendar and Edit Mask Feature added by Feroz  -- End
							--      'TabIndex="'   + ltrim(rtrim(isnull(@tab_seq,0)))                       + '" '  +
							'TabIndex="' + ltrim(rtrim(@tab_seq_tmp)) + '" ' + -- code added by gopinath S for the Bug ID PNR2.0_19995
							'AccessKey="' + ltrim(rtrim(isnull(@AccessKey, ''))) + '" ' + -- Added by Jeya For AccessKey
							-- Code modification for  PNR2.0_19426  ends
							-- Code addition for PNR2.0_21576 starts
							--Code modified by Balaji D for Bug ID PNR2.0_28889 on 01-Nov-2010 starts
							'GridLite="' + ltrim(rtrim(isnull(@gridlite, 'N'))) + '" ' +
							--Code modified by Balaji D for Bug ID PNR2.0_28889 on 01-Nov-2010 end
							-- Code addition for PNR2.0_21576 ends
							-- Code addition for PNR2.0_20849 starts
							'NoofLinesPerRow="' + ltrim(rtrim(isnull(@NoofLinesPerRow, ''))) + '" ' + 'RowHeight="' + ltrim(rtrim(isnull(@RowHeight, ''))) + '" ' +
							-- Added By Feroz
							'BulletLink="' + ltrim(rtrim(isnull(@bulletlink_req, 'N'))) + '" ' + 'ButtonCombo="' + ltrim(rtrim(isnull(@buttoncombo_req, 'N'))) + '" ' + 'DataAsCaption="' + ltrim(rtrim(isnull(@dataascaption, 'N'))) + '" ' + 'AssociatedList="' + ltrim(rtrim(isnull(@associatedlist_name, ''))) + '" ' + 'OnFocusTask="' + ltrim(rtrim(isnull(@onfocus_taskname, ''))) + '" ' + 'ListRefillTask="' + ltrim(rtrim(isnull(@listrefill_taskname, ''))) + '" ' + 'MappedListControlID="' + ltrim(rtrim(isnull(@mapped_list_controlid
, ''))) + '" ' + 'MappedListViewName="' + ltrim(rtrim(isnull(@mapped_list_viewname, ''))) + '" ' + 'AttachDocument="' + ltrim(rtrim(isnull(@attach_document, 'N'))) + '" ' + 'ImageUpload="' + ltrim(rtrim(isnull(@image_upload, 'N'))) + '" ' + 'InplaceImage=
"' + ltrim(rtrim(isnull(@inplace_image, 'N'))) + '" ' + 'ImageIcon="' + ltrim(rtrim(isnull(@image_icon, 'N'))) + '" ' + 
'ImageType="'   + ltrim(rtrim(isnull(@ImageType,'N')))             + '" ' +
'ImageRowHeight="' + ltrim(rtrim(isnull(@image_row_height, '0'))) + '" ' + 'RelativeUrlPath="' + ltrim(rtrim(isnull(@relative_url_path,
 ''))) + '" ' + 'RelativeDocumentPath="' + ltrim(rtrim(
									isnull(@relative_document_path, ''))) + '" ' + 'RelativeImagePath="' + ltrim(rtrim(isnull(@relative_image_path, ''))) + '" ' + 'SaveDocContentToDb="' + ltrim(rtrim(isnull(@save_doc_content_to_db, 'N'))) + '" ' + 'SaveImageContentToDb="' + ltrim(rtrim(isnull(@save_image_content_to_db, 'N'))) + '" ' + 'DateHighlight="' + ltrim(rtrim(isnull(@date_highlight_req, 'N'))) + '" ' + 'LinkedHiddenViewName="' + ltrim(rtrim(isnull(@hidden_view_name, ''))) + '" ' + 'Vscrollbar_Req="' + ltrim(rtrim(isnull(@Vscrollbar_Req, 'N'))) + '" LiteAttach="' + Isnull(@Lite_Attach, 'N') + '" Browse_Button="' + Isnull(@BrowseButton, 'N') + '" Delete_Button="' + Isnull(@DeleteButton, 'N') + '" ' + --PNR2.0_28365 -- Code Modified For BUGID PNR2.0_28537
							--code added for the caseid : PNR2.0_28319 starts
							'image_row_width="' + CONVERT(VARCHAR, isnull(@image_row_width, 0), 4) + '" ' + 'IsITK="N"  FC="' + CONVERT(VARCHAR, isnull(@freezecount, 0), 4) + '" ' + 'image_preview_height="' + CONVERT(VARCHAR, isnull(@image_preview_height, 0), 4) + '" ' + 'image_preview_width="' + CONVERT(VARCHAR, isnull(@image_preview_width, 0), 4) + '" ' + 'image_preview_req="' + isnull(@image_preview_req, 'N') + '" ' + 'Accept_Type="' + isnull(@Accept_Type, '') + '" ' + 'Lite_Attach_Image="' + isnull(@Lite_Attach_Image, 'N'
) + '" ' + 'LabelLink="' + isnull(@LabelLink, 'N') + '" ' + --added for PNR2.0_26860, PNR2.0_27796,PNR2.0_36309
							-- Code addition for PNR2.0_20849 ends
							--code added for the caseid : PNR2.0_28319 ends
							--Code Added for the Bug ID: PLF2.0_00961 starts
							--'PopUpPage="'           +   isnull(@popup_page,'')                  +'" ' +
							--'PopUpSection="'        +   isnull(@popup_section,'')               +'" ' +
							--'PopUpClose="'          +   isnull(@popup_Close,'N')                +'" ' +
							'CaptionType="' + isnull(@captiontype, '') + '" ' + 'ControlStyle="' + isnull(@controlstyle, '') + '" ' + 'ControlImage="' + isnull(@controlimage, '') + '" ' + 'IsListBox="' + isnull(@IsListBox, '') + '" ' + 'Toolbar_Not_Req="' + isnull(@Toolbar_Not_Req, '') + '" ' + 'ColumnBorder_Not_Req="' + isnull(@ColumnBorder_Not_Req, '') + '" ' + 'RowBorder_Not_Req="' + isnull(@RowBorder_Not_Req, '') + '" ' + 'PageNavigation_Only="' + isnull(@PagenavigationOnly, '') + '" ' + 'RowNo_Not_Req="' + isnull(@RowNo_Not_Req, '') + '" ' + 'ExtType="' + isnull(@ExtType, '') + '" ' + 'ColSpan="' + CONVERT(VARCHAR, isnull(@ControlColSpan, ''), 4) + '" ' + 'RowSpan="' + CONVERT(VARCHAR, isnull(@ControlRowSpan, ''), 4) + '" ' + 'Tooltip_Not_Req="' + CONVERT(VARCHAR, isnull(@Tooltip_Not_Req, ''), 4) + '" ' + 'GridHeader_Not_Req="' + CONVERT(VARCHAR, isnull(@columncaption_Not_Req, ''), 4) + '" ' + 'Border_Not_Req="' + CONVERT(VARCHAR, isnull(@Border_Not_Req, ''), 4) + '" ' + 'IsModal="' + CONVERT(VARCHAR, isnull(@IsModal, ''), 4) + '" ' + 'Alternate_Color_Req="' + CONVERT(VARCHAR, isnull(@Alternate_Color_Req
									, ''), 4) + '" ' + 'Map_In_Req="' + CONVERT(VARCHAR, isnull(@Map_In_Req, ''), 4) + '" ' + 'Map_Out_Req="' + CONVERT(VARCHAR, isnull(@Map_Out_Req, ''), 4) + '" ' + 'IsCallout="' + isnull(@iscallout, '') + '" ' + 'SmartViewSection="' + isnull(@smartviewsection, '') + '" ' + 'SetScrollPosition="' + isnull(@preserveposition, '') + '" ' + -- added for Defect ID: TECH-18349
						'IsPivot="' + isnull(@ispivot, 'N') + '" ' + 'TemplateCategory="' + isnull(@TemplateCat, '') + '" ' + 'TemplateSpecification="' + isnull(@TemplateSpecific, '') + '" ' + 'FileSize="' + isnull(@filesize, '') + '" />',
							@xml_seq_tmp
							)
							--Code Added for the Bug ID:PLF2.0_00961 ends
					END
					ELSE
					BEGIN
						SELECT @proto_tooltip_tmp = replace(@proto_tooltip_tmp, '&', '&amp;')  
  
						SELECT @proto_tooltip_tmp = replace(@proto_tooltip_tmp, '<', '&lt;')  
  
						SELECT @proto_tooltip_tmp = replace(@proto_tooltip_tmp, '>', '&gt;')  
  
						SELECT @proto_tooltip_tmp = replace(@proto_tooltip_tmp, '"', '&quot;')  --TECH-68512 ends 
						-- code added for bugid : PNR2.0_17974  ends     --
						INSERT INTO ep_genxml_tmp (
							customer_name,
							project_name,
							req_no,
							process_name,
							component_name,
							activity_name,
							guid,
							gen_xml,
							seq_no
							)
						VALUES (
							@engg_customer_name,
							@engg_project_name,
							@engg_req_no,
							@process_name,
							@engg_component,
							@activity_name,
							@guid,
							'<Control Name="' + ltrim(rtrim(isnull(@controlid_tmp, ''))) + '" ' + 'RenderAs="' + ltrim(rtrim(isnull(@renderas, ''))) + '" ' + 'ControlCaption="' + ltrim(rtrim(isnull(@ctrl_descr_tmp, ''))) + '" ' + 'SectionName="' + ltrim(rtrim(isnull(@section_bt_synonym_tmp, ''))) + '" ' + 'PageName="' + ltrim(rtrim(isnull(@page_bt_synonym_tmp, ''))) + '" ' + 'ILBOName="' + ltrim(rtrim(isnull(@ui_name_tmp, ''))) + '" ' + 'ActivityName="' + ltrim(rtrim(isnull(@activity_name, ''))) + '" ' + 'ComponentName="' + ltrim(rtrim(isnull(@engg_component, ''))) + '" ' + 'ControlType="' + ltrim(rtrim(isnull(upper(@control_type_tmp), ''))) + '" ' + 'BaseControlType="' + ltrim(rtrim(isnull(upper(@base_ctrl_type_tmp), ''))) + '" ' + -- Code modification  for  PNR2.0_23635
							--       'DataType="'   + ltrim(rtrim(isnull(@datatype_tmp,'')))         + '" ' +
							--       'DataLength="'   + ltrim(rtrim(isnull(@datalength_tmp,'')))         + '" ' +
							--       'DecimalLength="'  + isnull(convert(varchar, @decimal_length_ctrl),'')       + '" ' +
							-- code modified by Anuradha on 22-Mar-2006 for the Bug id :: PNR2.0_7393
							'DataType="' + CASE ltrim(rtrim(isnull(@base_ctrl_type_tmp, ''))) + '-' + ltrim(rtrim(isnull(@datatype_tmp, '')))
								WHEN 'COMBO-INTEGER'
									THEN ''
								ELSE ltrim(rtrim(isnull(@datatype_tmp, '')))
								END + '" ' + 'DataLength="' + CASE ltrim(rtrim(isnull(@base_ctrl_type_tmp, ''))) + '-' + ltrim(rtrim(isnull(@datatype_tmp, '')))
								WHEN 'COMBO-INTEGER'
									THEN ''
								ELSE ltrim(rtrim(isnull(@datalength_tmp, '')))
								END + '" ' + 'DecimalLength="' + CASE ltrim(rtrim(isnull(@base_ctrl_type_tmp, ''))) + '-' + ltrim(rtrim(isnull(@datatype_tmp, '')))
								WHEN 'COMBO-INTEGER'
									THEN ''
								ELSE isnull(convert(VARCHAR, @decimal_length_ctrl), '')
								END + '" ' +
							-- code modified by Anuradha on 22-Mar-2006 for the Bug id :: PNR2.0_7393
							'BTSynonym="' + ltrim(rtrim(isnull(@control_bt_synonym_tmp, ''))) + '" ' + 'VisibleLength="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@visible_length_tmp, 0)))) + '" ' + 'ProtoTooltip="' + ltrim(rtrim(isnull(@proto_tooltip_tmp, ''))) + '" ' + 'SampleData="' + ltrim(rtrim(isnull(@sample_data_tmp, ''))) + '" ' + 'DefaultSampleData="' + ltrim(rtrim(isnull(@default_sample_data_tmp, ''))) + '" ' + 'HOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, isnull(@transformed_horder_tmp, 0)), 3))) + '" ' + 'VOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, isnull(@transformed_vorder_tmp, 0)), 3))) + '" ' + 'Mandatory="' + ltrim(rtrim(isnull(@mandatory_flag_tmp, ''))) + '" ' + 'Visible="' + ltrim(rtrim(isnull(@visible_flag_tmp, ''))) + '" ' + 'Editable="' + ltrim(rtrim(isnull(@editable_flag_tmp, ''))) + '" ' + 'CaptionRequired="' + ltrim(rtrim(isnull(@caption_req_tmp, ''))) + '" ' + 'SelectFlag="' + ltrim(rtrim(isnull(@select_flag_tmp, ''))) + '" ' + 'DeleteFlag="' + ltrim(rtrim(isnull(@delete_flag_tmp, 
''))) + '" ' + 'ZoomRequired="' + ltrim(rtrim(isnull(
										@zoom_req_tmp, ''))) + '" ' + 'HelpRequired="' + ltrim(rtrim(isnull(@help_req_tmp, ''))) + '" ' + 'EllipsesRequired="' + ltrim(rtrim(isnull(@ellipses_req_tmp, ''))) + '" ' + 'AssociatedTask="' + ltrim(rtrim(isnull(@uitaskname_tmp, ''))) + '" ' +
 'DataColumnWidth="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@data_column_width_tmp, 0)))) + '" ' + 'LabelColumnWidth="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@label_column_width_tmp, 0)))) + '" ' + 'DataColumnScaleMode="' + ltrim(rtrim(isnull(@data_column_scalemode, '%'))) + '" ' + 'LabelColumnScaleMode="' + ltrim(rtrim(isnull(@label_column_scalemode, '%'))) + '" ' + 'CaptionWrap="' + ltrim(rtrim(isnull(@caption_wrap_tmp, 'Y'))) + '" ' + 'CaptionAlignment="' + ltrim(rtrim(isnull(@caption_alignment_tmp, 'LEFT'))) + '" ' + 'CaptionPosition="' + ltrim(rtrim(isnull(@caption_position_tmp, 'LEFT'))) + '" ' + 'ControlPosition="' + ltrim(rtrim(isnull(@ctrl_position_tmp, 'LEFT'))) + '" ' + 'LabelClass="' + ltrim(rtrim(isnull(@label_class_tmp, ''))) + '" ' + 'ControlClass="' + ltrim(rtrim(isnull(
										@ctrl_class_tmp, ''))) + '" ' + 'PasswordChar="' + ltrim(rtrim(isnull(@password_char_tmp, 'N'))) + '" ' + 'TaskImageClass="' + ltrim(rtrim(isnull(@task_img_tmp, ''))) + '" ' + 'HelpImageClass="' + ltrim(rtrim(isnull(@help_img_tmp, ''))) + '" ' +
 'Documentation="' + ltrim(rtrim(isnull(@controldoc_tmp, ''))) + '" ' +
							-- code added for bugid : PNR2.0_17974  starts     --
							'OrderSequence="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@transformed_seqno_tmp, 0)))) + '" ' +
							--      'OrderSequence="'  + ltrim(rtrim(CONVERT(VARCHAR,isnull(@order_seq_tmp,0))))     + '" ' +
							-- code added for bugid : PNR2.0_17974  ends     --
							'VisibleRows="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@visible_rows_tmp, 0)))) + '" ' + 'HTMLTextArea="' + ltrim(rtrim(isnull(@html_text_area, 'N'))) + '" ' + 'SpinRequired="' + ltrim(rtrim(isnull(@spin_required, 'N'))) + '" ' + 'SpinUpImage="' + ltrim(rtrim(isnull(@spin_up_image, 'spinup.gif'))) + '" ' + 'SpinDownImage="' + ltrim(rtrim(isnull(@spin_down_image, 'spindown.gif'))) + '" ' + 'AssociatedSpinControl="' + ltrim(rtrim(isnull(@associated_spin_ctrl, ''))) + '" ' + 'AssociatedSpinTask="' + ltrim(rtrim(isnull(@associated_spin_task, ''))) + '" ' + 'HelpText="' + ltrim(rtrim(isnull(@helptext, ''))) + '" ' +
							--code modified for bugId : PNR2.0_10741
							'ReportRequired="' + ltrim(rtrim(isnull(@report_reqd, ''))) + '" ' + 'ModelSectionName="' + ltrim(rtrim(isnull(@section_bt_synonym_tmp, ''))) + '" ' +
							-- Inplace Calendar and Edit Mask Feature added by Feroz -- Start
							'InPlaceCalendar="' + ltrim(rtrim(isnull(@InPlaceCalendar, 'n'))) + '" ' +
							-- Code modification for  PNR2.0_19426  starts
							'InCalDisplay="' + ltrim(rtrim(isnull(@InPlaceCal_Display, ''))) + '" ' + 'EditMask="' + ltrim(rtrim(isnull(@EditMaskPattern, ''))) + '" ' +
							-- Inplace Calendar and Edit Mask Feature added by Feroz -- End
							'TabIndex="' + ltrim(rtrim(@tab_seq)) + '" ' + 'AccessKey="' + ltrim(rtrim(isnull(@AccessKey, ''))) + '" ' + -- Added by Jeya For AccessKey
							-- Code modification for  PNR2.0_19426  ends
							-- Code addition for PNR2.0_21576 starts
							--Code modified by Balaji D for Bug ID PNR2.0_28889 on 01-Nov-2010 starts
							'GridLite="' + ltrim(rtrim(isnull(@gridlite, 'N'))) + '" ' +
							--Code modified by Balaji D for Bug ID PNR2.0_28889 on 01-Nov-2010 end
							-- Code addition for PNR2.0_21576 ends
							-- Code addition for PNR2.0_20849 starts
							'NoofLinesPerRow="' + ltrim(rtrim(isnull(@NoofLinesPerRow, ''))) + '" ' + 'RowHeight="' + ltrim(rtrim(isnull(@RowHeight, ''))) + '" ' +
							-- Added By Feroz
							'BulletLink="' + ltrim(rtrim(isnull(@bulletlink_req, 'N'))) + '" ' + 'ButtonCombo="' + ltrim(rtrim(isnull(@buttoncombo_req, 'N'))) + '" ' + 'DataAsCaption="' + ltrim(rtrim(isnull(@dataascaption, 'N'))) + '" ' + 'AssociatedList="' + ltrim(rtrim(isnull(@associatedlist_name, ''))) + '" ' + 'OnFocusTask="' + ltrim(rtrim(isnull(@onfocus_taskname, ''))) + '" ' + 'ListRefillTask="' + ltrim(rtrim(isnull(@listrefill_taskname, ''))) + '" ' + 'MappedListControlID="' + ltrim(rtrim(isnull(@mapped_list_controlid
, ''))) + '" ' + 'MappedListViewName="' + ltrim(rtrim(isnull(@mapped_list_viewname, ''))) + '" ' + 'AttachDocument="' + ltrim(rtrim(isnull(@attach_document, 'N'))) + '" ' + 'ImageUpload="' + ltrim(rtrim(isnull(@image_upload, 'N'))) + '" ' + 'InplaceImage=
"' + ltrim(rtrim(isnull(@inplace_image, 'N'))) + '" ' + 'ImageIcon="' + ltrim(rtrim(isnull(@image_icon, 'N'))) + '" ' + 
'ImageType="'   + ltrim(rtrim(isnull(@ImageType,'N')))             + '" ' +
'ImageRowHeight="' + ltrim(rtrim(isnull(@image_row_height, '0'))) + '" ' + 'RelativeUrlPath="' + ltrim(rtrim(isnull(@relative_url_path,
 ''))) + '" ' + 'RelativeDocumentPath="' + ltrim(rtrim(
									isnull(@relative_document_path, ''))) + '" ' + 'RelativeImagePath="' + ltrim(rtrim(isnull(@relative_image_path, ''))) + '" ' + 'SaveDocContentToDb="' + ltrim(rtrim(isnull(@save_doc_content_to_db, 'N'))) + '" ' + 'SaveImageContentToDb="' + ltrim(rtrim(isnull(@save_image_content_to_db, 'N'))) + '" ' + 'DateHighlight="' + ltrim(rtrim(isnull(@date_highlight_req, 'N'))) + '" ' + 'LinkedHiddenViewName="' + ltrim(rtrim(isnull(@hidden_view_name, ''))) + '" ' + 'Vscrollbar_Req="' + ltrim(rtrim(isnull(@Vscrollbar_Req, 'N'))) + '" LiteAttach="' + Isnull(@Lite_Attach, 'N') + '" Browse_Button="' + Isnull(@BrowseButton, 'N') + '" Delete_Button="' + Isnull(@DeleteButton, 'N') + '" ' + --PNR2.0_28365 -- Code Modified For BUGID PNR2.0_28537
							'IsITK="N"  FC="' + CONVERT(VARCHAR, isnull(@freezecount, 0), 4) + '" ' +
							--code added for the caseid : PNR2.0_28319 starts
							'image_row_width="' + CONVERT(VARCHAR, isnull(@image_row_width, 0), 4) + '" ' + 'image_preview_height="' + CONVERT(VARCHAR, isnull(@image_preview_height, 0), 4) + '" ' + 'image_preview_width="' + CONVERT(VARCHAR, isnull(@image_preview_width, 0), 4)
 + '" ' + 'image_preview_req="' + isnull(@image_preview_req, 'N') + '" ' + 'Accept_Type="' + isnull(@Accept_Type, '') + '" ' + 'Lite_Attach_Image="' + isnull(@Lite_Attach_Image, 'N') + '" ' + 'LabelLink="' + isnull(@LabelLink, 'N') + '" ' + --added for PNR2.0_26860, PNR2.0_27796,PNR2.0_36309
							-- Code addition for PNR2.0_20849 ends
							--code added for the caseid : PNR2.0_28319 ends
							--Code Added for the Bug ID: PLF2.0_00961 starts
							--'PopUpPage="'           +   isnull(@popup_page,'')                  +'" ' +
							--'PopUpSection="'        +   isnull(@popup_section,'')               +'" ' +
							--'PopUpClose="'          +   isnull(@popup_Close,'N')                +'" ' +
							'CaptionType="' + isnull(@captiontype, '') + '" ' + 'ControlStyle="' + isnull(@controlstyle, '') + '" ' + 'ControlImage="' + isnull(@controlimage, '') + '" ' + 'IsListBox="' + isnull(@IsListBox, '') + '" ' + 'Toolbar_Not_Req="' + isnull(@Toolbar_Not_Req, '') + '" ' + 'ColumnBorder_Not_Req="' + isnull(@ColumnBorder_Not_Req, '') + '" ' + 'RowBorder_Not_Req="' + isnull(@RowBorder_Not_Req, '') + '" ' + 'PageNavigation_Only="' + isnull(@PagenavigationOnly, '') + '" ' + 'RowNo_Not_Req="' + isnull(@RowNo_Not_Req, '') + '" ' +
							--'ExtType="'         +   isnull(@ExtType,'')  +'" ' +
							'ColSpan="' + CONVERT(VARCHAR, isnull(@ControlColSpan, ''), 4) + '" ' + 'RowSpan="' + CONVERT(VARCHAR, isnull(@ControlRowSpan, ''), 4) + '" ' + 'Tooltip_Not_Req="' + CONVERT(VARCHAR, isnull(@Tooltip_Not_Req, ''), 4) + '" ' + 'GridHeader_Not_Req="' 
+ CONVERT(VARCHAR, isnull(@columncaption_Not_Req, ''), 4) + '" ' + 'Border_Not_Req="' + CONVERT(VARCHAR, isnull(@Border_Not_Req, ''), 4) + '" ' + 'IsModal="' + CONVERT(VARCHAR, isnull(@IsModal, ''), 4) + '" ' + 'Alternate_Color_Req="' + CONVERT(VARCHAR, isnull(@Alternate_Color_Req, ''), 4) + '" ' + 'Map_In_Req="' + CONVERT(VARCHAR, isnull(@Map_In_Req, ''), 4) + '" ' + 'Map_Out_Req="' + CONVERT(VARCHAR, isnull(@Map_Out_Req, ''), 4) + '" ' + 'IsCallout="' + isnull(@iscallout, '') + '" ' + 'SmartViewSection=
"' + isnull(@smartviewsection, '') + '" ' + 'AutoSelect="' + isnull(@autoselect, '') + '" ' + 'SetScrollPosition="' + isnull(@preserveposition, '') + '" ' + -- added for Defect ID: TECH-18349
							'FileSize="' + isnull(@filesize, '') + '" ' + 'IsDeviceInfo="' + isnull(@iSDeviceInfo, 'N') + '" ' + 'DataGrid="' + isnull(@Datagrid, 'N') + '" ' + 'Email="' + isnull(@email, 'N') + '" ' + 'TemplateID="' + isnull(@TemplateID, '') + '" ' + 'Phone="'
 + isnull(@Phone, 'N') + '" ' + 'ListControl="' + isnull(@listcontrol, 'N') + '" ' + 'ColHdrAlign="' + isnull(@ctrl_col_caption_align, '') + '" ' + 'Gridheaderstyle="' + isnull(@Gridheaderstyle, '') + '" ' + 'Gridtoolbarstyle="' + isnull(@Gridtoolbarstyle
, '') + '" ' + 'preevent="' + isnull(@preevent, '') + '" ' + 'postevent="' + isnull(@postevent, '') + '" ' + 'ishijri="' + isnull(@ishijri, 'N') + '" ' + 'IsPivot="' + isnull(@ispivot, 'N') + '" ' + 'TemplateCategory="' + isnull(@TemplateCat, '') + '" ' +
 'TemplateSpecification="' + isnull(@TemplateSpecific, '') + '" ' + 
				'SetFocusEvent="'	+ isnull(@setfocusevent,'')	 +'" ' + -- Added for TECH-37471 
				'LeaveFocusEvent="'	+ isnull(@leavefocusevent,'')	 +'" ' + -- Added for TECH-37471 
				'SetFocusEventOccurence="'	+ isnull(@setfocuseventoccur,'')	 +'" ' +  
				'LeaveFocusEventOccurence="'	+ isnull(@leavefocuseventoccur,'')	 +'" ' +  
				'MoreEvent="'	+ isnull(@MoreEventName,'')	 +'" ' + --TECH-45828
				'UPEEnabled="'	+ isnull(@UPEEnabled,'N')	 +'" ' + 
				'RatingType="' + ltrim(rtrim(isnull(lower(@RatingType), ''))) + '" ' + 'CaptchaData="' + ltrim(rtrim(isnull(lower(@CaptchaData), ''))) + '" ' + 'ControlClassExt6="' + isnull(lower(@Control_cls_ext6), '') + '" ' + 'IconClass="' + isnull(@Icon_Class, '') + '" ' + 'StaticCaption="' + 
							isnull(@StaticCaption, 'N') + '" />',
							@xml_seq_tmp
							)
							--Code Added for the Bug ID:PLF2.0_00961 ends
							-- code added for bugid : PNR2.0_17974  starts     --
					END
							-- code added for bugid : PNR2.0_17974  ends     --
				END

				-- Insert Duplicate Filler Control
				--if @control_type_tmp in ('Filler2','Filler') and @filler_seq_no = 1
				IF @control_type_tmp IN ('Filler2')
					AND @filler_seq_no = 1
				BEGIN
					IF @ui_format_tmp = 'BES'
					BEGIN
						SELECT @position_vindex_tmp = @position_vindex_tmp + 1

						SELECT @transformed_horder_tmp = @horder_tmp

						SELECT @transformed_vorder_tmp = @vorder_tmp + @position_vindex_tmp
					END
					ELSE IF @ui_format_tmp = 'UND' ---added by kanagavel for filler UND caption handling
					BEGIN
						SELECT @transformed_horder_tmp = @horder_tmp * 2

						SELECT @transformed_vorder_tmp = @vorder_tmp
					END

					IF @ui_format_tmp = 'BES'
					BEGIN
						SELECT @helptext = @ctrl_descr_tmp + ' - Datatype : ' + ltrim(rtrim(isnull(@datatype_tmp, ''))) + ' - MaxLength : ' + ltrim(rtrim(isnull(@datalength_tmp, '')))

						IF upper(isnull(@datatype_tmp, '')) = 'NUMERIC'
							SELECT @helptext = @helptext + ' - DecimalLength : ' + ltrim(rtrim(isnull(@datalength_tmp, '')))

						INSERT INTO ep_genxml_tmp (
							customer_name,
							project_name,
							req_no,
							process_name,
							component_name,
							activity_name,
							guid,
							gen_xml,
							seq_no
							)
						VALUES (
							@engg_customer_name,
							@engg_project_name,
							@engg_req_no,
							@process_name,
							@engg_component,
							@activity_name,
							@guid,
							'<Control Name="' + ltrim(rtrim(isnull(@controlid_tmp, ''))) + '" ' + 'RenderAs="' + ltrim(rtrim(isnull(@renderas, ''))) + '" ' + 'ControlCaption="' + ltrim(rtrim(isnull(@ctrl_descr_tmp, ''))) + '" ' + 'SectionName="' + ltrim(rtrim(isnull(@section_bt_synonym_tmp, ''))) + '" ' + 'PageName="' + ltrim(rtrim(isnull(@page_bt_synonym_tmp, ''))) + '" ' + 'ILBOName="' + ltrim(rtrim(isnull(@ui_name_tmp, ''))) + '" ' + 'ActivityName="' + ltrim(rtrim(isnull(@activity_name, ''))) + '" ' + 'ComponentName="' + ltrim(rtrim(isnull(@engg_component, ''))) + '" ' + 'ControlType="' + ltrim(rtrim(isnull(upper(@control_type_tmp), ''))) + '" ' + 'BaseControlType="' + ltrim(rtrim(isnull(upper(@base_ctrl_type_tmp), ''))) + '" ' + -- Code modification  for  PNR2.0_23635
							--        'DataType="'   + ltrim(rtrim(isnull(@datatype_tmp,'')))         + '" ' +
							--        'DataLength="'   + ltrim(rtrim(isnull(@datalength_tmp,'')))         + '" ' +
							--        'DecimalLength="'  + isnull(convert(varchar, @decimal_length_ctrl),'')       + '" ' +
							-- code modified by Anuradha on 22-Mar-2006 for the Bug id :: PNR2.0_7393
							'DataType="' + CASE ltrim(rtrim(isnull(@base_ctrl_type_tmp, ''))) + '-' + ltrim(rtrim(isnull(@datatype_tmp, '')))
								WHEN 'COMBO-INTEGER'
									THEN ''
								ELSE ltrim(rtrim(isnull(@datatype_tmp, '')))
								END + '" ' + 'DataLength="' + CASE ltrim(rtrim(isnull(@base_ctrl_type_tmp, ''))) + '-' + ltrim(rtrim(isnull(@datatype_tmp, '')))
								WHEN 'COMBO-INTEGER'
									THEN ''
								ELSE ltrim(rtrim(isnull(@datalength_tmp, '')))
								END + '" ' + 'DecimalLength="' + CASE ltrim(rtrim(isnull(@base_ctrl_type_tmp, ''))) + '-' + ltrim(rtrim(isnull(@datatype_tmp, '')))
								WHEN 'COMBO-INTEGER'
									THEN ''
								ELSE isnull(convert(VARCHAR, @decimal_length_ctrl), '')
								END + '" ' +
							-- code modified by Anuradha on 22-Mar-2006 for the Bug id :: PNR2.0_7393
							'BTSynonym="' + ltrim(rtrim(isnull(@control_bt_synonym_tmp, ''))) + '" ' + 'VisibleLength="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@visible_length_tmp, 0)))) + '" ' + 'ProtoTooltip="' + ltrim(rtrim(isnull(@proto_tooltip_tmp, ''))) + '" ' + 'SampleData="' + ltrim(rtrim(isnull(@sample_data_tmp, ''))) + '" ' + 'DefaultSampleData="' + ltrim(rtrim(isnull(@default_sample_data_tmp, ''))) + '" ' + 'HOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, isnull(@transformed_horder_tmp, 0)), 3))) + '" ' + 'VOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, isnull(@transformed_vorder_tmp, 0)), 3))) + '" ' + 'Mandatory="' + ltrim(rtrim(isnull(@mandatory_flag_tmp, ''))) + '" ' + 'Visible="' + ltrim(rtrim(isnull(@visible_flag_tmp, ''))) + '" ' + 'Editable="' + ltrim(rtrim(isnull(@editable_flag_tmp, ''))) + '" ' + 'CaptionRequired="' + ltrim(rtrim(isnull(@caption_req_tmp, ''))) + '" ' + 'SelectFlag="' + ltrim(rtrim(isnull(@select_flag_tmp, ''))) + '" ' + 'DeleteFlag="' + ltrim(rtrim(isnull(@delete_flag_tmp, 
''))) + '" ' + 'ZoomRequired="' + ltrim(rtrim(isnull(
										@zoom_req_tmp, ''))) + '" ' + 'HelpRequired="' + ltrim(rtrim(isnull(@help_req_tmp, ''))) + '" ' + 'EllipsesRequired="' + ltrim(rtrim(isnull(@ellipses_req_tmp, ''))) + '" ' + 'AssociatedTask="' + ltrim(rtrim(isnull(@uitaskname_tmp, ''))) + '" ' +
'DataColumnWidth="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@data_column_width_tmp, 0)))) + '" ' + 'LabelColumnWidth="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@label_column_width_tmp, 0)))) + '" ' + 'DataColumnScaleMode="' + ltrim(rtrim(isnull(@data_column_scalemode, '%'))) + '" ' + 'LabelColumnScaleMode="' + ltrim(rtrim(isnull(@label_column_scalemode, '%'))) + '" ' + 'CaptionWrap="' + ltrim(rtrim(isnull(@caption_wrap_tmp, 'Y'))) + '" ' + 'CaptionAlignment="' + ltrim(rtrim(isnull(@caption_alignment_tmp, 'LEFT'))) + '" ' + 'CaptionPosition="' + ltrim(rtrim(isnull(@caption_position_tmp, 'LEFT'))) + '" ' + 'ControlPosition="' + ltrim(rtrim(isnull(@ctrl_position_tmp, 'LEFT'))) + '" ' + 'LabelClass="' + ltrim(rtrim(isnull(@label_class_tmp, ''))) + '" ' + 'ControlClass="' + ltrim(rtrim(isnull(
										@ctrl_class_tmp, ''))) + '" ' + 'PasswordChar="' + ltrim(rtrim(isnull(@password_char_tmp, 'N'))) + '" ' + 'TaskImageClass="' + ltrim(rtrim(isnull(@task_img_tmp, ''))) + '" ' + 'HelpImageClass="' + ltrim(rtrim(isnull(@help_img_tmp, ''))) + '" ' +
 'Documentation="' + ltrim(rtrim(isnull(@controldoc_tmp, ''))) + '" ' + 'OrderSequence="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@order_seq_tmp, 0)))) + '" ' + 'VisibleRows="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@visible_rows_tmp, 0)))) + '" ' + 'HTMLTextArea="' + ltrim(rtrim(isnull(@html_text_area, 'N'))) + '" ' + 'SpinRequired="' + ltrim(rtrim(isnull(@spin_required, 'N'))) + '" ' + 'SpinUpImage="' + ltrim(rtrim(isnull(@spin_up_image, 'spinup.gif'))) + '" ' + 'SpinDownImage="' + ltrim(rtrim(isnull(@spin_down_image, 'spindown.gif'))) + '" ' + 'AssociatedSpinControl="' + ltrim(rtrim(isnull(@associated_spin_ctrl, ''))) + '" ' + 'AssociatedSpinTask="' + ltrim(rtrim(isnull(@associated_spin_task, ''))) + '" ' + 'HelpText="' + ltrim(rtrim(isnull(@helptext, '')
)) + '" ' + 'ModelSectionName="' + ltrim(rtrim(
									isnull(@section_bt_synonym_tmp, ''))) + '" ' +
							-- Inplace Calendar and Edit Mask Feature added by Feroz -- Start
							'InPlaceCalendar="' + ltrim(rtrim(isnull(@InPlaceCalendar, 'n'))) + '" ' +
							-- Code modification for  PNR2.0_19426  starts
							'InCalDisplay="' + ltrim(rtrim(isnull(@InPlaceCal_Display, ''))) + '" ' + 'EditMask="' + ltrim(rtrim(isnull(@EditMaskPattern, ''))) + '" ' +
							-- Inplace Calendar and Edit Mask Feature added by Feroz -- End
							'TabIndex="' + ltrim(rtrim(@tab_seq)) + '" ' + 'AccessKey="' + ltrim(rtrim(isnull(@AccessKey, ''))) + '" ' + -- Added by Jeya For AccessKey
							-- Code modification for  PNR2.0_19426  ends
							-- Code addition for PNR2.0_21576 starts
							--Code modified by Balaji D for Bug ID PNR2.0_28889 on 01-Nov-2010 starts
							'GridLite="' + ltrim(rtrim(isnull(@gridlite, 'N'))) + '" ' +
							--Code modified by Balaji D for Bug ID PNR2.0_28889 on 01-Nov-2010 end
							-- Code addition for PNR2.0_21576 ends
							-- Code addition for PNR2.0_20849 starts
							'NoofLinesPerRow="' + ltrim(rtrim(isnull(@NoofLinesPerRow, ''))) + '" ' + 'RowHeight="' + ltrim(rtrim(isnull(@RowHeight, ''))) + '" ' +
							-- Added By Feroz
							'BulletLink="' + ltrim(rtrim(isnull(@bulletlink_req, 'N'))) + '" ' + 'ButtonCombo="' + ltrim(rtrim(isnull(@buttoncombo_req, 'N'))) + '" ' + 'DataAsCaption="' + ltrim(rtrim(isnull(@dataascaption, 'N'))) + '" ' + 'AssociatedList="' + ltrim(rtrim(isnull(@associatedlist_name, ''))) + '" ' + 'OnFocusTask="' + ltrim(rtrim(isnull(@onfocus_taskname, ''))) + '" ' + 'ListRefillTask="' + ltrim(rtrim(isnull(@listrefill_taskname, ''))) + '" ' + 'MappedListControlID="' + ltrim(rtrim(isnull(@mapped_list_controlid
, ''))) + '" ' + 'MappedListViewName="' + ltrim(rtrim(isnull(@mapped_list_viewname, ''))) + '" ' + 'AttachDocument="' + ltrim(rtrim(isnull(@attach_document, 'N'))) + '" ' + 'ImageUpload="' + ltrim(rtrim(isnull(@image_upload, 'N'))) + '" ' + 'InplaceImage=
"' + ltrim(rtrim(isnull(@inplace_image, 'N'))) + '" ' + 'ImageIcon="' + ltrim(rtrim(isnull(@image_icon, 'N'))) + '" ' + 
'ImageType="'   + ltrim(rtrim(isnull(@ImageType,'N')))             + '" ' +
'ImageRowHeight="' + ltrim(rtrim(isnull(@image_row_height, '0'))) + '" ' + 'RelativeUrlPath="' + ltrim(rtrim(isnull(@relative_url_path,
 ''))) + '" ' + 'RelativeDocumentPath="' + ltrim(rtrim(
									isnull(@relative_document_path, ''))) + '" ' + 'RelativeImagePath="' + ltrim(rtrim(isnull(@relative_image_path, ''))) + '" ' + 'SaveDocContentToDb="' + ltrim(rtrim(isnull(@save_doc_content_to_db, 'N'))) + '" ' + 'SaveImageContentToDb="' + ltrim(rtrim(isnull(@save_image_content_to_db, 'N'))) + '" ' + 'DateHighlight="' + ltrim(rtrim(isnull(@date_highlight_req, 'N'))) + '" ' + 'LinkedHiddenViewName="' + ltrim(rtrim(isnull(@hidden_view_name, ''))) + '" ' + 'Vscrollbar_Req="' + ltrim(rtrim(isnull(@Vscrollbar_Req, 'N'))) + '" LiteAttach="' + Isnull(@Lite_Attach, 'N') + '" Browse_Button="' + Isnull(@BrowseButton, 'N') + '" Delete_Button="' + Isnull(@DeleteButton, 'N') + '" ' + --PNR2.0_28365 -- Code Modified For BUGID PNR2.0_28537
							--code added for the caseid : PNR2.0_28319 starts
							'image_row_width="' + CONVERT(VARCHAR, isnull(@image_row_width, 0), 4) + '" ' + 'IsITK="N"  FC="' + CONVERT(VARCHAR, isnull(@freezecount, 0), 4) + '" ' + 'image_preview_height="' + CONVERT(VARCHAR, isnull(@image_preview_height, 0), 4) + '" ' + 'image_preview_width="' + CONVERT(VARCHAR, isnull(@image_preview_width, 0), 4) + '" ' + 'image_preview_req="' + isnull(@image_preview_req, 'N') + '" ' + 'Accept_Type="' + isnull(@Accept_Type, '') + '" ' + 'Lite_Attach_Image="' + isnull(@Lite_Attach_Image, 'N'
) + '" ' + 'LabelLink="' + isnull(@LabelLink, 'N') + '" ' + --added for PNR2.0_26860, PNR2.0_27796,PNR2.0_36309
							-- Code addition for PNR2.0_20849 ends
							--code added for the caseid : PNR2.0_28319 ends
							--Code Added for the Bug ID: PLF2.0_00961 starts
							--'PopUpPage="'           +   isnull(@popup_page,'')                  +'" ' +
							--'PopUpSection="'        +   isnull(@popup_section,'')               +'" ' +
							--'PopUpClose="'          +   isnull(@popup_Close,'N')                +'" ' +
							'CaptionType="' + isnull(@captiontype, '') + '" ' + 'ControlStyle="' + isnull(@controlstyle, '') + '" ' + 'ControlImage="' + isnull(@controlimage, '') + '" ' + 'IsListBox="' + isnull(@IsListBox, '') + '" ' + 'Toolbar_Not_Req="' + isnull(@Toolbar_Not_Req, '') + '" ' + 'ColumnBorder_Not_Req="' + isnull(@ColumnBorder_Not_Req, '') + '" ' + 'RowBorder_Not_Req="' + isnull(@RowBorder_Not_Req, '') + '" ' + 'PageNavigation_Only="' + isnull(@PagenavigationOnly, '') + '" ' + 'RowNo_Not_Req="' + isnull(@RowNo_Not_Req, '') + '" ' + 'ExtType="' + isnull(@ExtType, '') + '" ' + 'ColSpan="' + CONVERT(VARCHAR, isnull(@ControlColSpan, ''), 4) + '" ' + 'RowSpan="' + CONVERT(VARCHAR, isnull(@ControlRowSpan, ''), 4) + '" ' + 'Tooltip_Not_Req="' + CONVERT(VARCHAR, isnull(@Tooltip_Not_Req, ''), 4) + '" ' + 'GridHeader_Not_Req="' + CONVERT(VARCHAR, isnull(@columncaption_Not_Req, ''), 4) + '" ' + 'Border_Not_Req="' + CONVERT(VARCHAR, isnull(@Border_Not_Req, ''), 4) + '" ' + 'IsModal="' + CONVERT(VARCHAR, isnull(@IsModal, ''), 4) + '" ' + 'Alternate_Color_Req="' + CONVERT(VARCHAR, isnull(@Alternate_Color_Req
									, ''), 4) + '" ' + 'Map_In_Req="' + CONVERT(VARCHAR, isnull(@Map_In_Req, ''), 4) + '" ' + 'Map_Out_Req="' + CONVERT(VARCHAR, isnull(@Map_Out_Req, ''), 4) + '" ' + 'IsCallout="' + isnull(@iscallout, '') + '" ' + 'SmartViewSection="' + isnull(@smartviewsection, '') + '" ' + 'SetScrollPosition="' + isnull(@preserveposition, '') + '" ' + -- added for Defect ID: TECH-18349
							'IsPivot="' + isnull(@ispivot, 'N') + '" ' + 'TemplateCategory="' + isnull(@TemplateCat, '') + '" ' + 'TemplateSpecification="' + isnull(@TemplateSpecific, '') + '" ' + 'FileSize="' + isnull(@filesize, '') + '" />',
							@xml_seq_tmp
							)
							--Code Added for the Bug ID:PLF2.0_00961 ends
					END
					ELSE IF @ui_format_tmp = 'UND'
					BEGIN
						SELECT @helptext = @ctrl_descr_tmp + ' - Datatype : ' + ltrim(rtrim(isnull(@datatype_tmp, ''))) + ' - MaxLength : ' + ltrim(rtrim(isnull(@datalength_tmp, '')))

						IF upper(isnull(@datatype_tmp, '')) = 'NUMERIC'
							SELECT @helptext = @helptext + ' - DecimalLength : ' + ltrim(rtrim(isnull(@datalength_tmp, '')))

						INSERT INTO ep_genxml_tmp (
							customer_name,
							project_name,
							req_no,
							process_name,
							component_name,
							activity_name,
							guid,
							gen_xml,
							seq_no
							)
						VALUES (
							@engg_customer_name,
							@engg_project_name,
							@engg_req_no,
							@process_name,
							@engg_component,
							@activity_name,
							@guid,
							'<Control Name="' + ltrim(rtrim(isnull(@controlid_tmp, ''))) + '" ' + 'RenderAs="' + ltrim(rtrim(isnull(@renderas, ''))) + '" ' + 'ControlCaption="' + ltrim(rtrim(isnull(@ctrl_descr_tmp, ''))) + '" ' + 'SectionName="' + ltrim(rtrim(isnull(@section_bt_synonym_tmp, ''))) + '" ' + 'PageName="' + ltrim(rtrim(isnull(@page_bt_synonym_tmp, ''))) + '" ' + 'ILBOName="' + ltrim(rtrim(isnull(@ui_name_tmp, ''))) + '" ' + 'ActivityName="' + ltrim(rtrim(isnull(@activity_name, ''))) + '" ' + 'ComponentName="' + ltrim(rtrim(isnull(@engg_component, ''))) + '" ' + 'ControlType="' + ltrim(rtrim(isnull(upper(@control_type_tmp), ''))) + '" ' + 'BaseControlType="' + ltrim(rtrim(isnull(upper(@base_ctrl_type_tmp), ''))) + '" ' + -- Code modification  for  PNR2.0_23635
							--        'DataType="'   + ltrim(rtrim(isnull(@datatype_tmp,'')))         + '" ' +
							--        'DataLength="'   + ltrim(rtrim(isnull(@datalength_tmp,'')))         + '" ' +
							--        'DecimalLength="'  + isnull(convert(varchar, @decimal_length_ctrl),'')       + '" ' +
							-- code modified by Anuradha on 22-Mar-2006 for the Bug id :: PNR2.0_7393
							'DataType="' + CASE ltrim(rtrim(isnull(@base_ctrl_type_tmp, ''))) + '-' + ltrim(rtrim(isnull(@datatype_tmp, '')))
								WHEN 'COMBO-INTEGER'
									THEN ''
								ELSE ltrim(rtrim(isnull(@datatype_tmp, '')))
								END + '" ' + 'DataLength="' + CASE ltrim(rtrim(isnull(@base_ctrl_type_tmp, ''))) + '-' + ltrim(rtrim(isnull(@datatype_tmp, '')))
								WHEN 'COMBO-INTEGER'
									THEN ''
								ELSE ltrim(rtrim(isnull(@datalength_tmp, '')))
								END + '" ' + 'DecimalLength="' + CASE ltrim(rtrim(isnull(@base_ctrl_type_tmp, ''))) + '-' + ltrim(rtrim(isnull(@datatype_tmp, '')))
								WHEN 'COMBO-INTEGER'
									THEN ''
								ELSE isnull(convert(VARCHAR, @decimal_length_ctrl), '')
								END + '" ' +
							-- code modified by Anuradha on 22-Mar-2006 for the Bug id :: PNR2.0_7393
							'BTSynonym="' + ltrim(rtrim(isnull(@control_bt_synonym_tmp, ''))) + '" ' + 'VisibleLength="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@visible_length_tmp, 0)))) + '" ' + 'ProtoTooltip="' + ltrim(rtrim(isnull(@proto_tooltip_tmp, ''))) + '" ' + 'SampleData="' + ltrim(rtrim(isnull(@sample_data_tmp, ''))) + '" ' + 'DefaultSampleData="' + ltrim(rtrim(isnull(@default_sample_data_tmp, ''))) + '" ' + 'HOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, isnull(@transformed_horder_tmp, 0)), 3))) + '" ' + 'VOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, isnull(@transformed_vorder_tmp, 0)), 3))) + '" ' + 'Mandatory="' + ltrim(rtrim(isnull(@mandatory_flag_tmp, ''))) + '" ' + 'Visible="' + ltrim(rtrim(isnull(@visible_flag_tmp, ''))) + '" ' + 'Editable="' + ltrim(rtrim(isnull(@editable_flag_tmp, ''))) + '" ' + 'CaptionRequired="' + ltrim(rtrim(isnull(@caption_req_tmp, ''))) + '" ' + 'SelectFlag="' + ltrim(rtrim(isnull(@select_flag_tmp, ''))) + '" ' + 'DeleteFlag="' + ltrim(rtrim(isnull(@delete_flag_tmp, 
''))) + '" ' + 'ZoomRequired="' + ltrim(rtrim(isnull(
										@zoom_req_tmp, ''))) + '" ' + 'HelpRequired="' + ltrim(rtrim(isnull(@help_req_tmp, ''))) + '" ' + 'EllipsesRequired="' + ltrim(rtrim(isnull(@ellipses_req_tmp, ''))) + '" ' + 'AssociatedTask="' + ltrim(rtrim(isnull(@uitaskname_tmp, ''))) + '" ' +
 'DataColumnWidth="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@data_column_width_tmp, 0)))) + '" ' + 'LabelColumnWidth="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@label_column_width_tmp, 0)))) + '" ' + 'DataColumnScaleMode="' + ltrim(rtrim(isnull(@data_column_scalemode, '%'))) + '" ' + 'LabelColumnScaleMode="' + ltrim(rtrim(isnull(@label_column_scalemode, '%'))) + '" ' + 'CaptionWrap="' + ltrim(rtrim(isnull(@caption_wrap_tmp, 'Y'))) + '" ' + 'CaptionAlignment="' + ltrim(rtrim(isnull(@caption_alignment_tmp, 'LEFT'))) + '" ' + 'CaptionPosition="' + ltrim(rtrim(isnull(@caption_position_tmp, 'LEFT'))) + '" ' + 'ControlPosition="' + ltrim(rtrim(isnull(@ctrl_position_tmp, 'LEFT'))) + '" ' + 'LabelClass="' + ltrim(rtrim(isnull(@label_class_tmp, ''))) + '" ' + 'ControlClass="' + ltrim(rtrim(isnull(
										@ctrl_class_tmp, ''))) + '" ' + 'PasswordChar="' + ltrim(rtrim(isnull(@password_char_tmp, 'N'))) + '" ' + 'TaskImageClass="' + ltrim(rtrim(isnull(@task_img_tmp, ''))) + '" ' + 'HelpImageClass="' + ltrim(rtrim(isnull(@help_img_tmp, ''))) + '" ' +
 'Documentation="' + ltrim(rtrim(isnull(@controldoc_tmp, ''))) + '" ' + 'OrderSequence="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@order_seq_tmp, 0)))) + '" ' + 'VisibleRows="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@visible_rows_tmp, 0)))) + '" ' + 'HTMLTextArea="' + ltrim(rtrim(isnull(@html_text_area, 'N'))) + '" ' + 'SpinRequired="' + ltrim(rtrim(isnull(@spin_required, 'N'))) + '" ' + 'SpinUpImage="' + ltrim(rtrim(isnull(@spin_up_image, 'spinup.gif'))) + '" ' + 'SpinDownImage="' + ltrim(rtrim(isnull(@spin_down_image, 'spindown.gif'))) + '" ' + 'AssociatedSpinControl="' + ltrim(rtrim(isnull(@associated_spin_ctrl, ''))) + '" ' + 'AssociatedSpinTask="' + ltrim(rtrim(isnull(@associated_spin_task, ''))) + '" ' + 'HelpText="' + ltrim(rtrim(isnull(@helptext, '')
)) + '" ' + 'ModelSectionName="' + ltrim(rtrim(
									isnull(@section_bt_synonym_tmp, ''))) + '" ' +
							-- Inplace Calendar and Edit Mask Feature added by Feroz -- Start
							'InPlaceCalendar="' + ltrim(rtrim(isnull(@InPlaceCalendar, 'n'))) + '" ' +
							-- Code modification for  PNR2.0_19426  starts
							'InCalDisplay="' + ltrim(rtrim(isnull(@InPlaceCal_Display, ''))) + '" ' + 'EditMask="' + ltrim(rtrim(isnull(@EditMaskPattern, ''))) + '" ' +
							-- Inplace Calendar and Edit Mask Feature added by Feroz -- End
							'TabIndex="' + ltrim(rtrim(@tab_seq)) + '" ' + 'AccessKey="' + ltrim(rtrim(isnull(@AccessKey, ''))) + '" ' + -- Added by Jeya For AccessKey
							-- Code modification for  PNR2.0_19426  ends
							-- Code addition for PNR2.0_21576 starts
							--Code modified by Balaji D for Bug ID PNR2.0_28889 on 01-Nov-2010 starts
							'GridLite="' + ltrim(rtrim(isnull(@gridlite, 'N'))) + '" ' +
							--Code modified by Balaji D for Bug ID PNR2.0_28889 on 01-Nov-2010 end
							-- Code addition for PNR2.0_21576 ends
							-- Code addition for PNR2.0_20849 starts
							'NoofLinesPerRow="' + ltrim(rtrim(isnull(@NoofLinesPerRow, ''))) + '" ' + 'RowHeight="' + ltrim(rtrim(isnull(@RowHeight, ''))) + '" ' +
							-- Added By Feroz
							'BulletLink="' + ltrim(rtrim(isnull(@bulletlink_req, 'N'))) + '" ' + 'ButtonCombo="' + ltrim(rtrim(isnull(@buttoncombo_req, 'N'))) + '" ' + 'DataAsCaption="' + ltrim(rtrim(isnull(@dataascaption, 'N'))) + '" ' + 'AssociatedList="' + ltrim(rtrim(isnull(@associatedlist_name, ''))) + '" ' + 'OnFocusTask="' + ltrim(rtrim(isnull(@onfocus_taskname, ''))) + '" ' + 'ListRefillTask="' + ltrim(rtrim(isnull(@listrefill_taskname, ''))) + '" ' + 'MappedListControlID="' + ltrim(rtrim(isnull(@mapped_list_controlid
, ''))) + '" ' + 'MappedListViewName="' + ltrim(rtrim(isnull(@mapped_list_viewname, ''))) + '" ' + 'AttachDocument="' + ltrim(rtrim(isnull(@attach_document, 'N'))) + '" ' + 'ImageUpload="' + ltrim(rtrim(isnull(@image_upload, 'N'))) + '" ' + 'InplaceImage=
"' + ltrim(rtrim(isnull(@inplace_image, 'N'))) + '" ' + 'ImageIcon="' + ltrim(rtrim(isnull(@image_icon, 'N'))) + '" ' + 
'ImageType="'   + ltrim(rtrim(isnull(@ImageType,'N')))             + '" ' +
'ImageRowHeight="' + ltrim(rtrim(isnull(@image_row_height, '0'))) + '" ' + 'RelativeUrlPath="' + ltrim(rtrim(isnull(@relative_url_path,
 ''))) + '" ' + 'RelativeDocumentPath="' + ltrim(rtrim(
									isnull(@relative_document_path, ''))) + '" ' + 'RelativeImagePath="' + ltrim(rtrim(isnull(@relative_image_path, ''))) + '" ' + 'SaveDocContentToDb="' + ltrim(rtrim(isnull(@save_doc_content_to_db, 'N'))) + '" ' + 'SaveImageContentToDb="' + ltrim(rtrim(isnull(@save_image_content_to_db, 'N'))) + '" ' + 'DateHighlight="' + ltrim(rtrim(isnull(@date_highlight_req, 'N'))) + '" ' + 'LinkedHiddenViewName="' + ltrim(rtrim(isnull(@hidden_view_name, ''))) + '" ' + 'Vscrollbar_Req="' + ltrim(rtrim(isnull(@Vscrollbar_Req, 'N'))) + '" LiteAttach="' + Isnull(@Lite_Attach, 'N') + '" Browse_Button="' + Isnull(@BrowseButton, 'N') + '" Delete_Button="' + Isnull(@DeleteButton, 'N') + '" ' + --PNR2.0_28365 -- Code Modified For BUGID PNR2.0_28537
							'IsITK="N"  FC="' + CONVERT(VARCHAR, isnull(@freezecount, 0), 4) + '" ' +
							--code added for the caseid : PNR2.0_28319 starts
							'image_row_width="' + CONVERT(VARCHAR, isnull(@image_row_width, 0), 4) + '" ' + 'image_preview_height="' + CONVERT(VARCHAR, isnull(@image_preview_height, 0), 4) + '" ' + 'image_preview_width="' + CONVERT(VARCHAR, isnull(@image_preview_width, 0), 4)
 + '" ' + 'image_preview_req="' + isnull(@image_preview_req, 'N') + '" ' + 'Accept_Type="' + isnull(@Accept_Type, '') + '" ' + 'Lite_Attach_Image="' + isnull(@Lite_Attach_Image, 'N') + '" ' + 'LabelLink="' + isnull(@LabelLink, 'N') + '" ' + --added for PNR2.0_26860, PNR2.0_27796,PNR2.0_36309
							-- Code addition for PNR2.0_20849 ends
							--code added for the caseid : PNR2.0_28319 ends
							--Code Added for the Bug ID: PLF2.0_00961 starts
							--'PopUpPage="'           +   isnull(@popup_page,'')                  +'" ' +
							--'PopUpSection="'        +   isnull(@popup_section,'')               +'" ' +
							--'PopUpClose="'          +   isnull(@popup_Close,'N')                +'" ' +
							'CaptionType="' + isnull(@captiontype, '') + '" ' + 'ControlStyle="' + isnull(@controlstyle, '') + '" ' + 'ControlImage="' + isnull(@controlimage, '') + '" ' + 'IsListBox="' + isnull(@IsListBox, '') + '" ' + 'Toolbar_Not_Req="' + isnull(@Toolbar_Not_Req, '') + '" ' + 'ColumnBorder_Not_Req="' + isnull(@ColumnBorder_Not_Req, '') + '" ' + 'RowBorder_Not_Req="' + isnull(@RowBorder_Not_Req, '') + '" ' + 'PageNavigation_Only="' + isnull(@PagenavigationOnly, '') + '" ' + 'RowNo_Not_Req="' + isnull(@RowNo_Not_Req, '') + '" ' + 'ExtType="' + isnull(@ExtType, '') + '" ' + 'ColSpan="' + CONVERT(VARCHAR, isnull(@ControlColSpan, ''), 4) + '" ' + 'RowSpan="' + CONVERT(VARCHAR, isnull(@ControlRowSpan, ''), 4) + '" ' + 'Tooltip_Not_Req="' + CONVERT(VARCHAR, isnull(@Tooltip_Not_Req, ''), 4) + '" ' + 'GridHeader_Not_Req="' + CONVERT(VARCHAR, isnull(@columncaption_Not_Req, ''), 4) + '" ' + 'Border_Not_Req="' + CONVERT(VARCHAR, isnull(@Border_Not_Req, ''), 4) + '" ' + 'IsModal="' + CONVERT(VARCHAR, isnull(@IsModal, ''), 4) + '" ' + 'Alternate_Color_Req="' + CONVERT(VARCHAR, isnull(@Alternate_Color_Req
									, ''), 4) + '" ' + 'Map_In_Req="' + CONVERT(VARCHAR, isnull(@Map_In_Req, ''), 4) + '" ' + 'Map_Out_Req="' + CONVERT(VARCHAR, isnull(@Map_Out_Req, ''), 4) + '" ' + 'IsCallout="' + isnull(@iscallout, '') + '" ' + 'SmartViewSection="' + isnull(@smartviewsection, '') + '" ' + 'AutoSelect="' + isnull(@autoselect, '') + '" ' + 'SetScrollPosition="' + isnull(@preserveposition, '') + '" ' + -- added for Defect ID: TECH-18349
						'IsPivot="' + isnull(@ispivot, 'N') + '" ' + 
						'SetFocusEvent="'	+ isnull(@setfocusevent,'')	 +'" ' +  -- Added for TECH-37471 
						'LeaveFocusEvent="'	+ isnull(@leavefocusevent,'')	 +'" ' +  -- Added for TECH-37471 
						'SetFocusEventOccurence="'	+ isnull(@setfocuseventoccur,'')	 +'" ' +  
						'LeaveFocusEventOccurence="'	+ isnull(@leavefocuseventoccur,'')	 +'" ' +  
						'MoreEvent="'	+ isnull(@MoreEventName,'')	 +'" ' +  --TECH-45828
						'UPEEnabled="'	+ isnull(@UPEEnabled,'N')	 +'" ' + 
						'TemplateCategory="' + isnull(@TemplateCat, '') + '" ' + 'TemplateSpecification="' + isnull(@TemplateSpecific, '') + '" ' 
						+ 'FileSize="' + isnull(@filesize, '') + '" />',
							@xml_seq_tmp
							)
							--Code Added for the Bug ID:PLF2.0_00961 ends
					END
				END

				SELECT @previous_section_tmp = @section_bt_synonym_tmp,
					@previous_horder_tmp = @horder_tmp,
					@previous_vorder_tmp = @vorder_tmp
			END

			CLOSE ctrlcurs

			DEALLOCATE ctrlcurs

			-- in case of help ui add a standard ok task button
			-- Insert Control Entry
			-- code modified by shafina on 24-Aug-2004 for PREVIEWENG203SYS_000137 (In the generated preview OK button is not appearing,instead a X symbol is appearing)
			IF @ui_type_tmp = 'HELP'
			BEGIN
				--Code Added For Bug_id PNR2.0_17856 Starts Here
				IF NOT EXISTS (
						SELECT 'x'
						FROM es_comp_param_mst
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @process_name
							AND component_name = @engg_component
							AND param_type = 'UIFORMAT'
							AND param_category = 'OKLINES'
							AND current_value = 'Yes'
						)
				BEGIN
					--Code Added For Bug_id PNR2.0_17856 Ends Here
					--code modified for bugId : PNR2.0_10535
					-- code modification  for  PNR2.0_22560 starts
					IF @tab_seq IS NULL
						SELECT @tab_seq = 1
					ELSE
						SELECT @tab_seq = @tab_seq + 1

					-- code modification  for  PNR2.0_22560 ends
					--code modified for bugId : PNR2.0_10535
					SELECT @xml_seq_tmp = @xml_seq_tmp + 1

					SELECT @helptext = @ctrl_descr_tmp + ' - Datatype : ' + ltrim(rtrim(isnull(@datatype_tmp, ''))) + ' - MaxLength : ' + ltrim(rtrim(isnull(@datalength_tmp, '')))

					IF upper(isnull(@datatype_tmp, '')) = 'NUMERIC'
						SELECT @helptext = @helptext + ' - DecimalLength : ' + ltrim(rtrim(isnull(@datalength_tmp, '')))

					INSERT INTO ep_genxml_tmp (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						activity_name,
						guid,
						gen_xml,
						seq_no
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@engg_req_no,
						@process_name,
						@engg_component,
						@activity_name,
						@guid,
						'<Control Name="' + ltrim(rtrim('TRANSFER')) + '" ' + 'RenderAs="' + ltrim(rtrim(isnull(@renderas, ''))) + '" ' + 'ControlCaption="' + ltrim(rtrim(@ok_caption)) + '" ' + -- code modified by kiruthika for bugid :PNR2.0_28767 on 21-oct-2010
						'SectionName="' + ltrim(rtrim(isnull(@oksectionname_tmp, ''))) + '" ' + 'PageName="' + ltrim(rtrim(isnull(@mainpage_tmp, ''))) + '" ' + 'ILBOName="' + ltrim(rtrim(isnull(@ui_name_tmp, ''))) + '" ' + 'ActivityName="' + ltrim(rtrim(isnull(@activity_name, ''))) + '" ' + 'ComponentName="' + ltrim(rtrim(isnull(@engg_component, ''))) + '" ' +
					-- Code modified on 18-Feb-2009 for the Bug ID :: PNR2.0_21118 - Begin
						'ControlType="' + ltrim(rtrim('BUTTON')) + '" ' +
						-- Code modified on 18-Feb-2009 for the Bug ID :: PNR2.0_21118 - Ends
						'BaseControlType="' + ltrim(rtrim('BUTTON')) + '" ' + 'DataType="' + ltrim(rtrim('char')) + '" ' + 'DataLength="' + ltrim(rtrim('20')) + '" ' + 'DecimalLength="' + isnull(convert(VARCHAR, @decimal_length_ctrl), '') + '" ' + 'BTSynonym="' + ltrim(rtrim(isnull('OK', ''))) + '" ' + 'VisibleLength="' + ltrim(rtrim(CONVERT(VARCHAR, 10))) + '" ' + 'ProtoTooltip="' + ltrim(rtrim(isnull('OK', ''))) + '" ' + 'SampleData="' + '' + '" ' + 'HOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, isnull(1, 0)), 3))) + '" ' + 'VOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, isnull(1, 0)), 3))) + '" ' + 'Mandatory="' + ltrim(rtrim(isnull('N', ''))) + '" ' + 'Visible="' + ltrim(rtrim(isnull('Y', ''))) + '" ' + 'Editable="' + ltrim(rtrim(isnull('Y', ''))) + 
'" ' + 'CaptionRequired="' + ltrim(rtrim(isnull('N', ''))) + '" ' + 'SelectFlag="' + ltrim(rtrim(isnull('N', ''))) + '" ' + 'ZoomRequired="' + ltrim(rtrim(isnull('N', ''))) + '" ' + 'DeleteFlag="' + ltrim(rtrim(isnull('N', ''))) + '" ' + 'HelpRequired="' 
+ ltrim(rtrim(isnull('N', ''))) + '" ' + 'EllipsesRequired="' + ltrim(rtrim(isnull('N', '')
							)) + '" ' + 'AssociatedTask="' + ltrim(rtrim(isnull('TRANSFER', ''))) + '" ' + 'DataColumnWidth="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(50, 0)))) + '" ' + 'LabelColumnWidth="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(50, 0)))) + '" ' + 'DataColumnScaleMode="' + ltrim(rtrim(isnull('%', ''))) + '" ' + 'LabelColumnScaleMode="' + ltrim(rtrim(isnull('%', ''))) + '" ' + 'CaptionWrap="' + ltrim(rtrim('N')) + '" ' + 'CaptionAlignment="' + ltrim(rtrim('CENTER')) + '" ' + 'CaptionPosition="' + ltrim(rtrim('CENTER')) + '" ' + 'ControlPosition="' + ltrim(rtrim('CENTER')) + '" ' + 'LabelClass="' + ltrim(rtrim(isnull(@label_class_tmp, ''))) + '" ' + 'ControlClass="' + ltrim(rtrim(isnull(@ctrl_class_tmp, ''))) + '" ' + 'PasswordChar="' + ltrim(rtrim(isnull(@password_char_tmp, 'N'))) + '" ' + 'TaskImageClass="' + ltrim(rtrim(isnull(@task_img_tmp, ''))) + '" ' + 'HelpImageClass="' + ltrim(rtrim(isnull(@help_img_tmp, ''))) + '" ' + 'Documentation="' + ltrim(rtrim(isnull('', ''))) + '" ' + 'OrderSequence="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(1, 0)))) + '" ' + 'VisibleRows="' + ltrim(rtrim(
							CONVERT(VARCHAR, isnull(1, 0)))) + '" ' + 'HTMLTextArea="' + ltrim(rtrim(isnull(@html_text_area, 'N'))) + '" ' + 'SpinRequired="' + ltrim(rtrim(isnull(@spin_required, 'N'))) + '" ' + 'SpinUpImage="' + ltrim(rtrim(isnull(@spin_up_image, 'spinup.gif
'))) + '" ' + 'SpinDownImage="' + ltrim(rtrim(isnull(@spin_down_image, 'spindown.gif'))) + '" ' + 'AssociatedSpinControl="' + ltrim(rtrim(isnull(@associated_spin_ctrl, ''))) + '" ' + 'AssociatedSpinTask="' + ltrim(rtrim(isnull(@associated_spin_task, '')))
 + '" ' + 'HelpText="' + ltrim(rtrim(isnull(@helptext, ''))) + '" ' + 'ModelSectionName="' + ltrim(rtrim(isnull(@oksectionname_tmp, ''))) + '" ' +
						-- Inplace Calendar and Edit Mask Feature added by Feroz -- Start
						'InPlaceCalendar="' + ltrim(rtrim(isnull(@InPlaceCalendar, 'n'))) + '" ' +
						-- Code modification for  PNR2.0_19426  starts
						'InCalDisplay="' + ltrim(rtrim(isnull(@InPlaceCal_Display, ''))) + '" ' + 'EditMask="' + ltrim(rtrim(isnull(@EditMaskPattern, ''))) + '" ' +
						-- Inplace Calendar and Edit Mask Feature added by Feroz -- End
						'TabIndex="' + ltrim(rtrim(@tab_seq)) + '" ' + 'AccessKey="' + ltrim(rtrim(isnull(@AccessKey, ''))) + '" ' + -- Added by Jeya For AccessKey
						-- Code modification for  PNR2.0_19426  ends
						-- Code addition for PNR2.0_21576 starts
						--Code modified by Balaji D for Bug ID PNR2.0_28889 on 01-Nov-2010 starts
						'GridLite="' + ltrim(rtrim(isnull(@gridlite, 'N'))) + '" ' +
						--Code modified by Balaji D for Bug ID PNR2.0_28889 on 01-Nov-2010 end
						-- Code addition for PNR2.0_21576 ends
						-- Code addition for PNR2.0_20849 starts
						'NoofLinesPerRow="' + ltrim(rtrim(isnull(@NoofLinesPerRow, ''))) + '" ' + 'RowHeight="' + ltrim(rtrim(isnull(@RowHeight, ''))) + '" ' +
						-- Added By Feroz
						'BulletLink="' + ltrim(rtrim(isnull(@bulletlink_req, 'N'))) + '" ' + 'ButtonCombo="' + ltrim(rtrim(isnull(@buttoncombo_req, 'N'))) + '" ' + 'DataAsCaption="' + ltrim(rtrim(isnull(@dataascaption, 'N'))) + '" ' + 'AssociatedList="' + ltrim(rtrim(isnull(@associatedlist_name, ''))) + '" ' + 'OnFocusTask="' + ltrim(rtrim(isnull(@onfocus_taskname, ''))) + '" ' + 'ListRefillTask="' + ltrim(rtrim(isnull(@listrefill_taskname, ''))) + '" ' + 'MappedListControlID="' + ltrim(rtrim(isnull(@mapped_list_controlid,
 ''))) + '" ' + 'MappedListViewName="' + ltrim(rtrim(isnull(@mapped_list_viewname, ''))) + '" ' + 'AttachDocument="' + ltrim(rtrim(isnull(@attach_document, 'N'))) + '" ' + 'ImageUpload="' + ltrim(rtrim(isnull(@image_upload, 'N'))) + '" ' + 'InplaceImage="
' + ltrim(rtrim(isnull(@inplace_image, 'N'))) + '" ' + 'ImageIcon="' + ltrim(rtrim(isnull(@image_icon, 'N'))) + '" ' + 
'ImageType="'   + ltrim(rtrim(isnull(@ImageType,'N')))             + '" ' +
'ImageRowHeight="' + ltrim(rtrim(isnull(@image_row_height, '0'))) + '" ' + 'RelativeUrlPath="' + ltrim(rtrim(isnull(@relative_url_path, 
''))) + '" ' + 'RelativeDocumentPath="' + ltrim(rtrim(isnull(
									@relative_document_path, ''))) + '" ' + 'RelativeImagePath="' + ltrim(rtrim(isnull(@relative_image_path, ''))) + '" ' + 'SaveDocContentToDb="' + ltrim(rtrim(isnull(@save_doc_content_to_db, 'N'))) + '" ' + 'SaveImageContentToDb="' + ltrim(rtrim(isnull(@save_image_content_to_db, 'N'))) + '" ' + 'DateHighlight="' + ltrim(rtrim(isnull(@date_highlight_req, 'N'))) + '" ' + 'LinkedHiddenViewName="' + ltrim(rtrim(isnull(@hidden_view_name, ''))) + '" ' + 'Vscrollbar_Req="' + ltrim(rtrim(isnull(@Vscrollbar_Req, 'N'))) + '" LiteAttach="' + Isnull(@Lite_Attach, 'N') + '" Browse_Button="' + Isnull(@BrowseButton, 'N') + '" Delete_Button="' + Isnull(@DeleteButton, 'N') + '" ' + --PNR2.0_28365 -- Code Modified For BUGID PNR2.0_28537
						'IsITK="N"  FC="' + CONVERT(VARCHAR, isnull(@freezecount, 0), 4) + '" ' +
						--code added for the caseid : PNR2.0_28319 starts
						'image_row_width="' + CONVERT(VARCHAR, isnull(@image_row_width, 0), 4) + '" ' + 'image_preview_height="' + CONVERT(VARCHAR, isnull(@image_preview_height, 0), 4) + '" ' + 'image_preview_width="' + CONVERT(VARCHAR, isnull(@image_preview_width, 0), 4) 
+ '" ' + 'image_preview_req="' + isnull(@image_preview_req, 'N') + '" ' + 'Accept_Type="' + isnull(@Accept_Type, '') + '" ' + 'Lite_Attach_Image="' + isnull(@Lite_Attach_Image, 'N') + '" ' + --commented for PNR2.0_28376
						'LabelLink="' + isnull(@LabelLink, 'N') + '" ' + --added for PNR2.0_26860, PNR2.0_27796,PNR2.0_36309
						-- Code addition for PNR2.0_20849 ends
						--code added for the caseid : PNR2.0_28319 ends
						--Code Added for the Bug ID: PLF2.0_00961 starts
						--'PopUpPage="'           +   isnull(@popup_page,'')                  +'" ' +
						--'PopUpSection="'        +   isnull(@popup_section,'')               +'" ' +
						--'PopUpClose="'          +   isnull(@popup_Close,'N')                +'" ' +
						'CaptionType="' + isnull(@captiontype, '') + '" ' + 'ControlStyle="' + isnull(@controlstyle, '') + '" ' + 'ControlImage="' + isnull(@controlimage, '') + '" ' + 'IsListBox="' + isnull(@IsListBox, '') + '" ' + 'Toolbar_Not_Req="' + isnull(@Toolbar_Not_Req, '') + '" ' + 'ColumnBorder_Not_Req="' + isnull(@ColumnBorder_Not_Req, '') + '" ' + 'RowBorder_Not_Req="' + isnull(@RowBorder_Not_Req, '') + '" ' + 'PageNavigation_Only="' + isnull(@PagenavigationOnly, '') + '" ' + 'RowNo_Not_Req="' + isnull(@RowNo_Not_Req, '') + '" ' + 'ExtType="' + isnull(@ExtType, '') + '" ' + 'ColSpan="' + CONVERT(VARCHAR, isnull(@ControlColSpan, ''), 4) + '" ' + 'RowSpan="' + CONVERT(VARCHAR, isnull(@ControlRowSpan, ''), 4) + '" ' + 'Tooltip_Not_Req="' + CONVERT(VARCHAR, isnull(@Tooltip_Not_Req, ''), 4) + '" ' + 'GridHeader_Not_Req="' + CONVERT(VARCHAR, isnull(@columncaption_Not_Req, ''), 4) + '" ' + 'Border_Not_Req="' + CONVERT(VARCHAR, isnull(@Border_Not_Req, ''), 4) + '" ' + 'IsModal="' + CONVERT(VARCHAR, isnull(@IsModal, ''), 4) + '" ' + 'Alternate_Color_Req="' + CONVERT(VARCHAR, isnull(@Alternate_Color_Req, '')
							, 4) + '" ' + 'Map_In_Req="' + CONVERT(VARCHAR, isnull(@Map_In_Req, ''), 4) + '" ' + 'Map_Out_Req="' + CONVERT(VARCHAR, isnull(@Map_Out_Req, ''), 4) + '" ' + 'IsCallout="' + isnull(@iscallout, '') + '" ' + 'SmartViewSection="' + isnull(@smartviewsection, '') + '" ' + 'SetScrollPosition="' + isnull(@preserveposition, '') + '" ' + -- added for Defect ID: TECH-18349
						'IsPivot="' + isnull(@ispivot, 'N') + '" ' + 'TemplateCategory="' + isnull(@TemplateCat, '') + '" ' + 'TemplateSpecification="' + isnull(@TemplateSpecific, '') + '" ' + 'RatingType="' + ltrim(rtrim(isnull(lower(@RatingType), ''))) + '" ' + 'CaptchaData="' + ltrim(rtrim(isnull(lower(@CaptchaData), ''))) + '" ' + 'FileSize="' + isnull(@filesize, '') + '" />',
						@xml_seq_tmp
						)
						--Code Added for the Bug ID:PLF2.0_00961 ends
				END
				ELSE
				BEGIN
					--Code Added For Bug_id PNR2.0_17856 Starts Here
					--code modified for bugId : PNR2.0_10535
					-- code modification  for  PNR2.0_22560 starts
					IF @tab_seq IS NULL
						SELECT @tab_seq = 1
					ELSE
						SELECT @tab_seq = @tab_seq + 1

					-- code modification  for  PNR2.0_22560 ends
					--code modified for bugId : PNR2.0_10535
					SELECT @xml_seq_tmp = @xml_seq_tmp + 1

					SELECT @helptext = @ctrl_descr_tmp + ' - Datatype : ' + ltrim(rtrim(isnull(@datatype_tmp, ''))) + ' - MaxLength : ' + ltrim(rtrim(isnull(@datalength_tmp, '')))

					IF upper(isnull(@datatype_tmp, '')) = 'NUMERIC'
						SELECT @helptext = @helptext + ' - DecimalLength : ' + ltrim(rtrim(isnull(@datalength_tmp, '')))

					INSERT INTO ep_genxml_tmp (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						activity_name,
						guid,
						gen_xml,
						seq_no
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@engg_req_no,
						@process_name,
						@engg_component,
						@activity_name,
						@guid,
						'<Control Name="' + 'OKLINE1' + '" ' + 'RenderAs="' + ltrim(rtrim(isnull(@renderas, ''))) + '" ' + 'ControlCaption="' + 'OKLINE1' + '" ' + 'SectionName="' + ltrim(rtrim(isnull(@oksectionname_tmp, ''))) + '" ' + 'PageName="' + ltrim(rtrim(isnull(@mainpage_tmp, ''))) + '" ' + 'ILBOName="' + ltrim(rtrim(isnull(@ui_name_tmp, ''))) + '" ' + 'ActivityName="' + ltrim(rtrim(isnull(@activity_name, ''))) + '" ' + 'ComponentName="' + ltrim(rtrim(isnull(@engg_component, ''))) + '" ' + 'ControlType="' + upper('Line') + '" ' + 'BaseControlType="' + 'LINE' + '" ' + 'DataType="' + 'char' + '" ' + 'DataLength="' + '20' + '" ' + 'DecimalLength="' + isnull(convert(VARCHAR, @decimal_length_ctrl), '') + '" ' + 'BTSynonym="' + 'OKLINE1' + '" ' + 'VisibleLength="' + ltrim(rtrim(CONVERT(VARCHAR, 0))) + '" ' + 'ProtoTooltip="' + '' + '" ' + 'SampleData="' + '' + '" ' + 'DefaultSampleData="' + '' + '" ' + 'HOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, isnull(1, 0)), 3))) + '" ' + 'VOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, isnull(1, 0)), 3))) + '" ' + 'Mandatory="' + 'N' + '" ' + 'Visible="' + 'Y' + '" ' + 'Editable="' + 'N' + '" ' + 'CaptionRequired="' + 'N' + '" ' + 'SelectFlag="' + 'N' + '" ' + 'ZoomRequired="' + 'N' + '" ' + 'DeleteFlag="' + 'N' + '" ' + 'HelpRequired="' + 'N' + '" ' + 'EllipsesRequired="' + 'N' + '" ' + 'AssociatedTask="' + '' + 
'" ' + 'DataColumnWidth="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(0, 0)))) + '" ' + 'LabelColumnWidth="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(0, 0)))) + '" ' + 'DataColumnScaleMode="' + '%' + '" ' + 'LabelColumnScaleMode="' + '%' + '" ' + 'CaptionWrap="' 
+ 'N' + '" ' + 'CaptionAlignment="' + 'RIGHT' + '" ' + 'CaptionPosition="' + 'LEFT' + '" ' + 'ControlPosition="' + 'LEFT' + '" ' + 'LabelClass="' + '' + '" ' + 'ControlClass="' + '' + '" ' + 'PasswordChar="' + 'N' + '" ' + 'TaskImageClass="' + '' + '" ' +
 'HelpImageClass="' + '' + '" ' + 'Documentation="' + '' + '" ' + 'OrderSequence="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(1, 0)))) + '" ' + 'VisibleRows="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(1, 0)))) + '" ' + 'HTMLTextArea="' + '' + '" ' + 'SpinRequired="' + 'N' + '" ' + 'SpinUpImage="' + '' + '" ' + 'SpinDownImage="' + '' + '" ' + 'AssociatedSpinControl="' + '' + '" ' + 
						'AssociatedSpinTask="' + '' + '" ' + 'HelpText="' + ltrim(rtrim(isnull(@helptext, ''))) + '" ' + 'ReportRequired="' + 'N' + '" ' + 'ModelSectionName="' + ltrim(rtrim(isnull(@oksectionname_tmp, ''))) + '" ' +
						-- Inplace Calendar and Edit Mask Feature added by Feroz -- Start
						'InPlaceCalendar="' + ltrim(rtrim(isnull(@InPlaceCalendar, 'n'))) + '" ' +
						-- Code modification for  PNR2.0_19426  starts
						'InCalDisplay="' + ltrim(rtrim(isnull(@InPlaceCal_Display, ''))) + '" ' + 'EditMask="' + ltrim(rtrim(isnull(@EditMaskPattern, ''))) + '" ' +
						-- Inplace Calendar and Edit Mask Feature added by Feroz -- End
						'TabIndex="' + ltrim(rtrim(@tab_seq)) + '" ' + 'AccessKey="' + ltrim(rtrim(isnull(@AccessKey, ''))) + '" ' + -- Added by Jeya For AccessKey
						-- Code modification for  PNR2.0_19426  ends
						-- Code addition for PNR2.0_20849 starts
						-- Code addition for PNR2.0_21576 starts
						--Code modified by Balaji D for Bug ID PNR2.0_28889 on 01-Nov-2010 starts
						'GridLite="' + ltrim(rtrim(isnull(@gridlite, 'N'))) + '" ' +
						--Code modified by Balaji D for Bug ID PNR2.0_28889 on 01-Nov-2010 end
						-- Code addition for PNR2.0_21576 ends
						'NoofLinesPerRow="' + ltrim(rtrim(isnull(@NoofLinesPerRow, ''))) + '" ' + 'RowHeight="' + ltrim(rtrim(isnull(@RowHeight, ''))) + '" ' +
						-- Added By Feroz
						'BulletLink="' + ltrim(rtrim(isnull(@bulletlink_req, 'N'))) + '" ' + 'ButtonCombo="' + ltrim(rtrim(isnull(@buttoncombo_req, 'N'))) + '" ' + 'DataAsCaption="' + ltrim(rtrim(isnull(@dataascaption, 'N'))) + '" ' + 'AssociatedList="' + ltrim(rtrim(isnull(@associatedlist_name, ''))) + '" ' + 'OnFocusTask="' + ltrim(rtrim(isnull(@onfocus_taskname, ''))) + '" ' + 'ListRefillTask="' + ltrim(rtrim(isnull(@listrefill_taskname, ''))) + '" ' + 'AttachDocument="' + ltrim(rtrim(isnull(@attach_document, 'N'))) + '" ' + 'MappedListControlID="' + ltrim(rtrim(isnull(@mapped_list_controlid, ''))) + '" ' + 'MappedListViewName="' + ltrim(rtrim(isnull(@mapped_list_viewname, ''))) + '" ' + 'ImageUpload="' + ltrim(rtrim(isnull(@image_upload, 'N'))) + '" ' + 'InplaceImage="' + ltrim(rtrim(isnull(@inplace_image, 'N'))) + '" ' + 'ImageIcon="' + ltrim(rtrim(isnull(@image_icon, 'N'))) + '" ' + 'ImageRowHeight="' + ltrim(rtrim(isnull(@image_row_height, '0'))) + '" ' + 'RelativeUrlPath="' + ltrim(rtrim(isnull(@relative_url_path, 
''))) + '" ' + 'RelativeDocumentPath="' + ltrim(rtrim(isnull(
									@relative_document_path, ''))) + '" ' + 'RelativeImagePath="' + ltrim(rtrim(isnull(@relative_image_path, ''))) + '" ' + 'SaveDocContentToDb="' + ltrim(rtrim(isnull(@save_doc_content_to_db, 'N'))) + '" ' + 'SaveImageContentToDb="' + ltrim(rtrim(isnull(@save_image_content_to_db, 'N'))) + '" ' + 'DateHighlight="' + ltrim(rtrim(isnull(@date_highlight_req, 'N'))) + '" ' + 'LinkedHiddenViewName="' + ltrim(rtrim(isnull(@hidden_view_name, ''))) + '" ' + 'Vscrollbar_Req="' + ltrim(rtrim(isnull(@Vscrollbar_Req, 'N'))) + '" LiteAttach="' + Isnull(@Lite_Attach, 'N') + '" Browse_Button="' + Isnull(@BrowseButton, 'N') + '" Delete_Button="' + Isnull(@DeleteButton, 'N') + '" ' + --PNR2.0_28365 -- Code Modified For BUGID PNR2.0_28537
						'IsITK="N"  FC="' + CONVERT(VARCHAR, isnull(@freezecount, 0), 4) + '" ' +
						--code added for the caseid : PNR2.0_28319 starts
						'image_row_width="' + CONVERT(VARCHAR, isnull(@image_row_width, 0), 4) + '" ' + 'image_preview_height="' + CONVERT(VARCHAR, isnull(@image_preview_height, 0), 4) + '" ' + 'image_preview_width="' + CONVERT(VARCHAR, isnull(@image_preview_width, 0), 4) 
+ '" ' + 'image_preview_req="' + isnull(@image_preview_req, 'N') + '" ' + 'Accept_Type="' + isnull(@Accept_Type, '') + '" ' + 'Lite_Attach_Image="' + isnull(@Lite_Attach_Image, 'N') + '" ' + --commented for PNR2.0_28376
						'LabelLink="' + isnull(@LabelLink, 'N') + '" ' + --added for PNR2.0_26860, PNR2.0_27796,PNR2.0_36309
						-- Code addition for PNR2.0_20849 ends
						--code added for the caseid : PNR2.0_28319 ends
						--Code Added for the Bug ID: PLF2.0_00961 starts
						--'PopUpPage="'           +   isnull(@popup_page,'')                  +'" ' +
						--'PopUpSection="'        +   isnull(@popup_section,'')               +'" ' +
						--'PopUpClose="'          +   isnull(@popup_Close,'N')                +'" ' +
						'CaptionType="' + isnull(@captiontype, '') + '" ' + 'ControlStyle="' + isnull(@controlstyle, '') + '" ' + 'ControlImage="' + isnull(@controlimage, '') + '" ' + 'IsListBox="' + isnull(@IsListBox, '') + '" ' + 'Toolbar_Not_Req="' + isnull(@Toolbar_Not_Req, '') + '" ' + 'ColumnBorder_Not_Req="' + isnull(@ColumnBorder_Not_Req, '') + '" ' + 'RowBorder_Not_Req="' + isnull(@RowBorder_Not_Req, '') + '" ' + 'PageNavigation_Only="' + isnull(@PagenavigationOnly, '') + '" ' + 'RowNo_Not_Req="' + isnull(@RowNo_Not_Req, '') + '" ' + 'ExtType="' + isnull(@ExtType, '') + '" ' + 'ColSpan="' + CONVERT(VARCHAR, isnull(@ControlColSpan, ''), 4) + '" ' + 'RowSpan="' + CONVERT(VARCHAR, isnull(@ControlRowSpan, ''), 4) + '" ' + 'Tooltip_Not_Req="' + CONVERT(VARCHAR, isnull(@Tooltip_Not_Req, ''), 4) + '" ' + 'GridHeader_Not_Req="' + CONVERT(VARCHAR, isnull(@columncaption_Not_Req, ''), 4) + '" ' + 'Border_Not_Req="' + CONVERT(VARCHAR, isnull(@Border_Not_Req, ''), 4) + '" ' + 'IsModal="' + CONVERT(VARCHAR, isnull(@IsModal, '')
, 4) + '" ' + 'Alternate_Color_Req="' + CONVERT(VARCHAR, isnull(@Alternate_Color_Req, '')
							, 4) + '" ' + --PLF2.0_03057
						'Map_In_Req="' + CONVERT(VARCHAR, isnull(@Map_In_Req, ''), 4) + '" ' + 'Map_Out_Req="' + CONVERT(VARCHAR, isnull(@Map_Out_Req, ''), 4) + '" ' + 'IsCallout="' + isnull(@iscallout, '') + '" ' + 'SmartViewSection="' + isnull(@smartviewsection, '') + '"
 ' + 'AutoSelect="' + isnull(@autoselect, '') + '" ' + 'SetScrollPosition="' + isnull(@preserveposition, '') + '" ' + -- added for Defect ID: TECH-18349
						'FileSize="' + isnull(@filesize, '') + '" ' + 'IsPivot="' + isnull(@ispivot, 'N') + '" ' + 'TemplateCategory="' + isnull(@TemplateCat, '') + '" ' + 'TemplateSpecification="' + isnull(@TemplateSpecific, '') + '" ' + 
						'SetFocusEvent="'	+ isnull(@setfocusevent,'')	 +'" ' + -- Added for TECH-37471 
						'LeaveFocusEvent="'	+ isnull(@leavefocusevent,'')	 +'" ' + -- Added for TECH-37471 
						'SetFocusEventOccurence="'	+ isnull(@setfocuseventoccur,'')	 +'" ' +  
						'LeaveFocusEventOccurence="'	+ isnull(@leavefocuseventoccur,'')	 +'" ' +  
						'MoreEvent="'	+ isnull(@MoreEventName,'')	 +'" ' + --TECH-45828
						'UPEEnabled="'	+ isnull(@UPEEnabled,'N')	 +'" ' + 
						'Orientation="' + isnull(@Orientation, 'Horizontal') + '" />',
						@xml_seq_tmp
						)

					--Code Added for the Bug ID:PLF2.0_00961 ends
					SELECT @xml_seq_tmp = @xml_seq_tmp + 1

					INSERT INTO ep_genxml_tmp (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						activity_name,
						guid,
						gen_xml,
						seq_no
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@engg_req_no,
						@process_name,
						@engg_component,
						@activity_name,
						@guid,
						'<Control Name="' + ltrim(rtrim('TRANSFER')) + '" ' + 'RenderAs="' + ltrim(rtrim(isnull(@renderas, ''))) + '" ' + 'ControlCaption="' + ltrim(rtrim(@ok_caption)) + '" ' + -- code modified by kiruthika for bugid :PNR2.0_28767 on 21-oct-2010
						'SectionName="' + ltrim(rtrim(isnull(@oksectionname_tmp, ''))) + '" ' + 'PageName="' + ltrim(rtrim(isnull(@mainpage_tmp, ''))) + '" ' + 'ILBOName="' + ltrim(rtrim(isnull(@ui_name_tmp, ''))) + '" ' + 'ActivityName="' + ltrim(rtrim(isnull(@activity_name, ''))) + '" ' + 'ComponentName="' + ltrim(rtrim(isnull(@engg_component, ''))) + '" ' +
						-- Code modified on 18-Feb-2009 for the Bug ID :: PNR2.0_21118 - Begin
						'ControlType="' + ltrim(rtrim('BUTTON')) + '" ' +
						-- Code modified on 18-Feb-2009 for the Bug ID :: PNR2.0_21118 - Ends
						'BaseControlType="' + ltrim(rtrim('BUTTON')) + '" ' + 'DataType="' + ltrim(rtrim('char')) + '" ' + 'DataLength="' + ltrim(rtrim('20')) + '" ' + 'DecimalLength="' + isnull(convert(VARCHAR, @decimal_length_ctrl), '') + '" ' + 'BTSynonym="' + ltrim(rtrim(isnull('OK', ''))) + '" ' + 'VisibleLength="' + ltrim(rtrim(CONVERT(VARCHAR, 10))) + '" ' + 'ProtoTooltip="' + ltrim(rtrim(isnull('OK', ''))) + '" ' + 'SampleData="' + '' + '" ' + 'HOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, isnull(2, 0)), 3))) + '" ' + 'VOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, isnull(1, 0)), 3))) + '" ' + 'Mandatory="' + ltrim(rtrim(isnull('N', ''))) + '" ' + 'Visible="' + ltrim(rtrim(isnull('Y', ''))) + '" ' + 'Editable="' + ltrim(rtrim(isnull('Y', ''))) + 
'" ' + 'CaptionRequired="' + ltrim(rtrim(isnull('N', ''))) + '" ' + 'SelectFlag="' + ltrim(rtrim(isnull('N', ''))) + '" ' + 'ZoomRequired="' + ltrim(rtrim(isnull('N', ''))) + '" ' + 'DeleteFlag="' + ltrim(rtrim(isnull('N', ''))) + '" ' + 'HelpRequired="' 
+ ltrim(rtrim(isnull('N', ''))) + '" ' + 'EllipsesRequired="' + ltrim(rtrim(isnull('N', '')
							)) + '" ' + 'AssociatedTask="' + ltrim(rtrim(isnull('TRANSFER', ''))) + '" ' + 'DataColumnWidth="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(50, 0)))) + '" ' + 'LabelColumnWidth="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(50, 0)))) + '" ' + 'DataColumnScaleMode="' + ltrim(rtrim(isnull('%', ''))) + '" ' + 'LabelColumnScaleMode="' + ltrim(rtrim(isnull('%', ''))) + '" ' + 'CaptionWrap="' + ltrim(rtrim('N')) + '" ' + 'CaptionAlignment="' + ltrim(rtrim('CENTER')) + '" ' + 'CaptionPosition="' + ltrim(rtrim('CENTER')) + '" ' + 'ControlPosition="' + ltrim(rtrim('CENTER')) + '" ' + 'LabelClass="' + ltrim(rtrim(isnull(@label_class_tmp, ''))) + '" ' + 'ControlClass="' + ltrim(rtrim(isnull(@ctrl_class_tmp, ''))) + '" ' + 'PasswordChar="' + ltrim(rtrim(isnull(@password_char_tmp, 'N'))) + '" ' + 'TaskImageClass="' + ltrim(rtrim(isnull(@task_img_tmp, ''))) + '" ' + 'HelpImageClass="' + ltrim(rtrim(isnull(@help_img_tmp, ''))) + '" ' + 'Documentation="' + ltrim(rtrim(isnull('', ''))) + '" ' + 'OrderSequence="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(1, 0)))) + '" ' + 'VisibleRows="' + ltrim(rtrim(
								CONVERT(VARCHAR, isnull(1, 0)))) + '" ' + 'HTMLTextArea="' + ltrim(rtrim(isnull(@html_text_area, 'N'))) + '" ' + 'SpinRequired="' + ltrim(rtrim(isnull(@spin_required, 'N'))) + '" ' + 'SpinUpImage="' + ltrim(rtrim(isnull(@spin_up_image, 'spinup.gif
'))) + '" ' + 'SpinDownImage="' + ltrim(rtrim(isnull(@spin_down_image, 'spindown.gif'))) + '" ' + 'AssociatedSpinControl="' + ltrim(rtrim(isnull(@associated_spin_ctrl, ''))) + '" ' + 'AssociatedSpinTask="' + ltrim(rtrim(isnull(@associated_spin_task, '')))
 + '" ' + 'HelpText="' + ltrim(rtrim(isnull(@helptext, ''))) + '" ' + 'ModelSectionName="' + ltrim(rtrim(isnull(@oksectionname_tmp, ''))) + '" ' +
						-- Inplace Calendar and Edit Mask Feature added by Feroz -- Start
						'InPlaceCalendar="' + ltrim(rtrim(isnull(@InPlaceCalendar, 'n'))) + '" ' +
						-- Code modification for  PNR2.0_19426  starts
						'InCalDisplay="' + ltrim(rtrim(isnull(@InPlaceCal_Display, ''))) + '" ' + 'EditMask="' + ltrim(rtrim(isnull(@EditMaskPattern, ''))) + '" ' +
						-- Inplace Calendar and Edit Mask Feature added by Feroz -- End
						'TabIndex="' + ltrim(rtrim(@tab_seq)) + '" ' + 'AccessKey="' + ltrim(rtrim(isnull(@AccessKey, ''))) + '" ' + -- Added by Jeya For AccessKey
						-- Code modification for  PNR2.0_19426  ends
						-- Code addition for PNR2.0_21576 starts
						--Code modified by Balaji D for Bug ID PNR2.0_28889 on 01-Nov-2010 starts
						'GridLite="' + ltrim(rtrim(isnull(@gridlite, 'N'))) + '" ' +
						--Code modified by Balaji D for Bug ID PNR2.0_28889 on 01-Nov-2010 end
						-- Code addition for PNR2.0_21576 ends
						-- Code addition for PNR2.0_20849 starts
						'NoofLinesPerRow="' + ltrim(rtrim(isnull(@NoofLinesPerRow, ''))) + '" ' + 'RowHeight="' + ltrim(rtrim(isnull(@RowHeight, ''))) + '" ' +
						-- Added By Feroz
						'BulletLink="' + ltrim(rtrim(isnull(@bulletlink_req, 'N'))) + '" ' + 'ButtonCombo="' + ltrim(rtrim(isnull(@buttoncombo_req, 'N'))) + '" ' + 'DataAsCaption="' + ltrim(rtrim(isnull(@dataascaption, 'N'))) + '" ' + 'AssociatedList="' + ltrim(rtrim(isnull(@associatedlist_name, ''))) + '" ' + 'OnFocusTask="' + ltrim(rtrim(isnull(@onfocus_taskname, ''))) + '" ' + 'ListRefillTask="' + ltrim(rtrim(isnull(@listrefill_taskname, ''))) + '" ' + 'MappedListControlID="' + ltrim(rtrim(isnull(@mapped_list_controlid,
 ''))) + '" ' + 'MappedListViewName="' + ltrim(rtrim(isnull(@mapped_list_viewname, ''))) + '" ' + 'AttachDocument="' + ltrim(rtrim(isnull(@attach_document, 'N'))) + '" ' + 'ImageUpload="' + ltrim(rtrim(isnull(@image_upload, 'N'))) + '" ' + 'InplaceImage="
' + ltrim(rtrim(isnull(@inplace_image, 'N'))) + '" ' + 'ImageIcon="' + ltrim(rtrim(isnull(@image_icon, 'N'))) + '" ' + 'ImageRowHeight="' + ltrim(rtrim(isnull(@image_row_height, '0'))) + '" ' + 'RelativeUrlPath="' + ltrim(rtrim(isnull(@relative_url_path, 
''))) + '" ' + 'RelativeDocumentPath="' + ltrim(rtrim(isnull(
									@relative_document_path, ''))) + '" ' + 'RelativeImagePath="' + ltrim(rtrim(isnull(@relative_image_path, ''))) + '" ' + 'SaveDocContentToDb="' + ltrim(rtrim(isnull(@save_doc_content_to_db, 'N'))) + '" ' + 'SaveImageContentToDb="' + ltrim(rtrim(isnull(@save_image_content_to_db, 'N'))) + '" ' + 'DateHighlight="' + ltrim(rtrim(isnull(@date_highlight_req, 'N'))) + '" ' + 'LinkedHiddenViewName="' + ltrim(rtrim(isnull(@hidden_view_name, ''))) + '" ' + 'Vscrollbar_Req="' + ltrim(rtrim(isnull(@Vscrollbar_Req, 'N'))) + '" LiteAttach="' + Isnull(@Lite_Attach, 'N') + '" Browse_Button="' + Isnull(@BrowseButton, 'N') + '" Delete_Button="' + Isnull(@DeleteButton, 'N') + '" ' + --PNR2.0_28365 -- Code Modified For BUGID PNR2.0_28537
						'IsITK="N"  FC="' + CONVERT(VARCHAR, isnull(@freezecount, 0), 4) + '" ' +
						--code added for the caseid : PNR2.0_28319 starts
						'image_row_width="' + CONVERT(VARCHAR, isnull(@image_row_width, 0), 4) + '" ' + 'image_preview_height="' + CONVERT(VARCHAR, isnull(@image_preview_height, 0), 4) + '" ' + 'image_preview_width="' + CONVERT(VARCHAR, isnull(@image_preview_width, 0), 4) 
+ '" ' + 'image_preview_req="' + isnull(@image_preview_req, 'N') + '" ' + 'Accept_Type="' + isnull(@Accept_Type, '') + '" ' + 'Lite_Attach_Image="' + isnull(@Lite_Attach_Image, 'N') + '" ' + --commented for PNR2.0_28376
						'LabelLink="' + isnull(@LabelLink, 'N') + '" ' + --added for PNR2.0_26860, PNR2.0_27796,PNR2.0_36309
						-- Code addition for PNR2.0_20849 ends
						--code added for the caseid : PNR2.0_28319 ends
						--Code Added for the Bug ID: PLF2.0_00961 starts
						--'PopUpPage="'           +   isnull(@popup_page,'')                  +'" ' +
						--'PopUpSection="'        +   isnull(@popup_section,'')               +'" ' +
						--'PopUpClose="'          +   isnull(@popup_Close,'N')                +'" ' +
						'CaptionType="' + isnull(@captiontype, '') + '" ' + 'ControlStyle="' + isnull(@controlstyle, '') + '" ' + 'ControlImage="' + isnull(@controlimage, '') + '" ' + 'IsListBox="' + isnull(@IsListBox, '') + '" ' + 'Toolbar_Not_Req="' + isnull(@Toolbar_Not_Req, '') + '" ' + 'ColumnBorder_Not_Req="' + isnull(@ColumnBorder_Not_Req, '') + '" ' + 'RowBorder_Not_Req="' + isnull(@RowBorder_Not_Req, '') + '" ' + 'PageNavigation_Only="' + isnull(@PagenavigationOnly, '') + '" ' + 'RowNo_Not_Req="' + isnull(@RowNo_Not_Req, '') + '" ' + 'ExtType="' + isnull(@ExtType, '') + '" ' + 'ColSpan="' + CONVERT(VARCHAR, isnull(@ControlColSpan, ''), 4) + '" ' + 'RowSpan="' + CONVERT(VARCHAR, isnull(@ControlRowSpan, ''), 4) + '" ' + 'Tooltip_Not_Req="' + CONVERT(VARCHAR, isnull(@Tooltip_Not_Req, ''), 4) + '" ' + 'GridHeader_Not_Req="' + CONVERT(VARCHAR, isnull(@columncaption_Not_Req, ''), 4) + '" ' + 'Border_Not_Req="' + CONVERT(VARCHAR, isnull(@Border_Not_Req, ''), 4) + '" ' + 'IsModal="' + CONVERT(VARCHAR, isnull(@IsModal, '')
, 4) + '" ' + 'Alternate_Color_Req="' + CONVERT(VARCHAR, isnull(@Alternate_Color_Req, '')
							, 4) + '" ' + 'Map_In_Req="' + CONVERT(VARCHAR, isnull(@Map_In_Req, ''), 4) + '" ' + 'Map_Out_Req="' + CONVERT(VARCHAR, isnull(@Map_Out_Req, ''), 4) + '" ' + 'IsCallout="' + isnull(@iscallout, '') + '" ' + 'SmartViewSection="' + isnull(@smartviewsection, '') + '" ' + 'SetScrollPosition="' + isnull(@preserveposition, '') + '" ' + -- added for Defect ID: TECH-18349
						'IsPivot="' + isnull(@ispivot, 'N') + '" ' + 'TemplateCategory="' + isnull(@TemplateCat, '') + '" ' + 'TemplateSpecification="' + isnull(@TemplateSpecific, '') + '" ' + 
						'SetFocusEvent="'	+ isnull(@setfocusevent,'')	 +'" ' + -- Added for TECH-37471 
						'LeaveFocusEvent="'	+ isnull(@leavefocusevent,'')	 +'" ' + -- Added for TECH-37471 
						'SetFocusEventOccurence="'	+ isnull(@setfocuseventoccur,'')	 +'" ' +  
						'LeaveFocusEventOccurence="'	+ isnull(@leavefocuseventoccur,'')	 +'" ' +  
						'MoreEvent="'	+ isnull(@MoreEventName,'')	 +'" ' + --TECH-45828
						'UPEEnabled="'	+ isnull(@UPEEnabled,'N')	 +'" ' + 
						'FileSize="' + isnull(@filesize, '') + '" />',
						@xml_seq_tmp
						)

					--Code Added for the Bug ID:PLF2.0_00961 ends
					SELECT @xml_seq_tmp = @xml_seq_tmp + 1

					INSERT INTO ep_genxml_tmp (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						activity_name,
						guid,
						gen_xml,
						seq_no
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@engg_req_no,
						@process_name,
						@engg_component,
						@activity_name,
						@guid,
						'<Control Name="' + 'OKLINE2' + '" ' + 'RenderAs="' + ltrim(rtrim(isnull(@renderas, ''))) + '" ' + 'ControlCaption="' + 'OKLINE2' + '" ' + 'SectionName="' + ltrim(rtrim(isnull(@oksectionname_tmp, ''))) + '" ' + 'PageName="' + ltrim(rtrim(isnull(@mainpage_tmp, ''))) + '" ' + 'ILBOName="' + ltrim(rtrim(isnull(@ui_name_tmp, ''))) + '" ' + 'ActivityName="' + ltrim(rtrim(isnull(@activity_name, ''))) + '" ' + 'ComponentName="' + ltrim(rtrim(isnull(@engg_component, ''))) + '" ' + 'ControlType="' + upper('Line') + '" ' + 'BaseControlType="' + 'LINE' + '" ' + 'DataType="' + 'char' + '" ' + 'DataLength="' + '20' + '" ' + 'DecimalLength="' + isnull(convert(VARCHAR, @decimal_length_ctrl), '') + '" ' + 'BTSynonym="' + 'OKLINE2' + '" ' + 'VisibleLength="' + ltrim
(rtrim(CONVERT(VARCHAR, 0))) + '" ' + 'ProtoTooltip="' + '' + '" ' + 'SampleData="' + '' + '" ' + 'DefaultSampleData="' + '' + '" ' + 'HOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, isnull(3, 0)), 3))) + '" ' + 'VOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, isnull(1, 0)), 3))) + '" ' + 'Mandatory="' + 'N' + '" ' + 'Visible="' + 'Y' + '" ' + 
						'Editable="' + 'N' + '" ' + 'CaptionRequired="' + 'N' + '" ' + 'SelectFlag="' + 'N' + '" ' + 'ZoomRequired="' + 'N' + '" ' + 'DeleteFlag="' + 'N' + '" ' + 'HelpRequired="' + 'N' + '" ' + 'EllipsesRequired="' + 'N' + '" ' + 'AssociatedTask="' + '' + 
'" ' + 'DataColumnWidth="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(0, 0)))) + '" ' + 'LabelColumnWidth="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(0, 0)))) + '" ' + 'DataColumnScaleMode="' + '%' + '" ' + 'LabelColumnScaleMode="' + '%' + '" ' + 'CaptionWrap="' 
+ 'N' + '" ' + 'CaptionAlignment="' + 'RIGHT' + '" ' + 'CaptionPosition="' + 'LEFT' + '" ' + 'ControlPosition="' + 'LEFT' + '" ' + 'LabelClass="' + '' + '" ' + 'ControlClass="' + '' + '" ' + 'PasswordChar="' + 'N' + '" ' + 'TaskImageClass="' + '' + '" ' +
 'HelpImageClass="' + '' + '" ' + 'Documentation="' + '' + '" ' + 'OrderSequence="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(1, 0)))) + '" ' + 'VisibleRows="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(1, 0)))) + '" ' + 'HTMLTextArea="' + '' + '" ' + 'SpinRequired="' + 'N' + '" ' + 'SpinUpImage="' + '' + '" ' + 'SpinDownImage="' + '' + '" ' + 'AssociatedSpinControl="' + '' + '" ' + 
						'AssociatedSpinTask="' + '' + '" ' + 'HelpText="' + ltrim(rtrim(isnull(@helptext, ''))) + '" ' + 'ReportRequired="' + 'N' + '" ' + 'ModelSectionName="' + ltrim(rtrim(isnull(@oksectionname_tmp, ''))) + '" ' +
						-- Inplace Calendar and Edit Mask Feature added by Feroz -- Start
						'InPlaceCalendar="' + ltrim(rtrim(isnull(@InPlaceCalendar, 'n'))) + '" ' +
						-- Code modification for  PNR2.0_19426  starts
						'InCalDisplay="' + ltrim(rtrim(isnull(@InPlaceCal_Display, ''))) + '" ' + 'EditMask="' + ltrim(rtrim(isnull(@EditMaskPattern, ''))) + '" ' +
						-- Inplace Calendar and Edit Mask Feature added by Feroz -- End
						'TabIndex="' + ltrim(rtrim(@tab_seq)) + '" ' + 'AccessKey="' + ltrim(rtrim(isnull(@AccessKey, ''))) + '" ' + -- Added by Jeya For AccessKey
						-- Code modification for  PNR2.0_19426  ends
						-- Code addition for PNR2.0_21576 starts
						--Code modified by Balaji D for Bug ID PNR2.0_28889 on 01-Nov-2010 starts
						'GridLite="' + ltrim(rtrim(isnull(@gridlite, 'N'))) + '" ' +
						--Code modified by Balaji D for Bug ID PNR2.0_28889 on 01-Nov-2010 end
						-- Code addition for PNR2.0_21576 ends
						-- Code addition for PNR2.0_20849 starts
						'NoofLinesPerRow="' + ltrim(rtrim(isnull(@NoofLinesPerRow, ''))) + '" ' + 'RowHeight="' + ltrim(rtrim(isnull(@RowHeight, ''))) + '" ' +
						-- Added By Feroz
						'BulletLink="' + ltrim(rtrim(isnull(@bulletlink_req, 'N'))) + '" ' + 'ButtonCombo="' + ltrim(rtrim(isnull(@buttoncombo_req, 'N'))) + '" ' + 'DataAsCaption="' + ltrim(rtrim(isnull(@dataascaption, 'N'))) + '" ' + 'AssociatedList="' + ltrim(rtrim(isnull(@associatedlist_name, ''))) + '" ' + 'OnFocusTask="' + ltrim(rtrim(isnull(@onfocus_taskname, ''))) + '" ' + 'ListRefillTask="' + ltrim(rtrim(isnull(@listrefill_taskname, ''))) + '" ' + 'MappedListControlID="' + ltrim(rtrim(isnull(@mapped_list_controlid,
 ''))) + '" ' + 'MappedListViewName="' + ltrim(rtrim(isnull(@mapped_list_viewname, ''))) + '" ' + 'AttachDocument="' + ltrim(rtrim(isnull(@attach_document, 'N'))) + '" ' + 'ImageUpload="' + ltrim(rtrim(isnull(@image_upload, 'N'))) + '" ' + 'InplaceImage="
' + ltrim(rtrim(isnull(@inplace_image, 'N'))) + '" ' + 'ImageIcon="' + ltrim(rtrim(isnull(@image_icon, 'N'))) + '" ' + 'ImageRowHeight="' + ltrim(rtrim(isnull(@image_row_height, '0'))) + '" ' + 'RelativeUrlPath="' + ltrim(rtrim(isnull(@relative_url_path, 
''))) + '" ' + 'RelativeDocumentPath="' + ltrim(rtrim(isnull(
									@relative_document_path, ''))) + '" ' + 'RelativeImagePath="' + ltrim(rtrim(isnull(@relative_image_path, ''))) + '" ' + 'SaveDocContentToDb="' + ltrim(rtrim(isnull(@save_doc_content_to_db, 'N'))) + '" ' + 'SaveImageContentToDb="' + ltrim(rtrim(isnull(@save_image_content_to_db, 'N'))) + '" ' + 'DateHighlight="' + ltrim(rtrim(isnull(@date_highlight_req, 'N'))) + '" ' + 'LinkedHiddenViewName="' + ltrim(rtrim(isnull(@hidden_view_name, ''))) + '" ' + 'Vscrollbar_Req="' + ltrim(rtrim(isnull(@Vscrollbar_Req, 'N'))) + '" LiteAttach="' + Isnull(@Lite_Attach, 'N') + '" Browse_Button="' + Isnull(@BrowseButton, 'N') + '" Delete_Button="' + Isnull(@DeleteButton, 'N') + '" ' + 'IsITK="N"  FC="' + CONVERT(VARCHAR, isnull(@freezecount, 0), 4) + '" ' + --PNR2.0_28365 -- Code Modified For BUGID PNR2.0_28537
						--code added for the caseid : PNR2.0_28319 starts
						'image_row_width="' + CONVERT(VARCHAR, isnull(@image_row_width, 0), 4) + '" ' + 'image_preview_height="' + CONVERT(VARCHAR, isnull(@image_preview_height, 0), 4) + '" ' + 'image_preview_width="' + CONVERT(VARCHAR, isnull(@image_preview_width, 0), 4) 
+ '" ' + 'image_preview_req="' + isnull(@image_preview_req, 'N') + '" ' + 'Accept_Type="' + isnull(@Accept_Type, '') + '" ' + 'Lite_Attach_Image="' + isnull(@Lite_Attach_Image, 'N') + '" ' + 'LabelLink="' + isnull(@LabelLink, 'N') + '" ' + --added for PNR2.0_26860, PNR2.0_27796,PNR2.0_36309
						-- Code addition for PNR2.0_20849 ends
						--code added for the caseid : PNR2.0_28319 ends
						--Code Added for the Bug ID: PLF2.0_00961 starts
						--'PopUpPage="'           +   isnull(@popup_page,'')                  +'" ' +
						--'PopUpSection="'        +   isnull(@popup_section,'')               +'" ' +
						--'PopUpClose="'          +   isnull(@popup_Close,'N')                +'" ' +
						'CaptionType="' + isnull(@captiontype, '') + '" ' + 'ControlStyle="' + isnull(@controlstyle, '') + '" ' + 'ControlImage="' + isnull(@controlimage, '') + '" ' + 'IsListBox="' + isnull(@IsListBox, '') + '" ' + 'Toolbar_Not_Req="' + isnull(@Toolbar_Not_Req, '') + '" ' + 'ColumnBorder_Not_Req="' + isnull(@ColumnBorder_Not_Req, '') + '" ' + 'RowBorder_Not_Req="' + isnull(@RowBorder_Not_Req, '') + '" ' + 'PageNavigation_Only="' + isnull(@PagenavigationOnly, '') + '" ' + 'RowNo_Not_Req="' + isnull(@RowNo_Not_Req, '') + '" ' + 'ExtType="' + isnull(@ExtType, '') + '" ' + 'ColSpan="' + CONVERT(VARCHAR, isnull(@ControlColSpan, ''), 4) + '" ' + 'RowSpan="' + CONVERT(VARCHAR, isnull(@ControlRowSpan, ''), 4) + '" ' + 'Tooltip_Not_Req="' + CONVERT(VARCHAR, isnull(@Tooltip_Not_Req, ''), 4) + '" ' + 'GridHeader_Not_Req="' + CONVERT(VARCHAR, isnull(@columncaption_Not_Req, ''), 4) + '" ' + 'Border_Not_Req="' + CONVERT(VARCHAR, isnull(@Border_Not_Req, ''), 4) + '" ' + 'IsModal="' + CONVERT(VARCHAR, isnull(@IsModal, '')
, 4) + '" ' + 'Alternate_Color_Req="' + CONVERT(VARCHAR, isnull(@Alternate_Color_Req, '')
							, 4) + '" ' + 'Map_In_Req="' + CONVERT(VARCHAR, isnull(@Map_In_Req, ''), 4) + '" ' + 'Map_Out_Req="' + CONVERT(VARCHAR, isnull(@Map_Out_Req, ''), 4) + '" ' + 'IsCallout="' + isnull(@iscallout, '') + '" ' + 'SmartViewSection="' + isnull(@smartviewsection, '') + '" ' + 'SetScrollPosition="' + isnull(@preserveposition, '') + '" ' + -- added for Defect ID: TECH-18349
						'FileSize="' + isnull(@filesize, '') + '" ' + 'IsPivot="' + isnull(@ispivot, 'N') + '" ' + 'TemplateCategory="' + isnull(@TemplateCat, '') + '" ' + 'TemplateSpecification="' + isnull(@TemplateSpecific, '') + '" ' + 'Orientation="' + isnull(@Orientation, 'Horizontal') + '" />',
						@xml_seq_tmp
						)
						--Code Added for the Bug ID:PLF2.0_00961 ends
				END
						--Code Added For Bug_id PNR2.0_17856 Ends Here
			END

			-- For Hidden controls
			IF @ctxt_service_in IN ('BulkGenerate')
				AND @pubflag = 'P'
			BEGIN
				DECLARE ctrlcurs INSENSITIVE CURSOR
				FOR
				SELECT upper(control_bt_synonym),
					isnull(bt_synonym_caption, control_bt_synonym),
					upper(control_id),
					control_type,
					upper(base_ctrl_type),
					upper(isnull(data_type, 'char')),
					isnull(length, 20),
					ctrl.horder,
					ctrl.vorder,
					isnull(visisble_length, 0),
					isnull(proto_tooltip, ''),
					isnull(sample_data, ''),
					upper(ctrl.page_bt_synonym),
					upper(ctrl.section_bt_synonym),
					upper(ltrim(rtrim(mandatory_flag))),
					upper(ltrim(rtrim(ctype.visisble_flag))),
					upper(ltrim(rtrim(editable_flag))),
					upper(ltrim(rtrim(caption_req))),
					upper(ltrim(rtrim(select_flag))),
					upper(ltrim(rtrim(zoom_req))),
					upper(ltrim(rtrim(help_req))),
					upper(ltrim(rtrim(ellipses_req))),
					isnull(visisble_rows, 0),
					upper(isnull(ctrl_position, 'LEFT')),
					upper(isnull(LabelClass, '')),
					upper(isnull(controlclass, '')),
					isnull(data_column_width, 0),
					isnull(label_column_width, 0),
					isnull(control_doc, ''),
					upper(isnull(caption_wrap, 'Y')),
					upper(isnull(caption_alignment, 'LEFT')),
					upper(isnull(caption_position, 'LEFT')),
					upper(isnull(delete_req, 'N')),
					upper(isnull(password_char, 'N')),
					upper(isnull(tskimg_class, '')),
					upper(isnull(hlpimg_class, '')),
					upper(isnull(data_column_scalemode, '%')),
					upper(isnull(label_column_scalemode, '%')),
					sec.horder,
					sec.vorder,
					upper(isnull(html_txt_area, 'N')),
					upper(isnull(Spin_required, 'N')),
					upper(isnull(spin_up_image, 'spinup.gif')),
					isnull(spin_down_image, 'spindown.gif'),
					--Code Modified for bugId : PNR2.0_11293
					isnull(report_req, 'N'),
					isnull(InPlace_Calendar, 'N'),
					isnull(EditMask, ''), -- Inplace Calendar and Edit Mask Feature added by Feroz
					isnull(AccessKey, ''), -- Added by Jeya
					-- Code addition for PNR2.0_20849 starts
					convert(VARCHAR, NoofLinesPerRow),
					isnull(convert(VARCHAR, RowHeight), ''),
					isnull(Vscrollbar_Req, 'N'),
					-- Code addition for PNR2.0_20849 ends
					-- Added By Feroz
					isnull(bulletlink_req, 'N'),
					isnull(buttoncombo_req, 'N'),
					isnull(associatedlist_req, 'N'),
					isnull(onfocustask_req, 'N'),
					isnull(listrefilltask_req, 'N'),
					isnull(dataascaption, 'N'),
					isnull(ListEdit_NoofColumns, 0),
					isnull(attach_document, 'N'),
					isnull(image_upload, 'N'),
					isnull(inplace_image, 'N'),
					isnull(image_row_height, 0),
					isnull(image_icon, 'N'),
					isnull(relative_url_path, ''),
					isnull(relative_document_path, ''),
					isnull(relative_image_path, ''),
					isnull(save_doc_content_to_db, 'N'),
					isnull(save_image_content_to_db, 'N'),
					isnull(Date_highlight, 'N'),
					-- Code addition for PNR2.0_21576 starts
					isnull(gridlite_req, 'N'),
					-- Code addition for PNR2.0_21576 ends
					isnull(freezecount, 0),
					isnull(Lite_Attach_Document, 'N'),
					isnull(Browse_Button_Enable, 'N'),
					isnull(Delete_Button_Enable, 'N'), --added for PNR2.0_26860 -- Code Modified for the Bug ID : PNR2.0_27796
					isnull(image_row_width, 0),
					isnull(image_preview_height, 0),
					isnull(image_preview_width, 0),
					isnull(image_preview_req, 'N'),
					isnull(Accpet_Type, ''),
					isnull(Lite_Attach_Image, 'N'), -- PNR2.0_28319
					isnull(Label_link, 'N'), --Code Added for the Bug ID PNR2.0_36309
					isnull(captiontype, 'Text'),
					isnull(controlstyle, 'Default'),
					isnull(controlimage, ''),
					isnull(FileSize, '') --Code added for Bug ID:PLF2.0_00961
				FROM ep_published_ui_control_dtl ctrl(NOLOCK),
					ep_published_ui_section_dtl sec(NOLOCK),
					@ep_published_comp_glossary_mst gls,
					es_comp_ctrl_type_mst_vw ctype(NOLOCK)
				WHERE ctrl.customer_name = sec.customer_name
					AND ctrl.project_name = sec.project_name
					AND ctrl.req_no = sec.req_no
					AND ctrl.process_name = sec.process_name
					AND ctrl.component_name = sec.component_name
					AND ctrl.activity_name = sec.activity_name
					AND ctrl.ui_name = sec.ui_name
					AND ctrl.page_bt_synonym = sec.page_bt_synonym
					AND ctrl.section_bt_synonym = sec.section_bt_synonym
					AND ctrl.customer_name = gls.customer_name
					AND ctrl.project_name = gls.project_name
					AND ctrl.req_no = gls.req_no
					AND ctrl.process_name = gls.process_name
					AND ctrl.component_name = gls.component_name
					AND ctrl.control_bt_synonym = gls.bt_synonym_name
					AND ctrl.customer_name = ctype.customer_name
					AND ctrl.project_name = ctype.project_name
					AND ctrl.process_name = ctype.process_name
					AND ctrl.component_name = ctype.component_name
					AND ctrl.control_type = ctype.ctrl_type_name
					AND sec.customer_name = @engg_customer_name
					AND sec.project_name = @engg_project_name
					AND sec.req_no = @engg_req_no
					AND sec.process_name = @process_name
					AND sec.component_name = @engg_component
					AND sec.activity_name = @activity_name
					AND sec.ui_name = @ui_name_tmp
					AND isnull(sec.section_type, 'MAIN') = 'MAIN'
					AND (
						ctype.visisble_flag = 'N'
						AND ctrl.control_type <> 'Filler'
						)
					AND isnull(ctype.Is_Extjs_Control, 'N') = 'N' -- Added By Feroz for extjs -- PNR2.0_1790
					--Code Modified For BugId : PNR2.0_9414
					--    or  ctype.base_ctrl_type = 'Label')
					--AND gls.languageid = @language_code
				
				UNION
				
				-- code modified by Ganesh  for the callid :: PNR2.0_3023 on 24/6/05
				SELECT upper(control_bt_synonym),
					isnull(bt_synonym_caption, control_bt_synonym),
					upper(control_id),
					control_type,
					upper(base_ctrl_type),
					upper(isnull(data_type, 'char')),
					isnull(length, 20),
					ctrl.horder,
					ctrl.vorder,
					isnull(visisble_length, 0),
					isnull(proto_tooltip, ''),
					isnull(sample_data, ''),
					upper(ctrl.page_bt_synonym),
					upper(ctrl.section_bt_synonym),
					upper(ltrim(rtrim(mandatory_flag))),
					upper(ltrim(rtrim(ctype.visisble_flag))),
					upper(ltrim(rtrim(editable_flag))),
					upper(ltrim(rtrim(caption_req))),
					upper(ltrim(rtrim(select_flag))),
					upper(ltrim(rtrim(zoom_req))),
					upper(ltrim(rtrim(help_req))),
					upper(ltrim(rtrim(ellipses_req))),
					isnull(visisble_rows, 0),
					upper(isnull(ctrl_position, 'LEFT')),
					upper(isnull(LabelClass, '')),
					upper(isnull(controlclass, '')),
					isnull(data_column_width, 0),
					isnull(label_column_width, 0),
					isnull(control_doc, ''),
					upper(isnull(caption_wrap, 'Y')),
					upper(isnull(caption_alignment, 'LEFT')),
					upper(isnull(caption_position, 'LEFT')),
					upper(isnull(delete_req, 'N')),
					upper(isnull(password_char, 'N')),
					upper(isnull(tskimg_class, '')),
					upper(isnull(hlpimg_class, '')),
					upper(isnull(data_column_scalemode, '%')),
					upper(isnull(label_column_scalemode, '%')),
					sec.horder,
					sec.vorder,
					upper(isnull(html_txt_area, 'N')),
					upper(isnull(Spin_required, 'N')),
					upper(isnull(spin_up_image, 'spinup.gif')),
					isnull(spin_down_image, 'spindown.gif'),
					--Code Modified for bugId : PNR2.0_11293
					isnull(report_req, 'N'),
					isnull(InPlace_Calendar, 'N'),
					isnull(EditMask, ''), -- Inplace Calendar and Edit Mask Feature added by Feroz
					isnull(AccessKey, ''), -- Added by Jeya
					-- Code addition for PNR2.0_20849 starts
					convert(VARCHAR, NoofLinesPerRow),
					isnull(convert(VARCHAR, RowHeight), ''),
					isnull(Vscrollbar_Req, 'N'),
					-- Code addition for PNR2.0_20849 ends
					-- Added By Feroz
					isnull(bulletlink_req, 'N'),
					isnull(buttoncombo_req, 'N'),
					isnull(associatedlist_req, 'N'),
					isnull(onfocustask_req, 'N'),
					isnull(listrefilltask_req, 'N'),
					isnull(dataascaption, 'N'),
					isnull(ListEdit_NoofColumns, 0),
					isnull(attach_document, 'N'),
					isnull(image_upload, 'N'),
					isnull(inplace_image, 'N'),
					isnull(image_row_height, 0),
					isnull(image_icon, 'N'),
					isnull(relative_url_path, ''),
					isnull(relative_document_path, ''),
					isnull(relative_image_path, ''),
					isnull(save_doc_content_to_db, 'N'),
					isnull(save_image_content_to_db, 'N'),
					isnull(Date_highlight, 'N'),
					-- Code addition for PNR2.0_21576 starts
					isnull(gridlite_req, 'N'),
					-- Code addition for PNR2.0_21576 ends
					isnull(freezecount, 0),
					isnull(Lite_Attach_Document, 'N'),
					isnull(Browse_Button_Enable, 'N'),
					isnull(Delete_Button_Enable, 'N'), --added for PNR2.0_26860 -- Code Modified for the Bug ID : PNR2.0_27796
					isnull(image_row_width, 0),
					isnull(image_preview_height, 0),
					isnull(image_preview_width, 0),
					isnull(image_preview_req, 'N'),
					isnull(Accpet_Type, ''),
					isnull(Lite_Attach_Image, 'N'), -- PNR2.0_28319
					isnull(Label_link, 'N'), --Code Added for the Bug ID PNR2.0_36309
					isnull(captiontype, 'Text'),
					isnull(controlstyle, 'Default'),
					isnull(controlimage, ''),
					isnull(FileSize, '') --Code added for Bug ID:PLF2.0_00961
				FROM ep_published_ui_control_dtl ctrl(NOLOCK),
					ep_published_ui_section_dtl sec(NOLOCK),
					@ep_published_comp_glossary_mst gls,
					es_comp_ctrl_type_mst_vw ctype(NOLOCK)
				WHERE ctrl.customer_name = sec.customer_name
					AND ctrl.project_name = sec.project_name
					AND ctrl.req_no = sec.req_no
					AND ctrl.process_name = sec.process_name
					AND ctrl.component_name = sec.component_name
					AND ctrl.activity_name = sec.activity_name
					AND ctrl.ui_name = sec.ui_name
					AND ctrl.page_bt_synonym = sec.page_bt_synonym
					AND ctrl.section_bt_synonym = sec.section_bt_synonym
					AND ctrl.customer_name = gls.customer_name
					AND ctrl.project_name = gls.project_name
					AND ctrl.req_no = gls.req_no
					AND ctrl.process_name = gls.process_name
					AND ctrl.component_name = gls.component_name
					AND ctrl.control_bt_synonym = gls.bt_synonym_name
					AND ctrl.customer_name = ctype.customer_name
					AND ctrl.project_name = ctype.project_name
					AND ctrl.process_name = ctype.process_name
					AND ctrl.component_name = ctype.component_name
					AND ctrl.control_type = ctype.ctrl_type_name
					AND sec.customer_name = @engg_customer_name
					AND sec.project_name = @engg_project_name
					AND sec.req_no = @engg_req_no
					AND sec.process_name = @process_name
					AND sec.component_name = @engg_component
					AND sec.activity_name = @activity_name
					AND sec.ui_name = @ui_name_tmp
					AND isnull(sec.section_type, 'MAIN') = 'MAIN'
					AND sec.visisble_flag = 'N'
					AND ctype.visisble_flag = 'Y'
					AND isnull(ctype.Is_Extjs_Control, 'N') = 'N' -- Added By Feroz for extjs -- PNR2.0_1790
					--AND gls.languageid = @language_code
				
				UNION
				
				SELECT upper(control_bt_synonym),
					isnull(bt_synonym_caption, control_bt_synonym),
					upper(control_id),
					control_type,
					upper(base_ctrl_type),
					upper(isnull(data_type, 'char')),
					isnull(length, 20),
					ctrl.horder,
					ctrl.vorder,
					isnull(visisble_length, 0),
					isnull(proto_tooltip, ''),
					isnull(sample_data, ''),
					upper(ctrl.page_bt_synonym),
					upper(ctrl.section_bt_synonym),
					upper(rtrim(mandatory_flag)),
					upper(rtrim(ctype.visisble_flag)),
					upper(rtrim(editable_flag)),
					upper(rtrim(caption_req)),
					upper(rtrim(select_flag)),
					upper(rtrim(zoom_req)),
					upper(rtrim(help_req)),
					upper(rtrim(ellipses_req)),
					isnull(visisble_rows, 0),
					upper(isnull(ctrl_position, 'LEFT')),
					upper(isnull(LabelClass, '')),
					upper(isnull(controlclass, '')),
					isnull(data_column_width, 0),
					isnull(label_column_width, 0),
					isnull(control_doc, ''),
					upper(isnull(caption_wrap, 'Y')),
					upper(isnull(caption_alignment, 'LEFT')),
					upper(isnull(caption_position, 'LEFT')),
					upper(isnull(delete_req, 'N')),
					upper(isnull(password_char, 'N')),
					upper(isnull(tskimg_class, '')),
					upper(isnull(hlpimg_class, '')),
					upper(isnull(data_column_scalemode, '%')),
					upper(isnull(label_column_scalemode, '%')),
					sec.horder,
					sec.vorder,
					upper(isnull(html_txt_area, 'N')),
					upper(isnull(Spin_required, 'N')),
					upper(isnull(spin_up_image, 'spinup.gif')),
					isnull(spin_down_image, 'spindown.gif'),
					--Code Modified for bugId : PNR2.0_11293
					isnull(report_req, 'N'),
					isnull(InPlace_Calendar, 'N'),
					isnull(EditMask, ''), -- Inplace Calendar and Edit Mask Feature added by Feroz
					isnull(AccessKey, ''), -- Added by Jeya
					-- Code addition for PNR2.0_20849 starts
					convert(VARCHAR, NoofLinesPerRow),
					isnull(convert(VARCHAR, RowHeight), ''),
					isnull(Vscrollbar_Req, 'N'),
					-- Code addition for PNR2.0_20849 ends
					-- Added By Feroz
					isnull(bulletlink_req, 'N'),
					isnull(buttoncombo_req, 'N'),
					isnull(associatedlist_req, 'N'),
					isnull(onfocustask_req, 'N'),
					isnull(listrefilltask_req, 'N'),
					isnull(dataascaption, 'N'),
					isnull(ListEdit_NoofColumns, 0),
					isnull(attach_document, 'N'),
					isnull(image_upload, 'N'),
					isnull(inplace_image, 'N'),
					isnull(image_row_height, 0),
					isnull(image_icon, 'N'),
					isnull(relative_url_path, ''),
					isnull(relative_document_path, ''),
					isnull(relative_image_path, ''),
					isnull(save_doc_content_to_db, 'N'),
					isnull(save_image_content_to_db, 'N'),
					isnull(Date_highlight, 'N'),
					-- Code addition for PNR2.0_21576 starts
					isnull(gridlite_req, 'N'),
					-- Code addition for PNR2.0_21576 ends
					isnull(freezecount, 0),
					isnull(Lite_Attach_Document, 'N'),
					isnull(Browse_Button_Enable, 'N'),
					isnull(Delete_Button_Enable, 'N'), --added for PNR2.0_26860 -- Code Modified for the Bug ID : PNR2.0_27796
					isnull(image_row_width, 0),
					isnull(image_preview_height, 0),
					isnull(image_preview_width, 0),
					isnull(image_preview_req, 'N'),
					isnull(Accpet_Type, ''),
					isnull(Lite_Attach_Image, 'N'), -- PNR2.0_28319
					isnull(Label_link, 'N'), --Code Added for the Bug ID PNR2.0_36309
					isnull(captiontype, 'Text'),
					isnull(controlstyle, 'Default'),
					isnull(controlimage, ''),
					isnull(FileSize, '') --Code added for Bug ID:PLF2.0_00961
				FROM ep_published_ui_control_dtl ctrl(NOLOCK),
					ep_published_ui_section_dtl sec(NOLOCK),
					@ep_published_comp_glossary_mst gls,
					es_comp_ctrl_type_mst_vw ctype(NOLOCK)
				WHERE ctrl.customer_name = sec.customer_name
					AND ctrl.project_name = sec.project_name
					AND ctrl.req_no = sec.req_no
					AND ctrl.process_name = sec.process_name
					AND ctrl.component_name = sec.component_name
					AND ctrl.activity_name = sec.activity_name
					AND ctrl.ui_name = sec.ui_name
					AND ctrl.page_bt_synonym = sec.page_bt_synonym
					AND ctrl.section_bt_synonym = sec.section_bt_synonym
					AND ctrl.customer_name = gls.customer_name
					AND ctrl.project_name = gls.project_name
					AND ctrl.req_no = gls.req_no
					AND ctrl.process_name = gls.process_name
					AND ctrl.component_name = gls.component_name
					AND ctrl.control_bt_synonym = gls.bt_synonym_name
					AND ctrl.customer_name = ctype.customer_name
					AND ctrl.project_name = ctype.project_name
					AND ctrl.process_name = ctype.process_name
					AND ctrl.component_name = ctype.component_name
					AND ctrl.control_type = ctype.ctrl_type_name
					AND sec.customer_name = @engg_customer_name
					AND sec.project_name = @engg_project_name
					AND sec.req_no = @engg_req_no
					AND sec.process_name = @process_name
					AND sec.component_name = @engg_component
					AND sec.activity_name = @activity_name
					AND sec.ui_name = @ui_name_tmp
					AND isnull(sec.section_type, 'MAIN') = 'MAIN'
					AND sec.section_bt_synonym = 'PRJHDNSECTION'
					--AND gls.languageid = @language_code
			END
			ELSE
			BEGIN
				DECLARE ctrlcurs INSENSITIVE CURSOR
				FOR
				SELECT upper(control_bt_synonym),
					isnull(bt_synonym_caption, control_bt_synonym),
					upper(control_id),
					control_type,
					upper(base_ctrl_type),
					upper(isnull(data_type, 'char')),
					isnull(length, 20),
					ctrl.horder,
					ctrl.vorder,
					isnull(visisble_length, 0),
					isnull(proto_tooltip, ''),
					isnull(sample_data, ''),
					upper(ctrl.page_bt_synonym),
					upper(ctrl.section_bt_synonym),
					upper(ltrim(rtrim(mandatory_flag))),
					upper(ltrim(rtrim(ctype.visisble_flag))),
					upper(ltrim(rtrim(editable_flag))),
					upper(ltrim(rtrim(caption_req))),
					upper(ltrim(rtrim(select_flag))),
					upper(ltrim(rtrim(zoom_req))),
					upper(ltrim(rtrim(help_req))),
					upper(ltrim(rtrim(ellipses_req))),
					isnull(visisble_rows, 0),
					upper(isnull(ctrl_position, 'LEFT')),
					upper(isnull(LabelClass, '')),
					upper(isnull(controlclass, '')),
					isnull(data_column_width, 0),
					isnull(label_column_width, 0),
					isnull(control_doc, ''),
					upper(isnull(caption_wrap, 'Y')),
					upper(isnull(caption_alignment, 'LEFT')),
					upper(isnull(caption_position, 'LEFT')),
					upper(isnull(delete_req, 'N')),
					upper(isnull(password_char, 'N')),
					upper(isnull(tskimg_class, '')),
					upper(isnull(hlpimg_class, '')),
					upper(isnull(data_column_scalemode, '%')),
					upper(isnull(label_column_scalemode, '%')),
					sec.horder,
					sec.vorder,
					upper(isnull(html_txt_area, 'N')),
					upper(isnull(Spin_required, 'N')),
					upper(isnull(spin_up_image, 'spinup.gif')),
					isnull(spin_down_image, 'spindown.gif'),
					--Code Modified for bugId : PNR2.0_11293
					isnull(report_req, 'N'),
					isnull(InPlace_Calendar, 'N'),
					isnull(EditMask, ''), -- Inplace Calendar and Edit Mask Feature added by Feroz
					isnull(AccessKey, ''), -- Added by Jeya
					-- Code addition for PNR2.0_20849 starts
					convert(VARCHAR, NoofLinesPerRow),
					isnull(convert(VARCHAR, RowHeight), ''),
					isnull(Vscrollbar_Req, 'N'),
					-- Code addition for PNR2.0_20849 ends
					-- Added By Feroz
					isnull(bulletlink_req, 'N'),
					isnull(buttoncombo_req, 'N'),
					isnull(associatedlist_req, 'N'),
					isnull(onfocustask_req, 'N'),
					isnull(listrefilltask_req, 'N'),
					isnull(dataascaption, 'N'),
					isnull(ListEdit_NoofColumns, 0),
					isnull(attach_document, 'N'),
					isnull(image_upload, 'N'),
					isnull(inplace_image, 'N'),
					isnull(image_row_height, 0),
					isnull(image_icon, 'N'),
					isnull(relative_url_path, ''),
					isnull(relative_document_path, ''),
					isnull(relative_image_path, ''),
					isnull(save_doc_content_to_db, 'N'),
					isnull(save_image_content_to_db, 'N'),
					isnull(Date_highlight, 'N'),
					-- Code addition for PNR2.0_21576 starts
					isnull(gridlite_req, 'N'),
					-- Code addition for PNR2.0_21576 ends
					isnull(freezecount, 0),
					isnull(Lite_Attach_Document, 'N'),
					isnull(Browse_Button_Enable, 'N'),
					isnull(Delete_Button_Enable, 'N'), --added for PNR2.0_26860 -- Code Modified for the Bug ID : PNR2.0_27796
					isnull(image_row_width, 0),
					isnull(image_preview_height, 0),
					isnull(image_preview_width, 0),
					isnull(image_preview_req, 'N'),
					isnull(Accpet_Type, ''),
					isnull(Lite_Attach_Image, 'N'), -- PNR2.0_28319
					isnull(Label_link, 'N'), --Code Added for the Bug ID PNR2.0_36309
					isnull(captiontype, 'Text'),
					isnull(controlstyle, 'Default'),
					isnull(controlimage, ''),
					isnull(FileSize, '') --Code added for Bug ID:PLF2.0_00961
				FROM ep_ui_control_dtl ctrl(NOLOCK),
					ep_ui_section_dtl sec(NOLOCK),
					@ep_component_glossary_mst gls,
					es_comp_ctrl_type_mst_vw ctype(NOLOCK)
				--     where ctrl.ui_section_sysid = sec.ui_section_sysid
				WHERE ctrl.customer_name = sec.customer_name
					AND ctrl.project_name = sec.project_name
					--PNR2.0_14358
					AND ctrl.req_no = sec.req_no
					AND ctrl.process_name = sec.process_name
					AND ctrl.component_name = sec.component_name
					AND ctrl.activity_name = sec.activity_name
					AND ctrl.ui_name = sec.ui_name
					AND ctrl.page_bt_synonym = sec.page_bt_synonym
					AND ctrl.section_bt_synonym = sec.section_bt_synonym
					AND ctrl.customer_name = gls.customer_name
					AND ctrl.project_name = gls.project_name
					AND ctrl.req_no = gls.req_no
					AND ctrl.process_name = gls.process_name
					AND ctrl.component_name = gls.component_name
					AND ctrl.control_bt_synonym = gls.bt_synonym_name
					AND ctrl.customer_name = ctype.customer_name
					AND ctrl.project_name = ctype.project_name
					AND ctrl.process_name = ctype.process_name
					AND ctrl.component_name = ctype.component_name
					AND ctrl.control_type = ctype.ctrl_type_name
					AND sec.customer_name = @engg_customer_name
					AND sec.project_name = @engg_project_name
					AND sec.process_name = @process_name
					AND sec.component_name = @engg_component
					AND sec.activity_name = @activity_name
					AND sec.ui_name = @ui_name_tmp
					AND isnull(sec.section_type, 'MAIN') = 'MAIN'
					AND (
						ctype.visisble_flag = 'N'
						AND ctrl.control_type <> 'Filler'
						)
					AND isnull(ctype.Is_Extjs_Control, 'N') = 'N' -- Added By Feroz for extjs -- PNR2.0_1790
					--Code Modified For BugId : PNR2.0_9414
					--    or  ctype.base_ctrl_type = 'Label')
					--AND gls.languageid = @language_code
				
				UNION
				
				-- code modified by Ganesh  for the callid :: PNR2.0_3023 on 24/6/05
				-- The Visible control in the hidden section has to be moved to the PRJHDNSECTION section
				SELECT upper(control_bt_synonym),
					isnull(bt_synonym_caption, control_bt_synonym),
					upper(control_id),
					control_type,
					upper(base_ctrl_type),
					upper(isnull(data_type, 'char')),
					isnull(length, 20),
					ctrl.horder,
					ctrl.vorder,
					isnull(visisble_length, 0),
					isnull(proto_tooltip, ''),
					isnull(sample_data, ''),
					upper(ctrl.page_bt_synonym),
					upper(ctrl.section_bt_synonym),
					upper(ltrim(rtrim(mandatory_flag))),
					upper(ltrim(rtrim(ctype.visisble_flag))),
					upper(ltrim(rtrim(editable_flag))),
					upper(ltrim(rtrim(caption_req))),
					upper(ltrim(rtrim(select_flag))),
					upper(ltrim(rtrim(zoom_req))),
					upper(ltrim(rtrim(help_req))),
					upper(ltrim(rtrim(ellipses_req))),
					isnull(visisble_rows, 0),
					upper(isnull(ctrl_position, 'LEFT')),
					upper(isnull(LabelClass, '')),
					upper(isnull(controlclass, '')),
					isnull(data_column_width, 0),
					isnull(label_column_width, 0),
					isnull(control_doc, ''),
					upper(isnull(caption_wrap, 'Y')),
					upper(isnull(caption_alignment, 'LEFT')),
					upper(isnull(caption_position, 'LEFT')),
					upper(isnull(delete_req, 'N')),
					upper(isnull(password_char, 'N')),
					upper(isnull(tskimg_class, '')),
					upper(isnull(hlpimg_class, '')),
					upper(isnull(data_column_scalemode, '%')),
					upper(isnull(label_column_scalemode, '%')),
					sec.horder,
					sec.vorder,
					upper(isnull(html_txt_area, 'N')),
					upper(isnull(Spin_required, 'N')),
					upper(isnull(spin_up_image, 'spinup.gif')),
					isnull(spin_down_image, 'spindown.gif'),
					--Code Modified for bugId : PNR2.0_11293
					isnull(report_req, 'N'),
					isnull(InPlace_Calendar, 'N'),
					isnull(EditMask, ''), -- Inplace Calendar and Edit Mask Feature added by Feroz
					isnull(AccessKey, ''), -- Added by Jeya
					-- Code addition for PNR2.0_20849 starts
					convert(VARCHAR, NoofLinesPerRow),
					isnull(convert(VARCHAR, RowHeight), ''),
					isnull(Vscrollbar_Req, 'N'),
					-- Code addition for PNR2.0_20849 ends
					-- Added By Feroz
					isnull(bulletlink_req, 'N'),
					isnull(buttoncombo_req, 'N'),
					isnull(associatedlist_req, 'N'),
					isnull(onfocustask_req, 'N'),
					isnull(listrefilltask_req, 'N'),
					isnull(dataascaption, 'N'),
					isnull(ListEdit_NoofColumns, 0),
					isnull(attach_document, 'N'),
					isnull(image_upload, 'N'),
					isnull(inplace_image, 'N'),
					isnull(image_row_height, 0),
					isnull(image_icon, 'N'),
					isnull(relative_url_path, ''),
					isnull(relative_document_path, ''),
					isnull(relative_image_path, ''),
					isnull(save_doc_content_to_db, 'N'),
					isnull(save_image_content_to_db, 'N'),
					isnull(Date_highlight, 'N'),
					-- Code addition for PNR2.0_21576 starts
					isnull(gridlite_req, 'N'),
					-- Code addition for PNR2.0_21576 ends
					isnull(freezecount, 0),
					isnull(Lite_Attach_Document, 'N'),
					isnull(Browse_Button_Enable, 'N'),
					isnull(Delete_Button_Enable, 'N'), --added for PNR2.0_26860 -- Code Modified for the Bug ID : PNR2.0_27796
					isnull(image_row_width, 0),
					isnull(image_preview_height, 0),
					isnull(image_preview_width, 0),
					isnull(image_preview_req, 'N'),
					isnull(Accpet_Type, ''),
					isnull(Lite_Attach_Image, 'N'), -- PNR2.0_28319
					isnull(Label_link, 'N'), --Code Added for the Bug ID PNR2.0_36309
					isnull(captiontype, 'Text'),
					isnull(controlstyle, 'Default'),
					isnull(controlimage, ''),
					isnull(FileSize, '') --Code added for Bug ID:PLF2.0_00961
				FROM ep_ui_control_dtl ctrl(NOLOCK),
					ep_ui_section_dtl sec(NOLOCK),
					@ep_component_glossary_mst gls,
					es_comp_ctrl_type_mst_vw ctype(NOLOCK)
				--     where ctrl.ui_section_sysid = sec.ui_section_sysid
				WHERE ctrl.customer_name = sec.customer_name
					AND ctrl.project_name = sec.project_name
					AND ctrl.req_no = sec.req_no
					AND ctrl.process_name = sec.process_name
					AND ctrl.component_name = sec.component_name
					AND ctrl.activity_name = sec.activity_name
					AND ctrl.ui_name = sec.ui_name
					AND ctrl.page_bt_synonym = sec.page_bt_synonym
					AND ctrl.section_bt_synonym = sec.section_bt_synonym
					AND ctrl.customer_name = gls.customer_name
					AND ctrl.project_name = gls.project_name
					AND ctrl.req_no = gls.req_no
					AND ctrl.process_name = gls.process_name
					AND ctrl.component_name = gls.component_name
					AND ctrl.control_bt_synonym = gls.bt_synonym_name
					AND ctrl.customer_name = ctype.customer_name
					AND ctrl.project_name = ctype.project_name
					AND ctrl.process_name = ctype.process_name
					AND ctrl.component_name = ctype.component_name
					AND ctrl.control_type = ctype.ctrl_type_name
					AND sec.customer_name = @engg_customer_name
					AND sec.project_name = @engg_project_name
					AND sec.process_name = @process_name
					AND sec.component_name = @engg_component
					AND sec.activity_name = @activity_name
					AND sec.ui_name = @ui_name_tmp
					AND isnull(sec.section_type, 'MAIN') = 'MAIN'
					AND sec.visisble_flag = 'N'
					AND ctype.visisble_flag = 'Y'
					AND isnull(ctype.Is_Extjs_Control, 'N') = 'N' -- Added By Feroz for extjs -- PNR2.0_1790
					--AND gls.languageid = @language_code
				
				UNION
				
				SELECT upper(control_bt_synonym),
					isnull(bt_synonym_caption, control_bt_synonym),
					upper(control_id),
					control_type,
					upper(base_ctrl_type),
					upper(isnull(data_type, 'char')),
					isnull(length, 20),
					ctrl.horder,
					ctrl.vorder,
					isnull(visisble_length, 0),
					isnull(proto_tooltip, ''),
					isnull(sample_data, ''),
					upper(ctrl.page_bt_synonym),
					upper(ctrl.section_bt_synonym),
					upper(rtrim(mandatory_flag)),
					upper(rtrim(ctype.visisble_flag)),
					upper(rtrim(editable_flag)),
					upper(rtrim(caption_req)),
					upper(rtrim(select_flag)),
					upper(rtrim(zoom_req)),
					upper(rtrim(help_req)),
					upper(rtrim(ellipses_req)),
					isnull(visisble_rows, 0),
					upper(isnull(ctrl_position, 'LEFT')),
					upper(isnull(LabelClass, '')),
					upper(isnull(controlclass, '')),
					isnull(data_column_width, 0),
					isnull(label_column_width, 0),
					isnull(control_doc, ''),
					upper(isnull(caption_wrap, 'Y')),
					upper(isnull(caption_alignment, 'LEFT')),
					upper(isnull(caption_position, 'LEFT')),
					upper(isnull(delete_req, 'N')),
					upper(isnull(password_char, 'N')),
					upper(isnull(tskimg_class, '')),
					upper(isnull(hlpimg_class, '')),
					upper(isnull(data_column_scalemode, '%')),
					upper(isnull(label_column_scalemode, '%')),
					sec.horder,
					sec.vorder,
					'N',
					upper(isnull(Spin_required, 'N')),
					upper(isnull(spin_up_image, 'spinup.gif')),
					isnull(spin_down_image, 'spindown.gif'),
					--Code Modified for bugId : PNR2.0_11293
					isnull(report_req, 'N'),
					isnull(InPlace_Calendar, 'N'),
					isnull(EditMask, ''), -- Inplace Calendar and Edit Mask Feature added by Feroz
					isnull(AccessKey, ''), -- Added by Jeya
					-- Code addition for PNR2.0_20849 starts
					convert(VARCHAR, NoofLinesPerRow),
					isnull(convert(VARCHAR, RowHeight), ''),
					isnull(Vscrollbar_Req, 'N'),
					-- Code addition for PNR2.0_20849 ends
					-- Added By Feroz
					isnull(bulletlink_req, 'N'),
					isnull(buttoncombo_req, 'N'),
					isnull(associatedlist_req, 'N'),
					isnull(onfocustask_req, 'N'),
					isnull(listrefilltask_req, 'N'),
					isnull(dataascaption, 'N'),
					isnull(ListEdit_NoofColumns, 0),
					isnull(attach_document, 'N'),
					isnull(image_upload, 'N'),
					isnull(inplace_image, 'N'),
					isnull(image_row_height, 0),
					isnull(image_icon, 'N'),
					isnull(relative_url_path, ''),
					isnull(relative_document_path, ''),
					isnull(relative_image_path, ''),
					isnull(save_doc_content_to_db, 'N'),
					isnull(save_image_content_to_db, 'N'),
					isnull(Date_highlight, 'N'),
					-- Code addition for PNR2.0_21576 starts
					isnull(gridlite_req, 'N'),
					-- Code addition for PNR2.0_21576 ends
					isnull(freezecount, 0),
					isnull(Lite_Attach_Document, 'N'),
					isnull(Browse_Button_Enable, 'N'),
					isnull(Delete_Button_Enable, 'N'), --added for PNR2.0_26860 -- Code Modified for the Bug ID : PNR2.0_27796
					isnull(image_row_width, 0),
					isnull(image_preview_height, 0),
					isnull(image_preview_width, 0),
					isnull(image_preview_req, 'N'),
					isnull(Accpet_Type, ''),
					isnull(Lite_Attach_Image, 'N'), -- PNR2.0_28319
					isnull(Label_link, 'N'), --Code Added for the Bug ID PNR2.0_36309
					isnull(captiontype, 'Text'),
					isnull(controlstyle, 'Default'),
					isnull(controlimage, ''),
					isnull(FileSize, '') --Code added for Bug ID:PLF2.0_00961
				FROM ep_ui_control_dtl ctrl(NOLOCK),
					ep_ui_section_dtl sec(NOLOCK),
					@ep_component_glossary_mst gls,
					es_comp_ctrl_type_mst_vw ctype(NOLOCK)
				--     where ctrl.ui_section_sysid = sec.ui_section_sysid
				WHERE ctrl.customer_name = sec.customer_name
					AND ctrl.project_name = sec.project_name
					--PNR2.0_14358
					AND ctrl.req_no = sec.req_no
					AND ctrl.process_name = sec.process_name
					AND ctrl.component_name = sec.component_name
					AND ctrl.activity_name = sec.activity_name
					AND ctrl.ui_name = sec.ui_name
					AND ctrl.page_bt_synonym = sec.page_bt_synonym
					AND ctrl.section_bt_synonym = sec.section_bt_synonym
					AND ctrl.customer_name = gls.customer_name
					AND ctrl.project_name = gls.project_name
					AND ctrl.req_no = gls.req_no
					AND ctrl.process_name = gls.process_name
					AND ctrl.component_name = gls.component_name
					AND ctrl.control_bt_synonym = gls.bt_synonym_name
					AND ctrl.customer_name = ctype.customer_name
					AND ctrl.project_name = ctype.project_name
					AND ctrl.process_name = ctype.process_name
					AND ctrl.component_name = ctype.component_name
					AND ctrl.control_type = ctype.ctrl_type_name
					AND sec.customer_name = @engg_customer_name
					AND sec.project_name = @engg_project_name
					AND sec.process_name = @process_name
					AND sec.component_name = @engg_component
					AND sec.activity_name = @activity_name
					AND sec.ui_name = @ui_name_tmp
					AND isnull(sec.section_type, 'MAIN') = 'MAIN'
					AND sec.section_bt_synonym = 'PRJHDNSECTION'
					--AND gls.languageid = @language_code
			END

			-- Set Previous Section Name as blank
			SELECT @previous_section_tmp = '',
				@position_vindex_tmp = 0,
				@transformed_horder_tmp = 1,
				@transformed_vorder_tmp = 0

			-- For each Control generate entries
			OPEN ctrlcurs

			WHILE (1 = 1)
			BEGIN
				FETCH NEXT
				FROM ctrlcurs
				INTO @control_bt_synonym_tmp,
					@ctrl_descr_tmp,
					@controlid_tmp,
					@control_type_tmp,
					@base_ctrl_type_tmp,
					@datatype_tmp,
					@datalength_tmp,
					@horder_tmp,
					@vorder_tmp,
					@visible_length_tmp,
					@proto_tooltip_tmp,
					@sample_data_tmp,
					@page_bt_synonym_tmp,
					@section_bt_synonym_tmp,
					@mandatory_flag_tmp,
					@visible_flag_tmp,
					@editable_flag_tmp,
					@caption_req_tmp,
					@select_flag_tmp,
					@zoom_req_tmp,
					@help_req_tmp,
					@ellipses_req_tmp,
					@visible_rows_tmp,
					@ctrl_position_tmp,
					@label_class_tmp,
					@ctrl_class_tmp,
					@data_column_width_tmp,
					@label_column_width_tmp,
					@controldoc_tmp,
					@caption_wrap_tmp,
					@caption_alignment_tmp,
					@caption_position_tmp,
					@delete_flag_tmp,
					@password_char_tmp,
					@task_img_tmp,
					@help_img_tmp,
					@data_column_scalemode,
					@label_column_scalemode,
					@tab_sec_horder,
					@tab_sec_vorder,
					@html_text_area,
					@spin_required,
					@spin_up_image,
					--Code Modified for bugId : PNR2.0_11293
					@spin_down_image,
					@report_reqd,
					@InPlaceCalendar,
					@EditMaskPattern, -- Inplace Calendar and Edit Mask Feature added by Feroz
					@AccessKey, -- Added By Jeya
					-- Code addition for PNR2.0_20849 starts
					@NoofLinesPerRow,
					@RowHeight,
					@Vscrollbar_Req,
					-- Code addition for PNR2.0_20849 ends
					-- Added By Feroz
					@bulletlink_req,
					@buttoncombo_req,
					@associatedlist_req,
					@onfocustask_req,
					@listrefilltask_req,
					@dataascaption,
					@listedit_NoofColumns,
					@attach_document,
					@image_upload,
					@inplace_image,
					@image_row_height,
					@image_icon,
					@relative_url_path,
					@relative_document_path,
					@relative_image_path,
					@save_doc_content_to_db,
					@save_image_content_to_db,
					@Date_highlight_req,
					-- Code addition for PNR2.0_21576 starts
					@gridlite,
					@freezecount,
					@Lite_Attach,
					@BrowseButton,
					@DeleteButton, --added for PNR2.0_26860 -- Code Modified for the Bug ID : PNR2.0_27796
					@image_row_width,
					@image_preview_height,
					@image_preview_width,
					@image_preview_req,
					@Accept_Type,
					@Lite_Attach_Image, --PNR2.0_28319-- Code addition for PNR2.0_21576 ends
					@Labellink, --Code Added for the Bug ID PNR2.0_36309
					@captiontype,
					@controlstyle,
					@controlimage --Code added for Bug ID:PLF2.0_00961
					,
					@filesize

				IF @@fetch_status <> 0
					BREAK

				SELECT @Toolbar_Not_Req = 'N'

				SELECT @ColumnBorder_Not_Req = 'N'

				SELECT @RowBorder_Not_Req = 'N'

				SELECT @PagenavigationOnly = 'N'

				SELECT @RowNo_Not_Req = 'N'

				SELECT @ExtType = 'N'

				SELECT @ControlColSpan = ''

				SELECT @ControlRowSpan = ''

				SELECT @ToolTip_Not_Req = 'N'

				SELECT @columncaption_Not_Req = 'N'

				SELECT @Border_Not_Req = 'N'

				SELECT @IsModal = 'N'

				SELECT @Alternate_Color_Req = 'N'

				SELECT @Map_In_Req = 'N'

				SELECT @Map_Out_Req = 'N'

				SELECT @spin_up_image = '../Themes/' + @engg_stylesheet + '/images/' + @spin_up_image,
					@spin_down_image = '../Themes/' + @engg_stylesheet + '/images/' + @spin_down_image

				-- Start For Inplace Calender added by Feroz
				IF isnull(@InPlaceCalendar, 'N') = 'Y'
					AND @datatype_tmp = 'Date'
					SELECT @InPlaceCalendar = 'y'
				ELSE
					SELECT @InPlaceCalendar = 'n'

				IF isnull(@InPlaceCalendar, 'N') = 'Y'
					AND isnull(@editable_flag_tmp, 'N') = 'Y'
					SELECT @InPlaceCal_Display = 'y'
				ELSE
					SELECT @InPlaceCal_Display = 'n'

				-- end For Inplace Calender added by Feroz
				--Code added for Bug ID:PLF2.0_00961 starts
				SELECT @captiontype = replace(@captiontype, '&', '&amp;')

				SELECT @captiontype = replace(@captiontype, '<', '&lt;')

				SELECT @captiontype = replace(@captiontype, '>', '&gt;')

				SELECT @captiontype = replace(@captiontype, '"', '&quot;')

				SELECT @captiontype = CASE isnull(@controlstyle, '')
						WHEN 'Image'
							THEN ''
						ELSE @captiontype
						END

				--Code added for Bug ID:PLF2.0_00961 ends
				-- Added By feroz For Edit mask pattern -- start
				SELECT @EditMaskPattern = replace(@EditMaskPattern, '&', '&amp;')

				SELECT @EditMaskPattern = replace(@EditMaskPattern, '<', '&lt;')

				SELECT @EditMaskPattern = replace(@EditMaskPattern, '>', '&gt;')

				SELECT @EditMaskPattern = replace(@EditMaskPattern, '"', '&quot;')

				-- Added By feroz For Edit mask pattern -- end
				-- code added by Ganesh for the bugid PNR2.0_2026 on 18/4/05
				-- To include the tab index property
				--     if @editable_flag_tmp = 'Y' or
				--      ( @base_ctrl_type_tmp in ('CheckBox', 'Button', 'Combo', 'RadioButton', 'DataHyperLink', 'Link' ))
				--
				--     begin
				--      select @tab_seq_tmp = @tab_sec_horder * 1000 + @tab_sec_vorder * 100+ @horder_tmp * 10 + @vorder_tmp
				--
				--      if @set_first_tab =  @tab_seq_tmp
				--       begin
				--       select @tab_seq  = 1
				--       end
				--      else
				--       begin
				--       select @tab_seq  = @tab_seq_tmp
				--       end
				--
				--      select @tab_seq  = @tab_seq_tmp
				--     end
				--     else
				--     begin
				--      select @tab_seq = ''
				--     end
				SELECT @tab_seq = ''

				--Code Modified for bugId : PNR2.0_11293
				IF @report_reqd = ''
					OR @report_reqd IS NULL
					SELECT @report_reqd = 'N'

				--Code addition  for  PNR2.0_20049  starts
				SELECT @data_type_ctrl = ''

				SELECT @data_type_ctrl = bts.data_type
				FROM @ep_component_glossary_mst gls,
					de_business_term bts(NOLOCK)
				WHERE gls.customer_name = bts.customer_name
					AND gls.project_name = bts.project_name
					AND gls.process_name = bts.process_name
					AND gls.component_name = bts.component_name
					AND gls.bt_name = bts.bt_name
					AND gls.customer_name = @engg_customer_name
					AND gls.project_name = @engg_project_name
					AND gls.req_no = 'Base'
					AND gls.process_name = @process_name
					AND gls.component_name = @engg_component
					AND gls.bt_synonym_name = @control_bt_synonym_tmp
					--AND gls.languageid = @language_code

				IF isnull(@data_type_ctrl, '') = ''
				BEGIN
					SELECT @data_type_ctrl = gls.data_type
					FROM @ep_component_glossary_mst gls
					WHERE gls.customer_name = @engg_customer_name
						AND gls.project_name = @engg_project_name
						AND gls.req_no = 'Base'
						AND gls.process_name = @process_name
						AND gls.component_name = @engg_component
						AND gls.bt_synonym_name = @control_bt_synonym_tmp
						--AND gls.languageid = @language_code
				END

				IF @data_type_ctrl <> 'char'
					SELECT @ellipses_req_tmp = 'N'

				--Code addition  for  PNR2.0_20049  ends
				-- code added by Ganesh on 08/12/04 to Populate the decimal value for the numeric field
				IF @datatype_tmp = 'Numeric'
				BEGIN
					SELECT @decimal_length_ctrl = decimal_length
					FROM @ep_component_glossary_mst gls,
						de_business_term bts(NOLOCK),
						de_precision_type pt(NOLOCK)
					WHERE gls.customer_name = bts.customer_name
						AND gls.project_name = bts.project_name
						AND gls.process_name = bts.process_name
						AND gls.component_name = bts.component_name
						AND gls.bt_name = bts.bt_name
						AND bts.customer_name = pt.customer_name
						AND bts.project_name = pt.project_name
						AND bts.process_name = pt.process_name
						AND bts.component_name = pt.component_name
						AND bts.precision_type = pt.pt_name
						AND gls.customer_name = @engg_customer_name
						AND gls.project_name = @engg_project_name
						AND gls.process_name = @process_name
						AND gls.component_name = @engg_component
						AND gls.bt_synonym_name = @control_bt_synonym_tmp
						--AND gls.languageid = @language_code

					IF isnull(@decimal_length_ctrl, - 915) = - 915
					BEGIN
						SELECT @decimal_length_ctrl = 3
					END
				END
				ELSE
				BEGIN
					SELECT @decimal_length_ctrl = 0
				END

				-- Code Added By Feroz For List edit
				SELECT @associatedlist_name = '',
					@onfocus_taskname = '',
					@listrefill_taskname = '',
					@hidden_view_name = '',
					@mapped_list_controlid = '',
					@mapped_list_viewname = ''

				IF isnull(@date_highlight_req, 'N') = 'Y'
				BEGIN
					IF @pubflag = 'P'
					BEGIN
						SELECT TOP 1 @associatedlist_name = Upper(a.listedit_controlid)
						FROM ep_published_date_highlight_control_map a(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.req_no = @engg_req_no
							AND a.process_name = @process_name
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							AND a.page_bt_synonym = @page_bt_synonym_tmp
							AND a.section_bt_synonym = @section_bt_synonym_tmp
							AND a.control_bt_synonym = @control_bt_synonym_tmp

						SELECT @mapped_list_controlid = upper(controlid),
							@mapped_list_viewname = upper(viewname)
						FROM #maplist -- code modified by gopinath S for the call ID PNR2.0_24034
						WHERE activityname = @activity_name
							AND ilbocode = @ui_name_tmp
							AND listedit = @associatedlist_name
					END
					ELSE
					BEGIN
						SELECT TOP 1 @associatedlist_name = Upper(a.listedit_controlid)
						FROM ep_date_highlight_control_map a(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.process_name = @process_name
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							AND a.page_bt_synonym = @page_bt_synonym_tmp
							AND a.section_bt_synonym = @section_bt_synonym_tmp
							AND a.control_bt_synonym = @control_bt_synonym_tmp

						SELECT @mapped_list_controlid = upper(controlid),
							@mapped_list_viewname = upper(viewname)
						FROM #maplist -- code modified by gopinath S for the call ID PNR2.0_24034
						WHERE activityname = @activity_name
							AND ilbocode = @ui_name_tmp
							AND listedit = @associatedlist_name
					END
				END

				IF @pubflag = 'P'
				BEGIN
					IF EXISTS (
							SELECT 'x'
							FROM ep_published_date_highlight_control_map a(NOLOCK)
							WHERE a.customer_name = @engg_customer_name
								AND a.project_name = @engg_project_name
								AND a.req_no = @engg_req_no
								AND a.process_name = @process_name
								AND a.component_name = @engg_component
								AND a.activity_name = @activity_name
								AND a.ui_name = @ui_name_tmp
								AND a.listedit_synonym = @control_bt_synonym_tmp
							)
						SELECT @base_ctrl_type_tmp = 'LISTEDIT'
				END
				ELSE
				BEGIN
					IF EXISTS (
							SELECT 'x'
							FROM ep_date_highlight_control_map a(NOLOCK)
							WHERE a.customer_name = @engg_customer_name
								AND a.project_name = @engg_project_name
								AND a.process_name = @process_name
								AND a.component_name = @engg_component
								AND a.activity_name = @activity_name
								AND a.ui_name = @ui_name_tmp
								AND a.listedit_synonym = @control_bt_synonym_tmp
							)
						SELECT @base_ctrl_type_tmp = 'LISTEDIT'
				END

				IF isnull(@associatedlist_req, 'N') = 'Y'
				BEGIN
					IF @pubflag = 'P'
					BEGIN
						SELECT TOP 1 @associatedlist_name = upper(b.listedit_controlid)
						FROM ep_published_listedit_control_map a(NOLOCK),
							ep_published_listedit_column_dtl b(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.req_no = @engg_req_no
							AND a.process_name = @process_name
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							AND a.page_bt_synonym = @page_bt_synonym_tmp
							AND a.section_bt_synonym = @section_bt_synonym_tmp
							AND a.mapped_bt_synonym = @control_bt_synonym_tmp
							AND a.customer_name = b.customer_name
							AND a.project_name = b.project_name
							AND a.req_no = b.req_no
							AND a.process_name = b.process_name
							AND a.component_name = b.component_name
							AND a.activity_name = b.activity_name
							AND a.ui_name = b.ui_name
							AND a.listedit_synonym = b.listedit_synonym

						SELECT @mapped_list_controlid = upper(controlid),
							@mapped_list_viewname = upper(viewname)
						FROM #maplist -- code modified by gopinath S for the call ID PNR2.0_24034
						WHERE activityname = @activity_name
							AND ilbocode = @ui_name_tmp
							AND listedit = @associatedlist_name

						IF isnull(@onfocustask_req, 'N') = 'Y'
							SELECT @onfocus_taskname = task_name
							FROM ep_published_action_mst(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND req_no = @engg_req_no
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND task_descr = 'List Edit Onfocus Task'
								AND primary_control_bts = @control_bt_synonym_tmp

						IF isnull(@listrefilltask_req, 'N') = 'Y'
							SELECT @listrefill_taskname = task_name
							FROM ep_published_action_mst(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND req_no = @engg_req_no
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND task_descr = 'List Edit Refill Task'
								AND primary_control_bts = @control_bt_synonym_tmp
					END
					ELSE
					BEGIN
						SELECT TOP 1 @associatedlist_name = upper(b.listedit_controlid)
						FROM ep_listedit_control_map a(NOLOCK),
							ep_listedit_column_dtl b(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.process_name = @process_name
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							AND a.page_bt_synonym = @page_bt_synonym_tmp
							AND a.section_bt_synonym = @section_bt_synonym_tmp
							AND a.mapped_bt_synonym = @control_bt_synonym_tmp
							AND a.customer_name = b.customer_name
							AND a.project_name = b.project_name
							AND a.process_name = b.process_name
							AND a.component_name = b.component_name
							AND a.activity_name = b.activity_name
							AND a.ui_name = b.ui_name
							AND a.listedit_synonym = b.listedit_synonym

						SELECT @mapped_list_controlid = upper(controlid),
							@mapped_list_viewname = upper(viewname)
						FROM #maplist -- code modified by gopinath S for the call ID PNR2.0_24034
						WHERE activityname = @activity_name
							AND ilbocode = @ui_name_tmp
							AND listedit = @associatedlist_name

						IF isnull(@onfocustask_req, 'N') = 'Y'
							SELECT @onfocus_taskname = task_name
							FROM ep_action_mst(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND task_descr = 'List Edit Onfocus Task'
								AND primary_control_bts = @control_bt_synonym_tmp

						IF isnull(@listrefilltask_req, 'N') = 'Y'
							SELECT @listrefill_taskname = task_name
							FROM ep_action_mst(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND task_descr = 'List Edit Refill Task'
								AND primary_control_bts = @control_bt_synonym_tmp
					END
				END

				IF @pubflag = 'P'
				BEGIN
					IF EXISTS (
							SELECT 'x'
							FROM ep_published_listedit_column_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND req_no = @engg_req_no
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND listedit_synonym = @control_bt_synonym_tmp
							)
						SELECT @base_ctrl_type_tmp = 'LISTEDIT'
				END
				ELSE
				BEGIN
					IF EXISTS (
							SELECT 'x'
							FROM ep_listedit_column_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND listedit_synonym = @control_bt_synonym_tmp
							)
						SELECT @base_ctrl_type_tmp = 'LISTEDIT'
				END

				IF EXISTS (
						SELECT 'x'
						FROM es_comp_ctrl_type_mst(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @process_name
							AND component_name = @engg_component
							AND ctrl_type_name = @control_type_tmp
							AND (
								isnull(attach_document, 'N') = 'Y'
								OR isnull(image_upload, 'N') = 'Y'
								)
						)
				BEGIN
					SELECT @hidden_view_name = Upper(view_name)
					FROM de_hidden_view(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @process_name
						AND component_name = @engg_component
						AND activity_name = @activity_name
						AND ui_name = @ui_name_tmp
						AND page_name = @page_bt_synonym_tmp
						AND section_name = @section_bt_synonym_tmp
						AND control_bt_synonym = @control_bt_synonym_tmp
				END

				-- Code Added By Feroz For List edit
				-- Modified By feroz for bug id :PNR2.0_23654
				SELECT @visible_rows_tmp = visisble_rows
				FROM es_comp_ctrl_type_mst(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @process_name
					AND component_name = @engg_component
					AND ctrl_type_name = @control_type_tmp

				-- Modified By feroz for bug id :PNR2.0_23654
				--PNR2.0_15700
				SELECT @sample_data_tmp = replace(@sample_data_tmp, '&', '&amp;')

				SELECT @sample_data_tmp = replace(@sample_data_tmp, '<', '&lt;')

				SELECT @sample_data_tmp = replace(@sample_data_tmp, '>', '&gt;')

				SELECT @sample_data_tmp = replace(@sample_data_tmp, '"', '&quot;')

				SELECT @ctrl_descr_tmp = replace(@ctrl_descr_tmp, '&', '&amp;')

				SELECT @ctrl_descr_tmp = replace(@ctrl_descr_tmp, '<', '&lt;')

				SELECT @ctrl_descr_tmp = replace(@ctrl_descr_tmp, '>', '&gt;')

				SELECT @ctrl_descr_tmp = replace(@ctrl_descr_tmp, '"', '&quot;')

				--select @ctrl_descr_tmp = replace(@ctrl_descr_tmp,'--nocaption--','')
				--Code Modified for bugid : PNR2.0_11183
				SELECT @modelsectioname_tmp = @section_bt_synonym_tmp

				-------Hdn Grid	--  PLF2.0_18888    
				IF @base_ctrl_type_tmp <> 'Grid'
					SELECT @section_bt_synonym_tmp = 'PRJHDNSECTION',
						@uitaskname_tmp = ''

				IF @base_ctrl_type_tmp = 'Grid'
					SELECT @uitaskname_tmp = ''

				-------Hdn Grid  PLF2.0_18888    
				IF @transformed_vorder_tmp >= 6
				BEGIN
					SELECT @transformed_vorder_tmp = 0,
						@transformed_horder_tmp = @transformed_horder_tmp + 1
				END

				-- Check whether it is a new section
				IF @previous_section_tmp <> @section_bt_synonym_tmp
					SELECT @position_vindex_tmp = 0

				IF @previous_horder_tmp <> @horder_tmp
					SELECT @position_vindex_tmp = 0

				--code modified by kiruthika for bugid :PNR2.0_27888 on 24-8-2010 starts
				IF (
						@section_bt_synonym_tmp = 'PRJHDNSECTION'
						AND @controlid_tmp = 'HDNHDNRT_STCONTROL'
						)
				BEGIN
					IF @pubflag = 'C'
					BEGIN
						SELECT @sample_data_tmp = isnull(a.state_id, '')
						FROM ep_ui_state_task_dtl a(NOLOCK),
							ep_action_mst b(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.process_name = @process_name
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							AND isnull(a.state_id, '') <> ''
							AND a.customer_name = b.customer_name
							AND a.project_name = b.project_name
							AND a.process_name = b.process_name
							AND a.component_name = b.component_name
							AND a.activity_name = b.activity_name
							AND a.ui_name = b.ui_name
							AND a.task_name = b.task_name
							AND b.task_type = 'fetch'
					END
					ELSE
					BEGIN
						SELECT @sample_data_tmp = isnull(a.state_id, '')
						FROM ep_published_ui_state_task_dtl a(NOLOCK),
							ep_published_action_mst b(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.req_no = @engg_req_no
							AND a.process_name = @process_name
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							AND isnull(a.state_id, '') <> ''
							AND a.customer_name = b.customer_name
							AND a.project_name = b.project_name
							AND a.req_no = b.req_no
							AND a.process_name = b.process_name
							AND a.component_name = b.component_name
							AND a.activity_name = b.activity_name
							AND a.ui_name = b.ui_name
							AND a.task_name = b.task_name
							AND b.task_type = 'fetch'
					END
				END

				--code modified by kiruthika for bugid :PNR2.0_27888 on 24-8-2010 ends
				--Code added for Bug ID:PLF2.0_00961 starts
				IF @pubflag = 'P'
				BEGIN
					SELECT @popup_page = PopUp_page_bt_synonym,
						@popup_section = PopUp_section,
						@popup_close = PopUp_close,
						@iscallout = CASE iscallout
							WHEN 1
								THEN 'Y'
							ELSE 'N'
							END
					FROM ep_published_action_mst(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_req_no
						AND process_name = @process_name
						AND component_name = @engg_component
						AND activity_name = @activity_name
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = @page_bt_synonym_tmp
						AND primary_control_bts = @control_bt_synonym_tmp
				END
				ELSE
				BEGIN
					SELECT @popup_page = PopUp_page_bt_synonym,
						@popup_section = PopUp_section,
						@popup_close = PopUp_close,
						@iscallout = CASE iscallout
							WHEN 1
								THEN 'Y'
							ELSE 'N'
							END
					FROM ep_action_mst(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @process_name
						AND component_name = @engg_component
						AND activity_name = @activity_name
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = @page_bt_synonym_tmp
						AND primary_control_bts = @control_bt_synonym_tmp
				END

				--Code added for Bug ID:PLF2.0_00961 ends
				-- Insert Label Entry
				IF @base_ctrl_type_tmp IN (
						'Edit',
						'Combo',
						'Checkbox',
						'DataHyperLink'
						)
					AND @caption_req_tmp = 'Y'
				BEGIN
					SELECT @transformed_vorder_tmp = @transformed_vorder_tmp + 1

					SELECT @xml_seq_tmp = @xml_seq_tmp + 1

					SELECT @helptext = @ctrl_descr_tmp + ' - Datatype : ' + ltrim(rtrim(isnull(@datatype_tmp, ''))) + ' - MaxLength : ' + ltrim(rtrim(isnull(@datalength_tmp, '')))

					IF upper(isnull(@datatype_tmp, '')) = 'NUMERIC'
						SELECT @helptext = @helptext + ' - DecimalLength : ' + ltrim(rtrim(isnull(@datalength_tmp, '')))

					IF @auto_tab_stop = 'Y'
						SELECT @tab_seq_tmp = '' -- code added by gopinath S for the Bug ID PNR2.0_19995

					INSERT INTO ep_genxml_tmp (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						activity_name,
						guid,
						gen_xml,
						seq_no
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@engg_req_no,
						@process_name,
						@engg_component,
						@activity_name,
						@guid,
						'<Control Name="' + 'lbl' + ltrim(rtrim(@controlid_tmp)) + '" ' + 'RenderAs="' + ltrim(rtrim(isnull(@renderas, ''))) + '" ' + 'ControlCaption="' + ltrim(rtrim(@ctrl_descr_tmp)) + '" ' + 'SectionName="' + ltrim(rtrim(isnull(@section_bt_synonym_tmp, 
'PRJHDNSECTION'))) + '" ' + 'PageName="' + ltrim(rtrim(@page_bt_synonym_tmp)) + '" ' + 'ILBOName="' + ltrim(rtrim(@ui_name_tmp)) + '" ' + 'ActivityName="' + ltrim(rtrim(@activity_name)) + '" ' + 'ComponentName="' + ltrim(rtrim(@engg_component)) + '" ' + '
ControlType="' + ltrim(rtrim(upper(@control_type_tmp))) + '" ' + 'BTSynonym="' + ltrim(rtrim(isnull(@control_bt_synonym_tmp, ''))) + '" ' + 'BaseControlType="' + 'LABEL' + '" ' + -- Code modification  for  PNR2.0_23635
						--       'DataType="'   + ltrim(rtrim(isnull(@datatype_tmp,'')))         + '" ' +
						--       'DataLength="'   + ltrim(rtrim(isnull(@datalength_tmp,'')))         + '" ' +
						--       'DecimalLength="'  + isnull(convert(varchar, @decimal_length_ctrl),'')       + '" ' +
						-- code modified by Anuradha on 22-Mar-2006 for the Bug id :: PNR2.0_7393
						'DataType="' + CASE ltrim(rtrim(isnull(@base_ctrl_type_tmp, ''))) + '-' + ltrim(rtrim(isnull(@datatype_tmp, '')))
							WHEN 'COMBO-INTEGER'
								THEN ''
							ELSE ltrim(rtrim(isnull(@datatype_tmp, '')))
							END + '" ' + 'DataLength="' + CASE ltrim(rtrim(isnull(@base_ctrl_type_tmp, ''))) + '-' + ltrim(rtrim(isnull(@datatype_tmp, '')))
							WHEN 'COMBO-INTEGER'
								THEN ''
							ELSE ltrim(rtrim(isnull(@datalength_tmp, '')))
							END + '" ' + 'DecimalLength="' + CASE ltrim(rtrim(isnull(@base_ctrl_type_tmp, ''))) + '-' + ltrim(rtrim(isnull(@datatype_tmp, '')))
							WHEN 'COMBO-INTEGER'
								THEN ''
							ELSE isnull(convert(VARCHAR, @decimal_length_ctrl), '')
							END + '" ' +
						-- code modified by Anuradha on 22-Mar-2006 for the Bug id :: PNR2.0_7393
					'VisibleLength="' + ltrim(rtrim(CONVERT(VARCHAR, @visible_length_tmp))) + '" ' + 'ProtoTooltip="' + ltrim(rtrim(@proto_tooltip_tmp)) + '" ' + 'DefaultSampleData="' + ltrim(rtrim(@sample_data_tmp)) + '" ' + 'SampleData="' + ltrim(rtrim(@sample_data_tmp)) + '" ' + 'HOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, @transformed_horder_tmp), 3))) + '" ' + 'VOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, @transformed_vorder_tmp), 3))) + '" ' + 'Mandatory="' + ltrim(rtrim(@mandatory_flag_tmp)) + '" ' + 'Visible="' + ltrim(rtrim(@visible_flag_tmp)) + '" ' + 'Editable="' + ltrim(rtrim(@editable_flag_tmp)) + '" ' + 'CaptionRequired="' + ltrim(rtrim(@caption_req_tmp)) + '" ' + 'ControlPosition="' + ltrim(rtrim(isnull(@ctrl_position_tmp, 'LEFT'))) + '" ' + 'LabelClass="' + ltrim(rtrim(isnull(@label_class_tmp, ''))) + '" ' + 'ControlClass="' + ltrim(rtrim(isnull(@ctrl_class_tmp, ''))) + '" ' + 'SelectFlag="' + ltrim(rtrim(@select_flag_tmp)) + '" ' + 'DeleteFlag="' + ltrim(rtrim(isnull(@delete_flag_tmp, ''))) + '" ' + 'ZoomRequired="' + ltrim(rtrim(
							@zoom_req_tmp)) + '" ' + 'HelpRequired="' + ltrim(rtrim(@help_req_tmp)) + '" ' + 'EllipsesRequired="' + ltrim(rtrim(@ellipses_req_tmp)) + '" ' + 'AssociatedTask="' + ltrim(rtrim(isnull(@uitaskname_tmp, ''))) + '" ' + 'DataColumnWidth="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@data_column_width_tmp, 0)))) + '" ' + 'LabelColumnWidth="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@label_column_width_tmp, 0)))) + '" ' + 'DataColumnScaleMode="' + ltrim(rtrim(isnull(@data_column_scalemode, '%'))) + '" ' + 'LabelColumnScaleMode="' + ltrim(rtrim(isnull(@label_column_scalemode, '%'))) + '" ' + 'CaptionWrap="' + ltrim(rtrim(isnull(@caption_wrap_tmp, 'Y'))) + '" ' + 'CaptionAlignment="' + ltrim(rtrim(isnull(@caption_alignment_tmp, 'LEFT'))) + '" ' + 'CaptionPosition="' + ltrim(rtrim(isnull(@caption_position_tmp, 'LEFT'))) + '" ' + 'PasswordChar="' + ltrim(rtrim(isnull(@password_char_tmp, 'N'))) + '" ' + 'TaskImageClass="' + ltrim(rtrim(isnull(@task_img_tmp, ''))) + '" ' + 'HelpImageClass="' + ltrim(rtrim(isnull(@help_img_tmp, ''))) + '" ' + 'Documentation="' + ltrim
						(rtrim(isnull(@controldoc_tmp, ''))) + '" ' + 'OrderSequence="' + '1' + '" ' + 'VisibleRows="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@visible_rows_tmp, 0)))) + '" ' + -- code modified for BugID : PNR2.0_23999
						'HTMLTextArea="' + ltrim(rtrim(isnull(@html_text_area, 'N'))) + '" ' + 'SpinRequired="' + ltrim(rtrim(isnull(@spin_required, 'N'))) + '" ' + 'SpinUpImage="' + ltrim(rtrim(isnull(@spin_up_image, 'spinup.gif'))) + '" ' + 'SpinDownImage="' + ltrim(rtrim(isnull(@spin_down_image, 'spindown.gif'))) + '" ' + 'AssociatedSpinControl="' + ltrim(rtrim(isnull(@associated_spin_ctrl, ''))) + '" ' + 'AssociatedSpinTask="' + ltrim(rtrim(isnull(@associated_spin_task, ''))) + '" ' + 'HelpText="' + ltrim(rtrim(isnull(@helptext, ''))) + '" ' +
						--Code Modified for bugId : PNR2.0_11293
						'ReportRequired="' + ltrim(rtrim(isnull(@report_reqd, ''))) + '" ' +
						--Code Modified for bugid : PNR2.0_11183
						'ModelSectionName="' + ltrim(rtrim(isnull(@modelsectioname_tmp, ''))) + '" ' +
						-- Inplace Calendar and Edit Mask Feature added by Feroz -- Start
						'InPlaceCalendar="' + ltrim(rtrim(isnull(@InPlaceCalendar, 'n'))) + '" ' +
						-- Code modification for  PNR2.0_19426  starts
						'InCalDisplay="' + ltrim(rtrim(isnull(@InPlaceCal_Display, ''))) + '" ' + 'EditMask="' + ltrim(rtrim(isnull(@EditMaskPattern, ''))) + '" ' +
						-- Inplace Calendar and Edit Mask Feature added by Feroz -- End
						--       'TabIndex="'   + ltrim(rtrim(isnull(@tab_seq,0)))                        + '" ' +
						'TabIndex="' + ltrim(rtrim(@tab_seq_tmp)) + '" ' + -- code added by gopinath S for the Bug ID PNR2.0_19995
						'AccessKey="' + ltrim(rtrim(isnull(@AccessKey, ''))) + '" ' + -- Added By Jeya For Access Key
						-- Code modification for  PNR2.0_19426  ends
						-- Code addition for PNR2.0_21576 starts
						--Code modified by Balaji D for Bug ID PNR2.0_28889 on 01-Nov-2010 starts
						'GridLite="' + ltrim(rtrim(isnull(@gridlite, 'N'))) + '" ' +
						--Code modified by Balaji D for Bug ID PNR2.0_28889 on 01-Nov-2010 end
						-- Code addition for PNR2.0_21576 ends
						-- Code addition for PNR2.0_20849 starts
						'NoofLinesPerRow="' + ltrim(rtrim(isnull(@NoofLinesPerRow, ''))) + '" ' + 'RowHeight="' + ltrim(rtrim(isnull(@RowHeight, ''))) + '" ' +
						-- Added By Feroz
						'BulletLink="' + ltrim(rtrim(isnull(@bulletlink_req, 'N'))) + '" ' + 'ButtonCombo="' + ltrim(rtrim(isnull(@buttoncombo_req, 'N'))) + '" ' + 'DataAsCaption="' + ltrim(rtrim(isnull(@dataascaption, 'N'))) + '" ' + 'AssociatedList="' + ltrim(rtrim(isnull(@associatedlist_name, ''))) + '" ' + 'OnFocusTask="' + ltrim(rtrim(isnull(@onfocus_taskname, ''))) + '" ' + 'ListRefillTask="' + ltrim(rtrim(isnull(@listrefill_taskname, ''))) + '" ' + 'MappedListControlID="' + ltrim(rtrim(isnull(@mapped_list_controlid,
 ''))) + '" ' + 'MappedListViewName="' + ltrim(rtrim(isnull(@mapped_list_viewname, ''))) + '" ' + 'AttachDocument="' + ltrim(rtrim(isnull(@attach_document, 'N'))) + '" ' + 'ImageUpload="' + ltrim(rtrim(isnull(@image_upload, 'N'))) + '" ' + 'InplaceImage="
' + ltrim(rtrim(isnull(@inplace_image, 'N'))) + '" ' + 'ImageIcon="' + ltrim(rtrim(isnull(@image_icon, 'N'))) + '" ' + 'ImageRowHeight="' + ltrim(rtrim(isnull(@image_row_height, '0'))) + '" ' + 'RelativeUrlPath="' + ltrim(rtrim(isnull(@relative_url_path, 
''))) + '" ' + 'RelativeDocumentPath="' + ltrim(rtrim(isnull(
									@relative_document_path, ''))) + '" ' + 'RelativeImagePath="' + ltrim(rtrim(isnull(@relative_image_path, ''))) + '" ' + 'SaveDocContentToDb="' + ltrim(rtrim(isnull(@save_doc_content_to_db, 'N'))) + '" ' + 'SaveImageContentToDb="' + ltrim(rtrim(isnull(@save_image_content_to_db, 'N'))) + '" ' + 'DateHighlight="' + ltrim(rtrim(isnull(@date_highlight_req, 'N'))) + '" ' + 'LinkedHiddenViewName="' + ltrim(rtrim(isnull(@hidden_view_name, ''))) + '" ' + 'Vscrollbar_Req="' + ltrim(rtrim(isnull(@Vscrollbar_Req, 'N'))) + '" LiteAttach="' + Isnull(@Lite_Attach, 'N') + '" Browse_Button="' + Isnull(@BrowseButton, 'N') + '" Delete_Button="' + Isnull(@DeleteButton, 'N') + '" ' + --PNR2.0_28365 -- Code Modified For BUGID PNR2.0_28537
						'IsITK="N"  FC="' + CONVERT(VARCHAR, isnull(@freezecount, 0), 4) + '" ' +
						--code added for the caseid : PNR2.0_28319 starts
						'image_row_width="' + CONVERT(VARCHAR, isnull(@image_row_width, 0), 4) + '" ' + 'image_preview_height="' + CONVERT(VARCHAR, isnull(@image_preview_height, 0), 4) + '" ' + 'image_preview_width="' + CONVERT(VARCHAR, isnull(@image_preview_width, 0), 4) 
+ '" ' + 'image_preview_req="' + isnull(@image_preview_req, 'N') + '" ' + 'Accept_Type="' + isnull(@Accept_Type, '') + '" ' + 'Lite_Attach_Image="' + isnull(@Lite_Attach_Image, 'N') + '" ' + 'LabelLink="' + isnull(@LabelLink, 'N') + '" ' + --added for PNR2.0_26860, PNR2.0_27796,PNR2.0_36309
						-- Code addition for PNR2.0_20849 ends
						--code added for the caseid : PNR2.0_28319 ends
						--Code Added for the Bug ID: PLF2.0_00961 starts
						--'PopUpPage="'           +   isnull(@popup_page,'')                  +'" ' +
						--'PopUpSection="'        +   isnull(@popup_section,'')               +'" ' +
						--'PopUpClose="'          +   isnull(@popup_Close,'N')                +'" ' +
						'CaptionType="' + isnull(@captiontype, '') + '" ' + 'ControlStyle="' + isnull(@controlstyle, '') + '" ' + 'ControlImage="' + isnull(@controlimage, '') + '" ' + 'IsListBox="' + isnull(@IsListBox, '') + '" ' + 'Toolbar_Not_Req="' + isnull(@Toolbar_Not_Req, '') + '" ' + 'ColumnBorder_Not_Req="' + isnull(@ColumnBorder_Not_Req, '') + '" ' + 'RowBorder_Not_Req="' + isnull(@RowBorder_Not_Req, '') + '" ' + 'PageNavigation_Only="' + isnull(@PagenavigationOnly, '') + '" ' + 'RowNo_Not_Req="' + isnull(@RowNo_Not_Req, '') + '" ' + 'ExtType="' + isnull(@ExtType, '') + '" ' + 'ColSpan="' + CONVERT(VARCHAR, isnull(@ControlColSpan, ''), 4) + '" ' + 'RowSpan="' + CONVERT(VARCHAR, isnull(@ControlRowSpan, ''), 4) + '" ' + 'Tooltip_Not_Req="' + CONVERT(VARCHAR, isnull(@Tooltip_Not_Req, ''), 4) + '" ' + 'GridHeader_Not_Req="' + CONVERT(VARCHAR, isnull(@columncaption_Not_Req, ''), 4) + '" ' + 'Border_Not_Req="' + CONVERT(VARCHAR, isnull(@Border_Not_Req, ''), 4) + '" ' + 'IsModal="' + CONVERT(VARCHAR, isnull(@IsModal, ''), 4) + '" ' + 'Alternate_Color_Req="' + CONVERT(VARCHAR, isnull(@Alternate_Color_Req, '')
							, 4) + '" ' + 'Map_In_Req="' + CONVERT(VARCHAR, isnull(@Map_In_Req, ''), 4) + '" ' + 'Map_Out_Req="' + CONVERT(VARCHAR, isnull(@Map_Out_Req, ''), 4) + '" ' + 'IsCallout="' + isnull(@iscallout, '') + '" ' + 'SmartViewSection="' + isnull(@smartviewsection, '') + '" ' + 'FileSize="' + isnull(@filesize, '') + '" />',
						@xml_seq_tmp
						)

					--Code Added for the Bug ID:PLF2.0_00961 ends
					SELECT @position_vindex_tmp = @position_vindex_tmp + 1
				END

				SELECT @transformed_vorder_tmp = @transformed_vorder_tmp + 1

				IF @base_ctrl_type_tmp = 'Label'
					SELECT @control_type_tmp = 'Edit',
						@base_ctrl_type_tmp = 'Edit',
						@editable_flag_tmp = 'Y',
						@visible_flag_tmp = 'N'

				-- Insert Control Entry
				SELECT @xml_seq_tmp = @xml_seq_tmp + 1

				SELECT @helptext = @ctrl_descr_tmp + ' - Datatype : ' + ltrim(rtrim(isnull(@datatype_tmp, ''))) + ' - MaxLength : ' + ltrim(rtrim(isnull(@datalength_tmp, '')))

				IF upper(isnull(@datatype_tmp, '')) = 'NUMERIC'
					SELECT @helptext = @helptext + ' - DecimalLength : ' + ltrim(rtrim(isnull(@datalength_tmp, '')))

				INSERT INTO ep_genxml_tmp (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					activity_name,
					guid,
					gen_xml,
					seq_no
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@process_name,
					@engg_component,
					@activity_name,
					@guid,
					'<Control Name="' + ltrim(rtrim(@controlid_tmp)) + '" ' + 'RenderAs="' + ltrim(rtrim(isnull(@renderas, ''))) + '" ' + 'ControlCaption="' + ltrim(rtrim(@ctrl_descr_tmp)) + '" ' + 'SectionName="' + ltrim(rtrim(isnull(@section_bt_synonym_tmp, 'PRJHDNSECTION'))) + '" ' + 'PageName="' + ltrim(rtrim(@page_bt_synonym_tmp)) + '" ' + 'ILBOName="' + ltrim(rtrim(@ui_name_tmp)) + '" ' + 'ActivityName="' + ltrim(rtrim(@activity_name)) + '" ' + 'ComponentName="' + ltrim(rtrim(@engg_component)) + '" ' + 'ControlType="' + ltrim(rtrim(upper(@control_type_tmp))) + '" ' + 'BaseControlType="' + ltrim(rtrim(isnull(upper(@base_ctrl_type_tmp), ''))) + '" ' + -- Code modification  for  PNR2.0_23635
					'BTSynonym="' + ltrim(rtrim(isnull(@control_bt_synonym_tmp, ''))) + '" ' +
					--      'DataType="'   + ltrim(rtrim(isnull(@datatype_tmp,'')))         + '" ' +
					--      'DataLength="'   + ltrim(rtrim(isnull(@datalength_tmp,'')))         + '" ' +
					--      'DecimalLength="'  + isnull(convert(varchar, @decimal_length_ctrl),'')       + '" ' +
					-- code modified by Anuradha on 22-Mar-2006 for the Bug id :: PNR2.0_7393
					'DataType="' + CASE ltrim(rtrim(isnull(@base_ctrl_type_tmp, ''))) + '-' + ltrim(rtrim(isnull(@datatype_tmp, '')))
						WHEN 'COMBO-INTEGER'
							THEN ''
						ELSE ltrim(rtrim(isnull(@datatype_tmp, '')))
						END + '" ' + 'DataLength="' + CASE ltrim(rtrim(isnull(@base_ctrl_type_tmp, ''))) + '-' + ltrim(rtrim(isnull(@datatype_tmp, '')))
						WHEN 'COMBO-INTEGER'
							THEN ''
						ELSE ltrim(rtrim(isnull(@datalength_tmp, '')))
						END + '" ' + 'DecimalLength="' + CASE ltrim(rtrim(isnull(@base_ctrl_type_tmp, ''))) + '-' + ltrim(rtrim(isnull(@datatype_tmp, '')))
						WHEN 'COMBO-INTEGER'
							THEN ''
						ELSE isnull(convert(VARCHAR, @decimal_length_ctrl), '')
						END + '" ' +
					-- code modified by Anuradha on 22-Mar-2006 for the Bug id :: PNR2.0_7393
					'VisibleLength="' + ltrim(rtrim(CONVERT(VARCHAR, @visible_length_tmp))) + '" ' + 'ProtoTooltip="' + ltrim(rtrim(@proto_tooltip_tmp)) + '" ' + 'DefaultSampleData="' + ltrim(rtrim(@sample_data_tmp)) + '" ' + 'SampleData="' + ltrim(rtrim(@sample_data_tmp)) + '" ' + 'HOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, @transformed_horder_tmp), 3))) + '" ' + 'VOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, @transformed_vorder_tmp), 3))) + '" ' + 'Mandatory="' + ltrim(rtrim(@mandatory_flag_tmp)
) + '" ' + 'Visible="' + ltrim(rtrim(@visible_flag_tmp)) + '" ' + 'Editable="' + ltrim(rtrim(@editable_flag_tmp)) + '" ' + 'CaptionRequired="' + ltrim(rtrim(@caption_req_tmp)) + '" ' + 'ControlPosition="' + ltrim(rtrim(isnull(@ctrl_position_tmp, 'LEFT')))
 + '" ' + 'LabelClass="' + ltrim(rtrim(isnull(@label_class_tmp, ''))) + '" ' + 'ControlClass="' + ltrim(rtrim(isnull(@ctrl_class_tmp, ''))) + '" ' + 'SelectFlag="' + ltrim(rtrim(@select_flag_tmp)) + '" ' + 'DeleteFlag="' + ltrim(rtrim(isnull(@delete_flag_tmp, ''))) + '" ' + 'ZoomRequired="' + ltrim(rtrim(@zoom_req_tmp)
					) + '" ' + 'HelpRequired="' + ltrim(rtrim(@help_req_tmp)) + '" ' + 'EllipsesRequired="' + ltrim(rtrim(@ellipses_req_tmp)) + '" ' + 'AssociatedTask="' + ltrim(rtrim(isnull(@uitaskname_tmp, ''))) + '" ' + 'DataColumnWidth="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@data_column_width_tmp, 0)))) + '" ' + 'LabelColumnWidth="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@label_column_width_tmp, 0)))) + '" ' + 'DataColumnScaleMode="' + ltrim(rtrim(isnull(@data_column_scalemode, '%'))) + '" ' + 'LabelColumnScaleMode="' + ltrim(rtrim(isnull(@label_column_scalemode, '%'))) + '" ' +
					--Code Modified For BugId : PNR2.0_7273
					'CaptionWrap="' + ltrim(rtrim(isnull(@caption_wrap_tmp, 'Y'))) + '" ' + 'CaptionAlignment="' + ltrim(rtrim(isnull(@caption_alignment_tmp, 'LEFT'))) + '" ' + 'CaptionPosition="' + ltrim(rtrim(isnull(@caption_position_tmp, 'LEFT'))) + '" ' + 'PasswordChar="' + ltrim(rtrim(isnull(@password_char_tmp, 'N'))) + '" ' + 'TaskImageClass="' + ltrim(rtrim(isnull(@task_img_tmp, ''))) + '" ' + 'HelpImageClass="' + ltrim(rtrim(isnull(@help_img_tmp, ''))) + '" ' + 'Documentation="' + ltrim(rtrim(isnull(@controldoc_tmp, ''))) + '" ' + 'OrderSequence="' + '1' + '" ' + 'VisibleRows="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@visible_rows_tmp, 0)))) + '" ' + -- code modified for BugID : PNR2.0_23999
					'HTMLTextArea="' + ltrim(rtrim(isnull(@html_text_area, 'N'))) + '" ' + 'SpinRequired="' + ltrim(rtrim(isnull(@spin_required, 'N'))) + '" ' + 'SpinUpImage="' + ltrim(rtrim(isnull(@spin_up_image, 'spinup.gif'))) + '" ' + 'SpinDownImage="' + ltrim(rtrim
(isnull(@spin_down_image, 'spindown.gif'))) + '" ' + 'AssociatedSpinControl="' + ltrim(rtrim(isnull(@associated_spin_ctrl, ''))) + '" ' + 'AssociatedSpinTask="' + ltrim(rtrim(isnull(@associated_spin_task, ''))) + '" ' + 'HelpText="' + ltrim(rtrim(isnull(@helptext, ''))) + '" ' +
					--Code Modified for bugId : PNR2.0_11293
					'ReportRequired="' + ltrim(rtrim(isnull(@report_reqd, ''))) + '" ' + 'ModelSectionName="' + ltrim(rtrim(isnull(@modelsectioname_tmp, ''))) + '" ' +
					--Code Modified for bugid : PNR2.0_11183
					-- Inplace Calendar and Edit Mask Feature added by Feroz -- Start
					'InPlaceCalendar="' + ltrim(rtrim(isnull(@InPlaceCalendar, 'n'))) + '" ' +
					-- Code modification for  PNR2.0_19426  starts
					'InCalDisplay="' + ltrim(rtrim(isnull(@InPlaceCal_Display, ''))) + '" ' + 'EditMask="' + ltrim(rtrim(isnull(@EditMaskPattern, ''))) + '" ' +
					-- Inplace Calendar and Edit Mask Feature added by Feroz -- End
					'TabIndex="' + ltrim(rtrim(@tab_seq)) + '" ' + 'AccessKey="' + ltrim(rtrim(isnull(@AccessKey, ''))) + '" ' + -- Added By Jeya For Access Key
					-- Code modification for  PNR2.0_19426  ends
					-- Code addition for PNR2.0_21576 starts
					--Code modified by Balaji D for Bug ID PNR2.0_28889 on 01-Nov-2010 starts
					'GridLite="' + ltrim(rtrim(isnull(@gridlite, 'N'))) + '" ' +
					--Code modified by Balaji D for Bug ID PNR2.0_28889 on 01-Nov-2010 end
					-- Code addition for PNR2.0_21576 ends
					-- Code addition for PNR2.0_20849 starts
					'NoofLinesPerRow="' + ltrim(rtrim(isnull(@NoofLinesPerRow, ''))) + '" ' + 'RowHeight="' + ltrim(rtrim(isnull(@RowHeight, ''))) + '" ' +
					-- Added By Feroz
					'BulletLink="' + ltrim(rtrim(isnull(@bulletlink_req, 'N'))) + '" ' + 'ButtonCombo="' + ltrim(rtrim(isnull(@buttoncombo_req, 'N'))) + '" ' + 'DataAsCaption="' + ltrim(rtrim(isnull(@dataascaption, 'N'))) + '" ' + 'AssociatedList="' + ltrim(rtrim(isnull
(@associatedlist_name, ''))) + '" ' + 'OnFocusTask="' + ltrim(rtrim(isnull(@onfocus_taskname, ''))) + '" ' + 'ListRefillTask="' + ltrim(rtrim(isnull(@listrefill_taskname, ''))) + '" ' + 'MappedListControlID="' + ltrim(rtrim(isnull(@mapped_list_controlid, 
''))) + '" ' + 'MappedListViewName="' + ltrim(rtrim(isnull(@mapped_list_viewname, ''))) + '" ' + 'AttachDocument="' + ltrim(rtrim(isnull(@attach_document, 'N'))) + '" ' + 'ImageUpload="' + ltrim(rtrim(isnull(@image_upload, 'N'))) + '" ' + 'InplaceImage="'
+ ltrim(rtrim(isnull(@inplace_image, 'N'))) + '" ' + 'ImageIcon="' + ltrim(rtrim(isnull(@image_icon, 'N'))) + '" ' + 'ImageRowHeight="' + ltrim(rtrim(isnull(@image_row_height, '0'))) + '" ' + 'RelativeUrlPath="' + ltrim(rtrim(isnull(@relative_url_path, '
'))) + '" ' + 'RelativeDocumentPath="' + ltrim(rtrim(isnull(
								@relative_document_path, ''))) + '" ' + 'RelativeImagePath="' + ltrim(rtrim(isnull(@relative_image_path, ''))) + '" ' + 'SaveDocContentToDb="' + ltrim(rtrim(isnull(@save_doc_content_to_db, 'N'))) + '" ' + 'SaveImageContentToDb="' + ltrim(rtrim(isnull(@save_image_content_to_db, 'N'))) + '" ' + 'DateHighlight="' + ltrim(rtrim(isnull(@date_highlight_req, 'N'))) + '" ' + 'LinkedHiddenViewName="' + ltrim(rtrim(isnull(@hidden_view_name, ''))) + '" ' + 'Vscrollbar_Req="' + ltrim(rtrim(isnull(@Vscrollbar_Req, 'N'))) + '" LiteAttach="' + Isnull(@Lite_Attach, 'N') + '" Browse_Button="' + Isnull(@BrowseButton, 'N') + '" Delete_Button="' + Isnull(@DeleteButton, 'N') + '" ' + --PNR2.0_28365 -- Code Modified For BUGID PNR2.0_28537
					'IsITK="N"  FC="' + CONVERT(VARCHAR, isnull(@freezecount, 0), 4) + '" ' +
					--code added for the caseid : PNR2.0_28319 starts
					'image_row_width="' + CONVERT(VARCHAR, isnull(@image_row_width, 0), 4) + '" ' + 'image_preview_height="' + CONVERT(VARCHAR, isnull(@image_preview_height, 0), 4) + '" ' + 'image_preview_width="' + CONVERT(VARCHAR, isnull(@image_preview_width, 0), 4) +
 '" ' + 'image_preview_req="' + isnull(@image_preview_req, 'N') + '" ' + 'Accept_Type="' + isnull(@Accept_Type, '') + '" ' + 'Lite_Attach_Image="' + isnull(@Lite_Attach_Image, 'N') + '" ' + 'LabelLink="' + isnull(@LabelLink, 'N') + '" ' + --added for PNR2.0_26860, PNR2.0_27796,PNR2.0_36309
					-- Code addition for PNR2.0_20849 ends
					--code added for the caseid : PNR2.0_28319 ends
					--Code Added for the Bug ID: PLF2.0_00961 starts
					--'PopUpPage="'           +   isnull(@popup_page,'')                  +'" ' +
					--'PopUpSection="'        +   isnull(@popup_section,'')               +'" ' +
					--'PopUpClose="'          +   isnull(@popup_Close,'N')                +'" ' +
					'CaptionType="' + isnull(@captiontype, '') + '" ' + 'ControlStyle="' + isnull(@controlstyle, '') + '" ' + 'ControlImage="' + isnull(@controlimage, '') + '" ' + 'IsListBox="' + isnull(@IsListBox, '') + '" ' + 'Toolbar_Not_Req="' + isnull(@Toolbar_Not_Req, '') + '" ' + 'ColumnBorder_Not_Req="' + isnull(@ColumnBorder_Not_Req, '') + '" ' + 'RowBorder_Not_Req="' + isnull(@RowBorder_Not_Req, '') + '" ' + 'PageNavigation_Only="' + isnull(@PagenavigationOnly, '') + '" ' + 'RowNo_Not_Req="' + isnull(@RowNo_Not_Req, '') + '" ' + 'ExtType="' + isnull(@ExtType, '') + '" ' + 'ColSpan="' + CONVERT(VARCHAR, isnull(@ControlColSpan, ''), 4) + '" ' + 'RowSpan="' + CONVERT(VARCHAR, isnull(@ControlRowSpan, ''), 4) + '" ' + 'Tooltip_Not_Req="' + CONVERT(VARCHAR, isnull(@Tooltip_Not_Req, ''), 4) + '" ' + 'GridHeader_Not_Req="' + CONVERT(VARCHAR, isnull(@columncaption_Not_Req, ''), 4) + '" ' + 'Border_Not_Req="' + CONVERT(VARCHAR, isnull(@Border_Not_Req, ''), 4) + '" ' + 'IsModal="' + CONVERT(VARCHAR, isnull(@IsModal, ''),4) + '" ' + 'Alternate_Color_Req="' + CONVERT(VARCHAR, isnull(@Alternate_Color_Req, ''), 4) + 
					'" ' + 'Map_In_Req="' + CONVERT(VARCHAR, isnull(@Map_In_Req, ''), 4) + '" ' + 'Map_Out_Req="' + CONVERT(VARCHAR, isnull(@Map_Out_Req, ''), 4) + '" ' + 'IsCallout="' + isnull(@iscallout, '') + '" ' + 'SmartViewSection="' + isnull(@smartviewsection, ''
) + '" ' + 'FileSize="' + isnull(@filesize, '') + '" ' + 'TemplateID="' + isnull(@TemplateID, '') + '" />',
					@xml_seq_tmp
					)
					--Code Added for the Bug ID:PLF2.0_00961 ends
			END

			CLOSE ctrlcurs

			DEALLOCATE ctrlcurs

			-- Insert Closing entry for Controls
			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'</Controls>',
				@xml_seq_tmp
				)

			-- Insert Base Entry for Grid Columns
			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'<GridColumns>',
				@xml_seq_tmp
				)

			-- code added by Ganesh for the callid :: PNR2.0_3762 on 5/09/05
			--    DECLARE vis_cursor CURSOR FOR
			--    select page_bt_synonym,
			--      control_bt_synonym,
			--      column_bt_synonym /* PNR2.0_11203 */
			--    from ep_ui_grid_dtl  a (nolock)
			--    where a.customer_name =   @engg_customer_name
			--    and  a.project_name = @engg_project_name
			--    and  a.process_name = @process_name
			--    and  a.component_name= @engg_component
			--    and  a.activity_name = @activity_name
			--    and  a.ui_name  =  @ui_name_tmp
			--    and  isnull(a.visible_length, 0 ) = 0
			--    group by a.customer_name, a.project_name, a.process_name, a.component_name, activity_name, ui_name, page_bt_synonym, control_bt_synonym,column_bt_synonym /* PNR2.0_11203 */
			--    having count( distinct isnull(a.visible_length, 0 )) = 1
			--
			--
			--    OPEN vis_cursor
			--
			--    WHILE (1=1)
			--    BEGIN
			--     FETCH NEXT FROM vis_cursor
			--     INTO @vis_page, @vis_ctrl,@vis_col /* PNR2.0_11203 */
			--
			--     if (@@FETCH_STATUS <> 0)
			--      break
			--
			--     update a
			--     set  visible_length  =  isnull(len(bt_synonym_caption), 30)
			--     from ep_ui_grid_dtl    a (nolock),
			--       @ep_component_glossary_mst b (nolock)
			--     where a.customer_name  =   b.customer_name
			--     and  a.project_name  = b.project_name
			--     and  a.process_name  = b.process_name
			--     and  a.component_name = b.component_name
			--     and  a.column_bt_synonym = b.bt_synonym_name
			--
			--     and  a.customer_name  =   @engg_customer_name
			--     and  a.project_name  = @engg_project_name
			--     and  a.process_name  = @process_name
			--     and  a.component_name = @engg_component
			--     and  a.activity_name  = @activity_name
			--     and  a.ui_name   =  @ui_name_tmp
			--     and  a.page_bt_synonym =  @vis_page
			--     and  a.control_bt_synonym= @vis_ctrl
			--     and  a.column_bt_synonym = @vis_col/* PNR2.0_11203 */
			--
			--     select @vis_leng = 0
			--
			-- --    select @vis_leng   = (82 - sum(visible_length))/count(visible_length)
			--     select  @vis_leng   = (100 - sum(isnull(visible_length,0)))/count(*)
			--     from ep_ui_grid_dtl  a (nolock)
			--     where a.customer_name  =   @engg_customer_name
			--     and  a.project_name  = @engg_project_name
			--     and  a.process_name  = @process_name
			--     and  a.component_name = @engg_component
			--     and  a.activity_name  = @activity_name
			--     and  a.ui_name   =  @ui_name_tmp
			--     and  a.page_bt_synonym =  @vis_page
			--     and  a.control_bt_synonym= @vis_ctrl
			--     group by a.process_name, a.component_name, activity_name, ui_name, page_bt_synonym, control_bt_synonym
			--     having sum(isnull(visible_length,0)) < 100
			-- --    having sum(visible_length) < 82
			--
			--
			--     if isnull(@vis_leng, 0) <> 0
			--     begin
			--      update a
			--      set  visible_length  = isnull(visible_length, 30) + @vis_leng + 1
			--      from ep_ui_grid_dtl  a (nolock)
			--      where a.customer_name  =   @engg_customer_name
			--      and  a.project_name  = @engg_project_name
			--    and  a.process_name  = @process_name
			--      and  a.component_name = @engg_component
			--      and  a.activity_name  = @activity_name
			--      and  a.ui_name   =  @ui_name_tmp
			--      and  a.page_bt_synonym  =  @vis_page
			--      and  a.control_bt_synonym =  @vis_ctrl
			--      and  a.column_bt_synonym  = @vis_col /* PNR2.0_11203 */
			--
			--      update a
			--      set  visible_length  = isnull(visible_length, 30) + @vis_leng + 1
			--      from ep_published_ui_grid_dtl  a (nolock)
			--      where a.customer_name  =   @engg_customer_name
			--      and  a.project_name  = @engg_project_name
			--      and  a.req_no   =  @engg_req_no
			--      and  a.process_name  = @process_name
			--      and  a.component_name = @engg_component
			--      and  a.activity_name  = @activity_name
			--      and  a.ui_name   =  @ui_name_tmp
			--      and  a.page_bt_synonym =  @vis_page
			--      and  a.control_bt_synonym=  @vis_ctrl
			--      and  a.column_bt_synonym = @vis_col /* PNR2.0_11203 */
			--     end
			--    end
			--    CLOSE vis_cursor
			--    DEALLOCATE vis_cursor
			--code modified by kiruthika for bugid:PNR2.0_14487
			CREATE TABLE #visible_length_details (
				customer_name VARCHAR(60) collate database_default,
				project_name VARCHAR(60) collate database_default,
				process_name VARCHAR(60) collate database_default,
				component_name VARCHAR(60) collate database_default,
				activity_name VARCHAR(60) collate database_default,
				ui_name VARCHAR(60) collate database_default,
				page_bt_synonym VARCHAR(60) collate database_default,
				control_bt_synonym VARCHAR(60) collate database_default,
				column_bt_synonym VARCHAR(60) collate database_default
				)

			INSERT INTO #visible_length_details
			SELECT a.customer_name,
				a.project_name,
				a.process_name,
				a.component_name,
				a.activity_name,
				a.ui_name,
				a.page_bt_synonym,
				a.control_bt_synonym,
				a.column_bt_synonym
			FROM ep_ui_grid_dtl a(NOLOCK)
			WHERE a.customer_name = @engg_customer_name
				AND a.project_name = @engg_project_name
				AND a.process_name = @process_name
				AND a.component_name = @engg_component
				AND a.activity_name = @activity_name
				AND a.ui_name = @ui_name_tmp
				AND isnull(a.visible_length, 0) = 0
			GROUP BY a.customer_name,
				a.project_name,
				a.process_name,
				a.component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				control_bt_synonym,
				column_bt_synonym /* PNR2.0_11203 */
			HAVING count(DISTINCT isnull(a.visible_length, 0)) = 1

			UPDATE a
			SET a.visible_length = isnull(len(b.bt_synonym_caption), 30)
			FROM ep_ui_grid_dtl a(NOLOCK),
				@ep_component_glossary_mst b,
				#visible_length_details c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.control_bt_synonym = c.control_bt_synonym
				AND a.column_bt_synonym = c.column_bt_synonym
				AND a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.column_bt_synonym = b.bt_synonym_name

			DECLARE vis_cursor CURSOR
			FOR
			SELECT DISTINCT page_bt_synonym,
				control_bt_synonym
			FROM #visible_length_details

			OPEN vis_cursor

			WHILE (1 = 1)
			BEGIN
				FETCH NEXT
				FROM vis_cursor
				INTO @vis_page,
					@vis_ctrl

				IF (@@FETCH_STATUS <> 0)
					BREAK

				SELECT @vis_leng = 0

				SELECT @Sum_vis_leng = 0

				SELECT @Sum_vis_leng = sum(isnull(a.visible_length, 0))
				FROM ep_ui_grid_dtl a(NOLOCK)
				WHERE a.customer_name = @engg_customer_name
					AND a.project_name = @engg_project_name
					AND a.process_name = @process_name
					AND a.component_name = @engg_component
					AND a.activity_name = @activity_name
					AND a.ui_name = @ui_name_tmp
					AND a.page_bt_synonym = @vis_page
					AND a.control_bt_synonym = @vis_ctrl
				GROUP BY a.process_name,
					a.component_name,
					a.activity_name,
					a.ui_name,
					a.page_bt_synonym,
					a.control_bt_synonym
				HAVING sum(isnull(visible_length, 0)) < 75

				IF isnull(@Sum_vis_leng, 0) <> 0
				BEGIN
					SELECT @vis_leng = (75 - @Sum_vis_leng) / count(*)
					FROM #visible_length_details a(NOLOCK)
					WHERE a.customer_name = @engg_customer_name
						AND a.project_name = @engg_project_name
						AND a.process_name = @process_name
						AND a.component_name = @engg_component
						AND a.activity_name = @activity_name
						AND a.ui_name = @ui_name_tmp
						AND a.page_bt_synonym = @vis_page
						AND a.control_bt_synonym = @vis_ctrl
					GROUP BY a.process_name,
						a.component_name,
						a.activity_name,
						a.ui_name,
						a.page_bt_synonym,
						a.control_bt_synonym

					UPDATE b
					SET b.visible_length = isnull(b.visible_length, 30) + @vis_leng
					FROM #visible_length_details a(NOLOCK),
						ep_ui_grid_dtl b(NOLOCK)
					WHERE a.customer_name = @engg_customer_name
						AND a.project_name = @engg_project_name
						AND a.process_name = @process_name
						AND a.component_name = @engg_component
						AND a.activity_name = @activity_name
						AND a.ui_name = @ui_name_tmp
						AND a.page_bt_synonym = @vis_page
						AND a.control_bt_synonym = @vis_ctrl
						AND a.customer_name = b.customer_name
						AND a.project_name = b.project_name
						AND a.process_name = b.process_name
						AND a.component_name = b.component_name
						AND a.activity_name = b.activity_name
						AND a.ui_name = b.ui_name
						AND a.page_bt_synonym = b.page_bt_synonym
						AND a.control_bt_synonym = b.control_bt_synonym
						AND a.column_bt_synonym = b.column_bt_synonym

					UPDATE a
					SET visible_length = isnull(visible_length, 30) + @vis_leng
					FROM ep_published_ui_grid_dtl a(NOLOCK),
						#visible_length_details b(NOLOCK)
					WHERE a.customer_name = @engg_customer_name
						AND a.project_name = @engg_project_name
						AND a.req_no = @engg_req_no
						AND a.process_name = @process_name
						AND a.component_name = @engg_component
						AND a.activity_name = @activity_name
						AND a.ui_name = @ui_name_tmp
						AND a.page_bt_synonym = @vis_page
						AND a.control_bt_synonym = @vis_ctrl
						AND a.customer_name = b.customer_name
						AND a.project_name = b.project_name
						AND a.process_name = b.process_name
						AND a.component_name = b.component_name
						AND a.activity_name = b.activity_name
						AND a.ui_name = b.ui_name
						AND a.page_bt_synonym = b.page_bt_synonym
						AND a.control_bt_synonym = b.control_bt_synonym
						AND a.column_bt_synonym = b.column_bt_synonym
				END
			END

			CLOSE vis_cursor

			DEALLOCATE vis_cursor

			DROP TABLE #visible_length_details

			-- Fetch Grid Controls
			IF @ctxt_service_in IN ('BulkGenerate')
				AND @pubflag = 'P'
			BEGIN
				DECLARE gridcurs INSENSITIVE CURSOR
				FOR
				SELECT upper(column_bt_synonym),
					isnull(bt_synonym_caption, column_bt_synonym),
					upper(grid.control_id),
					isnull(column_type, ''),
					upper(base_ctrl_type),
					column_no,
					isnull(visible_length, 0),
					isnull(grid.proto_tooltip, ''),
					isnull(grid.sample_data, ''),
					upper(grid.page_bt_synonym) AS 'page_bt_synonym',
					upper(grid.section_bt_synonym) AS 'section_bt_synonym',
					upper(grid.control_bt_synonym) AS 'control_bt_synonym',
					upper(rtrim(mandatory_flag)),
					CASE 
						WHEN isnull(upper(rtrim(grid.visible)), 'Yes') = 'Yes'
							THEN 'Y'
						ELSE 'N'
						END,
					upper(rtrim(editable_flag)),
					upper(rtrim(caption_req)),
					upper(rtrim(select_flag)),
					upper(rtrim(zoom_req)),
					upper(rtrim(help_req)),
					upper(rtrim(ellipses_req)),
					isnull(visisble_rows, 0),
					upper(isnull(data_type, 'char')),
					isnull(length, 0),
					isnull(col_doc, ''),
					upper(isnull(caption_wrap, 'Y')),
					upper(isnull(caption_alignment, 'LEFT')),
					upper(isnull(caption_position, 'LEFT')),
					isnull(grid.view_name, ''),
					upper(isnull(ctrl_position, 'LEFT')),
					upper(isnull(LabelClass, '')),
					upper(isnull(controlclass, '')),
					upper(isnull(password_char, 'N')),
					upper(isnull(tskimg_class, '')),
					upper(isnull(hlpimg_class, '')),
					sec.horder,
					sec.vorder,
					upper(isnull(html_txt_area, 'N')),
					isnull(report_req, 'N'),
					-- Added By Feroz
					isnull(bulletlink_req, 'N'),
					isnull(buttoncombo_req, 'N'),
					isnull(associatedlist_req, 'N'),
					isnull(onfocustask_req, 'N'),
					isnull(listrefilltask_req, 'N'),
					isnull(@dataascaption, 'N'),
					isnull(ListEdit_NoofColumns, 0),
					isnull(attach_document, 'N'),
					isnull(image_upload, 'N'),
					isnull(inplace_image, 'N'),
					isnull(image_row_height, 0),
					isnull(image_icon, 'N'),
					isnull(relative_url_path, ''),
					isnull(relative_document_path, ''),
					isnull(relative_image_path, ''),
					isnull(save_doc_content_to_db, 'N'),
					isnull(save_image_content_to_db, 'N'),
					isnull(Date_highlight, 'N'),
					isnull(Lite_Attach_Document, 'N'),
					isnull(Browse_Button_Enable, 'N'),
					isnull(Delete_Button_Enable, 'N'), -- Code Modified for the Bug ID : PNR2.0_27796
					isnull(image_row_width, 0),
					isnull(image_preview_height, 0),
					isnull(image_preview_width, 0),
					isnull(image_preview_req, 'N'),
					isnull(Accpet_Type, ''),
					isnull(Lite_Attach_Image, 'N'),
					isnull(grid.Forcefit, 'N') -- PNR2.0_28319
					,
					isnull(ColumnClass, ''),
					isnull(controlstyle, '')
					/*isnull(ColumnHdrClass,''),*/,
					isnull(ctype.ismodal, ''),
					isnull(filesize, ''),
					isnull(grid.TemplateId, ''),
					isnull(ctype.col_caption_align, 'Left'),
					isnull(Email, ''),
					isnull(Phone, ''),
					isnull(col_data_align, ''),
					isnull(ctype.ishijri, 'N'),
					isnull(col_data_align, ''),
					isnull(avn_download, ''),
					isnull(grid.TemplateCategory, ''),
					isnull(grid.TemplateSpecific, ''),
					isnull(grid.Column_class_ext6, ''),
					isnull(ctype.RatingType, ''),
					isnull(CaptchaData, ''),
					isnull(grid.RowExpander, 'N'),
					isnull(grid.GridToForm, 'N')
				FROM ep_published_ui_grid_dtl grid(NOLOCK),
					ep_published_ui_control_dtl ctrl(NOLOCK),
					ep_published_ui_section_dtl sec(NOLOCK),
					@ep_published_comp_glossary_mst gls,
					es_comp_ctrl_type_mst_vw ctype(NOLOCK)
				WHERE grid.customer_name = ctrl.customer_name
					AND grid.project_name = ctrl.project_name
					AND grid.req_no = ctrl.req_no
					AND grid.process_name = ctrl.process_name
					AND grid.component_name = ctrl.component_name
					AND grid.activity_name = ctrl.activity_name
					AND grid.ui_name = ctrl.ui_name
					AND grid.page_bt_synonym = ctrl.page_bt_synonym
					AND grid.section_bt_synonym = ctrl.section_bt_synonym
					AND grid.control_bt_synonym = ctrl.control_bt_synonym
					AND ctrl.customer_name = sec.customer_name
					AND ctrl.project_name = sec.project_name
					AND ctrl.req_no = sec.req_no
					AND ctrl.process_name = sec.process_name
					AND ctrl.component_name = sec.component_name
					AND ctrl.activity_name = sec.activity_name
					AND ctrl.ui_name = sec.ui_name
					AND ctrl.page_bt_synonym = sec.page_bt_synonym
					AND ctrl.section_bt_synonym = sec.section_bt_synonym
					AND grid.customer_name = gls.customer_name
					AND grid.project_name = gls.project_name
					AND grid.req_no = gls.req_no
					AND grid.process_name = gls.process_name
					AND grid.component_name = gls.component_name
					AND grid.column_bt_synonym = gls.bt_synonym_name
					AND grid.customer_name = ctype.customer_name
					AND grid.project_name = ctype.project_name
					AND grid.process_name = ctype.process_name
					AND grid.component_name = ctype.component_name
					AND grid.column_type = ctype.ctrl_type_name
					AND sec.customer_name = @engg_customer_name
					AND sec.project_name = @engg_project_name
					AND sec.req_no = @engg_req_no
					AND sec.process_name = @process_name
					AND sec.component_name = @engg_component
					AND sec.activity_name = @activity_name
					AND sec.ui_name = @ui_name_tmp
					AND isnull(sec.section_type, 'MAIN') = 'MAIN'
					--AND gls.languageid = @language_code
				    and grid.view_name not in ('__nodeexpand','__nodeid','__parentnodeid','__icon','__icls') -- Code added for the defect id TECH-46330
				
				UNION
				
				SELECT upper(column_bt_synonym),
					isnull(bt_synonym_caption, column_bt_synonym),
					upper(grid.control_id),
					isnull(column_type, ''),
					upper(base_ctrl_type),
					column_no,
					isnull(visible_length, 0),
					isnull(grid.proto_tooltip, ''),
					isnull(grid.sample_data, ''),
					upper(grid.page_bt_synonym) AS 'page_bt_synonym',
					upper(grid.section_bt_synonym) AS 'section_bt_synonym',
					upper(grid.control_bt_synonym) AS 'control_bt_synonym',
					'Y',
					'Y',
					'Y',
					'Y',
					'N',
					'N',
					'N',
					'N',
					'0',
					upper(isnull(data_type, 'char')),
					isnull(length, 0),
					isnull(col_doc, ''),
					'Y',
					'LEFT',
					'LEFT',
					isnull(grid.view_name, ''),
					'LEFT',
					'',
					'',
					'N',
					'',
					'',
					sec.horder,
					sec.vorder,
					'N',
					'N',
					-- Added By Feroz
					'N',
					'N',
					'N',
					'N',
					'N',
					'N',
					0,
					'N',
					'N',
					'N',
					0,
					'N',
					'',
					'',
					'',
					'N',
					'N',
					'N',
					'N',
					'N',
					'N', -- Code Modified for the Bug ID : PNR2.0_27796
					0,
					0,
					0,
					'N',
					'',
					'N',
					'N',
					'',
					'',
					'',
					'',
					'',
					'',
					'',
					'',
					'' --,''--PNR2.0_28319
					,
					'N',
					'',
					'',
					'',
					'',
					'',
					'',
					'',
					'',
					''
				FROM ep_published_ui_grid_dtl grid(NOLOCK),
					ep_published_ui_control_dtl ctrl(NOLOCK),
					ep_published_ui_section_dtl sec(NOLOCK),
					@ep_published_comp_glossary_mst gls,
					ep_published_comp_stat_ctrl_type_mst ctype(NOLOCK)
				WHERE grid.customer_name = ctrl.customer_name
					AND grid.project_name = ctrl.project_name
					AND grid.req_no = ctrl.req_no
					AND grid.process_name = ctrl.process_name
					AND grid.component_name = ctrl.component_name
					AND grid.activity_name = ctrl.activity_name
					AND grid.ui_name = ctrl.ui_name
					AND grid.page_bt_synonym = ctrl.page_bt_synonym
					AND grid.section_bt_synonym = ctrl.section_bt_synonym
					AND grid.control_bt_synonym = ctrl.control_bt_synonym
					AND ctrl.customer_name = sec.customer_name
					AND ctrl.project_name = sec.project_name
					AND ctrl.req_no = sec.req_no
					AND ctrl.process_name = sec.process_name
					AND ctrl.component_name = sec.component_name
					AND ctrl.activity_name = sec.activity_name
					AND ctrl.ui_name = sec.ui_name
					AND ctrl.page_bt_synonym = sec.page_bt_synonym
					AND ctrl.section_bt_synonym = sec.section_bt_synonym
					AND grid.customer_name = gls.customer_name
					AND grid.project_name = gls.project_name
					AND grid.req_no = gls.req_no
					AND grid.process_name = gls.process_name
					AND grid.component_name = gls.component_name
					AND grid.column_bt_synonym = gls.bt_synonym_name
					AND grid.customer_name = ctype.customer_name
					AND grid.project_name = ctype.project_name
					AND grid.process_name = ctype.process_name
					AND grid.component_name = ctype.component_name
					AND grid.column_type = ctype.ctrl_type_name
					AND sec.customer_name = @engg_customer_name
					AND sec.project_name = @engg_project_name
					AND sec.req_no = @engg_req_no
					AND sec.process_name = @process_name
					AND sec.component_name = @engg_component
					AND sec.activity_name = @activity_name
					AND sec.ui_name = @ui_name_tmp
					AND isnull(sec.section_type, 'MAIN') = 'MAIN'
					--AND gls.languageid = @language_code
					and grid.view_name not in ('__nodeexpand','__nodeid','__parentnodeid','__icon','__icls') -- Code added for the defect id TECH-46330
				-- Added By feroz For extjs -- Start -- PNR2.0_1790
				
				UNION
				
				SELECT upper(column_bt_synonym),
					isnull(bt_synonym_caption, column_bt_synonym),
					upper(grid.control_id),
					isnull(column_type, ''),
					upper(base_ctrl_type),
					column_no,
					isnull(visible_length, 0),
					isnull(grid.proto_tooltip, ''),
					isnull(grid.sample_data, ''),
					upper(grid.page_bt_synonym) AS 'page_bt_synonym',
					upper(grid.section_bt_synonym) AS 'section_bt_synonym',
					upper(grid.control_bt_synonym) AS 'control_bt_synonym',
					upper(rtrim(mandatory_flag)),
					CASE 
						WHEN isnull(upper(rtrim(grid.visible)), 'Yes') = 'Yes'
							THEN 'Y'
						ELSE 'N'
						END,
					upper(rtrim(editable_flag)),
					upper(rtrim(caption_req)),
					upper(rtrim(select_flag)),
					upper(rtrim(zoom_req)),
					upper(rtrim(help_req)),
					upper(rtrim(ellipses_req)),
					isnull(visisble_rows, 0),
					upper(isnull(data_type, 'char')),
					isnull(length, 0),
					isnull(col_doc, ''),
					upper(isnull(caption_wrap, 'Y')),
					upper(isnull(caption_alignment, 'LEFT')),
					upper(isnull(caption_position, 'LEFT')),
					isnull(grid.view_name, ''),
					upper(isnull(ctrl_position, 'LEFT')),
					upper(isnull(LabelClass, '')),
					upper(isnull(controlclass, '')),
					upper(isnull(password_char, 'N')),
					upper(isnull(tskimg_class, '')),
					upper(isnull(hlpimg_class, '')),
					sec.horder,
					sec.vorder,
					upper(isnull(html_txt_area, 'N')),
					isnull(report_req, 'N'),
					-- Added By Feroz
					isnull(bulletlink_req, 'N'),
					isnull(buttoncombo_req, 'N'),
					isnull(associatedlist_req, 'N'),
					isnull(onfocustask_req, 'N'),
					isnull(listrefilltask_req, 'N'),
					isnull(@dataascaption, 'N'),
					isnull(ListEdit_NoofColumns, 0),
					isnull(attach_document, 'N'),
					isnull(image_upload, 'N'),
					isnull(inplace_image, 'N'),
					isnull(image_row_height, 0),
					isnull(image_icon, 'N'),
					isnull(relative_url_path, ''),
					isnull(relative_document_path, ''),
					isnull(relative_image_path, ''),
					isnull(save_doc_content_to_db, 'N'),
					isnull(save_image_content_to_db, 'N'),
					isnull(Date_highlight, 'N'),
					isnull(Lite_Attach_Document, 'N'),
					isnull(Browse_Button_Enable, 'N'),
					isnull(Delete_Button_Enable, 'N'), -- Code Modified for the Bug ID : PNR2.0_27796
					isnull(image_row_width, 0),
					isnull(image_preview_height, 0),
					isnull(image_preview_width, 0),
					isnull(image_preview_req, 'N'),
					isnull(Accpet_Type, ''),
					isnull(Lite_Attach_Image, 'N'),
					isnull(grid.Forcefit, 'N') -- PNR2.0_28319
					,
					isnull(Columnclass, ''),
					isnull(controlstyle, ''), /*isnull(ColumnHdrClass,''),*/
					isnull(ismodal, ''),
					isnull(FileSize, ''),
					isnull(grid.TemplateId, ''),
					'',
					isnull(Email, ''),
					isnull(Phone, ''),
					'',
					isnull(ctype.ishijri, 'N'),
					isnull(col_data_align, ''),
					isnull(avn_download, ''),
					isnull(grid.TemplateCategory, ''),
					isnull(grid.TemplateSpecific, ''),
					isnull(ctype.RatingType, ''),
					isnull(CaptchaData, ''),
					isnull(grid.Column_class_ext6, ''),
					'',
					''
				FROM ep_published_ui_grid_dtl grid(NOLOCK),
					ep_published_ui_control_dtl ctrl(NOLOCK),
					ep_published_ui_section_dtl sec(NOLOCK),
					@ep_published_comp_glossary_mst gls,
					es_comp_ctrl_type_mst_vw ctype(NOLOCK)
				WHERE grid.customer_name = ctrl.customer_name
					AND grid.project_name = ctrl.project_name
					AND grid.req_no = ctrl.req_no
					AND grid.process_name = ctrl.process_name
					AND grid.component_name = ctrl.component_name
					AND grid.activity_name = ctrl.activity_name
					AND grid.ui_name = ctrl.ui_name
					AND grid.page_bt_synonym = ctrl.page_bt_synonym
					AND grid.section_bt_synonym = ctrl.section_bt_synonym
					AND grid.control_bt_synonym = ctrl.control_bt_synonym
					AND ctrl.customer_name = sec.customer_name
					AND ctrl.project_name = sec.project_name
					AND ctrl.req_no = sec.req_no
					AND ctrl.process_name = sec.process_name
					AND ctrl.component_name = sec.component_name
					AND ctrl.activity_name = sec.activity_name
					AND ctrl.ui_name = sec.ui_name
					AND ctrl.page_bt_synonym = sec.page_bt_synonym
					AND ctrl.section_bt_synonym = sec.section_bt_synonym
					AND grid.customer_name = gls.customer_name
					AND grid.project_name = gls.project_name
					AND grid.req_no = gls.req_no
					AND grid.process_name = gls.process_name
					AND grid.component_name = gls.component_name
					AND grid.column_bt_synonym = gls.bt_synonym_name
					AND grid.customer_name = ctype.customer_name
					AND grid.project_name = ctype.project_name
					AND grid.process_name = ctype.process_name
					AND grid.component_name = ctype.component_name
					AND grid.column_type = ctype.ctrl_type_name
					AND sec.customer_name = @engg_customer_name
					AND sec.project_name = @engg_project_name
					AND sec.req_no = @engg_req_no
					AND sec.process_name = @process_name
					AND sec.component_name = @engg_component
					AND sec.activity_name = @activity_name
					AND sec.ui_name = @ui_name_tmp
					AND isnull(sec.section_type, 'MAIN') NOT IN (
						'MAIN',
						'TREE',
						'CHART'
						)
					--AND gls.languageid = @language_code
					--and grid.view_name not in ('__nodeexpand','__nodeid','__parentnodeid','__icon','__icls')
				-- Added By feroz For extjs -- End -- PNR2.0_1790
				/* Code modified by Makesh Prabu R to change the scripts 90 compatible on 05-April-10 for the Case ID: PNR2.0_26469 -- Starts */
				ORDER BY page_bt_synonym,
					section_bt_synonym,
					control_bt_synonym,
					column_no
					/* Code modified by Makesh Prabu R to change the scripts 90 compatible on 05-April-10 for the Case ID: PNR2.0_26469 -- End */
			END
			ELSE
			BEGIN
				DECLARE gridcurs INSENSITIVE CURSOR
				FOR
				SELECT upper(column_bt_synonym),
					isnull(bt_synonym_caption, column_bt_synonym),
					upper(grid.control_id),
					isnull(column_type, ''),
					upper(base_ctrl_type),
					column_no,
					isnull(visible_length, 0),
					isnull(grid.proto_tooltip, ''),
					isnull(grid.sample_data, ''),
					upper(grid.page_bt_synonym) AS 'page_bt_synonym',
					upper(grid.section_bt_synonym) AS 'section_bt_synonym',
					upper(grid.control_bt_synonym) AS 'control_bt_synonym',
					upper(rtrim(mandatory_flag)),
					CASE 
						WHEN isnull(upper(rtrim(grid.visible)), 'Yes') = 'Yes'
							THEN 'Y'
						ELSE 'N'
						END,
					upper(rtrim(editable_flag)),
					upper(rtrim(caption_req)),
					upper(rtrim(select_flag)),
					upper(rtrim(zoom_req)),
					upper(rtrim(help_req)),
					upper(rtrim(ellipses_req)),
					isnull(visisble_rows, 0),
					upper(isnull(data_type, 'char')),
					isnull(length, 0),
					isnull(col_doc, ''),
					upper(isnull(caption_wrap, 'Y')),
					upper(isnull(caption_alignment, 'LEFT')),
					upper(isnull(caption_position, 'LEFT')),
					isnull(grid.view_name, ''),
					upper(isnull(ctrl_position, 'LEFT')),
					upper(isnull(LabelClass, '')),
					upper(isnull(controlclass, '')),
					upper(isnull(password_char, 'N')),
					upper(isnull(tskimg_class, '')),
					upper(isnull(hlpimg_class, '')),
					sec.horder,
					sec.vorder,
					upper(isnull(html_txt_area, 'N')),
					isnull(report_req, 'N'),
					-- Added By Feroz
					isnull(bulletlink_req, 'N'),
					isnull(buttoncombo_req, 'N'),
					isnull(associatedlist_req, 'N'),
					isnull(onfocustask_req, 'N'),
					isnull(listrefilltask_req, 'N'),
					isnull(@dataascaption, 'N'),
					isnull(ListEdit_NoofColumns, 0),
					isnull(attach_document, 'N'),
					isnull(image_upload, 'N'),
					isnull(inplace_image, 'N'),
					isnull(image_row_height, 0),
					isnull(image_icon, 'N'),
					isnull(relative_url_path, ''),
					isnull(relative_document_path, ''),
					isnull(relative_image_path, ''),
					isnull(save_doc_content_to_db, 'N'),
					isnull(save_image_content_to_db, 'N'),
					isnull(Date_highlight, 'N'),
					isnull(Lite_Attach_Document, 'N'),
					isnull(Browse_Button_Enable, 'N'),
					isnull(Delete_Button_Enable, 'N'), -- Code Modified for the Bug ID : PNR2.0_27796
					isnull(image_row_width, 0),
					isnull(image_preview_height, 0),
					isnull(image_preview_width, 0),
					isnull(image_preview_req, 'N'),
					isnull(Accpet_Type, ''),
					isnull(Lite_Attach_Image, 'N'),
					isnull(grid.Forcefit, 'N') -- PNR2.0_28319
					,
					isnull(Columnclass, ''),
					isnull(controlstyle, ''), /*isnull(ColumnHdrClass,''),*/
					isnull(ismodal, ''),
					isnull(FileSize, ''),
					isnull(grid.TemplateId, ''),
					'',
					isnull(Email, ''),
					isnull(Phone, ''),
					'',
					isnull(ctype.ishijri, 'N'),
					isnull(col_data_align, ''),
					isnull(avn_download, ''),
					isnull(grid.TemplateCategory, ''),
					isnull(grid.TemplateSpecific, ''),
					isnull(ctype.RatingType, ''),
					isnull(CaptchaData, ''),
					isnull(grid.Column_class_ext6, ''),
					isnull(grid.RowExpander, 'N'),
					isnull(grid.GridToForm, 'N')
				FROM ep_ui_grid_dtl grid(NOLOCK),
					ep_ui_control_dtl ctrl(NOLOCK),
					ep_ui_section_dtl sec(NOLOCK),
					@ep_component_glossary_mst gls,
					es_comp_ctrl_type_mst_vw ctype(NOLOCK)
				WHERE grid.customer_name = ctrl.customer_name
					AND grid.project_name = ctrl.project_name
					AND grid.req_no = ctrl.req_no
					AND grid.process_name = ctrl.process_name
					AND grid.component_name = ctrl.component_name
					AND grid.activity_name = ctrl.activity_name
					AND grid.ui_name = ctrl.ui_name
					AND grid.page_bt_synonym = ctrl.page_bt_synonym
					AND grid.section_bt_synonym = ctrl.section_bt_synonym
					AND grid.control_bt_synonym = ctrl.control_bt_synonym
					AND ctrl.customer_name = sec.customer_name
					AND ctrl.project_name = sec.project_name
					AND ctrl.req_no = sec.req_no
					AND ctrl.process_name = sec.process_name
					AND ctrl.component_name = sec.component_name
					AND ctrl.activity_name = sec.activity_name
					AND ctrl.ui_name = sec.ui_name
					AND ctrl.page_bt_synonym = sec.page_bt_synonym
					AND ctrl.section_bt_synonym = sec.section_bt_synonym
					AND grid.customer_name = gls.customer_name
					AND grid.project_name = gls.project_name
					AND grid.req_no = gls.req_no
					AND grid.process_name = gls.process_name
					AND grid.component_name = gls.component_name
					AND grid.column_bt_synonym = gls.bt_synonym_name
					AND grid.customer_name = ctype.customer_name
					AND grid.project_name = ctype.project_name
					AND grid.process_name = ctype.process_name
					AND grid.component_name = ctype.component_name
					AND grid.column_type = ctype.ctrl_type_name
					AND sec.customer_name = @engg_customer_name
					AND sec.project_name = @engg_project_name
					AND sec.req_no = 'Base'
					AND sec.process_name = @process_name
					AND sec.component_name = @engg_component
					AND sec.activity_name = @activity_name
					AND sec.ui_name = @ui_name_tmp
					AND isnull(sec.section_type, 'MAIN') = 'MAIN'
					--AND gls.languageid = @language_code
					and grid.view_name not in ('__nodeexpand','__nodeid','__parentnodeid','__icon','__icls') -- Code added for the defect id TECH-46330
				
				UNION
				
				SELECT upper(column_bt_synonym),
					isnull(bt_synonym_caption, column_bt_synonym),
					upper(grid.control_id),
					isnull(column_type, ''),
					upper(base_ctrl_type),
					column_no,
					isnull(visible_length, 0),
					isnull(grid.proto_tooltip, ''),
					isnull(grid.sample_data, ''),
					upper(grid.page_bt_synonym) AS 'page_bt_synonym',
					upper(grid.section_bt_synonym) AS 'section_bt_synonym',
					upper(grid.control_bt_synonym) AS 'control_bt_synonym',
					'Y',
					'Y',
					'Y',
					'Y',
					'N',
					'N',
					'N',
					'N',
					'0',
					upper(isnull(data_type, 'char')),
					isnull(length, 0),
					isnull(col_doc, ''),
					'Y',
					'LEFT',
					'LEFT',
					isnull(grid.view_name, ''),
					'LEFT',
					'',
					'',
					'N',
					'',
					'',
					sec.horder,
					sec.vorder,
					'N',
					'N',
					-- Added By Feroz
					'N',
					'N',
					'N',
					'N',
					'N',
					'N',
					0,
					'N',
					'N',
					'N',
					0,
					'N',
					'',
					'',
					'',
					'N',
					'N',
					'N',
					'N',
					'N',
					'N', -- Code Modified for the Bug ID : PNR2.0_27796
					0,
					0,
					0,
					'N',
					'',
					'N',
					'N',
					'',
					'',
					'',
					'',
					'',
					'',
					'',
					'',
					'' --,''--PNR2.0_28319
					,
					'N',
					'',
					'',
					'',
					'',
					'',
					'',
					'',
					'',
					''
				FROM ep_ui_grid_dtl grid(NOLOCK),
					ep_ui_control_dtl ctrl(NOLOCK),
					ep_ui_section_dtl sec(NOLOCK),
					@ep_component_glossary_mst gls,
					es_comp_stat_ctrl_type_mst ctype(NOLOCK)
				WHERE grid.customer_name = ctrl.customer_name
					AND grid.project_name = ctrl.project_name
					AND grid.req_no = ctrl.req_no
					AND grid.process_name = ctrl.process_name
					AND grid.component_name = ctrl.component_name
					AND grid.activity_name = ctrl.activity_name
					AND grid.ui_name = ctrl.ui_name
					AND grid.page_bt_synonym = ctrl.page_bt_synonym
					AND grid.control_bt_synonym = ctrl.control_bt_synonym
					AND ctrl.customer_name = sec.customer_name
					AND ctrl.project_name = sec.project_name
					AND ctrl.req_no = sec.req_no
					AND ctrl.process_name = sec.process_name
					AND ctrl.component_name = sec.component_name
					AND ctrl.activity_name = sec.activity_name
					AND ctrl.ui_name = sec.ui_name
					AND ctrl.page_bt_synonym = sec.page_bt_synonym
					AND ctrl.section_bt_synonym = sec.section_bt_synonym
					AND grid.customer_name = gls.customer_name
					AND grid.project_name = gls.project_name
					AND grid.req_no = gls.req_no
					AND grid.process_name = gls.process_name
					AND grid.component_name = gls.component_name
					AND grid.column_bt_synonym = gls.bt_synonym_name
					AND grid.customer_name = ctype.customer_name
					AND grid.project_name = ctype.project_name
					AND grid.process_name = ctype.process_name
					AND grid.component_name = ctype.component_name
					AND grid.column_type = ctype.ctrl_type_name
					AND sec.customer_name = @engg_customer_name
					AND sec.project_name = @engg_project_name
					AND sec.req_no = 'Base'
					AND sec.process_name = @process_name
					AND sec.component_name = @engg_component
					AND sec.activity_name = @activity_name
					AND sec.ui_name = @ui_name_tmp
					AND isnull(sec.section_type, 'MAIN') = 'MAIN'
					--AND gls.languageid = @language_code
				-- Added By feroz For extjs -- Start -- PNR2.0_1790
					and grid.view_name not in ('__nodeexpand','__nodeid','__parentnodeid','__icon','__icls') -- Code added for the defect id TECH-46330
				UNION
				
				SELECT upper(column_bt_synonym),
					isnull(bt_synonym_caption, column_bt_synonym),
					upper(grid.control_id),
					isnull(column_type, ''),
					upper(base_ctrl_type),
					column_no,
					isnull(visible_length, 0),
					isnull(grid.proto_tooltip, ''),
					isnull(grid.sample_data, ''),
					upper(grid.page_bt_synonym) AS 'page_bt_synonym',
					upper(grid.section_bt_synonym) AS 'section_bt_synonym',
					upper(grid.control_bt_synonym) AS 'control_bt_synonym',
					upper(rtrim(mandatory_flag)),
					CASE 
						WHEN isnull(upper(rtrim(grid.visible)), 'Yes') = 'Yes'
							THEN 'Y'
						ELSE 'N'
						END,
					upper(rtrim(editable_flag)),
					upper(rtrim(caption_req)),
					upper(rtrim(select_flag)),
					upper(rtrim(zoom_req)),
					upper(rtrim(help_req)),
					upper(rtrim(ellipses_req)),
					isnull(visisble_rows, 0),
					upper(isnull(data_type, 'char')),
					isnull(length, 0),
					isnull(col_doc, ''),
					upper(isnull(caption_wrap, 'Y')),
					upper(isnull(caption_alignment, 'LEFT')),
					upper(isnull(caption_position, 'LEFT')),
					isnull(grid.view_name, ''),
					upper(isnull(ctrl_position, 'LEFT')),
					upper(isnull(LabelClass, '')),
					upper(isnull(controlclass, '')),
					upper(isnull(password_char, 'N')),
					upper(isnull(tskimg_class, '')),
					upper(isnull(hlpimg_class, '')),
					sec.horder,
					sec.vorder,
					upper(isnull(html_txt_area, 'N')),
					isnull(report_req, 'N'),
					-- Added By Feroz
					isnull(bulletlink_req, 'N'),
					isnull(buttoncombo_req, 'N'),
					isnull(associatedlist_req, 'N'),
					isnull(onfocustask_req, 'N'),
					isnull(listrefilltask_req, 'N'),
					isnull(@dataascaption, 'N'),
					isnull(ListEdit_NoofColumns, 0),
					isnull(attach_document, 'N'),
					isnull(image_upload, 'N'),
					isnull(inplace_image, 'N'),
					isnull(image_row_height, 0),
					isnull(image_icon, 'N'),
					isnull(relative_url_path, ''),
					isnull(relative_document_path, ''),
					isnull(relative_image_path, ''),
					isnull(save_doc_content_to_db, 'N'),
					isnull(save_image_content_to_db, 'N'),
					isnull(Date_highlight, 'N'),
					isnull(Lite_Attach_Document, 'N'),
					isnull(Browse_Button_Enable, 'N'),
					isnull(Delete_Button_Enable, 'N'), -- Code Modified for the Bug ID : PNR2.0_27796
					isnull(image_row_width, 0),
					isnull(image_preview_height, 0),
					isnull(image_preview_width, 0),
					isnull(image_preview_req, 'N'),
					isnull(Accpet_Type, ''),
					isnull(Lite_Attach_Image, 'N'),
					isnull(grid.Forcefit, 'N') -- PNR2.0_28319
					,
					isnull(ColumnClass, ''),
					isnull(controlstyle, '') /*,isnull(ColumnHdrClass,'')*/,
					isnull(ismodal, ''),
					isnull(filesize, ''),
					isnull(grid.TemplateId, ''),
					'',
					isnull(Email, ''),
					isnull(Phone, ''),
					'',
					isnull(ctype.ishijri, 'N'),
					isnull(col_data_align, ''),
					isnull(avn_download, ''),
					isnull(grid.TemplateCategory, ''),
					isnull(grid.TemplateSpecific, ''),
					isnull(ctype.RatingType, ''),
					isnull(CaptchaData, ''),
					isnull(grid.Column_class_ext6, ''),
					'',
					''
				FROM ep_ui_grid_dtl grid(NOLOCK),
					ep_ui_control_dtl ctrl(NOLOCK),
					ep_ui_section_dtl sec(NOLOCK),
					@ep_component_glossary_mst gls,
					es_comp_ctrl_type_mst_vw ctype(NOLOCK)
				WHERE grid.customer_name = ctrl.customer_name
					AND grid.project_name = ctrl.project_name
					AND grid.component_name = ctrl.component_name
					AND grid.activity_name = ctrl.activity_name
					AND grid.ui_name = ctrl.ui_name
					AND grid.page_bt_synonym = ctrl.page_bt_synonym
					AND grid.control_bt_synonym = ctrl.control_bt_synonym
					AND ctrl.customer_name = sec.customer_name
					AND ctrl.project_name = sec.project_name
					AND ctrl.component_name = sec.component_name
					AND ctrl.activity_name = sec.activity_name
					AND ctrl.ui_name = sec.ui_name
					AND ctrl.page_bt_synonym = sec.page_bt_synonym
					AND ctrl.section_bt_synonym = sec.section_bt_synonym
					AND grid.customer_name = gls.customer_name
					AND grid.project_name = gls.project_name
					AND grid.req_no = gls.req_no
					AND grid.process_name = gls.process_name
					AND grid.component_name = gls.component_name
					AND grid.column_bt_synonym = gls.bt_synonym_name
					AND grid.customer_name = ctype.customer_name
					AND grid.project_name = ctype.project_name
					AND grid.process_name = ctype.process_name
					AND grid.component_name = ctype.component_name
					AND grid.column_type = ctype.ctrl_type_name
					AND sec.customer_name = @engg_customer_name
					AND sec.project_name = @engg_project_name
					AND sec.process_name = @process_name
					AND sec.component_name = @engg_component
					AND sec.activity_name = @activity_name
					AND sec.ui_name = @ui_name_tmp
					AND isnull(sec.section_type, 'MAIN') NOT IN (
						'MAIN',
						'TREE',
						'CHART'
						)
					--AND gls.languageid = @language_code
					and grid.view_name not in ('__nodeexpand','__nodeid','__parentnodeid','__icon','__icls') -- Code added for the defect id TECH-46330
				-- Added By feroz For extjs -- End -- PNR2.0_1790
				/* Code modified by Makesh Prabu R to change the scripts 90 compatible on 05-April-10 for the Case ID: PNR2.0_26469 -- Starts */
				ORDER BY page_bt_synonym,
					section_bt_synonym,
					control_bt_synonym,
					column_no
				/* Code modified by Makesh Prabu R to change the scripts 90 compatible on 05-April-10 for the Case ID: PNR2.0_26469 -- End */
				OPTION (
					HASH
				
				UNION
					) -- code modified for PNR2.0_12645
			END

			-- For each Grid Column generate entries
			OPEN gridcurs

			WHILE (1 = 1)
			BEGIN
				FETCH NEXT
				FROM gridcurs
				INTO @column_bt_synonym_tmp,
					@col_descr_tmp,
					@controlid_tmp,
					@column_type_tmp,
					@base_ctrl_type_tmp,
					@column_no_tmp,
					@visible_length_tmp,
					@proto_tooltip_tmp,
					@sample_data_tmp,
					@page_bt_synonym_tmp,
					@section_bt_synonym_tmp,
					@control_bt_synonym_tmp,
					@mandatory_flag_tmp,
					@visible_flag_tmp,
					@editable_flag_tmp,
					@caption_req_tmp,
					@select_flag_tmp,
					@zoom_req_tmp,
					@help_req_tmp,
					@ellipses_req_tmp,
					@visible_rows_tmp,
					@datatype_tmp,
					@datalength_tmp,
					@controldoc_tmp,
					@caption_wrap_tmp,
					@caption_alignment_tmp,
					@caption_position_tmp,
					@viewname_tmp,
					@ctrl_position_tmp,
					@label_class_tmp,
					@ctrl_class_tmp,
					@password_char_tmp,
					@task_img_tmp,
					@help_img_tmp,
					@tab_sec_horder,
					@tab_sec_vorder,
					@html_text_area,
					@report_reqd,
					-- Added By Feroz
					@bulletlink_req,
					@buttoncombo_req,
					@associatedlist_req,
					@onfocustask_req,
					@listrefilltask_req,
					@dataascaption,
					@listedit_NoofColumns,
					@attach_document,
					@image_upload,
					@inplace_image,
					@image_row_height,
					@image_icon,
					@relative_url_path,
					@relative_document_path,
					@relative_image_path,
					@save_doc_content_to_db,
					@save_image_content_to_db,
					@Date_highlight_req,
					@Lite_Attach,
					@BrowseButton,
					@DeleteButton, -- Code Modified for the Bug ID : PNR2.0_27796
					@image_row_width,
					@image_preview_height,
					@image_preview_width,
					@image_preview_req,
					@Accept_Type,
					@Lite_Attach_Image,
					@Forcefit --PNR2.0_28319
					,
					@ColumnClass,
					@ColumnStyle, /*@columnhdrclass,*/
					@ismodal,
					@fileSize,
					@TemplateId,
					@col_caption_align,
					@Email,
					@Phone,
					@col_data_align,
					@ishijri,
					@col_data_align,
					@avn_download,
					@TemplateCat,
					@TemplateSpecific,
					@RatingType,
					@CaptchaData,
					@Control_class_ext6,
					@rowexpander,
					@gridtoform

				IF @@fetch_status <> 0
					BREAK

				SET @Control_cls_ext6 = ''
				SET @Icon_Class = ''

				SELECT @renderas = @column_type_tmp

				--For Control Class implementation ext6
				IF @Control_class_ext6 <> ''
					AND charindex('~', @Control_class_ext6) <> 0
				BEGIN
					SET @Control_cls_ext6 = substring(@Control_class_ext6, 1, charindex('~', @Control_class_ext6) - 1)
					SET @Icon_Class = substring(@Control_class_ext6, charindex('~', @Control_class_ext6) + 1, len(@Control_class_ext6))
				END

				IF @Control_class_ext6 <> ''
					AND charindex('~', @Control_class_ext6) = 0
					SET @Control_cls_ext6 = @Control_class_ext6

				-- code added by Ganesh for the bugid PNR2.0_2026 on 18/4/05
				-- To include the tab index property
				SELECT @tab_seq_tmp = ''

				SELECT @tab_seq_tmp = tab_index
				FROM @temp_tab_index
				WHERE ui_name = @ui_name_tmp
					AND page_bt_synonym = @page_bt_synonym_tmp
					AND control_bt_synonym = @column_bt_synonym_tmp

				IF @report_reqd = ''
					OR isnull(@report_reqd, '') = ''
					SELECT @report_reqd = 'N'

				IF isnull(@tab_seq_tmp, '') = ''
				BEGIN
					SELECT @tab_seq = ''

					SELECT @tab_seq_tmp = '' -- code added by gopinath S for the Bug ID PNR2.0_19995
				END
				ELSE
				BEGIN
					SELECT @tab_seq = @tab_seq_tmp
				END

				SELECT @decimal_length_grid = NULL -- code added by Gowrisankar M on 21-Dec-2009 for PNR2.0_25330

				 -- Added for the Defect ID: TECH-37471 Starts for Set & LEave Focus Events
set @setfocusevent			= ''
set @leavefocusevent		= ''
set @setfocuseventoccur		= ''
set @leavefocuseventoccur	= ''
set @DirectPrint			= ''
set @SpellCheckRequired		= ''
set	@UPEEnabled				= ''
set @MoreEventName			= ''

select	@setfocusevent		= upper(isnull(task_name,''))
from	ep_action_mst (nolock)
where	customer_name		= @engg_customer_name
and		project_name		= @engg_project_name
and		req_no				= @engg_req_no
and		process_name		= @process_name
and		component_name		= @engg_component
and		activity_name		= @activity_name
and		ui_name				= @ui_name_tmp
and		page_bt_synonym		= @page_bt_synonym_tmp
and		primary_control_bts	= @column_bt_synonym_tmp
and		task_descr			like 'Set Focus Event For%'

select	@leavefocusevent	= upper(isnull(task_name,''))
from	ep_action_mst (nolock)
where	customer_name		= @engg_customer_name
and		project_name		= @engg_project_name
and		req_no				= @engg_req_no
and		process_name		= @process_name
and		component_name		= @engg_component
and		activity_name		= @activity_name
and		ui_name				= @ui_name_tmp
and		page_bt_synonym		= @page_bt_synonym_tmp
and		primary_control_bts	= @column_bt_synonym_tmp
and		task_descr			like 'Leave Focus Event For%'
-- Added for the Defect ID: TECH-37471 Ends for Set & LEave Focus Events

SELECT	@setfocuseventoccur		= isnull(SetFocusEventOccurence, ''),
		@leavefocuseventoccur	= isnull(LeaveFocusEventOccurence, ''),
		@DirectPrint			= ISNULL(DirectPrint,''),
		@SpellCheckRequired		= ISNULL(IsSpellCheck,'')
FROM	es_comp_ctrl_type_mst_extn (NOLOCK)
where	customer_name		= @engg_customer_name
and		project_name		= @engg_project_name
and		process_name		= @process_name
and		component_name		= @engg_component
and		ctrl_type_name		= @column_type_tmp

-- Added for TECH-46646 
IF ISNULL(@image_icon, 'N') = 'Y' AND ISNULL(@DynamicFileUpload,'N') = 'Y'
	SELECT @ImageType = 'Dynamic'
ELSE IF ISNULL(@image_icon, 'N') = 'Y' AND ISNULL(@relative_image_path,'') <> ''AND ISNULL(@DynamicFileUpload,'N') = 'N'
	SELECT @ImageType = 'Static'

				IF @datatype_tmp = 'Numeric'
				BEGIN
					SELECT @decimal_length_grid = decimal_length
					FROM @ep_component_glossary_mst gls,
						de_business_term bts(NOLOCK),
						de_precision_type pt(NOLOCK)
					WHERE gls.customer_name = bts.customer_name
						AND gls.project_name = bts.project_name
						AND gls.process_name = bts.process_name
						AND gls.component_name = bts.component_name
						AND gls.bt_name = bts.bt_name
						AND bts.customer_name = pt.customer_name
						AND bts.project_name = pt.project_name
						AND bts.process_name = pt.process_name
						AND bts.component_name = pt.component_name
						AND bts.precision_type = pt.pt_name
						AND gls.customer_name = @engg_customer_name
						AND gls.project_name = @engg_project_name
						AND gls.process_name = @process_name
						AND gls.component_name = @engg_component
						AND gls.bt_synonym_name = @column_bt_synonym_tmp
						--AND gls.languageid = @language_code

					IF isnull(@decimal_length_grid, - 915) = - 915
					BEGIN
						SELECT @decimal_length_grid = 3
					END
				END
				ELSE
				BEGIN
					SELECT @decimal_length_grid = 0
				END

				SELECT @default_sample_data_tmp = ''

				--PNR2.0_16123
				IF @sample_data_from = 'Layout'
					AND len(@sample_data_tmp) = 0
				BEGIN
					IF @base_ctrl_type_tmp IN (
							'Edit',
							'Button',
							'Links',
							'RadioButton',
							'CheckBox',
							'DataHyperLink'
							)
						IF @ctxt_service_in IN ('BulkGenerate')
							AND @pubflag = 'P'
						BEGIN
							SELECT @sample_data_tmp = isnull(sample_data, '')
							FROM ep_published_ui_grid_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @process_name
								AND component_name = @engg_component
								AND req_no = @engg_req_no
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND page_bt_synonym = @page_bt_synonym_tmp /*Modification made by Muthupandi S for Bug id : PNR2.0_33389*/
								AND column_bt_synonym = @column_bt_synonym_tmp
								--and  languageid   =  @language_code
						END
						ELSE
						BEGIN
							SELECT @sample_data_tmp = isnull(sample_data, '')
							FROM ep_ui_grid_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND page_bt_synonym = @page_bt_synonym_tmp /*Modification made by Muthupandi S for Bug id : PNR2.0_33389*/
								AND column_bt_synonym = @column_bt_synonym_tmp
						END
					ELSE
					BEGIN
						IF @ctxt_service_in IN ('BulkGenerate')
							AND @pubflag = 'P'
						BEGIN
							SELECT @sample_data_tmp = isnull(sample_data, '')
							FROM ep_published_ui_grid_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @process_name
								AND component_name = @engg_component
								AND req_no = @engg_req_no
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND page_bt_synonym = @page_bt_synonym_tmp /*Modification made by Muthupandi S for Bug id : PNR2.0_33389*/
								AND column_bt_synonym = @column_bt_synonym_tmp
						END
						ELSE
						BEGIN
							SELECT @sample_data_tmp = isnull(sample_data, '')
							FROM ep_ui_grid_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND page_bt_synonym = @page_bt_synonym_tmp /*Modification made by Muthupandi S for Bug id : PNR2.0_33389*/
								AND column_bt_synonym = @column_bt_synonym_tmp
						END
					END
				END

				IF @sample_data_from = 'Glossary'
				BEGIN
					IF @base_ctrl_type_tmp IN (
							'Edit',
							'Button',
							'Links',
							'RadioButton',
							'CheckBox',
							'DataHyperLink'
							)
					BEGIN
						IF @ctxt_service_in IN ('BulkGenerate')
							AND @pubflag = 'P'
						BEGIN
							SELECT @sample_data_tmp = isnull(singleinst_sample_data, '')
							FROM @ep_published_comp_glossary_mst
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @process_name
								AND component_name = @engg_component
								AND req_no = @engg_req_no
								AND bt_synonym_name = @control_bt_synonym_tmp
								--AND languageid = @language_code
						END
						ELSE
						BEGIN
							SELECT @sample_data_tmp = isnull(singleinst_sample_data, '')
							FROM @ep_component_glossary_mst
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @process_name
								AND component_name = @engg_component
								AND bt_synonym_name = @control_bt_synonym_tmp
								--AND languageid = @language_code
						END
					END
					ELSE
					BEGIN
						IF @ctxt_service_in IN ('BulkGenerate')
							AND @pubflag = 'P'
						BEGIN
							SELECT @sample_data_tmp = isnull(multiinst_sample_data, '')
							FROM @ep_published_comp_glossary_mst
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @process_name
								AND component_name = @engg_component
								AND req_no = @engg_req_no
								AND bt_synonym_name = @column_bt_synonym_tmp
								--AND languageid = @language_code
						END
						ELSE
						BEGIN
							SELECT @sample_data_tmp = isnull(multiinst_sample_data, '')
							FROM @ep_component_glossary_mst
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @process_name
								AND component_name = @engg_component
								AND req_no = @engg_req_no
								AND bt_synonym_name = @column_bt_synonym_tmp
								--AND languageid = @language_code
						END
					END
				END

				IF @ctxt_service_in IN ('BulkGenerate')
					AND @pubflag = 'P'
				BEGIN
					SELECT @default_sample_data_tmp = isnull(enum_caption, '')
					FROM ep_published_enum_value_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @process_name
						AND component_name = @engg_component
						AND activity_name = @activity_name
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = @page_bt_synonym_tmp
						AND section_bt_synonym = @section_bt_synonym_tmp
						AND control_bt_synonym = @column_bt_synonym_tmp
						AND default_flag = 'Y'
				END
				ELSE
				BEGIN
					SELECT @default_sample_data_tmp = isnull(enum_caption, '')
					FROM ep_enum_value_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @process_name
						AND component_name = @engg_component
						AND activity_name = @activity_name
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = @page_bt_synonym_tmp
						AND section_bt_synonym = @section_bt_synonym_tmp
						AND control_bt_synonym = @column_bt_synonym_tmp
						AND default_flag = 'Y'
				END

				IF @base_ctrl_type_tmp = 'Combo'
				BEGIN
					IF @default_sample_data_tmp = ''
					BEGIN
						IF charindex('~', @sample_data_tmp, 1) - 1 > 0
							SELECT @default_sample_data_tmp = substring(@sample_data_tmp, 1, charindex('~', @sample_data_tmp, 1) - 1)
						ELSE
							SELECT @default_sample_data_tmp = @sample_data_tmp
					END
				END

				SELECT @popup_page = PopUp_page_bt_synonym,
					@popup_section = PopUp_section,
					@popup_close = upper(PopUp_close)
				FROM ep_action_mst(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @process_name
					AND component_name = @engg_component
					AND activity_name = @activity_name
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = @page_bt_synonym_tmp
					AND primary_control_bts = @control_bt_synonym_tmp

				---For Tooltip
				SELECT @proto_tooltip_tmp = isnull(tooltip, '')
				FROM ep_ui_tooltip_dtl_lng_extn
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @process_name
					AND component_name = @engg_component
					AND activity_name = @activity_name
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = @page_bt_synonym_tmp
					AND section_bt_synonym = @section_bt_synonym_tmp
					AND control_bt_synonym = @control_bt_synonym_tmp
					AND column_bt_synonym = @column_bt_synonym_tmp
					--AND languageid = @language_code

				-- For Static Control Types Sample Data Starts
				IF @pubflag = 'C'
				BEGIN
					IF EXISTS (
							SELECT 'x'
							FROM es_comp_stat_ctrl_type_mst(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @process_name
								AND component_name = @engg_component
								AND ctrl_type_name = @column_type_tmp
							)
					BEGIN
						SELECT @sample_data_tmp = dbo.engg_get_static_ctrl_values(@engg_customer_name, @engg_project_name, @engg_req_no, @process_name, @engg_component, @language_code, @column_type_tmp, @pubflag)

						SELECT @default_sample_data_tmp = dbo.engg_get_static_ctrl_def_value(@engg_customer_name, @engg_project_name, @engg_req_no, @process_name, @engg_component, @language_code, @column_type_tmp, @pubflag)
					END
				END
				ELSE IF @pubflag = 'P'
				BEGIN
					IF EXISTS (
							SELECT 'x'
							FROM ep_published_comp_stat_ctrl_type_mst(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND req_no = @engg_req_no
								AND process_name = @process_name
								AND component_name = @engg_component
								AND ctrl_type_name = @column_type_tmp
							)
					BEGIN
						SELECT @sample_data_tmp = dbo.engg_get_static_ctrl_values(@engg_customer_name, @engg_project_name, @engg_req_no, @process_name, @engg_component, @language_code, @column_type_tmp, @pubflag)

						SELECT @default_sample_data_tmp = dbo.engg_get_static_ctrl_def_value(@engg_customer_name, @engg_project_name, @engg_req_no, @process_name, @engg_component, @language_code, @column_type_tmp, @pubflag)
					END
				END

				-- For Static Control Types Sample Data Ends
				SELECT @col_descr_tmp = replace(@col_descr_tmp, '&', '&amp;')

				SELECT @col_descr_tmp = replace(@col_descr_tmp, '<', '&lt;')

				SELECT @col_descr_tmp = replace(@col_descr_tmp, '>', '&gt;')

				SELECT @col_descr_tmp = replace(@col_descr_tmp, '"', '&quot;')

				SELECT @sample_data_tmp = replace(@sample_data_tmp, '&', '&amp;')

				SELECT @sample_data_tmp = replace(@sample_data_tmp, '<', '&lt;')

				SELECT @sample_data_tmp = replace(@sample_data_tmp, '>', '&gt;')

				SELECT @sample_data_tmp = replace(@sample_data_tmp, '"', '&quot;')

				SELECT @default_sample_data_tmp = replace(@default_sample_data_tmp, '&', '&amp;')

				SELECT @default_sample_data_tmp = replace(@default_sample_data_tmp, '<', '&lt;')

				SELECT @default_sample_data_tmp = replace(@default_sample_data_tmp, '>', '&gt;')

				SELECT @default_sample_data_tmp = replace(@default_sample_data_tmp, '"', '&quot;')

				SELECT @controldoc_tmp = replace(@controldoc_tmp, '&', '&amp;')

				SELECT @controldoc_tmp = replace(@controldoc_tmp, '<', '&lt;')

				SELECT @controldoc_tmp = replace(@controldoc_tmp, '>', '&gt;')

				SELECT @controldoc_tmp = replace(@controldoc_tmp, '"', '&quot;')

				IF @base_ctrl_type_tmp IN (
						'Edit',
						'Combo'
						)
					SELECT @default_for_tmp = 'UI'
				ELSE IF @base_ctrl_type_tmp IN ('Button')
					SELECT @default_for_tmp = 'Trans'
				ELSE IF @base_ctrl_type_tmp IN ('Link')
					SELECT @default_for_tmp = 'Trans'

					IF @base_ctrl_type_tmp IN ('Link','DataHyperLink') --Added datahyperlink for TECH-64821
					AND @report_reqd = 'N'
					SELECT @default_for_tmp = 'Link'
				ELSE IF @base_ctrl_type_tmp IN ('Link','DataHyperLink')--Added datahyperlink for TECH-64821
					AND @report_reqd = 'Y'
					SELECT @default_for_tmp = 'Report'

				-- For Associated Task
				IF @ctxt_service_in IN ('BulkGenerate')
					AND @pubflag = 'P'
				BEGIN
					IF EXISTS (
							SELECT 'x'
							FROM ep_published_action_mst a(NOLOCK),
								es_comp_task_type_mst b(NOLOCK)
							WHERE a.customer_name = b.customer_name
								AND a.project_name = b.project_name
								AND a.component_name = b.component_name
								AND a.task_pattern = b.task_type_name
								AND a.customer_name = @engg_customer_name
								AND a.project_name = @engg_project_name
								AND a.req_no = @engg_req_no
								AND a.process_name = @process_name
								AND a.component_name = @engg_component
								AND a.activity_name = @activity_name
								AND a.ui_name = @ui_name_tmp
								AND a.page_bt_synonym = @page_bt_synonym_tmp
								AND a.primary_control_bts = @column_bt_synonym_tmp
								AND a.task_pattern = b.task_type_name
								AND a.task_type = @default_for_tmp
							)
					BEGIN
						SELECT @uitaskname_tmp = upper(task_name)
						FROM ep_published_action_mst a(NOLOCK),
							es_comp_task_type_mst b(NOLOCK)
						WHERE a.customer_name = b.customer_name
							AND a.project_name = b.project_name
							AND a.component_name = b.component_name
							AND a.task_pattern = b.task_type_name
							AND a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.req_no = @engg_req_no
							AND a.process_name = @process_name
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							AND a.page_bt_synonym = @page_bt_synonym_tmp
							AND a.primary_control_bts = @column_bt_synonym_tmp
							AND a.task_pattern = b.task_type_name
							AND a.task_type = @default_for_tmp
					END
					ELSE
					BEGIN
						SELECT @uitaskname_tmp = ''
					END
				END
				ELSE
				BEGIN
					IF EXISTS (
							SELECT 'x'
							FROM ep_action_mst a(NOLOCK),
								es_comp_task_type_mst b(NOLOCK)
							WHERE a.customer_name = b.customer_name
								AND a.project_name = b.project_name
								AND a.req_no = b.req_no
								AND a.component_name = b.component_name
								AND a.task_pattern = b.task_type_name
								AND a.customer_name = @engg_customer_name
								AND a.project_name = @engg_project_name
								AND a.process_name = @process_name
								AND a.component_name = @engg_component
								AND a.activity_name = @activity_name
								AND a.ui_name = @ui_name_tmp
								AND a.page_bt_synonym = @page_bt_synonym_tmp
								AND a.primary_control_bts = @column_bt_synonym_tmp
								AND a.task_pattern = b.task_type_name
								AND a.task_type = @default_for_tmp
							)
					BEGIN
						SELECT @uitaskname_tmp = upper(task_name)
						FROM ep_action_mst a(NOLOCK),
							es_comp_task_type_mst b(NOLOCK)
						WHERE a.customer_name = b.customer_name
							AND a.project_name = b.project_name
							AND a.req_no = b.req_no
							AND a.component_name = b.component_name
							AND a.task_pattern = b.task_type_name
							AND a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.process_name = @process_name
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							AND a.page_bt_synonym = @page_bt_synonym_tmp
							AND a.primary_control_bts = @column_bt_synonym_tmp
							AND a.task_pattern = b.task_type_name
							AND a.task_type = @default_for_tmp
					END
					ELSE
					BEGIN
						SELECT @uitaskname_tmp = ''
					END
				END

				--Code addition  for  PNR2.0_20049  starts
				SELECT @data_type_grid = ''

				SELECT @data_type_grid = bts.data_type
				FROM @ep_component_glossary_mst gls,
					de_business_term bts(NOLOCK)
				WHERE gls.customer_name = bts.customer_name
					AND gls.project_name = bts.project_name
					AND gls.process_name = bts.process_name
					AND gls.component_name = bts.component_name
					AND gls.bt_name = bts.bt_name
					AND gls.customer_name = @engg_customer_name
					AND gls.project_name = @engg_project_name
					AND gls.req_no = 'Base'
					AND gls.process_name = @process_name
					AND gls.component_name = @engg_component
					AND gls.bt_synonym_name = @column_bt_synonym_tmp
					--AND gls.languageid = @language_code

				IF isnull(@data_type_grid, '') = ''
				BEGIN
					SELECT @data_type_grid = gls.data_type
					FROM @ep_component_glossary_mst gls
					WHERE gls.customer_name = @engg_customer_name
						AND gls.project_name = @engg_project_name
						AND gls.req_no = 'Base'
						AND gls.process_name = @process_name
						AND gls.component_name = @engg_component
						AND gls.bt_synonym_name = @column_bt_synonym_tmp
						--AND gls.languageid = @language_code
				END

				IF @data_type_grid <> 'char'
					SELECT @ellipses_req_tmp = 'N'

				--Code addition  for  PNR2.0_20049  ends
				-- Code added by feroz for extjs -- start  -- PNR2.0_1790
				SELECT @type_prefix = '',
					@callout_task_tmp = 'N',
					@pivot_prop_tmp = ''

				IF EXISTS (
						SELECT 'x'
						FROM ep_ui_section_dtl(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @process_name
							AND component_name = @engg_component
							AND activity_name = @activity_name
							AND ui_name = @ui_name_tmp
							AND page_bt_synonym = @page_bt_synonym_tmp
							AND section_bt_synonym = @section_bt_synonym_tmp
							AND section_type IN (
								'Text Scroller',
								'Formatted Text',
								'Report List',
								'Property Window',
								'Pivot',
								'Tree Grid'
								)
						)
				BEGIN -- 1
					SELECT @section_type = section_type
					FROM ep_ui_section_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @process_name
						AND component_name = @engg_component
						AND activity_name = @activity_name
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = @page_bt_synonym_tmp
						AND section_bt_synonym = @section_bt_synonym_tmp

					SELECT @type_prefix = type_prefix
					FROM ep_extjs_metadata_dtl(NOLOCK)
					WHERE Extjs_type = @section_type
						AND task_req = 'y'

					IF (@section_bt_synonym_tmp + '_' + @type_prefix = @column_bt_synonym_tmp)
					BEGIN -- 2
						IF @pubflag = 'P'
						BEGIN -- 3
							SELECT @uitaskname_tmp = upper(isnull(RVW_Task, '')),
								@sample_data_tmp = isnull(sample_data, ''),
								@callout_task_tmp = CASE 
									WHEN callout_task = 0
										THEN 'N'
									ELSE 'Y'
									END
							FROM ep_published_ext_js_section_dtl a(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND req_no = @engg_req_no
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND page_bt_synonym = @page_bt_synonym_tmp
								AND section_bt_synonym = @section_bt_synonym_tmp
						END -- 3
						ELSE
						BEGIN -- 3
							SELECT @uitaskname_tmp = upper(isnull(RVW_Task, '')),
								@sample_data_tmp = isnull(sample_data, ''),
								@callout_task_tmp = CASE 
									WHEN callout_task = 0
										THEN 'N'
									ELSE 'Y'
									END
							FROM ep_ext_js_section_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND page_bt_synonym = @page_bt_synonym_tmp
								AND section_bt_synonym = @section_bt_synonym_tmp
						END -- 3
					END -- 2

					IF EXISTS (
							SELECT 'x'
							FROM ep_ext_js_section_column_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND page_bt_synonym = @page_bt_synonym_tmp
								AND section_bt_synonym = @section_bt_synonym_tmp
								AND control_bt_synonym = @control_bt_synonym_tmp
								AND column_bt_synonym = @column_bt_synonym_tmp
							)
					BEGIN -- 4
						IF @pubflag = 'P'
						BEGIN -- 5
							SELECT @uitaskname_tmp = upper(isnull(RVW_Task, '')),
								@sample_data_tmp = isnull(sample_data, ''),
								@callout_task_tmp = CASE 
									WHEN callout_task = 0
										THEN 'N'
									ELSE 'Y'
									END,
								@label_class_tmp = isnull(label_class, ''),
								@ctrl_class_tmp = isnull(control_class, ''),
								@pivot_prop_tmp = ' GroupingSynonym="' + isnull(grouping_synonym, '') + '" GroupingFunction="' + isnull(grouping_function, '') + '" PivotSeqno="' + (convert(VARCHAR, isnull(pivot_sequence, 0))) + '" FieldList="' + CASE 
									WHEN isnull(FieldList, 0) = 0
										THEN 'N'
									ELSE 'Y'
									END + '" DragOption="' + isnull(Default_Dragoption, '') + '" IsKey="' + CASE 
									WHEN isnull(IS_Key, 0) = 0
										THEN 'N'
									ELSE 'Y'
									END + '"'
							FROM ep_published_ext_js_section_column_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND req_no = @engg_req_no
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND page_bt_synonym = @page_bt_synonym_tmp
								AND section_bt_synonym = @section_bt_synonym_tmp
								AND control_bt_synonym = @control_bt_synonym_tmp
								AND column_bt_synonym = @column_bt_synonym_tmp
						END -- 5
						ELSE
						BEGIN -- 5
							SELECT @uitaskname_tmp = upper(isnull(RVW_Task, '')),
								@sample_data_tmp = isnull(sample_data, ''),
								@callout_task_tmp = CASE 
									WHEN callout_task = 0
										THEN 'N'
									ELSE 'Y'
									END,
								@label_class_tmp = isnull(label_class, ''),
								@ctrl_class_tmp = isnull(control_class, ''),
								@pivot_prop_tmp = ' GroupingSynonym="' + isnull(grouping_synonym, '') + '" GroupingFunction="' + isnull(grouping_function, '') + '" PivotSeqno="' + (convert(VARCHAR, isnull(pivot_sequence, 0))) + '" FieldList="' + CASE 
									WHEN isnull(FieldList, 0) = 0
										THEN 'N'
									ELSE 'Y'
									END + '" DragOption="' + isnull(Default_Dragoption, '') + '" IsKey="' + CASE 
									WHEN isnull(IS_Key, 0) = 0
										THEN 'N'
									ELSE 'Y'
									END + '"'
							FROM ep_ext_js_section_column_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND page_bt_synonym = @page_bt_synonym_tmp
								AND section_bt_synonym = @section_bt_synonym_tmp
								AND control_bt_synonym = @control_bt_synonym_tmp
								AND column_bt_synonym = @column_bt_synonym_tmp
						END -- 5
					END -- 4

					IF EXISTS (
							SELECT 'x'
							FROM de_published_ext_js_section_column(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND ecrno = @engg_req_no
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND page_bt_synonym = @page_bt_synonym_tmp
								AND section_bt_synonym = @section_bt_synonym_tmp
								AND control_bt_synonym = @control_bt_synonym_tmp
								AND column_bt_synonym = @column_bt_synonym_tmp
								AND section_type = 'Tree Grid'
							)
					BEGIN -- 4
						SELECT /*@visible_length_tmp	= ISNULL(visible_length,@visible_length_tmp)
--,@treeGrdNew		= 'ImageColumn="' +  isnull(image_column,'') + '" '
,*/ @ColumnStyle = ISNULL(image_column, @ColumnStyle)
						FROM de_published_ext_js_section_column(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND ecrno = @engg_req_no
							AND process_name = @process_name
							AND component_name = @engg_component
							AND activity_name = @activity_name
							AND ui_name = @ui_name_tmp
							AND page_bt_synonym = @page_bt_synonym_tmp
							AND section_bt_synonym = @section_bt_synonym_tmp
							AND control_bt_synonym = @control_bt_synonym_tmp
							AND column_bt_synonym = @column_bt_synonym_tmp
					END -- 4
				END -- 1

				IF EXISTS (
						SELECT 'x'
						FROM es_comp_ctrl_type_mst_vw ty(NOLOCK),
							ep_ui_control_dtl ct(NOLOCK)
						WHERE ty.customer_name = ct.customer_name
							AND ty.project_name = ct.project_name
							AND ty.process_name = ct.process_name
							AND ty.component_name = ct.component_name
							AND ty.ctrl_type_name = ct.control_type
							AND ct.customer_name = @engg_customer_name
							AND ct.project_name = @engg_project_name
							AND ct.process_name = @process_name
							AND ct.component_name = @engg_component
							AND ct.activity_name = @activity_name
							AND ct.ui_name = @ui_name_tmp
							AND ct.page_bt_synonym = @page_bt_synonym_tmp
							AND ct.section_bt_synonym = @section_bt_synonym_tmp
							AND ct.control_bt_synonym = @control_bt_synonym_tmp
							AND ty.Is_Extjs_Control = 'y'
						)
				BEGIN -- 1
					SELECT @extjs_ctrl_type = ty.Extjs_Ctrl_type,
						@control_type_tmp = ct.control_type
					FROM es_comp_ctrl_type_mst_vw ty(NOLOCK),
						ep_ui_control_dtl ct(NOLOCK)
					WHERE ty.customer_name = ct.customer_name
						AND ty.project_name = ct.project_name
						AND ty.process_name = ct.process_name
						AND ty.component_name = ct.component_name
						AND ty.ctrl_type_name = ct.control_type
						AND ct.customer_name = @engg_customer_name
						AND ct.project_name = @engg_project_name
						AND ct.process_name = @process_name
						AND ct.component_name = @engg_component
						AND ct.activity_name = @activity_name
						AND ct.ui_name = @ui_name_tmp
						AND ct.page_bt_synonym = @page_bt_synonym_tmp
						AND ct.section_bt_synonym = @section_bt_synonym_tmp
						AND ct.control_bt_synonym = @control_bt_synonym_tmp
						AND ty.Is_Extjs_Control = 'y'

					IF @extjs_ctrl_type IN (
							'TextType Writer',
							'Marquee Ticker',
							'EMail'
							)
					BEGIN -- 2
						SELECT @type_prefix = type_prefix
						FROM ep_extjs_metadata_dtl(NOLOCK)
						WHERE Extjs_type = @extjs_ctrl_type
							AND task_req = 'y'

						IF (@control_bt_synonym_tmp + '_' + @type_prefix = @column_bt_synonym_tmp)
						BEGIN -- 3
							IF @pubflag = 'P'
							BEGIN -- 4
								SELECT @uitaskname_tmp = upper(isnull(RVW_Task, '')),
									@sample_data_tmp = isnull(sample_data, ''),
									@callout_task_tmp = CASE 
										WHEN callout_task = 0
											THEN 'N'
										ELSE 'Y'
										END
								FROM ep_published_ext_js_control_dtl(NOLOCK)
								WHERE customer_name = @engg_customer_name
									AND project_name = @engg_project_name
									AND req_no = @engg_req_no
									AND process_name = @process_name
									AND component_name = @engg_component
									AND activity_name = @activity_name
									AND ui_name = @ui_name_tmp
									AND page_bt_synonym = @page_bt_synonym_tmp
									AND section_bt_synonym = @section_bt_synonym_tmp
									AND control_bt_synonym = @control_bt_synonym_tmp
							END -- 4
							ELSE
							BEGIN -- 4
								SELECT @uitaskname_tmp = upper(isnull(RVW_Task, '')),
									@sample_data_tmp = isnull(sample_data, ''),
									@callout_task_tmp = CASE 
										WHEN callout_task = 0
											THEN 'N'
										ELSE 'Y'
										END
								FROM ep_ext_js_control_dtl(NOLOCK)
								WHERE customer_name = @engg_customer_name
									AND project_name = @engg_project_name
									AND process_name = @process_name
									AND component_name = @engg_component
									AND activity_name = @activity_name
									AND ui_name = @ui_name_tmp
									AND page_bt_synonym = @page_bt_synonym_tmp
									AND section_bt_synonym = @section_bt_synonym_tmp
									AND control_bt_synonym = @control_bt_synonym_tmp
							END -- 4
						END -- 3
					END -- 2
				END -- 1

				-- Code Added By Feroz For List edit
				SELECT @associatedlist_name = '',
					@primary_search_column = '',
					@list_index_search = '',
					@hidden_view_name = '',
					@mapped_list_controlid = '',
					@mapped_list_viewname = ''

				IF isnull(@date_highlight_req, 'N') = 'Y'
				BEGIN
					IF @pubflag = 'P'
					BEGIN
						SELECT TOP 1 @associatedlist_name = Upper(a.listedit_controlid)
						FROM ep_published_date_highlight_control_map a(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.req_no = @engg_req_no
							AND a.process_name = @process_name
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							AND a.page_bt_synonym = @page_bt_synonym_tmp
							AND a.section_bt_synonym = @section_bt_synonym_tmp
							AND a.control_bt_synonym = @column_bt_synonym_tmp

						SELECT @mapped_list_controlid = upper(controlid),
							@mapped_list_viewname = upper(viewname)
						FROM #maplist -- code modified by gopinath S for the call ID PNR2.0_24034
						WHERE activityname = @activity_name
							AND ilbocode = @ui_name_tmp
							AND listedit = @associatedlist_name
					END
					ELSE
					BEGIN
						SELECT TOP 1 @associatedlist_name = Upper(a.listedit_controlid)
						FROM ep_date_highlight_control_map a(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.process_name = @process_name
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							AND a.page_bt_synonym = @page_bt_synonym_tmp
							AND a.section_bt_synonym = @section_bt_synonym_tmp
							AND a.control_bt_synonym = @column_bt_synonym_tmp

						SELECT @mapped_list_controlid = upper(controlid),
							@mapped_list_viewname = upper(viewname)
						FROM #maplist -- code modified by gopinath S for the call ID PNR2.0_24034
						WHERE activityname = @activity_name
							AND ilbocode = @ui_name_tmp
							AND listedit = @associatedlist_name
					END
				END

				IF @pubflag = 'P'
				BEGIN
					IF EXISTS (
							SELECT 'x'
							FROM ep_published_date_highlight_control_map a(NOLOCK)
							WHERE a.customer_name = @engg_customer_name
								AND a.project_name = @engg_project_name
								AND a.req_no = @engg_req_no
								AND a.process_name = @process_name
								AND a.component_name = @engg_component
								AND a.activity_name = @activity_name
								AND a.ui_name = @ui_name_tmp
								AND a.listedit_synonym = @control_bt_synonym_tmp
							)
						SELECT @base_ctrl_type_tmp = 'LISTEDIT'
				END
				ELSE
				BEGIN
					IF EXISTS (
							SELECT 'x'
							FROM ep_date_highlight_control_map a(NOLOCK)
							WHERE a.customer_name = @engg_customer_name
								AND a.project_name = @engg_project_name
								AND a.process_name = @process_name
								AND a.component_name = @engg_component
								AND a.activity_name = @activity_name
								AND a.ui_name = @ui_name_tmp
								AND a.listedit_synonym = @control_bt_synonym_tmp
							)
						SELECT @base_ctrl_type_tmp = 'LISTEDIT'
				END

				IF isnull(@associatedlist_req, 'N') = 'Y'
				BEGIN
					IF @pubflag = 'P'
					BEGIN
						SELECT TOP 1 @associatedlist_name = upper(b.listedit_controlid)
						FROM ep_published_listedit_control_map a(NOLOCK),
							ep_published_listedit_column_dtl b(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.req_no = @engg_req_no
							AND a.process_name = @process_name
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							AND a.page_bt_synonym = @page_bt_synonym_tmp
							AND a.section_bt_synonym = @section_bt_synonym_tmp
							AND a.mapped_bt_synonym = @column_bt_synonym_tmp
							AND a.customer_name = b.customer_name
							AND a.project_name = b.project_name
							AND a.req_no = b.req_no
							AND a.process_name = b.process_name
							AND a.component_name = b.component_name
							AND a.activity_name = b.activity_name
							AND a.ui_name = b.ui_name
							AND a.listedit_synonym = b.listedit_synonym

						SELECT @mapped_list_controlid = upper(controlid),
							@mapped_list_viewname = upper(viewname)
						FROM #maplist -- code modified by gopinath S for the call ID PNR2.0_24034
						WHERE activityname = @activity_name
							AND ilbocode = @ui_name_tmp
							AND listedit = @associatedlist_name
					END
					ELSE
					BEGIN
						SELECT TOP 1 @associatedlist_name = upper(b.listedit_controlid)
						FROM ep_listedit_control_map a(NOLOCK),
							ep_listedit_column_dtl b(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.process_name = @process_name
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							AND a.page_bt_synonym = @page_bt_synonym_tmp
							AND a.section_bt_synonym = @section_bt_synonym_tmp
							AND a.mapped_bt_synonym = @column_bt_synonym_tmp
							AND a.customer_name = b.customer_name
							AND a.project_name = b.project_name
							AND a.process_name = b.process_name
							AND a.component_name = b.component_name
							AND a.activity_name = b.activity_name
							AND a.ui_name = b.ui_name
							AND a.listedit_synonym = b.listedit_synonym

						SELECT @mapped_list_controlid = upper(controlid),
							@mapped_list_viewname = upper(viewname)
						FROM #maplist -- code modified by gopinath S for the call ID PNR2.0_24034
						WHERE activityname = @activity_name
							AND ilbocode = @ui_name_tmp
							AND listedit = @associatedlist_name
					END
				END

				IF @pubflag = 'P'
				BEGIN
					IF EXISTS (
							SELECT 'x'
							FROM ep_published_listedit_column_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND req_no = @engg_req_no
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND listedit_synonym = @control_bt_synonym_tmp
							)
						SELECT @base_ctrl_type_tmp = 'LISTEDIT'
				END
				ELSE
				BEGIN
					IF EXISTS (
							SELECT 'x'
							FROM ep_listedit_column_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND listedit_synonym = @control_bt_synonym_tmp
							)
						SELECT @base_ctrl_type_tmp = 'LISTEDIT'
				END

				IF @pubflag = 'P'
				BEGIN
					IF EXISTS (
							SELECT 'x'
							FROM ep_published_listedit_column_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND req_no = @engg_req_no
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND listedit_synonym = @control_bt_synonym_tmp
								AND listedit_column_synonym = @column_bt_synonym_tmp
							)
						SELECT @viewname_tmp = lower(@controlid_tmp) + lower(@viewname_tmp)
				END
				ELSE
				BEGIN
					IF EXISTS (
							SELECT 'x'
							FROM ep_listedit_column_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND req_no = 'Base'
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND listedit_synonym = @control_bt_synonym_tmp
								AND listedit_column_synonym = @column_bt_synonym_tmp
							)
						SELECT @viewname_tmp = lower(@controlid_tmp) + lower(@viewname_tmp)
				END

				IF EXISTS (
						SELECT 'x'
						FROM es_comp_ctrl_type_mst(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @process_name
							AND component_name = @engg_component
							AND ctrl_type_name = @column_type_tmp
							AND (
								isnull(attach_document, 'N') = 'Y'
								OR isnull(image_upload, 'N') = 'Y'
								)
						)
				BEGIN
					SELECT @hidden_view_name = Upper(view_name)
					FROM de_hidden_view(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @process_name
						AND component_name = @engg_component
						AND activity_name = @activity_name
						AND ui_name = @ui_name_tmp
						AND page_name = @page_bt_synonym_tmp
						AND section_name = @section_bt_synonym_tmp
						AND control_bt_synonym = @column_bt_synonym_tmp
				END

				-- Code Added By Feroz For List edit
				-- Modified By feroz for bug id :PNR2.0_23654
				SELECT @visible_rows_tmp = visisble_rows
				FROM es_comp_ctrl_type_mst(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @process_name
					AND component_name = @engg_component
					AND ctrl_type_name = @column_type_tmp -- Modified By Feroz for bug id : PNR2.0_23862
					-- Modified By feroz for bug id :PNR2.0_23654

				--Code modified by Kanagavel A to allow values given in grid info
				--code modified for PLF2.0_07135 starts
				IF @base_ctrl_type_tmp = 'LISTEDIT'
				BEGIN
					SELECT @visible_length_tmp = 0

					IF EXISTS (
							SELECT 'x'
							FROM ep_listedit_column_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND listedit_controlid = @controlid_tmp
								AND listedit_column_synonym = @column_bt_synonym_tmp
								AND isnull(visible_length, 0) <> 0
							)
					BEGIN
						SELECT @visible_length_tmp = visible_length
						FROM ep_listedit_column_dtl(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @process_name
							AND component_name = @engg_component
							AND activity_name = @activity_name
							AND ui_name = @ui_name_tmp
							AND listedit_controlid = @controlid_tmp
							AND listedit_column_synonym = @column_bt_synonym_tmp
							AND isnull(visible_length, 0) <> 0
					END
				END

				--code modified for PLF2.0_07135 End
				SELECT @sample_data_tmp = replace(@sample_data_tmp, '&', '&amp;')

				SELECT @sample_data_tmp = replace(@sample_data_tmp, '<', '&lt;')

				SELECT @sample_data_tmp = replace(@sample_data_tmp, '>', '&gt;')

				SELECT @sample_data_tmp = replace(@sample_data_tmp, '"', '&quot;')

				-- Code added by feroz for extjs -- end -- PNR2.0_1790
--if isnull(@viewname_tmp,'') in ( 'tagkeyfield','tagseqno','tagvalue')
--	select @viewname_tmp = CONVERT(VARCHAR,@column_no_tmp)

select	@editmask		= isnull(EditMask,'N')
from    es_comp_ctrl_type_mst (nolock)
where   customer_name   = @engg_customer_name
and		project_name    = @engg_project_name
and		process_name    = @process_name
and		component_name  = @engg_component
and		ctrl_type_name	= @column_type_tmp

If isnull(@editmask,'N')	= 'Y'
	
		select @column_type_tmp = 'EDITMASK'
	else
		select @column_type_tmp = @column_type_tmp

--- TECH-23600 Starts
if @base_ctrl_type_tmp in ('Datahyperlink')  
select @base_ctrl_type_tmp = 'Link'

--- TECH-23600 Ends

-- Added for TECH-35368 For Calendar Starts
if exists ( select 'x'
from    es_comp_ctrl_type_mst_vw typ (nolock),
		ep_ui_control_dtl  ctl (nolock)
where   typ.customer_name		= ctl.customer_name
and		typ.project_name		= ctl.project_name
and		typ.process_name		= ctl.process_name
and		typ.component_name		= ctl.component_name
and		typ.ctrl_type_name		= ctl.control_type

and		ctl.customer_name		= @engg_customer_name
and		ctl.project_name		= @engg_project_name
and		ctl.process_name		= @process_name
and		ctl.component_name		= @engg_component
and		ctl.activity_name		= @activity_name
and		ctl.ui_name				= @ui_name_tmp
and		ctl.page_bt_synonym		=  @page_bt_synonym_tmp
and		ctl.section_bt_synonym	=  @section_bt_synonym_tmp
and		ctl.control_bt_synonym	=  @control_bt_synonym_tmp
and		typ.RenderAs			LIKE 'CALENDAR_%')
	SELECT @viewname_tmp	= @viewname_tmp
ELSE
	SELECT @viewname_tmp	= LOWER(@viewname_tmp)
-- Added for TECH-35368 For Calendar Ends

--TECH-72114
SELECT @BadgeText = ''

SELECT	@BadgeText		= ISNULL(BadgeText,'N')
FROM    es_comp_ctrl_type_mst_Extn WITH (NOLOCK)
WHERE   customer_name   = @engg_customer_name
AND		project_name    = @engg_project_name
AND		process_name    = @process_name
AND		component_name  = @engg_component
AND		ctrl_type_name	= @column_type_tmp
AND		base_ctrl_type	= 'DataHyperLink'

IF ISNULL(@BadgeText,'')	= ''
	SELECT @BadgeText = 'N'
--TECH-72114
				-- Insert Column  Entry
				SELECT @xml_seq_tmp = @xml_seq_tmp + 1

				SELECT @helptext = @ctrl_descr_tmp + ' - Datatype : ' + ltrim(rtrim(isnull(@datatype_tmp, ''))) + ' - MaxLength : ' + ltrim(rtrim(isnull(@datalength_tmp, '')))

				IF upper(isnull(@datatype_tmp, '')) = 'NUMERIC'
					SELECT @helptext = @helptext + ' - DecimalLength : ' + ltrim(rtrim(isnull(@datalength_tmp, '')))

				INSERT INTO ep_genxml_tmp (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					activity_name,
					guid,
					gen_xml,
					seq_no
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@process_name,
					@engg_component,
					@activity_name,
					@guid,
					'<Column Name="' + ltrim(rtrim(@column_bt_synonym_tmp)) + '" ' + 
					'RenderAs="'  + ltrim(rtrim(isnull(@base_ctrl_type_tmp,'')))          + '" ' + -- Added for Defect ID: TECH-35368
					--'RenderAs="'  + ltrim(rtrim(isnull(@column_type_tmp,'')))          + '" ' +
					'ColumnCaption="' + ltrim(rtrim(@col_descr_tmp)) + '" ' + 'ControlName="' + ltrim(rtrim(@controlid_tmp)) + '" ' + 'SectionName="' + ltrim(rtrim(@section_bt_synonym_tmp)) + '" ' + 'PageName="' + ltrim(rtrim(@page_bt_synonym_tmp)) + '" ' + 'ILBOName="' + ltrim(rtrim(@ui_name_tmp)) + '" ' + 'ActivityName="' + ltrim(rtrim(@activity_name)) + '" ' + 'ComponentName="' + ltrim(rtrim(@engg_component)) + '" ' + 'ControlType="' + ltrim(rtrim(upper(@column_type_tmp))) + '" ' + 'BaseControlType="' + ltrim(rtrim(isnull(upper(@base_ctrl_type_tmp), ''))) + '" ' + -- Code modification  for  PNR2.0_23635
					'BTSynonym="' + ltrim(rtrim(@column_bt_synonym_tmp)) + '" ' + 'ColumnNo="' + ltrim(rtrim(CONVERT(VARCHAR, @column_no_tmp))) + '" ' + 'VisibleLength="' + ltrim(rtrim(CONVERT(VARCHAR, @visible_length_tmp))) + '" ' + 'ProtoTooltip="' + ltrim(rtrim(@proto_tooltip_tmp)) + '" ' + 'SampleData="' + ltrim(rtrim(@sample_data_tmp)) + '" ' + 'DefaultSampleData="' + ltrim(rtrim(isnull(@default_sample_data_tmp, ''))) + '" ' + 'Mandatory="' + ltrim(rtrim(@mandatory_flag_tmp)) + '" ' + 'Visible="' + ltrim(rtrim(@visible_flag_tmp)) + '" ' + 'Editable="' + ltrim(rtrim(@editable_flag_tmp)) + '" ' + 'CaptionRequired="' + ltrim(rtrim(@caption_req_tmp)) + '" ' + 'SelectFlag="' + ltrim(rtrim(@select_flag_tmp)) + '" ' + 'ZoomRequired="' + ltrim(rtrim(@zoom_req_tmp)) + '" ' 
+ 'HelpRequired="' + ltrim(rtrim(@help_req_tmp)) + '" ' + 'EllipsesRequired="' + ltrim(rtrim(@ellipses_req_tmp)) + '" ' + 'AssociatedTask="' + ltrim(rtrim(@uitaskname_tmp)) + '" ' +
					-- code modified by Anuradha on 24-Mar-2006 for the Bug ID :: PNR2.0_7393
					--      'DataType="'   + ltrim(rtrim(isnull(@datatype_tmp,'')))   + '" ' +
					--      'DataLength="'   + ltrim(rtrim(isnull(@datalength_tmp,'')))   + '" ' +
					--      'DecimalLength="'  + isnull(convert(varchar, @decimal_length_grid),'')        + '" ' +
					'DataType="' + CASE ltrim(rtrim(isnull(@base_ctrl_type_tmp, ''))) + '-' + ltrim(rtrim(isnull(@datatype_tmp, '')))
						WHEN 'COMBO-INTEGER'
							THEN ''
						ELSE ltrim(rtrim(isnull(@datatype_tmp, '')))
						END + '" ' + 'DataLength="' + CASE ltrim(rtrim(isnull(@base_ctrl_type_tmp, ''))) + '-' + ltrim(rtrim(isnull(@datatype_tmp, '')))
						WHEN 'COMBO-INTEGER'
							THEN ''
						ELSE ltrim(rtrim(isnull(@datalength_tmp, '')))
						END + '" ' + 'DecimalLength="' + CASE ltrim(rtrim(isnull(@base_ctrl_type_tmp, ''))) + '-' + ltrim(rtrim(isnull(@datatype_tmp, '')))
						WHEN 'COMBO-INTEGER'
							THEN ''
						ELSE isnull(convert(VARCHAR, @decimal_length_grid), '')
						END + '" ' + 'ColumnWrap="' + ltrim(rtrim(isnull(@caption_wrap_tmp, 'Y'))) + '" ' + 'ColumnAlignment="' + ltrim(rtrim(isnull(@caption_alignment_tmp, 'LEFT'))) + '" ' + 'ColumnPosition="' + ltrim(rtrim(isnull(@caption_position_tmp, 'LEFT'))) + '" ' 
+ 'ControlPosition="' + ltrim(rtrim(isnull(@ctrl_position_tmp, 'LEFT'))) + '" ' + 'LabelClass="' + ltrim(rtrim(isnull(@label_class_tmp, ''))) + '" ' + 
'ControlClass="' + ltrim(rtrim(isnull(@ctrl_class_tmp, ''))) + '" ' + 'PasswordChar="' + ltrim(rtrim(isnull(@password_char_tmp, 'N'))) + '" ' + 
'TaskImageClass="' + ltrim(rtrim(isnull(@task_img_tmp, ''))) + '" ' + 'HelpImageClass="' + ltrim(rtrim(isnull(@help_img_tmp, ''))) + '" ' + 
'Documentation="' + ltrim(rtrim(isnull(@controldoc_tmp, ''))) + '" ' + 
'ViewName="' + ltrim(rtrim(isnull(@viewname_tmp, ''))) + '" ' + 'VisibleRows="' + ltrim(rtrim(CONVERT(VARCHAR, isnull(@visible_rows_tmp, 0)))) + '" ' + -- code modified for BugID : PNR2.0_23999
					'HTMLTextArea="' + ltrim(rtrim(isnull(@html_text_area, 'N'))) + '" ' + 'ReportRequired="' + ltrim(rtrim(isnull(@report_reqd, ''))) + '" ' + 'HelpText="' + ltrim(rtrim(isnull(@helptext, ''))) + '" ' + 'CalloutTask="' + ltrim(rtrim(isnull(@callout_task_tmp, ''))) + '" ' + -- added by Feroz for extjs -- PNR2.0_1790
					-- Added By Feroz
				'BulletLink="' + ltrim(rtrim(isnull(@bulletlink_req, 'N'))) + '" ' + 'ButtonCombo="' + ltrim(rtrim(isnull(@buttoncombo_req, 'N'))) + '" ' + 'DataAsCaption="' + ltrim(rtrim(isnull(@dataascaption, 'N'))) + '" ' + 'AssociatedList="' + ltrim(rtrim(isnull
(@associatedlist_name, ''))) + '" ' + 'MappedListControlID="' + ltrim(rtrim(isnull(@mapped_list_controlid, ''))) + '" ' + 'MappedListViewName="' + ltrim(rtrim(isnull(@mapped_list_viewname, ''))) + '" ' + 'AttachDocument="' + ltrim(rtrim(isnull(@attach_document, 'N'))) + '" ' + 'ImageUpload="' + ltrim(rtrim(isnull(@image_upload, 'N'))) + '" ' + 'InplaceImage="' + ltrim(rtrim(isnull(@inplace_image, 'N'))) + '" ' + 'ImageIcon="' + ltrim(rtrim(isnull(@image_icon, 'N'))) + '" ' + 'ImageRowHeight="' + ltrim(rtrim(isnull(@image_row_height, '0'))) + '" ' + 'RelativeUrlPath="' + ltrim(rtrim(isnull(@relative_url_path, ''))) + '" ' + 'RelativeDocumentPath="' + ltrim(rtrim(isnull(@relative_document_path, ''))) + '" ' + 'RelativeImagePath="' + ltrim(rtrim(isnull(@relative_image_path, ''))) + '" ' + 'SaveDocContentToDb="' + ltrim(
						rtrim(isnull(@save_doc_content_to_db, 'N'))) + '" ' + 'SaveImageContentToDb="' + ltrim(rtrim(isnull(@save_image_content_to_db, 'N'))) + '" ' + 'DateHighlight="' + ltrim(rtrim(isnull(@date_highlight_req, 'N'))) + '" ' + 'LinkedHiddenViewName="' + ltrim(rtrim(isnull(@hidden_view_name, ''))) + '" ' + 'TabIndex="' + ltrim(rtrim(@tab_seq)) + '" LiteAttach="' + Isnull(@Lite_Attach, 'N') + '" Browse_Button="' + Isnull(@BrowseButton, 'N') + '" Delete_Button="' + Isnull(@DeleteButton, 'N') + '" ' + --PNR2.0_28365 -- Code Modified For BUGID PNR2.0_28537
					--code added for the caseid : PNR2.0_28319 starts
					'image_row_width="' + CONVERT(VARCHAR, isnull(@image_row_width, 0), 4) + '" ' + 'image_preview_height="' + CONVERT(VARCHAR, isnull(@image_preview_height, 0), 4) + '" ' + 'image_preview_width="' + CONVERT(VARCHAR, isnull(@image_preview_width, 0), 4) +
 '" ' + 'image_preview_req="' + isnull(@image_preview_req, 'N') + '" ' + 'Accept_Type="' + isnull(@Accept_Type, '') + '" ' + 'Lite_Attach_Image="' + isnull(@Lite_Attach_Image, 'N') + '" ' + 'Forcefit="' + isnull(@Forcefit, 'N') + '" ' + isnull(@pivot_prop_tmp, '') + ' ' + 'ColumnClass="' + isnull(@ColumnClass, '') + '" ' + -- added by Feroz for extjs -- PNR2.0_1790 -- Code Modified for the Bug ID : PNR2.0_27796
					--'ColumnHdrClass="' +   isnull(@ColumnHdrClass,'') +'" ' +
					'ColumnStyle="' + isnull(@ColumnStyle, '') + '" ' + 'IsModal="' + CONVERT(VARCHAR, isnull(@IsModal, ''), 4) + '" ' +
					--'PopUpPage="'           +  	isnull(@popup_page,'')                  +'" ' +
					--'PopUpSection="'        +   isnull(@popup_section,'')               +'" ' +
					--'PopUpClose="'          +   isnull(@popup_Close,'N') +'" ' + 
					'FileSize="' + isnull(@filesize, '') + '" ' + 'Email="' + isnull(@Email, 'N') + '" ' + 'Phone="' + isnull(@Phone, 'N') + '" ' + 
					'TemplateID="' + isnull(@templateid, '') + '" ' + 'IsITK="' + isnull(@itk_req, 'N') + '" ' + 'ishijri="' + isnull(@ishijri, '') + '" ' + 
					'ColDataAlign="' + isnull(@col_data_align, '') + '" ' + 'AvnFileDownload="' + isnull(@avn_download, '') + '" ' + 
					'TemplateCategory="' + isnull(@TemplateCat, '') + '" ' + 'TemplateSpecification="' + isnull(@TemplateSpecific, '') + '" ' + 
					'RatingType="' + ltrim(rtrim(isnull(lower(@RatingType), ''))) + '" ' + 'CaptchaData="' + ltrim(rtrim(isnull(lower(@CaptchaData), ''))) + '" ' + 
					'ColumnClassExt6="' + isnull(lower(@Control_cls_ext6), '') + '" ' + 'IconClass="' + isnull(@Icon_Class, '') + '" 
					' + 'RowExpander="' + isnull(@rowexpander, 'N') + '" ' + 'GridToForm="' + isnull(@gridtoform, 'N') + '" ' + 
					'BadgeText="'		+ isnull(@BadgeText,'N')  + '" ' +			--TECH-72114
					'ColHdrAlign="' + isnull(@col_caption_align, '') + '" />',
					@xml_seq_tmp
					)
			END

			CLOSE gridcurs

			DEALLOCATE gridcurs

			-- Insert Closing entry for Grid Columns
			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'</GridColumns>',
				@xml_seq_tmp
				)

			-- Insert Base Entry for Radio Buttons
			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'<RadioButtons>',
				@xml_seq_tmp
				)

			-- Fetch Radio Button Control Details
			IF @ctxt_service_in IN ('BulkGenerate')
				AND @pubflag = 'P'
			BEGIN
				DECLARE radiocurs INSENSITIVE CURSOR
				FOR
				SELECT upper(rad.button_code),
					rad.seq_no,
					rad.button_caption,
					upper(rad.default_flag),
					upper(rad.page_bt_synonym),
					upper(rad.section_bt_synonym),
					upper(rad.control_bt_synonym),
					upper(control_id),
					upper(isnull(caption_wrap, 'Y')),
					upper(isnull(caption_alignment, 'LEFT')),
					upper(isnull(caption_position, 'LEFT')),
					upper(isnull(mandatory_flag, 'N')),
					upper(isnull(ctrl_position, 'LEFT')),
					upper(isnull(LabelClass, '')),
					upper(isnull(controlclass, '')),
					isnull(rad.horder, 0),
					isnull(rad.vorder, 0),
					rad1.button_caption
				FROM ep_published_radio_button_dtl_lng_extn rad(NOLOCK),
					ep_published_radio_button_dtl_lng_extn rad1(NOLOCK), --code modified for bugid:PNR2.0_8637
					ep_published_ui_control_dtl ctrl(NOLOCK),
					ep_published_ui_section_dtl sec(NOLOCK),
					es_comp_ctrl_type_mst_vw ctype(NOLOCK)
				WHERE rad.customer_name = ctrl.customer_name
					AND rad.project_name = ctrl.project_name
					AND rad.req_no = ctrl.req_no
					AND rad.process_name = ctrl.process_name
					AND rad.component_name = ctrl.component_name
					AND rad.activity_name = ctrl.activity_name
					AND rad.ui_name = ctrl.ui_name
					AND rad.page_bt_synonym = ctrl.page_bt_synonym
					AND rad.section_bt_synonym = ctrl.section_bt_synonym
					AND rad.control_bt_synonym = ctrl.control_bt_synonym
					--code modified for bugid:PNR2.0_8637
					AND rad.customer_name = rad1.customer_name
					AND rad.project_name = rad1.project_name
					AND rad.req_no = rad1.req_no
					AND rad.process_name = rad1.process_name
					AND rad.component_name = rad1.component_name
					AND rad.activity_name = rad1.activity_name
					AND rad.ui_name = rad1.ui_name
					AND rad.page_bt_synonym = rad1.page_bt_synonym
					AND rad.section_bt_synonym = rad1.section_bt_synonym
					AND rad.control_bt_synonym = rad1.control_bt_synonym
					AND rad.button_code = rad1.button_code
					AND ctrl.customer_name = sec.customer_name
					AND ctrl.project_name = sec.project_name
					AND ctrl.req_no = sec.req_no
					AND ctrl.process_name = sec.process_name
					AND ctrl.component_name = sec.component_name
					AND ctrl.activity_name = sec.activity_name
					AND ctrl.ui_name = sec.ui_name
					AND ctrl.page_bt_synonym = sec.page_bt_synonym
					AND ctrl.section_bt_synonym = sec.section_bt_synonym
					AND ctrl.customer_name = ctype.customer_name
					AND ctrl.project_name = ctype.project_name
					AND ctrl.process_name = ctype.process_name
					AND ctrl.component_name = ctype.component_name
					AND ctrl.control_type = ctype.ctrl_type_name
					AND rad.customer_name = @engg_customer_name
					AND rad.project_name = @engg_project_name
					AND rad.req_no = @engg_req_no
					AND rad.process_name = @process_name
					AND rad.component_name = @engg_component
					AND rad.activity_name = @activity_name
					AND rad.ui_name = @ui_name_tmp
					/* code modified for BugId : PNR2.0_8351 */
					AND rad.languageid = @language_code
					--code modified for bugid:PNR2.0_8637
					AND rad1.languageid = 1
				ORDER BY rad.page_bt_synonym,
					rad.section_bt_synonym,
					rad.control_bt_synonym,
					rad.seq_no,
					rad.horder,
					rad.vorder
			END
			ELSE
			BEGIN
				DECLARE radiocurs INSENSITIVE CURSOR
				FOR
				SELECT upper(rad.button_code),
					rad.seq_no,
					rad.button_caption,
					upper(rad.default_flag),
					upper(rad.page_bt_synonym),
					upper(rad.section_bt_synonym),
					upper(rad.control_bt_synonym),
					upper(control_id),
					upper(isnull(caption_wrap, 'Y')),
					upper(isnull(caption_alignment, 'LEFT')),
					upper(isnull(caption_position, 'LEFT')),
					upper(isnull(mandatory_flag, 'N')),
					upper(isnull(ctrl_position, 'LEFT')),
					upper(isnull(LabelClass, '')),
					upper(isnull(controlclass, '')),
					isnull(rad.horder, 0),
					isnull(rad.vorder, 0),
					rad1.button_caption
				FROM ep_radio_button_dtl_lng_extn rad(NOLOCK),
					ep_radio_button_dtl_lng_extn rad1(NOLOCK),
					ep_ui_control_dtl ctrl(NOLOCK),
					ep_ui_section_dtl sec(NOLOCK),
					es_comp_ctrl_type_mst_vw ctype(NOLOCK)
				WHERE ctrl.customer_name = ctype.customer_name
					AND ctrl.project_name = ctype.project_name
					AND ctrl.req_no = ctype.req_no
					AND ctrl.process_name = ctype.process_name
					AND ctrl.component_name = ctype.component_name
					AND ctrl.control_type = ctype.ctrl_type_name
					AND rad.customer_name = @engg_customer_name
					AND rad.project_name = @engg_project_name
					AND rad.req_no = 'Base'
					AND rad.process_name = @process_name
					AND rad.component_name = @engg_component
					AND rad.activity_name = @activity_name
					AND rad.ui_name = @ui_name_tmp
					--code modified for bugid:PNR2.0_8637
					AND rad.customer_name = rad1.customer_name
					AND rad.project_name = rad1.project_name
					AND rad.req_no = rad1.req_no
					AND rad.process_name = rad1.process_name
					AND rad.component_name = rad1.component_name
					AND rad.activity_name = rad1.activity_name
					AND rad.ui_name = rad1.ui_name
					AND rad.page_bt_synonym = rad1.page_bt_synonym
					AND rad.section_bt_synonym = rad1.section_bt_synonym
					AND rad.control_bt_synonym = rad1.control_bt_synonym
					AND rad.button_code = rad1.button_code
					--     and  rad.ui_control_sysid = ctrl.ui_control_sysid
					AND rad.customer_name = ctrl.customer_name
					AND rad.project_name = ctrl.project_name
					AND rad.req_no = ctrl.req_no
					AND rad.process_name = ctrl.process_name
					AND rad.component_name = ctrl.component_name
					AND rad.activity_name = ctrl.activity_name
					AND rad.ui_name = ctrl.ui_name
					AND rad.page_bt_synonym = ctrl.page_bt_synonym
					AND rad.section_bt_synonym = ctrl.section_bt_synonym
					AND rad.control_bt_synonym = ctrl.control_bt_synonym
					--     and  ctrl.ui_section_sysid = sec.ui_section_sysid
					AND ctrl.customer_name = sec.customer_name
					AND ctrl.project_name = sec.project_name
					AND ctrl.req_no = sec.req_no
					AND ctrl.process_name = sec.process_name
					AND ctrl.component_name = sec.component_name
					AND ctrl.activity_name = sec.activity_name
					AND ctrl.ui_name = sec.ui_name
					AND ctrl.page_bt_synonym = sec.page_bt_synonym
					AND ctrl.section_bt_synonym = sec.section_bt_synonym
					/* code modified for BugId : PNR2.0_8351 */
					AND rad.languageid = @language_code
					--code modified for bugid:PNR2.0_8637
					AND rad1.languageid = 1
				ORDER BY rad.page_bt_synonym,
					rad.section_bt_synonym,
					rad.control_bt_synonym,
					rad1.seq_no,
					rad.horder,
					rad.vorder
			END

			-- For each Radio Button generate entries
			OPEN radiocurs

			WHILE (1 = 1)
			BEGIN
				FETCH NEXT
				FROM radiocurs
				INTO @button_code_tmp,
					@seq_no_tmp,
					@button_caption_tmp,
					@default_flag_tmp,
					@page_bt_synonym_tmp,
					@section_bt_synonym_tmp,
					@control_bt_synonym_tmp,
					@controlid_tmp,
					@caption_wrap_tmp,
					@caption_alignment_tmp,
					@caption_position_tmp,
					@mandatory_flag_tmp,
					@ctrl_position_tmp,
					@label_class_tmp,
					@ctrl_class_tmp,
					@radhorder_tmp,
					@radvorder_tmp,
					@value_tmp

				IF @@fetch_status <> 0
					BREAK

				/*PNR2.0_14287*/
				SELECT @button_caption_tmp = replace(@button_caption_tmp, '&', '&amp;')

				SELECT @button_caption_tmp = replace(@button_caption_tmp, '<', '&lt;')

				SELECT @button_caption_tmp = replace(@button_caption_tmp, '>', '&gt;')

				SELECT @button_caption_tmp = replace(@button_caption_tmp, '"', '&quot;')

				SELECT @value_tmp = replace(@value_tmp, '&', '&amp;')

				SELECT @value_tmp = replace(@value_tmp, '<', '&lt;')

				SELECT @value_tmp = replace(@value_tmp, '>', '&gt;')

				SELECT @value_tmp = replace(@value_tmp, '"', '&quot;')

				-- Insert Column  Entry
				SELECT @xml_seq_tmp = @xml_seq_tmp + 1

				INSERT INTO ep_genxml_tmp (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					activity_name,
					guid,
					gen_xml,
					seq_no
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@process_name,
					@engg_component,
					@activity_name,
					@guid,
					'<Button Name="' + ltrim(rtrim(@button_code_tmp)) + '" ' + 'ButtonCaption="' + ltrim(rtrim(@button_caption_tmp)) + '" ' + 'ControlName="' + ltrim(rtrim(@controlid_tmp)) + '" ' + 'SectionName="' + ltrim(rtrim(@section_bt_synonym_tmp)) + '" ' + 'PageName="' + ltrim(rtrim(@page_bt_synonym_tmp)) + '" ' + 'ILBOName="' + ltrim(rtrim(@ui_name_tmp)) + '" ' + 'ActivityName="' + ltrim(rtrim(@activity_name)) + '" ' + 'ComponentName="' + ltrim(rtrim(@engg_component)) + '" ' + 'SequenceNo="' + ltrim(rtrim(CONVERT(VARCHAR, @seq_no_tmp))) + '" ' + 'CaptionWrap="' + ltrim(rtrim(isnull(@caption_wrap_tmp, 'Y'))) + '" ' + 'CaptionAlignment="' + ltrim(rtrim(isnull(@caption_alignment_tmp, 'LEFT'))) + '" ' + 'CaptionPosition="' + ltrim(rtrim(isnull(@caption_position_tmp, 'LEFT'))) + '" ' + 'ControlPosition="' + ltrim(rtrim(isnull(@ctrl_position_tmp, 'LEFT'))) + '" ' + 'LabelClass="' + ltrim(rtrim(isnull(@label_class_tmp, ''))) + '" ' + 'ControlClass="' + ltrim(rtrim(isnull(@ctrl_class_tmp, ''))) + '" ' + 'Mandatory="' + ltrim(rtrim(isnull(@mandatory_flag_tmp, 'N'))) + '" ' + 'HOrder="' + 
					ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, @radhorder_tmp), 3))) + '" ' + 'VOrder="' + ltrim(rtrim(dbo.ep_padzero(CONVERT(VARCHAR, @radvorder_tmp), 3))) + '" ' + 'Default="' + ltrim(rtrim(@default_flag_tmp)) + '" ' +
					--code modified for bugid:PNR2.0_8637
					'Value="' + ltrim(rtrim(@value_tmp)) + '"/>',
					@xml_seq_tmp
					)
			END

			CLOSE radiocurs

			DEALLOCATE radiocurs

			-- Insert Closing entry for Radio Buttons
			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'</RadioButtons>',
				@xml_seq_tmp
				)

			-- Insert Base Entry for Enumerated Values
			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'<EnumValues>',
				@xml_seq_tmp
				)

			--Code Modified for BugId : PNR2.0_14936
			-- Fetch Enum Button Control Details
			DECLARE enumcurs INSENSITIVE CURSOR
			FOR
			SELECT upper(enum.enum_code),
				enum.seq_no,
				enum.enum_caption,
				upper(enum.default_flag),
				upper(enum.page_bt_synonym),
				upper(enum.section_bt_synonym),
				upper(enum.control_bt_synonym),
				upper(control_id),
				upper(isnull(caption_wrap, 'Y')),
				upper(isnull(caption_alignment, 'LEFT')),
				upper(isnull(caption_position, 'LEFT')),
				upper(isnull(mandatory_flag, 'N')),
				upper(isnull(ctrl_position, 'LEFT')),
				upper(isnull(LabelClass, '')),
				upper(isnull(ControlClass, ''))
			FROM ep_enum_value_dtl_lng_extn enum(NOLOCK),
				ep_ui_control_dtl ctrl(NOLOCK),
				ep_ui_section_dtl sec(NOLOCK),
				es_comp_ctrl_type_mst_vw ctype(NOLOCK)
			WHERE enum.customer_name = ctrl.customer_name
				AND enum.project_name = ctrl.project_name
				AND enum.process_name = ctrl.process_name
				AND enum.component_name = ctrl.component_name
				AND enum.activity_name = ctrl.activity_name
				AND enum.ui_name = ctrl.ui_name
				AND enum.page_bt_synonym = ctrl.page_bt_synonym
				AND enum.section_bt_synonym = ctrl.section_bt_synonym
				AND enum.control_bt_synonym = ctrl.control_bt_synonym
				AND ctrl.customer_name = sec.customer_name
				AND ctrl.project_name = sec.project_name
				AND ctrl.process_name = sec.process_name
				AND ctrl.component_name = sec.component_name
				AND ctrl.activity_name = sec.activity_name
				AND ctrl.ui_name = sec.ui_name
				AND ctrl.page_bt_synonym = sec.page_bt_synonym
				AND ctrl.section_bt_synonym = sec.section_bt_synonym
				AND ctrl.customer_name = ctype.customer_name
				AND ctrl.project_name = ctype.project_name
				AND ctrl.process_name = ctype.process_name
				AND ctrl.component_name = ctype.component_name
				AND ctrl.control_type = ctype.ctrl_type_name
				AND enum.customer_name = @engg_customer_name
				AND enum.project_name = @engg_project_name
				AND enum.process_name = @process_name
				AND enum.component_name = @engg_component
				AND enum.activity_name = @activity_name
				AND enum.ui_name = @ui_name_tmp
				AND enum.languageid = @language_code
			
			UNION
			
			SELECT upper(enum.enum_code),
				enum.seq_no,
				enum.enum_caption,
				upper(enum.default_flag),
				upper(enum.page_bt_synonym),
				upper(enum.section_bt_synonym),
				upper(enum.control_bt_synonym),
				upper(control_id),
				upper(isnull(caption_wrap, 'Y')),
				upper(isnull(caption_alignment, 'LEFT')),
				upper(isnull(caption_position, 'LEFT')),
				upper(isnull(mandatory_flag, 'N')),
				upper(isnull(ctrl_position, 'LEFT')),
				'',
				''
			FROM ep_enum_value_dtl_lng_extn enum(NOLOCK),
				ep_ui_grid_dtl ctrl(NOLOCK),
				ep_ui_section_dtl sec(NOLOCK),
				es_comp_ctrl_type_mst_vw ctype(NOLOCK)
			WHERE enum.customer_name = ctrl.customer_name
				AND enum.project_name = ctrl.project_name
				AND enum.process_name = ctrl.process_name
				AND enum.component_name = ctrl.component_name
				AND enum.activity_name = ctrl.activity_name
				AND enum.ui_name = ctrl.ui_name
				AND enum.page_bt_synonym = ctrl.page_bt_synonym
				AND enum.section_bt_synonym = ctrl.section_bt_synonym
				AND enum.control_bt_synonym = ctrl.column_bt_synonym
				AND ctrl.customer_name = sec.customer_name
				AND ctrl.project_name = sec.project_name
				AND ctrl.process_name = sec.process_name
				AND ctrl.component_name = sec.component_name
				AND ctrl.activity_name = sec.activity_name
				AND ctrl.ui_name = sec.ui_name
				AND ctrl.page_bt_synonym = sec.page_bt_synonym
				AND ctrl.section_bt_synonym = sec.section_bt_synonym
				AND ctrl.customer_name = ctype.customer_name
				AND ctrl.project_name = ctype.project_name
				AND ctrl.process_name = ctype.process_name
				AND ctrl.component_name = ctype.component_name
				AND ctrl.column_type = ctype.ctrl_type_name
				AND enum.customer_name = @engg_customer_name
				AND enum.project_name = @engg_project_name
				AND enum.process_name = @process_name
				AND enum.component_name = @engg_component
				AND enum.activity_name = @activity_name
				AND enum.ui_name = @ui_name_tmp
				AND enum.languageid = @language_code

			--   order by enum.page_bt_synonym, enum.section_bt_synonym, enum.control_bt_synonym, enum.seq_no
			-- For each Radio Button generate entries
			OPEN enumcurs

			WHILE (1 = 1)
			BEGIN
				FETCH NEXT
				FROM enumcurs
				INTO @enum_code_tmp,
					@seq_no_tmp,
					@enum_caption_tmp,
					@default_flag_tmp,
					@page_bt_synonym_tmp,
					@section_bt_synonym_tmp,
					@control_bt_synonym_tmp,
					@controlid_tmp,
					@caption_wrap_tmp,
					@caption_alignment_tmp,
					@caption_position_tmp,
					@mandatory_flag_tmp,
					@ctrl_position_tmp,
					@label_class_tmp,
					@ctrl_class_tmp

				IF @@fetch_status <> 0
					BREAK

				SELECT @enum_caption_tmp = replace(@enum_caption_tmp, '&', '&amp;')

				SELECT @enum_caption_tmp = replace(@enum_caption_tmp, '<', '&lt;')

				SELECT @enum_caption_tmp = replace(@enum_caption_tmp, '>', '&gt;')

				SELECT @enum_caption_tmp = replace(@enum_caption_tmp, '"', '&quot;')

				-- Insert Column  Entry
				SELECT @xml_seq_tmp = @xml_seq_tmp + 1

				INSERT INTO ep_genxml_tmp (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					activity_name,
					guid,
					gen_xml,
					seq_no
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@process_name,
					@engg_component,
					@activity_name,
					@guid,
					'<ENum ENumCode="' + ltrim(rtrim(@enum_code_tmp)) + '" ' + 'ENumCaption="' + ltrim(rtrim(@enum_caption_tmp)) + '" ' + 'ControlName="' + ltrim(rtrim(@controlid_tmp)) + '" ' + 'ControlBTSynonym="' + ltrim(rtrim(@control_bt_synonym_tmp)) + '" ' + 'SectionBTSynonym="' + ltrim(rtrim(@section_bt_synonym_tmp)) + '" ' + 'PageBTSynonym="' + ltrim(rtrim(@page_bt_synonym_tmp)) + '" ' + 'ILBOName="' + ltrim(rtrim(@ui_name_tmp)) + '" ' + 'ActivityName="' + ltrim(rtrim(@activity_name)) + '" ' + 'ComponentName="' +
 ltrim(rtrim(@engg_component)) + '" ' + 'ENumSeqNo="' + ltrim(rtrim(CONVERT(VARCHAR, @seq_no_tmp))) + '" ' + 'CaptionWrap="' + ltrim(rtrim(isnull(@caption_wrap_tmp, 'Y'))) + '" ' + 'CaptionAlignment="' + ltrim(rtrim(isnull(@caption_alignment_tmp, 'LEFT'))
) + '" ' + 'CaptionPosition="' + ltrim(rtrim(isnull(@caption_position_tmp, 'LEFT'))) + '" ' + 'ControlPosition="' + ltrim(rtrim(isnull(@ctrl_position_tmp, 'LEFT'))) + '" ' + 'LabelClass="' + ltrim(rtrim(isnull(@label_class_tmp, ''))) + '" ' + 'ControlClass="' + ltrim(rtrim(isnull(lower(@ctrl_class_tmp), ''))) + '" ' + 
					'Mandatory="' + ltrim(rtrim(isnull(@mandatory_flag_tmp, 'N'))) + '" ' + 'Default="' + ltrim(rtrim(@default_flag_tmp)) + '"/>',
					@xml_seq_tmp
					)
			END

			CLOSE enumcurs

			DEALLOCATE enumcurs

			-- Insert Closing entry for Enumerated Values
			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'</EnumValues>',
				@xml_seq_tmp
				)

			-- Insert Base Entry for Combolink Values
			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'<CombolinkValues>',
				@xml_seq_tmp
				)

			-- Fetch Combolink Button Control Details
			DECLARE combolinkcurs INSENSITIVE CURSOR
			FOR
			SELECT upper(comb.combo_control_bt_synonym),
				upper(comb.link_control_bt_synonym),
				upper(comb.link_control_caption),
				comb.display_seqno,
				comb.map,
				comb.separatelink_req,
				upper(act.task_name),
				upper(ctype.base_ctrl_type)
			FROM ep_published_ui_combolink_dtl comb(NOLOCK),
				ep_published_action_mst act(NOLOCK),
				ep_published_ui_control_dtl ctrl(NOLOCK),
				es_comp_ctrl_type_mst ctype(NOLOCK)
			WHERE comb.customer_name = act.customer_name
				AND comb.project_name = act.project_name
				AND comb.req_no = act.req_no
				AND comb.process_name = act.process_name
				AND comb.component_name = act.component_name
				AND comb.activity_name = act.activity_name
				AND comb.ui_name = act.ui_name
				AND comb.link_control_bt_synonym = act.primary_control_bts
				AND comb.customer_name = @engg_customer_name
				AND comb.project_name = @engg_project_name
				AND comb.req_no = @engg_req_no
				AND comb.process_name = @process_name
				AND comb.component_name = @engg_component
				AND comb.activity_name = @activity_name
				AND comb.ui_name = @ui_name_tmp
				AND ctrl.customer_name = comb.customer_name
				AND ctrl.project_name = comb.project_name
				AND ctrl.req_no = comb.req_no
				AND ctrl.process_name = comb.process_name
				AND ctrl.component_name = comb.component_name
				AND ctrl.activity_name = comb.activity_name
				AND ctrl.ui_name = comb.ui_name
				AND ctrl.control_bt_synonym = comb.combo_control_bt_synonym
				AND ctype.customer_name = ctrl.customer_name
				AND ctype.project_name = ctrl.project_name
				AND ctype.process_name = ctrl.process_name
				AND ctype.component_name = ctrl.component_name
				AND ctype.ctrl_type_name = ctrl.control_type

			-- For each Radio Button generate entries
			OPEN combolinkcurs

			WHILE (1 = 1)
			BEGIN
				FETCH NEXT
				FROM combolinkcurs
				INTO @Combo_control_bt_synonym_tmp,
					@link_control_bt_synonym_tmp,
					@link_control_caption_tmp,
					@display_seqno_tmp,
					@separatelink_req_tmp,
					@map_tmp,
					@associated_task_name_tmp,
					@control_task_type_tmp

				IF @display_seqno_tmp = 1
				BEGIN
					SET @combo_default = 'Y'
				END
				ELSE
				BEGIN
					SET @combo_default = 'N'
				END

				IF @@fetch_status <> 0
					BREAK

				SELECT @link_control_caption_tmp = replace(@link_control_caption_tmp, '&', '&amp;')

				SELECT @link_control_caption_tmp = replace(@link_control_caption_tmp, '<', '&lt;')

				SELECT @link_control_caption_tmp = replace(@link_control_caption_tmp, '>', '&gt;')

				SELECT @link_control_caption_tmp = replace(@link_control_caption_tmp, '"', '&quot;')

				-- Insert Column  Entry
				SELECT @xml_seq_tmp = @xml_seq_tmp + 1

				INSERT INTO ep_genxml_tmp (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					activity_name,
					guid,
					gen_xml,
					seq_no
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@process_name,
					@engg_component,
					@activity_name,
					@guid,
					'<Control Name="' + ltrim(rtrim(@combo_control_bt_synonym_tmp)) + '" ' + 'LinkControlName="' + ltrim(rtrim(@link_control_bt_synonym_tmp)) + '" ' + 'ControlCaption="' + ltrim(rtrim(@link_control_caption_tmp)) + '" ' + 'AssociatedTask="' + ltrim(rtrim(
@associated_task_name_tmp)) + '" ' + 'SequenceNo ="' + ltrim(rtrim(@display_seqno_tmp)) + '" ' + 'Default="' + ltrim(rtrim(@combo_default)) + '" ' + 'SeparateLinkReq="' + ltrim(rtrim(@separatelink_req_tmp)) + '" ' + 'BaseControlType="' + ltrim(rtrim(@control_task_type_tmp))
					-- + '" ' +'Map="' + ltrim(rtrim(@map_tmp))   
					+ '"/>',
					@xml_seq_tmp
					)
			END

			CLOSE combolinkcurs

			DEALLOCATE combolinkcurs

			-- Insert Closing entry for Combolink Values
			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'</CombolinkValues>',
				@xml_seq_tmp
				)

			---
			/*Platform_2.0.3.1_27 */
			-- Insert Base Entry for Links
			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'<Traversal>',
				@xml_seq_tmp
				)

			/*Platform_2.0.3.1_27 */
			-- For Traversal Details
			IF @ctxt_service_in IN ('BulkGenerate')
				AND @pubflag = 'P'
			BEGIN
				DECLARE linkcurs INSENSITIVE CURSOR
				FOR
				SELECT upper(control_bt_synonym),
					UPPER(trv.page_bt_synonym),
					UPPER(link_type),
					upper(isnull(trv.linked_component, '')),
					upper(isnull(trv.linked_activity, '')),
					upper(isnull(trv.linked_ui, '')),
					upper(trv.section_bt_synonym),
					upper(isnull(trv.LinkLaunchType, ''))
				FROM ep_published_ui_traversal_dtl trv(NOLOCK),
					ep_published_ui_page_dtl pg(NOLOCK) -- ,
					-- ep_published_ezeeview_sp ez (nolock)  -- code commented by Gopinath S for the Call ID PNR2.0_25510
				WHERE trv.customer_name = pg.customer_name
					AND trv.project_name = pg.project_name
					AND trv.req_no = pg.req_no
					AND trv.process_name = pg.process_name
					AND trv.component_name = pg.component_name
					AND trv.activity_name = pg.activity_name
					AND trv.ui_name = pg.ui_name
					AND trv.page_bt_synonym = pg.page_bt_synonym
					AND trv.customer_name = @engg_customer_name
					AND trv.project_name = @engg_project_name
					AND trv.req_no = @engg_req_no
					AND trv.process_name = @process_name
					AND trv.component_name = @engg_component
					AND trv.activity_name = @activity_name
					AND pg.customer_name = @engg_customer_name
					AND pg.project_name = @engg_project_name
					AND pg.req_no = @engg_req_no
					AND pg.process_name = @process_name
					AND pg.component_name = @engg_component
					AND pg.activity_name = @activity_name
					AND pg.ui_name = @ui_name_tmp
			END
			ELSE
			BEGIN
				DECLARE linkcurs INSENSITIVE CURSOR
				FOR
				SELECT upper(control_bt_synonym),
					UPPER(trv.page_bt_synonym),
					UPPER(link_type),
					upper(isnull(linked_component, '')),
					upper(isnull(linked_activity, '')),
					upper(isnull(linked_ui, '')),
					upper(trv.section_bt_synonym),
					upper(isnull(trv.LinkLaunchType, ''))
				FROM ep_ui_traversal_dtl trv(NOLOCK),
					ep_ui_page_dtl pg(NOLOCK)
				WHERE trv.customer_name = @engg_customer_name
					AND trv.project_name = @engg_project_name
					AND trv.req_no = 'Base'
					AND trv.process_name = @process_name
					AND trv.component_name = @engg_component
					AND trv.activity_name = @activity_name
					AND trv.ui_name = @ui_name_tmp
					AND trv.customer_name = pg.customer_name
					AND trv.project_name = pg.project_name
					AND trv.req_no = pg.req_no
					AND trv.process_name = pg.process_name
					AND trv.component_name = pg.component_name
					AND trv.activity_name = pg.activity_name
					AND trv.ui_name = pg.ui_name
					AND trv.page_bt_synonym = pg.page_bt_synonym
			END

			OPEN linkcurs

			WHILE (1 = 1)
			BEGIN
				FETCH NEXT
				FROM linkcurs
				INTO @link_name_tmp,
					@link_page_tmp,
					@link_type_tmp,
					@linked_component_tmp,
					@linked_activity_tmp,
					@linked_ui_tmp,
					@link_section_tmp,
					@LinkLaunchType

				IF @@fetch_status <> 0
					BREAK

				-- Part commented for Tuning 
				-- Added by Sangeetha L on 24/02/06 for Bug Id : PNR2.0_6595
				SELECT @associated_task = ''

				SELECT @task_descr_link_tmp = ''

				-- Added by Sangeetha L on 24/02/06 for Bug Id : PNR2.0_6595
				-- For Associated Task
				IF @ctxt_service_in IN ('BulkGenerate')
					AND @pubflag = 'P'
				BEGIN
					IF EXISTS (
							SELECT 'x'
							FROM ep_published_ui_control_dtl a(NOLOCK)
							WHERE a.customer_name = @engg_customer_name
								AND a.project_name = @engg_project_name
								AND a.req_no = @engg_req_no
								AND a.process_name = @process_name
								AND a.component_name = @engg_component
								AND a.activity_name = @activity_name
								AND a.ui_name = @ui_name_tmp
								AND a.page_bt_synonym = @link_page_tmp
								AND a.control_bt_synonym = @link_name_tmp
							)
					BEGIN
						-- code modified by shafina on 27-Oct-2004 for PREVIEWENG203SYS_000170(While generating Preveiw for the activity "MMS Report", all the link tasks available in that screen is pointed to a help task)
						SELECT @associated_task = upper(isnull(task_name, ''))
						FROM ep_published_action_mst a(NOLOCK),
							ep_published_ui_control_dtl b(NOLOCK),
							es_comp_task_type_mst c(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.req_no = @engg_req_no
							AND a.process_name = @process_name
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							AND a.page_bt_synonym = @link_page_tmp
							AND a.customer_name = b.customer_name
							AND a.project_name = b.project_name
							AND a.req_no = b.req_no
							AND a.process_name = b.process_name
							AND a.component_name = b.component_name
							AND a.activity_name = b.activity_name
							AND a.ui_name = b.ui_name
							AND a.page_bt_synonym = b.page_bt_synonym
							AND a.primary_control_bts = b.control_bt_synonym
							AND a.customer_name = c.customer_name
							AND a.project_name = c.project_name
							AND a.component_name = c.component_name
							AND a.task_pattern = c.task_type_name
							AND a.task_type IN (
								'Link',
								'Help'
								)
							AND b.control_bt_synonym = @link_name_tmp
					END
					ELSE
					BEGIN
						SELECT @associated_task = upper(isnull(task_name, ''))
						FROM ep_published_action_mst a(NOLOCK),
							ep_published_ui_grid_dtl b(NOLOCK),
							es_comp_task_type_mst c(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.req_no = @engg_req_no
							AND a.process_name = @process_name
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							AND a.page_bt_synonym = @link_page_tmp
							AND a.customer_name = b.customer_name
							AND a.project_name = b.project_name
							AND a.req_no = b.req_no
							AND a.process_name = b.process_name
							AND a.component_name = b.component_name
							AND a.activity_name = b.activity_name
							AND a.ui_name = b.ui_name
							AND a.page_bt_synonym = b.page_bt_synonym
							AND a.primary_control_bts = b.column_bt_synonym
							AND a.customer_name = c.customer_name
							AND a.project_name = c.project_name
							AND a.component_name = c.component_name
							AND a.task_pattern = c.task_type_name
							AND a.task_type IN (
								'Link',
								'Help'
								)
							--and b.section_bt_synonym= @link_section_tmp
							AND b.column_bt_synonym = @link_name_tmp
					END
				END
				ELSE
				BEGIN
					IF EXISTS (
							SELECT 'x'
							FROM ep_ui_control_dtl a(NOLOCK)
							WHERE a.customer_name = @engg_customer_name
								AND a.project_name = @engg_project_name
								AND a.process_name = @process_name
								AND a.component_name = @engg_component
								AND a.activity_name = @activity_name
								AND a.ui_name = @ui_name_tmp
								AND a.page_bt_synonym = @link_page_tmp
								AND a.control_bt_synonym = @link_name_tmp
							)
					BEGIN
						-- code modified by Ganesh on 2/12/04 to get the task descr
						SELECT @associated_task = upper(isnull(task_name, '')),
							@task_descr_link_tmp = upper(isnull(task_descr, ''))
						FROM ep_action_mst_lng_extn a(NOLOCK),
							ep_ui_control_dtl b(NOLOCK),
							es_comp_task_type_mst c(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.process_name = @process_name
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							AND a.page_bt_synonym = @link_page_tmp
							AND a.customer_name = b.customer_name
							AND a.project_name = b.project_name
							AND a.req_no = b.req_no
							AND a.process_name = b.process_name
							AND a.component_name = b.component_name
							AND a.activity_name = b.activity_name
							AND a.ui_name = b.ui_name
							AND a.page_bt_synonym = b.page_bt_synonym
							AND a.primary_control_bts = b.control_bt_synonym
							AND a.customer_name = c.customer_name
							AND a.project_name = c.project_name
							AND a.req_no = c.req_no
							AND a.component_name = c.component_name
							AND a.task_pattern = c.task_type_name
							AND a.task_type IN (
								'Link',
								'Help'
								)
							AND b.control_bt_synonym = @link_name_tmp
							AND languageid = @language_code
					END
					ELSE
					BEGIN
						SELECT @associated_task = upper(isnull(task_name, '')),
							@task_descr_link_tmp = upper(isnull(task_descr, ''))
						FROM ep_action_mst_lng_extn a(NOLOCK),
							ep_ui_grid_dtl b(NOLOCK),
							es_comp_task_type_mst c(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.process_name = @process_name
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							AND a.page_bt_synonym = @link_page_tmp
							AND a.customer_name = b.customer_name
							AND a.project_name = b.project_name
							AND a.req_no = b.req_no
							AND a.process_name = b.process_name
							AND a.component_name = b.component_name
							AND a.activity_name = b.activity_name
							AND a.ui_name = b.ui_name
							AND a.page_bt_synonym = b.page_bt_synonym
							AND a.primary_control_bts = b.column_bt_synonym
							AND a.customer_name = c.customer_name
							AND a.project_name = c.project_name
							AND a.req_no = c.req_no
							AND a.component_name = c.component_name
							AND a.task_pattern = c.task_type_name
							AND a.task_type IN (
								'Link',
								'Help'
								)
							AND b.column_bt_synonym = @link_name_tmp
							AND languageid = @language_code
					END
				END

				SELECT @task_descr_link_tmp = replace(@task_descr_link_tmp, '&', '&amp;')

				SELECT @task_descr_link_tmp = replace(@task_descr_link_tmp, '<', '&lt;')

				SELECT @task_descr_link_tmp = replace(@task_descr_link_tmp, '>', '&gt;')

				SELECT @task_descr_link_tmp = replace(@task_descr_link_tmp, '"', '&quot;')

				DECLARE @ezlink engg_flag

				IF EXISTS (
						SELECT 'X'
						FROM ep_layout_ezeeview_sp(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @process_name
							AND component_name = @engg_component
							AND activity_name = @activity_name
							AND ui_name = @ui_name_tmp
							AND page_bt_synonym = @link_page_tmp
							AND Link_ControlName = @link_name_tmp
						)
				BEGIN
					SELECT @ezlink = 'Y'
				END
				ELSE
					SELECT @ezlink = 'N'

				DECLARE @postuitask engg_name

				SET @postuitask = ''

				SELECT @postuitask = sub.post_linktask
				FROM ep_ui_traversal_dtl trv(NOLOCK),
					de_subscription sub(NOLOCK)
				WHERE trv.customer_name = sub.customer_name
					AND trv.project_name = sub.project_name
					AND trv.process_name = sub.process_name
					AND trv.component_name = sub.component_name
					AND trv.activity_name = sub.activity_name
					AND trv.ui_name = sub.ui_name
					AND trv.page_bt_synonym = sub.page_bt_synonym
					AND trv.control_bt_synonym = sub.control_bt_synonym
					AND sub.customer_name = @engg_customer_name
					AND sub.project_name = @engg_project_name
					AND sub.process_name = @process_name
					AND sub.component_name = @engg_component
					AND sub.activity_name = @activity_name
					AND sub.ui_name = @ui_name_tmp
					AND sub.page_bt_synonym = @link_page_tmp
					AND sub.control_bt_synonym = @link_name_tmp

				IF isnull(@postuitask, '') <> ''
					SET @postuitask = 'Y'
				ELSE
					SET @postuitask = 'N'

				-- Insert Column Entry
				SELECT @xml_seq_tmp = @xml_seq_tmp + 1

				INSERT INTO ep_genxml_tmp (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					activity_name,
					guid,
					gen_xml,
					seq_no
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@process_name,
					@engg_component,
					@activity_name,
					@guid,
					'<Link Name="' + ltrim(rtrim(isnull(@link_name_tmp, ''))) + '" ' + 'LinkDescr="' + ltrim(rtrim(isnull(@task_descr_link_tmp, ''))) + '" ' + 'LinkComp="' + ltrim(rtrim(isnull(@linked_component_tmp, ''))) + '" ' + 'LinkAct="' + ltrim(rtrim(isnull(@linked_activity_tmp, ''))) + '" ' + 'LinkUI="' + ltrim(rtrim(isnull(@linked_ui_tmp, ''))) + '" ' + 'LinkPage="' + ltrim(rtrim(isnull(@link_page_tmp, ''))) + '" ' + 'AssociatedTask="' + ltrim(rtrim(isnull(@associated_task, ''))) + '" ' +
					'LinkLaunchType="'  + ltrim(rtrim(isnull(@LinkLaunchType,'')))     + '" ' +
					'EzLink="'   + ltrim(rtrim(isnull(@ezlink,'N')))    + '"/>',
					@xml_seq_tmp
					)
			END

			CLOSE linkcurs

			DEALLOCATE linkcurs

			-- Insert Closing entry for Links
			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'</Traversal>',
				@xml_seq_tmp
				)

			-- For Actions
			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'<Tasks>',
				@xml_seq_tmp
				)

			-- For List of Task
			IF @ctxt_service_in IN ('BulkGenerate')
				AND @pubflag = 'P'
			BEGIN
				DECLARE act_cursor CURSOR
				FOR
				SELECT act.task_type,
					upper(act.page_bt_synonym),
					upper(task_name),
					task_descr,
					task_seq,
					upper(task_pattern),
					upper(primary_control_bts),
					PopUp_page_bt_synonym,
					PopUp_section,
					CASE PopUp_close
						WHEN '1'
							THEN 'Y'
						ELSE 'N'
						END,
					upper(isnull(browse_control, '')),
					CASE 
						WHEN isnull(Popup_onclick_close, 0) = 1
							THEN 'Y'
						ELSE 'N'
						END
				FROM ep_published_action_mst_lng_extn act(NOLOCK),
					es_comp_task_type_mst mst(NOLOCK)
				WHERE act.customer_name = mst.customer_name
					AND act.project_name = mst.project_name
					AND act.process_name = mst.process_name
					AND act.component_name = mst.component_name
					AND act.task_pattern = mst.task_type_name
					AND act.customer_name = @engg_customer_name
					AND act.project_name = @engg_project_name
					AND act.req_no = @engg_req_no
					AND act.process_name = @process_name
					AND act.component_name = @engg_component
					AND act.activity_name = @activity_name
					AND act.ui_name = @ui_name_tmp
					AND languageid = @language_code
				ORDER BY task_seq
			END
			ELSE
			BEGIN
				DECLARE act_cursor CURSOR
				FOR
				SELECT act.task_type,
					upper(act.page_bt_synonym),
					upper(task_name),
					task_descr,
					task_seq,
					upper(task_pattern),
					upper(primary_control_bts),
					PopUp_page_bt_synonym,
					PopUp_section,
					CASE PopUp_close
						WHEN '1'
							THEN 'Y'
						ELSE 'N'
						END,
					upper(isnull(browse_control, '')),
					CASE 
						WHEN isnull(Popup_onclick_close, 0) = 1
							THEN 'Y'
						ELSE 'N'
						END
				FROM ep_action_mst_lng_extn act(NOLOCK),
					es_comp_task_type_mst mst(NOLOCK)
				WHERE act.customer_name = mst.customer_name
					AND act.project_name = mst.project_name
					AND act.process_name = mst.process_name
					AND act.component_name = mst.component_name
					AND act.task_pattern = mst.task_type_name
					AND act.customer_name = @engg_customer_name
					AND act.project_name = @engg_project_name
					AND act.req_no = 'Base'
					AND act.process_name = @process_name
					AND act.component_name = @engg_component
					AND act.activity_name = @activity_name
					AND act.ui_name = @ui_name_tmp
					AND languageid = @language_code
				ORDER BY task_seq
			END

			OPEN act_cursor

			WHILE (1 = 1)
			BEGIN
				FETCH NEXT
				FROM act_cursor
				INTO @task_type_tmp,
					@page_bt_synonym_tmp,
					@task_name_tmp,
					@task_descr_tmp,
					@task_seq_tmp,
					@task_pattern_tmp,
					@primary_control_bts_tmp,
					@popup_page,
					@popup_section,
					@popup_Close,
					@browse_control,
					@Popup_onclick_close

				IF @@fetch_status <> 0
					BREAK

				-- Code Added for Bug ID PNR2.0_19757 Starts
				SELECT @section_bt_synonym_tmp = '',
					@ManualReport = '',
					@StatusMessage = '',
					@FullTree = '',
					@ConfirmationMessage = '',
					@CVS = '',
					@ExcelReport = '',
					@Chart = '',
					@Tree = '',
					@SourceCtrl = '',
					@TargetCtrl = '',
					@controltype = '',
					@width = '',
					@height = '',
					@Toolbar_notreq = '',
					@btype = '',
					@path_control = '',
					@group_name = ''

				-- Code Added for Bug ID PNR2.0_19757 Ends
				SELECT @task_descr_tmp = replace(@task_descr_tmp, '&', '&amp;')

				SELECT @task_descr_tmp = replace(@task_descr_tmp, '<', '&lt;')

				SELECT @task_descr_tmp = replace(@task_descr_tmp, '>', '&gt;')

				SELECT @task_descr_tmp = replace(@task_descr_tmp, '"', '&quot;')

				IF @task_type_tmp IN (
						'Help',
						'Link'
						)
				BEGIN
					SELECT @width = isnull(tra.Width, ''),
						@height = isnull(tra.height, ''),
						@Toolbar_notreq = isnull(tra.Toolbar_notreq, '')
					FROM ep_action_mst_lng_extn act(NOLOCK),
						ep_ui_traversal_dtl tra(NOLOCK)
					WHERE act.customer_name = tra.customer_name
						AND act.project_name = tra.project_name
						AND act.req_no = tra.req_no
						AND act.process_name = tra.process_name
						AND act.component_name = tra.component_name
						AND act.activity_name = tra.activity_name
						AND act.ui_name = tra.ui_name
						AND act.page_bt_synonym = tra.page_bt_synonym
						AND act.primary_control_bts = tra.control_bt_synonym
						AND act.customer_name = @engg_customer_name
						AND act.project_name = @engg_project_name
						AND act.req_no = 'Base'
						AND act.process_name = @process_name
						AND act.component_name = @engg_component
						AND act.activity_name = @activity_name
						AND act.ui_name = @ui_name_tmp
						AND act.task_name = @task_name_tmp
						AND languageid = @language_code
				END

				--kanagavel
				IF @task_type_tmp IN ('Trans')
					AND isnull(@browse_control, '') <> ''
				BEGIN
					SELECT @path_control = @browse_control

					SELECT @btype = CASE 
							WHEN (
									Browse_Button_Enable = 'Y'
									AND upload = 'Y'
									)
								THEN 'filebrowseupload'
							WHEN Browse_Button_Enable = 'Y'
								THEN 'filebrowse'
							WHEN Delete_Button_Enable = 'Y'
								THEN 'filedelete'
							WHEN upload = 'Y'
								THEN 'fileupload'
							ELSE NULL
							END
					FROM ep_ui_control_dtl ctrl(NOLOCK),
						es_comp_ctrl_type_mst mst(NOLOCK)
					WHERE ctrl.customer_name = mst.customer_name
						AND ctrl.project_name = mst.project_name
						AND ctrl.process_name = mst.process_name
						AND ctrl.component_name = mst.component_name
						AND ctrl.control_type = mst.ctrl_type_name
						AND ctrl.customer_name = @engg_customer_name
						AND ctrl.project_name = @engg_project_name
						AND ctrl.req_no = 'Base'
						AND ctrl.process_name = @process_name
						AND ctrl.component_name = @engg_component
						AND ctrl.activity_name = @activity_name
						AND ctrl.ui_name = @ui_name_tmp
						AND ctrl.control_bt_synonym = @primary_control_bts_tmp
				END

--Added for the TECH-29822 Starts

select	@QuickTask		= QuickTask,
		@OfflineTask	= autoupload,
		@SystemTaskType	= SystemTaskType,
		@sectionlaunchtype = ISNULL(sectionlaunchtype, '')
from ep_action_mst (nolock)
where  customer_name  =   @engg_customer_name
and  project_name  = @engg_project_name
and  process_name  = @process_name
and  component_name  = @engg_component
and  activity_name  = @activity_name
and  ui_name    =  @ui_name_tmp
and  page_bt_synonym  = @page_bt_synonym_tmp
and	 task_name				=	  @task_name_tmp
and  primary_control_bts =  @primary_control_bts_tmp

	IF ISNULL(@task_descr_tmp, '') LIKE 'System Task%' --ISNULL(@SystemTaskType,'') <> ''
		SELECT @SystemTask = 'Y'
	ELSE
		SELECT @SystemTask = 'N'
 --Added for the TECH-29822 Ends


				-- For Getting Section BT Synonym
				IF @task_type_tmp = 'Fetch'
					SELECT @section_bt_synonym_tmp = '[mainsection]'
				ELSE IF @task_type_tmp = 'Init'
					SELECT @section_bt_synonym_tmp = '[mainsection]'
				ELSE
				BEGIN
					IF @ctxt_service_in IN ('BulkGenerate')
						AND @pubflag = 'P'
					BEGIN
						IF EXISTS (
								SELECT 'x'
								FROM ep_published_ui_control_dtl(NOLOCK)
								WHERE customer_name = @engg_customer_name
									AND project_name = @engg_project_name
									AND req_no = @engg_req_no
									AND process_name = @process_name
									AND component_name = @engg_component
									AND activity_name = @activity_name
									AND ui_name = @ui_name_tmp
									AND page_bt_synonym = @page_bt_synonym_tmp
									AND control_bt_synonym = @primary_control_bts_tmp
								)
						BEGIN
							SELECT @section_bt_synonym_tmp = upper(section_bt_synonym)
							FROM ep_published_ui_control_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND req_no = @engg_req_no
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND page_bt_synonym = @page_bt_synonym_tmp
								AND control_bt_synonym = @primary_control_bts_tmp
						END
						ELSE
						BEGIN
							IF EXISTS (
									SELECT 'x'
									FROM ep_published_ui_grid_dtl(NOLOCK)
									WHERE customer_name = @engg_customer_name
										AND project_name = @engg_project_name
										AND req_no = @engg_req_no
										AND process_name = @process_name
										AND component_name = @engg_component
										AND activity_name = @activity_name
										AND ui_name = @ui_name_tmp
										AND page_bt_synonym = @page_bt_synonym_tmp
										AND column_bt_synonym = @primary_control_bts_tmp
									)
							BEGIN
								SELECT @section_bt_synonym_tmp = upper(section_bt_synonym)
								FROM ep_published_ui_grid_dtl(NOLOCK)
								WHERE customer_name = @engg_customer_name
									AND project_name = @engg_project_name
									AND req_no = @engg_req_no
									AND process_name = @process_name
									AND component_name = @engg_component
									AND activity_name = @activity_name
									AND ui_name = @ui_name_tmp
									AND page_bt_synonym = @page_bt_synonym_tmp
									AND column_bt_synonym = @primary_control_bts_tmp
							END
						END

						SELECT @SourceCtrl = upper(isnull(QR_sourceCtrl, '')),
							@TargetCtrl = upper(isnull(QR_targetCtrl, '')),
							@controltype = 'QRImage'
						FROM ep_published_action_mst(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND req_no = @engg_req_no
							AND process_name = @process_name
							AND component_name = @engg_component
							AND activity_name = @activity_name
							AND ui_name = @ui_name_tmp
							AND page_bt_synonym = @page_bt_synonym_tmp
							AND primary_control_bts = @primary_control_bts_tmp
							AND (
								isnull(QR_sourceCtrl, '') <> ''
								AND isnull(QR_targetCtrl, '') <> ''
								)

						SELECT @SourceCtrl = upper(isnull(Barcode_sourceCtrl, '')),
							@TargetCtrl = upper(isnull(Barcode_targetCtrl, '')),
							@controltype = 'BarCode'
						FROM ep_published_action_mst(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND req_no = @engg_req_no
							AND process_name = @process_name
							AND component_name = @engg_component
							AND activity_name = @activity_name
							AND ui_name = @ui_name_tmp
							AND page_bt_synonym = @page_bt_synonym_tmp
							AND primary_control_bts = @primary_control_bts_tmp
							AND (
								isnull(Barcode_sourceCtrl, '') <> ''
								AND isnull(Barcode_targetCtrl, '') <> ''
								)
					END
					ELSE
					BEGIN
						IF EXISTS (
								SELECT 'x'
								FROM ep_ui_control_dtl(NOLOCK)
								WHERE customer_name = @engg_customer_name
									AND project_name = @engg_project_name
									AND req_no = 'Base'
									AND process_name = @process_name
									AND component_name = @engg_component
									AND activity_name = @activity_name
									AND ui_name = @ui_name_tmp
									AND page_bt_synonym = @page_bt_synonym_tmp
									AND control_bt_synonym = @primary_control_bts_tmp
								)
						BEGIN
							SELECT @section_bt_synonym_tmp = upper(section_bt_synonym)
							FROM ep_ui_control_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND req_no = 'Base'
								AND process_name = @process_name
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND page_bt_synonym = @page_bt_synonym_tmp
								AND control_bt_synonym = @primary_control_bts_tmp
						END
						ELSE
						BEGIN
							IF EXISTS (
									SELECT 'x'
									FROM ep_ui_grid_dtl(NOLOCK)
									WHERE customer_name = @engg_customer_name
										AND project_name = @engg_project_name
										AND req_no = 'Base'
										AND process_name = @process_name
										AND component_name = @engg_component
										AND activity_name = @activity_name
										AND ui_name = @ui_name_tmp
										AND page_bt_synonym = @page_bt_synonym_tmp
										AND column_bt_synonym = @primary_control_bts_tmp
									)
							BEGIN
								SELECT @section_bt_synonym_tmp = upper(section_bt_synonym)
								FROM ep_ui_grid_dtl(NOLOCK)
								WHERE customer_name = @engg_customer_name
									AND project_name = @engg_project_name
									AND req_no = 'Base'
									AND process_name = @process_name
									AND component_name = @engg_component
									AND activity_name = @activity_name
									AND ui_name = @ui_name_tmp
									AND page_bt_synonym = @page_bt_synonym_tmp
									AND column_bt_synonym = @primary_control_bts_tmp
							END
						END
					END

					SELECT @SourceCtrl = upper(isnull(QR_sourceCtrl, '')),
						@TargetCtrl = upper(isnull(QR_targetCtrl, '')),
						@controltype = 'QRImage'
					FROM ep_action_mst(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @process_name
						AND component_name = @engg_component
						AND activity_name = @activity_name
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = @page_bt_synonym_tmp
						AND primary_control_bts = @primary_control_bts_tmp
						AND (
							isnull(QR_sourceCtrl, '') <> ''
							AND isnull(QR_targetCtrl, '') <> ''
							)

					SELECT @SourceCtrl = upper(isnull(Barcode_sourceCtrl, '')),
						@TargetCtrl = upper(isnull(Barcode_targetCtrl, '')),
						@controltype = 'BarCode'
					FROM ep_action_mst(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @process_name
						AND component_name = @engg_component
						AND activity_name = @activity_name
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = @page_bt_synonym_tmp
						AND primary_control_bts = @primary_control_bts_tmp
						AND (
							isnull(Barcode_sourceCtrl, '') <> ''
							AND isnull(Barcode_targetCtrl, '') <> ''
							)
				END

				SELECT @xml_seq_tmp = @xml_seq_tmp + 1,
					@section_bt_synonym_tmp = upper(@section_bt_synonym_tmp)

				-- Code Added By Jeya for the Bug ID PNR2.0_19279 Starts
				SELECT @StatusMessage = taskstatusmsg
				FROM de_fw_req_base_task_status_msg_vw(NOLOCK)
				WHERE customername = @engg_customer_name
					AND projectname = @engg_project_name
					AND processname = @process_name
					AND componentname = @engg_component
					AND activityname = @activity_name
					AND ilbocode = @ui_name_tmp
					AND taskname = @task_name_tmp
					--AND languageid = @language_code

				--code added for bugid : PNR2.0_19525 starts
				SELECT @StatusMessage = replace(@StatusMessage, '&', '&amp;')

				SELECT @StatusMessage = replace(@StatusMessage, '<', '&lt;')

				SELECT @StatusMessage = replace(@StatusMessage, '>', '&gt;')

				SELECT @StatusMessage = replace(@StatusMessage, '"', '&quot;')

				--code added for bugid : PNR2.0_19525 ends
				SELECT @ConfirmationMessage = taskconfirmmsg
				FROM de_fw_req_base_tsk_confirm_msg_vw(NOLOCK)
				WHERE customername = @engg_customer_name
					AND projectname = @engg_project_name
					AND processname = @process_name
					AND componentname = @engg_component
					AND activityname = @activity_name
					AND ilbocode = @ui_name_tmp
					AND taskname = @task_name_tmp
					--AND languageid = @language_code

				--code added for bugid : PNR2.0_19525 starts
				SELECT @ConfirmationMessage = replace(@ConfirmationMessage, '&', '&amp;')

				SELECT @ConfirmationMessage = replace(@ConfirmationMessage, '<', '&lt;')

				SELECT @ConfirmationMessage = replace(@ConfirmationMessage, '>', '&gt;')

				SELECT @ConfirmationMessage = replace(@ConfirmationMessage, '"', '&quot;')

				--code added for bugid : PNR2.0_19525 ends
				--Code Modification for PNR2.0_30869 starts
				SELECT @ProcessingMessage = taskprocessmsg
				FROM de_fw_req_base_task_process_msg_vw(NOLOCK)
				WHERE customername = @engg_customer_name
					AND projectname = @engg_project_name
					AND processname = @process_name
					AND componentname = @engg_component
					AND activityname = @activity_name
					AND ilbocode = @ui_name_tmp
					AND taskname = @task_name_tmp
					--AND languageid = @language_code

				SELECT @ProcessingMessage = replace(@ProcessingMessage, '&', '&amp;')

				SELECT @ProcessingMessage = replace(@ProcessingMessage, '<', '&lt;')

				SELECT @ProcessingMessage = replace(@ProcessingMessage, '>', '&gt;')

				SELECT @ProcessingMessage = replace(@ProcessingMessage, '"', '&quot;')

				--Code Modification for PNR2.0_30869 ends
				IF EXISTS (
						SELECT 'x'
						FROM cvs_message(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @process_name
							AND component_name = @engg_component
							AND activity_name = @activity_name
							AND ui_name = @ui_name_tmp
							AND page_name = @page_bt_synonym_tmp
							AND task_name = @task_name_tmp
						)
				BEGIN
					SELECT @CVS = 'Y'
				END

				SELECT @associated_control = ''

				-- Code modified by Jeya on 25 sep 2008 Starts
				IF EXISTS (
						SELECT 'x'
						FROM de_exrep_task_template_map(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @process_name
							AND component_name = @engg_component
							AND activity_name = @activity_name
							AND ui_name = @ui_name_tmp
							AND page_name = @page_bt_synonym_tmp
							AND task_name = @task_name_tmp
						)
				BEGIN
					SELECT @ExcelReport = 'Y'

					-- Code modified by Jeya on 25 sep 2008 Ends
					SELECT @associated_control = b.control_id
					FROM de_exrep_task_template_map a(NOLOCK),
						ep_ui_control_dtl b(NOLOCK)
					WHERE a.customer_name = @engg_customer_name
						AND a.project_name = @engg_project_name
						AND a.process_name = @process_name
						AND a.component_name = @engg_component
						AND a.activity_name = @activity_name
						AND a.ui_name = @ui_name_tmp
						AND a.page_name = @page_bt_synonym_tmp
						AND a.task_name = @task_name_tmp
						AND a.customer_name = b.customer_name
						AND a.project_name = b.project_name
						AND a.process_name = b.process_name
						AND a.component_name = b.component_name
						AND a.activity_name = b.activity_name
						AND a.ui_name = b.ui_name
						AND a.page_name = b.page_bt_synonym
						AND a.associated_control = b.control_bt_synonym
						-- Code modification for PNR2.0_23208 ends
				END

				IF EXISTS (
						SELECT 'x'
						FROM ep_tree_dtl(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @process_name
							AND component_name = @engg_component
							AND activity_name = @activity_name
							AND ui_name = @ui_name_tmp
							AND page_bt_synonym = @page_bt_synonym_tmp
							AND mapped_task = @task_name_tmp
						)
				BEGIN
					SELECT @Tree = 'Y'
				END

				--if exists  (select 'x'
				--from de_published_chart_task_map_vw (nolock)
				--where customername  =   @engg_customer_name
				--and projectname  = @engg_project_name
				--and  processname  = @process_name
				--and  componentname  = @engg_component
				--and  activity_name  = @activity_name
				--and  ui_name    =  @ui_name_tmp
				--and  page_name  = @page_bt_synonym_tmp
				--and  taskname =  @task_name_tmp)
				--begin
				--select @Chart = 'Y'
				--End
				SELECT @FullTree = clear_tree_before_population
				FROM re_published_flowbr_combo(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @process_name
					AND component_name = @engg_component
					AND activity_name = @activity_name
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = @page_bt_synonym_tmp
					AND task_name = @task_name_tmp

				IF isnull(@FullTree, '') = ''
					OR @FullTree = '0'
					SELECT @FullTree = 'N'
				ELSE
					SELECT @FullTree = 'Y'

				SELECT @ManualReport = isnull(ReportName, '')
				FROM engg_devcon_handcoded_reports_vw(NOLOCK)
				WHERE customername = @engg_customer_name
					AND projectname = @engg_project_name
					AND processname = @process_name
					AND componentname = @engg_component
					AND ActivityName = @activity_name
					AND uiname = @ui_name_tmp
					AND taskname = @task_name_tmp

				-- Code Added By Jeya for the Bug ID PNR2.0_19279 Ends
				-- Code modification for  PNR2.0_30127 starts
				IF EXISTS (
						SELECT 'x'
						FROM de_fw_des_publish_error_lookup(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @process_name
							AND component_name = @engg_component
							AND Activity_Name = @activity_name
							AND ui_name = @ui_name_tmp
							AND taskname = @task_name_tmp
						)
				BEGIN
					SELECT @ErrorLookup = 'Y'
				END
				ELSE
					SELECT @ErrorLookup = 'N'

				IF EXISTS (
						SELECT 'x'
						FROM de_fw_des_publish_followup_tasks(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @process_name
							AND component_name = @engg_component
							AND Activity_Name = @activity_name
							AND ui_name = @ui_name_tmp
							AND task_name = @task_name_tmp
						)
				BEGIN
					SELECT @FollowupTask = 'Y'
				END
				ELSE
					SELECT @FollowupTask = 'N'

				-- Code modification for  PNR2.0_30127 ends	
				-- Code Added for PNR2.0_31051 Starts
				DECLARE @mlcontrol engg_name

				SELECT @mlcontrol = ''

				SELECT @AssociatedML = ''

				DECLARE task_ml_fet CURSOR
				FOR
				SELECT DISTINCT a.controlid
				FROM de_fw_des_ilbo_service_view_datamap a(NOLOCK),
					de_ui_grid b(NOLOCK),
					de_fw_des_service_dataitem c(NOLOCK)
				WHERE a.customer_name = b.customer_name
					AND a.project_name = b.project_name
					AND a.process_name = b.process_name
					AND a.component_name = b.component_name
					AND a.activity_name = b.Activity_Name
					AND a.ilbocode = b.UI_Name
					AND a.page_bt_synonym = b.page_bt_synonym
					AND a.controlid = b.control_id
					AND a.viewname = b.view_name
					AND a.customer_name = c.customer_name
					AND a.project_name = c.project_name
					AND a.process_name = c.process_name
					AND a.component_name = c.component_name
					AND a.servicename = c.servicename
					AND a.segmentname = c.segmentname
					AND a.dataitemname = c.dataitemname
					AND c.flowattribute = 0
					AND a.customer_name = @engg_customer_name
					AND a.project_name = @engg_project_name
					AND a.process_name = @process_name
					AND a.component_name = @engg_component
					AND a.Activity_Name = @activity_name
					AND a.ilbocode = @ui_name_tmp
					AND a.taskname = @task_name_tmp
				ORDER BY 1

				OPEN task_ml_fet

				WHILE (1 = 1)
				BEGIN
					FETCH NEXT
					FROM task_ml_fet
					INTO @mlcontrol

					IF @@fetch_status <> 0
						BREAK

					IF isnull(@mlcontrol, '') <> ''
						AND isnull(@AssociatedML, '') = ''
						SELECT @AssociatedML = isnull(@AssociatedML, '') + isnull(@mlcontrol, '')
					ELSE IF isnull(@mlcontrol, '') <> ''
						AND isnull(@AssociatedML, '') <> ''
						SELECT @AssociatedML = isnull(@AssociatedML, '') + ', ' + isnull(@mlcontrol, '')
				END

				CLOSE task_ml_fet

				DEALLOCATE task_ml_fet

				-- Code Added for PNR2.0_31051 End
				INSERT INTO ep_genxml_tmp (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					activity_name,
					guid,
					gen_xml,
					seq_no
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@process_name,
					@engg_component,
					@activity_name,
					@guid,
					'<Task Name="' + ltrim(rtrim(isnull(@task_name_tmp, ''))) + '" ' + 'TaskDescr="' + ltrim(rtrim(isnull(@task_descr_tmp, ''))) + '" ' + 'TaskSeq="' + ltrim(rtrim(isnull(str(@task_seq_tmp), ''))) + '" ' + 'TaskType="' + ltrim(rtrim(isnull(@task_type_tmp, ''))) + '" ' + 'TaskPattern="' + ltrim(rtrim(isnull(@task_pattern_tmp, ''))) + '" ' + 'PageName="' + ltrim(rtrim(isnull(@page_bt_synonym_tmp, ''))) + '" ' + 'SectionName="' + ltrim(rtrim(isnull(@section_bt_synonym_tmp, ''))) + '" ' + 'PrimaryControlBT=
"' + ltrim(rtrim(isnull(@primary_control_bts_tmp, ''))) + '" ' +
					-- Code Added By Jeya for the Bug ID PNR2.0_19279 Starts
					'StatusMessage="' + ltrim(rtrim(isnull(@StatusMessage, ''))) + '" ' + 'ConfirmationMessage="' + ltrim(rtrim(isnull(@ConfirmationMessage, ''))) + '" ' + 'CVS="' + ltrim(rtrim(isnull(@CVS, ''))) + '" ' + 'ExcelReport="' + ltrim(rtrim(isnull(@ExcelReport, ''))) + '" ' + 'Tree="' + ltrim(rtrim(isnull(@Tree, 'N'))) + '" ' + 'Chart="' + ltrim(rtrim(isnull(@Chart, 'N'))) + '" ' + 'FullTree="' + ltrim(rtrim(isnull(@FullTree, 'N'))) + '" ' +
					-- Code modification for PNR2.0_23175 starts
					'ManualReport="' + ltrim(rtrim(isnull(@ManualReport, ''))) + '" ' + 'ExcelRepAsscCtrl="' + '' + '" ' +
					-- Code modification for PNR2.0_23175 ends
					-- Code Added By Jeya for the Bug ID PNR2.0_19279 Ends
					'ErrorLookup="' + ltrim(rtrim(isnull(@ErrorLookup, ''))) + '" ' + 'FollowupTask="' + ltrim(rtrim(isnull(@FollowupTask, ''))) + '" ' + 'ProcessingMessage="' + ltrim(rtrim(isnull(@ProcessingMessage, ''))) + '" ' + --Code Modified for PNR2.0_30869
					'PopUpPage="' + isnull(@popup_page, '') + '" ' + 'PopUpSection="' + isnull(@popup_section, '') + '" ' + 
					'PopUpClose="' + isnull(@popup_Close, 'N') + '" ' + 'SourceCtrl="' + ltrim(rtrim(isnull(@SourceCtrl, ''))) + '" ' + 
					'TargetCtrl="' + ltrim(rtrim(isnull(@TargetCtrl, ''))) + '" ' + 'QRType="' + ltrim(rtrim(isnull(@controltype, ''))) + '" ' + 
					'ChildWidth="' + ltrim(rtrim(isnull(@Width, ''))) + '" ' + 'ChildHeight="' + ltrim(rtrim(isnull(@Height, ''))) + '" ' + 
					'Toolbarnotreq="' + ltrim(rtrim(isnull(@Toolbar_notreq, ''))) + '" ' + 'btype="' + ltrim(rtrim(isnull(@btype, ''))) + '" ' + 
					'AssociatedPathCtrl="' + ltrim(rtrim(isnull(@path_control, ''))) + '" ' + 
					'PopupOnClickClose="' + ltrim(rtrim(@Popup_onclick_close)) + '" ' + 
					-- Added for the TECH-29822 Starts
					'QuickAction="'+ ltrim(rtrim(isnull(@QuickTask,'N')))               +'" ' +
					'IsOffline="'+ ltrim(rtrim(isnull(@OfflineTask,'N')))               +'" ' +
					'IsSystemTask="'+ ltrim(rtrim(isnull(@SystemTask,'N')))               +'" ' +
					'SysTaskType="'+ ltrim(rtrim(isnull(@SystemTaskType,'')))               +'" ' +
					-- Added for the TECH-29822 Ends
					'DefaultGroup="' + ltrim(rtrim(isnull(@group_name, ''))) + '"/>',
					@xml_seq_tmp
					)
			END

			CLOSE act_cursor

			DEALLOCATE act_cursor

			-- Insert Closing entry for ILBO
			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'</Tasks>',
				@xml_seq_tmp
				)

			-- Added by Feroz For UI Toolbar start
			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'<ToolBar>',
				@xml_seq_tmp
				)

			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'<ToolBarItems>',
				@xml_seq_tmp
				)

			IF @pubflag = 'C'
			BEGIN
				DECLARE uitoolbar_cur INSENSITIVE CURSOR
				FOR
				SELECT DISTINCT toolbar_id,
					group_task_name,
					display_seqno,
					class_name,
					display_text,
					caption_req,
					control_req
				FROM ep_ui_toolbar_mapping_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = 'Base'
					AND component_name = @engg_component
					AND activity_name = @activity_name
					AND ui_name = @ui_name_tmp
				ORDER BY display_seqno
			END
			ELSE
			BEGIN
				DECLARE uitoolbar_cur INSENSITIVE CURSOR
				FOR
				SELECT DISTINCT toolbar_id,
					group_task_name,
					display_seqno,
					class_name,
					display_text,
					caption_req,
					control_req
				FROM ep_published_ui_toolbar_mapping_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_req_no
					AND component_name = @engg_component
					AND activity_name = @activity_name
					AND ui_name = @ui_name_tmp
				ORDER BY display_seqno
			END

			OPEN uitoolbar_cur

			WHILE (1 = 1)
			BEGIN
				FETCH NEXT
				FROM uitoolbar_cur
				INTO @toolbar_id,
					@group_task_name,
					@tb_display_seqno,
					@tb_class_name,
					@tb_display_text,
					@tb_caption_req,
					@tb_control_req

				IF @@fetch_status <> 0
					BREAK

				IF @tb_caption_req = '1'
					SELECT @tb_caption_req = 'Y'
				ELSE
					SELECT @tb_caption_req = 'N'

				IF @tb_control_req = '1'
					SELECT @tb_control_req = 'Y'
				ELSE
					SELECT @tb_control_req = 'N'

				SELECT @tb_controlid = '',
					@tb_viewname = ''

				IF @pubflag = 'C'
				BEGIN
					IF EXISTS (
							SELECT 'x'
							FROM ep_ui_toolbar_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND req_no = 'Base'
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND group_name = @group_task_name
							)
						SELECT @tb_type = 'Group'
					ELSE
					BEGIN
						SELECT @tb_type = 'Task'

						SELECT @tb_controlid = isnull(b.control_id, ''),
							@tb_viewname = isnull(b.view_name, '')
						FROM ep_action_mst a(NOLOCK),
							ep_ui_control_dtl b(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.req_no = 'Base'
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							AND a.task_name = @group_task_name
							AND a.customer_name = b.customer_name
							AND a.project_name = b.project_name
							AND a.req_no = b.req_no
							AND a.process_name = b.process_name
							AND a.component_name = b.component_name
							AND a.activity_name = b.activity_name
							AND a.ui_name = b.ui_name
							AND a.page_bt_synonym = b.page_bt_synonym
							AND a.primary_control_bts = b.control_bt_synonym

						IF isnull(@tb_controlid, '') = ''
							SELECT @tb_controlid = isnull(b.control_id, ''),
								@tb_viewname = isnull(b.view_name, '')
							FROM ep_action_mst a(NOLOCK),
								ep_ui_grid_dtl b(NOLOCK)
							WHERE a.customer_name = @engg_customer_name
								AND a.project_name = @engg_project_name
								AND a.req_no = 'Base'
								AND a.component_name = @engg_component
								AND a.activity_name = @activity_name
								AND a.ui_name = @ui_name_tmp
								AND a.task_name = @group_task_name
								AND a.customer_name = b.customer_name
								AND a.project_name = b.project_name
								AND a.req_no = b.req_no
								AND a.process_name = b.process_name
								AND a.component_name = b.component_name
								AND a.activity_name = b.activity_name
								AND a.ui_name = b.ui_name
								AND a.page_bt_synonym = b.page_bt_synonym
								AND a.primary_control_bts = b.column_bt_synonym
					END

					SELECT @tb_display_text = display_text
					FROM ep_ui_displaytext_lang_extn(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = 'Base'
						AND component_name = @engg_component
						AND activity_name = @activity_name
						AND ui_name = @ui_name_tmp
						AND group_task_name = @group_task_name
						AND lang_id = @language_code
				END
				ELSE
				BEGIN
					IF EXISTS (
							SELECT 'x'
							FROM ep_published_ui_toolbar_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND req_no = @engg_req_no
								AND component_name = @engg_component
								AND activity_name = @activity_name
								AND ui_name = @ui_name_tmp
								AND group_name = @group_task_name
							)
						SELECT @tb_type = 'Group'
					ELSE
					BEGIN
						SELECT @tb_type = 'Task'

						SELECT @tb_controlid = isnull(b.control_id, ''),
							@tb_viewname = isnull(b.view_name, '')
						FROM ep_published_action_mst a(NOLOCK),
							ep_published_ui_control_dtl b(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.req_no = @engg_req_no
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							AND a.task_name = @group_task_name
							AND a.customer_name = b.customer_name
							AND a.project_name = b.project_name
							AND a.req_no = b.req_no
							AND a.process_name = b.process_name
							AND a.component_name = b.component_name
							AND a.activity_name = b.activity_name
							AND a.ui_name = b.ui_name
							AND a.page_bt_synonym = b.page_bt_synonym
							AND a.primary_control_bts = b.control_bt_synonym

						IF isnull(@tb_controlid, '') = ''
							SELECT @tb_controlid = isnull(b.control_id, ''),
								@tb_viewname = isnull(b.view_name, '')
							FROM ep_published_action_mst a(NOLOCK),
								ep_published_ui_grid_dtl b(NOLOCK)
							WHERE a.customer_name = @engg_customer_name
								AND a.project_name = @engg_project_name
								AND a.req_no = @engg_req_no
								AND a.component_name = @engg_component
								AND a.activity_name = @activity_name
								AND a.ui_name = @ui_name_tmp
								AND a.task_name = @group_task_name
								AND a.customer_name = b.customer_name
								AND a.project_name = b.project_name
								AND a.req_no = b.req_no
								AND a.process_name = b.process_name
								AND a.component_name = b.component_name
								AND a.activity_name = b.activity_name
								AND a.ui_name = b.ui_name
								AND a.page_bt_synonym = b.page_bt_synonym
								AND a.primary_control_bts = b.column_bt_synonym
					END

					SELECT @tb_display_text = display_text
					FROM ep_published_ui_displaytext_lang_extn(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_req_no
						AND component_name = @engg_component
						AND activity_name = @activity_name
						AND ui_name = @ui_name_tmp
						AND group_task_name = @group_task_name
						AND lang_id = @language_code
				END

				SELECT @tb_display_text = replace(@tb_display_text, '&', '&amp;')

				SELECT @tb_display_text = replace(@tb_display_text, '<', '&lt;')

				SELECT @tb_display_text = replace(@tb_display_text, '>', '&gt;')

				SELECT @tb_display_text = replace(@tb_display_text, '"', '&quot;')

				SELECT @xml_seq_tmp = @xml_seq_tmp + 1

				INSERT INTO ep_genxml_tmp (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					activity_name,
					guid,
					gen_xml,
					seq_no
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@process_name,
					@engg_component,
					@activity_name,
					@guid,
					'<ToolBarItem Id="' + Upper(@toolbar_id) + '" ' + 'Name="' + Upper(isnull(@group_task_name, '')) + '" ' + 'Type="' + isnull(@tb_type, '') + '" ' + 'DisplayText="' + isnull(@tb_display_text, '') + '" ' + 'Sequence="' + ltrim(rtrim(CONVERT(VARCHAR(5), 
isnull(@tb_display_seqno, 0)))) + '" ' + 'CaptionRequired="' + isnull(@tb_caption_req, 'Y') + '" ' + 'ControlRequired="' + isnull(@tb_control_req, 'Y') + '" ' + 'ClassName="' + isnull(@tb_class_name, '') + '" ' + 'ControlId="' + upper(isnull(@tb_controlid
, '')) + '" ' + 'ViewName="' + upper(isnull(@tb_viewname, '')) + '"/>',
					@xml_seq_tmp
					)
			END

			CLOSE uitoolbar_cur

			DEALLOCATE uitoolbar_cur

			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'</ToolBarItems>',
				@xml_seq_tmp
				)

			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'<Groups>',
				@xml_seq_tmp
				)

			IF @pubflag = 'C'
			BEGIN
				-- Modified for adding orientation for the group (Mobility) Defect ID TECH-20897 
				DECLARE uitoolbar_cur_outer INSENSITIVE CURSOR
				FOR
				SELECT DISTINCT tool.group_name,
					Orientation
				FROM ep_ui_toolbar_dtl tool(NOLOCK),
					ep_ui_toolbar_group_dtl grp(NOLOCK)
				WHERE tool.customer_name = grp.customer_name
					AND tool.project_name = grp.project_name
					AND tool.req_no = 'Base'
					AND tool.process_name = grp.process_name
					AND tool.component_name = grp.component_name
					AND tool.activity_name = grp.activity_name
					AND tool.ui_name = grp.ui_name
					AND tool.group_name = grp.group_name
					AND tool.customer_name = @engg_customer_name
					AND tool.project_name = @engg_project_name
					AND grp.req_no = 'Base'
					AND tool.component_name = @engg_component
					AND tool.activity_name = @activity_name
					AND tool.ui_name = @ui_name_tmp
				ORDER BY tool.group_name
					--select distinct group_name
					--from ep_ui_toolbar_dtl (nolock)
					--where  customer_name   = @engg_customer_name
					--and   project_name   = @engg_project_name
					--and   req_no      = 'Base'
					--and   component_name   = @engg_component
					--and   activity_name  = @activity_name
					--and  ui_name    = @ui_name_tmp
					--order by group_name
			END
			ELSE
			BEGIN
				DECLARE uitoolbar_cur_outer INSENSITIVE CURSOR
				FOR
				SELECT DISTINCT tool.group_name,
					Orientation
				FROM ep_published_ui_toolbar_dtl tool(NOLOCK),
					ep_published_ui_toolbar_group_dtl grp(NOLOCK)
				WHERE tool.customer_name = grp.customer_name
					AND tool.project_name = grp.project_name
					AND tool.req_no = @engg_req_no
					AND tool.process_name = grp.process_name
					AND tool.component_name = grp.component_name
					AND tool.activity_name = grp.activity_name
					AND tool.ui_name = grp.ui_name
					AND tool.group_name = grp.group_name
					AND tool.customer_name = @engg_customer_name
					AND tool.project_name = @engg_project_name
					AND tool.req_no = @engg_req_no
					AND tool.component_name = @engg_component
					AND tool.activity_name = @activity_name
					AND tool.ui_name = @ui_name_tmp
				ORDER BY tool.group_name
					--select distinct group_name
					--from ep_published_ui_toolbar_dtl (nolock)
					--where  customer_name   = @engg_customer_name
					--and   project_name   = @engg_project_name
					--and   req_no      = @engg_req_no
					--and   component_name   = @engg_component
					--and   activity_name  = @activity_name
					--and  ui_name    = @ui_name_tmp
					--order by group_name
			END

			OPEN uitoolbar_cur_outer

			WHILE (1 = 1)
			BEGIN
				FETCH NEXT
				FROM uitoolbar_cur_outer
				INTO @group_name,
					@grporientation

				IF @@fetch_status <> 0
					BREAK

				SELECT @xml_seq_tmp = @xml_seq_tmp + 1

				INSERT INTO ep_genxml_tmp (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					activity_name,
					guid,
					gen_xml,
					seq_no
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@process_name,
					@engg_component,
					@activity_name,
					@guid,
					'<Group Name="' + Upper(@group_name) + '" Orientation="' + upper(@grporientation) + '">',
					@xml_seq_tmp
					)

				--@activity_name,   @guid,    '<Group Name="' + Upper(@group_name)  + '">',@xml_seq_tmp)
				IF @pubflag = 'C'
				BEGIN
					DECLARE uitoolbar_cur_inner INSENSITIVE CURSOR
					FOR
					SELECT DISTINCT group_task_name,
						task_seqno,
						class_name,
						display_text,
						group_task_desc
					FROM ep_ui_toolbar_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = 'Base'
						AND component_name = @engg_component
						AND activity_name = @activity_name
						AND ui_name = @ui_name_tmp
						AND group_name = @group_name
					ORDER BY task_seqno
				END
				ELSE
				BEGIN
					DECLARE uitoolbar_cur_inner INSENSITIVE CURSOR
					FOR
					SELECT DISTINCT group_task_name,
						task_seqno,
						class_name,
						display_text,
						group_task_desc
					FROM ep_published_ui_toolbar_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_req_no
						AND component_name = @engg_component
						AND activity_name = @activity_name
						AND ui_name = @ui_name_tmp
						AND group_name = @group_name
					ORDER BY task_seqno
				END

				OPEN uitoolbar_cur_inner

				WHILE (1 = 1)
				BEGIN
					FETCH NEXT
					FROM uitoolbar_cur_inner
					INTO @tbg_group_task_name,
						@tbg_task_seqno,
						@tbg_class_name,
						@tbg_display_text,
						@group_task_desc

					IF @@fetch_status <> 0
						BREAK

					SELECT @tbg_controlid = '',
						@tbg_viewname = ''

					IF @pubflag = 'C'
					BEGIN
						IF EXISTS (
								SELECT 'x'
								FROM ep_ui_toolbar_dtl(NOLOCK)
								WHERE customer_name = @engg_customer_name
									AND project_name = @engg_project_name
									AND req_no = 'Base'
									AND component_name = @engg_component
									AND activity_name = @activity_name
									AND ui_name = @ui_name_tmp
									AND group_name = @tbg_group_task_name
								)
							SELECT @tbg_type = 'Group'
						ELSE
						BEGIN
							SELECT @tbg_type = 'Task'

							SELECT @tbg_controlid = isnull(b.control_id, ''),
								@tbg_viewname = isnull(b.view_name, '')
							FROM ep_action_mst a(NOLOCK),
								ep_ui_control_dtl b(NOLOCK)
							WHERE a.customer_name = @engg_customer_name
								AND a.project_name = @engg_project_name
								AND a.req_no = 'Base'
								AND a.component_name = @engg_component
								AND a.activity_name = @activity_name
								AND a.ui_name = @ui_name_tmp
								AND a.task_name = @tbg_group_task_name
								AND a.customer_name = b.customer_name
								AND a.project_name = b.project_name
								AND a.req_no = b.req_no
								AND a.process_name = b.process_name
								AND a.component_name = b.component_name
								AND a.activity_name = b.activity_name
								AND a.ui_name = b.ui_name
								AND a.page_bt_synonym = b.page_bt_synonym
								AND a.primary_control_bts = b.control_bt_synonym

							IF isnull(@tbg_controlid, '') = ''
								SELECT @tbg_controlid = isnull(b.control_id, ''),
									@tbg_viewname = isnull(b.view_name, '')
								FROM ep_action_mst a(NOLOCK),
									ep_ui_grid_dtl b(NOLOCK)
								WHERE a.customer_name = @engg_customer_name
									AND a.project_name = @engg_project_name
									AND a.req_no = 'Base'
									AND a.component_name = @engg_component
									AND a.activity_name = @activity_name
									AND a.ui_name = @ui_name_tmp
									AND a.task_name = @tbg_group_task_name
									AND a.customer_name = b.customer_name
									AND a.project_name = b.project_name
									AND a.req_no = b.req_no
									AND a.process_name = b.process_name
									AND a.component_name = b.component_name
									AND a.activity_name = b.activity_name
									AND a.ui_name = b.ui_name
									AND a.page_bt_synonym = b.page_bt_synonym
									AND a.primary_control_bts = b.column_bt_synonym
						END

						SELECT @tb_control_req = control_req
						FROM ep_ui_toolbar_mapping_dtl(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND req_no = 'Base'
							AND component_name = @engg_component
							AND activity_name = @activity_name
							AND ui_name = @ui_name_tmp
							AND group_task_name = @group_name

						IF @tb_control_req = '1'
							SELECT @tb_control_req = 'Y'
						ELSE
							SELECT @tb_control_req = 'N'

						IF @tb_control_req = 'Y'
							SELECT @tbg_control_req = 'Y'
						ELSE
							SELECT @tbg_control_req = 'N'

						SELECT @tbg_display_text = display_text
						FROM ep_ui_displaytext_lang_extn(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND req_no = 'Base'
							AND component_name = @engg_component
							AND activity_name = @activity_name
							AND ui_name = @ui_name_tmp
							AND group_task_name = @tbg_group_task_name
							AND lang_id = @language_code
					END
					ELSE
					BEGIN
						IF EXISTS (
								SELECT 'x'
								FROM ep_published_ui_toolbar_dtl(NOLOCK)
								WHERE customer_name = @engg_customer_name
									AND project_name = @engg_project_name
									AND req_no = @engg_req_no
									AND component_name = @engg_component
									AND activity_name = @activity_name
									AND ui_name = @ui_name_tmp
									AND group_name = @tbg_group_task_name
								)
							SELECT @tbg_type = 'Group'
						ELSE
						BEGIN
							SELECT @tbg_type = 'Task'

							SELECT @tbg_controlid = isnull(b.control_id, ''),
								@tbg_viewname = isnull(b.view_name, '')
							FROM ep_published_action_mst a(NOLOCK),
								ep_published_ui_control_dtl b(NOLOCK)
							WHERE a.customer_name = @engg_customer_name
								AND a.project_name = @engg_project_name
								AND a.req_no = @engg_req_no
								AND a.component_name = @engg_component
								AND a.activity_name = @activity_name
								AND a.ui_name = @ui_name_tmp
								AND a.task_name = @tbg_group_task_name
								AND a.customer_name = b.customer_name
								AND a.project_name = b.project_name
								AND a.req_no = b.req_no
								AND a.process_name = b.process_name
								AND a.component_name = b.component_name
								AND a.activity_name = b.activity_name
								AND a.ui_name = b.ui_name
								AND a.page_bt_synonym = b.page_bt_synonym
								AND a.primary_control_bts = b.control_bt_synonym

							IF isnull(@tbg_controlid, '') = ''
								SELECT @tbg_controlid = isnull(b.control_id, ''),
									@tbg_viewname = isnull(b.view_name, '')
								FROM ep_published_action_mst a(NOLOCK),
									ep_published_ui_grid_dtl b(NOLOCK)
								WHERE a.customer_name = @engg_customer_name
									AND a.project_name = @engg_project_name
									AND a.req_no = @engg_req_no
									AND a.component_name = @engg_component
									AND a.activity_name = @activity_name
									AND a.ui_name = @ui_name_tmp
									AND a.task_name = @tbg_group_task_name
									AND a.customer_name = b.customer_name
									AND a.project_name = b.project_name
									AND a.req_no = b.req_no
									AND a.process_name = b.process_name
									AND a.component_name = b.component_name
									AND a.activity_name = b.activity_name
									AND a.ui_name = b.ui_name
									AND a.page_bt_synonym = b.page_bt_synonym
									AND a.primary_control_bts = b.column_bt_synonym
						END

						SELECT @tb_control_req = control_req
						FROM ep_published_ui_toolbar_mapping_dtl(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND req_no = @engg_req_no
							AND component_name = @engg_component
							AND activity_name = @activity_name
							AND ui_name = @ui_name_tmp
							AND group_task_name = @group_name

						IF @tb_control_req = '1'
							SELECT @tb_control_req = 'Y'
						ELSE
							SELECT @tb_control_req = 'N'

						IF @tb_control_req = 'Y'
							SELECT @tbg_control_req = 'Y'
						ELSE
							SELECT @tbg_control_req = 'N'

						SELECT @tbg_display_text = display_text
						FROM ep_published_ui_displaytext_lang_extn(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND req_no = @engg_req_no
							AND component_name = @engg_component
							AND activity_name = @activity_name
							AND ui_name = @ui_name_tmp
							AND group_task_name = @tbg_group_task_name
							AND lang_id = @language_code
					END

					SELECT @tbg_display_text = replace(@tbg_display_text, '&', '&amp;')

					SELECT @tbg_display_text = replace(@tbg_display_text, '<', '&lt;')

					SELECT @tbg_display_text = replace(@tbg_display_text, '>', '&gt;')

					SELECT @tbg_display_text = replace(@tbg_display_text, '"', '&quot;')

					SELECT @group_task_desc = replace(@group_task_desc, '&', '&amp;')

					SELECT @group_task_desc = replace(@group_task_desc, '<', '&lt;')

					SELECT @group_task_desc = replace(@group_task_desc, '>', '&gt;')

					SELECT @group_task_desc = replace(@group_task_desc, '"', '&quot;')

					SELECT @xml_seq_tmp = @xml_seq_tmp + 1

					INSERT INTO ep_genxml_tmp (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						activity_name,
						guid,
						gen_xml,
						seq_no
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@engg_req_no,
						@process_name,
						@engg_component,
						@activity_name,
						@guid,
						'<GroupItem Name="' + Upper(@tbg_group_task_name) + '" ' + 'Type="' + isnull(@tbg_type, '') + '" ' + 'Desc="' + isnull(@group_task_desc, '') + '" ' + 'DisplayText="' + isnull(@tbg_display_text, '') + '" ' + 'Sequence="' + ltrim(rtrim(CONVERT(VARCHAR
(5), isnull(@tbg_task_seqno, 0)))) + '" ' + 'ControlRequired="' + isnull(@tbg_control_req, 'Y') + '" ' + 'ClassName="' + isnull(@tbg_class_name, '') + '" ' + 'ControlId="' + upper(isnull(@tbg_controlid, '')) + '" ' + 'ViewName="' + upper(isnull(@tbg_viewname, '')) + '"/>',
						@xml_seq_tmp
						)
				END

				CLOSE uitoolbar_cur_inner

				DEALLOCATE uitoolbar_cur_inner

				SELECT @xml_seq_tmp = @xml_seq_tmp + 1

				INSERT INTO ep_genxml_tmp (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					activity_name,
					guid,
					gen_xml,
					seq_no
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@process_name,
					@engg_component,
					@activity_name,
					@guid,
					'</Group>',
					@xml_seq_tmp
					)
			END

			CLOSE uitoolbar_cur_outer

			DEALLOCATE uitoolbar_cur_outer

			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'</Groups>',
				@xml_seq_tmp
				)

			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'</ToolBar>',
				@xml_seq_tmp
				)

			-- Added by Feroz For UI Toolbar End
			-- Start for the feature Context Menu(PNR2.0_1476) -Added by Jeya
			-- For Preferred Tasks
			-- Code modified for the Bug ID PNR2.0_26058
			DELETE
			FROM ep_ui_contextmenu_task_dtl
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND wrkreqno = @engg_req_no
				AND component_name = @engg_component
				AND activity_name = @activity_name
				AND ui_name = @ui_name_tmp

			INSERT INTO ep_ui_contextmenu_task_dtl (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_name,
				control_bt_synonym,
				task_name,
				task_descr,
				task_type,
				task_seq,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				wrkreqno,
				control_id
				)
			SELECT customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_name,
				control_bt_synonym,
				isnull(task_name, contextual_link_name),
				contextual_link_name,
				task_type,
				contextual_link_seq,
				0,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				wrkreqno,
				substring(control_Bt_synonym, charindex('(', control_Bt_synonym) + 1, charindex('-', control_Bt_synonym) - charindex('(', control_Bt_synonym) - 1)
			FROM ep_contextual_links(NOLOCK) -- Code Modified for the Bug ID PNR2.0_25842
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND wrkreqno = @engg_req_no
				AND component_name = @engg_component
				AND activity_name = @activity_name
				AND ui_name = @ui_name_tmp

			-- Code Modification added for PNR2.0_34596   starts  
			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'<DepState>',
				@xml_seq_tmp
				)

			IF @dep_state = 'Y'
			BEGIN
				DECLARE depstate_cur INSENSITIVE CURSOR
				FOR
				SELECT page_bt_synonym,
					section_bt_synonym
				FROM ep_ui_section_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND component_name = @engg_component
					AND activity_name = @activity_name
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym <> '[mainscreen]'
				ORDER BY page_bt_synonym,
					section_bt_synonym

				SELECT @depst_page_tmp = ''

				OPEN depstate_cur

				WHILE 1 = 1
				BEGIN
					FETCH NEXT
					FROM depstate_cur
					INTO @depst_page,
						@depst_sec

					IF @@fetch_Status <> 0
						BREAK

					IF @depst_page_tmp <> @depst_page
					BEGIN
						IF @depst_page_tmp <> ''
						BEGIN
							SELECT @xml_seq_tmp = @xml_seq_tmp + 1

							INSERT INTO ep_genxml_tmp (
								customer_name,
								project_name,
								req_no,
								process_name,
								component_name,
								activity_name,
								guid,
								gen_xml,
								seq_no
								)
							VALUES (
								@engg_customer_name,
								@engg_project_name,
								@engg_req_no,
								@process_name,
								@engg_component,
								@activity_name,
								@guid,
								'</Page>',
								@xml_seq_tmp
								)
						END

						SELECT @xml_seq_tmp = @xml_seq_tmp + 1

						INSERT INTO ep_genxml_tmp (
							customer_name,
							project_name,
							req_no,
							process_name,
							component_name,
							activity_name,
							guid,
							gen_xml,
							seq_no
							)
						VALUES (
							@engg_customer_name,
							@engg_project_name,
							@engg_req_no,
							@process_name,
							@engg_component,
							@activity_name,
							@guid,
							'<Page Name="' + lower(ltrim(rtrim(isnull(@depst_page, '')))) + '">',
							@xml_seq_tmp
							)
					END

					SELECT @xml_seq_tmp = @xml_seq_tmp + 1

					INSERT INTO ep_genxml_tmp (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						activity_name,
						guid,
						gen_xml,
						seq_no
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@engg_req_no,
						@process_name,
						@engg_component,
						@activity_name,
						@guid,
						'<Section Name="' + lower(ltrim(rtrim(isnull(@depst_sec, '')))) + '"/>',
						@xml_seq_tmp
						)

					SELECT @depst_page_tmp = @depst_page
				END

				IF EXISTS (
						SELECT '*'
						FROM ep_ui_section_dtl(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND component_name = @engg_component
							AND activity_name = @activity_name
							AND ui_name = @ui_name_tmp
							AND page_bt_synonym <> '[mainscreen]'
						)
				BEGIN
					SELECT @xml_seq_tmp = @xml_seq_tmp + 1

					INSERT INTO ep_genxml_tmp (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						activity_name,
						guid,
						gen_xml,
						seq_no
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@engg_req_no,
						@process_name,
						@engg_component,
						@activity_name,
						@guid,
						'</Page>',
						@xml_seq_tmp
						)
				END

				CLOSE depstate_cur

				DEALLOCATE depstate_cur
			END

			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'</DepState>',
				@xml_seq_tmp
				)

			-- Code Modification added for PNR2.0_34596   ends  
			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'<PreferredTasks>',
				@xml_seq_tmp
				)

			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'<Controls>',
				@xml_seq_tmp
				)

			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			DECLARE @ctrlchk engg_name

			SET @ctrlchk = ''

			DECLARE prefTasks INSENSITIVE CURSOR
			FOR
			--select * from  #controls_preferredtasks (nolock)
			SELECT DISTINCT ui_name,
				upper(page_bt_synonym),
				upper(section_name),
				upper(control_bt_synonym)
			FROM ep_ui_contextmenu_task_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND wrkreqno = @engg_req_no
				AND component_name = @engg_component
				AND activity_name = @activity_name
				AND ui_name = @ui_name_tmp

			DECLARE @ui_tmp engg_name
			DECLARE @control_tmp engg_name
			DECLARE @page_tmp engg_name
			DECLARE @section_tmp engg_name
			DECLARE @taskname_tmp engg_name
			DECLARE @taskdescr_tmp engg_name
			DECLARE @tasktype_tmp engg_name
			DECLARE @taskseq_tmp engg_name
			DECLARE @control_di_tmp engg_name
			DECLARE @TaskCaption_tmp engg_name

			OPEN prefTasks

			-- For each control generate entries
			WHILE (1 = 1)
			BEGIN
				FETCH NEXT
				FROM prefTasks
				INTO @ui_tmp,
					@page_tmp,
					@section_tmp,
					@control_tmp

				IF @@fetch_status <> 0
					BREAK

				SET @ctrlchk = ltrim(rtrim(isnull(@control_tmp, '')))

				INSERT INTO ep_genxml_tmp (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					activity_name,
					guid,
					gen_xml,
					seq_no
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@process_name,
					@engg_component,
					@activity_name,
					@guid,
					'<Control Name="' + upper(ltrim(rtrim(isnull(@control_tmp, '')))) + '" ' + 'PageName="' + upper(ltrim(rtrim(isnull(@page_tmp, '')))) + '" ' + 'SectionName="' + upper(ltrim(rtrim(isnull(@section_tmp, '')))) + '">',
					@xml_seq_tmp
					)

				SELECT @taskname_tmp = task_name,
					@taskdescr_tmp = task_descr,
					@tasktype_tmp = task_type,
					@taskseq_tmp = task_seq
				FROM ep_ui_contextmenu_task_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND wrkreqno = @engg_req_no
					AND component_name = @engg_component
					AND activity_name = @activity_name
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = @page_tmp
					AND section_name = @section_tmp
					AND control_bt_synonym = @control_tmp

				SELECT @xml_seq_tmp = @xml_seq_tmp + 1

				INSERT INTO ep_genxml_tmp (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					activity_name,
					guid,
					gen_xml,
					seq_no
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@process_name,
					@engg_component,
					@activity_name,
					@guid,
					'<Tasks>',
					@xml_seq_tmp
					)

				DECLARE TotTasks INSENSITIVE CURSOR
				FOR
				-- Code modified By Jeya for the Bug ID PNR2.0_19279 Starts
				-- Existing Query Commented and new query added to fetch the task caption
				--  select  task_name, task_descr,  task_type,  task_seq ,page_bt_synonym
				-- --  select  @taskname_tmp = task_name,
				-- --   @taskdescr_tmp = task_descr,
				-- --   @tasktype_tmp = task_type,
				-- --   @taskseq_tmp = task_seq
				--  from ep_ui_contextmenu_task_dtl (nolock)
				--  where  customer_name  = @engg_customer_name
				--  and   project_name  = @engg_project_name
				--  and   wrkreqno    = @engg_req_no
				--  and   component_name  = @engg_component
				--  and   activity_name  = @activity_name
				--  and ui_name  = @ui_tmp
				--  and page_bt_synonym = @page_tmp
				--  and  section_name = @section_tmp
				--  and control_bt_synonym = @control_tmp
				SELECT DISTINCT upper(context.task_name),
					context.task_descr,
					context.task_type,
					context.task_seq,
					context.page_bt_synonym,
					syn.bt_synonym_caption
				FROM ep_ui_contextmenu_task_dtl context(NOLOCK),
					ep_published_action_mst_lng_extn task(NOLOCK),
					@ep_component_glossary_mst syn
				WHERE context.customer_name = task.customer_name
					AND context.project_name = task.project_name
					AND context.component_name = task.component_name
					AND context.process_name = task.process_name
					AND context.activity_name = task.activity_name
					AND context.ui_name = task.ui_name
					AND context.req_no = task.req_no
					--and  context.page_bt_synonym  = task.page_bt_synonym -- PNR2.0_26058
					AND context.task_name = task.task_name
					AND task.customer_name = syn.customer_name
					AND task.project_name = syn.project_name
					AND task.component_name = syn.component_name
					AND task.process_name = syn.process_name
					AND task.primary_control_bts = syn.bt_synonym_name
					AND context.customer_name = @engg_customer_name
					AND context.project_name = @engg_project_name
					AND context.component_name = @engg_component
					AND context.activity_name = @activity_name
					AND context.ui_name = @ui_tmp
					AND context.page_bt_synonym = @page_tmp
					AND context.section_name = @section_tmp
					AND context.control_bt_synonym = @control_tmp
					AND languageid = @language_code

				-- Code modified By Jeya for the Bug ID PNR2.0_19279 Ends
				OPEN TotTasks

				-- For each control generate entries
				WHILE (1 = 1)
				BEGIN
					FETCH NEXT
					FROM TotTasks
					INTO @taskname_tmp,
						@taskdescr_tmp,
						@tasktype_tmp,
						@taskseq_tmp,
						@pref_pagename,
						@TaskCaption_tmp

					IF @@fetch_status <> 0
						BREAK

					-- Code modification for PNR2.0_21576 starts
					SELECT @taskdescr_tmp = replace(@taskdescr_tmp, '&', '&amp;')

					SELECT @taskdescr_tmp = replace(@taskdescr_tmp, '<', '&lt;')

					SELECT @taskdescr_tmp = replace(@taskdescr_tmp, '>', '&gt;')

					SELECT @taskdescr_tmp = replace(@taskdescr_tmp, '"', '&quot;')

					SELECT @TaskCaption_tmp = replace(@TaskCaption_tmp, '&', '&amp;')

					SELECT @TaskCaption_tmp = replace(@TaskCaption_tmp, '<', '&lt;')

					SELECT @TaskCaption_tmp = replace(@TaskCaption_tmp, '>', '&gt;')

					SELECT @TaskCaption_tmp = replace(@TaskCaption_tmp, '"', '&quot;')

					-- Code modification for PNR2.0_21576 ends
					INSERT INTO ep_genxml_tmp (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						activity_name,
						guid,
						gen_xml,
						seq_no
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@engg_req_no,
						@process_name,
						@engg_component,
						@activity_name,
						@guid,
						'<Task Name="' + ltrim(rtrim(isnull(@taskname_tmp, ''))) + '" ' + 'TaskDesc="' + ltrim(rtrim(isnull(@taskdescr_tmp, ''))) + '" ' + 'TaskSeq="' + ltrim(rtrim(isnull(str(@taskseq_tmp), ''))) + '" ' + 'TaskType="' + ltrim(rtrim(isnull(@tasktype_tmp, ''
))) + '" ' + 'PageName="' + ltrim(rtrim(isnull(@pref_pagename, ''))) + '" ' +
						-- Code modified By Jeya for the Bug ID PNR2.0_19279 Starts
						'TaskCaption="' + ltrim(rtrim(isnull(@TaskCaption_tmp, ''))) + '"/>',
						@xml_seq_tmp
						)
						-- Code modified By Jeya for the Bug ID PNR2.0_19279 Ends
				END

				CLOSE TotTasks

				DEALLOCATE TotTasks

				SELECT @xml_seq_tmp = @xml_seq_tmp + 1

				INSERT INTO ep_genxml_tmp (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					activity_name,
					guid,
					gen_xml,
					seq_no
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@process_name,
					@engg_component,
					@activity_name,
					@guid,
					'</Tasks>',
					@xml_seq_tmp
					)

				SELECT @xml_seq_tmp = @xml_seq_tmp + 1

				INSERT INTO ep_genxml_tmp (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					activity_name,
					guid,
					gen_xml,
					seq_no
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@process_name,
					@engg_component,
					@activity_name,
					@guid,
					'</Control>',
					@xml_seq_tmp
					)
			END

			CLOSE prefTasks

			DEALLOCATE prefTasks

			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'</Controls>',
				@xml_seq_tmp
				)

			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'</PreferredTasks>',
				@xml_seq_tmp
				)

			-- End for the feature Context Menu(PNR2.0_1476) -Added by Jeya
			-- Code Added for the Feature Control Extensions Starts-- by Jeya Latha K
			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'<ControlExtensions>',
				@xml_seq_tmp
				)

			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'<Controls>',
				@xml_seq_tmp
				)

			SET @ctrlchk = ''

			DECLARE get_controlext INSENSITIVE CURSOR
			FOR
			SELECT DISTINCT ui_name,
				upper(page_bt_synonym),
				upper(section_name),
				upper(control_bt_synonym)
			FROM ep_control_extensions(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND component_name = @engg_component
				AND activity_name = @activity_name
				AND ui_name = @ui_name_tmp

			DECLARE @ce_ui_tmp engg_name
			DECLARE @ce_control_tmp engg_name
			DECLARE @ce_page_tmp engg_name
			DECLARE @ce_section_tmp engg_name
			DECLARE @ce_taskname_tmp engg_name
			DECLARE @ce_taskdescr_tmp engg_name
			DECLARE @ce_tasktype_tmp engg_name
			DECLARE @ce_taskseq_tmp engg_name
			DECLARE @ce_control_id_tmp engg_name
			DECLARE @ce_TaskCaption_tmp engg_name

			OPEN get_controlext

			-- For each control generate entries
			WHILE (1 = 1)
			BEGIN
				FETCH NEXT
				FROM get_controlext
				INTO @ce_ui_tmp,
					@ce_page_tmp,
					@ce_section_tmp,
					@ce_control_tmp

				IF @@fetch_status <> 0
					BREAK

				SET @ctrlchk = ltrim(rtrim(isnull(@control_tmp, '')))

				SELECT @ce_control_id_tmp = substring(@ce_control_tmp, charindex('(', @ce_control_tmp) + 1, charindex('-', @ce_control_tmp) - charindex('(', @ce_control_tmp) - 1)

				SELECT @xml_seq_tmp = @xml_seq_tmp + 1

				INSERT INTO ep_genxml_tmp (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					activity_name,
					guid,
					gen_xml,
					seq_no
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@process_name,
					@engg_component,
					@activity_name,
					@guid,
					'<Control Name="' + upper(ltrim(rtrim(isnull(@ce_control_id_tmp, '')))) + '" ' + 'PageName="' + upper(ltrim(rtrim(isnull(@ce_page_tmp, '')))) + '" ' + 'SectionName="' + upper(ltrim(rtrim(isnull(@ce_section_tmp, '')))) + '">',
					@xml_seq_tmp
					)

				SELECT @xml_seq_tmp = @xml_seq_tmp + 1

				INSERT INTO ep_genxml_tmp (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					activity_name,
					guid,
					gen_xml,
					seq_no
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@process_name,
					@engg_component,
					@activity_name,
					@guid,
					'<Tasks>',
					@xml_seq_tmp
					)

				DECLARE TotTasks1 INSENSITIVE CURSOR
				FOR
				SELECT DISTINCT upper(context.task_name),
					context.controlextension_name,
					context.task_type,
					context.controlextension_seq,
					upper(context.page_bt_synonym),
					syn.bt_synonym_caption
				FROM ep_control_extensions context(NOLOCK),
					ep_published_action_mst_lng_extn task(NOLOCK),
					@ep_component_glossary_mst syn
				WHERE context.customer_name = task.customer_name
					AND context.project_name = task.project_name
					AND context.component_name = task.component_name
					AND context.process_name = task.process_name
					AND context.activity_name = task.activity_name
					AND context.ui_name = task.ui_name
					AND context.req_no = task.req_no
					AND context.page_bt_synonym = task.page_bt_synonym
					AND context.task_name = task.task_name
					AND task.customer_name = syn.customer_name
					AND task.project_name = syn.project_name
					AND task.component_name = syn.component_name
					AND task.process_name = syn.process_name
					AND task.primary_control_bts = syn.bt_synonym_name
					AND context.customer_name = @engg_customer_name
					AND context.project_name = @engg_project_name
					AND context.component_name = @engg_component
					AND context.activity_name = @activity_name
					AND context.ui_name = @ce_ui_tmp
					AND context.page_bt_synonym = @ce_page_tmp
					AND context.section_name = @ce_section_tmp
					AND context.control_bt_synonym = @ce_control_tmp

				OPEN TotTasks1

				-- For each control generate entries
				WHILE (1 = 1)
				BEGIN
					FETCH NEXT
					FROM TotTasks1
					INTO @ce_taskname_tmp,
						@ce_taskdescr_tmp,
						@ce_tasktype_tmp,
						@ce_taskseq_tmp,
						@ce_page_tmp,
						@ce_TaskCaption_tmp

					IF @@fetch_status <> 0
						BREAK

					SELECT @ce_taskdescr_tmp = replace(@ce_taskdescr_tmp, '&', '&amp;')

					SELECT @ce_taskdescr_tmp = replace(@ce_taskdescr_tmp, '<', '&lt;')

					SELECT @ce_taskdescr_tmp = replace(@ce_taskdescr_tmp, '>', '&gt;')

					SELECT @ce_taskdescr_tmp = replace(@ce_taskdescr_tmp, '"', '&quot;')

					SELECT @ce_TaskCaption_tmp = replace(@ce_TaskCaption_tmp, '&', '&amp;')

					SELECT @ce_TaskCaption_tmp = replace(@ce_TaskCaption_tmp, '<', '&lt;')

					SELECT @ce_TaskCaption_tmp = replace(@ce_TaskCaption_tmp, '>', '&gt;')

					SELECT @ce_TaskCaption_tmp = replace(@ce_TaskCaption_tmp, '"', '&quot;')

					INSERT INTO ep_genxml_tmp (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						activity_name,
						guid,
						gen_xml,
						seq_no
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@engg_req_no,
						@process_name,
						@engg_component,
						@activity_name,
						@guid,
						'<Task Name="' + ltrim(rtrim(isnull(@ce_taskname_tmp, ''))) + '" ' + 'TaskDesc="' + ltrim(rtrim(isnull(@ce_taskdescr_tmp, ''))) + '" ' + 'TaskSeq="' + ltrim(rtrim(isnull(str(@ce_taskseq_tmp), ''))) + '" ' + 'TaskType="' + ltrim(rtrim(isnull(@ce_tasktype_tmp, ''))) + '" ' + 'PageName="' + ltrim(rtrim(isnull(@ce_page_tmp, ''))) + '" ' + 'TaskCaption="' + ltrim(rtrim(isnull(@TaskCaption_tmp, ''))) + '"/>',
						@xml_seq_tmp
						)
				END

				CLOSE TotTasks1

				DEALLOCATE TotTasks1

				SELECT @xml_seq_tmp = @xml_seq_tmp + 1

				INSERT INTO ep_genxml_tmp (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					activity_name,
					guid,
					gen_xml,
					seq_no
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@process_name,
					@engg_component,
					@activity_name,
					@guid,
					'</Tasks>',
					@xml_seq_tmp
					)

				SELECT @xml_seq_tmp = @xml_seq_tmp + 1

				INSERT INTO ep_genxml_tmp (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					activity_name,
					guid,
					gen_xml,
					seq_no
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@process_name,
					@engg_component,
					@activity_name,
					@guid,
					'</Control>',
					@xml_seq_tmp
					)
			END

			CLOSE get_controlext

			DEALLOCATE get_controlext

			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'</Controls>',
				@xml_seq_tmp
				)

			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'</ControlExtensions>',
				@xml_seq_tmp
				)

			-- Code Added for the Feature Control Extensions  End-- by Jeya Latha K
			-- Added By Feroz For List Edit
			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'<ListEdit>',
				@xml_seq_tmp
				)

			DECLARE @listedit_synonym engg_name,
				@listedit_controlid engg_name,
				@mapped_bt_synonym engg_name,
				@Mapped_control_id engg_name,
				@Mapped_view_name engg_name,
				@listedit_column_synonym engg_name,
				@data_mapped_synonym engg_name,
				@datamap_control_id engg_name,
				@datamap_view_name engg_name,
				@lst_controlid engg_name,
				@listedit_viewname engg_name,
				@visible_listcolumn engg_flag,
				@autolist_not_req engg_flag,
				@controlname engg_name
			DECLARE @page_name engg_name --Added for PNR2.0_26631

			IF @pubflag = 'C'
			BEGIN
				DECLARE ListEditMainCur INSENSITIVE CURSOR
				FOR
				SELECT DISTINCT listedit_synonym,
					listedit_controlid,
					listedit_viewname -- Modified By feroz for bug id :PNR2.0_23463
				FROM ep_listedit_control_map(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = 'Base'
					AND component_name = @engg_component
					AND activity_name = @activity_name
					AND ui_name = @ui_name_tmp
				ORDER BY listedit_synonym
			END
			ELSE
			BEGIN
				DECLARE ListEditMainCur INSENSITIVE CURSOR
				FOR
				SELECT DISTINCT listedit_synonym,
					listedit_controlid,
					listedit_viewname -- Modified By feroz for bug id :PNR2.0_23463
				FROM ep_published_listedit_control_map(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_req_no
					AND component_name = @engg_component
					AND activity_name = @activity_name
					AND ui_name = @ui_name_tmp
				ORDER BY listedit_synonym
			END

			OPEN ListEditMainCur

			WHILE (1 = 1)
			BEGIN
				FETCH NEXT
				FROM ListEditMainCur
				INTO @listedit_synonym,
					@lst_controlid,
					@listedit_viewname -- Modified By feroz for bug id :PNR2.0_23463

				IF @@fetch_status <> 0
					BREAK

				-- Modified By feroz for bug id :PNR2.0_23463
				IF @pubflag = 'C'
				BEGIN
					SELECT @listedit_controlid = upper(Control_id)
					FROM ep_ui_control_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND component_name = @engg_component
						AND activity_name = @activity_name
						AND ui_name = @ui_name_tmp
						AND control_bt_synonym = @listedit_synonym
						AND control_id = @lst_controlid
						AND view_name = @listedit_viewname
				END
				ELSE
				BEGIN
					SELECT @listedit_controlid = upper(Control_id)
					FROM ep_published_ui_control_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_req_no
						AND component_name = @engg_component
						AND activity_name = @activity_name
						AND ui_name = @ui_name_tmp
						AND control_bt_synonym = @listedit_synonym
						AND control_id = @lst_controlid
						AND view_name = @listedit_viewname
				END

				-- Modified By feroz for bug id :PNR2.0_23463
				SELECT @xml_seq_tmp = @xml_seq_tmp + 1

				INSERT INTO ep_genxml_tmp (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					activity_name,
					guid,
					gen_xml,
					seq_no
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@process_name,
					@engg_component,
					@activity_name,
					@guid,
					'<ListControl Name="' + upper(ltrim(rtrim(isnull(@listedit_controlid, '')))) + '">',
					@xml_seq_tmp
					)

				IF @pubflag = 'C'
				BEGIN
					DECLARE ListEditCur INSENSITIVE CURSOR
					FOR
					SELECT mapped_bt_synonym,
						control_id,
						view_name,
						page_bt_synonym --Modified for PNR2.0_26631
					FROM ep_listedit_control_map(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = 'Base'
						AND component_name = @engg_component
						AND activity_name = @activity_name
						AND ui_name = @ui_name_tmp
						AND listedit_synonym = @listedit_synonym
					ORDER BY mapped_bt_synonym,
						control_id,
						view_name
				END
				ELSE
				BEGIN
					DECLARE ListEditCur INSENSITIVE CURSOR
					FOR
					SELECT mapped_bt_synonym,
						control_id,
						view_name,
						page_bt_synonym --Modified for PNR2.0_26631
					FROM ep_published_listedit_control_map(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_req_no
						AND component_name = @engg_component
						AND activity_name = @activity_name
						AND ui_name = @ui_name_tmp
						AND listedit_synonym = @listedit_synonym
					ORDER BY mapped_bt_synonym,
						control_id,
						view_name
				END

				OPEN ListEditCur

				WHILE (1 = 1)
				BEGIN
					FETCH NEXT
					FROM ListEditCur
					INTO @mapped_bt_synonym,
						@Mapped_control_id,
						@Mapped_view_name,
						@page_name --Modified for PNR2.0_26631

					IF @@fetch_status <> 0
						BREAK

					IF @pubflag = 'C'
					BEGIN
						SELECT @primary_search_column = Upper(b.listedit_controlid) + b.listedit_viewname,
							@list_index_search = a.list_index_search
						FROM ep_resolvelist_data_map a(NOLOCK),
							ep_listedit_column_dtl b(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.req_no = 'Base'
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							--and a.page_bt_synonym = @page_name  --Modified for PNR2.0_26631    --Commented for PNR2.0_26701
							AND a.listedit_synonym = @listedit_synonym
							AND a.mapped_bt_syn_page = @page_name --Modified for  PNR2.0_26701
							AND a.mapped_bt_synonym = @mapped_bt_synonym
							AND a.primary_search_column = 1
							AND a.customer_name = b.customer_name
							AND a.project_name = b.project_name
							AND a.req_no = b.req_no
							AND a.process_name = b.process_name
							AND a.component_name = b.component_name
							AND a.activity_name = b.activity_name
							AND a.ui_name = b.ui_name
							AND a.listedit_synonym = b.listedit_synonym
							AND a.listedit_column_synonym = b.listedit_column_synonym
					END

					BEGIN
						SELECT @primary_search_column = upper(b.listedit_controlid) + b.listedit_viewname,
							@list_index_search = a.list_index_search
						FROM ep_published_resolvelist_data_map a(NOLOCK),
							ep_published_listedit_column_dtl b(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.req_no = @engg_req_no
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							AND a.listedit_synonym = @listedit_synonym
							AND a.mapped_bt_synonym = @mapped_bt_synonym
							AND a.primary_search_column = 1
							AND a.customer_name = b.customer_name
							AND a.project_name = b.project_name
							AND a.req_no = b.req_no
							AND a.process_name = b.process_name
							AND a.component_name = b.component_name
							AND a.activity_name = b.activity_name
							AND a.ui_name = b.ui_name
							AND a.listedit_synonym = b.listedit_synonym
							AND a.listedit_column_synonym = b.listedit_column_synonym
					END

					SELECT @xml_seq_tmp = @xml_seq_tmp + 1

					INSERT INTO ep_genxml_tmp (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						activity_name,
						guid,
						gen_xml,
						seq_no
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@engg_req_no,
						@process_name,
						@engg_component,
						@activity_name,
						@guid,
						'<EditControl Name="' + upper(ltrim(rtrim(isnull(@mapped_bt_synonym, '')))) + '" ' + 'ControlId="' + upper(ltrim(rtrim(isnull(@Mapped_control_id, '')))) + '" ' + 'ViewName="' + upper(ltrim(rtrim(isnull(@Mapped_view_name, '')))) + '" ' + 'PrimarySearchColumn="' + ltrim(rtrim(isnull(@primary_search_column, ''))) + '" ' + 'ListIndexSearch="' + ltrim(rtrim(isnull(@list_index_search, '0'))) + '">',
						@xml_seq_tmp
						)

					IF @pubflag = 'C'
					BEGIN
						DECLARE ListEditInnerCur INSENSITIVE CURSOR
						FOR
						SELECT listedit_column_synonym,
							data_mapped_synonym,
							b.control_id,
							b.view_name,
							CASE 
								WHEN a.visible = 1
									THEN 'Y'
								ELSE 'N'
								END
						FROM ep_resolvelist_data_map a(NOLOCK),
							ep_ui_grid_dtl b(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							--and  a.page_bt_synonym			= @page_bt_synonym  --Modified for PNR2.0_26631 --Commented for PNR2.0_26701
							AND a.mapped_bt_syn_page = @page_tmp --Modified for  PNR2.0_26701 
							AND a.listedit_synonym = @listedit_synonym
							AND a.mapped_bt_synonym = @mapped_bt_synonym
							--and	a.visible					= 1
							AND a.customer_name = b.customer_name
							AND a.project_name = b.project_name
							AND a.process_name = b.process_name
							AND a.component_name = b.component_name
							AND a.activity_name = b.activity_name
							AND a.ui_name = b.ui_name
							--and	a.page_bt_synonym = b.page_bt_synonym  --commented for PNR2.0_26631
							AND a.listedit_synonym = b.control_bt_synonym
							AND a.listedit_column_synonym = b.column_bt_synonym
						ORDER BY b.control_id,
							b.view_name
							-- Modified By feroz for bug id :PNR2.0_23463
					END
					ELSE
					BEGIN
						DECLARE ListEditInnerCur INSENSITIVE CURSOR
						FOR
						SELECT listedit_column_synonym,
							data_mapped_synonym,
							b.control_id,
							b.view_name,
							CASE 
								WHEN a.visible = 1
									THEN 'Y'
								ELSE 'N'
								END
						FROM ep_published_resolvelist_data_map a(NOLOCK),
							ep_published_ui_grid_dtl b(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.req_no = @engg_req_no
							AND a.component_name = @engg_component
							AND a.activity_name = @activity_name
							AND a.ui_name = @ui_name_tmp
							--and  a.page_bt_synonym = 	@page_bt_synonym  --Modified for PNR2.0_26631 --Commented for PNR2.0_26701
							AND a.mapped_bt_syn_page = @page_tmp --Modified for  PNR2.0_26701 
							AND a.listedit_synonym = @listedit_synonym
							AND a.mapped_bt_synonym = @mapped_bt_synonym
							--and  a.visible   = 1
							AND a.customer_name = b.customer_name
							AND a.project_name = b.project_name
							AND a.req_no = b.req_no
							AND a.process_name = b.process_name
							AND a.component_name = b.component_name
							AND a.activity_name = b.activity_name
							AND a.ui_name = b.ui_name
							--and  a.page_bt_synonym = b.page_bt_synonym  --commented for PNR2.0_26631
							AND a.listedit_synonym = b.control_bt_synonym
							AND a.listedit_column_synonym = b.column_bt_synonym
						ORDER BY b.control_id,
							b.view_name
							-- Modified By feroz for bug id :PNR2.0_23463
					END

					OPEN ListEditInnerCur

					-- For each control generate entries
					WHILE (1 = 1)
					BEGIN
						FETCH NEXT
						FROM ListEditInnerCur
						INTO @listedit_column_synonym,
							@data_mapped_synonym,
							@datamap_control_id,
							@datamap_view_name,
							@visible_listcolumn

						IF @@fetch_status <> 0
							BREAK

						SELECT @xml_seq_tmp = @xml_seq_tmp + 1

						INSERT INTO ep_genxml_tmp (
							customer_name,
							project_name,
							req_no,
							process_name,
							component_name,
							activity_name,
							guid,
							gen_xml,
							seq_no
							)
						VALUES (
							@engg_customer_name,
							@engg_project_name,
							@engg_req_no,
							@process_name,
							@engg_component,
							@activity_name,
							@guid,
							'<Column Name="' + upper(ltrim(rtrim(isnull(@listedit_column_synonym, '')))) + '" ' + 'MappedControlId="' + upper(ltrim(rtrim(isnull(@datamap_control_id, '')))) + '" ' + 'MappedViewName="' + upper(ltrim(rtrim(isnull(@datamap_view_name, '')))) + '" 
' + 'Visible="' + upper(ltrim(rtrim(isnull(@visible_listcolumn, '')))) + '" />',
							@xml_seq_tmp
							)
					END

					CLOSE ListEditInnerCur

					DEALLOCATE ListEditInnerCur

					SELECT @xml_seq_tmp = @xml_seq_tmp + 1

					INSERT INTO ep_genxml_tmp (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						activity_name,
						guid,
						gen_xml,
						seq_no
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@engg_req_no,
						@process_name,
						@engg_component,
						@activity_name,
						@guid,
						'</EditControl>',
						@xml_seq_tmp
						)
				END

				CLOSE ListEditCur

				DEALLOCATE ListEditCur

				SELECT @xml_seq_tmp = @xml_seq_tmp + 1

				INSERT INTO ep_genxml_tmp (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					activity_name,
					guid,
					gen_xml,
					seq_no
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@process_name,
					@engg_component,
					@activity_name,
					@guid,
					'</ListControl>',
					@xml_seq_tmp
					)
			END

			CLOSE ListEditMainCur

			DEALLOCATE ListEditMainCur

			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'</ListEdit>',
				@xml_seq_tmp
				)

				Declare	@tmp_listcontrolsyn		engg_name,
				@tmp_listcontrolid		engg_documentation,
				@tmp_listviewname		engg_name,
				@tmp_queryid			engg_name,
				@tmp_searchindex		engg_name,
				@tmp_pagesize			engg_name,
				@tmp_searchcontext		ngplf_nvarchar_max,
				@tmp_resultcolumn		ngplf_nvarchar_max,
				@tmp_selectcolumn		ngplf_nvarchar_max,
				@tmp_caption			engg_description,
				@tmp_width				engg_seqno,
				@Position				engg_seqno,
				@tmp_pagename			engg_name,
				@xml_seq_tmp_out		int ,
				@sql					nvarchar(max)

			-- Added By Feroz For List Edit
			--code added by kiruthika for bugid:PLF2.0_03710
			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'<CustomList>',
				@xml_seq_tmp
				)

			DECLARE @editcontrol engg_name,
				@list_search_id engg_custom,
				@list_search_context engg_custom,
				@list_recurrent_search engg_seqno,
				@list_search_delay engg_seqno,
				@list_select_column engg_custom,
				@list_result_column engg_custom,
				@list_width engg_seqno,
				@control_id	engg_name -- Code added for TECH-56482

			IF @ctxt_service_in IN ('BulkGenerate')
				AND @pubflag = 'P'
			BEGIN
				DECLARE custom_cursor CURSOR
				FOR
				SELECT DISTINCT upper(page_bt_synonym),
					upper(listedit_synonym),
					list_search_id,
					list_search_context,
					list_index_search,
					list_recurrent_search,
					list_search_delay,
					list_select_column,
					list_result_column,
					list_width
				FROM ep_published_custom_listedit(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_req_no
					AND process_name = @process_name
					AND component_name = @engg_component
					AND activity_name = @activity_name
					AND ui_name = @ui_name_tmp
			END
			ELSE
			BEGIN
				DECLARE custom_cursor CURSOR
				FOR
				SELECT DISTINCT upper(page_bt_synonym),
					upper(listedit_synonym),
					list_search_id,
					list_search_context,
					list_index_search,
					list_recurrent_search,
					list_search_delay,
					list_select_column,
					list_result_column,
					list_width
				FROM ep_custom_listedit(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @process_name
					AND component_name = @engg_component
					AND activity_name = @activity_name
					AND ui_name = @ui_name_tmp
			END

			OPEN custom_cursor

			WHILE (1 = 1)
			BEGIN
				FETCH NEXT
				FROM custom_cursor
				INTO @page_bt_synonym_tmp,
					@editcontrol,
					@list_search_id,
					@list_search_context,
					@list_index_search,
					@list_recurrent_search,
					@list_search_delay,
					@list_select_column,
					@list_result_column,
					@list_width

				IF @@fetch_status <> 0
					BREAK

					select	@control_id	= upper(ctrl_id)
					from	ep_ui_control_dtl_vw (nolock)
					where	customer_name		=	@engg_customer_name
					and		project_name		=	@engg_project_name
					and		process_name		=	@process_name
					and		component_name		=	@engg_component
					and		activity_name		=	@activity_name
					and		ui_name				=	@ui_name_tmp
					and		page_bt_synonym		=	@page_bt_synonym_tmp -- modified for TECH-56570
					--and		section_bt_synonym	=	@de_maint_callout_section
					and		((control_bt_synonym	= @editcontrol) or 	(column_bt_synonym	= @editcontrol))
				

				SELECT @xml_seq_tmp = @xml_seq_tmp + 1

				INSERT INTO ep_genxml_tmp (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					activity_name,
					guid,
					gen_xml,
					seq_no
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@process_name,
					@engg_component,
					@activity_name,
					@guid,
					'<EditControl Name="' + ltrim(rtrim(isnull(@editcontrol, ''))) + '" ' +
					'ControlName="' + ltrim(rtrim(@control_id))      + '" ' + ---- Code added for TECH-56482
					'PageName="' + ltrim(rtrim(isnull(@page_bt_synonym_tmp, ''))) + '" ' + 
					'IlboName="' + ltrim(rtrim(isnull(@ui_name_tmp, ''))) + '" ' + 
					'ActivityName="' + ltrim(rtrim(isnull(@activity_name, ''))) + '" ' + 
					'ComponentName="' + ltrim(rtrim(isnull(@engg_component, ''))) + '" ' + 
					'SearchId="' + ltrim(rtrim(isnull(@list_search_id, ''))) + '" ' + 
					'SearchContext="' + ltrim(rtrim(isnull(@list_search_context, ''))) + '" ' + 
					'ListIndexSearch="' + ltrim(rtrim(isnull(str(@list_index_search), ''))) + '" ' + 
					'Position="' + ltrim(rtrim(isnull(str(@list_recurrent_search), ''))) + '" ' + 
					'Delay="' + ltrim(rtrim(isnull(str(@list_search_delay), ''))) + '" ' + 
					'SelectColumn="' + ltrim(rtrim(isnull(@list_select_column, ''))) + '" ' + 
					'ResultColumn="' + ltrim(rtrim(isnull(@list_result_column, ''))) + '" ' + 
					'ListWidth="' + ltrim(rtrim(isnull(str(@list_width), ''))) + '"/>',
					@xml_seq_tmp
					)
			END

			CLOSE custom_cursor

			DEALLOCATE custom_cursor

		-- Added by JL elastic search TECH-45546 Starts
		Declare eslist_cur cursor Fast_forward for
		SELECT	DISTINCT 
				UPPER(ListControlSynonym),	UPPER(ListControlID),	UPPER(ListViewname),		LOWER(QueryID),
				SearchIndex,		Pagesize--,		UPPER(Page_bt_synonym)--
		FROM	ep_els_query_listedit_map lst (nolock)--,
			--	de_published_ui_control ctl (nolock)
		WHERE	lst.customername	=	@engg_customer_name
		and		lst.projectname		=	@engg_project_name
		and		lst.Reqno			=	@engg_req_no
		and		lst.processname		=	@process_name
		and		lst.componentname	=	@engg_component
		and		lst.activityname	=	@activity_name
		and		lst.uiname      	=	@ui_name_tmp	
			
		open eslist_cur
		Fetch Next from eslist_cur into @tmp_listcontrolsyn,	@tmp_listcontrolid,	@tmp_listviewname,	@tmp_queryid,
							@tmp_searchindex,	@tmp_pagesize--,		@tmp_pagename--, @tmp_node
			
		While (1=1)
		begin		
		If @@fetch_status <> 0 
		 break
		 
		
			SELECT	@tmp_searchindex	=	1,
					@position			=	1,
					@tmp_searchcontext	=	'',
					@tmp_resultcolumn	=	'',
					@tmp_selectcolumn	=	''
					

			select	@tmp_pagename		=	page_bt_synonym,
					@tmp_node			=	'Control'
			from	ep_ui_control_dtl (nolock)
			where	customer_name		=	@engg_customer_name
			and		project_name		=	@engg_project_name
			and		process_name		=	@process_name
			and		component_name		=	@engg_component
			and		activity_name		=	@activity_name
			and		ui_name				=	@ui_name_tmp
			and		control_bt_synonym	=	@tmp_listcontrolsyn 

			IF ISNULL(@tmp_pagename,'') = ''
			BEGIN
				select	@tmp_pagename		=	page_bt_synonym,
						@tmp_node			=	'Column'
				from	ep_ui_grid_dtl (nolock)
				where	customer_name		=	@engg_customer_name
				and		project_name		=	@engg_project_name
				and		process_name		=	@process_name
				and		component_name		=	@engg_component
				and		activity_name		=	@activity_name
				and		ui_name				=	@ui_name_tmp
				and		column_bt_synonym	=	@tmp_listcontrolsyn 
			END

			SELECT	@tmp_searchcontext	=	STUFF((SELECT '~' + (ISNULL(MappedControlID,'') + '$$' + ISNULL(MappedViewName,''))
					FROM ep_els_query_listedit_input lst (nolock)
					WHERE	lst.customername	=	inp.customername
					and		lst.projectname		=	inp.projectname
					and		lst.componentname	=	inp.componentname
					and		lst.activityname	=	inp.activityname
					and		lst.uiname			=	inp.uiname
					and		lst.Listcontrolid	=	inp.Listcontrolid
					and		lst.listviewname	=	inp.listviewname
					and		lst.QueryID			=	inp.QueryID
					and		lst.reqno			=	@engg_req_no
					FOR XML PATH ('')), 1, 1, '') 
			FROM	ep_els_query_listedit_input inp (nolock)
			WHERE 	inp.customername	=	@engg_customer_name
			and		inp.projectname		=	@engg_project_name
			and		inp.reqno			=	@engg_req_no
			and		inp.processname		=	@process_name
			and		inp.componentname	=	@engg_component
			and		inp.activityname	=	@activity_name
			and		inp.uiname      	=	@ui_name_tmp	
			and		inp.Listcontrolid	=	@tmp_listcontrolid
			and		inp.listviewname	=	@tmp_listviewname
			and		inp.queryid			=	@tmp_queryid
			GROUP BY  inp.customername, inp.projectname, inp.componentname, inp.activityname, inp.uiname, inp.Listcontrolid, inp.listviewname, inp.QueryID
			--select 'tt1',@tmp_searchcontext, @tmp_listcontrolid,@tmp_listviewname, @tmp_queryid
		
			SELECT	@tmp_resultcolumn	=	STUFF((SELECT '#' + (ISNULL(ResultColumnName,'') + '~' + ISNULL(IsVisible,'N') + '~' + CAST(ISNULL(Width,'20') AS NVARCHAR(10))+ '~' + ISNULL(ParameterCaption,''))
					FROM ep_els_query_listedit_result lst (nolock)
					WHERE	lst.customername	=	inp.customername
					and		lst.projectname		=	inp.projectname
					and		lst.componentname	=	inp.componentname
					and		lst.activityname	=	inp.activityname
					and		lst.uiname			=	inp.uiname
					and		lst.Listcontrolid	=	inp.Listcontrolid
					and		lst.listviewname	=	inp.listviewname
					and		lst.QueryID			=	inp.QueryID
					and		lst.reqno			=	@engg_req_no
					ORDER BY  seqno
					FOR XML PATH ('')), 1, 1, '') 
			FROM	ep_els_query_listedit_result inp (nolock)
			WHERE 	inp.customername	=	@engg_customer_name
			and		inp.projectname		=	@engg_project_name
			and		inp.reqno			=	@engg_req_no
			and		inp.processname		=	@process_name
			and		inp.componentname	=	@engg_component
			and		inp.activityname	=	@activity_name
			and		inp.uiname      	=	@ui_name_tmp	
			and		inp.Listcontrolid	=	@tmp_listcontrolid
			and		inp.listviewname	=	@tmp_listviewname
			and		inp.queryid			=	@tmp_queryid
			GROUP BY  inp.customername, inp.projectname, inp.componentname, inp.activityname, inp.uiname, inp.Listcontrolid, inp.listviewname, inp.QueryID
			
			
			IF ISNULL(@tmp_node,'') = 'Control'		
			BEGIN
				SELECT	@tmp_selectcolumn	=	STUFF((SELECT '#' + (ISNULL(MappedViewName,'') + '~' + CAST(ISNULL(Seqno-1,0) AS NVARCHAR(10)))
						FROM ep_els_query_listedit_result lst (nolock)
						WHERE	lst.customername	=	inp.customername
						and		lst.projectname		=	inp.projectname
						and		lst.componentname	=	inp.componentname
						and		lst.activityname	=	inp.activityname
						and		lst.uiname			=	inp.uiname
						and		lst.Listcontrolid	=	inp.Listcontrolid
						and		lst.listviewname	=	inp.listviewname
						and		lst.QueryID			=	inp.QueryID
						and		lst.reqno			=	@engg_req_no
						and		ISNULL(lst.MappedViewName,'')  <> ''
						ORDER BY  seqno
						FOR XML PATH ('')), 1, 1, '') 
				FROM	ep_els_query_listedit_result inp (nolock)
				WHERE 	inp.customername	=	@engg_customer_name
				and		inp.projectname		=	@engg_project_name
				and		inp.reqno			=	@engg_req_no
				and		inp.processname		=	@process_name
				and		inp.componentname	=	@engg_component
				and		inp.activityname	=	@activity_name
				and		inp.uiname      	=	@ui_name_tmp	
				and		inp.Listcontrolid	=	@tmp_listcontrolid
				and		inp.listviewname	=	@tmp_listviewname
				and		inp.queryid			=	@tmp_queryid
				and		ISNULL(inp.MappedViewName,'')  <> ''
				GROUP BY  inp.customername, inp.projectname, inp.componentname, inp.activityname, inp.uiname, inp.Listcontrolid, inp.listviewname, inp.QueryID
			END

			IF ISNULL(@tmp_node,'') = 'Column'		
			BEGIN
				SELECT	@tmp_selectcolumn	=	STUFF((SELECT '#' + (ISNULL(MappedViewName,'') + '~' + CAST(ISNULL(Seqno-1,0) AS NVARCHAR(10)))
						FROM ep_els_query_listedit_result lst (nolock)
						WHERE	lst.customername	=	inp.customername
						and		lst.projectname		=	inp.projectname
						and		lst.componentname	=	inp.componentname
						and		lst.activityname	=	inp.activityname
						and		lst.uiname			=	inp.uiname
						and		lst.Listcontrolid	=	inp.Listcontrolid
						and		lst.listviewname	=	inp.listviewname
						and		lst.QueryID			=	inp.QueryID
						and		lst.reqno			=	@engg_req_no
						--and		ISNULL(lst.MappedViewName,'')  <> ''
						ORDER BY  seqno
						FOR XML PATH ('')), 1, 1, '') 
				FROM	ep_els_query_listedit_result inp (nolock)
				WHERE 	inp.customername	=	@engg_customer_name
				and		inp.projectname		=	@engg_project_name
				and		inp.reqno			=	@engg_req_no
				and		inp.processname	=	@process_name
				and		inp.componentname	=	@engg_component
				and		inp.activityname	=	@activity_name
				and		inp.uiname      	=	@ui_name_tmp	
				and		inp.Listcontrolid	=	@tmp_listcontrolid
				and		inp.listviewname	=	@tmp_listviewname
				and		inp.queryid			=	@tmp_queryid
				--and		ISNULL(inp.MappedViewName,'')  <> ''
				GROUP BY  inp.customername, inp.projectname, inp.componentname, inp.activityname, inp.uiname, inp.Listcontrolid, inp.listviewname, inp.QueryID
			END
			
				select @xml_seq_tmp=@xml_seq_tmp+1
				insert into ep_genxml_tmp 
					(customer_name, 		project_name, 		req_no, 		process_name, 		component_name, 
					activity_name, 			guid, 				gen_xml,		seq_no)		
				values 
					(@engg_customer_name,	@engg_project_name, @engg_req_no,  	@process_name,	@engg_component,
					@activity_name,		@guid,
					'<EditControl Name="' 		+ ltrim(rtrim(isnull(@tmp_listcontrolsyn,'')))			+ '" ' +	
							'ControlName="'		+ ltrim(rtrim(isnull(@tmp_listcontrolid,''))) 			+ '" ' +					
							'PageName="'		+ ltrim(rtrim(isnull(@tmp_pagename,''))) 			+ '" ' +	
							'IlboName="'		+ UPPER(ltrim(rtrim(isnull(@ui_name_tmp,'')))) 			+ '" ' +	
							'ActivityName="'		+ UPPER(ltrim(rtrim(isnull(@activity_name,'')))) 			+ '" ' +
							'ComponentName="'		+ ltrim(rtrim(isnull(@engg_component,''))) 			+ '" ' +
							'SearchId="'		+ ltrim(rtrim(isnull(@tmp_queryid,''))) 			+ '" ' +
							'SearchContext="'		+ LOWER(ltrim(rtrim(isnull(@tmp_searchcontext,'')))) 			+ '" ' +
							'ListIndexSearch="'		+ ltrim(rtrim(isnull(@tmp_searchindex,0))) 			+ '" ' +
							'Position="'		+ ltrim(rtrim(isnull(@Position,0))) 			+ '" ' +
							'SelectColumn="'		+ LOWER(ltrim(rtrim(isnull(@tmp_selectcolumn,'')))) 			+ '" ' +
							'ResultColumn="'		+ ltrim(rtrim(isnull(@tmp_resultcolumn,''))) 	+ '"/>',@xml_seq_tmp)
					

		Fetch Next from eslist_cur into @tmp_listcontrolsyn,	@tmp_listcontrolid,	@tmp_listviewname,	@tmp_queryid,
							@tmp_searchindex,	@tmp_pagesize--,		@tmp_pagename
		
		end
		close eslist_cur
		deallocate eslist_cur
-- Added by JL elastic search TECH-45546 Ends

			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'</CustomList>',
				@xml_seq_tmp
				)

			--code added by kiruthika for bugid:PLF2.0_03710
			--Code added for completion charts
			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'<CompletionCharts>',
				@xml_seq_tmp
				)

			DECLARE compchart_curs INSENSITIVE CURSOR
			FOR
			SELECT upper(sec.section_bt_synonym),
				upper(val.control_bt_synonym),
				upper(con.control_bt_synonym),
				upper(fal.control_bt_synonym)
			FROM ep_ui_section_dtl sec(NOLOCK),
				ep_ui_control_dtl val(NOLOCK),
				ep_ui_control_dtl fal(NOLOCK),
				ep_ui_control_dtl con(NOLOCK)
			WHERE sec.customer_name = val.customer_name
				AND sec.project_name = val.project_name
				AND sec.req_no = val.req_no
				AND sec.process_name = val.process_name
				AND sec.component_name = val.component_name
				AND sec.activity_name = val.activity_name
				AND sec.ui_name = val.ui_name
				AND sec.page_bt_synonym = val.page_bt_synonym
				AND sec.section_bt_synonym = val.section_bt_synonym
				AND val.customer_name = fal.customer_name
				AND val.project_name = fal.project_name
				AND val.req_no = fal.req_no
				AND val.process_name = fal.process_name
				AND val.component_name = fal.component_name
				AND val.component_name = fal.component_name
				AND val.ui_name = fal.ui_name
				AND val.page_bt_synonym = fal.page_bt_synonym
				AND val.section_bt_synonym = fal.section_bt_synonym
				AND val.customer_name = con.customer_name
				AND val.project_name = con.project_name
				AND val.req_no = con.req_no
				AND val.process_name = con.process_name
				AND val.component_name = con.component_name
				AND val.component_name = con.component_name
				AND val.ui_name = con.ui_name
				AND val.page_bt_synonym = con.page_bt_synonym
				AND val.section_bt_synonym = con.section_bt_synonym
				AND sec.customer_name = @engg_customer_name
				AND sec.project_name = @engg_project_name
				AND sec.req_no = 'Base'
				AND sec.process_name = @process_name
				AND sec.component_name = @engg_component
				AND sec.activity_name = @activity_name
				AND sec.ui_name = @ui_name_tmp
				AND sec.section_type = 'Completion Chart'
				AND val.control_type IN (
					SELECT ctrl_type_name
					FROM es_comp_ctrl_type_mst(NOLOCK)
					WHERE config_value = 'Y'
						AND editable_flag = 'Y'
						AND customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @process_name
						AND component_name = @engg_component
					)
				AND fal.control_type IN (
					SELECT ctrl_type_name
					FROM es_comp_ctrl_type_mst(NOLOCK)
					WHERE isfallback = 'Y'
						AND editable_flag = 'Y'
						AND customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @process_name
						AND component_name = @engg_component
					)
				AND con.control_type IN (
					SELECT ctrl_type_name
					FROM es_comp_ctrl_type_mst(NOLOCK)
					WHERE config_parameter = 'Y'
						AND editable_flag = 'Y'
						AND customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @process_name
						AND component_name = @engg_component
					)
			ORDER BY sec.horder,
				sec.vorder

			-- declare temporary variables
			DECLARE @section_bt_synonym_chart engg_name
			DECLARE @chart_value engg_values
			DECLARE @chart_configuration engg_values
			DECLARE @chart_fallback engg_values

			OPEN compchart_curs

			WHILE (1 = 1)
			BEGIN
				FETCH NEXT
				FROM compchart_curs
				INTO @section_bt_synonym_chart,
					@chart_value,
					@chart_configuration,
					@chart_fallback

				IF @@fetch_status <> 0
					BREAK

				SELECT @xml_seq_tmp = @xml_seq_tmp + 1

				INSERT INTO ep_genxml_tmp (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					activity_name,
					guid,
					gen_xml,
					seq_no
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@process_name,
					@engg_component,
					@activity_name,
					@guid,
					'<Section Name="' + ltrim(rtrim(isnull(@section_bt_synonym_chart, ''))) + '" ' + 'Values="' + ltrim(rtrim(isnull(@chart_value, ''))) + '" ' + 'Configuration="' + ltrim(rtrim(isnull(@chart_configuration, ''))) + '" ' + 'Fallback="' + ltrim(rtrim(isnull(@chart_fallback, ''))) + '"/>',
					@xml_seq_tmp
					)
			END

			CLOSE compchart_curs

			DEALLOCATE compchart_curs

			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'</CompletionCharts>',
				@xml_seq_tmp
				)

			--Code added for Inplace videos
			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'<InplaceVideos>',
				@xml_seq_tmp
				)

			DECLARE inplacevid_curs INSENSITIVE CURSOR
			FOR
			SELECT upper(sec.section_bt_synonym),
				upper(con.control_bt_synonym),
				upper(val.control_bt_synonym),
				upper(fal.control_bt_synonym)
			FROM ep_ui_section_dtl sec(NOLOCK),
				ep_ui_control_dtl val(NOLOCK),
				ep_ui_control_dtl fal(NOLOCK),
				ep_ui_control_dtl con(NOLOCK)
			WHERE sec.customer_name = val.customer_name
				AND sec.project_name = val.project_name
				AND sec.req_no = val.req_no
				AND sec.process_name = val.process_name
				AND sec.component_name = val.component_name
				AND sec.activity_name = val.activity_name
				AND sec.ui_name = val.ui_name
				AND sec.page_bt_synonym = val.page_bt_synonym
				AND sec.section_bt_synonym = val.section_bt_synonym
				AND val.customer_name = fal.customer_name
				AND val.project_name = fal.project_name
				AND val.req_no = fal.req_no
				AND val.process_name = fal.process_name
				AND val.component_name = fal.component_name
				AND val.component_name = fal.component_name
				AND val.ui_name = fal.ui_name
				AND val.page_bt_synonym = fal.page_bt_synonym
				AND val.section_bt_synonym = fal.section_bt_synonym
				AND val.customer_name = con.customer_name
				AND val.project_name = con.project_name
				AND val.req_no = con.req_no
				AND val.process_name = con.process_name
				AND val.component_name = con.component_name
				AND val.component_name = con.component_name
				AND val.ui_name = con.ui_name
				AND val.page_bt_synonym = con.page_bt_synonym
				AND val.section_bt_synonym = con.section_bt_synonym
				AND sec.customer_name = @engg_customer_name
				AND sec.project_name = @engg_project_name
				AND sec.req_no = 'Base'
				AND sec.process_name = @process_name
				AND sec.component_name = @engg_component
				AND sec.activity_name = @activity_name
				AND sec.ui_name = @ui_name_tmp
				AND sec.section_type = 'Inplace Video'
				AND con.control_type IN (
					SELECT ctrl_type_name
					FROM es_comp_ctrl_type_mst(NOLOCK)
					WHERE base_ctrl_type = 'Link'
						AND customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @process_name
						AND component_name = @engg_component
					)
				AND val.control_type IN (
					SELECT ctrl_type_name
					FROM es_comp_ctrl_type_mst(NOLOCK)
					WHERE config_parameter = 'Y'
						AND editable_flag = 'Y'
						AND customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @process_name
						AND component_name = @engg_component
					)
				AND fal.control_type IN (
					SELECT ctrl_type_name
					FROM es_comp_ctrl_type_mst(NOLOCK)
					WHERE isfallback = 'Y'
						AND editable_flag = 'Y'
						AND customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @process_name
						AND component_name = @engg_component
					)
			ORDER BY sec.horder,
				sec.vorder

			-- declare temporary variables
			DECLARE @section_bt_synonym_video engg_name
			DECLARE @video_value engg_values
			DECLARE @video_configuration engg_values
			DECLARE @video_fallback engg_values

			OPEN inplacevid_curs

			WHILE (1 = 1)
			BEGIN
				FETCH NEXT
				FROM inplacevid_curs
				INTO @section_bt_synonym_video,
					@video_value,
					@video_configuration,
					@video_fallback

				IF @@fetch_status <> 0
					BREAK

				SELECT @xml_seq_tmp = @xml_seq_tmp + 1

				INSERT INTO ep_genxml_tmp (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					activity_name,
					guid,
					gen_xml,
					seq_no
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@process_name,
					@engg_component,
					@activity_name,
					@guid,
					'<Section Name="' + ltrim(rtrim(isnull(@section_bt_synonym_video, ''))) + '" ' + 'Values="' + ltrim(rtrim(isnull(@video_value, ''))) + '" ' + 'Configuration="' + ltrim(rtrim(isnull(@video_configuration, ''))) + '" ' + 'Fallback="' + ltrim(rtrim(isnull(@video_fallback, ''))) + '"/>',
					@xml_seq_tmp
					)
			END

			CLOSE inplacevid_curs

			DEALLOCATE inplacevid_curs

			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'</InplaceVideos>',
				@xml_seq_tmp
				)

			--Code added for Datagrid
			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'<DataGrid>',
				@xml_seq_tmp
				)

			DECLARE datagrid_curs INSENSITIVE CURSOR
			FOR
			SELECT isnull(upper(ctrl.control_id), ''),
				isnull(upper(MoveFirst), 'N'),
				isnull(upper(Move_PrevSet), 'N'),
				isnull(upper(Move_Previous), 'N'),
				isnull(upper(Move_Next), 'N'),
				isnull(upper(Move_NextSet), 'N'),
				isnull(upper(Move_Last), 'N'),
				isnull(upper(Carousel_Req), 'N'),
				isnull(upper(Orientation), ''),
				isnull(upper(WrapCount), ''),
				isnull(upper(Box_Type), '')
			FROM ep_ui_control_dtl ctrl(NOLOCK),
				es_comp_ctrl_type_mst_vw ctype(NOLOCK)
			WHERE ctrl.customer_name = ctype.customer_name
				AND ctrl.project_name = ctype.project_name
				AND ctrl.process_name = ctype.process_name
				AND ctrl.component_name = ctype.component_name
				AND ctrl.control_type = ctype.ctrl_type_name
				AND ctrl.customer_name = @engg_customer_name
				AND ctrl.project_name = @engg_project_name
				--and  ctrl.req_no    =  @engg_req_no Code commented by Ganesh for the case id TECH-14021
				AND ctrl.process_name = @process_name
				AND ctrl.component_name = @engg_component
				AND ctrl.activity_name = @activity_name
				AND ctrl.ui_name = @ui_name_tmp
				AND ctype.Datagrid = 'Y'

			OPEN datagrid_curs

			WHILE (1 = 1)
			BEGIN
				FETCH NEXT
				FROM datagrid_curs
				INTO @controlid_tmp,
					@MoveFirst,
					@Move_PrevSet,
					@Move_Previous,
					@Move_Next,
					@Move_NextSet,
					@Move_Last,
					@Carousel_Req,
					@Orientation,
					@Wrapcount,
					@Box_Type

				IF @@fetch_status <> 0
					BREAK

				SELECT @colname = ''

				SELECT @colname = isnull(upper(col.view_name), '')
				FROM ep_ui_grid_dtl col(NOLOCK)
				WHERE col.customer_name = @engg_customer_name
					AND col.project_name = @engg_project_name
					--and  col.req_no    =  @engg_req_no
					AND col.process_name = @process_name
					AND col.component_name = @engg_component
					AND col.activity_name = @activity_name
					AND col.ui_name = @ui_name_tmp
					AND col.control_id = @controlid_tmp
					AND col.visible = 'yes'

				SELECT @RowIndicator = isnull(upper(ctrl.control_id), '')
				FROM ep_ui_control_dtl ctrl(NOLOCK)
				WHERE ctrl.customer_name = @engg_customer_name
					AND ctrl.project_name = @engg_project_name
					AND ctrl.process_name = @process_name
					AND ctrl.component_name = @engg_component
					AND ctrl.activity_name = @activity_name
					AND ctrl.ui_name = @ui_name_tmp
					AND ctrl.section_bt_synonym = @dg_section_bt_synonym
					AND ctrl.control_id <> @controlid_tmp

				SELECT @xml_seq_tmp = @xml_seq_tmp + 1

				INSERT INTO ep_genxml_tmp (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					activity_name,
					guid,
					gen_xml,
					seq_no
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@process_name,
					@engg_component,
					@activity_name,
					@guid,
					'<Control Name="' + ltrim(rtrim(isnull(@controlid_tmp, ''))) + '" ' + 'DvOrientation="' + isnull(@Orientation, '') + '" ' + 'DvColname="' + isnull(cast(@colname AS VARCHAR(100)), '') + '" ' + 'DvWrapcount="' + isnull(cast(@wrapcount AS VARCHAR(100)),
 '') + '" ' + 'DvBoxtype="' + isnull(cast(@Box_Type AS VARCHAR(100)), '') + '" ' + 'IsMovefirst="' + isnull(@MoveFirst, 'N') + '" ' + 'IsMoveprevset="' + isnull(@Move_PrevSet, 'N') + '" ' + 'IsMoveprev="' + isnull(@Move_Previous, 'N') + '" ' + 'IsMovenext
="' + isnull(@Move_Next, 'N') + '" ' + 'IsMovenextset="' + isnull(@Move_NextSet, 'N') + '" ' + 'IsMovelast="' + isnull(@Move_Last, 'N') + '" ' + 'IsCarouselreq="' + isnull(@Carousel_Req, 'N') + '" ' + 'RowIndicator="' + isnull(@RowIndicator, '') + '" />',

					@xml_seq_tmp
					)
			END

			CLOSE datagrid_curs

			DEALLOCATE datagrid_curs

			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'</DataGrid>',
				@xml_seq_tmp
				)

			-- Code Added By Jeya for the Bug ID PNR2.0_19279 Starts
			--Code commented for TECH-75230
			--SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			--INSERT INTO ep_genxml_tmp (
			--	customer_name,
			--	project_name,
			--	req_no,
			--	process_name,
			--	component_name,
			--	activity_name,
			--	guid,
			--	gen_xml,
			--	seq_no
			--	)
			--VALUES (
			--	@engg_customer_name,
			--	@engg_project_name,
			--	@engg_req_no,
			--	@process_name,
			--	@engg_component,
			--	@activity_name,
			--	@guid,
			--	'<Trees>',
			--	@xml_seq_tmp
			--	)
			--Code commented for TECH-75230

			DECLARE TreesCur INSENSITIVE CURSOR
			FOR
			SELECT DISTINCT upper(section_bt_synonym),
				upper(section_bt_synonym),
				upper(page_bt_synonym),
				CheckboxRequired,
				linesRequired
			FROM ep_tree_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @process_name
				AND component_name = @engg_component
				AND activity_name = @activity_name
				AND ui_name = @ui_name_tmp

			--and  page_bt_synonym  = @page_bt_synonym_tmp
			--and  mapped_task =  @task_name_tmp
			DECLARE @tree_id engg_name
			DECLARE @tree_section engg_name
			DECLARE @tree_page engg_name
			DECLARE @tree_chk engg_name
			DECLARE @tree_lines engg_name
			DECLARE @tree_hdnctrl engg_name
			DECLARE @node_type engg_name
			DECLARE @node_Eventreq engg_name
			DECLARE @node_task engg_name

			OPEN TreesCur

			-- For each control generate entries
			WHILE (1 = 1)
			BEGIN
				FETCH NEXT
				FROM TreesCur
				INTO @tree_id,
					@tree_section,
					@tree_page,
					@tree_chk,
					@tree_lines

				IF @@fetch_status <> 0
					BREAK

				SELECT @tree_hdnctrl = c.control_bt_synonym
				FROM ep_ui_section_dtl a(NOLOCK),
					ep_ui_control_dtl c(NOLOCK)
				WHERE a.customer_name = @engg_customer_name
					AND a.project_name = @engg_project_name
					AND a.process_name = @process_name
					AND a.component_name = @engg_component
					AND a.activity_name = @activity_name
					AND a.ui_name = @ui_name_tmp
					AND a.page_bt_synonym = @tree_page
					AND a.section_bt_synonym = @tree_section
					AND a.section_type = 'Tree'
					AND a.customer_name = c.customer_name
					AND a.project_name = c.project_name
					AND a.process_name = c.process_name
					AND a.component_name = c.component_name
					AND a.activity_name = c.activity_name
					AND a.ui_name = c.ui_name
					AND a.page_bt_synonym = c.page_bt_synonym
					AND a.section_bt_synonym = c.section_bt_synonym

				IF isnull(@tree_chk, '') = ''
					OR @tree_chk = '0'
					SELECT @tree_chk = 'N'
				ELSE
					SELECT @tree_chk = 'Y'

				IF isnull(@tree_lines, '') = ''
					OR @tree_lines = '0'
					SELECT @tree_lines = 'N'
				ELSE
					SELECT @tree_lines = 'Y'

				INSERT INTO ep_genxml_tmp (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					activity_name,
					guid,
					gen_xml,
					seq_no
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@process_name,
					@engg_component,
					@activity_name,
					@guid,
					'<Tree Id="' + ltrim(rtrim(isnull(@tree_id, ''))) + '" ' + 'SectionName="' + ltrim(rtrim(isnull(@tree_section, ''))) + '" ' + 'PageName="' + ltrim(rtrim(isnull(@tree_page, ''))) + '" ' + 'CheckReq="' + ltrim(rtrim(isnull(@tree_chk, ''))) + '" ' + 'LinesRequired="' + ltrim(rtrim(isnull(@tree_lines, ''))) + '" ' + 'HiddenControl="' + ltrim(rtrim(isnull(@tree_hdnctrl, ''))) + '">',
					@xml_seq_tmp
					)

				SELECT @xml_seq_tmp = @xml_seq_tmp + 1

				INSERT INTO ep_genxml_tmp (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					activity_name,
					guid,
					gen_xml,
					seq_no
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@process_name,
					@engg_component,
					@activity_name,
					@guid,
					'<nts>',
					@xml_seq_tmp
					)

				DECLARE NodesCur INSENSITIVE CURSOR
				FOR
				SELECT DISTINCT upper(node_type),
					event_req,
					upper(mapped_task),
					ExpandImageEvent
				FROM ep_tree_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @process_name
					AND component_name = @engg_component
					AND activity_name = @activity_name
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = @page_bt_synonym_tmp
					AND section_bt_synonym = @tree_section
					AND event_req IN (
						'Y',
						'1'
						)

				OPEN NodesCur

				-- For each control generate entries
				WHILE (1 = 1)
				BEGIN
					FETCH NEXT
					FROM NodesCur
					INTO @node_type,
						@node_Eventreq,
						@node_task,
						@ExpandImageEvent

					IF @@fetch_status <> 0
						BREAK

					IF isnull(@node_Eventreq, '') = ''
						OR @node_Eventreq = '0'
						SELECT @node_Eventreq = 'N'
					ELSE
						SELECT @node_Eventreq = 'Y'

					--if @node_task = '--NOACTION--' Code modified for BugID:PNR2.0_33556
					-- select @node_task = ''   Code modified for BugID:PNR2.0_33556
					--Code added for BugID:PNR2.0_33556 starts
					IF @node_task = '--NOACTION--'
						AND @node_Eventreq = 'Y'
					BEGIN
						SELECT DISTINCT @node_task = a.task_name
						FROM ep_action_mst a(NOLOCK),
							ep_ui_control_dtl b(NOLOCK),
							ep_ui_section_dtl c(NOLOCK)
						WHERE c.customer_name = @engg_customer_name
							AND c.project_name = @engg_project_name
							AND c.process_name = @process_name
							AND c.component_name = @engg_component
							AND c.activity_name = @activity_name
							AND c.ui_name = @ui_name_tmp
							AND c.page_bt_synonym = @page_bt_synonym_tmp
							AND c.section_bt_synonym = @tree_section
							AND c.section_type = 'Tree'
							AND b.customer_name = c.customer_name
							AND b.project_name = c.project_name
							AND b.process_name = c.process_name
							AND b.component_name = c.component_name
							AND b.activity_name = c.activity_name
							AND b.ui_name = c.ui_name
							AND b.section_bt_synonym = c.section_bt_synonym
							AND a.primary_control_bts = b.control_bt_synonym
							AND a.customer_name = b.customer_name
							AND a.project_name = b.project_name
							AND a.process_name = b.process_name
							AND a.component_name = b.component_name
							AND a.activity_name = b.activity_name
							AND a.ui_name = b.ui_name
					END
					ELSE
					BEGIN
						SELECT @node_task = ''
					END

					--Code added for BugID:PNR2.0_33556 ends
					INSERT INTO ep_genxml_tmp (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						activity_name,
						guid,
						gen_xml,
						seq_no
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@engg_req_no,
						@process_name,
						@engg_component,
						@activity_name,
						@guid,
						'<nt Name="' + ltrim(rtrim(isnull(@node_type, ''))) + '" ' + 'EventRequired="' + ltrim(rtrim(isnull(@node_Eventreq, ''))) + '" ' + 'ExpandImageEvent="' + ltrim(rtrim(isnull(@ExpandImageEvent, ''))) + '" ' + 'MappedTask="' + ltrim(rtrim(isnull(@node_task, ''))) + '"/>',
						@xml_seq_tmp
						)
				END

				CLOSE NodesCur

				DEALLOCATE NodesCur

				SELECT @xml_seq_tmp = @xml_seq_tmp + 1

				INSERT INTO ep_genxml_tmp (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					activity_name,
					guid,
					gen_xml,
					seq_no
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@process_name,
					@engg_component,
					@activity_name,
					@guid,
					'</nts>',
					@xml_seq_tmp
					)

				SELECT @xml_seq_tmp = @xml_seq_tmp + 1

				INSERT INTO ep_genxml_tmp (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					activity_name,
					guid,
					gen_xml,
					seq_no
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@process_name,
					@engg_component,
					@activity_name,
					@guid,
					'</Tree>',
					@xml_seq_tmp
					)
			END

			CLOSE TreesCur

			DEALLOCATE TreesCur

			/* select @xml_seq_tmp=@xml_seq_tmp+1  -- 11537 starts
insert into ep_genxml_tmp
(customer_name,   project_name,   req_no,   process_name,   component_name,
activity_name,    guid,    gen_xml,seq_no)
values
(@engg_customer_name, @engg_project_name, @engg_req_no,   @process_name, @engg_component,
@activity_name,   @guid,    '</Trees>',@xml_seq_tmp)
 */-- 11537 Ends
			-- Code Added By Jeya for the Bug ID PNR2.0_19279 Ends
			-- For Tree Node xml
			EXEC ep_genenrate_treexml @engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@ui_name_tmp,
				@xml_seq_tmp,
				@guid,
				@pubflag,
				@xml_tree_seq OUTPUT

			SELECT @xml_seq_tmp = @xml_tree_seq

			-- For Chart xml
			EXEC ep_genenrate_chartxml @engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@ui_name_tmp,
				@xml_seq_tmp,
				@guid,
				@pubflag,
				@xml_tree_seq OUTPUT

			SELECT @xml_seq_tmp = @xml_tree_seq

			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'<UserSections>',
				@xml_seq_tmp
				)

			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'<BrowserContent>',
				@xml_seq_tmp
				)

			DECLARE @include_value engg_name,
				@include_text VARCHAR(max),
				@usersection_name engg_name

			DECLARE htmlattrcur CURSOR
			FOR
			SELECT DISTINCT section_bt_synonym,
				include_value,
				include_text
			FROM ep_user_section_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @process_name
				AND component_name = @engg_component
				AND activity_name = @activity_name
				AND ui_name = @ui_name_tmp

			OPEN htmlattrcur

			WHILE (1 = 1)
			BEGIN
				FETCH NEXT
				FROM htmlattrcur
				INTO @usersection_name,
					@include_value,
					@include_text

				IF @@fetch_status <> 0
					BREAK

				IF @include_value = 'HTML Onload'
				BEGIN
					SELECT @xml_seq_tmp = @xml_seq_tmp + 1

					INSERT INTO ep_genxml_tmp (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						activity_name,
						guid,
						gen_xml,
						seq_no
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@engg_req_no,
						@process_name,
						@engg_component,
						@activity_name,
						@guid,
						'<HTMLOnload>',
						@xml_seq_tmp
						)

					SELECT @xml_seq_tmp = @xml_seq_tmp + 1

					INSERT INTO ep_genxml_tmp (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						activity_name,
						guid,
						gen_xml,
						seq_no
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@engg_req_no,
						@process_name,
						@engg_component,
						@activity_name,
						@guid,
						'<![CDATA[' + ltrim(rtrim(isnull(@include_text, ''))) + ']]>',
						@xml_seq_tmp
						)

					SELECT @xml_seq_tmp = @xml_seq_tmp + 1

					INSERT INTO ep_genxml_tmp (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						activity_name,
						guid,
						gen_xml,
						seq_no
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@engg_req_no,
						@process_name,
						@engg_component,
						@activity_name,
						@guid,
						'</HTMLOnload>',
						@xml_seq_tmp
						)
				END

				IF @include_value = 'HTML Body Content'
				BEGIN
					SELECT @xml_seq_tmp = @xml_seq_tmp + 1

					INSERT INTO ep_genxml_tmp (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						activity_name,
						guid,
						gen_xml,
						seq_no
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@engg_req_no,
						@process_name,
						@engg_component,
						@activity_name,
						@guid,
						'<HTMLBodyContent>',
						@xml_seq_tmp
						)

					SELECT @xml_seq_tmp = @xml_seq_tmp + 1

					INSERT INTO ep_genxml_tmp (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						activity_name,
						guid,
						gen_xml,
						seq_no
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@engg_req_no,
						@process_name,
						@engg_component,
						@activity_name,
						@guid,
						'<![CDATA[' + ltrim(rtrim(isnull(@include_text, ''))) + ']]>',
						@xml_seq_tmp
						)

					SELECT @xml_seq_tmp = @xml_seq_tmp + 1

					INSERT INTO ep_genxml_tmp (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						activity_name,
						guid,
						gen_xml,
						seq_no
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@engg_req_no,
						@process_name,
						@engg_component,
						@activity_name,
						@guid,
						'</HTMLBodyContent>',
						@xml_seq_tmp
						)
				END

				IF @include_value = 'HTML JavaScript'
				BEGIN
					SELECT @xml_seq_tmp = @xml_seq_tmp + 1

					INSERT INTO ep_genxml_tmp (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						activity_name,
						guid,
						gen_xml,
						seq_no
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@engg_req_no,
						@process_name,
						@engg_component,
						@activity_name,
						@guid,
						'<HTMLJavaScript>',
						@xml_seq_tmp
						)

					SELECT @xml_seq_tmp = @xml_seq_tmp + 1

					INSERT INTO ep_genxml_tmp (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						activity_name,
						guid,
						gen_xml,
						seq_no
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@engg_req_no,
						@process_name,
						@engg_component,
						@activity_name,
						@guid,
						'<![CDATA[' + ltrim(rtrim(isnull(@include_text, ''))) + ']]>',
						@xml_seq_tmp
						)

					SELECT @xml_seq_tmp = @xml_seq_tmp + 1

					INSERT INTO ep_genxml_tmp (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						activity_name,
						guid,
						gen_xml,
						seq_no
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@engg_req_no,
						@process_name,
						@engg_component,
						@activity_name,
						@guid,
						'</HTMLJavaScript>',
						@xml_seq_tmp
						)
				END

				IF @include_value = 'HTML JavaScript Before'
				BEGIN
					SELECT @xml_seq_tmp = @xml_seq_tmp + 1

					INSERT INTO ep_genxml_tmp (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						activity_name,
						guid,
						gen_xml,
						seq_no
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@engg_req_no,
						@process_name,
						@engg_component,
						@activity_name,
						@guid,
						'<HTMLJavaScriptBefore>',
						@xml_seq_tmp
						)

					SELECT @xml_seq_tmp = @xml_seq_tmp + 1

					INSERT INTO ep_genxml_tmp (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						activity_name,
						guid,
						gen_xml,
						seq_no
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@engg_req_no,
						@process_name,
						@engg_component,
						@activity_name,
						@guid,
						'<![CDATA[' + ltrim(rtrim(isnull(@include_text, ''))) + ']]>',
						@xml_seq_tmp
						)

					SELECT @xml_seq_tmp = @xml_seq_tmp + 1

					INSERT INTO ep_genxml_tmp (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						activity_name,
						guid,
						gen_xml,
						seq_no
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@engg_req_no,
						@process_name,
						@engg_component,
						@activity_name,
						@guid,
						'</HTMLJavaScriptBefore>',
						@xml_seq_tmp
						)
				END

				IF @include_value = 'HTML CSS'
				BEGIN
					SELECT @xml_seq_tmp = @xml_seq_tmp + 1

					INSERT INTO ep_genxml_tmp (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						activity_name,
						guid,
						gen_xml,
						seq_no
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@engg_req_no,
						@process_name,
						@engg_component,
						@activity_name,
						@guid,
						'<HTMLCSS>',
						@xml_seq_tmp
						)

					SELECT @xml_seq_tmp = @xml_seq_tmp + 1

					INSERT INTO ep_genxml_tmp (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						activity_name,
						guid,
						gen_xml,
						seq_no
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@engg_req_no,
						@process_name,
						@engg_component,
						@activity_name,
						@guid,
						'<![CDATA[' + ltrim(rtrim(isnull(@include_text, ''))) + ']]>',
						@xml_seq_tmp
						)

					SELECT @xml_seq_tmp = @xml_seq_tmp + 1

					INSERT INTO ep_genxml_tmp (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						activity_name,
						guid,
						gen_xml,
						seq_no
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@engg_req_no,
						@process_name,
						@engg_component,
						@activity_name,
						@guid,
						'</HTMLCSS>',
						@xml_seq_tmp
						)
				END

				IF @include_value = 'HTML Content'
				BEGIN
					SELECT @xml_seq_tmp = @xml_seq_tmp + 1

					INSERT INTO ep_genxml_tmp (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						activity_name,
						guid,
						gen_xml,
						seq_no
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@engg_req_no,
						@process_name,
						@engg_component,
						@activity_name,
						@guid,
						'<Section Name="' + ltrim(rtrim(isnull(upper(@usersection_name), ''))) + '">',
						@xml_seq_tmp
						)

					SELECT @xml_seq_tmp = @xml_seq_tmp + 1

					INSERT INTO ep_genxml_tmp (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						activity_name,
						guid,
						gen_xml,
						seq_no
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@engg_req_no,
						@process_name,
						@engg_component,
						@activity_name,
						@guid,
						'<HTMLContent>',
						@xml_seq_tmp
						)

					IF @include_value = 'HTML Content'
					BEGIN
						SELECT @xml_seq_tmp = @xml_seq_tmp + 1

						INSERT INTO ep_genxml_tmp (
							customer_name,
							project_name,
							req_no,
							process_name,
							component_name,
							activity_name,
							guid,
							gen_xml,
							seq_no
							)
						VALUES (
							@engg_customer_name,
							@engg_project_name,
							@engg_req_no,
							@process_name,
							@engg_component,
							@activity_name,
							@guid,
							'<![CDATA[' + ltrim(rtrim(isnull(@include_text, ''))) + ']]>',
							@xml_seq_tmp
							)
					END

					SELECT @xml_seq_tmp = @xml_seq_tmp + 1

					INSERT INTO ep_genxml_tmp (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						activity_name,
						guid,
						gen_xml,
						seq_no
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@engg_req_no,
						@process_name,
						@engg_component,
						@activity_name,
						@guid,
						'</HTMLContent>',
						@xml_seq_tmp
						)

					SELECT @xml_seq_tmp = @xml_seq_tmp + 1

					INSERT INTO ep_genxml_tmp (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						activity_name,
						guid,
						gen_xml,
						seq_no
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@engg_req_no,
						@process_name,
						@engg_component,
						@activity_name,
						@guid,
						'</Section>',
						@xml_seq_tmp
						)
				END
			END

			CLOSE htmlattrcur

			DEALLOCATE htmlattrcur

			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'</BrowserContent>',
				@xml_seq_tmp
				)

			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'</UserSections>',
				@xml_seq_tmp
				)

			------------------- Inner Sp
			--DECLARE @xml_seq_tmp_out INT

			IF EXISTS (
					SELECT 'X'
					FROM sys.columns
					WHERE name = 'preventdownload'
					)
			BEGIN
				EXEC ep_ui_extended_properties @engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@process_name,
					@engg_component,
					@activity_name,
					@ui_name_tmp,
					@language_code,
					@guid,
					@xml_seq_tmp,
					@xml_seq_tmp_out OUTPUT

				SET @xml_seq_tmp = @xml_seq_tmp_out
			END

			---------------
			-- Insert Closing entry for ILBO
			SELECT @xml_seq_tmp = @xml_seq_tmp + 1

			INSERT INTO ep_genxml_tmp (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				guid,
				gen_xml,
				seq_no
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_req_no,
				@process_name,
				@engg_component,
				@activity_name,
				@guid,
				'</ILBO>',
				@xml_seq_tmp
				)

			DROP TABLE #maplist -- code added by Gopinath S for the Call ID PNR2.0_25510

			Drop table #AlignBtn -- 11537 TECH-47379

		END

		CLOSE uicurs

		DEALLOCATE uicurs

		-- Insert Closing entry for ILBOs
		SELECT @xml_seq_tmp = @xml_seq_tmp + 1

		INSERT INTO ep_genxml_tmp (
			customer_name,
			project_name,
			req_no,
			process_name,
			component_name,
			activity_name,
			guid,
			gen_xml,
			seq_no
			)
		VALUES (
			@engg_customer_name,
			@engg_project_name,
			@engg_req_no,
			@process_name,
			@engg_component,
			@activity_name,
			@guid,
			'</ILBOs>',
			@xml_seq_tmp
			)

		-- Insert Closing entry for Activity
		SELECT @xml_seq_tmp = @xml_seq_tmp + 1

		INSERT INTO ep_genxml_tmp (
			customer_name,
			project_name,
			req_no,
			process_name,
			component_name,
			activity_name,
			guid,
			gen_xml,
			seq_no
			)
		VALUES (
			@engg_customer_name,
			@engg_project_name,
			@engg_req_no,
			@process_name,
			@engg_component,
			@activity_name,
			@guid,
			'</Activity>',
			@xml_seq_tmp
			)
	END

	CLOSE actcurs

	DEALLOCATE actcurs

	-- Insert Closing Root entry
	SELECT @xml_seq_tmp = @xml_seq_tmp + 1

	INSERT INTO ep_genxml_tmp (
		customer_name,
		project_name,
		req_no,
		process_name,
		component_name,
		activity_name,
		guid,
		gen_xml,
		seq_no
		)
	VALUES (
		@engg_customer_name,
		@engg_project_name,
		@engg_req_no,
		@process_name,
		@engg_component,
		@activity_name,
		@guid,
		'</Activities>',
		@xml_seq_tmp
		)

	IF @ctxt_service_in = 'BulkGenerate'
	BEGIN
		SELECT 'engg_genxml' = gen_xml
		FROM ep_genxml_tmp(NOLOCK)
		WHERE guid = @guid
		ORDER BY seq_no

		DELETE ep_genxml_tmp
		WHERE guid = @guid

		DELETE ep_section_hierarchy
		WHERE guid = @guid
	END
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME= 'ep_generate_uixml' AND TYPE='P')
BEGIN
	GRANT EXEC ON  ep_generate_uixml TO PUBLIC
END
GO  


