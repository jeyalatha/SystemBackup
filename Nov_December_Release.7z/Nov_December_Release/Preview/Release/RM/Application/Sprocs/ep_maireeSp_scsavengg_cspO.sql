IF EXISTS  (SELECT 'X' FROM SYSOBJECTS WHERE NAME ='ep_maireeSp_scsavengg_cspO' AND TYPE = 'P')
    BEGIN
        DROP PROC ep_maireeSp_scsavengg_cspO
    END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		ep_maireeSp_scsavengg_cspO.sql
********************************************************************************/
/********************************************************************************/
/* Procedure    : ep_maireeSp_scsavengg_cspO                                    */
/* Description  :                                                               */
/********************************************************************************/
/* Project      :                                                               */
/* ECR          :                                                               */
/* Version      :                                                               */
/********************************************************************************/
/* Referenced   :                                                               */
/* Tables       :                                                               */
/********************************************************************************/
/* Development history                                                          */
/********************************************************************************/
/* Author       : Model Explorer                                                */
/* Date         : 23/Sep/2005                                                   */
/********************************************************************************/
/* Modification history                                                         */
/********************************************************************************/
/* modified by  : Balaji S For BugId : PNR2.0_6270                             */
/* date         : 14-feb-2006                                                 */
/* description  : Tree sections must not get loaded in the section combo  */
/********************************************************************************/
/* modified by  : Sivakumar S For BugId : PNR2.0_14785         */
/* date         : 03-AUG-2007                */
/* description  :   In Section Layout tab,Controls Order sequence needs to be changed.*/
/**************************************************************************************/
/* modified by   : Feroz           */
/* date     : 25-nov-2008         */
/* BugId    : PNR2.0_1790          */
/************************************************************************/
/* modified by  : Muthupandi S              */
/* date         : 21-July-2011              */
/* Bug ID : PNR2.0_32496                      */
/* Description : To avoid fetching controls  to the ML in specify layout ,   */
/*   under the following sections "PrjHdnSection','[tabcontrol]'     */
/*   and  'hdnrt_stsection'              */
/*************************************************************************************/
/* modified by  : Piranava T  			                                        */
/* date         : Oct 10 2014			                                        */
/* BugId        : PLF2.0_09035 			                                        */
/* description  : Model changes for rowspan,colspan,IsStatic,IsCallout inß layout level */
/************************************************************************************/
/* Modified by  : Veena U                                                  */
/* Date         : 25-Feb-2015                                                  */
/* Call ID		: PLF2.0_11499                                                 */
/********************************************************************************/
/* Modified by  : Kalidas S	                                                  */
/* Date         : 03-Aug-2015                                                  */
/* Defect ID	: PLF2.0_14096                                                 */
/********************************************************************************/
/* modified by			Date				Defect ID							*/
/* Veena U				08-Jun-2016			PLF2.0_18487						*/
/********************************************************************************/
/* Modified by    :    Ponmalar A                                               */
/* Modified on    :    02/12/22													*/
/* Defect ID      :    TECH-75230												*/
/* Description    : Platform Release for the Month of Nov'22				    */
/********************************************************************************/
CREATE PROCEDURE ep_maireeSp_scsavengg_cspO
	@ctxt_ouinstance engg_ctxt_ouinstance, --Input
	@ctxt_user engg_ctxt_user, --Input
	@ctxt_language engg_ctxt_language, --Input
	@ctxt_service engg_ctxt_service, --Input
	@engg_act_descr ENGG_DESCRIPTION, --Input
	@engg_component engg_description, --Input
	@engg_cont_page_bts engg_name, --Input
	@engg_cont_sec_bts engg_name, --Input
	@engg_customer_name engg_name, --Input
	@engg_enum_page_bts engg_name, --Input
	@engg_enum_sec_bts engg_name, --Input
	@engg_grid_page_bts engg_name, --Input
	@engg_grid_sec_bts engg_name, --Input
	@engg_lay_page_bts engg_name, --Input
	@engg_process_descr engg_description, --Input
	@engg_project_name engg_name, --Input
	@engg_radio_page_bts engg_name, --Input
	@engg_radio_sec_bts engg_name, --Input
	@engg_req_no engg_name, --Input
	@engg_rf_act engg_description, --Input
	@engg_rf_comp engg_description, --Input
	@engg_rf_ui engg_description, --Input
	@engg_sec_page_bts engg_name, --Input
	@engg_ui_descr engg_description, --Input
	@engg_ui_xml engg_documentation, --Input
	@hdncustomer engg_name, --Input
	@hdnproject engg_name, --Input
	@engg_c_fprowno engg_rowno, --Input/Output
	@engg_y_fprowno engg_rowno, --Input/Output
	@_sec_fprowno engg_rowno, --Input/Output
	@m_errorid Engg_Seqno OUTPUT --To Return Execution Status
AS
BEGIN
	-- nocount should be switched on to prevent phantom rows
	SET NOCOUNT ON
	-- @m_errorid should be 0 to Indicate Success
	SET @m_errorid = 0
	--declaration of temporary variables
	--temporary and formal parameters mapping
	SET @ctxt_user = ltrim(rtrim(@ctxt_user))
	SET @ctxt_service = ltrim(rtrim(@ctxt_service))
	SET @engg_act_descr = ltrim(rtrim(@engg_act_descr))
	SET @engg_component = ltrim(rtrim(@engg_component))
	SET @engg_cont_page_bts = ltrim(rtrim(@engg_cont_page_bts))
	SET @engg_cont_sec_bts = ltrim(rtrim(@engg_cont_sec_bts))
	SET @engg_customer_name = ltrim(rtrim(@engg_customer_name))
	SET @engg_enum_page_bts = ltrim(rtrim(@engg_enum_page_bts))
	SET @engg_enum_sec_bts = ltrim(rtrim(@engg_enum_sec_bts))
	SET @engg_grid_page_bts = ltrim(rtrim(@engg_grid_page_bts))
	SET @engg_grid_sec_bts = ltrim(rtrim(@engg_grid_sec_bts))
	SET @engg_lay_page_bts = ltrim(rtrim(@engg_lay_page_bts))
	SET @engg_process_descr = ltrim(rtrim(@engg_process_descr))
	SET @engg_project_name = ltrim(rtrim(@engg_project_name))
	SET @engg_radio_page_bts = ltrim(rtrim(@engg_radio_page_bts))
	SET @engg_radio_sec_bts = ltrim(rtrim(@engg_radio_sec_bts))
	SET @engg_req_no = ltrim(rtrim(@engg_req_no))
	SET @engg_rf_act = ltrim(rtrim(@engg_rf_act))
	SET @engg_rf_comp = ltrim(rtrim(@engg_rf_comp))
	SET @engg_rf_ui = ltrim(rtrim(@engg_rf_ui))
	SET @engg_sec_page_bts = ltrim(rtrim(@engg_sec_page_bts))
	SET @engg_ui_descr = ltrim(rtrim(@engg_ui_descr))
	SET @engg_ui_xml = ltrim(rtrim(@engg_ui_xml))
	SET @hdncustomer = ltrim(rtrim(@hdncustomer))
	SET @hdnproject = ltrim(rtrim(@hdnproject))

	--null checking
	IF @ctxt_ouinstance = - 915
		SET @ctxt_ouinstance = NULL

	IF @ctxt_user = '~#~'
		SET @ctxt_user = NULL

	IF @ctxt_language = - 915
		SET @ctxt_language = NULL

	IF @ctxt_service = '~#~'
		SET @ctxt_service = NULL

	IF @engg_act_descr = '~#~'
		SET @engg_act_descr = NULL

	IF @engg_component = '~#~'
		SET @engg_component = NULL

	IF @engg_cont_page_bts = '~#~'
		SET @engg_cont_page_bts = NULL

	IF @engg_cont_sec_bts = '~#~'
		SET @engg_cont_sec_bts = NULL

	IF @engg_customer_name = '~#~'
		SET @engg_customer_name = NULL

	IF @engg_enum_page_bts = '~#~'
		SET @engg_enum_page_bts = NULL

	IF @engg_enum_sec_bts = '~#~'
		SET @engg_enum_sec_bts = NULL

	IF @engg_grid_page_bts = '~#~'
		SET @engg_grid_page_bts = NULL

	IF @engg_grid_sec_bts = '~#~'
		SET @engg_grid_sec_bts = NULL

	IF @engg_lay_page_bts = '~#~'
		SET @engg_lay_page_bts = NULL

	IF @engg_process_descr = '~#~'
		SET @engg_process_descr = NULL

	IF @engg_project_name = '~#~'
		SET @engg_project_name = NULL

	IF @engg_radio_page_bts = '~#~'
		SET @engg_radio_page_bts = NULL

	IF @engg_radio_sec_bts = '~#~'
		SET @engg_radio_sec_bts = NULL

	IF @engg_req_no = '~#~'
		SET @engg_req_no = NULL

	IF @engg_rf_act = '~#~'
		SET @engg_rf_act = NULL

	IF @engg_rf_comp = '~#~'
		SET @engg_rf_comp = NULL

	IF @engg_rf_ui = '~#~'
		SET @engg_rf_ui = NULL

	IF @engg_sec_page_bts = '~#~'
		SET @engg_sec_page_bts = NULL

	IF @engg_ui_descr = '~#~'
		SET @engg_ui_descr = NULL

	IF @engg_ui_xml = '~#~'
		SET @engg_ui_xml = NULL

	IF @hdncustomer = '~#~'
		SET @hdncustomer = NULL

	IF @hdnproject = '~#~'
		SET @hdnproject = NULL

	IF @engg_c_fprowno = - 915
		SELECT @engg_c_fprowno = NULL

	IF @engg_y_fprowno = - 915
		SELECT @engg_y_fprowno = NULL

	IF @_sec_fprowno = - 915
		SELECT @_sec_fprowno = NULL

	/*
--OuputList
Select null 'fprowno',
null 'engg_cont_btsynname',
null 'engg_cont_ctrlclass',
null 'engg_cont_ctrlimgclass',
null 'engg_cont_datawidth',
null 'engg_cont_descr',
null 'engg_cont_doc',
null 'engg_cont_elem_type',
null 'engg_cont_helptabstop',
null 'engg_cont_horder',
null 'engg_cont_labclass',
null 'engg_cont_labimgclass',
null 'engg_cont_labwidth',
null 'engg_cont_samp_data',
null 'engg_cont_sequence',
null 'engg_cont_tabseq',
null 'engg_cont_tooltip',
null 'engg_cont_vis_length',
null 'engg_cont_vorder' from ***
*/
	DECLARE @tmp_comp_name engg_name,
		@tmp_proc engg_name,
		@tmp_acty_name engg_name,
		@tmp_ui_name engg_name,
		@engg_base_req_no engg_name

	SELECT @engg_base_req_no = 'BASE'

	--select process name for description
	SELECT @tmp_proc = rtrim(process_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_req_no)
		AND process_descr = rtrim(@engg_process_descr)

	--select component name for description
	SELECT @tmp_comp_name = rtrim(component_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_descr = rtrim(@engg_component)

	--  --select actitity name for description
	--  select @tmp_acty_name  = rtrim(activity_name)
	--  from  ep_ui_req_dtl (nolock)
	--  where customer_name  = rtrim(@engg_customer_name)
	--  and project_name = rtrim(@engg_project_name)
	--  and req_no  = rtrim(@engg_req_no)
	--  and process_name = rtrim(@tmp_proc)
	--  and component_name  = rtrim(@tmp_comp_name)
	--  and activity_descr = rtrim(@engg_act_descr)
	--
	--  --select UI name for description
	--  select @tmp_ui_name  = min(rtrim(ui_name))
	--  from  ep_ui_req_dtl (nolock)
	--  where customer_name  = rtrim(@engg_customer_name)
	--  and project_name = rtrim(@engg_project_name)
	--   and req_no  = rtrim(@engg_req_no)
	--  and process_name = rtrim(@tmp_proc)
	--  and component_name  = rtrim(@tmp_comp_name)
	--  and activity_name = rtrim(@tmp_acty_name)
	--GETTING THE ACTIVITY NAME FOR THE DESCRIPTION
	SELECT @tmp_acty_name = activity_name
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND req_no = @engg_req_no
		AND process_name = @tmp_proc
		AND component_name = @tmp_comp_name
		AND activity_descr = @engg_act_descr

	--GETTING THE UI NAME FOR THE DESCRIPTION
	SELECT @tmp_ui_name = ui_name
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND req_no = @engg_req_no
		AND process_name = @tmp_proc
		AND component_name = @tmp_comp_name
		AND activity_name = @tmp_acty_name
		AND ui_descr = @engg_ui_descr

	/*select the min of page*/
	DECLARE @page_bt_synonym_tmp engg_name
	DECLARE @section_bt_synonym_tmp engg_name

	SELECT TOP 1 @page_bt_synonym_tmp = rtrim(page_bt_synonym)
	FROM ep_ui_page_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_base_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp_name)
		AND activity_name = rtrim(@tmp_acty_name)
		AND ui_name = rtrim(@tmp_ui_name)
	ORDER BY horder,
		vorder

	/*select the min of section*/
	SELECT @section_bt_synonym_tmp = min(rtrim(section_bt_synonym))
	FROM ep_ui_section_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_base_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp_name)
		AND activity_name = rtrim(@tmp_acty_name)
		AND ui_name = rtrim(@tmp_ui_name)
		AND page_bt_synonym = rtrim(@page_bt_synonym_tmp)
		-- modified by shafina on 30-jan-2004
		AND section_bt_synonym NOT IN (
			'PrjHdnSection',
			'[tabcontrol]',
			'hdnrt_stsection'
			) /*Modification made by Muthupandi S for Bug id : PNR2.0_32496  */
		AND section_type = 'Main'

	--Modified For BugId : PNR2.0_6270
	--  and  section_type not in ('Tree') -- added for request id: PNR2.0_1790
	/*
fetch the controls details for the selected activity/ui/page/section and display in the multiline
*/
	SELECT '' '_sec_fpRowNo',
		rtrim(control_bt_synonym) 'engg_cont_btsynname',
		ControlClass 'engg_cont_ctrlclass',
		ControlImageClass 'engg_cont_ctrlimgclass',
		rtrim(data_column_width) + rtrim(data_column_scalemode) 'engg_cont_datawidth',
		rtrim(b.bt_synonym_caption) 'engg_cont_descr',
		rtrim(control_doc) 'engg_cont_doc',
		rtrim(control_type) 'engg_cont_elem_type',
		CASE rtrim(help_tabstop)
			WHEN 'Y'
				THEN '1'
			WHEN 'N'
				THEN '0'
			END 'engg_cont_helptabstop',
		rtrim(horder) 'engg_cont_horder',
		LabelClass 'engg_cont_labclass',
		LabelImageClass 'engg_cont_labimgclass',
		rtrim(label_column_width) + rtrim(label_column_scalemode) 'engg_cont_labwidth',
		rtrim(sample_data) 'engg_cont_samp_data',
		rtrim(order_seq) 'engg_cont_sequence',
		tab_seq 'engg_cont_tabseq',
		rtrim(proto_tooltip) 'engg_cont_tooltip',
		rtrim(visisble_length) 'engg_cont_vis_length',
		rtrim(vorder) 'engg_cont_vorder',
		a.TemplateID 'engg_cont_tempid', -- Added for PLF2.0_14096
		controlimage 'Engg_cont_Ctrlimg', --shakthi
		parameter_text 'ctrl_temp_cat',
		TemplateSpecific 'ctrl_temp_specific',
		rtrim(icon_position) 'icon_position', --Code added for TECH-75230
		rtrim(ButtonNature) 'ButtonNature',	--Code added for TECH-75230
		rtrim(InlineStyle) 'InlineStyle' --Code added for TECH-75230
	FROM ep_ui_control_dtl a(NOLOCK)
	LEFT JOIN ep_device_quick_code_met c(NOLOCK) ON a.TemplateCategory = c.parameter_code
		AND parameter_type = 'TemplateCategory',
		ep_component_glossary_mst b(NOLOCK)
	WHERE a.customer_name = rtrim(@engg_customer_name)
		AND a.project_name = rtrim(@engg_project_name)
		AND a.req_no = rtrim(@engg_base_req_no)
		AND a.process_name = rtrim(@tmp_proc)
		AND a.component_name = rtrim(@tmp_comp_name)
		AND a.activity_name = rtrim(@tmp_acty_name)
		AND a.ui_name = rtrim(@tmp_ui_name)
		AND a.page_bt_synonym = rtrim(@page_bt_synonym_tmp)
		AND a.section_bt_synonym = rtrim(@section_bt_synonym_tmp)
		AND b.customer_name = a.customer_name
		AND b.project_name = a.project_name
		AND b.req_no = a.req_no
		AND b.process_name = a.process_name
		AND b.component_name = a.component_name
		AND b.bt_synonym_name = a.control_bt_synonym
	ORDER BY horder,
		vorder,
		order_seq

	SET NOCOUNT OFF
END

GO

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_maireeSp_scsavengg_cspO' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON ep_maireeSp_scsavengg_cspO TO PUBLIC
END
GO
