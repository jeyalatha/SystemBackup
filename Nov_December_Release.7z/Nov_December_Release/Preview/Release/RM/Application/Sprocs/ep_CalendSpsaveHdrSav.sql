IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_CalendSpsaveHdrSav' AND TYPE = 'P')
BEGIN
	DROP PROC ep_CalendSpsaveHdrSav
END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		ep_CalendSpsaveHdrSav.sql
********************************************************************************/
/******************************************************************************/
/* Procedure					: ep_CalendSpsaveHdrSav								 */
/* Description					: 								 */
/******************************************************************************/
/* Project						: 								 */
/* EcrNo						: 								 */
/* Version						: 								 */
/******************************************************************************/
/* Referenced					: 								 */
/* Tables						: 								 */
/******************************************************************************/
/* Development history			: 								 */
/******************************************************************************/
/* Author						: ModelExplorer								 */
/* Date							: Mar 30 2017  5:38PM								 */
/******************************************************************************/
/* Modification History			: 								 */
/******************************************************************************/
/* Modified by : Ganesh Prabhu S/Ranjitha R      for callid  TECH-10118       */
/* Modified on : 30-May-2017                                                  */
/* Description : Platform Feature Release                                     */
/********************************************************************************/
/* Modified by : Venkatesan K	DefectID: TECH-74049	Date: 01Dec2022			*/
/********************************************************************************/
CREATE PROCEDURE ep_CalendSpsaveHdrSav
	@ctxt_ouinstance ctxt_ouinstance, --Input 
	@ctxt_user ctxt_user, --Input 
	@ctxt_language ctxt_language, --Input 
	@ctxt_service ctxt_service, --Input 
	@ep_call_workreq engg_name, --Input 
	@ep_cal_comp engg_description, --Input 
	@ep_cal_customer engg_name, --Input 
	@ep_cal_deftemp engg_name, --Input 
	@ep_cal_detpan engg_seqno, --Input 
	@ep_cal_doubletap engg_seqno, --Input 
	@ep_cal_doubletapevt engg_seqno, --Input 
	@ep_cal_drag engg_seqno, --Input 
	@ep_cal_dragevt engg_seqno, --Input 
	@ep_cal_editable engg_seqno, --Input 
	@ep_cal_eventstyle engg_type, --Input 
	@ep_cal_listview engg_seqno, --Input 
	@ep_cal_monnavievt engg_seqno, --Input 
	@ep_cal_monthnavi engg_seqno, --Input 
	@ep_cal_monview engg_seqno, --Input 
	@ep_cal_page engg_name, --Input 
	@ep_cal_process engg_description, --Input 
	@ep_cal_project engg_name, --Input 
	@ep_cal_section engg_name, --Input 
	@ep_cal_tap engg_seqno, --Input 
	@ep_cal_tapevt engg_seqno, --Input 
	@ep_cal_ui engg_description, --Input 
	@ep_cal_weeknavi engg_seqno, --Input 
	@ep_cal_weeknavievt engg_seqno, --Input 
	@ep_cal_weekview engg_seqno, --Input 
	@ep_ca_act engg_description, --Input 
	@hdncustomer engg_name, --Input 
	@hdnproject engg_name, --Input 
	@prj_hdn_ctrl engg_description, --Input 
	@m_errorid INT OUTPUT --To Return Execution Status
AS
BEGIN
	-- nocount should be switched on to prevent phantom rows
	SET NOCOUNT ON
	-- @m_errorid should be 0 to Indicate Success
	SET @m_errorid = 0
	--declaration of temporary variables
	--temporary and formal parameters mapping
	SET @ctxt_user = ltrim(rtrim(@ctxt_user))
	SET @ctxt_service = ltrim(rtrim(@ctxt_service))
	SET @ep_call_workreq = ltrim(rtrim(@ep_call_workreq))
	SET @ep_cal_comp = ltrim(rtrim(@ep_cal_comp))
	SET @ep_cal_customer = ltrim(rtrim(@ep_cal_customer))
	SET @ep_cal_deftemp = ltrim(rtrim(@ep_cal_deftemp))
	SET @ep_cal_eventstyle = ltrim(rtrim(@ep_cal_eventstyle))
	SET @ep_cal_page = ltrim(rtrim(@ep_cal_page))
	SET @ep_cal_process = ltrim(rtrim(@ep_cal_process))
	SET @ep_cal_project = ltrim(rtrim(@ep_cal_project))
	SET @ep_cal_section = ltrim(rtrim(@ep_cal_section))
	SET @ep_cal_ui = ltrim(rtrim(@ep_cal_ui))
	SET @ep_ca_act = ltrim(rtrim(@ep_ca_act))
	SET @hdncustomer = ltrim(rtrim(@hdncustomer))
	SET @hdnproject = ltrim(rtrim(@hdnproject))
	SET @prj_hdn_ctrl = ltrim(rtrim(@prj_hdn_ctrl))

	--null checking
	IF @ctxt_ouinstance = - 915
		SELECT @ctxt_ouinstance = NULL

	IF @ctxt_user = '~#~'
		SELECT @ctxt_user = NULL

	IF @ctxt_language = - 915
		SELECT @ctxt_language = NULL

	IF @ctxt_service = '~#~'
		SELECT @ctxt_service = NULL

	IF @ep_call_workreq = '~#~'
		SELECT @ep_call_workreq = NULL

	IF @ep_cal_comp = '~#~'
		SELECT @ep_cal_comp = NULL

	IF @ep_cal_customer = '~#~'
		SELECT @ep_cal_customer = NULL

	IF @ep_cal_deftemp = '~#~'
		SELECT @ep_cal_deftemp = NULL

	IF @ep_cal_detpan = - 915
		SELECT @ep_cal_detpan = NULL

	IF @ep_cal_doubletap = - 915
		SELECT @ep_cal_doubletap = NULL

	IF @ep_cal_doubletapevt = - 915
		SELECT @ep_cal_doubletapevt = NULL

	IF @ep_cal_drag = - 915
		SELECT @ep_cal_drag = NULL

	IF @ep_cal_dragevt = - 915
		SELECT @ep_cal_dragevt = NULL

	IF @ep_cal_editable = - 915
		SELECT @ep_cal_editable = NULL

	IF @ep_cal_eventstyle = '~#~'
		SELECT @ep_cal_eventstyle = NULL

	IF @ep_cal_listview = - 915
		SELECT @ep_cal_listview = NULL

	IF @ep_cal_monnavievt = - 915
		SELECT @ep_cal_monnavievt = NULL

	IF @ep_cal_monthnavi = - 915
		SELECT @ep_cal_monthnavi = NULL

	IF @ep_cal_monview = - 915
		SELECT @ep_cal_monview = NULL

	IF @ep_cal_page = '~#~'
		SELECT @ep_cal_page = NULL

	IF @ep_cal_process = '~#~'
		SELECT @ep_cal_process = NULL

	IF @ep_cal_project = '~#~'
		SELECT @ep_cal_project = NULL

	IF @ep_cal_section = '~#~'
		SELECT @ep_cal_section = NULL

	IF @ep_cal_tap = - 915
		SELECT @ep_cal_tap = NULL

	IF @ep_cal_tapevt = - 915
		SELECT @ep_cal_tapevt = NULL

	IF @ep_cal_ui = '~#~'
		SELECT @ep_cal_ui = NULL

	IF @ep_cal_weeknavi = - 915
		SELECT @ep_cal_weeknavi = NULL

	IF @ep_cal_weeknavievt = - 915
		SELECT @ep_cal_weeknavievt = NULL

	IF @ep_cal_weekview = - 915
		SELECT @ep_cal_weekview = NULL

	IF @ep_ca_act = '~#~'
		SELECT @ep_ca_act = NULL

	IF @hdncustomer = '~#~'
		SELECT @hdncustomer = NULL

	IF @hdnproject = '~#~'
		SELECT @hdnproject = NULL

	IF @prj_hdn_ctrl = '~#~'
		SELECT @prj_hdn_ctrl = NULL

	IF isnull(@ep_cal_customer, '') = ''
	BEGIN
		RAISERROR (
				'Customer Name cannot be blank.',
				16,
				1
				)

		RETURN
	END

	IF isnull(@ep_cal_project, '') = ''
	BEGIN
		RAISERROR (
				'Project Name cannot be blank.',
				16,
				1
				)

		RETURN
	END

	IF isnull(@ep_call_workreq, '') = ''
	BEGIN
		RAISERROR (
				'Work Request # cannot be blank.',
				16,
				1
				)

		RETURN
	END

	IF isnull(@ep_cal_process, '') = ''
	BEGIN
		RAISERROR (
				'Process Description cannot be blank.',
				16,
				1
				)

		RETURN
	END

	IF isnull(@ep_cal_comp, '') = ''
	BEGIN
		RAISERROR (
				'Component Description cannot be blank.',
				16,
				1
				)

		RETURN
	END

	IF isnull(@ep_ca_act, '') = ''
	BEGIN
		RAISERROR (
				'Activity Description cannot be blank.',
				16,
				1
				)

		RETURN
	END

	IF isnull(@ep_cal_ui, '') = ''
	BEGIN
		RAISERROR (
				'UI Description cannot be blank.',
				16,
				1
				)

		RETURN
	END

	IF isnull(@ep_cal_page, '') = ''
	BEGIN
		RAISERROR (
				'Page Name cannot be blank.',
				16,
				1
				)

		RETURN
	END

	DECLARE @msg engg_description,
		@tmp_comp_name engg_name,
		@tmp_proc engg_name,
		@tmp_acty_name engg_name,
		@tmp_ui_name engg_name,
		@tmp_pagebt engg_name,
		@engg_base_req_no engg_name,
		@control_name engg_name

	SELECT @engg_base_req_no = 'BASE'

	SELECT @control_name = @ep_cal_section + '_ML'

	--select process name for description
	SELECT @tmp_proc = rtrim(process_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@ep_cal_customer)
		AND project_name = rtrim(@ep_cal_project)
		AND req_no = rtrim(@ep_call_workreq)
		AND process_descr = rtrim(@ep_cal_process)

	--select component name for description
	SELECT @tmp_comp_name = rtrim(component_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@ep_cal_customer)
		AND project_name = rtrim(@ep_cal_project)
		AND req_no = rtrim(@ep_call_workreq)
		AND process_name = rtrim(@tmp_proc)
		AND component_descr = rtrim(@ep_cal_comp)

	--select activity name for description
	SELECT @tmp_acty_name = min(rtrim(activity_name))
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@ep_cal_customer)
		AND project_name = rtrim(@ep_cal_project)
		AND req_no = rtrim(@ep_call_workreq)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp_name)
		AND activity_descr = rtrim(@ep_ca_act)

	--select ui name for description
	SELECT @tmp_ui_name = min(rtrim(ui_name))
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@ep_cal_customer)
		AND project_name = rtrim(@ep_cal_project)
		AND req_no = rtrim(@ep_call_workreq)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp_name)
		AND activity_name = rtrim(@tmp_acty_name)
		AND ui_descr = rtrim(@ep_cal_ui)

	IF EXISTS (
			SELECT 'x'
			FROM ep_ui_req_dtl(NOLOCK)
			WHERE customer_name = @ep_cal_customer
				AND project_name = @ep_cal_project
				AND req_no = @ep_call_workreq
				AND process_name = @tmp_proc
				AND component_name = @tmp_comp_name
				AND activity_name = @tmp_acty_name
				AND ui_name = @tmp_ui_name
				AND req_status = 'P'
			)
	BEGIN
		SELECT @msg = 'Cannot be saved as Selected UI is in published status'

		EXEC engg_error_sp 'ep_layout_sp_savln_hsv',
			1,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		IF @m_errorid <> 0
			RETURN
	END

	IF isnull(@ep_cal_section, '') = ''
	BEGIN
		RAISERROR (
				'Section Name cannot be blank.',
				16,
				1
				)

		RETURN
	END

	DECLARE @ep_cal_drag_tmp engg_flag,
		@ep_cal_monview_tmp engg_flag,
		@ep_cal_weekview_tmp engg_flag,
		@ep_cal_editable_tmp engg_flag,
		@ep_cal_detpan_tmp engg_flag,
		@ep_cal_listview_tmp engg_flag,
		@ep_cal_monthnavi_tmp engg_flag,
		@ep_cal_weeknavi_tmp engg_flag,
		@ep_cal_tap_tmp engg_flag,
		@ep_cal_doubletap_tmp engg_flag,
		@ep_cal_monnavievt_tmp engg_flag,
		@ep_cal_weeknavievt_tmp engg_flag,
		@ep_cal_tapevt_tmp engg_flag,
		@ep_cal_doubletapevt_tmp engg_flag,
		@ep_cal_dragevt_tmp engg_flag

	IF ISNULL(@ep_cal_drag, 0) = 1
		SELECT @ep_cal_drag_tmp = 'Y'
	ELSE
		SELECT @ep_cal_drag_tmp = 'N'

	IF ISNULL(@ep_cal_monview, 0) = 1
		SELECT @ep_cal_monview_tmp = 'Y'
	ELSE
		SELECT @ep_cal_monview_tmp = 'N'

	IF ISNULL(@ep_cal_weekview, 0) = 1
		SELECT @ep_cal_weekview_tmp = 'Y'
	ELSE
		SELECT @ep_cal_weekview_tmp = 'N'

	IF ISNULL(@ep_cal_editable, 0) = 1
		SELECT @ep_cal_editable_tmp = 'Y'
	ELSE
		SELECT @ep_cal_editable_tmp = 'N'

	IF ISNULL(@ep_cal_detpan, 0) = 1
		SELECT @ep_cal_detpan_tmp = 'Y'
	ELSE
		SELECT @ep_cal_detpan_tmp = 'N'

	IF ISNULL(@ep_cal_listview, 0) = 1
		SELECT @ep_cal_listview_tmp = 'Y'
	ELSE
		SELECT @ep_cal_listview_tmp = 'N'

	IF ISNULL(@ep_cal_monthnavi, 0) = 1
		SELECT @ep_cal_monthnavi_tmp = 'Y'
	ELSE
		SELECT @ep_cal_monthnavi_tmp = 'N'

	IF ISNULL(@ep_cal_weeknavi, 0) = 1
		SELECT @ep_cal_weeknavi_tmp = 'Y'
	ELSE
		SELECT @ep_cal_weeknavi_tmp = 'N'

	IF ISNULL(@ep_cal_tap, 0) = 1
		SELECT @ep_cal_tap_tmp = 'Y'
	ELSE
		SELECT @ep_cal_tap_tmp = 'N'

	IF ISNULL(@ep_cal_doubletap, 0) = 1
		SELECT @ep_cal_doubletap_tmp = 'Y'
	ELSE
		SELECT @ep_cal_doubletap_tmp = 'N'

	IF ISNULL(@ep_cal_monnavievt, 0) = 1
		SELECT @ep_cal_monnavievt_tmp = 'Y'
	ELSE
		SELECT @ep_cal_monnavievt_tmp = 'N'

	IF ISNULL(@ep_cal_weeknavievt, 0) = 1
		SELECT @ep_cal_weeknavievt_tmp = 'Y'
	ELSE
		SELECT @ep_cal_weeknavievt_tmp = 'N'

	IF ISNULL(@ep_cal_tapevt, 0) = 1
		SELECT @ep_cal_tapevt_tmp = 'Y'
	ELSE
		SELECT @ep_cal_tapevt_tmp = 'N'

	IF ISNULL(@ep_cal_doubletapevt, 0) = 1
		SELECT @ep_cal_doubletapevt_tmp = 'Y'
	ELSE
		SELECT @ep_cal_doubletapevt_tmp = 'N'

	IF ISNULL(@ep_cal_dragevt, 0) = 1
		SELECT @ep_cal_dragevt_tmp = 'Y'
	ELSE
		SELECT @ep_cal_dragevt_tmp = 'N'

	IF NOT EXISTS (
			SELECT 'x'
			FROM ep_Calendar_configure(NOLOCK)
			WHERE customer_name = rtrim(@ep_cal_customer)
				AND project_name = rtrim(@ep_cal_project)
				AND req_no = rtrim(@engg_base_req_no)
				AND process_name = rtrim(@tmp_proc)
				AND component_name = rtrim(@tmp_comp_name)
				AND activity_name = rtrim(@tmp_acty_name)
				AND ui_name = rtrim(@tmp_ui_name)
				AND page_name = rtrim(@ep_cal_page)
				AND section_name = rtrim(@ep_cal_section)
			)
	BEGIN
		INSERT INTO ep_Calendar_configure (
			customer_name,
			project_name,
			Req_no,
			Process_name,
			Component_name,
			Activity_name,
			ui_name,
			page_name,
			section_name,
			DefaultTemplate,
			detailspane,
			doubletap_req,
			doubletap_event,
			drag_req,
			dragevent,
			editable,
			eventstyle,
			listview_req,
			month_nav_event,
			month_nav_req,
			monthview_cal,
			tap_req,
			tapevent,
			week_nav_req,
			week_nav_event,
			weekview_cal,
			TIMESTAMP,
			createdby,
			createddate,
			modifiedby,
			modifieddate
			)
		VALUES (
			@ep_cal_customer,
			@ep_cal_project,
			@engg_base_req_no,
			@tmp_proc,
			@tmp_comp_name,
			@tmp_acty_name,
			@tmp_ui_name,
			@ep_cal_page,
			@ep_cal_section,
			@ep_cal_deftemp,
			@ep_cal_detpan_tmp,
			@ep_cal_doubletap_tmp,
			@ep_cal_doubletapevt_tmp,
			@ep_cal_drag_tmp,
			@ep_cal_dragevt_tmp,
			@ep_cal_editable_tmp,
			@ep_cal_eventstyle,
			@ep_cal_listview_tmp,
			@ep_cal_monnavievt_tmp,
			@ep_cal_monthnavi_tmp,
			@ep_cal_monview_tmp,
			@ep_cal_tap_tmp,
			@ep_cal_tapevt_tmp,
			@ep_cal_weeknavi_tmp,
			@ep_cal_weeknavievt_tmp,
			@ep_cal_weekview_tmp,
			1,
			@ctxt_user,
			getdate(),
			@ctxt_user,
			getdate()
			)
	END
	ELSE
	BEGIN
		UPDATE ep_Calendar_configure
		SET DefaultTemplate = @ep_cal_deftemp,
			detailspane = @ep_cal_detpan_tmp,
			doubletap_req = @ep_cal_doubletap_tmp,
			doubletap_event = @ep_cal_doubletapevt_tmp,
			drag_req = @ep_cal_drag_tmp,
			dragevent = @ep_cal_dragevt_tmp,
			editable = @ep_cal_editable_tmp,
			eventstyle = @ep_cal_eventstyle,
			listview_req = @ep_cal_listview_tmp,
			month_nav_event = @ep_cal_monnavievt_tmp,
			month_nav_req = @ep_cal_monthnavi_tmp,
			monthview_cal = @ep_cal_monview_tmp,
			tap_req = @ep_cal_tap_tmp,
			tapevent = @ep_cal_tapevt_tmp,
			week_nav_req = @ep_cal_weeknavi_tmp,
			week_nav_event = @ep_cal_weeknavievt_tmp,
			weekview_cal = @ep_cal_weekview_tmp,
			modifiedby = @ctxt_user,
			modifieddate = getdate()
		WHERE customer_name = rtrim(@ep_cal_customer)
			AND project_name = rtrim(@ep_cal_project)
			AND req_no = rtrim(@engg_base_req_no)
			AND process_name = rtrim(@tmp_proc)
			AND component_name = rtrim(@tmp_comp_name)
			AND activity_name = rtrim(@tmp_acty_name)
			AND ui_name = rtrim(@tmp_ui_name)
			AND page_name = rtrim(@ep_cal_page)
			AND section_name = rtrim(@ep_cal_section)
	END

	IF isnull(@ep_cal_monnavievt, 0) = 1
	BEGIN
		IF NOT EXISTS (
				SELECT 'x'
				FROM es_ctrl_type_events_mst(NOLOCK)
				WHERE customer_name = @ep_cal_customer
					AND project_name = @ep_cal_project
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp_name
					AND ctrl_type_name = @ep_cal_section
					AND base_ctrl_type = 'MobCalendar'
					AND events_desc = 'Month Navigation'
				)
			INSERT INTO es_ctrl_type_events_mst (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				ctrl_type_name,
				base_ctrl_type,
				events_desc,
				events_required,
				tasktype
				)
			VALUES (
				@ep_cal_customer,
				@ep_cal_project,
				'Base',
				@tmp_proc,
				@tmp_comp_name,
				@ep_cal_section,
				'MobCalendar',
				'Month Navigation',
				'Y',
				'Trans'
				)
	END
	ELSE IF isnull(@ep_cal_monnavievt, 0) = 0
	BEGIN
		IF EXISTS (
				SELECT 'x'
				FROM es_ctrl_type_events_mst(NOLOCK)
				WHERE customer_name = @ep_cal_customer
					AND project_name = @ep_cal_project
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp_name
					AND ctrl_type_name = @ep_cal_section
					AND base_ctrl_type = 'MobCalendar'
					AND events_desc = 'Month Navigation'
				)
			DELETE
			FROM es_ctrl_type_events_mst
			WHERE customer_name = @ep_cal_customer
				AND project_name = @ep_cal_project
				AND process_name = @tmp_proc
				AND component_name = @tmp_comp_name
				AND ctrl_type_name = @ep_cal_section
				AND base_ctrl_type = 'MobCalendar'
				AND events_desc = 'Month Navigation'
	END

	IF isnull(@ep_cal_weeknavievt, 0) = 1
	BEGIN
		IF NOT EXISTS (
				SELECT 'x'
				FROM es_ctrl_type_events_mst(NOLOCK)
				WHERE customer_name = @ep_cal_customer
					AND project_name = @ep_cal_project
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp_name
					AND ctrl_type_name = @ep_cal_section
					AND base_ctrl_type = 'MobCalendar'
					AND events_desc = 'Week Navigation'
				)
			INSERT INTO es_ctrl_type_events_mst (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				ctrl_type_name,
				base_ctrl_type,
				events_desc,
				events_required,
				tasktype
				)
			VALUES (
				@ep_cal_customer,
				@ep_cal_project,
				'Base',
				@tmp_proc,
				@tmp_comp_name,
				@ep_cal_section,
				'MobCalendar',
				'Week Navigation',
				'Y',
				'Trans'
				)
	END
	ELSE IF isnull(@ep_cal_weeknavievt, 0) = 0
	BEGIN
		IF EXISTS (
				SELECT 'x'
				FROM es_ctrl_type_events_mst(NOLOCK)
				WHERE customer_name = @ep_cal_customer
					AND project_name = @ep_cal_project
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp_name
					AND ctrl_type_name = @ep_cal_section
					AND base_ctrl_type = 'MobCalendar'
					AND events_desc = 'Week Navigation'
				)
			DELETE
			FROM es_ctrl_type_events_mst
			WHERE customer_name = @ep_cal_customer
				AND project_name = @ep_cal_project
				AND process_name = @tmp_proc
				AND component_name = @tmp_comp_name
				AND ctrl_type_name = @ep_cal_section
				AND base_ctrl_type = 'MobCalendar'
				AND events_desc = 'Week Navigation'
	END

	IF isnull(@ep_cal_tapevt, 0) = 1
	BEGIN
		IF NOT EXISTS (
				SELECT 'x'
				FROM es_ctrl_type_events_mst(NOLOCK)
				WHERE customer_name = @ep_cal_customer
					AND project_name = @ep_cal_project
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp_name
					AND ctrl_type_name = @ep_cal_section
					AND base_ctrl_type = 'MobCalendar'
					AND events_desc = 'Tap Event'
				)
			INSERT INTO es_ctrl_type_events_mst (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				ctrl_type_name,
				base_ctrl_type,
				events_desc,
				events_required,
				tasktype
				)
			VALUES (
				@ep_cal_customer,
				@ep_cal_project,
				'Base',
				@tmp_proc,
				@tmp_comp_name,
				@ep_cal_section,
				'MobCalendar',
				'Tap Event',
				'Y',
				'Trans'
				)
	END
	ELSE IF isnull(@ep_cal_tapevt, 0) = 0
	BEGIN
		IF EXISTS (
				SELECT 'x'
				FROM es_ctrl_type_events_mst(NOLOCK)
				WHERE customer_name = @ep_cal_customer
					AND project_name = @ep_cal_project
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp_name
					AND ctrl_type_name = @ep_cal_section
					AND base_ctrl_type = 'MobCalendar'
					AND events_desc = 'Tap Event'
				)
			DELETE
			FROM es_ctrl_type_events_mst
			WHERE customer_name = @ep_cal_customer
				AND project_name = @ep_cal_project
				AND process_name = @tmp_proc
				AND component_name = @tmp_comp_name
				AND ctrl_type_name = @ep_cal_section
				AND base_ctrl_type = 'MobCalendar'
				AND events_desc = 'Tap Event'
	END

	IF isnull(@ep_cal_doubletapevt, 0) = 1
	BEGIN
		IF NOT EXISTS (
				SELECT 'x'
				FROM es_ctrl_type_events_mst(NOLOCK)
				WHERE customer_name = @ep_cal_customer
					AND project_name = @ep_cal_project
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp_name
					AND ctrl_type_name = @ep_cal_section
					AND base_ctrl_type = 'MobCalendar'
					AND events_desc = 'Double Tap Event'
				)
			INSERT INTO es_ctrl_type_events_mst (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				ctrl_type_name,
				base_ctrl_type,
				events_desc,
				events_required,
				tasktype
				)
			VALUES (
				@ep_cal_customer,
				@ep_cal_project,
				'Base',
				@tmp_proc,
				@tmp_comp_name,
				@ep_cal_section,
				'MobCalendar',
				'Double Tap Event',
				'Y',
				'Trans'
				)
	END
	ELSE IF isnull(@ep_cal_doubletapevt, 0) = 0
	BEGIN
		IF EXISTS (
				SELECT 'x'
				FROM es_ctrl_type_events_mst(NOLOCK)
				WHERE customer_name = @ep_cal_customer
					AND project_name = @ep_cal_project
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp_name
					AND ctrl_type_name = @ep_cal_section
					AND base_ctrl_type = 'MobCalendar'
					AND events_desc = 'Double Tap Event'
				)
			DELETE
			FROM es_ctrl_type_events_mst
			WHERE customer_name = @ep_cal_customer
				AND project_name = @ep_cal_project
				AND process_name = @tmp_proc
				AND component_name = @tmp_comp_name
				AND ctrl_type_name = @ep_cal_section
				AND base_ctrl_type = 'MobCalendar'
				AND events_desc = 'Double Tap Event'
	END

	IF isnull(@ep_cal_dragevt, 0) = 1
	BEGIN
		IF NOT EXISTS (
				SELECT 'x'
				FROM es_ctrl_type_events_mst(NOLOCK)
				WHERE customer_name = @ep_cal_customer
					AND project_name = @ep_cal_project
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp_name
					AND ctrl_type_name = @ep_cal_section
					AND base_ctrl_type = 'MobCalendar'
					AND events_desc = 'Drag Event'
				)
			INSERT INTO es_ctrl_type_events_mst (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				ctrl_type_name,
				base_ctrl_type,
				events_desc,
				events_required,
				tasktype
				)
			VALUES (
				@ep_cal_customer,
				@ep_cal_project,
				'Base',
				@tmp_proc,
				@tmp_comp_name,
				@ep_cal_section,
				'MobCalendar',
				'Drag Event',
				'Y',
				'Trans'
				)
	END
	ELSE IF isnull(@ep_cal_dragevt, 0) = 0
	BEGIN
		IF EXISTS (
				SELECT 'x'
				FROM es_ctrl_type_events_mst(NOLOCK)
				WHERE customer_name = @ep_cal_customer
					AND project_name = @ep_cal_project
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp_name
					AND ctrl_type_name = @ep_cal_section
					AND base_ctrl_type = 'MobCalendar'
					AND events_desc = 'Drag Event'
				)
			DELETE
			FROM es_ctrl_type_events_mst
			WHERE customer_name = @ep_cal_customer
				AND project_name = @ep_cal_project
				AND process_name = @tmp_proc
				AND component_name = @tmp_comp_name
				AND ctrl_type_name = @ep_cal_section
				AND base_ctrl_type = 'MobCalendar'
				AND events_desc = 'Drag Event'
	END

	-- Event Generation starts
	IF EXISTS (
			SELECT 'x'
			FROM es_ctrl_type_events_mst(NOLOCK)
			WHERE customer_name = @ep_cal_customer
				AND project_name = @ep_cal_project
				AND process_name = @tmp_proc
				AND component_name = @tmp_comp_name
				AND ctrl_type_name = @ep_cal_section
				AND base_ctrl_type = 'MobCalendar'
			)
	BEGIN
		--select 'tt'
		EXEC ep_layout_save_events_gen @ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			@ep_cal_customer,
			@ep_cal_project,
			@tmp_proc,
			@tmp_comp_name,
			@tmp_acty_name,
			@tmp_ui_name,
			@ep_cal_page,
			@ep_cal_section,
			@control_name,
			'BASE',
			@ep_cal_section,
			'MobCalendar',
			'', --TECH-74049
			'', --TECH-74049
			@m_errorid OUTPUT
	END

	/* 
	--OutputList
		Select
	*/
	SET NOCOUNT OFF
END
GO

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_CalendSpsaveHdrSav' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON ep_CalendSpsaveHdrSav TO PUBLIC
END
GO

