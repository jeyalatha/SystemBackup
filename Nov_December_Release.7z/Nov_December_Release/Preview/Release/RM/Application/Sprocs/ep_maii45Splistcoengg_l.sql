/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		ep_maii45Splistcoengg_l.sql
********************************************************************************/
/******************************************************************************/
/* Procedure					: ep_maii45Splistcoengg_l								 */
/* DescriptiON					: 								 */
/******************************************************************************/
/* Project						: 								 */
/* EcrNo						: Prw_ECR_00258								 */
/* VersiON						: 								 */
/******************************************************************************/
/* Referenced					: 								 */
/* Tables						: 								 */
/******************************************************************************/
/* Development history			: 								 */
/******************************************************************************/
/* Author						: 								 */
/* Date							: Jul 18 2016  8:07PM								 */
/******************************************************************************/
/* ModificatiON History			: 								 */
/******************************************************************************/
/* Modified By					: 	Kiruthika R							 */
/* Date							: 	20-oct-2016							 */
/* DescriptiON					: 	Smart search enhancement			 */
/******************************************************************************/
/* Modified By					: 	Venkatesan K						 */
/* Date							: 	20-jan-2018							 */
/* DescriptiON					: 	Validation added to specify the column caption and visible length for the Tech-id TECH-17972 */
/******************************************************************************/
/* Modified By					: 	Ganesh Prabhu S	 						  */
/* Date							: 	01-Nov-2022								  */
/* Defect Id					: 	TECH-74112								  */
/******************************************************************************/
CREATE PROCEDURE ep_maii45Splistcoengg_l
	@ctxt_ouinstance ctxt_ouinstance, --Input 
	@ctxt_user ctxt_user, --Input 
	@ctxt_language ctxt_language, --Input 
	@ctxt_service ctxt_service, --Input 
	@engg_act_descr engg_descriptiON, --Input 
	@engg_compONent engg_descriptiON, --Input 
	@engg_customer_name engg_name, --Input 
	@engg_listcolcaptiON engg_descriptiON, --Input 
	@engg_listcolname engg_name, --Input 
	@engg_list_synONym engg_name, --Input 
	@engg_process_descr engg_descriptiON, --Input 
	@engg_project_name engg_name, --Input 
	@engg_recurrentsearch engg_seqno, --Input 
	@engg_req_no engg_name, --Input 
	@engg_searchid vw_plf_desc, --Input 
	@engg_searchindex engg_seqno, --Input 
	@engg_ui_descr vw_plf_desc, --Input 
	@list_visible engg_seqno, --Input 
	@list_width engg_seqno, --Input 
	@modeflag modeflag, --Input 
	@engg_l_fprowno rowno, --Input/Output
	@m_errorid INT OUTPUT --To Return ExecutiON Status
AS
BEGIN
	-- nocount should be switched ON to prevent phantom rows
	SET NOCOUNT ON
	-- @m_errorid should be 0 to Indicate Success
	SET @m_errorid = 0

	--declaratiON of temporary variables
	DECLARE @ctxt_ouinstance_In ctxt_ouinstance
	DECLARE @ctxt_user_In ctxt_user
	DECLARE @ctxt_language_In ctxt_language
	DECLARE @ctxt_service_In ctxt_service
	DECLARE @engg_act_descr_In engg_descriptiON
	DECLARE @engg_compONent_In engg_descriptiON
	DECLARE @engg_customer_name_In engg_name
	DECLARE @engg_listcolcaptiON_In engg_descriptiON
	DECLARE @engg_listcolname_In engg_name
	DECLARE @engg_list_synONym_In engg_name
	DECLARE @engg_process_descr_In engg_descriptiON
	DECLARE @engg_project_name_In engg_name
	DECLARE @engg_recurrentsearch_In engg_seqno
	DECLARE @engg_req_no_In engg_name
	DECLARE @engg_searchid_In vw_plf_desc
	DECLARE @engg_searchindex_In engg_seqno
	DECLARE @engg_ui_descr_In vw_plf_desc
	DECLARE @list_visible_In engg_seqno
	DECLARE @list_width_In engg_seqno
	DECLARE @modeflag_In modeflag
	DECLARE @engg_l_fprowno_In rowno

	--temporary and formal parameters mapping
	SET @ctxt_ouinstance_In = @ctxt_ouinstance
	SET @ctxt_user_In = ltrim(rtrim(@ctxt_user))
	SET @ctxt_language_In = @ctxt_language
	SET @ctxt_service_In = ltrim(rtrim(@ctxt_service))
	SET @engg_act_descr_In = ltrim(rtrim(@engg_act_descr))
	SET @engg_compONent_In = ltrim(rtrim(@engg_compONent))
	SET @engg_customer_name_In = ltrim(rtrim(@engg_customer_name))
	SET @engg_listcolcaptiON_In = ltrim(rtrim(@engg_listcolcaptiON))
	SET @engg_listcolname_In = ltrim(rtrim(@engg_listcolname))
	SET @engg_list_synONym_In = ltrim(rtrim(@engg_list_synONym))
	SET @engg_process_descr_In = ltrim(rtrim(@engg_process_descr))
	SET @engg_project_name_In = ltrim(rtrim(@engg_project_name))
	SET @engg_recurrentsearch_In = @engg_recurrentsearch
	SET @engg_req_no_In = ltrim(rtrim(@engg_req_no))
	SET @engg_searchid_In = ltrim(rtrim(@engg_searchid))
	SET @engg_searchindex_In = @engg_searchindex
	SET @engg_ui_descr_In = ltrim(rtrim(@engg_ui_descr))
	SET @list_visible_In = @list_visible
	SET @list_width_In = @list_width
	SET @modeflag_In = ltrim(rtrim(@modeflag))
	SET @engg_l_fprowno_In = @engg_l_fprowno

	--null checking
	IF @ctxt_ouinstance = - 915
		SELECT @ctxt_ouinstance_In = NULL

	IF @ctxt_user = '~#~'
		SELECT @ctxt_user_In = NULL

	IF @ctxt_language = - 915
		SELECT @ctxt_language_In = NULL

	IF @ctxt_service = '~#~'
		SELECT @ctxt_service_In = NULL

	IF @engg_act_descr = '~#~'
		SELECT @engg_act_descr_In = NULL

	IF @engg_compONent = '~#~'
		SELECT @engg_compONent_In = NULL

	IF @engg_customer_name = '~#~'
		SELECT @engg_customer_name_In = NULL

	IF @engg_listcolcaptiON = '~#~'
		SELECT @engg_listcolcaptiON_In = NULL

	IF @engg_listcolname = '~#~'
		SELECT @engg_listcolname_In = NULL

	IF @engg_list_synONym = '~#~'
		SELECT @engg_list_synONym_In = NULL

	IF @engg_process_descr = '~#~'
		SELECT @engg_process_descr_In = NULL

	IF @engg_project_name = '~#~'
		SELECT @engg_project_name_In = NULL

	IF @engg_recurrentsearch = - 915
		SELECT @engg_recurrentsearch_In = NULL

	IF @engg_req_no = '~#~'
		SELECT @engg_req_no_In = NULL

	IF @engg_searchid = '~#~'
		SELECT @engg_searchid_In = NULL

	IF @engg_searchindex = - 915
		SELECT @engg_searchindex_In = NULL

	IF @engg_ui_descr = '~#~'
		SELECT @engg_ui_descr_In = NULL

	IF @list_visible = - 915
		SELECT @list_visible_In = NULL

	IF @list_width = - 915
		SELECT @list_width_In = NULL

	IF @modeflag = '~#~'
		SELECT @modeflag_In = NULL

	IF @engg_l_fprowno = - 915
		SELECT @engg_l_fprowno_In = NULL

	--If Isnull(@list_visible_In,0) = 0
	--		Set  @list_visible_In = 1
	--TECH-17972 validation starts 
	IF @list_visible_In = 1
	BEGIN
		IF Isnull(@list_width_In, 0) = 0
		BEGIN
			RAISERROR (
					'Kindly specify the visible length for the column: %s',
					16,
					1,
					@engg_listcolname_In
					)

			RETURN
		END

		IF Isnull(@engg_listcolcaptiON_In, '') = ''
		BEGIN
			RAISERROR (
					'Kindly specify the caption for the column: %s',
					16,
					1,
					@engg_listcolname_In
					)

			RETURN
		END

		IF @engg_listcolcaptiON_In LIKE '%#%'
			OR @engg_listcolcaptiON_In LIKE '%~%'
		BEGIN
			RAISERROR (
					'Special characters(# or ~) is not allowed as column caption: %s',
					16,
					1,
					@engg_listcolcaptiON_In
					)--TECH-74112

			RETURN
		END
	END

	--Ends
	IF CHARINDEX('~', @engg_list_synONym_In) <> 0
		SET @engg_list_synONym_In = REPLACE(@engg_list_synONym_In, 'ML~', '')

	DECLARE @process_name engg_name,
		@compONent_name engg_name,
		@activity_name engg_name,
		@ui_name engg_name, --@oldlistsynONym engg_name 
		@list_result_column vw_plf_desc,
		@seqno engg_seqno,
		@listedit_column_synonym engg_name
	DECLARE @date DATETIME

	SET @date = Getdate()

	SELECT @process_name = process_name,
		@compONent_name = compONent_name,
		@activity_name = activity_name,
		@ui_name = ui_name
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name_In
		AND project_name = @engg_project_name_In
		AND req_no = @engg_req_no_In
		AND process_descr = @engg_process_descr_In
		AND compONent_descr = @engg_compONent_In
		AND activity_descr = @engg_act_descr_In
		AND ui_descr = @engg_ui_descr_In

	--select @oldlistsynONym = listedit_column_synONym
	--from ep_customlist_column_dtl (nolock)
	--where  customer_name		=  @engg_customer_name_In
	--and	  project_name		=	@engg_project_name_In
	--and	  process_name		=	@process_name
	--and	  compONent_name	=	@compONent_name
	--and	  activity_name		=  @activity_name
	--and	  ui_name				=	@ui_name
	--and	  listedit_synONym	=	@engg_list_synONym_In
	--and	  listedit_column_synONym	=	@engg_listcolname_In
	--Set 	@list_visible_In    = case when @list_visible_In	 =1 then 'y'  else 'n' end	
	IF @modeflag_In IN (
			'I',
			'X'
			)
	BEGIN
		IF NOT EXISTS (
				SELECT 'K'
				FROM ep_customlist_column_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name_In
					AND project_name = @engg_project_name_In
					AND process_name = @process_name
					AND compONent_name = @compONent_name
					AND activity_name = @activity_name
					AND ui_name = @ui_name
					AND listedit_synONym = @engg_list_synONym_In
					AND listedit_column_synONym = @engg_listcolname_In
					AND langid = 1
				)
		BEGIN
			SELECT @seqno = max(seqno) + 1
			FROM ep_customlist_column_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name_In
				AND project_name = @engg_project_name_In
				AND process_name = @process_name
				AND compONent_name = @compONent_name
				AND activity_name = @activity_name
				AND ui_name = @ui_name
				AND listedit_synONym = @engg_list_synONym_In
				AND langid = 1

			SET @seqno = Isnull(@seqno, 0)

			INSERT ep_customlist_column_dtl (
				customer_name,
				project_name,
				req_no,
				process_name,
				compONent_name,
				activity_name,
				ui_name,
				listedit_synONym,
				listedit_column_synONym,
				listedit_column_captiON,
				visible_length,
				createdby,
				createddate,
				visible,
				langid,
				seqno
				)
			SELECT @engg_customer_name_In,
				@engg_project_name_In,
				'Base',
				@process_name,
				@compONent_name,
				@activity_name,
				@ui_name,
				@engg_list_synONym_In,
				@engg_listcolname_In,
				@engg_listcolcaptiON_In,
				@list_width_In,
				@ctxt_user_In,
				@date,
				@list_visible_In,
				1,
				@seqno

			IF EXISTS (
					SELECT 'K'
					FROM ep_customlist_column_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name_In
						AND project_name = @engg_project_name_In
						AND process_name = @process_name
						AND compONent_name = @compONent_name
						AND activity_name = @activity_name
						AND ui_name = @ui_name
						AND listedit_synonym = @engg_list_synONym_In
						AND langid = 1
						AND visible_length IS NOT NULL
					) --visible length should be given to all column or nothing
			BEGIN
				SET @list_result_column = ''

				--select @list_result_column = @list_result_column+ listedit_column_synonym+'~'+
				--											Case when visible=1 then 'y' else 'n' end +'~'+cast (isnull(visible_length,0) as varchar(40))
				--											+'~'+listedit_column_caption+'#'
				SELECT TOP 1 @list_result_column = dbo.udf_select_concat(customer_name, project_name, process_name, component_name, activity_name, ui_name, listedit_synonym, 'y')
				FROM ep_customlist_column_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name_In
					AND project_name = @engg_project_name_In
					AND process_name = @process_name
					AND compONent_name = @compONent_name
					AND activity_name = @activity_name
					AND ui_name = @ui_name
					AND listedit_synonym = @engg_list_synONym_In
					AND langid = 1

				--order by seqno
				SET @list_result_column = SUBSTRING(@list_result_column, 1, len(@list_result_column) - 1)
			END
			ELSE --visible length should be given to all column or nothing
			BEGIN
				SET @list_result_column = ''

				--select @list_result_column = @list_result_column+ listedit_column_synonym+'~'+
				--				Case when visible=1 then 'y' else 'n' end +'#'
				SELECT TOP 1 @list_result_column = dbo.udf_select_concat(customer_name, project_name, process_name, component_name, activity_name, ui_name, listedit_synonym, 'n')
				FROM ep_customlist_column_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name_In
					AND project_name = @engg_project_name_In
					AND process_name = @process_name
					AND compONent_name = @compONent_name
					AND activity_name = @activity_name
					AND ui_name = @ui_name
					AND listedit_synonym = @engg_list_synONym_In
					AND langid = 1

				--														  order by seqno
				SET @list_result_column = SUBSTRING(@list_result_column, 1, len(@list_result_column) - 1)
			END

			UPDATE ep_custom_listedit
			SET list_result_column = @list_result_column
			WHERE customer_name = @engg_customer_name_In
				AND project_name = @engg_project_name_In
				AND process_name = @process_name
				AND compONent_name = @compONent_name
				AND activity_name = @activity_name
				AND ui_name = @ui_name
				AND listedit_synONym = @engg_list_synONym_In
		END
	END

	IF @modeflag_In IN (
			'U',
			'Y'
			)
		AND NOT EXISTS (
			SELECT 'K'
			FROM ep_customlist_column_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name_In
				AND project_name = @engg_project_name_In
				AND process_name = @process_name
				AND compONent_name = @compONent_name
				AND activity_name = @activity_name
				AND ui_name = @ui_name
				AND langid = 1
				AND listedit_synONym = @engg_list_synONym_In
				AND listedit_column_synONym = @engg_listcolname_In
			)
	BEGIN
		RAISERROR (
				'BT Synonym Name Can not be modified',
				16,
				1
				)

		RETURN
	END

	IF @modeflag_In IN (
			'U',
			'Y'
			)
	BEGIN
		UPDATE ep_customlist_column_dtl
		SET listedit_column_captiON = @engg_listcolcaptiON_In,
			visible = @list_visible_In,
			visible_length = @list_width_In
		WHERE customer_name = @engg_customer_name_In
			AND project_name = @engg_project_name_In
			AND process_name = @process_name
			AND compONent_name = @compONent_name
			AND activity_name = @activity_name
			AND ui_name = @ui_name
			AND listedit_synONym = @engg_list_synONym_In
			AND listedit_column_synONym = @engg_listcolname_In
			AND langid = 1

		IF EXISTS (
				SELECT 'K'
				FROM ep_customlist_column_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name_In
					AND project_name = @engg_project_name_In
					AND process_name = @process_name
					AND compONent_name = @compONent_name
					AND activity_name = @activity_name
					AND ui_name = @ui_name
					AND langid = 1
					AND listedit_synonym = @engg_list_synONym_In
					AND visible_length IS NOT NULL
				) --visible length should be given to all column or nothing
		BEGIN
			SET @list_result_column = ''

			SELECT TOP 1 @list_result_column = dbo.udf_select_concat(customer_name, project_name, process_name, component_name, activity_name, ui_name, listedit_synonym, 'y')
			FROM ep_customlist_column_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name_In
				AND project_name = @engg_project_name_In
				AND process_name = @process_name
				AND compONent_name = @compONent_name
				AND activity_name = @activity_name
				AND ui_name = @ui_name
				AND listedit_synonym = @engg_list_synONym_In
				AND langid = 1

			--order by seqno
			SET @list_result_column = SUBSTRING(@list_result_column, 1, len(@list_result_column) - 1)
		END
		ELSE --visible length should be given to all column or nothing
		BEGIN
			SET @list_result_column = ''

			SELECT TOP 1 @list_result_column = dbo.udf_select_concat(customer_name, project_name, process_name, component_name, activity_name, ui_name, listedit_synonym, 'n')
			FROM ep_customlist_column_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name_In
				AND project_name = @engg_project_name_In
				AND process_name = @process_name
				AND compONent_name = @compONent_name
				AND activity_name = @activity_name
				AND ui_name = @ui_name
				AND listedit_synonym = @engg_list_synONym_In
				AND langid = 1

			--														  order by seqno
			SET @list_result_column = SUBSTRING(@list_result_column, 1, len(@list_result_column) - 1)
		END

		UPDATE ep_custom_listedit
		SET list_result_column = @list_result_column
		WHERE customer_name = @engg_customer_name_In
			AND project_name = @engg_project_name_In
			AND process_name = @process_name
			AND compONent_name = @compONent_name
			AND activity_name = @activity_name
			AND ui_name = @ui_name
			AND listedit_synONym = @engg_list_synONym_In
	END

	--For Deletion
	IF @modeflag_In = 'D'
	BEGIN
		IF EXISTS (
				SELECT 'K'
				FROM ep_customlist_data_map(NOLOCK)
				WHERE customer_name = @engg_customer_name_In
					AND project_name = @engg_project_name_In
					AND process_name = @process_name
					AND compONent_name = @compONent_name
					AND activity_name = @activity_name
					AND ui_name = @ui_name
					AND listedit_synONym = @engg_list_synONym_In
					AND listedit_column_synONym = @engg_listcolname_In
				)
		BEGIN
			RAISERROR (
					'Kindly Unmap the Column Name : %s in Resolve List Columns',
					16,
					1,
					@engg_listcolname_In
					)

			RETURN
		END

		DELETE ep_customlist_column_dtl
		WHERE customer_name = @engg_customer_name_In
			AND project_name = @engg_project_name_In
			AND process_name = @process_name
			AND compONent_name = @compONent_name
			AND activity_name = @activity_name
			AND ui_name = @ui_name
			AND listedit_synONym = @engg_list_synONym_In
			AND listedit_column_synONym = @engg_listcolname_In
			AND langid = 1

		--To Update colseq
		IF EXISTS (
				SELECT 'K'
				FROM ep_customlist_column_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name_In
					AND project_name = @engg_project_name_In
					AND process_name = @process_name
					AND compONent_name = @compONent_name
					AND activity_name = @activity_name
					AND ui_name = @ui_name
					AND listedit_synONym = @engg_list_synONym_In
				)
		BEGIN
			SELECT *
			INTO #ep_customlist_column_dtl
			FROM ep_customlist_column_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name_In
				AND project_name = @engg_project_name_In
				AND process_name = @process_name
				AND compONent_name = @compONent_name
				AND activity_name = @activity_name
				AND ui_name = @ui_name
				AND listedit_synONym = @engg_list_synONym_In

			SET @seqno = 0

			WHILE EXISTS (
					SELECT 'K'
					FROM #ep_customlist_column_dtl
					)
			BEGIN
				SELECT TOP 1 @listedit_column_synonym = listedit_column_synonym
				FROM #ep_customlist_column_dtl

				UPDATE ep_customlist_column_dtl
				SET seqno = @seqno
				WHERE customer_name = @engg_customer_name_In
					AND project_name = @engg_project_name_In
					AND process_name = @process_name
					AND compONent_name = @compONent_name
					AND activity_name = @activity_name
					AND ui_name = @ui_name
					AND listedit_synONym = @engg_list_synONym_In
					AND listedit_column_synonym = @listedit_column_synonym

				SET @seqno = @seqno + 1

				DELETE
				FROM #ep_customlist_column_dtl
				WHERE listedit_column_synonym = @listedit_column_synonym
			END
		END --To Update colseq

		IF EXISTS (
				SELECT 'K'
				FROM ep_customlist_column_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name_In
					AND project_name = @engg_project_name_In
					AND process_name = @process_name
					AND compONent_name = @compONent_name
					AND activity_name = @activity_name
					AND ui_name = @ui_name
					AND listedit_synonym = @engg_list_synONym_In
					AND langid = 1
				)
		BEGIN
			IF EXISTS (
					SELECT 'K'
					FROM ep_customlist_column_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name_In
						AND project_name = @engg_project_name_In
						AND process_name = @process_name
						AND compONent_name = @compONent_name
						AND activity_name = @activity_name
						AND ui_name = @ui_name
						AND listedit_synonym = @engg_list_synONym_In
						AND langid = 1
						AND visible_length IS NOT NULL
					) --visible length should be given to all column or nothing
			BEGIN
				SET @list_result_column = ''

				SELECT TOP 1 @list_result_column = dbo.udf_select_concat(customer_name, project_name, process_name, component_name, activity_name, ui_name, listedit_synonym, 'y')
				FROM ep_customlist_column_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name_In
					AND project_name = @engg_project_name_In
					AND process_name = @process_name
					AND compONent_name = @compONent_name
					AND activity_name = @activity_name
					AND ui_name = @ui_name
					AND listedit_synonym = @engg_list_synONym_In
					AND langid = 1

				--																		  order by seqno
				SET @list_result_column = SUBSTRING(@list_result_column, 1, len(@list_result_column) - 1)
			END
			ELSE --visible length should be given to all column or nothing
			BEGIN
				SET @list_result_column = ''

				SELECT TOP 1 @list_result_column = dbo.udf_select_concat(customer_name, project_name, process_name, component_name, activity_name, ui_name, listedit_synonym, 'n')
				FROM ep_customlist_column_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name_In
					AND project_name = @engg_project_name_In
					AND process_name = @process_name
					AND compONent_name = @compONent_name
					AND activity_name = @activity_name
					AND ui_name = @ui_name
					AND listedit_synonym = @engg_list_synONym_In
					AND langid = 1

				--order by seqno
				SET @list_result_column = SUBSTRING(@list_result_column, 1, len(@list_result_column) - 1)
			END

			UPDATE ep_custom_listedit
			SET list_result_column = @list_result_column
			WHERE customer_name = @engg_customer_name_In
				AND project_name = @engg_project_name_In
				AND process_name = @process_name
				AND compONent_name = @compONent_name
				AND activity_name = @activity_name
				AND ui_name = @ui_name
				AND listedit_synONym = @engg_list_synONym_In
		END
		ELSE
			UPDATE ep_custom_listedit
			SET list_result_column = NULL
			WHERE customer_name = @engg_customer_name_In
				AND project_name = @engg_project_name_In
				AND process_name = @process_name
				AND compONent_name = @compONent_name
				AND activity_name = @activity_name
				AND ui_name = @ui_name
				AND listedit_synONym = @engg_list_synONym_In
	END

	IF NOT EXISTS (
			SELECT 'K'
			FROM ep_customlist_column_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name_In
				AND project_name = @engg_project_name_In
				AND process_name = @process_name
				AND compONent_name = @compONent_name
				AND activity_name = @activity_name
				AND ui_name = @ui_name
				AND listedit_synonym = @engg_list_synONym_In
				AND langid = 1
			)
		AND NOT EXISTS (
			SELECT 'K'
			FROM ep_customlist_search_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name_In
				AND project_name = @engg_project_name_In
				AND process_name = @process_name
				AND compONent_name = @compONent_name
				AND activity_name = @activity_name
				AND ui_name = @ui_name
				AND listedit_synonym = @engg_list_synONym_In
			)
		AND NOT EXISTS (
			SELECT 'K'
			FROM ep_customlist_data_map(NOLOCK)
			WHERE customer_name = @engg_customer_name_In
				AND project_name = @engg_project_name_In
				AND process_name = @process_name
				AND compONent_name = @compONent_name
				AND activity_name = @activity_name
				AND ui_name = @ui_name
				AND listedit_synonym = @engg_list_synONym_In
			)
	BEGIN
		DELETE ep_custom_listedit
		WHERE customer_name = @engg_customer_name_In
			AND project_name = @engg_project_name_In
			AND process_name = @process_name
			AND compONent_name = @compONent_name
			AND activity_name = @activity_name
			AND ui_name = @ui_name
			AND listedit_synonym = @engg_list_synONym_In
	END

	IF @modeflag_In <> 'D'
	BEGIN
		UPDATE ep_custom_listedit
		SET list_recurrent_search = @engg_recurrentsearch_In,
			list_index_search = @engg_searchindex_In,
			list_search_id = @engg_searchid_In
		WHERE customer_name = @engg_customer_name_In
			AND project_name = @engg_project_name_In
			AND process_name = @process_name
			AND compONent_name = @compONent_name
			AND activity_name = @activity_name
			AND ui_name = @ui_name
			AND listedit_synonym = @engg_list_synONym_In
	END

	/* 
	--OutputList
		Select
		null 'engg_l_fprowno', 
	*/
	SET NOCOUNT OFF
END

