IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_layout_sp_defctl_hsv' AND TYPE = 'P')
BEGIN
	DROP PROC ep_layout_sp_defctl_hsv
END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		ep_layout_sp_defctl_hsv.sql
********************************************************************************/
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
/*      V E R S I O N      :  2 . 0 .3    */
/*      Released By        :  PTech    */
/*      Release Comments   :  Released on  07 - Jan -05 (Patch Release 1)    */
/*      V E R S I O N      :  2.0.2    */
/*      Released By        :  PTech    */
/*      Release Comments   :  Released on  22-Jan-2004    */
/********************************************************************************/
/* procedure      ep_layout_sp_defctl_hsv                                       */
/* description                                                                  */
/********************************************************************************/
/* project        Preview                                                       */
/* version                                                                      */
/********************************************************************************/
/* referenced                                                                   */
/* tables                                                                       */
/********************************************************************************/
/* development history                                                          */
/********************************************************************************/
/* author         Shafina Begum.B                                               */
/* date           29/ 11/ 2003                                                  */
/********************************************************************************/
/* modification history                                                         */
/********************************************************************************/
/* modified by  : B.Shafina Begum                                               */
/* date         : 04-feb-2004                                                 */
/* description  : To check for ui's req_status            */
/* modified by  : ARUNN                                                   */
/* date         : 29-Jun-2005                                                 */
/* bugid  : PNR2.0_3088             */
/* bug desc  : On Clicking 'Default from reference UI', getting an error message */
/*      Cannot insert the value NULL into column 'tab_height',        */
/*                table 'rvw20appdb.dbo.ep_ui_mst'; column does not allow nulls.*/
/*      UPDATE fails.     */
/********************************************************************************/
/* modified by  : Balaji S For BugId :PNR2.0_3932                               */
/* date         : 22-Sep-2005                                                 */
/* description  : Defaulting From Reference UI.Validation to be Added For Control Duplication          */
/********************************************************************************/
/* modified by  : Balaji S For BugId :PNR2.0_3967                               */
/* date         : 22-Sep-2005                                                 */
/* description  : Validation Should be Added For Control Duplication Within Page*/
/********************************************************************************/
/********************************************************************************/
/* modified by  : C Lavanya                                            */
/* date         : 21-oct-2005                                                 */
/* description  : Htm Problem in Specify tree layout , Sp changed for default From Reference UI  in specify Layout.
for fixnote : _DM_FN_124               */
/********************************************************************************/
/* modified by  : Anuradha M                            0                       */
/* date         : 06-Nov-2006                                              */
/* description  : PNR2.0_10832                                                  */
/********************************************************************************/
/* modified by  : Balaji S                                                    */
/* date         : 05-Dec-2007                                              */
/* description  : PNR2.0_16195                                                  */
/********************************************************************************/
/* modified by  : Chanheetha N A                                                */
/* date         : 12-Feb-2008                                              */
/* description  : PNR2.0_16801                                                  */
/********************************************************************************/
/* Modified By      : Chanheetha N A               */
/* Date            : 14-May-2010             */
/* BugID       : PNR2.0_26860              */
/* Modified For      : Extra column to specify freezecount                   */
/********************************************************************************/
/* Modified By      : Sangeetha G											  */
/* Date             : 22-Sep-2010											  */
/* BugID			: PNR2.0_28401											  */
/* Modified For     :  On click of default reference Ui, The formal parameter */
/*                     @user_pref was not declared as an OUTPUT parameter	  */
/********************************************************************************/
/* Modified by  : Kalidas S	                                                  */
/* Date         : 03-Aug-2015                                                  */
/* Defect ID	: PLF2.0_14096                                                 */
/********************************************************************************/
/* Modified by : Jeya Latha K/Ganesh Prabhu S	for callid TECH-7349				*/
/* Modified on : 14-03-2017				 											*/
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and New Feature Organization chart */
/* Modified by : Rajeswari M/Priyadharshini U Date: 28-Jul-2021  Defect ID : TECH-60451*/
/* TECH-60451  : Launching Help&Link UIs, Popup sections and Grid Extensions in Side Drawer*/
/* TECH-63527  : Associate Control added in ep_ui_control_dtl for Multiselectcombo */ 
/***********************************************************************************/
/* Modified by	:	VimalKumar R 												*/
/* Modified on	:	08/06/22				 									*/
/* Defect ID	:	TECH-69624													*/
/* Description	:	Custom border, Custom actions and Responsive layout			*/
/********************************************************************************/
/* Modified by	:	Priyadharshini U											*/
/* Modified on	:	22/08/22				 									*/
/* Defect ID	:	TECH-72114													*/
/********************************************************************************/
/* Modified by	:	Ponmalar A													*/
/* Modified on	:	01/Dec/2022				 									*/
/* Defect ID	:	TECH-75230													*/
/********************************************************************************/
CREATE PROCEDURE ep_layout_sp_defctl_hsv
	@ctxt_language_in engg_ctxt_language,
	@ctxt_ouinstance_in engg_ctxt_ouinstance,
	@ctxt_service_in engg_ctxt_service,
	@ctxt_user_in engg_ctxt_user,
	@engg_act_descr_in engg_description,
	@engg_component_in engg_description,
	@engg_cont_page_bts_in engg_name,
	@engg_cont_sec_bts_in engg_name,
	@engg_customer_name_in engg_name,
	@engg_enum_page_bts_in engg_name,
	@engg_enum_sec_bts_in engg_name,
	@engg_grid_page_bts_in engg_name,
	@engg_grid_sec_bts_in engg_name,
	@engg_process_descr_in engg_description,
	@engg_project_name_in engg_name,
	@engg_radpage_bts_in engg_name,
	@engg_radsec_bts_in engg_name,
	@engg_req_no_in engg_name,
	@engg_rf_act_in engg_description,
	@engg_rf_comp_in engg_description,
	@engg_rf_ui_in engg_description,
	@engg_ui_descr_in engg_description,
	@guid_in engg_guid,
	@m_errorid INT OUTPUT
AS
BEGIN
	SET NOCOUNT ON

	--declaration of temporary variables
	DECLARE @ctxt_language engg_ctxt_language
	DECLARE @ctxt_ouinstance engg_ctxt_ouinstance
	DECLARE @ctxt_service engg_ctxt_service
	DECLARE @ctxt_user engg_ctxt_user
	DECLARE @engg_act_descr engg_description
	DECLARE @engg_component engg_description
	DECLARE @engg_cont_page_bts engg_name
	DECLARE @engg_cont_sec_bts engg_name
	DECLARE @engg_customer_name engg_name
	DECLARE @engg_enum_page_bts engg_name
	DECLARE @engg_enum_sec_bts engg_name
	DECLARE @engg_grid_page_bts engg_name
	DECLARE @engg_grid_sec_bts engg_name
	DECLARE @engg_process_descr engg_description
	DECLARE @engg_project_name engg_name
	DECLARE @engg_radpage_bts engg_name
	DECLARE @engg_radsec_bts engg_name
	DECLARE @engg_req_no engg_name
	DECLARE @engg_rf_act engg_description
	DECLARE @engg_rf_comp engg_description
	DECLARE @engg_rf_ui engg_description
	DECLARE @engg_ui_descr engg_description
	DECLARE @guid engg_guid
	DECLARE @ctrl_temp_cat engg_name
	DECLARE @ctrl_temp_specific engg_name
	DECLARE @Engg_cont_forresponsive engg_seqno --Code Added for TECH-69624

	--temporary and formal parameters mapping
	SELECT @ctxt_language = @ctxt_language_in

	SELECT @ctxt_ouinstance = @ctxt_ouinstance_in

	SELECT @ctxt_service = ltrim(rtrim(@ctxt_service_in))

	SELECT @ctxt_user = ltrim(rtrim(@ctxt_user_in))

	SELECT @engg_act_descr = ltrim(rtrim(@engg_act_descr_in))

	SELECT @engg_component = ltrim(rtrim(@engg_component_in))

	SELECT @engg_cont_page_bts = ltrim(rtrim(@engg_cont_page_bts_in))

	SELECT @engg_cont_sec_bts = ltrim(rtrim(@engg_cont_sec_bts_in))

	SELECT @engg_customer_name = ltrim(rtrim(@engg_customer_name_in))

	SELECT @engg_enum_page_bts = ltrim(rtrim(@engg_enum_page_bts_in))

	SELECT @engg_enum_sec_bts = ltrim(rtrim(@engg_enum_sec_bts_in))

	SELECT @engg_grid_page_bts = ltrim(rtrim(@engg_grid_page_bts_in))

	SELECT @engg_grid_sec_bts = ltrim(rtrim(@engg_grid_sec_bts_in))

	SELECT @engg_process_descr = ltrim(rtrim(@engg_process_descr_in))

	SELECT @engg_project_name = ltrim(rtrim(@engg_project_name_in))

	SELECT @engg_radpage_bts = ltrim(rtrim(@engg_radpage_bts_in))

	SELECT @engg_radsec_bts = ltrim(rtrim(@engg_radsec_bts_in))

	SELECT @engg_req_no = ltrim(rtrim(@engg_req_no_in))

	SELECT @engg_rf_act = ltrim(rtrim(@engg_rf_act_in))

	SELECT @engg_rf_comp = ltrim(rtrim(@engg_rf_comp_in))

	SELECT @engg_rf_ui = ltrim(rtrim(@engg_rf_ui_in))

	SELECT @engg_ui_descr = ltrim(rtrim(@engg_ui_descr_in))

	SELECT @guid = ltrim(rtrim(@guid_in))

	--null checking
	IF @ctxt_language = - 915
		SELECT @ctxt_language = NULL

	IF @ctxt_ouinstance = - 915
		SELECT @ctxt_ouinstance = NULL

	IF @ctxt_service = '~#~'
		SELECT @ctxt_service = NULL

	IF @ctxt_user = '~#~'
		SELECT @ctxt_user = NULL

	IF @engg_act_descr = '~#~'
		SELECT @engg_act_descr = NULL

	IF @engg_component = '~#~'
		SELECT @engg_component = NULL

	IF @engg_cont_page_bts = '~#~'
		SELECT @engg_cont_page_bts = NULL

	IF @engg_cont_sec_bts = '~#~'
		SELECT @engg_cont_sec_bts = NULL

	IF @engg_customer_name = '~#~'
		SELECT @engg_customer_name = NULL

	IF @engg_enum_page_bts = '~#~'
		SELECT @engg_enum_page_bts = NULL

	IF @engg_enum_sec_bts = '~#~'
		SELECT @engg_enum_sec_bts = NULL

	IF @engg_grid_page_bts = '~#~'
		SELECT @engg_grid_page_bts = NULL

	IF @engg_grid_sec_bts = '~#~'
		SELECT @engg_grid_sec_bts = NULL

	IF @engg_process_descr = '~#~'
		SELECT @engg_process_descr = NULL

	IF @engg_project_name = '~#~'
		SELECT @engg_project_name = NULL

	IF @engg_radpage_bts = '~#~'
		SELECT @engg_radpage_bts = NULL

	IF @engg_radsec_bts = '~#~'
		SELECT @engg_radsec_bts = NULL

	IF @engg_req_no = '~#~'
		SELECT @engg_req_no = NULL

	IF @engg_rf_act = '~#~'
		SELECT @engg_rf_act = NULL

	IF @engg_rf_comp = '~#~'
		SELECT @engg_rf_comp = NULL

	IF @engg_rf_ui = '~#~'
		SELECT @engg_rf_ui = NULL

	IF @engg_ui_descr = '~#~'
		SELECT @engg_ui_descr = NULL

	IF @guid = '~#~'
		SELECT @guid = NULL

	--errors mapped
	DECLARE @iudmodeflag VARCHAR(2),
		@tmp_processname engg_name,
		@tmp_componentname engg_name,
		@tmp_activity engg_name,
		@tmp_ui engg_name,
		@tmp_ref_componentname engg_name,
		@tmp_ref_activity engg_name,
		@tmp_ref_ui engg_name,
		@msg VARCHAR(200),
		@engg_base_req_no engg_name,
		@maxhorder engg_seqno,
		@rowcount engg_seqno,
		@page_prefix_tmp engg_name,
		@control_bt_caption engg_description,
		@base_ctl_type engg_name,
		@event_req engg_name,
		@help_req engg_name,
		@zoom_req engg_name,
		@editable engg_name,
		@visible engg_name,
		/*fIXNOTE:_DM_FN_124*/
		@engg_label_class engg_name,
		@engg_control_class engg_name,
		@engg_label_image_class engg_name,
		@engg_control_image_class engg_name,
		@engg_tab_sequence engg_seqno,
		@engg_tab_stopforhelp engg_flag,
		/*fIXNOTE:_DM_FN_124*/
		@AccessKey engg_code -- Modified by Ranjitha
		,
		@Icon_class engg_name,
		@Icon_position engg_name,
		@Cont_class_ext6 engg_name

	SELECT @engg_base_req_no = 'BASE'

	DECLARE @control_bt_synonym engg_name,
		@control_doc engg_documentation,
		@control_type engg_name,
		@horder engg_seqno,
		@sample_data engg_description,
		@proto_tooltip engg_description,
		@visisble_length engg_length,
		@vorder engg_seqno,
		@control_id engg_name,
		@control_id_tmp engg_name,
		@count engg_name,
		@data_column_width engg_seqno,
		@label_column_width engg_seqno,
		@order_seq engg_seqno,
		@data_column_scalemode engg_prefix,
		@label_column_scalemode engg_prefix,
		@user_pref engg_flag, -- added for PNR2.0_28401
		@report_req engg_flag -- code modified by Anuradha on 06-Nov-2006 for the Bug ID :: PNR2.0_10832
		,
		@controlimage engg_name,
		@colspan engg_seqno,
		@rowspan engg_seqno,
		@TemplateID engg_name, -- Added for PLF2.0_14096
		@engg_MSC_Ass_control engg_name, --code added for TECH-63527
		@engg_cont_control_format	engg_name,	--Code Added for the Defect Id TECH-72114
		@ButtonNature	engg_name, --TECH-75230
		@InlineStyle	engg_nvarchar_max --TECH-75230

	--getting the process name for description
	SELECT @tmp_processname = process_name
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND process_descr = @engg_process_descr
		AND req_no = @engg_req_no

	--getting the component name for the description
	SELECT @tmp_componentname = component_name
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND process_name = @tmp_processname
		AND component_descr = @engg_component
		AND req_no = @engg_req_no

	--getting the activity name for the description
	SELECT @tmp_activity = activity_name
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND process_name = @tmp_processname
		AND component_name = @tmp_componentname
		AND activity_descr = @engg_act_descr
		AND req_no = @engg_req_no

	--getting the ui name for the description
	SELECT @tmp_ui = ui_name
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND process_name = @tmp_processname
		AND component_name = @tmp_componentname
		AND activity_name = @tmp_activity
		AND ui_descr = @engg_ui_descr
		AND req_no = @engg_req_no

	IF EXISTS (
			SELECT 'x'
			FROM ep_ui_req_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_req_no
				AND process_name = @tmp_processname
				AND component_name = @tmp_componentname
				AND activity_name = @tmp_activity
				AND ui_name = @tmp_ui
				AND req_status = 'P'
			)
	BEGIN
		SELECT @msg = 'Cannot default as Selected UI is in published status'

		EXEC engg_error_sp 'en_layout_sp_defctlcnml',
			1,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		IF @m_errorid <> 0
			RETURN
	END

	--validations
	--check whether activity is selected. if not display error message
	IF @engg_act_descr IS NULL
	BEGIN
		SELECT @msg = 'select activity'

		EXEC engg_error_sp 'en_layout_sp_defctlcnml',
			1,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		RETURN
	END

	--check whether ui is selected. if not display error message
	IF @engg_ui_descr IS NULL
	BEGIN
		SELECT @msg = 'select user interface'

		EXEC engg_error_sp 'en_layout_sp_defctlcnml',
			2,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		RETURN
	END

	--check whether page bt is selected. if not display error message
	IF @engg_cont_page_bts IS NULL
	BEGIN
		SELECT @msg = 'select page (bt synonym)'

		EXEC engg_error_sp 'en_layout_sp_defctlcnml',
			3,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		RETURN
	END

	--check whether section bt is selected. if not display error message
	IF @engg_cont_sec_bts IS NULL
	BEGIN
		SELECT @msg = 'select section (bt synonym)'

		EXEC engg_error_sp 'en_layout_sp_defctlcnml',
			4,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		RETURN
	END

	--for the selected activity/ui combination check whether refernce ui has been defined. if not, display error message
	IF @engg_rf_ui IS NULL
	BEGIN
		SELECT @msg = 'reference ui does not exists for the selected ui.'

		EXEC engg_error_sp 'en_layout_sp_defctlcnml',
			3,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		RETURN
	END

	--getting the ref component name for the description
	SELECT @tmp_ref_componentname = component_name
	--  from  ep_ui_req_dtl (nolock)
	FROM Fw_BPT_RE_NameDesc_Vw(NOLOCK) -- Modified By Arunn for pnr2.0_3088
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		--  and   process_name      = @tmp_processname
		AND component_descr = @engg_rf_comp

	-- and     req_no         = @engg_req_no
	--getting the ref activity name for the description
	SELECT @tmp_ref_activity = activity_name
	--  from  ep_ui_req_dtl (nolock)
	FROM Fw_BPT_RE_NameDesc_Vw(NOLOCK) -- Modified By Arunn for pnr2.0_3088
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		-- code modified by shafina on 07-July-2004 for PREVIEWENG203SYS_000115
		-- When i click 'Default from Reference UI' task in Section Layout tabs, it says that "Control does not exist in Reference UI".
		--  and   process_name    = @tmp_processname
		AND component_name = @tmp_ref_componentname
		AND activity_descr = @engg_rf_act

	-- and     req_no        = @engg_req_no
	--getting the ref ui name for the description
	SELECT @tmp_ref_ui = ui_name
	--  from  ep_ui_req_dtl (nolock)
	FROM Fw_BPT_RE_NameDesc_Vw(NOLOCK) -- Modified By Arunn for pnr2.0_3088
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		--  and   process_name   = @tmp_processname
		AND component_name = @tmp_ref_componentname
		AND activity_name = @tmp_ref_activity
		AND ui_descr = @engg_rf_ui

	-- and     req_no       = @engg_req_no
	--check whether the section exists in reference ui for the reference ui. if not, display error message.
	IF NOT EXISTS (
			SELECT 'A'
			FROM ep_ui_control_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				--      and   process_name    = @tmp_processname
				AND component_name = @tmp_ref_componentname
				AND activity_name = @tmp_ref_activity
				AND ui_name = @tmp_ref_ui
				AND page_bt_synonym = @engg_cont_page_bts
				AND section_bt_synonym = @engg_cont_sec_bts
				AND req_no = @engg_base_req_no
			)
	BEGIN
		SELECT @msg = 'Control does not exist in Reference UI.'

		EXEC engg_error_sp 'en_layout_sp_defctlcnml',
			5,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		RETURN
	END

	--Check whether no controls exist for the ui/page/section.Else display error.
	IF (
			SELECT count('x')
			FROM ep_ui_control_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_base_req_no
				AND process_name = @tmp_processname
				AND component_name = @tmp_componentname
				AND activity_name = @tmp_activity
				AND ui_name = @tmp_ui
				AND page_bt_synonym = @engg_cont_page_bts
				AND section_bt_synonym = @engg_cont_sec_bts
				AND section_bt_synonym <> 'PrjHdnSection'
			) = 0
	BEGIN
		SELECT @tmp_ui = rtrim(@tmp_ui)
	END
	ELSE
	BEGIN
		SELECT @msg = 'Default from Reference UI cannot be done as there are controls defined for this UI/Page/Section already'

		EXEC engg_error_sp 'en_layout_sp_defctlcnml',
			6,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		RETURN
	END

	/*
expanation for the following query:

first part [query part before union]:
-------------------------------------

Selecting all the control details for the selected customer, project, process,
reference component, reference activity, reference ui, pagebtsynonym and sectionbtsynonym
from the table ep_ui_control_dtl also filtering the ui names for which the control
detail already saved.
Inserting the above selected values in the ep_ui_control_dtl table for the selected customer,
project, process, component, activity and ui

second part [query part after union]:
-------------------------------------

selecting all the control details for the selected customer, project, process, component,
activity, ui, page bt synonym and section bt synonym from the table ep_ui_control_dtl along with the
bt synonym caption for the corresponding control_bt_synonym from the table ep_glossary_mst.
*/
	DECLARE insert_cur INSENSITIVE CURSOR
	FOR
	SELECT control_bt_synonym,
		control_doc,
		control_type,
		horder,
		sample_data,
		proto_tooltip,
		visisble_length,
		vorder,
		data_column_width,
		label_column_width,
		order_seq,
		-- code modified by shafina on 22-Dec-2004 for  PREVIEWENG203ACC_000116 (In control_dtl table, label_column_scalemode and data_column_scalemode are added.)
		data_column_scalemode,
		label_column_scalemode,
		LabelClass,
		controlclass,
		labelimageclass,
		/*fIXNOTE:_DM_FN_124*/
		controlimageclass,
		isnull(tab_seq, 0),
		CASE 
			WHEN help_tabstop = 'N'
				THEN 0
			ELSE 1
			END,
		a.Set_User_Pref --Modified for PNR2.0_28401
		/*fIXNOTE:_DM_FN_124*/
		--   control_id , view_name
		,
		controlimage,
		colspan,
		rowspan,
		TemplateID, -- Added for PLF2.0_14096
		--Modified by Ranjitha
		AccessKey,
		Icon_class,
		Icon_position,
		Control_class_ext6,
		AssociateControl,
		ForResponsive,			--Code Added for TECH-69624 
		CASE WHEN ControlFormat	= 'Bes' THEN 'Controls Beside Captions'
			 WHEN ControlFormat = 'Top'	THEN 'Top Inner' ELSE '' END 'engg_cont_control_format',	--Code Added for the Defect Id TECH-72114
		Buttonnature,--TECH-75230
		InlineStyle	--TECH-75230
	FROM ep_ui_control_dtl a(NOLOCK)
	WHERE a.customer_name = @engg_customer_name
		AND a.project_name = @engg_project_name
		AND a.req_no = @engg_base_req_no
		--  and   a.process_name    =  @tmp_processname
		AND a.component_name = @tmp_ref_componentname
		AND a.activity_name = @tmp_ref_activity
		AND a.ui_name = @tmp_ref_ui
		AND a.page_bt_synonym = @engg_cont_page_bts
		AND a.section_bt_synonym = @engg_cont_sec_bts

	/*and   not exists (
select  'A'
from  ep_ui_control_dtl c (nolock)
where  a.customer_name    =  c.customer_name
and   a.project_name    =  c.project_name
and   a.process_name    =  c.process_name
and   a.component_name   =  c.component_name
and   a.ui_name      =  c.ui_name
and     a.req_no       =   c.req_no
and   a.page_bt_synonym   =  @engg_cont_page_bts
and   a.section_bt_synonym  <>  @engg_cont_sec_bts
and   a.control_bt_synonym  =  c.control_bt_synonym
)*/
	OPEN insert_cur

	WHILE (1 = 1)
	BEGIN
		FETCH NEXT
		FROM insert_cur
		INTO @control_bt_synonym,
			@control_doc,
			@control_type,
			@horder,
			@sample_data,
			@proto_tooltip,
			@visisble_length,
			@vorder,
			@data_column_width,
			@label_column_width,
			@order_seq,
			@data_column_scalemode,
			@label_column_scalemode,
			@engg_label_class,
			/*fIXNOTE:_DM_FN_124*/
			@engg_control_class,
			@engg_label_image_class,
			@engg_control_image_class,
			@engg_tab_sequence,
			@engg_tab_stopforhelp,
			@user_pref --Modified for PNR2.0_28401
			,
			@controlimage,
			@colspan,
			@rowspan,
			@TemplateID, -- Added for PLF2.0_14096
			--Ranjitha
			@AccessKey,
			@Icon_class,
			@Icon_position,
			@cont_class_ext6,
			@engg_MSC_Ass_control, --code added for TECH-63527
			@Engg_cont_forresponsive,	--Code Added for TECH-69624
			@engg_cont_control_format,	--Code Added for the Defect Id TECH-72114
			@ButtonNature,	--TECH-75230
			@InlineStyle	--TECH-75230

		--    @control_id , @view_name
		IF @@fetch_status <> 0
			BREAK

		-- code modified by shafina on 03-June-2004 for PREVIEWENG203ACC_000069
		-- When controls are defaulted from Reference UI , check whether the control type of ref ui exists in the base ui else error must be thrown.
		IF NOT EXISTS (
				SELECT 'x'
				FROM es_comp_ctrl_type_mst(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @tmp_processname
					AND component_name = @tmp_componentname
					AND ctrl_type_name = @control_type
				)
		BEGIN
			SELECT @msg = 'Default from Reference UI cannot be done as the control type ''' + @control_type + ''' does not exist in this component'

			EXEC engg_error_sp 'ep_layout_sp_defctl_hsv',
				8,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			CLOSE insert_cur

			DEALLOCATE insert_cur

			RETURN
		END

		SELECT @base_ctl_type = base_ctrl_type,
			@help_req = help_req,
			@event_req = event_handling_req,
			@zoom_req = zoom_req,
			@editable = editable_flag,
			@visible = visisble_flag,
			@report_req = report_req -- code modified by Anuradha on 06-Nov-2006 for the Bug ID :: PNR2.0_10832
		FROM es_comp_ctrl_type_mst_vw(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND process_name = @tmp_processname
			AND component_name = @tmp_componentname
			AND ctrl_type_name = @control_type
			AND req_no = @engg_base_req_no

		--code added by DNR for getting unique prefix ID on 30/12/2003
		EXEC engg_gen_prefix_id @engg_customer_name,
			@engg_project_name,
			@tmp_componentname,
			@tmp_activity,
			@tmp_ui,
			@control_bt_synonym,
			'C',
			6,
			@page_prefix_tmp OUTPUT

		-- code modified by shafina on 12-feb-2004 to generate controlID
		-- To Generate Control ID/View Names for the newly inserted controls
		--   select @ui_pfx_tmp   = page_prefix
		--   from ep_ui_page_dtl (nolock)
		--   where  customer_name    = @engg_customer_name
		--   and   project_name    = @engg_project_name
		--   and     req_no       = @engg_base_req_no
		--   and   process_name    = @tmp_processname
		--   and   component_name   = @tmp_componentname
		--   and   activity_name    = @tmp_activity
		--   and   ui_name       = @tmp_ui
		--   and  page_bt_synonym  = '[mainscreen]'
		-- code modified on shafina on 27-May-2004 for PREVIEWENG203ACC_000066
		-- (controlids are getting duplicated in some cases.)
		-- code modified by shafina on 12-Aug-2004 for PREVIEWENG203ACC_000085 - Control ID Generation Logic is changed.
		EXEC ep_controlid_generation @engg_customer_name,
			@engg_project_name,
			@engg_base_req_no,
			@tmp_processname,
			@tmp_componentname,
			@tmp_activity,
			@tmp_ui,
			@control_bt_synonym,
			@base_ctl_type,
			@editable,
			@visible,
			@control_id OUTPUT

		/*  select @control_id_tmp  = max(control_id)
from ep_ui_control_dtl (nolock)
where  customer_name    = @engg_customer_name
and   project_name    = @engg_project_name
and     req_no       = @engg_base_req_no
and   process_name    = @tmp_processname
and   component_name   = @tmp_componentname
and   activity_name    = @tmp_activity
and   ui_name       = @tmp_ui

select @control_id_tmp = right(isnull(@control_id_tmp,0) , 3)
select @count   = @control_id_tmp + 1

if len(@count) = 1
begin
select @control_id = @ui_pfx_tmp + '_' + '00' + @count
end
if len(@count) = 2
begin
select @control_id = @ui_pfx_tmp + '_' + '0' + @count
end
if len(@count) = 3
begin
select @control_id = @ui_pfx_tmp + '_' + @count
end*/
		--Code Modified for bugId : PNR2.0_16195
		EXEC ep_ui_control_dtl_sp_ins @ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			@engg_customer_name,
			@engg_project_name,
			@engg_base_req_no,
			@tmp_processname,
			@tmp_componentname,
			@tmp_activity,
			@tmp_ui,
			@engg_cont_page_bts,
			@engg_cont_sec_bts,
			@control_bt_synonym,
			@control_id,
			--@control_id, -- viewname
			@control_type,
			@visisble_length,
			@horder,
			@vorder,
			@order_seq,
			@data_column_width,
			@label_column_width,
			@proto_tooltip,
			@sample_data,
			@control_doc,
			@page_prefix_tmp,
			'',
			@data_column_scalemode,
			@label_column_scalemode,
			/*fIXNOTE:_DM_FN_124*/
			@engg_label_class,
			@engg_control_class,
			@engg_label_image_class,
			@engg_control_image_class,
			@engg_tab_sequence,
			@engg_tab_stopforhelp,
			/*fIXNOTE:_DM_FN_124*/
			1,
			@engg_req_no,
			@user_pref, --Modified for PNR2.0_28401
			0, --added for PNR2.0_26860
			@controlimage,
			@colspan,
			@rowspan,
			@TemplateID, -- Added for PLF2.0_14096
			@ctrl_temp_cat,
			@ctrl_temp_specific,
			--modified by Ranjitha
			@AccessKey,
			@Icon_class,
			@Icon_Position,
			@Cont_class_ext6,
			'',
			'',
			'',-----Code added for TECH-60451 ends
			@engg_MSC_Ass_control,--code added for TECH-63527
			@Engg_cont_forresponsive, --Code Added for TECH-69624 
			@engg_cont_control_format,--Code Added for the Defect Id TECH-72114
			@ButtonNature,	--TECH-75230
			@InlineStyle,	--TECH-75230
			@m_errorid OUTPUT

		IF @m_errorid <> 0
		BEGIN
			CLOSE insert_cur

			DEALLOCATE insert_cur

			RETURN
		END

		-- code modified by shafina on 04-June-2004 for PREVIEWENG203ACC_000070
		-- When controls/columns are defaulted form reference ui , corresponding glossary entry and task entry is not done.
		SELECT @visisble_length = isnull(@visisble_length, 20)

		-- code modified by shafina on 09-June-2004 for PREVIEWENG203ACC_000072
		IF @visisble_length = 0
			SELECT @visisble_length = 20

		IF NOT EXISTS (
				SELECT 'x'
				FROM ep_component_glossary_mst NOLOCK
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @tmp_processname
					AND component_name = @tmp_componentname
					AND bt_synonym_name = @control_bt_synonym
				)
		BEGIN
			-- code modified by shafina on 14-June-2004 for PREVIEWENG203ACC_000070
			--    exec ep_generate_caption @control_bt_synonym , @control_bt_caption out
			SELECT @control_bt_caption = bt_synonym_caption
			FROM ep_component_glossary_mst(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_base_req_no
				AND component_name = @tmp_ref_componentname
				AND bt_synonym_name = @control_bt_synonym

			-- 20/10/2005
			IF ISNULL(@control_bt_caption, '~#~') = '~#~'
				SET @control_bt_caption = @control_bt_synonym

			-- 20/10/2005
			-- code modified by shafina on 17-July-2004 for PREVIEWENG203ACC_000073
			EXEC ep_component_glossary_mst_sp_ins @ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@engg_customer_name,
				@engg_project_name,
				@engg_base_req_no,
				@tmp_processname,
				@tmp_componentname,
				@control_bt_synonym,
				NULL,
				'Char',
				@visisble_length,
				@control_bt_caption,
				@control_bt_synonym,
				'',
				'U',
				'',
				'',
				1,
				@engg_req_no,
				@m_errorid OUTPUT

			IF @m_errorid <> 0
			BEGIN
				CLOSE insert_cur

				DEALLOCATE insert_cur

				RETURN
			END
		END

		EXEC ep_task_generation @ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			@engg_customer_name,
			@engg_project_name,
			@engg_base_req_no,
			@tmp_processname,
			@tmp_componentname,
			@tmp_activity,
			@tmp_ui,
			@engg_cont_page_bts,
			@engg_cont_sec_bts,
			@control_bt_synonym,
			'',
			@base_ctl_type,
			@event_req,
			@help_req,
			@zoom_req,
			@editable,
			'CONTROL',
			@report_req,
			@engg_req_no, -- code modified by Anuradha on 06-Nov-2006 for the Bug ID :: PNR2.0_10832
			@m_errorid OUTPUT

		IF @m_errorid <> 0
		BEGIN
			CLOSE insert_cur

			DEALLOCATE insert_cur

			RETURN
		END

		--Code Modified For BugId : PNR2.0_3932
		IF EXISTS (
				SELECT 'A'
				FROM ep_ui_section_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @tmp_processname
					AND component_name = @tmp_componentname
					AND activity_name = @tmp_activity
					AND ui_name = @tmp_ui
					AND page_bt_synonym = @engg_cont_page_bts
					AND section_bt_synonym = @control_bt_synonym
					AND req_no = @engg_base_req_no
				)
		BEGIN
			SELECT @msg = 'Cannot Default. Control Bt Synonym ' + @control_bt_synonym + ' already exists in the Page as Section Bt Synonym'

			EXEC ENGG_ERROR_SP 'ep_layout_sp_defctl_hsv',
				7,
				@msg,
				@CTXT_LANGUAGE,
				@CTXT_OUINSTANCE,
				@CTXT_SERVICE,
				@CTXT_USER,
				'',
				'',
				'',
				'',
				@M_ERRORID OUTPUT

			CLOSE insert_cur

			DEALLOCATE insert_cur

			RETURN
		END

		IF EXISTS (
				SELECT 'A'
				FROM ep_ui_control_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @tmp_processname
					AND component_name = @tmp_componentname
					AND activity_name = @tmp_activity
					AND ui_name = @tmp_ui
					AND page_bt_synonym = @engg_cont_page_bts
					AND control_bt_synonym = @control_bt_synonym
					AND req_no = @engg_base_req_no
				GROUP BY customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					activity_name,
					ui_name,
					page_bt_synonym,
					control_bt_synonym
				HAVING count(*) > 1
				)
		BEGIN
			SELECT @msg = 'Cannot Default. Control Bt Synonym ' + @control_bt_synonym + ' already exists in the Page as Control Bt Synonym'

			EXEC ENGG_ERROR_SP 'ep_layout_sp_defctl_hsv',
				7,
				@msg,
				@CTXT_LANGUAGE,
				@CTXT_OUINSTANCE,
				@CTXT_SERVICE,
				@CTXT_USER,
				'',
				'',
				'',
				'',
				@M_ERRORID OUTPUT

			CLOSE insert_cur

			DEALLOCATE insert_cur

			RETURN
		END

		--code commented by chanheetha for the bug id :PNR2.0_16801
		--   if exists ( select 'X'
		--     from ep_ui_control_dtl (nolock)
		--     where  customer_name    =  @engg_customer_name
		--     and   project_name    =  @engg_project_name
		--     and   process_name    =  @tmp_processname
		--     and   component_name   =  @tmp_componentname
		--     and   activity_name    =  @tmp_activity
		--     and   ui_name      =  @tmp_ui
		--     and control_bt_synonym = rtrim(@control_bt_synonym)
		--     union
		--     select 'X'
		--     from ep_ui_grid_dtl (nolock)
		--     where  customer_name    =  @engg_customer_name
		--     and   project_name    =  @engg_project_name
		--     and   process_name    =  @tmp_processname
		--     and   component_name   =  @tmp_componentname
		--     and   activity_name    =  @tmp_activity
		--     and   ui_name      =  @tmp_ui
		--     and column_bt_synonym = rtrim(@control_bt_synonym))
		--   and  len (@control_bt_synonym) > 24
		--   begin
		--
		--    exec engg_error_sp 'ep_layout_sp_defctl_hsv',
		--       2, 'Cannot Default. Control (BT Synonym):<%2> length must not exceed 24',
		--       @ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,
		--       '',@control_bt_synonym,'','',@m_errorid output
		--    close insert_cur
		--    deallocate insert_cur
		--       return
		--   end
		--code commented by chanheetha for the bug id :PNR2.0_16801
		IF EXISTS (
				SELECT 'A'
				FROM ep_ui_grid_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @tmp_processname
					AND component_name = @tmp_componentname
					AND activity_name = @tmp_activity
					AND ui_name = @tmp_ui
					AND page_bt_synonym = @engg_cont_page_bts
					AND column_bt_synonym = @control_bt_synonym
					AND req_no = @engg_base_req_no
				)
		BEGIN
			SELECT @msg = 'Cannot Default. Control Bt Synonym ' + @control_bt_synonym + ' already exists in the Page as Grid Column Bt Synonym'

			EXEC ENGG_ERROR_SP 'ep_layout_sp_defctl_hsv',
				7,
				@msg,
				@CTXT_LANGUAGE,
				@CTXT_OUINSTANCE,
				@CTXT_SERVICE,
				@CTXT_USER,
				'',
				'',
				'',
				'',
				@M_ERRORID OUTPUT

			CLOSE insert_cur

			DEALLOCATE insert_cur

			RETURN
		END

		IF EXISTS (
				SELECT 'A'
				FROM de_hidden_view(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @tmp_processname
					AND component_name = @tmp_componentname
					AND activity_name = @tmp_activity
					AND ui_name = @tmp_ui
					AND page_name = @engg_cont_page_bts
					AND hidden_view_bt_synonym = @control_bt_synonym
				)
		BEGIN
			SELECT @msg = 'Cannot Default. Control Bt Synonym ' + @control_bt_synonym + ' already exists in the Page as Hidden View Bt Synonym'

			EXEC ENGG_ERROR_SP 'ep_layout_sp_defctl_hsv',
				7,
				@msg,
				@CTXT_LANGUAGE,
				@CTXT_OUINSTANCE,
				@CTXT_SERVICE,
				@CTXT_USER,
				'',
				'',
				'',
				'',
				@M_ERRORID OUTPUT

			CLOSE insert_cur

			DEALLOCATE insert_cur

			RETURN
		END

		IF EXISTS (
				SELECT 'A'
				FROM de_scratch_variable(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @tmp_processname
					AND component_name = @tmp_componentname
					AND activity_name = @tmp_activity
					AND ui_name = @tmp_ui
					AND page_name = @engg_cont_page_bts
					AND scratch_name = @control_bt_synonym
				)
		BEGIN
			SELECT @msg = 'Cannot Default. Control Bt Synonym ' + @control_bt_synonym + ' already exists in the Page as User Defined Scratch Variable'

			EXEC ENGG_ERROR_SP 'en_comp_sp_savcon_hsv',
				7,
				@msg,
				@CTXT_LANGUAGE,
				@CTXT_OUINSTANCE,
				@CTXT_SERVICE,
				@CTXT_USER,
				'',
				'',
				'',
				'',
				@M_ERRORID OUTPUT

			CLOSE insert_cur

			DEALLOCATE insert_cur

			RETURN
		END

		IF EXISTS (
				SELECT 'x'
				FROM de_scratch_variables_sys(NOLOCK)
				WHERE btsynonym = @control_bt_synonym
				)
			OR @control_bt_synonym = 'Modeflag'
		BEGIN
			SELECT @msg = 'Cannot Default. Control Bt Synonym ' + @control_bt_synonym + ' already exists as a Default Scratch Variable'

			EXEC engg_error_sp 'en_comp_sp_savcon_hsv',
				7,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			CLOSE insert_cur

			DEALLOCATE insert_cur

			RETURN
		END
	END

	CLOSE insert_cur

	DEALLOCATE insert_cur

	--output parameters
	SELECT 0 'fprowno'

	SET NOCOUNT OFF
END
GO

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_layout_sp_defctl_hsv' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON ep_layout_sp_defctl_hsv TO PUBLIC
END
GO

