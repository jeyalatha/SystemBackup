IF EXISTS(SELECT 'X' From SYSOBJECTS WHERE NAME ='EP_Layout_SP_InitGd_IconPos' AND TYPE='P')
   BEGIN
        DROP PROC EP_Layout_SP_InitGd_IconPos
   END
GO 
/*********************************************************************************/
/* Procedure					: EP_Layout_SP_InitGd_IconPos					 */
/* Description					: 												 */
/*********************************************************************************/
/* Project						: 												 */
/* EcrNo						: Prw_ECR_00									 */
/* Version						: 												 */
/*********************************************************************************/
/* Referenced					: 												 */
/* Tables						: 												 */
/*********************************************************************************/
/* Development history			: 												 */
/*********************************************************************************/
/* Author						: ModelExplorer									 */
/* Date							: Nov  2 2022  8:00PM							 */
/*********************************************************************************/
/* Modification History			: 												 */
/*********************************************************************************/
/* Modified By					: 	Priyadharshini U							 */
/* Date							: 	28Nov2022									 */
/* Defect Id					:	TECH-75230									 */
/*********************************************************************************/
CREATE Procedure EP_Layout_SP_InitGd_IconPos
	@ctxt_language_in      	ctxt_language, --Input 
	@ctxt_ouinstance_in    	ctxt_ouinstance, --Input 
	@ctxt_service_in       	ctxt_service, --Input 
	@ctxt_user_in          	ctxt_user, --Input 
	@engg_component_in     	engg_description, --Input 
	@engg_customer_name_in 	engg_name, --Input 
	@engg_process_descr_in 	engg_description, --Input 
	@engg_project_name_in  	engg_name, --Input 
	@engg_req_no_in        	engg_name, --Input 
	@m_errorid             	int output --To Return Execution Status
as
Begin
	-- nocount should be switched on to prevent phantom rows
	Set nocount on

	-- @m_errorid should be 0 to Indicate Success
	Set @m_errorid = 0

	-- declaration of temporary variables


	-- temporary and formal parameters mapping

	Set @ctxt_service_in        = ltrim(rtrim(@ctxt_service_in))
	Set @ctxt_user_in           = ltrim(rtrim(@ctxt_user_in))
	Set @engg_component_in      = ltrim(rtrim(@engg_component_in))
	Set @engg_customer_name_in  = ltrim(rtrim(@engg_customer_name_in))
	Set @engg_process_descr_in  = ltrim(rtrim(@engg_process_descr_in))
	Set @engg_project_name_in   = ltrim(rtrim(@engg_project_name_in))
	Set @engg_req_no_in         = ltrim(rtrim(@engg_req_no_in))

	-- null checking

	IF @ctxt_language_in = -915
		Select @ctxt_language_in = null  

	IF @ctxt_ouinstance_in = -915
		Select @ctxt_ouinstance_in = null  

	IF @ctxt_service_in = '~#~' 
		Select @ctxt_service_in = null  

	IF @ctxt_user_in = '~#~' 
		Select @ctxt_user_in = null  

	IF @engg_component_in = '~#~' 
		Select @engg_component_in = null  

	IF @engg_customer_name_in = '~#~' 
		Select @engg_customer_name_in = null  

	IF @engg_process_descr_in = '~#~' 
		Select @engg_process_descr_in = null  

	IF @engg_project_name_in = '~#~' 
		Select @engg_project_name_in = null  

	IF @engg_req_no_in = '~#~' 
		Select @engg_req_no_in = null  
	
	SELECT	''				'Icon_position'
	UNION
	select	distinct quick_code_value 'Icon_position'
	from	ep_quick_code_mst(nolock)
	WHERE	quick_code_type = 'IconPosition'	


	/* 
	-- OutputList
	Select
		null 'icon_position', 
	*/

	Set nocount off
End
GO
IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME= 'EP_Layout_SP_InitGd_IconPos' AND TYPE='P')
BEGIN
	GRANT EXEC ON  EP_Layout_SP_InitGd_IconPos TO PUBLIC
END
GO 


