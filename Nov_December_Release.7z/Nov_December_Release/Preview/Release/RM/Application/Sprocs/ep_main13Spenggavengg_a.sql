IF EXISTS  (SELECT 'X' FROM SYSOBJECTS WHERE NAME ='ep_main13Spenggavengg_a' AND TYPE = 'P')
    Begin
        Drop PROC ep_main13Spenggavengg_a
    End
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		ep_main13Spenggavengg_a.sql
********************************************************************************/
/********************************************************************************/
/* Procedure    : ep_main13Spenggavengg_a                                       */
/* Description  :                                                               */
/********************************************************************************/
/* Project      :                                                               */
/* ECR          :                                                               */
/* Version      :                                                               */
/********************************************************************************/
/* Referenced   :                                                               */
/* Tables       :                                                               */
/********************************************************************************/
/* Development history                                                          */
/********************************************************************************/
/* Author       : A Yuvaraj                                                     */
/* Date         : 28/Mar/2005                                                   */
/********************************************************************************/
/* Modification history                                                         */
/********************************************************************************/
/* Modified by  : kiruthika R                                                   */
/* Date         : 03-Nov-2006                                                   */
/* Description  : PNR2.0_10812                                                  */
/********************************************************************************/
/* Modified by  : Gowrisankar M for PNR2.0_20339                                */
/* Date         : 17-Dec-2008                                                   */
/* Description  : Fprowno Property addition                                     */
/********************************************************************************/
/* Modified By       : Chanheetha N A						 */
/* Date		     : 10-Nov-2010				                 */
/* Bug Id	     : PNR2.0_27462	                                         */
/* Description       : For the new feature Process Updated rows                  */
/*********************************************************************************/
/* modified by			: Vignesh R												*/
/* date					: 29-Sep-2011											*/
/* BugId				: PNR2.0_33317 											*/
/* Description			: New Feature - Offline Reports							*/
/********************************************************************************/
/* Modified by  : Veena U	                                                  */
/* Date         : 07-Aug-2015                                                  */
/* Defect ID	: PLF2.0_14096                                                 */
/********************************************************************************/
/* Created by  	: Veena U                                                */
/* Date         : 13-April-2016                                                  */
/*Defect Id 	: PLF2.0_17570													*/
/********************************************************************************/
/* Created by  	: Loganayaki P                                                */
/* Date         : 13-April-2016                                                  */
/*Defect Id 	: PLF2.0_17847													*/
/* Description	: Model Changes for System Process only selected Updated Rows	*/
/********************************************************************************/
/* Modified by : Veena U       */
/* Modified on : 08 June 2016       */
/* Description : PLF2.0_18487       */
/********************************************************************************/
/* Modified by : Loganayaki P       */
/* Modified on : 14 OCT 2016       */
/* Description : Tech-406      */
/********************************************************************************/
/* Modified by : Venkatesan K       */
/* Modified on : 19 May 2017       */
/* Description : TECH-9784      */
/* Description	: Validation handled to save "System Process only Selected Rows/System Process only Updated Rows" instead of 
				"Process only Selected Rows/Process only updated Rows" properties.*/
/********************************************************************************/
/*Modified by	: Ranjitha R   Defect ID: TECH-20897      On: 30-Apr-2018 */
/**************************************************************************************/
/* Modified by			: Priyadharshini U / Ponmalar A 							  */
/* Date					: 27-May-2022												  */
/* Defect ID			: TECH-69327												  */
/* Description			: Provision for modeling bubble message - display the multiple
						  messages when we fire a task - Bubble message.			  */
/**************************************************************************************/
/* Modified by	:	Priyadharshini U												  */
/* Modified on	:	10-Nov-2022				 										  */
/* Defect ID	:	TECH-75230														  */
/**************************************************************************************/
CREATE PROCEDURE ep_main13Spenggavengg_a
	@ctxt_ouinstance engg_ctxt_OUInstance, --Input 
	@ctxt_user engg_ctxt_User, --Input 
	@ctxt_language engg_ctxt_Language, --Input 
	@ctxt_service engg_ctxt_Service, --Input 
	@engg_cmbtaskt_met engg_name, --Input 
	@engg_cmbtask_patt engg_name, --Input 
	@engg_component engg_description, --Input 
	@engg_customer_name engg_name, --Input 
	@engg_process_descr engg_description, --Input 
	@engg_project_name engg_name, --Input 
	@engg_req_no engg_name, --Input 
	@engg_tasktxt_desc engg_description, --Input 
	@engg_task_descr engg_description, --Input 
	@engg_task_req engg_seqno, --Input 
	@engg_tasttxt_docu engg_description, --Input 
	@guid engg_guid, --Input 
	@hidden_control1 engg_description, --Input 
	@modeflag engg_ModeFlag, --Input 
	@engg_a_fprowno engg_RowNo, --Input/Output 
	@engg_k_fprowno engg_RowNo, --Input/Output 
	@m_errorid INT OUTPUT --To Return Execution Status 
AS
BEGIN
	-- nocount should be switched on to prevent phantom rows
	SET NOCOUNT ON
	-- @m_errorid should be 0 to Indicate Success
	SET @m_errorid = 0
	--declaration of temporary variables
	--temporary and formal parameters mapping
	SET @ctxt_user = ltrim(rtrim(@ctxt_user))
	SET @ctxt_service = ltrim(rtrim(@ctxt_service))
	SET @modeflag = ltrim(rtrim(@modeflag))

	--null checking
	IF @ctxt_ouinstance = - 915
		SET @ctxt_ouinstance = NULL

	IF @ctxt_user = '~#~'
		SET @ctxt_user = NULL

	IF @ctxt_language = - 915
		SET @ctxt_language = NULL

	IF @ctxt_service = '~#~'
		SET @ctxt_service = NULL

	IF @engg_cmbtaskt_met = '~#~'
		SET @engg_cmbtaskt_met = NULL

	IF @engg_cmbtask_patt = '~#~'
		SET @engg_cmbtask_patt = NULL

	IF @engg_component = '~#~'
		SET @engg_component = NULL

	IF @engg_customer_name = '~#~'
		SET @engg_customer_name = NULL

	IF @engg_process_descr = '~#~'
		SET @engg_process_descr = NULL

	IF @engg_project_name = '~#~'
		SET @engg_project_name = NULL

	IF @engg_req_no = '~#~'
		SET @engg_req_no = NULL

	IF @engg_tasktxt_desc = '~#~'
		SET @engg_tasktxt_desc = NULL

	IF @engg_task_descr = '~#~'
		SET @engg_task_descr = NULL

	IF @engg_task_req = - 915
		SET @engg_task_req = NULL

	IF @engg_tasttxt_docu = '~#~'
		SET @engg_tasttxt_docu = NULL

	IF @guid = '~#~'
		SET @guid = NULL

	IF @hidden_control1 = '~#~'
		SET @hidden_control1 = NULL

	IF @modeflag = '~#~'
		SET @modeflag = NULL

	IF @engg_a_fprowno = - 915
		SET @engg_a_fprowno = NULL

	IF @engg_k_fprowno = - 915
		SET @engg_k_fprowno = NULL

	/**
	--OuputList
	Select null 'engg_a_fprowno', 
	null 'engg_k_fprowno' from ****/
	DECLARE @engg_process_name engg_name,
		@engg_comp_name engg_name,
		@msg engg_description

	SELECT @engg_process_name = process_name,
		@engg_comp_name = component_name
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND process_descr = @engg_process_descr
		AND component_descr = @engg_component
	ORDER BY 1,
		2

	--code modified by kiruthika for bugid:PNR2.0_10812
	IF @modeflag IN (
			'U',
			'Y'
			)
	BEGIN
		/* validation added by Venkatesasn for bugid:TECH-9784 */
		IF @engg_task_descr = 'Process only Selected Rows'
			AND @engg_task_req = 1
		BEGIN
			SELECT @msg = 'Kindly select the "System Process only Selected Rows"  instead of  "Process only Selected Rows" and proceed.'

			EXEC engg_error_sp 'ep_main13SpenggavHdrSav',
				1,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			RETURN
		END

		IF @engg_task_descr = 'Process only Updated Rows'
			AND @engg_task_req = 1
		BEGIN
			SELECT @msg = 'Kindly select the "System Process only Updated Rows"  instead of  "Process only Updated Rows" and proceed.'

			EXEC engg_error_sp 'ep_main13SpenggavHdrSav',
				1,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			RETURN
		END

		--TECH-69327
		IF ISNULL(@engg_cmbtaskt_met,'') IN ('Initialize','Fetch') AND @engg_task_req = 1 AND ISNULL(@engg_task_descr,'') = 'Bubble Message'
		BEGIN
			RAISERROR ('Bubble message is not applicable for ''Initialize'' and ''Fetch''.',16,1)
		END
		--TECH-69327

		/* validation end */
		/*validation starting added by 11536*/
		DECLARE @renderas engg_name

		SELECT @renderas = CASE 
				WHEN sys_proc_sel_rows = 'y'
					THEN 'System Process only Selected Rows'
				WHEN sys_process_updrows = 'y'
					THEN 'System Process only Updated Rows'
				WHEN sys_proc_selupd_rows = 'y'
					THEN 'System Process only selected Updated Rows'
				END
		FROM es_comp_task_type_mst(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND process_name = @engg_process_name
			AND component_name = @engg_comp_name
			AND task_type_name = @engg_cmbtask_patt

		IF EXISTS (
				SELECT 'x'
				FROM es_comp_task_type_mst(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @engg_process_name
					AND component_name = @engg_comp_name
					AND task_type_name = @engg_cmbtask_patt
					AND len(@renderas) <> 0
					AND @engg_task_req = 1
					AND @engg_task_descr IN (
						'System Process only Selected Rows',
						'System Process only Updated Rows',
						'System Process only selected Updated Rows'
						)
					AND @renderas <> @engg_task_descr
				)
		BEGIN
			RAISERROR (
					'Kindly choose any one attribute from the following list ''System Process only Selected Rows, System Process only Updated Rows, System Process only selected Updated Rows''.',
					16,
					1
					)

			RETURN
		END

		/** Bulk Validation Property for Trans.
		Code added for Defect id: TECH-20897 starts.
	*/
		IF @engg_task_descr = 'Bulk Validation'
			AND @engg_cmbtaskt_met <> 'Trans'
			AND	@engg_task_req = 1	--TECH-75230	
		BEGIN
			RAISERROR (
					'Bulk Validation is applicable only for the Action type ''TRANS''.',
					16,
					1
					)

			RETURN
		END

		--Code added for Defect id: TECH-20897 starts
		/*validation Ended */
		IF EXISTS (
				SELECT 'x'
				FROM ep_action_mst a(NOLOCK),
					de_task_control_map b(NOLOCK)
				WHERE a.customer_name = @engg_customer_name
					AND a.project_name = @engg_project_name
					AND a.process_name = @engg_process_name
					AND a.component_name = @engg_comp_name
					AND a.task_pattern = @engg_cmbtask_patt
					AND a.customer_name = b.customer_name
					AND a.project_name = b.project_name
					AND a.process_name = b.process_name
					AND a.component_name = b.component_name
					AND a.activity_name = b.activity_name
					AND a.ui_name = b.ui_name
					AND a.task_name = b.action_name
				)
		BEGIN
			DECLARE @count engg_flag,
				@engg_task_req1 engg_flag

			IF (@engg_task_req = 1)
			BEGIN
				SELECT @engg_task_req1 = 'Y'
			END

			IF (@engg_task_req = 0)
			BEGIN
				SELECT @engg_task_req1 = 'n'
			END

			SELECT @count = NULL

			SELECT @count = CASE 
					WHEN @engg_task_descr = 'Clear On Page Save'
						AND (@engg_task_req1 <> a.clr_on_page_save)
						THEN 'Y'
					WHEN @engg_task_descr = 'Combo Default Required'
						AND (@engg_task_req1 <> a.cbdef_req)
						THEN 'Y'
					WHEN @engg_task_descr = 'Conditional Multiline Fetch'
						AND (@engg_task_req1 <> a.cond_ml_fetch)
						THEN 'Y'
					WHEN @engg_task_descr = 'Data Saving Task'
						AND (@engg_task_req1 <> a.data_save_req)
						THEN 'Y'
					WHEN @engg_task_descr = 'Header Fetch Required'
						AND (@engg_task_req1 <> a.hdr_fetch_req)
						THEN 'Y'
					WHEN @engg_task_descr = 'Header Save Required'
						AND (@engg_task_req1 <> a.hdr_save_req)
						THEN 'Y'
					WHEN @engg_task_descr = 'Include Message Place Holder'
						AND (@engg_task_req1 <> a.incl_place_holder)
						THEN 'Y'
					WHEN @engg_task_descr = 'ML Save Required'
						AND (@engg_task_req1 <> a.ml_save_req)
						THEN 'Y'
					WHEN @engg_task_descr = 'LinkAsUI Required'
						AND (@engg_task_req1 <> a.ml_save_req)
						THEN 'Y'
					WHEN @engg_task_descr = 'Uiastrans Required'
						AND (@engg_task_req1 <> a.ml_save_req)
						THEN 'Y'
					WHEN @engg_task_descr = 'Multiline Fetch Required'
						AND (@engg_task_req1 <> a.ml_fet_req)
						THEN 'Y'
					WHEN @engg_task_descr = 'ML Singlesegment Required'
						AND (@engg_task_req1 <> a.MLSaveSinglesegment)
						THEN 'Y'
					WHEN @engg_task_descr = 'Process only Selected Rows'
						AND (@engg_task_req1 <> a.proc_sel_rows)
						THEN 'Y'
					WHEN @engg_task_descr = 'Process only Updated Rows'
						AND (@engg_task_req1 <> a.process_updrows)
						THEN 'Y' --code added for the caseid : PNR2.0_27462
					WHEN @engg_task_descr = 'Refresh On Save'
						AND (@engg_task_req1 <> a.refresh_on_save)
						THEN 'Y'
					WHEN @engg_task_descr = 'Separate Header Refresh Method Required'
						AND (@engg_task_req1 <> a.hdr_ref_req)
						THEN 'Y'
					WHEN @engg_task_descr = 'Separate Method for Header Check Required'
						AND (@engg_task_req1 <> a.hdr_check_req)
						THEN 'Y'
					WHEN @engg_task_descr = 'Separate Method for Message Handling'
						AND (@engg_task_req1 <> a.err_handle_method)
						THEN 'Y'
					WHEN @engg_task_descr = 'Should User Role to be Mapped to All Methods'
						AND (@engg_task_req1 <> a.usr_role_map)
						THEN 'Y'
					WHEN @engg_task_descr = 'Task Conformation'
						AND (@engg_task_req1 <> a.task_confirmation)
						THEN 'Y'
					WHEN @engg_task_descr = 'Logic Extensions'
						AND (@engg_task_req1 <> a.Logic_Extensions)
						THEN 'Y'
					WHEN @engg_task_descr = 'Transaction Scope Required'
						AND (@engg_task_req1 <> a.trn_scope_req)
						THEN 'Y'
					WHEN @engg_task_descr = 'Validate On Initiate'
						AND (@engg_task_req1 <> a.valid_on_init)
						THEN 'Y'
					WHEN @engg_task_descr = 'Fprowno Required'
						AND (@engg_task_req1 <> a.fprowno_req)
						THEN 'Y' -- Code added for PNR2.0_20339 on 17-Dec-2008 by Gowrisankar M
					WHEN @engg_task_descr = 'Configure Alternate Database'
						AND (@engg_task_req1 <> a.alternate_db)
						THEN 'Y' -- Code added For Bug Id : PNR2.0_33317
					WHEN @engg_task_descr = 'System Process only Selected Rows'
						AND (@engg_task_req1 <> a.sys_proc_sel_rows)
						THEN 'Y'
					WHEN @engg_task_descr = 'System Process only Updated Rows'
						AND (@engg_task_req1 <> a.sys_process_updrows)
						THEN 'y'
					WHEN @engg_task_descr = 'System Process only selected Updated Rows'
						AND (@engg_task_req1 <> a.sys_proc_selupd_rows)
						THEN 'y' --PLF2.0_17847
					WHEN @engg_task_descr = 'Parent Context Parameters'
						AND (@engg_task_req1 <> a.ParentContextInformation)
						THEN 'y'
					WHEN @engg_task_descr = 'Current Context Parameters'
						AND (@engg_task_req1 <> a.CurrentContextInformation)
						THEN 'y'
					WHEN @engg_cmbtaskt_met = 'DoNotDefault'
						AND (a.default_for <> 'DND')
						THEN 'Y'
					WHEN @engg_cmbtaskt_met = 'Initialize'
						AND (a.default_for <> 'Init')
						THEN 'Y'
					WHEN @engg_cmbtaskt_met NOT IN (
							'DoNotDefault',
							'Initialize'
							)
						AND (@engg_cmbtaskt_met <> a.default_for)
						THEN 'Y'
					WHEN @engg_task_descr = 'Modeflag Enabled'
						AND (@engg_task_req1 <> a.ModeflagEnabled)
						THEN 'y'
							-- Code added for Defect id: TECH-20897 
					WHEN @engg_task_descr = 'Bulk Validation'
						AND (@engg_task_req1 <> a.BulkValidation)
						THEN 'y'
							-- code ends
					--Code Added for the Defect Id TECH-69327 Starts
					WHEN @engg_task_descr = 'Bubble Message'
						AND (@engg_task_req1 <> a.BubbleMessage)
						THEN 'y'
					--Code Added for the Defect Id TECH-69327 Ends
					ELSE 'n'
					END
			FROM es_comp_task_type_mst a(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @engg_process_name
				AND component_name = @engg_comp_name
				AND task_type_name = @engg_cmbtask_patt

			IF @count <> 'n'
			BEGIN
				RAISERROR (
						'Action Pattern Name %s is in use..Cannot modify..',
						16,
						1,
						@engg_cmbtask_patt
						)

				RETURN
			END
		END
		ELSE
		BEGIN
			--code modified by kiruthika for bugid:PNR2.0_10812
			UPDATE a
			SET a.clr_on_page_save = CASE 
					WHEN @engg_task_descr = 'Clear On Page Save'
						AND @engg_task_req = 1
						THEN 'Y'
					WHEN @engg_task_descr = 'Clear On Page Save'
						AND @engg_task_req = 0
						THEN 'n'
					ELSE a.clr_on_page_save
					END,
				a.cbdef_req = CASE 
					WHEN @engg_task_descr = 'Combo Default Required'
						AND @engg_task_req = 1
						THEN 'Y'
					WHEN @engg_task_descr = 'Combo Default Required'
						AND @engg_task_req = 0
						THEN 'n'
					ELSE a.cbdef_req
					END,
				a.cond_ml_fetch = CASE 
					WHEN @engg_task_descr = 'Conditional Multiline Fetch'
						AND @engg_task_req = 1
						THEN 'Y'
					WHEN @engg_task_descr = 'Conditional Multiline Fetch'
						AND @engg_task_req = 0
						THEN 'n'
					ELSE a.cond_ml_fetch
					END,
				a.data_save_req = CASE 
					WHEN @engg_task_descr = 'Data Saving Task'
						AND @engg_task_req = 1
						THEN 'Y'
					WHEN @engg_task_descr = 'Data Saving Task'
						AND @engg_task_req = 0
						THEN 'n'
					ELSE a.data_save_req
					END,
				a.hdr_fetch_req = CASE 
					WHEN @engg_task_descr = 'Header Fetch Required'
						AND @engg_task_req = 1
						THEN 'Y'
					WHEN @engg_task_descr = 'Header Fetch Required'
						AND @engg_task_req = 0
						THEN 'n'
					ELSE a.hdr_fetch_req
					END,
				a.hdr_save_req = CASE 
					WHEN @engg_task_descr = 'Header Save Required'
						AND @engg_task_req = 1
						THEN 'Y'
					WHEN @engg_task_descr = 'Header Save Required'
						AND @engg_task_req = 0
						THEN 'n'
					ELSE a.hdr_save_req
					END,
				a.incl_place_holder = CASE 
					WHEN @engg_task_descr = 'Include Message Place Holder'
						AND @engg_task_req = 1
						THEN 'Y'
					WHEN @engg_task_descr = 'Include Message Place Holder'
						AND @engg_task_req = 0
						THEN 'n'
					ELSE a.incl_place_holder
					END,
				a.ml_save_req = CASE 
					WHEN @engg_task_descr = 'ML Save Required'
						AND @engg_task_req = 1
						THEN 'Y'
					WHEN @engg_task_descr = 'ML Save Required'
						AND @engg_task_req = 0
						THEN 'n'
					ELSE a.ml_save_req
					END,
				a.Linkasui = CASE 
					WHEN @engg_task_descr = 'LinkAsUI Required'
						AND @engg_task_req = 1
						THEN 'Y'
					WHEN @engg_task_descr = 'LinkAsUI Required'
						AND @engg_task_req = 0
						THEN 'n'
					ELSE a.Linkasui
					END,
				a.Uiastrans = CASE 
					WHEN @engg_task_descr = 'Uiastrans Required'
						AND @engg_task_req = 1
						THEN 'Y'
					WHEN @engg_task_descr = 'Uiastrans Required'
						AND @engg_task_req = 0
						THEN 'n'
					ELSE a.Linkasui
					END,
				a.ml_fet_req = CASE 
					WHEN @engg_task_descr = 'Multiline Fetch Required'
						AND @engg_task_req = 1
						THEN 'Y'
					WHEN @engg_task_descr = 'Multiline Fetch Required'
						AND @engg_task_req = 0
						THEN 'n'
					ELSE a.ml_fet_req
					END,
				a.MLSaveSinglesegment = CASE 
					WHEN @engg_task_descr = 'ML Singlesegment Required'
						AND @engg_task_req = 1
						THEN 'Y'
					WHEN @engg_task_descr = 'ML Singlesegment Required'
						AND @engg_task_req = 0
						THEN 'n'
					ELSE a.MLSaveSinglesegment
					END, -- code changed against TECH-406
				a.proc_sel_rows = CASE 
					WHEN @engg_task_descr = 'Process only Selected Rows'
						AND @engg_task_req = 1
						THEN 'Y'
					WHEN @engg_task_descr = 'Process only Selected Rows'
						AND @engg_task_req = 0
						THEN 'n'
					ELSE a.proc_sel_rows
					END,
				--code added for the caseid : PNR2.0_27462 starts
				a.process_updrows = CASE 
					WHEN @engg_task_descr = 'Process only Updated Rows'
						AND @engg_task_req = 1
						THEN 'Y'
					WHEN @engg_task_descr = 'Process only Updated Rows'
						AND @engg_task_req = 0
						THEN 'n'
					ELSE a.process_updrows
					END,
				--code added for the caseid : PNR2.0_27462 ends
				a.refresh_on_save = CASE 
					WHEN @engg_task_descr = 'Refresh On Save'
						AND @engg_task_req = 1
						THEN 'Y'
					WHEN @engg_task_descr = 'Refresh On Save'
						AND @engg_task_req = 0
						THEN 'n'
					ELSE a.refresh_on_save
					END,
				a.hdr_ref_req = CASE 
					WHEN @engg_task_descr = 'Separate Header Refresh Method Required'
						AND @engg_task_req = 1
						THEN 'Y'
					WHEN @engg_task_descr = 'Separate Header Refresh Method Required'
						AND @engg_task_req = 0
						THEN 'n'
					ELSE a.hdr_ref_req
					END,
				a.hdr_check_req = CASE 
					WHEN @engg_task_descr = 'Separate Method for Header Check Required'
						AND @engg_task_req = 1
						THEN 'Y'
					WHEN @engg_task_descr = 'Separate Method for Header Check Required'
						AND @engg_task_req = 0
						THEN 'n'
					ELSE a.hdr_check_req
					END,
				a.err_handle_method = CASE 
					WHEN @engg_task_descr = 'Separate Method for Message Handling'
						AND @engg_task_req = 1
						THEN 'Y'
					WHEN @engg_task_descr = 'Separate Method for Message Handling'
						AND @engg_task_req = 0
						THEN 'n'
					ELSE a.err_handle_method
					END,
				a.usr_role_map = CASE 
					WHEN @engg_task_descr = 'Should User Role to be Mapped to All Methods'
						AND @engg_task_req = 1
						THEN 'y'
					WHEN @engg_task_descr = 'Should User Role to be Mapped to All Methods'
						AND @engg_task_req = 0
						THEN 'n'
					ELSE a.usr_role_map
					END,
				a.task_confirmation = CASE 
					WHEN @engg_task_descr = 'Task Conformation'
						AND @engg_task_req = 1
						THEN 'Y'
					WHEN @engg_task_descr = 'Task Conformation'
						AND @engg_task_req = 0
						THEN 'N'
					ELSE a.task_confirmation
					END,
				a.Logic_extensions = CASE 
					WHEN @engg_task_descr = 'Logic Extensions'
						AND @engg_task_req = 1
						THEN 'Y'
					WHEN @engg_task_descr = 'Logic Extensions'
						AND @engg_task_req = 0
						THEN 'N'
					ELSE a.Logic_extensions
					END,
				a.trn_scope_req = CASE 
					WHEN @engg_task_descr = 'Transaction Scope Required'
						AND @engg_task_req = 1
						THEN 'Y'
					WHEN @engg_task_descr = 'Transaction Scope Required'
						AND @engg_task_req = 0
						THEN 'N'
					ELSE a.trn_scope_req
					END,
				a.valid_on_init = CASE 
					WHEN @engg_task_descr = 'Validate On Initiate'
						AND @engg_task_req = 1
						THEN 'Y'
					WHEN @engg_task_descr = 'Validate On Initiate'
						AND @engg_task_req = 0
						THEN 'N'
					ELSE a.valid_on_init
					END,
				a.fprowno_req = CASE 
					WHEN @engg_task_descr = 'Fprowno Required'
						AND @engg_task_req = 1
						THEN 'Y'
					WHEN @engg_task_descr = 'Fprowno Required'
						AND @engg_task_req = 0
						THEN 'N'
					ELSE a.fprowno_req
					END, -- Code added for PNR2.0_20339 on 17-Dec-2008 by Gowrisankar M
				-- Code added For Bug Id : PNR2.0_33317		Starts
				a.alternate_db = CASE 
					WHEN @engg_task_descr = 'Configure Alternate Database'
						AND @engg_task_req = 1
						THEN 'Y'
					WHEN @engg_task_descr = 'Configure Alternate Database'
						AND @engg_task_req = 0
						THEN 'N'
					ELSE a.alternate_db
					END,
				a.sys_proc_sel_rows = CASE 
					WHEN @engg_task_descr = 'System Process only Selected Rows'
						AND @engg_task_req = 1
						THEN 'Y'
					WHEN @engg_task_descr = 'System Process only Selected Rows'
						AND @engg_task_req = 0
						THEN 'N'
					ELSE a.sys_proc_sel_rows
					END,
				a.sys_process_updrows = CASE 
					WHEN @engg_task_descr = 'System Process only Updated Rows'
						AND @engg_task_req = 1
						THEN 'Y'
					WHEN @engg_task_descr = 'System Process only Updated Rows'
						AND @engg_task_req = 0
						THEN 'N'
					ELSE a.sys_process_updrows
					END,
				a.sys_proc_selupd_rows = CASE 
					WHEN @engg_task_descr = 'System Process only selected Updated Rows'
						AND @engg_task_req = 1
						THEN 'Y'
					WHEN @engg_task_descr = 'System Process only selected Updated Rows'
						AND @engg_task_req = 0
						THEN 'N'
					ELSE a.sys_proc_selupd_rows
					END, -- PLF2.0_17847
				a.ParentContextInformation = CASE 
					WHEN @engg_task_descr = 'Parent Context Parameters'
						AND @engg_task_req = 1
						THEN 'Y'
					WHEN @engg_task_descr = 'Parent Context Parameters'
						AND @engg_task_req = 0
						THEN 'N'
					ELSE a.ParentContextInformation
					END,
				a.CurrentContextInformation = CASE 
					WHEN @engg_task_descr = 'Current Context Parameters'
						AND @engg_task_req = 1
						THEN 'Y'
					WHEN @engg_task_descr = 'Current Context Parameters'
						AND @engg_task_req = 0
						THEN 'N'
					ELSE a.CurrentContextInformation
					END,
				-- Code added For Bug Id : PNR2.0_33317		Ends
				a.ModeflagEnabled = CASE 
					WHEN @engg_task_descr = 'Modeflag Enabled'
						AND @engg_task_req = 1
						THEN 'Y'
					WHEN @engg_task_descr = 'Modeflag Enabled'
						AND @engg_task_req = 0
						THEN 'N'
					ELSE a.ModeflagEnabled
					END,
				-- Code added for Defect id: TECH-20897 starts
				a.bulkvalidation = CASE 
					WHEN @engg_task_descr = 'Bulk Validation'
						AND @engg_task_req = 1
						THEN 'Y'
					WHEN @engg_task_descr = 'Bulk Validation'
						AND @engg_task_req = 0
						THEN 'N'
					ELSE a.bulkvalidation
					END,
				-- code ends
				--Code Added for the Defect Id TECH-69327 starts
				a.BubbleMessage = CASE 
					WHEN @engg_task_descr = 'Bubble Message'
						AND @engg_task_req = 1
						THEN 'Y'
					WHEN @engg_task_descr = 'Bubble Message'
						AND @engg_task_req = 0
						THEN 'N'
					ELSE a.BubbleMessage
					END,				
				--Code Added for the Defect Id TECH-69327 Ends
				a.task_type_descr = @engg_tasktxt_desc,
				a.task_type_doc = @engg_tasttxt_docu,
				a.default_for = CASE 
					WHEN @engg_cmbtaskt_met = 'DoNotDefault'
						THEN 'DND'
					WHEN @engg_cmbtaskt_met = 'Initialize'
						THEN 'Init'
					ELSE @engg_cmbtaskt_met
					END
			FROM es_comp_task_type_mst a(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @engg_process_name
				AND component_name = @engg_comp_name
				AND task_type_name = @engg_cmbtask_patt
		END
	END

	--code modified by kiruthika for bugid:PNR2.0_10812
	UPDATE a
	SET a.task_type_descr = @engg_tasktxt_desc,
		a.task_type_doc = @engg_tasttxt_docu
	FROM es_comp_task_type_mst a(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND process_name = @engg_process_name
		AND component_name = @engg_comp_name
		AND task_type_name = @engg_cmbtask_patt

	--code modified by kiruthika for bugid:PNR2.0_10812
	SELECT @engg_a_fprowno 'engg_a_fprowno',
		@engg_k_fprowno 'engg_k_fprowno'

	SET NOCOUNT OFF
END

GO
IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_main13Spenggavengg_a' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON  ep_main13Spenggavengg_a TO PUBLIC
END
GO
