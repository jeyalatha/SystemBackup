/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		ep_layout_sp_savlnlnkml.sql
********************************************************************************/
/********************************************************************************/
/* Procedure    : ep_layout_sp_savlnlnkml                                       */
/* Description  :                                                               */
/********************************************************************************/
/* Project      :                                                               */
/* ECR          :                                                               */
/* Version      :                                                               */
/********************************************************************************/
/* Referenced   :                                                               */
/* Tables       :                                                               */
/********************************************************************************/
/* Development history                                                          */
/********************************************************************************/
/* Author       : Model Explorer                                                */
/* Date         : 22/Sep/2005                                                   */
/********************************************************************************/
/* Modification history                                                         */
/********************************************************************************/
/* Modified by : Sageetha L              */
/* Modified on : 11/04/2006  PNR2.0_7910            */
/* Description : Cyclic Ilbo Check Validation has to be added     */
/********************************************************************************/
/* Modified by : kiruthika R              */
/* Modified on : 17/05/2006         */
/* Description : PNR2.0_8517     */
/********************************************************************************/
/* Modified by : Balaji S             */
/* Modified on : 13/02/2007               */
/* Description : PNR2.0_12247             */
/********************************************************************************/
/* modified by   : Chanheetha N A        */
/* date     : 17-nov-2007         */
/* BugId    : PNR2.0_16023          */
/*******************************************************************************/
/* modified by			: Jeya Latha K											*/
/* date					: 07-Jan-2009											*/
/* BugId				: PNR2.0_20553 											*/
/********************************************************************************/
/* modified by			: Gankan G												*/
/* date					: 13-Sep-2012											*/
/* BugId				: PLF2.0_01435 											*/
/* Description			: Validation added to prevent changes in traverasl		*/
/*						  without modification in resolved links				*/
/* Primary BugID		: PLF2.0_01619											*/
/********************************************************************************/
/* modified by			: Kanagavel.A											*/
/* date					: 13/06/2014											*/
/* Description			: Code modified for adding link controls in state 		*/
/*						  handling.												*/
/********************************************************************************/
/* Modified by  : Veena U                                                  */
/* Description  : Width,Height,Toolbar not Required controls Addition   */
/* Date         : 25-Feb-2015                                                  */
/* Call ID		: PLF2.0_11499                                                 */
/********************************************************************************/
/* Modified by  	: Kanagavel A                                                  */
/* Description  	: Activity ui is added to avoid component descr duplicate issue  under diff process*/
/* Date         	: 21-Oct-2016                                                  */
/********************************************************************************/
/* Modified by : Jeya Latha K/Ganesh Prabhu S	for callid TECH-7349				*/
/* Modified on : 14-03-2017				 											*/
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and New Feature Organization chart */
/***********************************************************************************/
/* Modified by : Ganesh Prabhu S/Ranjitha R      for callid  TECH-10118                   */
/* Modified on : 30-May-2017                                                                                        */
/* Description : Platform Feature Release                                                              */
/*************************************************************************************/
/* Modified By : Jeya Latha K/ Venkatesan K Date: 04-Dec-2018  Defect ID: TECH-28806 */
/* Modified by : Jeya Latha K/Venkatesan K  Date: 17-Jun-2019  Defect ID: TECH-34971 */
/*************************************************************************************/
/* Modified By : Muneeswari G for Defect ID: TECH-74584									*/
/* Modified on : 17-Nov-2022															*/
/*Description : For base control type as link, traversal should be allowed in modeling  
				if the same control bt synonym has been involved in state task.			*/
/***************************************************************************************/
CREATE PROCEDURE ep_layout_sp_savlnlnkml
	@ctxt_language engg_ctxt_language, --Input
	@ctxt_ouinstance engg_ctxt_ouinstance, --Input
	@ctxt_service engg_ctxt_service, --Input
	@ctxt_user engg_ctxt_user, --Input
	@engg_act_descr engg_description, --Input
	@engg_component engg_description, --Input
	@engg_customer_name engg_name, --Input
	@engg_links_link_act engg_description, --Input
	@engg_links_link_comp engg_description, --Input
	@engg_links_link_type engg_name, --Input
	@engg_links_link_ui engg_description, --Input
	@engg_links_pcv_caption engg_description, --Input
	@engg_lnk_page_descr engg_description, --Input
	@engg_process_descr engg_description, --Input
	@engg_project_name engg_name, --Input
	@engg_req_no engg_name, --Input
	@engg_ui_descr engg_description, --Input
	@guid engg_guid, --Input
	@modeflag engg_modeflag, --Input
	@fprowno engg_rowno, --Input/Output
	@engg_links_asso_ctrl engg_name, --Input
	@engg_links_width number, --Input 
	@engg_links_height number, --Input 
	@engg_toolbar_notreq checkflag_int, --Input 
	@engg_Launch_type engg_name,
	@m_errorid engg_seq_no OUTPUT --To Return Execution Status
AS
BEGIN
	-- nocount should be switched on to prevent phantom rows
	SET NOCOUNT ON

	-- @m_errorid should be 0 to Indicate Success
	SELECT @m_errorid = 0

	--declaration of temporary variables
	--temporary and formal parameters mapping
	SELECT @ctxt_service = ltrim(rtrim(@ctxt_service))

	SELECT @ctxt_user = ltrim(rtrim(@ctxt_user))

	SELECT @engg_act_descr = ltrim(rtrim(@engg_act_descr))

	SELECT @engg_component = ltrim(rtrim(@engg_component))

	SELECT @engg_customer_name = ltrim(rtrim(@engg_customer_name))

	SELECT @engg_links_link_act = ltrim(rtrim(@engg_links_link_act))

	SELECT @engg_links_link_comp = ltrim(rtrim(@engg_links_link_comp))

	SELECT @engg_links_link_type = ltrim(rtrim(@engg_links_link_type))

	SELECT @engg_links_link_ui = ltrim(rtrim(@engg_links_link_ui))

	SELECT @engg_links_pcv_caption = ltrim(rtrim(@engg_links_pcv_caption))

	SELECT @engg_lnk_page_descr = ltrim(rtrim(@engg_lnk_page_descr))

	SELECT @engg_process_descr = ltrim(rtrim(@engg_process_descr))

	SELECT @engg_project_name = ltrim(rtrim(@engg_project_name))

	SELECT @engg_req_no = ltrim(rtrim(@engg_req_no))

	SELECT @engg_ui_descr = ltrim(rtrim(@engg_ui_descr))

	SELECT @guid = ltrim(rtrim(@guid))

	SELECT @modeflag = ltrim(rtrim(@modeflag))

	SELECT @engg_links_asso_ctrl = ltrim(rtrim(@engg_links_asso_ctrl))

	SELECT @engg_links_width = ltrim(rtrim(@engg_links_width))

	SELECT @engg_links_height = ltrim(rtrim(@engg_links_height))

	SELECT @engg_toolbar_notreq = ltrim(rtrim(@engg_toolbar_notreq))

	SELECT @engg_Launch_type = ltrim(rtrim(@engg_Launch_type))

	--null checking
	IF @ctxt_language = - 915
		SELECT @ctxt_language = NULL

	IF @ctxt_ouinstance = - 915
		SELECT @ctxt_ouinstance = NULL

	IF @ctxt_service = '~#~'
		SELECT @ctxt_service = NULL

	IF @ctxt_user = '~#~'
		SELECT @ctxt_user = NULL

	IF @engg_act_descr = '~#~'
		SELECT @engg_act_descr = NULL

	IF @engg_component = '~#~'
		SELECT @engg_component = NULL

	IF @engg_customer_name = '~#~'
		SELECT @engg_customer_name = NULL

	IF @engg_links_link_act = '~#~'
		SELECT @engg_links_link_act = NULL

	IF @engg_links_link_comp = '~#~'
		SELECT @engg_links_link_comp = NULL

	IF @engg_links_link_type = '~#~'
		SELECT @engg_links_link_type = NULL

	IF @engg_links_link_ui = '~#~'
		SELECT @engg_links_link_ui = NULL

	IF @engg_links_pcv_caption = '~#~'
		SELECT @engg_links_pcv_caption = NULL

	IF @engg_lnk_page_descr = '~#~'
		SELECT @engg_lnk_page_descr = NULL

	IF @engg_process_descr = '~#~'
		SELECT @engg_process_descr = NULL

	IF @engg_project_name = '~#~'
		SELECT @engg_project_name = NULL

	IF @engg_req_no = '~#~'
		SELECT @engg_req_no = NULL

	IF @engg_ui_descr = '~#~'
		SELECT @engg_ui_descr = NULL

	IF @guid = '~#~'
		SELECT @guid = NULL

	IF @modeflag = '~#~'
		SELECT @modeflag = NULL

	IF @fprowno = - 915
		SELECT @fprowno = NULL

	IF @engg_links_asso_ctrl = '~#~'
		SELECT @engg_links_asso_ctrl = NULL

	IF @engg_links_width = - 915
		SELECT @engg_links_width = NULL

	IF @engg_links_height = - 915
		SELECT @engg_links_height = NULL

	IF @engg_toolbar_notreq = - 915
		SELECT @engg_toolbar_notreq = NULL

	IF @engg_Launch_type = '~#~'
		SELECT @engg_Launch_type = NULL

	/*
--OuputList
Select null 'fprowno' from ***
*/
	--errors mapped
	DECLARE @tmp_comp_name engg_name,
		@tmp_proc engg_name,
		@tmp_acty_name engg_name,
		@tmp_ui_name engg_name,
		@tmp_sec_btsyn engg_name,
		@tmp_link_comp engg_name,
		@tmp_link_act engg_name,
		@tmp_link_ui engg_name,
		@count engg_seqno,
		@msg engg_description,
		@sub_name engg_name,
		@taskname engg_name

	--Code added for the BugID:PLF2.0_01435
	SELECT @fprowno = @fprowno + 1

	DECLARE @engg_base_req_no engg_name

	SELECT @engg_base_req_no = 'BASE'

	--select process name for description
	SELECT @tmp_proc = rtrim(process_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_req_no)
		AND process_descr = rtrim(@engg_process_descr)

	--select component name for description
	SELECT @tmp_comp_name = rtrim(component_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_descr = rtrim(@engg_component)

	--select activity name for description
	SELECT @tmp_acty_name = rtrim(activity_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp_name)
		AND activity_descr = rtrim(@engg_act_descr)

	--select UI name for description
	SELECT @tmp_ui_name = rtrim(ui_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp_name)
		AND activity_name = rtrim(@tmp_acty_name)
		AND ui_descr = rtrim(@engg_ui_descr)

	--Code added for the BugID:PLF2.0_01435 starts
	SELECT @sub_name = subscription_name
	FROM re_subscription(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND process_name = @tmp_proc
		AND component_name = @tmp_comp_name
		AND activity_name = @tmp_acty_name
		AND ui_name = @tmp_ui_name
		AND control_bt_synonym = @engg_links_pcv_caption

--commented by 13026 for tech id TECH-74584
		
	----Kanagavel starts
	--IF @ModeFlag IN (
	--		'U',
	--		'X',
	--		'Y',
	--		'I'
	--		)
	--BEGIN
	--	IF @engg_links_link_type = 'Link'
	--	BEGIN
	--		SELECT @taskname = task_name
	--		FROM ep_action_mst(NOLOCK)
	--		WHERE customer_name = rtrim(@engg_customer_name)
	--			AND project_name = rtrim(@engg_project_name)
	--			AND process_name = @tmp_proc
	--			AND component_name = @tmp_comp_name
	--			AND activity_name = @tmp_acty_name
	--			AND ui_name = @tmp_ui_name
	--			AND primary_control_bts = @engg_links_pcv_caption

	--		IF EXISTS (
	--				SELECT 'X'
	--				FROM ep_ui_state_task_dtl(NOLOCK)
	--				WHERE customer_name = rtrim(@engg_customer_name)
	--					AND project_name = rtrim(@engg_project_name)
	--					AND process_name = @tmp_proc
	--					AND component_name = @tmp_comp_name
	--					AND activity_name = @tmp_acty_name
	--					AND ui_name = @tmp_ui_name
	--					AND task_name = @taskname
	--					AND isnull(state_id, '') <> ''
					
	--				UNION
					
	--				SELECT 'X'
	--				FROM ep_ui_state_task_mst(NOLOCK)
	--				WHERE customer_name = rtrim(@engg_customer_name)
	--					AND project_name = rtrim(@engg_project_name)
	--					AND process_name = @tmp_proc
	--					AND component_name = @tmp_comp_name
	--					AND activity_name = @tmp_acty_name
	--					AND ui_name = @tmp_ui_name
	--					AND task_name = @taskname
	--				)
	--		BEGIN
	--			SELECT @msg = 'For Link "' + @engg_links_pcv_caption + '" is involved in state.Traversal is not allowed '

	--			RAISERROR (
	--					@msg,
	--					16,
	--					1
	--					)
	--		END
	--	END
	--END

	--Kanagavel ends
	--commented by 13026 for tech id TECH-74584
	--Code added for the BugID:PLF2.0_01435 ends
	-- code modified by shafina on 14-jan-2004 To save the linked component , activity and ui names in table
	--Check whether linkked component is null
	-- code modified by shafina on 10-feb-2004
	IF @modeflag <> 'D'
	BEGIN
		/*
if @engg_links_link_comp is null
begin
select @msg = 'Linked Component cannot be null at row '+ convert(char(5), @fprowno)
exec  engg_error_sp 'ep_layout_sp_savlnlnkml',8,@msg,
@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,
'','','','',@m_errorid output
if @m_errorid <> 0
return
end
*/
		--select component name for link comp description
		--Activity ui is added to avoid component descr duplicate issue by Kanagavel A
		SELECT @tmp_link_comp = isnull(rtrim(component_name), '')
		FROM fw_bpt_re_namedesc_vw(NOLOCK)
		WHERE customer_name = rtrim(@engg_customer_name)
			AND project_name = rtrim(@engg_project_name)
			AND component_descr = rtrim(@engg_links_link_comp)
			AND activity_descr = rtrim(@engg_links_link_act)
			AND ui_descr = rtrim(@engg_links_link_ui)

		IF isnull(@tmp_link_comp, '') = ''
			SELECT @tmp_link_comp = isnull(rtrim(component_name), '')
			-- code modified by shafina on 04-Feb-2005 for PREVIEWENG203ACC_000126  (in links tab , when fetch details is clicked , link details get duplicated.)
			FROM fw_bpt_re_namedesc_vw(NOLOCK)
			WHERE customer_name = rtrim(@engg_customer_name)
				AND project_name = rtrim(@engg_project_name)
				-- code modified by shafina on 28-July-2004 for PREVIEWENG203ACC_000080
				--   and  req_no   = rtrim(@engg_req_no)
				--  and  process_name = rtrim(@tmp_proc)
				AND component_descr = rtrim(@engg_links_link_comp)

		--  if @tmp_link_comp  is null or @tmp_link_comp  = ''
		--   select @tmp_link_comp  = @engg_links_link_comp
		-- code commented by shafina on 16-Nov-2004 for PREVIEWPF204SYS_000033 (Tab(Links) - While entering invalid linked Component,activity,UI descriptions error message not raised.)
		IF (
				isnull(@engg_links_link_comp, '') <> ''
				OR isnull(@engg_links_link_act, '') <> ''
				OR isnull(@engg_links_link_ui, '') <> ''
				)
		BEGIN
			--Check for the existence of linked component
			-- code modified by shafina on 07-Feb-2005 for PREVIEWENG203SYS_000201(Subquery returned more than 1 value. This is not permitted when the subquery follows =, !=, <, <= , >, >= or when the subquery is used as an expression. When I tried to remove links in a UI, this error is appearing ramcovm85)
			SELECT @count = isnull(count('X'), 0)
			FROM fw_bpt_re_namedesc_vw(NOLOCK)
			WHERE customer_name = rtrim(@engg_customer_name)
				AND project_name = rtrim(@engg_project_name)
				--   and  req_no   = rtrim(@engg_req_no)
				--   and  process_name = rtrim(@tmp_proc)
				AND component_name = rtrim(@tmp_link_comp)

			IF @count < 1
			BEGIN
				SELECT @msg = 'Linked Component  at row ' + convert(CHAR(5), @fprowno) + ' does not exist'

				EXEC engg_error_sp 'ep_layout_sp_savlnlnkml',
					1,
					@msg,
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					'',
					'',
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid <> 0
					RETURN
			END

			--Check whether linkked activity is null
			IF @engg_links_link_act IS NULL
			BEGIN
				SELECT @msg = 'Linked Activity cannot be null at row ' + convert(CHAR(5), @fprowno)

				EXEC engg_error_sp 'ep_layout_sp_savlnlnkml',
					6,
					@msg,
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					'',
					'',
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid <> 0
					RETURN
			END

			--select activity name for Link Act description
			SELECT @tmp_link_act = isnull(rtrim(activity_name), '')
			FROM fw_bpt_re_namedesc_vw(NOLOCK)
			WHERE customer_name = rtrim(@engg_customer_name)
				AND project_name = rtrim(@engg_project_name)
				--    and req_no  = rtrim(@engg_req_no)
				--  and process_name = rtrim(@tmp_proc)
				AND component_name = rtrim(@tmp_link_comp)
				AND activity_descr = rtrim(@engg_links_link_act)

			--  if @tmp_link_act  is null or @tmp_link_act  = ''
			--   select @tmp_link_act  = @engg_links_link_act
			--Check for the existence of linked activity
			SELECT @count = isnull(count('X'), 0)
			FROM fw_bpt_re_namedesc_vw(NOLOCK)
			WHERE customer_name = rtrim(@engg_customer_name)
				AND project_name = rtrim(@engg_project_name)
				--   and req_no   = rtrim(@engg_req_no)
				--   and process_name = rtrim(@tmp_proc)
				AND component_name = rtrim(@tmp_link_comp)
				AND activity_name = rtrim(@tmp_link_act)

			IF @count < 1
			BEGIN
				SELECT @msg = 'Linked Activity  at row ' + convert(CHAR(5), @fprowno) + 'does not exist'

				EXEC engg_error_sp 'ep_layout_sp_savlnlnkml',
					2,
					@msg,
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					'',
					'',
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid <> 0
					RETURN
			END

			--Check whether linkked UI is null
			IF @engg_links_link_ui IS NULL
			BEGIN
				SELECT @msg = 'Linked UI cannot be null at row ' + convert(CHAR(5), @fprowno)

				EXEC engg_error_sp 'ep_layout_sp_savlnlnkml',
					5,
					@msg,
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					'',
					'',
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid <> 0
					RETURN
			END

			--select UI name for description
			--    select @tmp_link_ui  = isnull(rtrim(ui_name),'')
			--    from  fw_bpt_re_namedesc_vw (nolock)
			--    where customer_name  = rtrim(@engg_customer_name)
			--    and project_name = rtrim(@engg_project_name)
			-- --    and req_no  = rtrim(@engg_req_no)
			--   --  and process_name = rtrim(@tmp_proc)
			--    and component_name  = rtrim(@tmp_link_comp)
			--    and activity_name = rtrim(@tmp_link_act)
			--    and ltrim(rtrim(ui_descr)) = ltrim(rtrim(@engg_links_link_ui))
			--Code modified for bugID : PNR2.0_12247
			SELECT @tmp_link_ui = isnull(rtrim(ui_name), '')
			FROM ep_ui_req_dtl(NOLOCK)
			WHERE customer_name = rtrim(@engg_customer_name)
				AND project_name = rtrim(@engg_project_name)
				AND component_name = rtrim(@tmp_link_comp)
				AND activity_name = rtrim(@tmp_link_act)
				AND ltrim(rtrim(ui_descr)) = ltrim(rtrim(@engg_links_link_ui))

			--  if @tmp_link_ui  is null or @tmp_link_ui  = ''
			--   select @tmp_link_ui  = @engg_links_link_ui
			--Check for the existence of linked ui
			SELECT @count = isnull(count('X'), 0)
			FROM ep_ui_req_dtl(NOLOCK)
			WHERE customer_name = rtrim(@engg_customer_name)
				AND project_name = rtrim(@engg_project_name)
				--   and  req_no  = rtrim(@engg_req_no)
				--   and  process_name = rtrim(@tmp_proc)
				AND component_name = rtrim(@tmp_link_comp)
				AND activity_name = rtrim(@tmp_link_act)
				AND ui_name = rtrim(@tmp_link_ui)

			IF @count < 1
			BEGIN
				SELECT @msg = 'Linked UI  at row ' + convert(CHAR(5), @fprowno) + 'does not exist'

				EXEC engg_error_sp 'ep_layout_sp_savlnlnkml',
					3,
					@msg,
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					'',
					'',
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid <> 0
					RETURN
			END
		END
	END

	--  select @tmp_link_comp  = isnull(rtrim(@engg_links_link_comp),''),
	--    @tmp_link_act  = isnull(rtrim(@engg_links_link_act),''),
	--    @tmp_link_ui  = isnull(rtrim(@engg_links_link_ui),'')
	/* Code Added For BugId : PNR2.0_8517 */
	IF @modeflag <> 'D'
	BEGIN
		/* Code Added For BugId : PNR2.0_7910 */
		IF (@tmp_comp_name = @tmp_link_comp)
			AND (@tmp_acty_name = @tmp_link_act)
			AND (@tmp_ui_name = @tmp_link_ui)
		BEGIN
			SELECT @msg = 'Trying to Link with Same UI at RowNo <%1> .Please Remove & Proceed'

			EXEC engg_error_sp 'ep_layout_sp_savlnlnkml',
				3,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@fprowno,
				'',
				'',
				'',
				@m_errorid OUTPUT

			IF @m_errorid <> 0
				RETURN
		END
	END

	/* Fetch the sec bt syn for the ui/page/control */
	SELECT @tmp_sec_btsyn = a.section_bt_synonym
	FROM (
		SELECT rtrim(section_bt_synonym) section_bt_synonym
		FROM ep_ui_control_dtl(NOLOCK)
		WHERE customer_name = rtrim(@engg_customer_name)
			AND project_name = rtrim(@engg_project_name)
			AND req_no = rtrim(@engg_base_req_no)
			AND process_name = rtrim(@tmp_proc)
			AND component_name = rtrim(@tmp_comp_name)
			AND activity_name = rtrim(@tmp_acty_name)
			AND ui_name = rtrim(@tmp_ui_name)
			AND page_bt_synonym = rtrim(@engg_lnk_page_descr)
			AND control_bt_synonym = rtrim(@engg_links_pcv_caption)
		
		UNION
		
		SELECT rtrim(section_bt_synonym) section_bt_synonym
		FROM ep_ui_grid_dtl(NOLOCK)
		WHERE customer_name = rtrim(@engg_customer_name)
			AND project_name = rtrim(@engg_project_name)
			AND req_no = rtrim(@engg_base_req_no)
			AND process_name = rtrim(@tmp_proc)
			AND component_name = rtrim(@tmp_comp_name)
			AND activity_name = rtrim(@tmp_acty_name)
			AND ui_name = rtrim(@tmp_ui_name)
			AND page_bt_synonym = rtrim(@engg_lnk_page_descr)
			AND column_bt_synonym = rtrim(@engg_links_pcv_caption)
		) a

	-- Code added for TECH-28806 Starts
	IF isnull(@tmp_sec_btsyn, '') = ''
	BEGIN
		SELECT @tmp_sec_btsyn = SectionName
		FROM ngplf_wr_template_action(NOLOCK)
		WHERE CustomerID = rtrim(@engg_customer_name)
			AND ProjectID = rtrim(@engg_project_name)
			AND DocNo = rtrim(@engg_base_req_no)
			AND ProcessName = rtrim(@tmp_proc)
			AND ComponentName = rtrim(@tmp_comp_name)
			AND ActivityName = rtrim(@tmp_acty_name)
			AND UIName = rtrim(@tmp_ui_name)
			AND PageName = rtrim(@engg_lnk_page_descr)
			AND ControlName + '_' + actionname = rtrim(@engg_links_pcv_caption)
	END

	-- Code added for TECH-28806 Ends
	IF rtrim(@engg_links_link_type) = 'link'
		SELECT @engg_links_link_type = 'lnk'
	ELSE IF rtrim(@engg_links_link_type) = 'help'
		SELECT @engg_links_link_type = 'hlp'

	--Code added for the BugID:PLF2.0_01435 starts
	IF EXISTS (
			SELECT 'x'
			FROM sysobjects(NOLOCK)
			WHERE name = 'de_customer_space'
				AND type = 'u'
			)
	BEGIN
		IF isnull(@sub_name, '') <> ''
		BEGIN
			IF EXISTS (
					SELECT 'x'
					FROM re_resolved_link(NOLOCK)
					WHERE customer_name = rtrim(@engg_customer_name)
						AND project_name = rtrim(@engg_project_name)
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp_name
						AND activity_name = @tmp_acty_name
						AND ui_name = @tmp_ui_name
						AND subscription_name = @sub_name
						AND publication_comp_name <> @tmp_link_comp
						AND publication_act_name <> @tmp_link_act
						AND publication_ui_name <> @tmp_link_ui
					)
			BEGIN
				SELECT @msg = 'Control ' + @engg_links_pcv_caption + ' at rowno:' + cast(@fprowno AS VARCHAR) + ' is mapped with resolved links to another publication screen. Please modify the exisiting details at requirement level and try modifying the traversal information.'

				RAISERROR (
						@msg,
						16,
						1
						)

				RETURN
			END
		END
	END

	--Code added for the BugID:PLF2.0_01435 ends
	/* For each row that does not exist in traversal details,
insert an entry for the traversal with the following information:
BT Synonym, Link Type, Linked Component, Linked Activity, Linked UI along
with Project, Customer, Process, Component, Activity, UI and Page names */
	IF @modeflag <> 'D'
	BEGIN
		IF (
				SELECT count('X')
				FROM ep_ui_traversal_dtl(NOLOCK)
				WHERE customer_name = rtrim(@engg_customer_name)
					AND project_name = rtrim(@engg_project_name)
					AND req_no = rtrim(@engg_base_req_no)
					AND process_name = rtrim(@tmp_proc)
					AND component_name = rtrim(@tmp_comp_name)
					AND activity_name = rtrim(@tmp_acty_name)
					AND ui_name = rtrim(@tmp_ui_name)
					AND control_bt_synonym = rtrim(@engg_links_pcv_caption)
					AND link_type = rtrim(@engg_links_link_type)
				) = 0
		BEGIN
			/*sp for inserting data in the table*/
			EXEC ep_ui_traversal_dtl_sp_ins @ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@engg_customer_name,
				@engg_project_name,
				@engg_base_req_no,
				@tmp_proc,
				@tmp_comp_name,
				@tmp_acty_name,
				@tmp_ui_name,
				@engg_lnk_page_descr, -- btsyn will be fetched and not the descr ?
				@tmp_sec_btsyn,
				@engg_links_pcv_caption, -- btsyn will be fetched and not the caption ?
				@engg_links_link_type,
				@tmp_link_comp,
				@tmp_link_act,
				@tmp_link_ui,
				@engg_links_asso_ctrl,
				1,
				@engg_req_no,
				@engg_links_width,
				@engg_links_height,
				@engg_toolbar_notreq,
				@engg_launch_type,
				@m_errorid OUTPUT --chan

			IF @m_errorid <> 0
				RETURN
		END
		ELSE
		BEGIN
			/* For each row that is updated, update the following information for the cotnrol:
		Linked Component, Linked Activity, Linked UI */
			UPDATE ep_ui_traversal_dtl
			SET linked_component = rtrim(@tmp_link_comp),
				linked_activity = rtrim(@tmp_link_act),
				linked_ui = rtrim(@tmp_link_ui),
				associated_ctrl_bt_synonym = @engg_links_asso_ctrl,
				modifiedby = rtrim(@ctxt_user),
				modifieddate = getdate(),
				Width = rtrim(@engg_links_width),
				Height = rtrim(@engg_links_Height),
				Toolbar_notreq = rtrim(isnull(@engg_toolbar_notreq, 0)),
				LinkLaunchType = rtrim(isnull(@engg_Launch_type, ''))
			WHERE customer_name = rtrim(@engg_customer_name)
				AND project_name = rtrim(@engg_project_name)
				AND req_no = rtrim(@engg_base_req_no)
				AND process_name = rtrim(@tmp_proc)
				AND component_name = rtrim(@tmp_comp_name)
				AND activity_name = rtrim(@tmp_acty_name)
				AND ui_name = rtrim(@tmp_ui_name)
				AND page_bt_synonym = rtrim(@engg_lnk_page_descr)
				--   and section_bt_synonym = rtrim(@tmp_sec_btsyn)
				AND control_bt_synonym = rtrim(@engg_links_pcv_caption)
				-- code modified by shafina on 20-Nov-2004 for Primary key modification in traversal tables.
				AND link_type = rtrim(@engg_links_link_type)
		END
				--IF exists (select * --'X'
				--FROM ep_template_action (nolock)
				--where CustomerID  = rtrim(@engg_customer_name)
				--and ProjectID  = rtrim(@engg_project_name)
				--and DocNo    = rtrim(@engg_base_req_no)
				--and ProcessName  = rtrim(@tmp_proc)
				--and ComponentName  = rtrim(@tmp_comp_name)
				--and ActivityName  = rtrim(@tmp_acty_name)
				--and UIName    = rtrim(@tmp_ui_name)
				--and PageName  = rtrim(@engg_lnk_page_descr)
				----   and section_bt_synonym = rtrim(@tmp_sec_btsyn)
				--and ControlName + TemplateID = rtrim(@engg_links_pcv_caption)
				--)
				--Begin
				--		UPDATE ep_template_action set 
				--				linked_component = rtrim(@tmp_link_comp),
				--				linked_activity  = rtrim(@tmp_link_act),
				--				linked_ui  = rtrim(@tmp_link_ui),
				--				associated_ctrl_bt_synonym = @engg_links_asso_ctrl ,
				--				modifiedby   = rtrim(@ctxt_user),
				--				modifieddate  = getdate(),
				--				Width	=	rtrim(@engg_links_width),
				--				Height	=	rtrim(@engg_links_Height),
				--				Toolbar_notreq	=	rtrim(isnull(@engg_toolbar_notreq,0)),
				--				LinkLaunchType =	rtrim(isnull(@engg_Launch_type,''))
				--		where CustomerID  = rtrim(@engg_customer_name)
				--		and ProjectID  = rtrim(@engg_project_name)
				--		and DocNo    = rtrim(@engg_base_req_no)
				--		and ProcessName  = rtrim(@tmp_proc)
				--		and ComponentName  = rtrim(@tmp_comp_name)
				--		and ActivityName  = rtrim(@tmp_acty_name)
				--		and UIName    = rtrim(@tmp_ui_name)
				--		and PageName  = rtrim(@engg_lnk_page_descr)
				--		--   and section_bt_synonym = rtrim(@tmp_sec_btsyn)
				--		and ControlName + TemplateID = rtrim(@engg_links_pcv_caption)
				--END
	END

	IF @modeflag = 'D'
	BEGIN
		IF EXISTS (
				SELECT 'X'
				FROM ep_layout_ezeeview_sp(NOLOCK)
				WHERE customer_name = rtrim(@engg_customer_name)
					AND project_name = rtrim(@engg_project_name)
					AND req_no = rtrim(@engg_base_req_no)
					AND process_name = rtrim(@tmp_proc)
					AND component_name = rtrim(@tmp_comp_name)
					AND activity_name = rtrim(@tmp_acty_name)
					AND ui_name = rtrim(@tmp_ui_name)
					AND page_bt_synonym = rtrim(@engg_lnk_page_descr)
					AND Link_ControlName = rtrim(@engg_links_pcv_caption)
				)
		BEGIN
			SELECT @msg = 'Selected Primary Control is enabled for EZee View. Cannot Delete. Error at Row No:<%1>'

			EXEC engg_error_sp 'ep_layout_sp_savlnlnkml',
				3,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@fprowno,
				'',
				'',
				'',
				@m_errorid OUTPUT

			IF @m_errorid <> 0
				RETURN
		END

		EXEC ep_ui_traversal_dtl_sp_del @ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			@engg_customer_name,
			@engg_project_name,
			@engg_base_req_no,
			@tmp_proc,
			@tmp_comp_name,
			@tmp_acty_name,
			@tmp_ui_name,
			@engg_lnk_page_descr, -- btsyn will be fetched and not the descr ?
			@tmp_sec_btsyn,
			@engg_links_pcv_caption,
			@engg_links_link_type, -- btsyn will be fetched and not the caption ?
			@m_errorid OUTPUT

		IF @m_errorid <> 0
			RETURN
	END

	--output parameters
	SELECT @fprowno 'fprowno'

	SET NOCOUNT OFF
END

