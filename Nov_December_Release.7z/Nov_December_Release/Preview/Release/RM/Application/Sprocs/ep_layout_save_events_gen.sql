IF EXISTS(SELECT 'X' From SYSOBJECTS WHERE NAME ='ep_layout_save_events_gen' AND TYPE='P')
   BEGIN
        DROP PROC ep_layout_save_events_gen
   END
GO 
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		ep_layout_save_events_gen.sql
********************************************************************************/
/*      V E R S I O N      :  2.0.4    */
/*      Released By        :  Ptech    */
/*      Release Comments   :  Released On 14-Mar-2017    */
/********************************************************************************/
/* Modified by : Jeya Latha K	for callid TECH-7349				*/
/* Modified on : 14-03-2017				 											*/
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and New Feature Organization chart */
/***********************************************************************************/
/* Modified by : Ganesh Prabhu S/Ranjitha R      for callid  TECH-10118                   */
/* Modified on : 30-May-2017                                                              */
/* Description : Platform Feature Release                                                 */
/*******************************************************************************************/
/* Modified by : Ranjitha R      for callid  TECH-16126                                    */
/* Modified on : 21-Nov-2017                                                               */
/* Description : Platform Feature Release                                                  */
/* Modified by : Jeya Latha K				     Date: 28-Jun-2019  Defect ID : TECH-35368 */
/* Modified by : Priyadharshini U/Rajeswari M	 Date: 29-Jan-2020  Defect ID : TECH-42483 */
/* Modified by : Jeya Latha K                    Date: 27-May-2020	Defect ID : TECH-46646 */
/*******************************************************************************************/
/* Modified by : Ponmalar A		Date: 02-Dec-2022       Defect ID : TECH-75230 				*/
/* Modified by : Venkatesan K   Date: 27-Oct-2022		Defect ID : TECH-74049 		   		*/
/*******************************************************************************************/
create PROCEDURE ep_layout_save_events_gen
	@ctxt_language engg_ctxt_language,
	@ctxt_ouinstance engg_ctxt_ouinstance,
	@ctxt_service engg_ctxt_service,
	@ctxt_user engg_ctxt_user,
	@engg_customer_name engg_name, --Input   
	@engg_project_name engg_name, --Input   
	@engg_process_name engg_name, --Input   
	@engg_component engg_name, --Input   
	@tmp_act engg_name, --Input   
	@tmp_ui engg_name, --Input 
	@engg_cont_page_bts engg_name, --Input 
	@engg_cont_sec_bts engg_name, --Input 
	@engg_cont_btsynname engg_name, --Input 
	@engg_req_no engg_name, --Input   
	@engg_cont_elem_type engg_name, --Input   
	@base_ctrl_type_tmp engg_name, --Input   
	@tmp_tasktype engg_name, --Input   		--TECH-74049
	@tmp_taskdesc engg_description, --Input --TECH-74049
	@m_errorid engg_seqno OUTPUT
AS
BEGIN
	DECLARE @eventdesc engg_name,
		@eventsreq engg_flag,
		@tasktype engg_name,
		@eventdesc1 engg_name,
		@col_bt_syn engg_name,
		@comp_pfx_tmp engg_name,
		@ui_pfx_tmp engg_name,
		@ctrl_pfx_tmp engg_name,
		@taskname engg_name,
		@taskseq engg_seqno,
		@tmp_tasknamesuffix engg_flag	--TECH-74049

	SELECT @comp_pfx_tmp = current_value
	FROM es_comp_param_mst(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND process_name = @engg_process_name
		AND component_name = @engg_component
		AND param_category = 'compprefix'

	SELECT @ui_pfx_tmp = page_prefix
	FROM ep_ui_page_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND req_no = @engg_req_no
		AND process_name = @engg_process_name
		AND component_name = @engg_component
		AND activity_name = @tmp_act
		AND ui_name = @tmp_ui
		AND page_bt_synonym = '[mainscreen]'


	SELECT @ctrl_pfx_tmp = control_prefix
	FROM ep_ui_control_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND req_no = @engg_req_no
		AND process_name = @engg_process_name
		AND component_name = @engg_component
		AND activity_name = @tmp_act
		AND ui_name = @tmp_ui
		AND page_bt_synonym = @engg_cont_page_bts
		AND section_bt_synonym = @engg_cont_sec_bts
		AND control_bt_synonym = @engg_cont_btsynname

	--select 'tt', @base_ctrl_type_tmp
	IF @engg_cont_elem_type = 'MobileGrid'
	BEGIN
		DECLARE eventsreq_cur CURSOR
		FOR
		SELECT DISTINCT events_desc,
			events_required,
			tasktype
		FROM es_ctrl_type_events_mst(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND process_name = @engg_process_name
			AND component_name = @engg_component
			--AND ctrl_type_name = @engg_cont_elem_type
			AND req_no = @engg_req_no
			AND	events_desc = @base_ctrl_type_tmp
			--AND base_ctrl_type = @base_ctrl_type_tmp
	END
	ELSE
	BEGIN
		DECLARE eventsreq_cur CURSOR
		FOR
		SELECT DISTINCT events_desc,
			events_required,
			tasktype
		FROM es_ctrl_type_events_mst(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND process_name = @engg_process_name
			AND component_name = @engg_component
			AND ctrl_type_name = @engg_cont_elem_type
			AND req_no = @engg_req_no
			AND base_ctrl_type = @base_ctrl_type_tmp
	END
	OPEN eventsreq_cur

	WHILE 1 = 1
	BEGIN
		FETCH NEXT
		FROM eventsreq_cur
		INTO @eventdesc,
			@eventsreq,
			@tasktype

		IF @@fetch_status <> 0
			BREAK
		--select 'tt', @eventdesc
		IF isnull(@eventsreq, 'N') = 'Y'
		BEGIN
			SELECT @col_bt_syn = CASE @eventdesc
					WHEN 'Allow Deletion'
						THEN 'del'
					WHEN 'Allow Insertion'
						THEN 'ins'
					WHEN 'Click Event'
						THEN 'clk'
					WHEN 'Collapse All Event'
						THEN 'cal'
					WHEN 'Collapse Event'
						THEN 'cpe'
					WHEN 'Expand All Event'
						THEN 'eal'
					WHEN 'Expand Event'
						THEN 'exp'
					WHEN 'Month Navigation'
						THEN 'mon'
					WHEN 'Week Navigation'
						THEN 'wek'
					WHEN 'Tap Event'
						THEN 'tap'
					WHEN 'Double Tap Event'
						THEN 'dbl'
					WHEN 'Drag Event'
						THEN 'drg'
					WHEN 'Pagination Event for Mobility'
						THEN 'pag' -- added for callid TECH-16126
					WHEN 'UI Task to Load MultiSelect Combo for Rule Builder'
						THEN 'RBMS' -- Added for Defect ID: TECH-35368
					WHEN 'UI Task for Title bar Search'
						THEN 'TBAR'
					WHEN 'AssociatedUpdateTask'
						THEN 'upd'
					WHEN 'AssociatedDeleteTask'
						THEN 'del'
					END

			--TECH-75230
			IF @eventdesc like 'Pagination Event for %'		
			BEGIN
			SELECT @col_bt_syn = 'pag'
			END
			--TECH-75230

			--TECH-74049 	

			IF ISNULL(@tmp_tasktype, '') = 'trans'
			BEGIN
				SELECT @tmp_tasknamesuffix = 'Tr'
			END
			IF ISNULL(@tmp_tasktype, '') = 'UI'
			BEGIN
				SELECT @tmp_tasknamesuffix = 'UI'
			END

			IF ISNULL(@tmp_tasktype, '') = 'Link'
			BEGIN
				SELECT @tmp_tasknamesuffix = 'Lk'
			END

			IF ISNULL(@tmp_tasktype, '') = 'Help'
			BEGIN
				SELECT @tmp_tasknamesuffix = 'Hp'
			END
			--TECH-74049
			SELECT @taskname = isnull(@comp_pfx_tmp, '') + isnull(@ui_pfx_tmp, '') + isnull(@ctrl_pfx_tmp, '') + ISNULL(@col_bt_syn,'') + ISNULL(@tmp_tasknamesuffix,'') --TECH-74049 	

			SELECT @taskseq = isnull(max(task_seq), 0) + 1
			FROM ep_Action_mst(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_req_no
				AND process_name = @engg_process_name
				AND component_name = @engg_component
				AND activity_name = @tmp_act
				AND ui_name = @tmp_ui
			SELECT @eventdesc = COALESCE(@tmp_taskdesc, @eventdesc) --TECH-74049 

				
			IF NOT EXISTS (
					SELECT 'x'
					FROM ep_Action_mst(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_req_no
						AND process_name = @engg_process_name
						AND component_name = @engg_component
						AND activity_name = @tmp_act
						AND ui_name = @tmp_ui
						AND task_name = @taskname
					)
			BEGIN
				EXEC ep_action_mst_sp_ins @ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@engg_process_name,
					@engg_component,
					@tmp_act,
					@tmp_ui,
					@engg_cont_page_bts,
					@taskname,
					@eventdesc,
					@taskseq,
					@tasktype,
					@engg_cont_btsynname,
					@tasktype,
					1,
					@engg_req_no,
					@m_errorid OUTPUT
			END
		END
	END

	CLOSE eventsreq_cur

	DEALLOCATE eventsreq_cur

	INSERT INTO ep_action_mst_lng_extn (
		customer_name,
		project_name,
		req_no,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		task_name,
		task_descr,
		task_seq,
		task_pattern,
		languageid,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		primary_control_bts,
		task_sysid,
		ui_sysid,
		task_type,
		task_confirm_msg,
		task_status_msg,
		wrkreqno
		)
	SELECT a.customer_name,
		a.project_name,
		a.req_no,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.task_name,
		convert(VARCHAR(3), quick_code) + '_' + a.task_descr,
		a.task_seq,
		a.task_pattern,
		quick_code,
		a.TIMESTAMP,
		a.createdby,
		getdate(),
		a.modifiedby,
		getdate(),
		a.primary_control_bts,
		newid(),
		a.ui_sysid,
		a.task_type,
		convert(VARCHAR(3), quick_code) + '_' + a.task_confirm_msg,
		convert(VARCHAR(3), quick_code) + '_' + a.task_status_msg,
		@engg_req_no
	FROM ep_action_mst a(NOLOCK),
		ep_language_met b(NOLOCK)
	WHERE quick_code_type = 'language_code'
		AND a.customer_name = @engg_customer_name
		AND a.project_name = @engg_project_name
		AND req_no = @engg_req_no
		AND process_name = @engg_process_name
		AND component_name = @engg_component
		AND activity_name = @tmp_act
		AND ui_name = @tmp_ui
		AND page_bt_synonym = @engg_cont_page_bts
		--and  task_name  =   @init_actionName
		AND NOT EXISTS (
			SELECT 's'
			FROM ep_action_mst_lng_extn c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.req_no = a.req_no
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
				AND c.task_name = a.task_name
				AND c.languageid = b.quick_code
			)
END

GO
IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME= 'ep_layout_save_events_gen' AND TYPE='P')
BEGIN
	GRANT EXEC ON  ep_layout_save_events_gen TO PUBLIC
END
GO 
