IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_maireeSpep_layHdrSav' AND TYPE = 'P')
BEGIN
	DROP PROC ep_maireeSpep_layHdrSav
END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		ep_maireeSpep_layHdrSav.sql
********************************************************************************/
/******************************************************************************/
/* Procedure     : ep_maireeSpep_layHdrSav         */
/* Description     :          */
/******************************************************************************/
/* Project      :          */
/* EcrNo      :          */
/* Version      :          */
/******************************************************************************/
/* Referenced     :          */
/* Tables      :          */
/******************************************************************************/
/* Development history   :          */
/******************************************************************************/
/* Author      : Gowrisankar M         */
/* Date       : Apr 16 2008 10:25AM         */
/******************************************************************************/
/* Modification History   :          */
/******************************************************************************/
/* modified by   : Jeya           */
/* date     : 24-nov-2008         */
/* BugId    : PNR2.0_1790          */
/************************************************************************/
/* modified by   : S.Sivakumar    */
/* date    : 22-MAY-2009    */
/* BugId   : PNR2.0_22357     */
/************************************************************************/
/* Modified By      : Chanheetha N A               */
/* Date            : 14-May-2010             */
/* BugID       : PNR2.0_26860              */
/* Modified For      : Extra column to specify freezecount                   */
/********************************************************************************/
/* modified by  : Jeyalatha K            */
/* date    : 11-Feb-2011                                           */
/* Bug Id   : PNR2.0_30127           */
/* Modified for  : Feature  Release          */
/****************************************************************************/
/* modified by  : Vignesh R            */
/* date    : 01-Aug-2011                                           */
/* Bug Id   : PNR2.0_32643           */
/* Modified for  : Error while clicking 'Default All from Reference UI'
button in Specify Layout */
/****************************************************************************/
/* modified by  : Veena U   			                                        */
/* date         : Oct 10 2014			                                        */
/* BugId        : PLF2.0_09035													*/
/* description  : Model changes for rowspan,colspan,IsStatic,IsCallout 
				  in  layout level.												*/
/********************************************************************************/
/* Modified by  : Veena U                                                  */
/* Date         : 25-Feb-2015                                                  */
/* Call ID		: PLF2.0_11499                                                 */
/********************************************************************************/
/* Modified by  : Kalidas S	                                                  */
/* Date         : 03-Aug-2015                                                  */
/* Defect ID	: PLF2.0_14096                                                 */
/********************************************************************************/
/* Modified by  : Veena U	                                                  */
/* Date         : 24-Dec-2015*/
/* Defect ID	: PLF2.0_16153                                                 */
/********************************************************************************/
/* Modified by  : Veena U                                                  */
/* Date         : 24-Feb-2016                                           */
/* Defect ID	: PLF2.0_16291                                                */
/********************************************************************************/
/* Modified by  : Veena U            */
/* Date         : 28-Mar-2016                                                 */
/* Call ID		: PLF2.0_17570                                               */
/********************************************************************************/
/* modified by			Date				Defect ID							*/
/* Veena U				08-Jun-2016			PLF2.0_18487						*/
/********************************************************************************/
/* Modified by : Jeya Latha K/Ganesh Prabhu S	for callid TECH-7349				*/
/* Modified on : 14-03-2017				 											*/
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and New Feature Organization chart */
/*******************************************************************************************/
/* Modified by : Ganesh Prabhu S/Ranjitha R      for callid  TECH-10118                    */
/* Modified on : 30-May-2017                                                               */
/* Description : Platform Feature Release                                                  */
/* Modified by : Priyadharshini U/Rajeswari M	Date: 29-Jan-2020  Defect ID : TECH-42483  */
/*******************************************************************************************/
/* TECH-63527  : Associate Control added in ep_ui_control_dtl for Multiselectcombo		   */ 
/*******************************************************************************************/
/* Modified by	:	Priyadharshini U 													   */
/* Modified on	:	08/07/2022				 											   */
/* Defect ID	:	Tech-70687															   */
/* Description	:	Tool and Toolbars													   */
/*******************************************************************************************/
/* Modified by : Priyadharshini U  														   */
/* Modified on : 27-July-2022															   */
/* Defect ID   : TECH-71262																   */
/* Description : Platform Features for the Month of July'22								   */
/*******************************************************************************************/
/* Modified by : Priyadharshini U/Ponmalar A											   */
/* Modified on : 24-Aug-2022															   */
/* Defect ID   : TECH-72114																   */
/* Description : Platform Release for the month of August'22							   */
/*******************************************************************************************/
/* Modified by : Ponmalar A						Date: 11-Oct-2022  Defect ID : TECH-73321  */
/*******************************************************************************************/
/* Modified by : Ponmalar A																   */
/* Modified on : 02-Nov-2022															   */
/* Defect ID   : TECH-75230																   */
/* Description : Platform Release for the month of Nov'22								   */
/*******************************************************************************************/
CREATE PROCEDURE ep_maireeSpep_layHdrSav
	@ctxt_ouinstance ctxt_OUInstance, --Input
	@ctxt_user ctxt_User, --Input
	@ctxt_language ctxt_Language, --Input
	@ctxt_service ctxt_Service, --Input
	@engg_act_descr ENGG_DESCRIPTION, --Input
	@engg_att_ui_cap_align engg_name, --Input
	@engg_att_ui_format engg_description, --Input
	@engg_att_ui_grid_type engg_type, --Input
	@engg_att_ui_trail_bar engg_name, --Input
	@engg_att_ui_type engg_name, --Input
	@engg_callout_type engg_type, --Input  -- added for request id: PNR2.0_1790
	@engg_component engg_description, --Input
	@engg_cont_page_bts engg_name, --Input
	@engg_cont_sec_bts engg_name, --Input
	@engg_customer_name engg_name, --Input
	@engg_enum_btsynname engg_name, --Input
	@engg_enum_page_bts engg_name, --Input
	@engg_enum_sec_bts engg_name, --Input
	@engg_grid_grid_code engg_name, --Input
	@engg_grid_page_bts engg_name, --Input
	@engg_grid_sec_bts engg_name, --Input
	@engg_lay_page_bts engg_name, --Input
	@engg_lnk_page_descr engg_description, --Input
	@engg_process_descr engg_description, --Input
	@engg_project_name engg_name, --Input
	@engg_radio_btsynname engg_name, --Input
	@engg_radio_page_bts engg_name, --Input
	@engg_radio_sec_bts engg_name, --Input
	@engg_req_no engg_name, --Input
	@engg_rf_act engg_description, --Input
	@engg_rf_comp engg_description, --Input
	@engg_rf_ui engg_description, --Input
	@engg_sec_page_bts engg_name, --Input
	@engg_tab_height engg_length, --Input
	@engg_ui_descr engg_name, --Input
	@eZee_Taskpane engg_name, --Input  -- added for Bug id: PNR2.0_30127
	@state_processing engg_name, --Input
	@engg_isdevice engg_flag, --Input 
	@engg_smarthide engg_flag, --Input 
	@engg_ilbotitle engg_flag, --Input 
	@engg_hdrpersonalisation engg_flag, --Input
	@engg_syst_excl_tab_ind engg_flag,
	@engg_phone engg_flag, --Input 
	@engg_tablet engg_flag, --Input 
	@engg_desk_brw engg_flag, --Input 
	@engg_tab_style engg_name, --Input  
	@engg_ui_layout engg_name, --Input 
	@engg_ui_laycon engg_description, --Input 
	@engg_tab_hdr_pos engg_name, --Input 
	@engg_hide_print engg_flag, --Input 
	@engg_tab_rotate engg_name, --Input 
	@engg_page_name engg_name, --Input 
	@engg_sect_name engg_name, --Input 
	@engg_control_name engg_name, --Input 
	@engg_group_caption engg_description, --Input 
	@engg_group_name engg_name, --Input 
	@engg_hide_default engg_flag,
	--@engg_uisubtype				engg_name,
	--Tech-70687
	@engg_lefttb		engg_seqno,
	@engg_righttb		engg_seqno,
	@engg_toptb			engg_seqno,
	@engg_bottomtb		engg_seqno,
	@engg_att_sidebar	engg_seqno,
	@engg_att_docked	engg_name,
	--Tech-70687 
	@PullToRefresh		engg_seqno,	--TECH-75230
	@m_errorid INT OUTPUT --To Return Execution Status
AS
BEGIN
	-- nocount should be switched on to prevent phantom rows
	SET NOCOUNT ON
	-- @m_errorid should be 0 to Indicate Success
	SET @m_errorid = 0

	--declaration of temporary variables
	DECLARE @engg_grid_default engg_flag --added for Bug Id : PNR2.0_32643
	DECLARE @engg_page_img engg_name
	DECLARE @Sec_CollapseMode engg_name
	DECLARE @engg_grd_visible engg_name
	DECLARE @HeaderPosition engg_code,
		@TabRotation engg_code,
		@TabTitleStyle engg_flag,
		@TabIconPosition engg_code,
		@PageLayout engg_flag,
		@XYCoordinates engg_description,
		@ColumnLayWidth engg_description,
		@Region engg_flag,
		@TitlePosition engg_flag,
		@CollapseDir engg_flag,
		@Associated_Control engg_name,
		@SectionLayout engg_flag,
		@TemplateCategory engg_name,
		@TemplateSpecific engg_documentation,
		@RowExpander engg_flag,
		@GridToForm engg_flag,
		@IsTag engg_name , @Slider engg_flag --TECH-73321

	--temporary and formal parameters mapping
	SET @ctxt_user = ltrim(rtrim(@ctxt_user))
	SET @ctxt_service = ltrim(rtrim(@ctxt_service))
	SET @engg_act_descr = ltrim(rtrim(@engg_act_descr))
	SET @engg_att_ui_cap_align = ltrim(rtrim(@engg_att_ui_cap_align))
	SET @engg_att_ui_format = ltrim(rtrim(@engg_att_ui_format))
	SET @engg_att_ui_grid_type = ltrim(rtrim(@engg_att_ui_grid_type))
	SET @engg_att_ui_trail_bar = ltrim(rtrim(@engg_att_ui_trail_bar))
	SET @engg_att_ui_type = ltrim(rtrim(@engg_att_ui_type))
	SET @engg_component = ltrim(rtrim(@engg_component))
	SET @engg_cont_page_bts = ltrim(rtrim(@engg_cont_page_bts))
	SET @engg_cont_sec_bts = ltrim(rtrim(@engg_cont_sec_bts))
	SET @engg_customer_name = ltrim(rtrim(@engg_customer_name))
	SET @engg_enum_btsynname = ltrim(rtrim(@engg_enum_btsynname))
	SET @engg_enum_page_bts = ltrim(rtrim(@engg_enum_page_bts))
	SET @engg_enum_sec_bts = ltrim(rtrim(@engg_enum_sec_bts))
	SET @engg_grid_grid_code = ltrim(rtrim(@engg_grid_grid_code))
	SET @engg_grid_page_bts = ltrim(rtrim(@engg_grid_page_bts))
	SET @engg_grid_sec_bts = ltrim(rtrim(@engg_grid_sec_bts))
	SET @engg_lay_page_bts = ltrim(rtrim(@engg_lay_page_bts))
	SET @engg_lnk_page_descr = ltrim(rtrim(@engg_lnk_page_descr))
	SET @engg_process_descr = ltrim(rtrim(@engg_process_descr))
	SET @engg_project_name = ltrim(rtrim(@engg_project_name))
	SET @engg_radio_btsynname = ltrim(rtrim(@engg_radio_btsynname))
	SET @engg_radio_page_bts = ltrim(rtrim(@engg_radio_page_bts))
	SET @engg_radio_sec_bts = ltrim(rtrim(@engg_radio_sec_bts))
	SET @engg_req_no = ltrim(rtrim(@engg_req_no))
	SET @engg_rf_act = ltrim(rtrim(@engg_rf_act))
	SET @engg_rf_comp = ltrim(rtrim(@engg_rf_comp))
	SET @engg_rf_ui = ltrim(rtrim(@engg_rf_ui))
	SET @engg_sec_page_bts = ltrim(rtrim(@engg_sec_page_bts))
	SET @engg_ui_descr = ltrim(rtrim(@engg_ui_descr))
	SET @eZee_Taskpane = ltrim(rtrim(@eZee_Taskpane)) -- added for Bug id: PNR2.0_30127
	SET @state_processing = ltrim(rtrim(@state_processing)) --null checking
	SET @engg_callout_type = ltrim(rtrim(@engg_callout_type)) --null checking -- added for request id: PNR2.0_1790
	SET @engg_isdevice = ltrim(rtrim(@engg_isdevice))
	SET @engg_smarthide = ltrim(rtrim(@engg_smarthide))
	SET @engg_ilbotitle = ltrim(rtrim(@engg_ilbotitle))
	SET @engg_hdrpersonalisation = ltrim(rtrim(@engg_hdrpersonalisation))

	SELECT @engg_syst_excl_tab_ind = ltrim(rtrim(@engg_syst_excl_tab_ind))

	SET @engg_phone = ltrim(rtrim(@engg_phone))
	SET @engg_tablet = ltrim(rtrim(@engg_tablet))
	SET @engg_desk_brw = ltrim(rtrim(@engg_desk_brw))
	SET @engg_tab_style = ltrim(rtrim(@engg_tab_style))
	SET @engg_ui_layout = ltrim(rtrim(@engg_ui_layout))
	SET @engg_ui_laycon = ltrim(rtrim(@engg_ui_laycon))
	SET @engg_tab_hdr_pos = ltrim(rtrim(@engg_tab_hdr_pos))
	SET @engg_hide_print = ltrim(rtrim(@engg_hide_print))
	SET @engg_tab_rotate = ltrim(rtrim(@engg_tab_rotate))
	SET @engg_page_name = ltrim(rtrim(@engg_page_name))
	SET @engg_sect_name = ltrim(rtrim(@engg_sect_name))
	SET @engg_control_name = ltrim(rtrim(@engg_control_name))
	SET @engg_group_caption = ltrim(rtrim(@engg_group_caption))
	SET @engg_group_name = ltrim(rtrim(@engg_group_name))
	SET @engg_hide_default = LTRIM(rtrim(@engg_hide_default))
	SET @engg_att_docked = LTRIM(rtrim(@engg_att_docked))	--Tech-70687

	--Set @engg_uisubtype			= LTRIM(rtrim(@engg_uisubtype))
	IF @ctxt_ouinstance = - 915
		SELECT @ctxt_ouinstance = NULL

	IF @ctxt_user = '~#~'
		SELECT @ctxt_user = NULL

	IF @ctxt_language = - 915
		SELECT @ctxt_language = NULL

	IF @ctxt_service = '~#~'
		SELECT @ctxt_service = NULL

	IF @engg_act_descr = '~#~'
		SELECT @engg_act_descr = NULL

	IF @engg_att_ui_cap_align = '~#~'
		SELECT @engg_att_ui_cap_align = NULL

	IF @engg_att_ui_format = '~#~'
		SELECT @engg_att_ui_format = NULL

	IF @engg_att_ui_grid_type = '~#~'
		SELECT @engg_att_ui_grid_type = NULL

	IF @engg_att_ui_trail_bar = '~#~'
		SELECT @engg_att_ui_trail_bar = NULL

	IF @engg_att_ui_type = '~#~'
		SELECT @engg_att_ui_type = NULL

	IF @engg_component = '~#~'
		SELECT @engg_component = NULL

	IF @engg_cont_page_bts = '~#~'
		SELECT @engg_cont_page_bts = NULL

	IF @engg_cont_sec_bts = '~#~'
		SELECT @engg_cont_sec_bts = NULL

	IF @engg_customer_name = '~#~'
		SELECT @engg_customer_name = NULL

	IF @engg_enum_btsynname = '~#~'
		SELECT @engg_enum_btsynname = NULL

	IF @engg_enum_page_bts = '~#~'
		SELECT @engg_enum_page_bts = NULL

	IF @engg_enum_sec_bts = '~#~'
		SELECT @engg_enum_sec_bts = NULL

	IF @engg_grid_grid_code = '~#~'
		SELECT @engg_grid_grid_code = NULL

	IF @engg_grid_page_bts = '~#~'
		SELECT @engg_grid_page_bts = NULL

	IF @engg_grid_sec_bts = '~#~'
		SELECT @engg_grid_sec_bts = NULL

	IF @engg_lay_page_bts = '~#~'
		SELECT @engg_lay_page_bts = NULL

	IF @engg_lnk_page_descr = '~#~'
		SELECT @engg_lnk_page_descr = NULL

	IF @engg_process_descr = '~#~'
		SELECT @engg_process_descr = NULL

	IF @engg_project_name = '~#~'
		SELECT @engg_project_name = NULL

	IF @engg_radio_btsynname = '~#~'
		SELECT @engg_radio_btsynname = NULL

	IF @engg_radio_page_bts = '~#~'
		SELECT @engg_radio_page_bts = NULL

	IF @engg_radio_sec_bts = '~#~'
		SELECT @engg_radio_sec_bts = NULL

	IF @engg_req_no = '~#~'
		SELECT @engg_req_no = NULL

	IF @engg_rf_act = '~#~'
		SELECT @engg_rf_act = NULL

	IF @engg_rf_comp = '~#~'
		SELECT @engg_rf_comp = NULL

	IF @engg_rf_ui = '~#~'
		SELECT @engg_rf_ui = NULL

	IF @engg_sec_page_bts = '~#~'
		SELECT @engg_sec_page_bts = NULL

	IF @engg_tab_height = - 915
		SELECT @engg_tab_height = NULL

	IF @engg_ui_descr = '~#~'
		SELECT @engg_ui_descr = NULL

	-- added for Bug id: PNR2.0_30127
	IF @eZee_Taskpane = '~#~'
		SELECT @eZee_Taskpane = NULL

	IF @state_processing = '~#~'
		SELECT @state_processing = NULL

	-- added for request id: PNR2.0_1790
	IF @engg_callout_type = '~#~'
		SELECT @engg_callout_type = NULL

	IF @engg_isdevice = '~#~'
		SELECT @engg_isdevice = NULL

	IF @engg_smarthide = '~#~'
		SELECT @engg_smarthide = NULL

	IF @engg_ilbotitle = '~#~'
		SELECT @engg_ilbotitle = NULL

	IF @engg_hdrpersonalisation = '~#~'
		SELECT @engg_hdrpersonalisation = NULL

	IF @engg_syst_excl_tab_ind = '~#~'
		SELECT @engg_syst_excl_tab_ind = NULL

	IF @engg_phone = '~#~'
		SELECT @engg_phone = NULL

	IF @engg_tablet = '~#~'
		SELECT @engg_tablet = NULL

	IF @engg_desk_brw = '~#~'
		SELECT @engg_desk_brw = NULL

	IF @engg_tab_style = '~#~'
		SELECT @engg_tab_style = NULL

	IF @engg_ui_layout = '~#~'
		SELECT @engg_ui_layout = NULL

	IF @engg_ui_laycon = '~#~'
		SELECT @engg_ui_laycon = NULL

	IF @engg_tab_hdr_pos = '~#~'
		SELECT @engg_tab_hdr_pos = NULL

	IF @engg_hide_print = '~#~'
		SELECT @engg_hide_print = NULL

	IF @engg_tab_rotate = '~#~'
		SELECT @engg_tab_rotate = NULL

	IF @engg_page_name = '~#~'
		SELECT @engg_page_name = NULL

	IF @engg_sect_name = '~#~'
		SELECT @engg_sect_name = NULL

	IF @engg_control_name = '~#~'
		SELECT @engg_control_name = NULL

	IF @engg_group_caption = '~#~'
		SELECT @engg_group_caption = NULL

	IF @engg_group_name = '~#~'
		SELECT @engg_group_name = NULL

	IF @engg_hide_default = - 915
		SELECT @engg_hide_default = NULL

	--if @engg_uisubtype		='~#~'
	--Select @engg_uisubtype	= NULL
	IF @engg_tab_style = '~#~'
		SELECT @engg_tab_style = NULL

	--Tech-70687
	IF @engg_toptb = - 915
		SELECT @engg_toptb = NULL

	IF @engg_bottomtb = - 915
		SELECT @engg_bottomtb = NULL

	IF @engg_lefttb = - 915
		SELECT @engg_lefttb = NULL

	IF @engg_righttb = - 915
		SELECT @engg_righttb = NULL

	IF @engg_att_sidebar = - 915
		SELECT @engg_att_sidebar = NULL
		
	IF @engg_att_docked = '~#~'
		SELECT @engg_att_docked = NULL		
	--Tech-70687

	IF @PullToRefresh = - 915		--TECH-75230
		SELECT @PullToRefresh = NULL

	DECLARE @tmp_processname engg_name,
		@tmp_componentname engg_name,
		@tmp_activity engg_name,
		@tmp_ui engg_name,
		@tmp_ref_componentname engg_name,
		@tmp_ref_activity engg_name,
		@tmp_ref_ui engg_name,
		@msg engg_description,
		@tmp_cap_align engg_name,
		@tmp_ui_format engg_name,
		@tmp_trail_bar engg_name,
		@tmp_ui_type engg_name,
		@tmp_tab_height engg_length,
		@engg_base_req_no engg_name,
		@ui_type engg_name,
		@tmp_grid_type engg_type,
		@tmp_state_processing engg_name,
		@tmp_callouttype engg_type,
		@page_name engg_name,
		@page_doc engg_documentation,
		@horder engg_seqno,
		@vorder engg_seqno,
		@page_prefix_tmp engg_name,
		@btLength engg_seqno,
		@page_bt_caption engg_description,
		@engg_section_type_in engg_name,
		@engg_sec_cap_align engg_name,
		@engg_sec_cap_format engg_flag,
		@sectionheight engg_seqno,
		@sectionwidth engg_seqno,
		@Section_width_Scalemode engg_name,
		@Section_height_Scalemode engg_name,
		@border_required engg_flag,
		@section_bt_synonym engg_name,
		@title_required engg_flag,
		@visisble_flag engg_flag,
		@section_doc engg_documentation,
		@parent_section engg_name,
		@title_alignment engg_name,
		@sec_bt_caption engg_description,
		@control_bt_synonym engg_name,
		@control_doc engg_documentation,
		@control_type engg_name,
		@sample_data engg_description,
		@proto_tooltip engg_description,
		@visisble_length engg_length,
		@control_id engg_name,
		@control_id_tmp engg_name,
		@count engg_name,
		@data_column_width engg_seqno,
		@label_column_width engg_seqno,
		@order_seq engg_seqno,
		@data_column_scalemode engg_prefix,
		@label_column_scalemode engg_prefix,
		@report_req engg_flag,
		@engg_label_class engg_name,
		@engg_control_class engg_name,
		@engg_label_image_class engg_name,
		@engg_control_image_class engg_name,
		@engg_tab_sequence engg_seqno,
		@engg_tab_stopforhelp engg_flag,
		@control_bt_caption engg_description,
		@base_ctl_type engg_name,
		@event_req engg_name,
		@help_req engg_name,
		@zoom_req engg_name,
		@editable engg_name,
		@visible engg_name,
		@column_bt_synonym engg_name,
		@column_no engg_seqno,
		@col_doc engg_documentation,
		@column_type engg_name,
		@visible_length engg_length,
		@ctrl_bt_syn_id engg_name,
		@viewname_tmp engg_name,
		@view_name engg_name,
		@column_bt_caption engg_description,
		@tmp_ctl engg_name,
		@button_caption engg_description,
		@button_code engg_name,
		@enum_caption engg_description,
		@enum_code engg_name,
		@default_flag engg_flag,
		@seq_no engg_seqno,
		@link_activity engg_name,
		@link_component engg_name,
		@link_type engg_name,
		@link_ui engg_name,
		@link_pcv_caption engg_name,
		@engg_links_asso_ctrl Engg_name,
		@ui_section_sysid_tmp engg_sysid,
		@languageid engg_lang_id,
		@enum_caption_lng engg_description_lng,
		@ui_control_sysid engg_sysid,
		@button_caption_lng engg_description_lng,
		--added for PNR2.0_26860 start
		@Set_User_Pref engg_flag,
		@freezecount engg_seqno,
		@Sec_Collapse engg_name,
		@section_rowspan engg_seqno,
		@section_colspan engg_seqno,
		@Engg_cont_Ctrlimg engg_name,
		@Engg_cont_rowspan engg_seqno,
		@Engg_cont_colspan engg_seqno,
		@engg_cont_tempid engg_name,
		@engg_col_tempid engg_name,
		@columnclass engg_name,
		@forcefit engg_flag,
		@devicetype engg_name,
		@IsDesktop engg_name
		--added for PNR2.0_26860 end
		,
		@group_name engg_name,
		@group_caption engg_name,
		@Seqno engg_seqno,
		@Mapped_ent engg_name,
		@engg_launch_type Engg_name,
		@engg_titlebar_Search engg_flag,
		@engg_dynamicstyle	engg_flag,		--code added by 13639
		@engg_imageasdata	engg_flag,		--code added by 13639
		@engg_extnreqd	engg_code,			--code added by 13639
		@engg_MSC_Ass_control engg_name, --code added for TECH-63527
		@MinimizedRows	engg_seqno, --Tech-70687
		@ViewMode		engg_name,	--Tech-70687
		@Engg_cont_forresponsive	engg_seqno, --Tech-70687
		@engg_cont_control_format	engg_name, --TECH-72114
		@engg_sec_titleicon	engg_name, --TECH-72114
		@Forresponsive	engg_seqno,
		@Orientation	engg_name,	--TECH-75230
		@ButtonNature	engg_name,	--TECH-75230
		@InlineStyle	engg_name	--TECH-75230
	
	SELECT @engg_base_req_no = 'BASE'

	--GETTING THE PROCESS NAME FOR DESCRIPTION
	SELECT @tmp_processname = process_name,
		@tmp_componentname = component_name,
		@tmp_activity = activity_name,
		@tmp_ui = ui_name
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND req_no = @engg_req_no
		AND process_descr = @engg_process_descr
		AND component_descr = @engg_component
		AND activity_descr = @engg_act_descr
		AND ui_descr = @engg_ui_descr

	IF EXISTS (
			SELECT 'x'
			FROM ep_ui_req_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_req_no
				AND process_name = @tmp_processname
				AND component_name = @tmp_componentname
				AND activity_name = @tmp_activity
				AND ui_name = @tmp_ui
				AND req_status = 'P'
			)
	BEGIN
		SELECT @msg = 'Cannot default as Selected UI is in published status'

		EXEC engg_error_sp 'ep_layout_sp_deffrm_hft',
			1,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		IF @m_errorid <> 0
			RETURN
	END

	IF @engg_act_descr IS NULL
	BEGIN
		SELECT @msg = 'Select Activity'

		EXEC engg_error_sp 'ep_layout_sp_defpg_hsv',
			1,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		RETURN
	END

	--Check whether UI is selected. If not display error message
	IF @engg_ui_descr IS NULL
	BEGIN
		SELECT @msg = 'Select User Interface'

		EXEC engg_error_sp 'ep_layout_sp_defpg_hsv',
			2,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		RETURN
	END

	--For the selected activity/UI combination check whether refernce UI has been defined. If not, display error message
	IF @engg_rf_ui IS NULL
	BEGIN
		SELECT @msg = 'Reference UI does not exists for the selected UI.'

		EXEC engg_error_sp 'ep_layout_sp_defpg_hsv',
			3,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		RETURN
	END

	/*Check whether no pages exist for the normal ui.else display error*/
	IF EXISTS (
			SELECT 'x'
			FROM ep_ui_page_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_base_req_no
				AND process_name = @tmp_processname
				AND component_name = @tmp_componentname
				AND activity_name = @tmp_activity
				AND ui_name = @tmp_ui
				AND page_bt_synonym <> '[mainscreen]'
			
			UNION
			
			SELECT 'x'
			FROM ep_ui_section_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_base_req_no
				AND process_name = @tmp_processname
				AND component_name = @tmp_componentname
				AND activity_name = @tmp_activity
				AND ui_name = @tmp_ui
				AND section_bt_synonym NOT IN (
					'PrjHdnSection',
					'[tabcontrol]'
					)
			)
	BEGIN
		SELECT @msg = 'Default from Reference UI cannot be done as there are Pages / Sections defined for this UI already'

		EXEC engg_error_sp 'ep_layout_sp_defpg_hsv',
			4,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		RETURN
	END

	--GETTING THE REF COMPONENT ACTIVITY UI NAME FOR THE DESCRIPTION
	SELECT @tmp_ref_componentname = component_name,
		@tmp_ref_activity = activity_name,
		@tmp_ref_ui = ui_name
	FROM Fw_BPT_RE_NameDesc_Vw(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND component_descr = @engg_rf_comp
		AND activity_descr = @engg_rf_act
		AND ui_descr = @engg_rf_ui

	SELECT @tmp_cap_align = rtrim(caption_alignment),
		@tmp_ui_format = rtrim(ui_format),
		@tmp_trail_bar = rtrim(trail_bar),
		@tmp_ui_type = isnull(ui_type, ''),
		@tmp_tab_height = isnull(tab_height, ''),
		@tmp_grid_type = isnull(grid_type, 'HTM'),
		@tmp_state_processing = isnull(state_processing, 'No'),
		@tmp_callouttype = isnull(callout_type, 'None'),
		@engg_smarthide = rtrim(SmartHide),
		@engg_isdevice = rtrim(Is_device),
		@engg_ilbotitle = rtrim(HideIlbotitlemenu_req),
		@engg_hdrpersonalisation = rtrim(personalization),
		@engg_syst_excl_tab_ind = rtrim(Exclude_Systemtabindex),
		@devicetype = rtrim(DeviceType),
		@engg_tab_style = rtrim(TabStyle),
		@IsDesktop = RTRIM(IsDesktop),
		@engg_ui_layout = RTRIM(Layout),
		@engg_hide_print = RTRIM(Hide_Print),
		@XYCoordinates = rtrim(XYCoordinates),
		@ColumnLayWidth = RTRIM(ColumnLayWidth),
		@engg_tab_hdr_pos = RTRIM(TabHeaderPostion),
		@engg_tab_rotate = RTRIM(TabRotation),
		@engg_hide_default = RTRIM(hide_imp_defaults),
		@engg_titlebar_Search = RTRIM(Titlebar_Search),
		--Code added for the Defect Id Tech-70687 starts 
		@engg_att_docked		=	RTRIM(Docked),
		@engg_att_sidebar		=	case when Sidebar			=	'Y' then 1 else 0 end	,
		@engg_lefttb			=	case when	LeftToolbar		=	'Y' then 1 else 0 end	,
		@engg_righttb			=	case when	RightToolbar	=	'Y' then 1 else 0 end	,
		@engg_toptb				=	case when	TopToolbar		=	'Y' then 1 else 0 end	,
		@engg_bottomtb			=	case when	BottomToolbar	=	'Y' then 1 else 0 end	,
		--Code added for the Defect Id Tech-70687 ends
		@PullToRefresh			=	case when	PullToRefresh	=	'Y' then 1 else 0 end		--TECH-75230
	FROM ep_ui_mst a(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND req_no = @engg_base_req_no
		AND component_name = @tmp_ref_componentname
		AND activity_name = @tmp_ref_activity
		AND ui_name = @tmp_ref_ui

	SELECT @ui_type = rtrim(ui_type)
	FROM ep_ui_mst(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND req_no = @engg_base_req_no
		AND process_name = @tmp_processname
		AND component_name = @tmp_componentname
		AND activity_name = @tmp_activity
		AND ui_name = @tmp_ui

	IF isnull(@ui_type, '') <> 'MAIN'
	BEGIN
		IF rtrim(@tmp_ui_type) IN (
				'Main',
				'Search'
				)
		BEGIN
			IF EXISTS (
					SELECT 'x'
					FROM ep_ui_mst(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_base_req_no
						AND process_name = @tmp_processname
						AND component_name = @tmp_componentname
						AND activity_name = @tmp_activity
						AND ui_name <> @tmp_ui
						AND ui_type IN (
							'Main',
							'Search'
							)
					)
			BEGIN
				SELECT @tmp_ui_type = 'Others'
			END
		END
	END /*End for Checking Type*/

	IF upper(@ui_type) NOT IN ('SEARCH')
	BEGIN
		/* To check whether ui of type 'main' or 'search' already exists for the activity*/
		IF rtrim(@tmp_ui_type) IN (
				'Main',
				'Search'
				)
		BEGIN
			IF EXISTS (
					SELECT 'x'
					FROM ep_ui_mst(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_base_req_no
						AND process_name = @tmp_processname
						AND component_name = @tmp_componentname
						AND activity_name = @tmp_activity
						AND ui_name <> @tmp_ui
						AND ui_type IN (
							'Main',
							'Search'
							)
					)
			BEGIN
				SELECT @tmp_ui_type = 'Others'
			END
		END
	END /*End for Checking Type*/

	/*update ui format attributes for the selected ui.*/
	UPDATE ep_ui_mst
	SET ui_type = rtrim(@tmp_ui_type),
		ui_format = rtrim(@tmp_ui_format),
		caption_alignment = rtrim(@tmp_cap_align),
		trail_bar = rtrim(@tmp_trail_bar),
		tab_height = rtrim(@tmp_tab_height),
		grid_type = rtrim(@tmp_grid_type),
		state_processing = rtrim(@tmp_state_processing),
		callout_type = rtrim(@tmp_callouttype),
		SmartHide = rtrim(@engg_smarthide),
		Is_device = rtrim(@engg_isdevice),
		HideIlbotitlemenu_req = rtrim(@engg_ilbotitle),
		personalization = rtrim(@engg_hdrpersonalisation),
		Exclude_Systemtabindex = rtrim(@engg_syst_excl_tab_ind) --PLF2.0_16291  
		,
		DeviceType = rtrim(@devicetype),
		TabStyle = rtrim(@engg_tab_style),
		IsDesktop = RTRIM(@IsDesktop),
		Layout = RTRIM(@engg_ui_layout),
		XYCoordinates = RTRIM(@XYCoordinates),
		ColumnLayWidth = RTRIM(@ColumnLayWidth),
		TabHeaderPostion = RTRIM(@engg_tab_hdr_pos),
		Hide_Print = RTRIM(@engg_hide_print),
		TabRotation = RTRIM(@engg_tab_rotate),
		hide_imp_defaults = rtrim(@engg_hide_default),
		Titlebar_search =	rtrim(@engg_titlebar_Search),
		--Code added for the Defect Id Tech-70687 starts 
		Docked			=	@engg_att_docked,
		Sidebar			=	case when @engg_att_sidebar	=	1 then 'Y' else 'N' end,	
		LeftToolbar		=	case when @engg_lefttb		=	1 then 'Y' else 'N' end,	
		RightToolbar	=	case when @engg_righttb		=	1 then 'Y' else 'N' end,	
		TopToolbar		=	case when @engg_toptb		=	1 then 'Y' else 'N' end,	
		BottomToolbar	=	case when @engg_bottomtb	=	1 then 'Y' else 'N' end,
		--Code added for the Defect Id Tech-70687 ends
		PullToRefresh	=	case when @PullToRefresh	=	1 then 'Y' else 'N' end --TECH-75230
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND req_no = @engg_base_req_no
		AND process_name = @tmp_processname
		AND component_name = @tmp_componentname
		AND activity_name = @tmp_activity
		AND ui_name = @tmp_ui

	/*
EXPLANATION FOR THE FOLLOWING QUERY:

-------------------------------------

Selecting all the page details for the selected customer, project, process, reference component,
reference activity and reference ui from the table ep_ui_page_dtl filtering the ui names
for which the page detail already saved
Inserting the above selected values in the ep_ui_page_dtl table for the selected customer,
project, process, component, activity and ui

Selecting all the page details for the selected customer, project, process, component,
activity and ui from the table ep_ui_page_dtl along with the BT Synonym caption for the
corresponding page_bt_synonym from the table ep_glossary_mst.
*/
	DECLARE insert_page_cur INSENSITIVE CURSOR
	FOR
	SELECT a.page_bt_synonym,
		a.page_doc,
		a.horder,
		a.vorder,
		a.pageimage,
		a.HeaderPosition,
		a.TabRotation,
		a.TabTitleStyle,
		a.TabIconPosition,
		a.PageLayout,
		a.XYCoordinates,
		a.ColumnLayWidth,
		--Code added for the Defect Id Tech-70687 starts 
		case when a.LeftToolbar=	'y' then 1 else 0 end	,
		case when a.RightToolbar=	'y' then 1 else 0 end	,
		case when a.TopToolbar	=	'y' then 1 else 0 end	,
		case when a.BottomToolbar=	'y' then 1 else 0 end
		--Code added for the Defect Id Tech-70687 ends	
	FROM ep_ui_page_dtl a(NOLOCK)
	WHERE a.customer_name = @engg_customer_name
		AND a.project_name = @engg_project_name
		AND a.req_no = @engg_base_req_no
		AND a.component_name = @tmp_ref_componentname
		AND a.activity_name = @tmp_ref_activity
		AND a.ui_name = @tmp_ref_ui

	--  and  a.horder     <> 0
	--  and  a.vorder     <> 0
	OPEN insert_page_cur

	WHILE (1 = 1)
	BEGIN -- For each page in ref UI
		FETCH NEXT
		FROM insert_page_cur
		INTO @page_name,
			@page_doc,
			@horder,
			@vorder,
			@engg_page_img,
			@HeaderPosition,
			@TabRotation,
			@TabTitleStyle,
			@TabIconPosition,
			@PageLayout,
			@XYCoordinates,
			@ColumnLayWidth,
			--Tech-70687 
			@engg_lefttb,
			@engg_righttb,
			@engg_toptb,
			@engg_bottomtb
			--Tech-70687 
		IF @@fetch_status <> 0
			BREAK

		IF @page_name <> '[mainscreen]'
		BEGIN
			EXEC engg_gen_prefix_id @engg_customer_name,
				@engg_project_name,
				@tmp_componentname,
				@tmp_activity,
				@tmp_ui,
				@page_name,
				'P',
				6,
				@page_prefix_tmp OUTPUT

			EXEC ep_ui_page_dtl_sp_ins @ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@engg_customer_name,
				@engg_project_name,
				@engg_base_req_no,
				@tmp_processname,
				@tmp_componentname,
				@tmp_activity,
				@tmp_ui,
				@page_name,
				@horder,
				@vorder,
				@page_doc,
				@page_prefix_tmp,
				1,
				@engg_req_no,
				'NORMAL', -- Code Added For BUG ID PNR2.0_22357
				@engg_page_img,
				@HeaderPosition,
				@TabRotation,
				@TabTitleStyle,
				@TabIconPosition,
				@PageLayout,
				@XYCoordinates,
				@ColumnLayWidth,
				--Tech-70687 
				@engg_lefttb,
				@engg_righttb,
				@engg_toptb,
				@engg_bottomtb,
				--Tech-70687
				@m_errorid OUTPUT

			IF @m_errorid <> 0
			BEGIN
				CLOSE insert_page_cur

				DEALLOCATE insert_page_cur

				RETURN
			END

			SELECT @btLength = 20

			IF NOT EXISTS (
					SELECT 'x'
					FROM ep_component_glossary_mst NOLOCK
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_base_req_no
						AND process_name = @tmp_processname
						AND component_name = @tmp_componentname
						AND bt_synonym_name = @page_name
					)
			BEGIN --Glossary Check
				SELECT @page_bt_caption = bt_synonym_caption
				FROM ep_component_glossary_mst(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND component_name = @tmp_ref_componentname
					AND bt_synonym_name = @page_name

				EXEC ep_component_glossary_mst_sp_ins @ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@engg_customer_name,
					@engg_project_name,
					'base',
					@tmp_processname,
					@tmp_componentname,
					@page_name,
					NULL,
					'Char',
					@btLength,
					@page_bt_caption,
					@page_name,
					'',
					'U',
					'',
					'',
					1,
					@engg_req_no,
					@m_errorid OUTPUT

				IF @m_errorid <> 0
				BEGIN
					CLOSE insert_page_cur

					DEALLOCATE insert_page_cur

					RETURN
				END
			END --Glossary Check
		END

		DECLARE insert_sec_cur INSENSITIVE CURSOR
		FOR
		SELECT border_required,
			section_bt_synonym,
			title_required,
			visisble_flag,
			section_doc,
			parent_section,
			horder,
			vorder,
			title_alignment,
			section_type,
			ctrl_caption_align,
			caption_Format,
			height,
			width,
			Section_width_Scalemode,
			Section_height_Scalemode,
			section_collapsemode,
			section_collapse,
			NRowSpan,
			NColSpan,
			Region,
			TitlePosition,
			CollapseDir,
			SectionLayout,
			XYCoordinates,
			ColumnLayWidth,
			Associated_Control,
			Forresponsive,
			Orientation,--TECH-75230
			--Tech-70687 
		case when BottomToolbar	=	'y' then 1 else 0 end	,
		case when TopToolbar	=	'y' then 1 else 0 end	,
		case when RightToolbar	=	'y' then 1 else 0 end	,
		case when LeftToolbar	=	'y' then 1 else 0 end	,		
			MinimizedRows,
			ViewMode,
			--Tech-70687 
			TitleIcon		--TECH-72114
		FROM ep_ui_section_dtl(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND req_no = @engg_base_req_no
			AND component_name = @tmp_ref_componentname
			AND activity_name = @tmp_ref_activity
			AND ui_name = @tmp_ref_ui
			AND page_bt_synonym = @page_name
			AND section_bt_synonym NOT IN (
				'PrjHdnSection',
				'[tabcontrol]'
				)

		OPEN insert_sec_cur

		WHILE (1 = 1)
		BEGIN -- For each section under the page "@page_name"
			FETCH NEXT
			FROM insert_sec_cur
			INTO @border_required,
				@section_bt_synonym,
				@title_required,
				@visisble_flag,
				@section_doc,
				@parent_section,
				@horder,
				@vorder,
				@title_alignment,
				@engg_section_type_in,
				@engg_sec_cap_align,
				@engg_sec_cap_format,
				@sectionheight,
				@sectionwidth,
				@Section_width_Scalemode,
				@Section_height_Scalemode,
				@Sec_CollapseMode,
				@Sec_Collapse,
				@section_rowspan,
				@section_colspan,
				@Region,
				@TitlePosition,
				@CollapseDir,
				@SectionLayout,
				@XYCoordinates,
				@ColumnLayWidth,
				@Associated_Control,
				@Forresponsive,
				@Orientation, --TECH-75230
				--Tech-70687 
				@engg_bottomtb,
				@engg_toptb,
				@engg_righttb,
				@engg_lefttb,				
				@MinimizedRows,
				@ViewMode,
				--Tech-70687
				@engg_sec_titleicon --TECH-72114
			IF @@fetch_status <> 0
				BREAK

			EXEC ep_ui_section_dtl_sp_ins 
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@engg_customer_name,
				@engg_project_name,
				@engg_base_req_no,
				@tmp_processname,
				@tmp_componentname,
				@tmp_activity,
				@tmp_ui,
				@page_name,
				@section_bt_synonym,
				@visisble_flag,
				@title_required,
				@border_required,
				@title_alignment,
				@parent_section,
				@horder,
				@vorder,
				@section_doc,
				1,
				@engg_section_type_in,
				@engg_sec_cap_align,
				@engg_sec_cap_format,
				@sectionheight,
				@sectionwidth,
				@Section_width_Scalemode,
				@Section_height_Scalemode,
				@Sec_CollapseMode,
				@Sec_Collapse,
				@engg_req_no,
				@section_rowspan,
				@section_colspan,
				@Region,
				@TitlePosition,
				@CollapseDir,
				@SectionLayout,
				@XYCoordinates,
				@ColumnLayWidth,
				@Associated_Control,
				'',
				'',
				'',
				@Orientation,	--TECH-75230
				@engg_bottomtb,
				@engg_toptb,
				@engg_righttb,
				@engg_lefttb,
				@minimizedrows,
				@viewmode,
				@engg_sec_titleicon,
				@m_errorid OUTPUT

			IF @m_errorid <> 0
			BEGIN
				CLOSE insert_sec_cur

				DEALLOCATE insert_sec_cur

				CLOSE insert_page_cur

				DEALLOCATE insert_page_cur

				RETURN
			END

			SELECT @btLength = 20

			IF NOT EXISTS (
					SELECT 'x'
					FROM ep_component_glossary_mst(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_base_req_no
						AND process_name = @tmp_processname
						AND component_name = @tmp_componentname
						AND bt_synonym_name = @section_bt_synonym
					)
			BEGIN --Glossary Check for Section Name
				SELECT @sec_bt_caption = bt_synonym_caption
				FROM ep_component_glossary_mst(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND component_name = @tmp_ref_componentname
					AND bt_synonym_name = @section_bt_synonym

				IF @ctxt_user = 'ss'
				BEGIN
					SELECT @section_bt_synonym
				END
				--Tech-70687 
				IF ISNULL(@sec_bt_caption,'')	=	''
				BEGIN
				IF EXISTS ( SELECT 'X'
							FROM	ep_ui_section_dtl WITH(NOLOCK)
							WHERE	customer_name		= @engg_customer_name
							AND		project_name		= @engg_project_name
							AND		req_no				= @engg_base_req_no
							and		process_name		= @tmp_processname
							AND		component_name		= @tmp_ref_componentname
							AND		activity_name		= @tmp_ref_activity
							AND		ui_name				= @tmp_ref_ui
							--AND		page_bt_synonym		= @engg_sec_page_bts
							AND		section_bt_synonym	= @section_bt_synonym
							AND		Section_type  IN ('Toolbar','Sidebar')	)
				BEGIN
				
						SELECT @sec_bt_caption	=	@section_bt_synonym
				END
				END
				--Tech-70687 

				EXEC ep_component_glossary_mst_sp_ins @ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@engg_customer_name,
					@engg_project_name,
					'BASE',
					@tmp_processname,
					@tmp_componentname,
					@section_bt_synonym,
					NULL,
					'Char',
					@btLength,
					@sec_bt_caption,
					@section_bt_synonym,
					'',
					'U',
					'',
					'',
					1,
					@engg_req_no,
					@m_errorid OUTPUT

				IF @ctxt_user = 'ss'
				BEGIN
					SELECT @section_bt_synonym
				END

				IF @m_errorid <> 0
				BEGIN
					CLOSE insert_sec_cur

					DEALLOCATE insert_sec_cur

					CLOSE insert_page_cur

					DEALLOCATE insert_page_cur

					RETURN
				END
			END --Glossary Check for Section Name

			/*explanation for the following query:

Selecting all the control details for the selected customer, project, process,
reference component, reference activity, reference ui, pagebtsynonym and sectionbtsynonym
from the table ep_ui_control_dtl also filtering the ui names for which the control
detail already saved.
Inserting the above selected values in the ep_ui_control_dtl table for the selected customer,
project, process, component, activity and ui

selecting all the control details for the selected customer, project, process, component,
activity, ui, page bt synonym and section bt synonym from the table ep_ui_control_dtl along with the
bt synonym caption for the corresponding control_bt_synonym from the table ep_glossary_mst.
*/
			--modified by Ranjitha
			DECLARE @AccessKey engg_code,
				@Icon_class engg_name,
				@Icon_position engg_name,
				@Cont_class_ext6 engg_name

			DECLARE insert_ctrl_cur INSENSITIVE CURSOR
			FOR
			SELECT control_bt_synonym,
				control_doc,
				control_type,
				horder,
				sample_data,
				proto_tooltip,
				visisble_length,
				vorder,
				data_column_width,
				label_column_width,
				order_seq,
				data_column_scalemode,
				label_column_scalemode,
				LabelClass,
				controlclass,
				labelimageclass,
				controlimageclass,
				isnull(tab_seq, 0),
				CASE 
					WHEN help_tabstop = 'N'
						THEN 0
					ELSE 1
					END,
				Set_User_Pref,
				freezecount, --added for PNR2.0_26860
				'n' --added for Bug Id : PNR2.0_32643
				,
				controlimage,
				colspan,
				rowspan,
				TemplateID -- Added for PLF2.0_14096
				,
				TemplateCategory,
				TemplateSpecific,
				--Ranjitha
				AccessKey,
				Icon_class,
				Icon_Position,
				Control_class_ext6,
				dynamicStyle,
				ImageAsData,
				ExtensionReqd,
				AssociateControl,--code added for TECH-63527
				ForResponsive,
				CASE WHEN ControlFormat = 'Bes' THEN 'Controls Beside Captions'
					 WHEN ControlFormat = 'Top' THEN 'Top Inner' ELSE '' END,	--TECH-72114
				ButtonNature,
				InlineStyle	--TECH-75230
			FROM ep_ui_control_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_base_req_no
				AND component_name = @tmp_ref_componentname
				AND activity_name = @tmp_ref_activity
				AND ui_name = @tmp_ref_ui
				AND page_bt_synonym = @page_name
				AND section_bt_synonym = @section_bt_synonym

			OPEN insert_ctrl_cur

			WHILE (1 = 1)
			BEGIN
				FETCH NEXT
				FROM insert_ctrl_cur
				INTO @control_bt_synonym,
					@control_doc,
					@control_type,
					@horder,
					@sample_data,
					@proto_tooltip,
					@visisble_length,
					@vorder,
					@data_column_width,
					@label_column_width,
					@order_seq,
					@data_column_scalemode,
					@label_column_scalemode,
					@engg_label_class,
					@engg_control_class,
					@engg_label_image_class,
					@engg_control_image_class,
					@engg_tab_sequence,
					@engg_tab_stopforhelp,
					@Set_User_Pref,
					@freezecount, --added for PNR2.0_26860
					@engg_grid_default --added for Bug Id : PNR2.0_32643
					,
					@Engg_cont_Ctrlimg,
					@Engg_cont_rowspan,
					@Engg_cont_colspan,
					@engg_cont_tempid -- Added for PLF2.0_14096
					,
					@TemplateCategory,
					@TemplateSpecific,
					--Ranjitha
					@AccessKey,
					@Icon_class,
					@Icon_Position,
					@cont_class_ext6,
					@engg_dynamicstyle,
					@engg_imageasdata,
					@engg_extnreqd,
					@engg_MSC_Ass_control,	--code added for TECH-63527
					@Engg_cont_forresponsive,
					@engg_cont_control_format,  --TECH-72114
					@buttonnature,	--TECH-75230
					@InlineStyle	--TECH-75230

				IF @@fetch_status <> 0
					BREAK

				IF EXISTS (
						SELECT 'A'
						FROM ep_ui_section_dtl(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND req_no = @engg_base_req_no
							AND process_name = @tmp_processname
							AND component_name = @tmp_componentname
							AND activity_name = @tmp_activity
							AND ui_name = @tmp_ui
							AND page_bt_synonym = @page_name
							AND section_bt_synonym = @control_bt_synonym
						)
				BEGIN
					SELECT @msg = 'Cannot Default. Control Bt Synonym ' + @control_bt_synonym + ' already exists in the Page as Section Bt Synonym'

					EXEC ENGG_ERROR_SP 'ep_layout_sp_defctl_hsv',
						7,
						@msg,
						@CTXT_LANGUAGE,
						@CTXT_OUINSTANCE,
						@CTXT_SERVICE,
						@CTXT_USER,
						'',
						'',
						'',
						'',
						@M_ERRORID OUTPUT

					CLOSE insert_ctrl_cur

					DEALLOCATE insert_ctrl_cur

					CLOSE insert_sec_cur

					DEALLOCATE insert_sec_cur

					CLOSE insert_page_cur

					DEALLOCATE insert_page_cur

					RETURN
				END

				IF EXISTS (
						SELECT 'A'
						FROM ep_ui_control_dtl(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND req_no = @engg_base_req_no
							AND process_name = @tmp_processname
							AND component_name = @tmp_componentname
							AND activity_name = @tmp_activity
							AND ui_name = @tmp_ui
							AND page_bt_synonym = @page_name
							AND control_bt_synonym = @control_bt_synonym
						)
				BEGIN
					SELECT @msg = 'Cannot Default. Control Bt Synonym ' + @control_bt_synonym + ' already exists in the Page as Control Bt Synonym'

					EXEC ENGG_ERROR_SP 'ep_layout_sp_defctl_hsv',
						7,
						@msg,
						@CTXT_LANGUAGE,
						@CTXT_OUINSTANCE,
						@CTXT_SERVICE,
						@CTXT_USER,
						'',
						'',
						'',
						'',
						@M_ERRORID OUTPUT

					CLOSE insert_ctrl_cur

					DEALLOCATE insert_ctrl_cur

					CLOSE insert_sec_cur

					DEALLOCATE insert_sec_cur

					CLOSE insert_page_cur

					DEALLOCATE insert_page_cur

					RETURN
				END

				IF EXISTS (
						SELECT 'A'
						FROM ep_ui_grid_dtl(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND req_no = @engg_base_req_no
							AND process_name = @tmp_processname
							AND component_name = @tmp_componentname
							AND activity_name = @tmp_activity
							AND ui_name = @tmp_ui
							AND page_bt_synonym = @page_name
							AND column_bt_synonym = @control_bt_synonym
						)
				BEGIN
					SELECT @msg = 'Cannot Default. Control Bt Synonym ' + @control_bt_synonym + ' already exists in the Page as Grid Column Bt Synonym'

					EXEC ENGG_ERROR_SP 'ep_layout_sp_defctl_hsv',
						7,
						@msg,
						@CTXT_LANGUAGE,
						@CTXT_OUINSTANCE,
						@CTXT_SERVICE,
						@CTXT_USER,
						'',
						'',
						'',
						'',
						@M_ERRORID OUTPUT

					CLOSE insert_ctrl_cur

					DEALLOCATE insert_ctrl_cur

					CLOSE insert_sec_cur

					DEALLOCATE insert_sec_cur

					CLOSE insert_page_cur

					DEALLOCATE insert_page_cur

					RETURN
				END

				IF EXISTS (
						SELECT 'A'
						FROM de_hidden_view(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @tmp_processname
							AND component_name = @tmp_componentname
							AND activity_name = @tmp_activity
							AND ui_name = @tmp_ui
							AND page_name = @page_name
							AND hidden_view_bt_synonym = @control_bt_synonym
						)
				BEGIN
					SELECT @msg = 'Cannot Default. Control Bt Synonym ' + @control_bt_synonym + ' already exists in the Page as Hidden View Bt Synonym'

					EXEC ENGG_ERROR_SP 'ep_layout_sp_defctl_hsv',
						7,
						@msg,
						@CTXT_LANGUAGE,
						@CTXT_OUINSTANCE,
						@CTXT_SERVICE,
						@CTXT_USER,
						'',
						'',
						'',
						'',
						@M_ERRORID OUTPUT

					CLOSE insert_ctrl_cur

					DEALLOCATE insert_ctrl_cur

					CLOSE insert_sec_cur

					DEALLOCATE insert_sec_cur

					CLOSE insert_page_cur

					DEALLOCATE insert_page_cur

					RETURN
				END

				IF EXISTS (
						SELECT 'A'
						FROM de_scratch_variable(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @tmp_processname
							AND component_name = @tmp_componentname
							AND activity_name = @tmp_activity
							AND ui_name = @tmp_ui
							AND page_name = @page_name
							AND scratch_name = @control_bt_synonym
						)
				BEGIN
					SELECT @msg = 'Cannot Default. Control Bt Synonym ' + @control_bt_synonym + ' already exists in the Page as User Defined Scratch Variable'

					EXEC ENGG_ERROR_SP 'ep_layout_sp_defctl_hsv',
						7,
						@msg,
						@CTXT_LANGUAGE,
						@CTXT_OUINSTANCE,
						@CTXT_SERVICE,
						@CTXT_USER,
						'',
						'',
						'',
						'',
						@M_ERRORID OUTPUT

					CLOSE insert_ctrl_cur

					DEALLOCATE insert_ctrl_cur

					CLOSE insert_sec_cur

					DEALLOCATE insert_sec_cur

					CLOSE insert_page_cur

					DEALLOCATE insert_page_cur

					RETURN
				END

				IF EXISTS (
						SELECT 'x'
						FROM de_scratch_variables_sys(NOLOCK)
						WHERE btsynonym = @control_bt_synonym
						)
					OR @control_bt_synonym = 'Modeflag'
				BEGIN
					SELECT @msg = 'Cannot Default. Control Bt Synonym ' + @control_bt_synonym + ' already exists as a Default Scratch Variable'

					EXEC ENGG_ERROR_SP 'ep_layout_sp_defctl_hsv',
						7,
						@msg,
						@CTXT_LANGUAGE,
						@CTXT_OUINSTANCE,
						@CTXT_SERVICE,
						@CTXT_USER,
						'',
						'',
						'',
						'',
						@M_ERRORID OUTPUT

					CLOSE insert_ctrl_cur

					DEALLOCATE insert_ctrl_cur

					CLOSE insert_sec_cur

					DEALLOCATE insert_sec_cur

					CLOSE insert_page_cur

					DEALLOCATE insert_page_cur

					RETURN
				END

				IF NOT EXISTS (
						SELECT 'x'
						FROM es_comp_ctrl_type_mst(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @tmp_processname
							AND component_name = @tmp_componentname
							AND ctrl_type_name = @control_type
						)
				BEGIN
					INSERT INTO es_comp_ctrl_type_mst (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						ctrl_type_name,
						ctrl_type_descr,
						base_ctrl_type,
						mandatory_flag,
						visisble_flag,
						editable_flag,
						caption_req,
						select_flag,
						zoom_req,
						insert_req,
						delete_req,
						help_req,
						event_handling_req,
						ellipses_req,
						comp_ctrl_type_sysid,
						TIMESTAMP,
						createdby,
						createddate,
						modifiedby,
						modifieddate,
						caption_alignment,
						caption_position,
						caption_wrap,
						visisble_rows,
						ctrl_type_doc,
						ctrl_position,
						label_class,
						ctrl_class,
						password_char,
						tskimg_class,
						hlpimg_class,
						disponlycmb_req,
						html_txt_area,
						report_req,
						Auto_tab_stop,
						Spin_required,
						Spin_up_image,
						Spin_down_image
						)
					SELECT customer_name,
						project_name,
						req_no,
						@tmp_processname,
						@tmp_componentname,
						ctrl_type_name,
						ctrl_type_descr,
						base_ctrl_type,
						mandatory_flag,
						visisble_flag,
						editable_flag,
						caption_req,
						select_flag,
						zoom_req,
						insert_req,
						delete_req,
						help_req,
						event_handling_req,
						ellipses_req,
						comp_ctrl_type_sysid,
						TIMESTAMP,
						createdby,
						createddate,
						modifiedby,
						modifieddate,
						caption_alignment,
						caption_position,
						caption_wrap,
						visisble_rows,
						ctrl_type_doc,
						ctrl_position,
						label_class,
						ctrl_class,
						password_char,
						tskimg_class,
						hlpimg_class,
						disponlycmb_req,
						html_txt_area,
						report_req,
						Auto_tab_stop,
						Spin_required,
						Spin_up_image,
						Spin_down_image
					FROM es_comp_ctrl_type_mst(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND component_name = @tmp_ref_componentname
						AND ctrl_type_name = @control_type
				END

				SELECT @base_ctl_type = base_ctrl_type,
					@help_req = help_req,
					@event_req = event_handling_req,
					@zoom_req = zoom_req,
					@editable = editable_flag,
					@visible = visisble_flag,
					@report_req = report_req
				FROM es_comp_ctrl_type_mst_vw(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @tmp_processname
					AND component_name = @tmp_componentname
					AND ctrl_type_name = @control_type
					AND req_no = @engg_base_req_no

				EXEC engg_gen_prefix_id @engg_customer_name,
					@engg_project_name,
					@tmp_componentname,
					@tmp_activity,
					@tmp_ui,
					@control_bt_synonym,
					'C',
					6,
					@page_prefix_tmp OUTPUT

				EXEC ep_controlid_generation @engg_customer_name,
					@engg_project_name,
					@engg_base_req_no,
					@tmp_processname,
					@tmp_componentname,
					@tmp_activity,
					@tmp_ui,
					@control_bt_synonym,
					@base_ctl_type,
					@editable,
					@visible,
					@control_id OUTPUT

				EXEC ep_ui_control_dtl_sp_ins @ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@engg_customer_name,
					@engg_project_name,
					@engg_base_req_no,
					@tmp_processname,
					@tmp_componentname,
					@tmp_activity,
					@tmp_ui,
					@page_name,
					@section_bt_synonym,
					@control_bt_synonym,
					@control_id,
					@control_type,
					@visisble_length,
					@horder,
					@vorder,
					@order_seq,
					@data_column_width,
					@label_column_width,
					@proto_tooltip,
					@sample_data,
					@control_doc,
					@page_prefix_tmp,
					'',
					@data_column_scalemode,
					@label_column_scalemode,
					@engg_label_class,
					@engg_control_class,
					@engg_label_image_class,
					@engg_control_image_class,
					@engg_tab_sequence,
					@engg_tab_stopforhelp,
					1,
					@engg_req_no,
					--added for PNR2.0_26860 start
					@Set_User_Pref,
					@freezecount,
					@Engg_cont_Ctrlimg,
					@Engg_cont_rowspan,
					@Engg_cont_colspan,
					--added for PNR2.0_26860 end
					@engg_cont_tempid, -- Added for PLF2.0_14096
					@TemplateCategory,
					@TemplateSpecific,
					--Ranjitha
					@AccessKey,
					@Icon_class,
					@Icon_position,
					@Cont_class_ext6,
					@engg_dynamicstyle,
					@engg_imageasdata,
					'',
					@engg_MSC_Ass_control,
					@Engg_cont_forresponsive,
					@engg_cont_control_format, --TECH-72114
					@buttonnature,	--TECH-75230
					@InlineStyle,	--TECH-75230
					@m_errorid OUTPUT

				IF @m_errorid <> 0
				BEGIN
					CLOSE insert_ctrl_cur

					DEALLOCATE insert_ctrl_cur

					CLOSE insert_sec_cur

					DEALLOCATE insert_sec_cur

					CLOSE insert_page_cur

					DEALLOCATE insert_page_cur

					RETURN
				END

				SELECT @visisble_length = isnull(@visisble_length, 20)

				IF @visisble_length = 0
					SELECT @visisble_length = 20

				IF NOT EXISTS (
						SELECT 'x'
						FROM ep_component_glossary_mst NOLOCK
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND req_no = @engg_base_req_no
							AND process_name = @tmp_processname
							AND component_name = @tmp_componentname
							AND bt_synonym_name = @control_bt_synonym
						)
				BEGIN
					SELECT @control_bt_caption = bt_synonym_caption
					FROM ep_component_glossary_mst(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_base_req_no
						AND component_name = @tmp_ref_componentname
						AND bt_synonym_name = @control_bt_synonym

					IF ISNULL(@control_bt_caption, '~#~') = '~#~'
						SET @control_bt_caption = @control_bt_synonym

					EXEC ep_component_glossary_mst_sp_ins @ctxt_language,
						@ctxt_ouinstance,
						@ctxt_service,
						@ctxt_user,
						@engg_customer_name,
						@engg_project_name,
						@engg_base_req_no,
						@tmp_processname,
						@tmp_componentname,
						@control_bt_synonym,
						NULL,
						'Char',
						@visisble_length,
						@control_bt_caption,
						@control_bt_synonym,
						'',
						'U',
						'',
						'',
						1,
						@engg_req_no,
						@m_errorid OUTPUT

					IF @m_errorid <> 0
					BEGIN
						CLOSE insert_ctrl_cur

						DEALLOCATE insert_ctrl_cur

						CLOSE insert_sec_cur

						DEALLOCATE insert_sec_cur

						CLOSE insert_page_cur

						DEALLOCATE insert_page_cur

						RETURN
					END
				END

				EXEC ep_task_generation @ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@engg_customer_name,
					@engg_project_name,
					@engg_base_req_no,
					@tmp_processname,
					@tmp_componentname,
					@tmp_activity,
					@tmp_ui,
					@page_name,
					@section_bt_synonym,
					@control_bt_synonym,
					'',
					@base_ctl_type,
					@event_req,
					@help_req,
					@zoom_req,
					@editable,
					'CONTROL',
					@report_req,
					@engg_req_no,
					@m_errorid OUTPUT

				IF @m_errorid <> 0
				BEGIN
					CLOSE insert_ctrl_cur

					DEALLOCATE insert_ctrl_cur

					CLOSE insert_sec_cur

					DEALLOCATE insert_sec_cur

					CLOSE insert_page_cur

					DEALLOCATE insert_page_cur

					RETURN
				END

				--Code modified by Ranjitha
				DECLARE @col_Icon_class engg_name,
					@col_Icon_position engg_name,
					@Col_class_ext6 engg_name,
					@Col_transform_as engg_name,
					@AssociateControl	engg_name	--Code Added for TECH-71262

			--	IF @base_ctl_type = 'Grid'
				IF @base_ctl_type IN ('Grid','ListView','Treegrid','Assorted','Pivot','Slider') --TECH-73321
				BEGIN
					DECLARE insert_col_cur INSENSITIVE CURSOR
					FOR
					SELECT rtrim(grd.column_bt_synonym),
						grd.column_no,
						rtrim(grd.col_doc),
						rtrim(grd.column_type),
						rtrim(grd.sample_data),
						rtrim(grd.proto_tooltip),
						grd.visible_length,
						grd.default_required,
						grd.visible,
						grd.ColumnClass,
						grd.Forcefit, --added for Bug Id : PNR2.0_32643
						grd.TemplateID,
						TemplateCategory,
						TemplateSpecific,
						AssociateControl,	--Code Added for TECH-71262
						isnull(RowExpander, 'N'),
						isnull(GridToForm, 'N') -- Added for PLF2.0_14096
						--Ranjitha
						,
						icon_class,
						icon_position,
						Column_class_ext6,
						column_Transformas,
						view_name --TECH-73321
					FROM ep_ui_grid_dtl grd(NOLOCK)
					WHERE grd.customer_name = @engg_customer_name
						AND grd.project_name = @engg_project_name
						AND grd.req_no = @engg_base_req_no
						AND grd.component_name = @tmp_ref_componentname
						AND grd.activity_name = @tmp_ref_activity
						AND grd.ui_name = @tmp_ref_ui
						AND grd.page_bt_synonym = @page_name
						AND grd.section_bt_synonym = @section_bt_synonym
						AND grd.control_bt_synonym = @control_bt_synonym

					OPEN insert_col_cur

					WHILE (1 = 1)
					BEGIN
						FETCH NEXT
						FROM insert_col_cur
						INTO @column_bt_synonym,
							@column_no,
							@col_doc,
							@column_type,
							@sample_data,
							@proto_tooltip,
							@visible_length,
							@engg_grid_default,
							@engg_grd_visible,
							@columnclass,
							@forcefit, --added for Bug Id : PNR2.0_32643
							@engg_col_tempid,
							@TemplateCategory,
							@TemplateSpecific,
							@AssociateControl,	--Code Added for TECH-71262
							@RowExpander,
							@GridToForm -- Added for PLF2.0_14096
							--Ranjitha
							,
							@col_Icon_class,
							@col_Icon_position,
							@col_class_ext6,
							@Col_transform_as,
							@view_name --TECH-73321

						IF @@fetch_status <> 0
							BREAK

						IF EXISTS (
								SELECT 'A'
								FROM ep_ui_section_dtl(NOLOCK)
								WHERE customer_name = @engg_customer_name
									AND project_name = @engg_project_name
									AND req_no = @engg_base_req_no
									AND process_name = @tmp_processname
									AND component_name = @tmp_componentname
									AND activity_name = @tmp_activity
									AND ui_name = @tmp_ui
									AND page_bt_synonym = @page_name
									AND section_bt_synonym = @column_bt_synonym
								)
						BEGIN
							SELECT @msg = 'Cannot Default. Column Bt Synonym ' + @column_bt_synonym + ' already exists in the Page as Section Bt Synonym'

							EXEC ENGG_ERROR_SP 'ep_layout_sp_defctl_hsv',
								7,
								@msg,
								@CTXT_LANGUAGE,
								@CTXT_OUINSTANCE,
								@CTXT_SERVICE,
								@CTXT_USER,
								'',
								'',
								'',
								'',
								@M_ERRORID OUTPUT

							CLOSE insert_col_cur

							DEALLOCATE insert_col_cur

							CLOSE insert_ctrl_cur

							DEALLOCATE insert_ctrl_cur

							CLOSE insert_sec_cur

							DEALLOCATE insert_sec_cur

							CLOSE insert_page_cur

							DEALLOCATE insert_page_cur

							RETURN
						END

						IF EXISTS (
								SELECT 'A'
								FROM ep_ui_control_dtl(NOLOCK)
								WHERE customer_name = @engg_customer_name
									AND project_name = @engg_project_name
									AND req_no = @engg_base_req_no
									AND process_name = @tmp_processname
									AND component_name = @tmp_componentname
									AND activity_name = @tmp_activity
									AND ui_name = @tmp_ui
									AND page_bt_synonym = @page_name
									AND control_bt_synonym = @column_bt_synonym
								)
						BEGIN
							SELECT @msg = 'Cannot Default. Column Bt Synonym ' + @column_bt_synonym + ' already exists in the Page as Control Bt Synonym'

							EXEC ENGG_ERROR_SP 'ep_layout_sp_defctl_hsv',
								7,
								@msg,
								@CTXT_LANGUAGE,
								@CTXT_OUINSTANCE,
								@CTXT_SERVICE,
								@CTXT_USER,
								'',
								'',
								'',
								'',
								@M_ERRORID OUTPUT

							CLOSE insert_col_cur

							DEALLOCATE insert_col_cur

							CLOSE insert_ctrl_cur

							DEALLOCATE insert_ctrl_cur

							CLOSE insert_sec_cur

							DEALLOCATE insert_sec_cur

							CLOSE insert_page_cur

							DEALLOCATE insert_page_cur

							RETURN
						END

						IF EXISTS (
								SELECT 'A'
								FROM ep_ui_grid_dtl(NOLOCK)
								WHERE customer_name = @engg_customer_name
									AND project_name = @engg_project_name
									AND process_name = @tmp_processname
									AND component_name = @tmp_componentname
									AND activity_name = @tmp_activity
									AND ui_name = @tmp_ui
									AND page_bt_synonym = @page_name
									AND column_bt_synonym = @column_bt_synonym
									AND req_no = @engg_base_req_no
								)
						BEGIN
							SELECT @msg = 'Cannot Default. Column Bt Synonym ' + @column_bt_synonym + ' already exists in the Page as Grid Column Bt Synonym'

							EXEC ENGG_ERROR_SP 'ep_layout_sp_defctl_hsv',
								7,
								@msg,
								@CTXT_LANGUAGE,
								@CTXT_OUINSTANCE,
								@CTXT_SERVICE,
								@CTXT_USER,
								'',
								'',
								'',
								'',
								@M_ERRORID OUTPUT

							CLOSE insert_col_cur

							DEALLOCATE insert_col_cur

							CLOSE insert_ctrl_cur

							DEALLOCATE insert_ctrl_cur

							CLOSE insert_sec_cur

							DEALLOCATE insert_sec_cur

							CLOSE insert_page_cur

							DEALLOCATE insert_page_cur

							RETURN
						END

						IF EXISTS (
								SELECT 'A'
								FROM de_hidden_view(NOLOCK)
								WHERE customer_name = @engg_customer_name
									AND project_name = @engg_project_name
									AND process_name = @tmp_processname
									AND component_name = @tmp_componentname
									AND activity_name = @tmp_activity
									AND ui_name = @tmp_ui
									AND page_name = @page_name
									AND hidden_view_bt_synonym = @column_bt_synonym
								)
						BEGIN
							SELECT @msg = 'Cannot Default. Column Bt Synonym ' + @column_bt_synonym + ' already exists in the Page as Hidden View Bt Synonym'

							EXEC ENGG_ERROR_SP 'ep_layout_sp_defctl_hsv',
								7,
								@msg,
								@CTXT_LANGUAGE,
								@CTXT_OUINSTANCE,
								@CTXT_SERVICE,
								@CTXT_USER,
								'',
								'',
								'',
								'',
								@M_ERRORID OUTPUT

							CLOSE insert_col_cur

							DEALLOCATE insert_col_cur

							CLOSE insert_ctrl_cur

							DEALLOCATE insert_ctrl_cur

							CLOSE insert_sec_cur

							DEALLOCATE insert_sec_cur

							CLOSE insert_page_cur

							DEALLOCATE insert_page_cur

							RETURN
						END

						IF EXISTS (
								SELECT 'A'
								FROM de_scratch_variable(NOLOCK)
								WHERE customer_name = @engg_customer_name
									AND project_name = @engg_project_name
									AND process_name = @tmp_processname
									AND component_name = @tmp_componentname
									AND activity_name = @tmp_activity
									AND ui_name = @tmp_ui
									AND page_name = @page_name
									AND scratch_name = @column_bt_synonym
								)
						BEGIN
							SELECT @msg = 'Cannot Default. Column Bt Synonym ' + @column_bt_synonym + ' already exists in the Page as User Defined Scratch Variable'

							EXEC ENGG_ERROR_SP 'ep_layout_sp_defctl_hsv',
								7,
								@msg,
								@CTXT_LANGUAGE,
								@CTXT_OUINSTANCE,
								@CTXT_SERVICE,
								@CTXT_USER,
								'',
								'',
								'',
								'',
								@M_ERRORID OUTPUT

							CLOSE insert_col_cur

							DEALLOCATE insert_col_cur

							CLOSE insert_ctrl_cur

							DEALLOCATE insert_ctrl_cur

							CLOSE insert_sec_cur

							DEALLOCATE insert_sec_cur

							CLOSE insert_page_cur

							DEALLOCATE insert_page_cur

							RETURN
						END

						IF EXISTS (
								SELECT 'x'
								FROM de_scratch_variables_sys(NOLOCK)
								WHERE btsynonym = @column_bt_synonym
								)
							OR @column_bt_synonym = 'Modeflag'
						BEGIN
							SELECT @msg = 'Cannot Default. Column Bt Synonym ' + @column_bt_synonym + ' already exists as a Default Scratch Variable'

							EXEC ENGG_ERROR_SP 'ep_layout_sp_defctl_hsv',
								7,
								@msg,
								@CTXT_LANGUAGE,
								@CTXT_OUINSTANCE,
								@CTXT_SERVICE,
								@CTXT_USER,
								'',
								'',
								'',
								'',
								@M_ERRORID OUTPUT

							CLOSE insert_col_cur

							DEALLOCATE insert_col_cur

							CLOSE insert_ctrl_cur

							DEALLOCATE insert_ctrl_cur

							CLOSE insert_sec_cur

							DEALLOCATE insert_sec_cur

							CLOSE insert_page_cur

							DEALLOCATE insert_page_cur

							RETURN
						END

						IF NOT EXISTS (
								SELECT 'x'
								FROM es_comp_ctrl_type_mst(NOLOCK)
								WHERE customer_name = @engg_customer_name
									AND project_name = @engg_project_name
									AND process_name = @tmp_processname
									AND component_name = @tmp_componentname
									AND ctrl_type_name = @column_type
								)
						BEGIN
							SELECT @msg = 'Default from Reference UI cannot be done as the column type ''' + @column_type + ''' does not exist in this component'

							EXEC ENGG_ERROR_SP 'ep_layout_sp_defctl_hsv',
								7,
								@msg,
								@CTXT_LANGUAGE,
								@CTXT_OUINSTANCE,
								@CTXT_SERVICE,
								@CTXT_USER,
								'',
								'',
								'',
								'',
								@M_ERRORID OUTPUT

							CLOSE insert_col_cur

							DEALLOCATE insert_col_cur

							CLOSE insert_ctrl_cur

							DEALLOCATE insert_ctrl_cur

							CLOSE insert_sec_cur

							DEALLOCATE insert_sec_cur

							CLOSE insert_page_cur

							DEALLOCATE insert_page_cur

							RETURN
						END

						EXEC engg_gen_prefix_id @engg_customer_name,
							@engg_project_name,
							@tmp_componentname,
							@tmp_activity,
							@tmp_ui,
							@column_bt_synonym,
							'C',
							6,
							@page_prefix_tmp OUTPUT

						SELECT @ctrl_bt_syn_id = control_id
						FROM ep_ui_control_dtl(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND req_no = @engg_base_req_no
							AND process_name = @tmp_processname
							AND component_name = @tmp_componentname
							AND activity_name = @tmp_activity
							AND ui_name = @tmp_ui
							AND page_bt_synonym = @page_name
							AND section_bt_synonym = @section_bt_synonym
							AND control_bt_synonym = @control_bt_synonym

						SELECT @ctrl_bt_syn_id = isnull(@ctrl_bt_syn_id, '')

					 --TECH-73321
						SELECT @IsTag = renderas
						FROM es_comp_ctrl_type_mst WITH (NOLOCK)
						WHERE customer_name		= @engg_customer_name
						AND project_name		= @engg_project_name
						AND process_name		= @tmp_processname
						AND component_name		= @tmp_componentname
						AND ctrl_type_name		= @control_type
						AND base_ctrl_type		= 'Grid'

						SELECT @Slider = 'Y'
						FROM es_comp_ctrl_type_mst WITH (NOLOCK)
						WHERE customer_name		= @engg_customer_name
						AND project_name		= @engg_project_name
						AND process_name		= @tmp_processname
						AND component_name		= @tmp_componentname
						AND ctrl_type_name		= @control_type
						AND base_ctrl_type		= 'SLIDER'
											
						IF ISNULL(@IsTag,'')	=	'Tag' 
						BEGIN
							SELECT @view_name = @view_name
						END

						ELSE IF ISNULL(@Slider,'')	=	'Y' 
						BEGIN
							SELECT @view_name = @view_name
						END
						---TECH-73321

						ELSE  --TECH-73321
						BEGIN
						SELECT @viewname_tmp = max(convert(INT, view_name))
						FROM ep_ui_grid_dtl(NOLOCK)
						WHERE customer_name		= @engg_customer_name
						AND project_name		= @engg_project_name
						AND req_no				= @engg_base_req_no
						AND process_name		= @tmp_processname
						AND component_name		= @tmp_componentname
						AND activity_name		= @tmp_activity
						AND ui_name				= @tmp_ui
						AND page_bt_synonym		= @page_name
						AND section_bt_synonym	= @section_bt_synonym
						AND control_bt_synonym	= @control_bt_synonym
						
						IF isnull(@viewname_tmp, '') = ''
						BEGIN
							SELECT @view_name = '1'
						END
						ELSE
						BEGIN
							SELECT @view_name = @viewname_tmp + 1
						END
						END

						EXEC ep_ui_grid_dtl_sp_ins @ctxt_language,
							@ctxt_ouinstance,
							@ctxt_service,
							@ctxt_user,
							@engg_customer_name,
							@engg_project_name,
							@engg_base_req_no,
							@tmp_processname,
							@tmp_componentname,
							@tmp_activity,
							@tmp_ui,
							@page_name,
							@section_bt_synonym,
							@control_bt_synonym,
							@column_bt_synonym,
							@ctrl_bt_syn_id,
							@view_name,
							@column_type,
							@column_no,
							@visible_length,
							@proto_tooltip,
							@sample_data,
							@col_doc,
							@page_prefix_tmp,
							1,
							@engg_req_no,
							@Set_User_Pref, --added for PNR2.0_26860
							@engg_grid_default, --added for Bug Id : PNR2.0_32643
							@engg_grd_visible,
							@columnclass,
							@engg_col_tempid, -- Added for PLF2.0_14096 
							@forcefit,
							@TemplateCategory,
							@TemplateSpecific,
							@associatecontrol,	--Code Added for TECH-71262
							@RowExpander,
							@GridToForm,
							'',
							@col_Icon_class,
							@col_Icon_position,
							@Col_class_ext6,
							@Col_transform_as,
							'',
							'',
							@m_errorid OUTPUT

						IF @m_errorid <> 0
						BEGIN
							CLOSE insert_col_cur

							DEALLOCATE insert_col_cur

							CLOSE insert_ctrl_cur

							DEALLOCATE insert_ctrl_cur

							CLOSE insert_sec_cur

							DEALLOCATE insert_sec_cur

							CLOSE insert_page_cur

							DEALLOCATE insert_page_cur

							RETURN
						END

						SELECT @visible_length = isnull(@visible_length, 20)

						IF @visible_length = 0
							SELECT @visible_length = 20

						IF NOT EXISTS (
								SELECT 'x'
								FROM ep_component_glossary_mst(NOLOCK)
								WHERE customer_name = @engg_customer_name
									AND project_name = @engg_project_name
									AND req_no = @engg_base_req_no
									AND process_name = @tmp_processname
									AND component_name = @tmp_componentname
									AND bt_synonym_name = @column_bt_synonym
								)
						BEGIN
							SELECT @column_bt_caption = bt_synonym_caption
							FROM ep_component_glossary_mst(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND req_no = @engg_base_req_no
								AND component_name = @tmp_ref_componentname
								AND bt_synonym_name = @column_bt_synonym

							EXEC ep_component_glossary_mst_sp_ins @ctxt_language,
								@ctxt_ouinstance,
								@ctxt_service,
								@ctxt_user,
								@engg_customer_name,
								@engg_project_name,
								@engg_base_req_no,
								@tmp_processname,
								@tmp_componentname,
								@column_bt_synonym,
								NULL,
								'Char',
								@visible_length,
								@column_bt_caption,
								@column_bt_synonym,
								'',
								'U',
								'',
								'',
								1,
								@engg_req_no,
								@m_errorid OUTPUT

							IF @m_errorid <> 0
							BEGIN
								CLOSE insert_col_cur

								DEALLOCATE insert_col_cur

								CLOSE insert_ctrl_cur

								DEALLOCATE insert_ctrl_cur

								CLOSE insert_sec_cur

								DEALLOCATE insert_sec_cur

								CLOSE insert_page_cur

								DEALLOCATE insert_page_cur

								RETURN
							END
						END

						SELECT @tmp_ctl = base_ctrl_type,
							@help_req = help_req,
							@event_req = event_handling_req,
							@zoom_req = zoom_req,
							@editable = editable_flag,
							@report_req = report_req
						FROM es_comp_ctrl_type_mst_vw(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @tmp_processname
							AND component_name = @tmp_componentname
							AND ctrl_type_name = @column_type
							AND req_no = @engg_base_req_no

						EXEC ep_task_generation @ctxt_language,
							@ctxt_ouinstance,
							@ctxt_service,
							@ctxt_user,
							@engg_customer_name,
							@engg_project_name,
							@engg_base_req_no,
							@tmp_processname,
							@tmp_componentname,
							@tmp_activity,
							@tmp_ui,
							@page_name,
							@section_bt_synonym,
							@control_bt_synonym,
							@column_bt_synonym,
							@tmp_ctl,
							@event_req,
							@help_req,
							@zoom_req,
							@editable,
							'COLUMN',
							@report_req,
							@engg_req_no,
							@m_errorid OUTPUT

						IF @m_errorid <> 0
						BEGIN
							CLOSE insert_col_cur

							DEALLOCATE insert_col_cur

							CLOSE insert_ctrl_cur

							DEALLOCATE insert_ctrl_cur

							CLOSE insert_sec_cur

							DEALLOCATE insert_sec_cur

							CLOSE insert_page_cur

							DEALLOCATE insert_page_cur

							RETURN
						END

						IF @tmp_ctl = 'Combo'
						BEGIN -- If base ctrl type = 'Combo' begins
							DECLARE insert_col_enum_cur INSENSITIVE CURSOR
							FOR
							SELECT rtrim(enum.enum_caption),
								rtrim(enum.enum_code),
								rtrim(enum.default_flag),
								enum.seq_no,
								enlg.languageid,
								enlg.enum_caption
							FROM ep_enum_value_dtl enum(NOLOCK)
							LEFT JOIN ep_enum_value_dtl_lng_extn enlg(NOLOCK) ON enum.customer_name = enlg.customer_name
								AND enum.project_name = enlg.project_name
								AND enum.req_no = enlg.req_no
								AND enum.component_name = enlg.component_name
								AND enum.activity_name = enlg.activity_name
								AND enum.ui_name = enlg.ui_name
								AND enum.page_bt_synonym = enlg.page_bt_synonym
								AND enum.section_bt_synonym = enlg.section_bt_synonym
								AND enum.control_bt_synonym = enlg.control_bt_synonym
								AND enum.enum_code = enlg.enum_code
							WHERE enum.customer_name = @engg_customer_name
								AND enum.project_name = @engg_project_name
								AND enum.req_no = @engg_base_req_no
								AND enum.component_name = @tmp_ref_componentname
								AND enum.activity_name = @tmp_ref_activity
								AND enum.ui_name = @tmp_ref_ui
								AND enum.page_bt_synonym = @page_name
								AND enum.section_bt_synonym = @section_bt_synonym
								AND enum.control_bt_synonym = @column_bt_synonym

							OPEN insert_col_enum_cur

							WHILE (1 = 1)
							BEGIN
								FETCH NEXT
								FROM insert_col_enum_cur
								INTO @enum_caption,
									@enum_code,
									@default_flag,
									@seq_no,
									@languageid,
									@enum_caption_lng

								IF @@fetch_status <> 0
									BREAK

								IF NOT EXISTS (
										SELECT 'x'
										FROM ep_enum_value_dtl enum(NOLOCK)
										WHERE enum.customer_name = @engg_customer_name
											AND enum.project_name = @engg_project_name
											AND enum.req_no = @engg_base_req_no
											AND enum.process_name = @tmp_processname
											AND enum.component_name = @tmp_componentname
											AND enum.activity_name = @tmp_activity
											AND enum.ui_name = @tmp_ui
											AND enum.page_bt_synonym = @page_name
											AND enum.section_bt_synonym = @section_bt_synonym
											AND enum.control_bt_synonym = @control_bt_synonym
											AND enum.enum_code = @enum_code
										)
								BEGIN
									EXEC ep_enum_value_dtl_sp_ins @ctxt_language,
										@ctxt_ouinstance,
										@ctxt_service,
										@ctxt_user,
										@engg_customer_name,
										@engg_project_name,
										@engg_base_req_no,
										@tmp_processname,
										@tmp_componentname,
										@tmp_activity,
										@tmp_ui,
										@page_name,
										@section_bt_synonym,
										@column_bt_synonym,
										@enum_code,
										@enum_caption,
										@default_flag,
										@seq_no,
										1,
										@engg_req_no,
										@m_errorid OUTPUT
								END

								SELECT @ui_section_sysid_tmp = dbo.ep_get_ui_section_sysid(@ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user, @engg_customer_name, @engg_project_name, @engg_base_req_no, @tmp_processname, @tmp_componentname, @tmp_activity, @tmp_ui, @page_name, @section_bt_synonym)

								IF isnull(@enum_caption_lng, '') <> ''
								BEGIN
									INSERT INTO ep_enum_value_dtl_lng_extn (
										customer_name,
										project_name,
										req_no,
										process_name,
										component_name,
										activity_name,
										ui_name,
										page_bt_synonym,
										section_bt_synonym,
										control_bt_synonym,
										enum_code,
										enum_caption,
										default_flag,
										seq_no,
										enum_value_sysid,
										ui_section_sysid,
										languageid,
										TIMESTAMP,
										createdby,
										createddate,
										modifiedby,
										modifieddate,
										wrkreqno
										)
									SELECT @engg_customer_name,
										@engg_project_name,
										@engg_base_req_no,
										@tmp_processname,
										@tmp_componentname,
										@tmp_activity,
										@tmp_ui,
										@page_name,
										@section_bt_synonym,
										@column_bt_synonym,
										@enum_code,
										@enum_caption,
										@default_flag,
										@seq_no,
										newid(),
										@ui_section_sysid_tmp,
										@languageid,
										1,
										@ctxt_user,
										getdate(),
										@ctxt_user,
										getdate(),
										@engg_req_no
								END

								IF @m_errorid <> 0
								BEGIN
									CLOSE insert_col_enum_cur

									DEALLOCATE insert_col_enum_cur

									CLOSE insert_col_cur

									DEALLOCATE insert_col_cur

									CLOSE insert_ctrl_cur

									DEALLOCATE insert_ctrl_cur

									CLOSE insert_sec_cur

									DEALLOCATE insert_sec_cur

									CLOSE insert_page_cur

									DEALLOCATE insert_page_cur

									RETURN
								END
							END

							CLOSE insert_col_enum_cur

							DEALLOCATE insert_col_enum_cur
						END -- If base ctrl type = 'Combo' ends
					END --Column while End

					CLOSE insert_col_cur

					DEALLOCATE insert_col_cur

					-----
					DECLARE insert_Grp_cur INSENSITIVE CURSOR
					FOR
					SELECT DISTINCT Group_name,
						Group_caption
					FROM ep_ui_columngroup grp(NOLOCK)
					WHERE grp.customer_name = @engg_customer_name
						AND grp.project_name = @engg_project_name
						AND grp.component_name = @tmp_ref_componentname
						AND grp.activity_name = @tmp_ref_activity
						AND grp.ui_name = @tmp_ref_ui
						AND grp.page_bt_synonym = @page_name
						AND grp.section_bt_synonym = @section_bt_synonym
						AND grp.grid_control_bt_synonym = @control_bt_synonym

					OPEN insert_Grp_cur

					WHILE (1 = 1)
					BEGIN
						FETCH NEXT
						FROM insert_Grp_cur
						INTO @group_name,
							@group_caption

						IF @@fetch_status <> 0
							BREAK

						IF EXISTS (
								SELECT 'X'
								FROM ep_ui_section_dtl(NOLOCK)
								WHERE customer_name = rtrim(@engg_customer_name)
									AND project_name = rtrim(@engg_project_name)
									AND process_name = rtrim(@tmp_processname)
									AND component_name = rtrim(@tmp_componentname)
									AND activity_name = rtrim(@tmp_activity)
									AND ui_name = rtrim(@tmp_ui)
									AND section_bt_synonym = rtrim(@group_name)
								)
						BEGIN
							RAISERROR (
									'Default from Refrence UI Cannot be performed as Group Name "%s" already exists as a Section(BT Synonym) in the UI',
									16,
									4,
									@group_name
									)

							RETURN
						END

						IF EXISTS (
								SELECT 'X'
								FROM ep_ui_control_dtl(NOLOCK)
								WHERE customer_name = rtrim(@engg_customer_name)
									AND project_name = rtrim(@engg_project_name)
									AND process_name = rtrim(@tmp_processname)
									AND component_name = rtrim(@tmp_componentname)
									AND activity_name = rtrim(@tmp_activity)
									AND ui_name = rtrim(@tmp_ui)
									AND control_bt_synonym = rtrim(@group_name)
								)
						BEGIN
							RAISERROR (
									'Default from Refrence UI Cannot be performed as Group Name "%s" already exists as a Control(BT Synonym) in the UI',
									16,
									4,
									@group_name
									)

							RETURN
						END

						IF EXISTS (
								SELECT 'X'
								FROM ep_ui_grid_dtl(NOLOCK)
								WHERE customer_name = rtrim(@engg_customer_name)
									AND project_name = rtrim(@engg_project_name)
									AND process_name = rtrim(@tmp_processname)
									AND component_name = rtrim(@tmp_componentname)
									AND activity_name = rtrim(@tmp_activity)
									AND ui_name = rtrim(@tmp_ui)
									AND column_bt_synonym = rtrim(@group_name)
								)
						BEGIN
							RAISERROR (
									'Default from Refrence UI Cannot be performed as Group Name "%s" already exists as a Grid(BT Synonym) in the UI',
									16,
									4,
									@group_name
									)

							RETURN
						END

						IF EXISTS (
								SELECT 'X'
								FROM de_hidden_view(NOLOCK)
								WHERE customer_name = rtrim(@engg_customer_name)
									AND project_name = rtrim(@engg_project_name)
									AND process_name = rtrim(@tmp_processname)
									AND component_name = rtrim(@tmp_componentname)
									AND activity_name = rtrim(@tmp_activity)
									AND ui_name = rtrim(@tmp_ui)
									AND hidden_view_bt_synonym = rtrim(@group_name)
								)
						BEGIN
							RAISERROR (
									'Default from Refrence UI Cannot be performed as Group Name "%s" already exists as a Hidden View(BT Synonym) in the UI',
									16,
									4,
									@group_name
									)

							RETURN
						END

						IF EXISTS (
								SELECT 'X'
								FROM de_scratch_variable(NOLOCK)
								WHERE customer_name = rtrim(@engg_customer_name)
									AND project_name = rtrim(@engg_project_name)
									AND process_name = rtrim(@tmp_processname)
									AND component_name = rtrim(@tmp_componentname)
									AND activity_name = rtrim(@tmp_activity)
									AND ui_name = rtrim(@tmp_ui)
									AND scratch_name = rtrim(@group_name)
								)
						BEGIN
							RAISERROR (
									'Default from Refrence UI Cannot be performed as Group Name "%s" already exists as a User Defined Scratch Variable in the UI',
									16,
									4,
									@group_name
									)

							RETURN
						END

						IF EXISTS (
								SELECT 'x'
								FROM de_scratch_variables_sys(NOLOCK)
								WHERE btsynonym = @group_name
								)
							OR @group_name = 'Modeflag'
						BEGIN
							RAISERROR (
									'Default from Refrence UI Cannot be performed as Group Name "%s" already exists as a Default Scratch Variable',
									16,
									4,
									@group_name
									)

							RETURN
						END

						IF EXISTS (
								SELECT 'X'
								FROM ep_listedit_column_dtl(NOLOCK)
								WHERE customer_name = rtrim(@engg_customer_name)
									AND project_name = rtrim(@engg_project_name)
									AND process_name = rtrim(@tmp_processname)
									AND component_name = rtrim(@tmp_componentname)
									AND activity_name = rtrim(@tmp_activity)
									AND ui_name = rtrim(@tmp_ui)
									AND listedit_column_synonym = rtrim(@group_name)
								)
						BEGIN
							RAISERROR (
									'Default from Refrence UI Cannot be performed as Group Name "%s" already exists as a List Edit Column Name in the UI',
									16,
									4,
									@group_name
									)

							RETURN
						END

						IF EXISTS (
								SELECT 'x'
								FROM ep_ui_columngroup(NOLOCK)
								WHERE customer_name = rtrim(@engg_customer_name)
									AND project_name = rtrim(@engg_project_name)
									AND process_name = rtrim(@tmp_processname)
									AND component_name = rtrim(@tmp_componentname)
									AND activity_name = rtrim(@tmp_activity)
									AND ui_name = rtrim(@tmp_ui)
									AND group_name = RTRIM(@group_name)
								)
						BEGIN
							RAISERROR (
									'Default from Refrence UI Cannot be performed as The Group Name "%s" already exists in the UI.',
									16,
									4,
									@group_name
									)

							RETURN
						END

						INSERT INTO ep_ui_columngroup (
							customer_name,
							project_name,
							req_no,
							process_name,
							component_name,
							activity_name,
							ui_name,
							Page_bt_synonym,
							section_bt_synonym,
							grid_control_bt_synonym,
							Group_name,
							Group_caption,
							wrkreqno,
							TIMESTAMP,
							createdby,
							createddate,
							modifiedby,
							modifieddate
							)
						SELECT @engg_customer_name,
							@engg_project_name,
							@engg_base_req_no,
							@tmp_processname,
							@tmp_componentname,
							@tmp_activity,
							@tmp_ui,
							@page_name,
							@section_bt_synonym,
							@control_bt_synonym,
							@group_name,
							@group_caption,
							@engg_req_no,
							1,
							@ctxt_user,
							GETDATE(),
							@ctxt_user,
							GETDATE()

						IF NOT EXISTS (
								SELECT 'x'
								FROM ep_component_glossary_mst(NOLOCK)
								WHERE customer_name = @engg_customer_name
									AND project_name = @engg_project_name
									AND req_no = @engg_base_req_no
									AND process_name = @tmp_processname
									AND component_name = @tmp_componentname
									AND bt_synonym_name = @column_bt_synonym
								)
						BEGIN
							EXEC ep_component_glossary_mst_sp_ins @ctxt_language,
								@ctxt_ouinstance,
								@ctxt_service,
								@ctxt_user,
								@engg_customer_name,
								@engg_project_name,
								@engg_base_req_no,
								@tmp_processname,
								@tmp_componentname,
								@Group_name,
								NULL,
								'Char',
								NULL,
								@group_caption,
								@Group_name,
								'',
								'U',
								'',
								'',
								1,
								@engg_req_no,
								@m_errorid OUTPUT

							IF @m_errorid <> 0
							BEGIN
								CLOSE insert_Grp_cur

								DEALLOCATE insert_Grp_cur

								CLOSE insert_ctrl_cur

								DEALLOCATE insert_ctrl_cur

								CLOSE insert_sec_cur

								DEALLOCATE insert_sec_cur

								CLOSE insert_page_cur

								DEALLOCATE insert_page_cur

								RETURN
							END
						END
					END

					CLOSE insert_Grp_cur

					DEALLOCATE insert_Grp_cur

					DECLARE insert_ColGrp_cur INSENSITIVE CURSOR
					FOR
					SELECT DISTINCT Group_name,
						column_bt_synonym,
						SequenceNo,
						mapped_entity
					FROM ep_ui_column_group_mapping grp(NOLOCK)
					WHERE grp.customer_name = @engg_customer_name
						AND grp.project_name = @engg_project_name
						AND grp.component_name = @tmp_ref_componentname
						AND grp.activity_name = @tmp_ref_activity
						AND grp.ui_name = @tmp_ref_ui
						AND grp.page_bt_synonym = @page_name
						AND grp.section_bt_synonym = @section_bt_synonym
						AND grp.grid_control_bt_synonym = @control_bt_synonym

					OPEN insert_ColGrp_cur

					WHILE (1 = 1)
					BEGIN
						FETCH NEXT
						FROM insert_ColGrp_cur
						INTO @group_name,
							@column_bt_synonym,
							@seqno,
							@mapped_ent

						IF @@fetch_status <> 0
							BREAK

						INSERT INTO ep_ui_column_group_mapping (
							customer_name,
							project_name,
							req_no,
							process_name,
							component_name,
							activity_name,
							ui_name,
							Page_bt_synonym,
							section_bt_synonym,
							grid_control_bt_synonym,
							Group_name,
							column_bt_synonym,
							SequenceNo,
							mapped_entity,
							wrkreqno,
							TIMESTAMP,
							createdby,
							createddate,
							modifiedby,
							modifieddate
							)
						SELECT @engg_customer_name,
							@engg_project_name,
							@engg_base_req_no,
							@tmp_processname,
							@tmp_componentname,
							@tmp_activity,
							@tmp_ui,
							@page_name,
							@section_bt_synonym,
							@control_bt_synonym,
							@group_name,
							@column_bt_synonym,
							@Seqno,
							@mapped_ent,
							@engg_req_no,
							1,
							@ctxt_user,
							GETDATE(),
							@ctxt_user,
							GETDATE()
					END

					CLOSE insert_ColGrp_cur

					DEALLOCATE insert_ColGrp_cur
				END -- If base ctrl type = 'Grid' ends

				IF @base_ctl_type = 'RadioButton'
				BEGIN -- If base ctrl type = 'Radio Button' begins
					DECLARE insert_rad_cur INSENSITIVE CURSOR
					FOR
					SELECT DISTINCT rtrim(rad.button_caption),
						rtrim(rad.button_code),
						rtrim(rad.default_flag),
						rad.seq_no,
						rad.horder,
						rad.vorder,
						rdlg.languageid,
						rdlg.button_caption
					FROM ep_radio_button_dtl rad(NOLOCK)
					LEFT JOIN ep_radio_button_dtl_lng_extn rdlg(NOLOCK) ON rad.customer_name = rdlg.customer_name
						AND rad.project_name = rdlg.project_name
						AND rad.req_no = rdlg.req_no
						AND rad.component_name = rdlg.component_name
						AND rad.activity_name = rdlg.activity_name
						AND rad.ui_name = rdlg.ui_name
						AND rad.page_bt_synonym = rdlg.page_bt_synonym
						AND rad.section_bt_synonym = rdlg.section_bt_synonym
						AND rad.control_bt_synonym = rdlg.control_bt_synonym
						AND rad.button_code = rdlg.button_code
					WHERE rad.customer_name = @engg_customer_name
						AND rad.project_name = @engg_project_name
						AND rad.req_no = @engg_base_req_no
						AND rad.component_name = @tmp_ref_componentname
						AND rad.activity_name = @tmp_ref_activity
						AND rad.ui_name = @tmp_ref_ui
						AND rad.page_bt_synonym = @page_name
						AND rad.section_bt_synonym = @section_bt_synonym
						AND rad.control_bt_synonym = @control_bt_synonym

					OPEN insert_rad_cur

					WHILE (1 = 1)
					BEGIN
						FETCH NEXT
						FROM insert_rad_cur
						INTO @button_caption,
							@button_code,
							@default_flag,
							@seq_no,
							@horder,
							@vorder,
							@languageid,
							@button_caption_lng

						IF @@fetch_status <> 0
							BREAK

						IF NOT EXISTS (
								SELECT 'x'
								FROM ep_radio_button_dtl rad(NOLOCK)
								WHERE rad.customer_name = @engg_customer_name
									AND rad.project_name = @engg_project_name
									AND rad.req_no = @engg_base_req_no
									AND rad.component_name = @tmp_componentname
									AND rad.activity_name = @tmp_activity
									AND rad.ui_name = @tmp_ui
									AND rad.page_bt_synonym = @page_name
									AND rad.section_bt_synonym = @section_bt_synonym
									AND rad.control_bt_synonym = @control_bt_synonym
									AND rad.button_code = @button_code
								)
						BEGIN
							EXEC ep_radio_button_dtl_sp_ins @ctxt_language,
								@ctxt_ouinstance,
								@ctxt_service,
								@ctxt_user,
								@engg_customer_name,
								@engg_project_name,
								@engg_base_req_no,
								@tmp_processname,
								@tmp_componentname,
								@tmp_activity,
								@tmp_ui,
								@page_name,
								@section_bt_synonym,
								@control_bt_synonym,
								@button_code,
								@seq_no,
								@button_caption,
								@default_flag,
								@horder,
								@vorder,
								1,
								@engg_req_no,
								@m_errorid OUTPUT
						END

						SELECT @ui_control_sysid = dbo.ep_get_ui_control_sysid(@ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user, @engg_customer_name, @engg_project_name, @engg_base_req_no, @tmp_processname, @tmp_componentname, @tmp_activity, @tmp_ui, @page_name, @section_bt_synonym, @control_bt_synonym)

						IF isnull(@button_caption_lng, '') <> ''
						BEGIN
							INSERT INTO ep_radio_button_dtl_lng_extn (
								customer_name,
								project_name,
								req_no,
								process_name,
								component_name,
								activity_name,
								ui_name,
								page_bt_synonym,
								section_bt_synonym,
								control_bt_synonym,
								button_code,
								seq_no,
								button_caption,
								default_flag,
								horder,
								vorder,
								radio_button_sysid,
								ui_control_sysid,
								languageid,
								TIMESTAMP,
								createdby,
								createddate,
								modifiedby,
								modifieddate,
								wrkreqno
								)
							SELECT @engg_customer_name,
								@engg_project_name,
								@engg_base_req_no,
								@tmp_processname,
								@tmp_componentname,
								@tmp_activity,
								@tmp_ui,
								@page_name,
								@section_bt_synonym,
								@control_bt_synonym,
								@button_code,
								@seq_no,
								@button_caption_lng,
								@default_flag,
								@horder,
								@vorder,
								newid(),
								@ui_control_sysid,
								@languageid,
								1,
								@ctxt_user,
								getdate(),
								@ctxt_user,
								getdate(),
								@engg_req_no
						END

						IF @m_errorid <> 0
						BEGIN
							CLOSE insert_rad_cur

							DEALLOCATE insert_rad_cur

							CLOSE insert_ctrl_cur

							DEALLOCATE insert_ctrl_cur

							CLOSE insert_sec_cur

							DEALLOCATE insert_sec_cur

							CLOSE insert_page_cur

							DEALLOCATE insert_page_cur

							RETURN
						END
					END

					CLOSE insert_rad_cur

					DEALLOCATE insert_rad_cur
				END -- If base ctrl type = 'Radio Button' ends

				IF @base_ctl_type = 'Combo'
				BEGIN -- If base ctrl type = 'Combo' begins
					DECLARE insert_enum_cur INSENSITIVE CURSOR
					FOR
					SELECT rtrim(enum.enum_caption),
						rtrim(enum.enum_code),
						rtrim(enum.default_flag),
						enum.seq_no,
						enlg.languageid,
						enlg.enum_caption
					FROM ep_enum_value_dtl enum(NOLOCK)
					LEFT JOIN ep_enum_value_dtl_lng_extn enlg(NOLOCK) ON enum.customer_name = enlg.customer_name
						AND enum.project_name = enlg.project_name
						AND enum.req_no = enlg.req_no
						AND enum.component_name = enlg.component_name
						AND enum.activity_name = enlg.activity_name
						AND enum.ui_name = enlg.ui_name
						AND enum.page_bt_synonym = enlg.page_bt_synonym
						AND enum.section_bt_synonym = enlg.section_bt_synonym
						AND enum.control_bt_synonym = enlg.control_bt_synonym
						AND enum.enum_code = enlg.enum_code
					WHERE enum.customer_name = @engg_customer_name
						AND enum.project_name = @engg_project_name
						AND enum.req_no = @engg_base_req_no
						AND enum.component_name = @tmp_ref_componentname
						AND enum.activity_name = @tmp_ref_activity
						AND enum.ui_name = @tmp_ref_ui
						AND enum.page_bt_synonym = @page_name
						AND enum.section_bt_synonym = @section_bt_synonym
						AND enum.control_bt_synonym = @control_bt_synonym

					OPEN insert_enum_cur

					WHILE (1 = 1)
					BEGIN
						FETCH NEXT
						FROM insert_enum_cur
						INTO @enum_caption,
							@enum_code,
							@default_flag,
							@seq_no,
							@languageid,
							@enum_caption_lng

						IF @@fetch_status <> 0
							BREAK

						IF NOT EXISTS (
								SELECT 'x'
								FROM ep_enum_value_dtl enum(NOLOCK)
								WHERE enum.customer_name = @engg_customer_name
									AND enum.project_name = @engg_project_name
									AND enum.req_no = @engg_base_req_no
									AND enum.process_name = @tmp_processname
									AND enum.component_name = @tmp_componentname
									AND enum.activity_name = @tmp_activity
									AND enum.ui_name = @tmp_ui
									AND enum.page_bt_synonym = @page_name
									AND enum.section_bt_synonym = @section_bt_synonym
									AND enum.control_bt_synonym = @control_bt_synonym
									AND enum.enum_code = @enum_code
								)
						BEGIN
							EXEC ep_enum_value_dtl_sp_ins @ctxt_language,
								@ctxt_ouinstance,
								@ctxt_service,
								@ctxt_user,
								@engg_customer_name,
								@engg_project_name,
								@engg_base_req_no,
								@tmp_processname,
								@tmp_componentname,
								@tmp_activity,
								@tmp_ui,
								@page_name,
								@section_bt_synonym,
								@control_bt_synonym,
								@enum_code,
								@enum_caption,
								@default_flag,
								@seq_no,
								1,
								@engg_req_no,
								@m_errorid OUTPUT
						END

						SELECT @ui_section_sysid_tmp = dbo.ep_get_ui_section_sysid(@ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user, @engg_customer_name, @engg_project_name, @engg_base_req_no, @tmp_processname, @tmp_componentname, @tmp_activity, @tmp_ui, @page_name, @section_bt_synonym)

						IF isnull(@enum_caption_lng, '') <> ''
						BEGIN
							INSERT INTO ep_enum_value_dtl_lng_extn (
								customer_name,
								project_name,
								req_no,
								process_name,
								component_name,
								activity_name,
								ui_name,
								page_bt_synonym,
								section_bt_synonym,
								control_bt_synonym,
								enum_code,
								enum_caption,
								default_flag,
								seq_no,
								enum_value_sysid,
								ui_section_sysid,
								languageid,
								TIMESTAMP,
								createdby,
								createddate,
								modifiedby,
								modifieddate,
								wrkreqno
								)
							SELECT @engg_customer_name,
								@engg_project_name,
								@engg_base_req_no,
								@tmp_processname,
								@tmp_componentname,
								@tmp_activity,
								@tmp_ui,
								@page_name,
								@section_bt_synonym,
								@control_bt_synonym,
								@enum_code,
								@enum_caption,
								@default_flag,
								@seq_no,
								newid(),
								@ui_section_sysid_tmp,
								@languageid,
								1,
								@ctxt_user,
								getdate(),
								@ctxt_user,
								getdate(),
								@engg_req_no
						END

						IF @m_errorid <> 0
						BEGIN
							CLOSE insert_enum_cur

							DEALLOCATE insert_enum_cur

							CLOSE insert_ctrl_cur

							DEALLOCATE insert_ctrl_cur

							CLOSE insert_sec_cur

							DEALLOCATE insert_sec_cur

							CLOSE insert_page_cur

							DEALLOCATE insert_page_cur

							RETURN
						END
					END

					CLOSE insert_enum_cur

					DEALLOCATE insert_enum_cur
				END -- If base ctrl type = 'Combo' ends
						--Go to Next Control BT Syn
			END --Control while End

			CLOSE insert_ctrl_cur

			DEALLOCATE insert_ctrl_cur
				--Go to Next Section BT Syn
		END -- Section while End

		CLOSE insert_sec_cur

		DEALLOCATE insert_sec_cur

		DECLARE insert_lnk_cur INSENSITIVE CURSOR
		FOR
		/*  Selecting controls from ep_ui_control_dtl table not existing in ui_traversal_dtl table
for the reference UI and not existing in ep_ui_control_dtl for which the section detail
already saved and whose base control type is 'Link'*/
		SELECT '',
			'',
			'lnk',
			'',
			control_bt_synonym,
			section_bt_synonym,
			'',
			''
		FROM ep_ui_control_dtl c(NOLOCK),
			es_comp_ctrl_type_mst_vw m(NOLOCK)
		WHERE c.customer_name = @engg_customer_name
			AND c.project_name = @engg_project_name
			AND c.req_no = @engg_base_req_no
			AND c.component_name = @tmp_ref_componentname
			AND c.activity_name = @tmp_ref_activity
			AND c.ui_name = @tmp_ref_ui
			AND c.page_bt_synonym = @page_name
			AND c.customer_name = m.customer_name
			AND c.project_name = m.project_name
			AND c.req_no = m.req_no
			AND c.process_name = m.process_name
			AND c.component_name = m.component_name
			AND c.control_type = m.ctrl_type_name
			AND m.base_ctrl_type = 'link'
			AND NOT EXISTS (
				SELECT 'x'
				FROM ep_ui_control_dtl a1(NOLOCK)
				WHERE a1.customer_name = c.customer_name
					AND a1.project_name = c.project_name
					AND a1.req_no = c.req_no
					AND a1.process_name = c.process_name
					AND a1.component_name = c.component_name
					AND a1.activity_name = c.activity_name
					AND a1.ui_name = c.ui_name
					AND a1.page_bt_synonym = c.page_bt_synonym
					AND a1.section_bt_synonym <> c.section_bt_synonym
					AND a1.control_bt_synonym = c.control_bt_synonym
				)
			AND NOT EXISTS (
				SELECT 'x'
				FROM ep_ui_traversal_dtl t1(NOLOCK)
				WHERE t1.customer_name = c.customer_name
					AND t1.project_name = c.project_name
					AND t1.req_no = c.req_no
					AND t1.process_name = c.process_name
					AND t1.component_name = c.component_name
					AND t1.activity_name = c.activity_name
					AND t1.ui_name = c.ui_name
					AND t1.page_bt_synonym = c.page_bt_synonym
					AND t1.section_bt_synonym = c.section_bt_synonym
					AND t1.control_bt_synonym = c.control_bt_synonym
				)
		
		UNION
		
		/*  Selecting columns from ui_grid_dtl table not existing in ui_traversal_dtl table for the
reference UI and not existing in ui_grid_dtl for which the control detail already
saved and whose base control type is 'Link'*/
		SELECT '',
			'',
			'lnk',
			'',
			column_bt_synonym,
			section_bt_synonym,
			'',
			''
		FROM ep_ui_grid_dtl g(NOLOCK),
			es_comp_ctrl_type_mst_vw m(NOLOCK)
		WHERE g.customer_name = @engg_customer_name
			AND g.project_name = @engg_project_name
			AND g.req_no = @engg_base_req_no
			AND g.component_name = @tmp_ref_componentname
			AND g.activity_name = @tmp_ref_activity
			AND g.ui_name = @tmp_ref_ui
			AND g.page_bt_synonym = @page_name
			AND g.customer_name = m.customer_name
			AND g.project_name = m.project_name
			AND g.req_no = m.req_no
			AND g.process_name = m.process_name
			AND g.component_name = m.component_name
			AND g.column_type = m.ctrl_type_name
			AND m.base_ctrl_type = 'link'
			AND NOT EXISTS (
				SELECT 'x'
				FROM ep_ui_grid_dtl a1(NOLOCK)
				WHERE a1.customer_name = g.customer_name
					AND a1.project_name = g.project_name
					AND a1.req_no = g.req_no
					AND a1.process_name = g.process_name
					AND a1.component_name = g.component_name
					AND a1.activity_name = g.activity_name
					AND a1.ui_name = g.ui_name
					AND a1.page_bt_synonym = g.page_bt_synonym
					AND a1.section_bt_synonym = g.section_bt_synonym
					AND a1.control_bt_synonym <> g.control_bt_synonym
				)
			AND NOT EXISTS (
				SELECT 'x'
				FROM ep_ui_traversal_dtl t1(NOLOCK)
				WHERE t1.customer_name = g.customer_name
					AND t1.project_name = g.project_name
					AND t1.req_no = g.req_no
					AND t1.process_name = g.process_name
					AND t1.component_name = g.component_name
					AND t1.activity_name = g.activity_name
					AND t1.ui_name = g.ui_name
					AND t1.page_bt_synonym = g.page_bt_synonym
					AND t1.section_bt_synonym = g.section_bt_synonym
					AND t1.control_bt_synonym = g.column_bt_synonym
				)
		
		UNION
		
		/*  Selecting controls from ui_control_dtl table not existing in ui_traversal_dtl table for the
reference UI and not existing in ui_control_dtl for which the section detail already
saved and whose help_required flag value is 'Y'*/
		SELECT '',
			'',
			'hlp',
			'',
			control_bt_synonym,
			section_bt_synonym,
			'',
			''
		FROM ep_ui_control_dtl c(NOLOCK),
			es_comp_ctrl_type_mst_vw m(NOLOCK)
		WHERE c.customer_name = @engg_customer_name
			AND c.project_name = @engg_project_name
			AND c.req_no = @engg_base_req_no
			AND c.component_name = @tmp_ref_componentname
			AND c.activity_name = @tmp_ref_activity
			AND c.ui_name = @tmp_ref_ui
			AND c.page_bt_synonym = @page_name
			AND c.customer_name = m.customer_name
			AND c.project_name = m.project_name
			AND c.req_no = m.req_no
			AND c.process_name = m.process_name
			AND c.component_name = m.component_name
			AND c.control_type = m.ctrl_type_name
			AND m.help_req = 'y'
			AND NOT EXISTS (
				SELECT 'x'
				FROM ep_ui_control_dtl a1(NOLOCK)
				WHERE a1.customer_name = c.customer_name
					AND a1.project_name = c.project_name
					AND a1.req_no = c.req_no
					AND a1.process_name = c.process_name
					AND a1.component_name = c.component_name
					AND a1.activity_name = c.activity_name
					AND a1.ui_name = c.ui_name
					AND a1.page_bt_synonym = c.page_bt_synonym
					AND a1.section_bt_synonym <> c.section_bt_synonym
					AND a1.control_bt_synonym = c.control_bt_synonym
				)
			AND NOT EXISTS (
				SELECT 'x'
				FROM ep_ui_traversal_dtl t1(NOLOCK)
				WHERE t1.customer_name = c.customer_name
					AND t1.project_name = c.project_name
					AND t1.req_no = c.req_no
					AND t1.process_name = c.process_name
					AND t1.component_name = c.component_name
					AND t1.activity_name = c.activity_name
					AND t1.ui_name = c.ui_name
					AND t1.page_bt_synonym = c.page_bt_synonym
					AND t1.section_bt_synonym = c.section_bt_synonym
					AND t1.control_bt_synonym = c.control_bt_synonym
				)
		
		UNION
		
		/*  Selecting columns from ui_grid_dtl table not existing in ui_traversal_dtl table for the
reference UI and not existing in ui_grid_dtl for which the control detail already
saved and whose help_required flag value is 'Y'*/
		SELECT '',
			'',
			'hlp',
			'',
			column_bt_synonym,
			section_bt_synonym,
			'',
			''
		FROM ep_ui_grid_dtl g(NOLOCK),
			es_comp_ctrl_type_mst_vw m(NOLOCK)
		WHERE g.customer_name = @engg_customer_name
			AND g.project_name = @engg_project_name
			AND g.req_no = @engg_base_req_no
			AND g.component_name = @tmp_ref_componentname
			AND g.activity_name = @tmp_ref_activity
			AND g.ui_name = @tmp_ref_ui
			AND g.page_bt_synonym = @page_name
			AND g.customer_name = m.customer_name
			AND g.project_name = m.project_name
			AND g.req_no = m.req_no
			AND g.process_name = m.process_name
			AND g.component_name = m.component_name
			AND g.column_type = m.ctrl_type_name
			AND m.help_req = 'y'
			AND NOT EXISTS (
				SELECT 'x'
				FROM ep_ui_grid_dtl a1(NOLOCK)
				WHERE a1.customer_name = g.customer_name
					AND a1.project_name = g.project_name
					AND a1.req_no = g.req_no
					AND a1.process_name = g.process_name
					AND a1.component_name = g.component_name
					AND a1.activity_name = g.activity_name
					AND a1.ui_name = g.ui_name
					AND a1.page_bt_synonym = g.page_bt_synonym
					AND a1.section_bt_synonym = g.section_bt_synonym
					AND a1.control_bt_synonym <> g.control_bt_synonym
				)
			AND NOT EXISTS (
				SELECT 'x'
				FROM ep_ui_traversal_dtl t1(NOLOCK)
				WHERE t1.customer_name = g.customer_name
					AND t1.project_name = g.project_name
					AND t1.req_no = g.req_no
					AND t1.process_name = g.process_name
					AND t1.component_name = g.component_name
					AND t1.activity_name = g.activity_name
					AND t1.ui_name = g.ui_name
					AND t1.page_bt_synonym = g.page_bt_synonym
					AND t1.section_bt_synonym = g.section_bt_synonym
					AND t1.control_bt_synonym = g.column_bt_synonym
				)
		
		UNION
		
		SELECT linked_activity,
			linked_component,
			link_type,
			linked_ui,
			control_bt_synonym,
			section_bt_synonym,
			associated_ctrl_bt_synonym,
			LinkLaunchType
		FROM ep_ui_traversal_dtl lnk(NOLOCK)
		WHERE lnk.customer_name = @engg_customer_name
			AND lnk.project_name = @engg_project_name
			AND lnk.req_no = @engg_base_req_no
			AND lnk.component_name = @tmp_ref_componentname
			AND lnk.activity_name = @tmp_ref_activity
			AND lnk.ui_name = @tmp_ref_ui
			AND lnk.page_bt_synonym = @page_name

		OPEN insert_lnk_cur

		WHILE 1 = 1
		BEGIN
			FETCH NEXT
			FROM insert_lnk_cur
			INTO @link_activity,
				@link_component,
				@link_type,
				@link_ui,
				@link_pcv_caption,
				@section_bt_synonym,
				@engg_links_asso_ctrl,
				@engg_launch_type

			IF @@fetch_status <> 0
				BREAK

			EXEC ep_ui_traversal_dtl_sp_ins @ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@engg_customer_name,
				@engg_project_name,
				@engg_base_req_no,
				@tmp_processname,
				@tmp_componentname,
				@tmp_activity,
				@tmp_ui,
				@page_name,
				@section_bt_synonym,
				@link_pcv_caption,
				@link_type,
				@link_component,
				@link_activity,
				@link_ui,
				@engg_links_asso_ctrl,
				1,
				@engg_req_no,
				'',
				'',
				'',
				@engg_launch_type,
				@m_errorid OUTPUT

			IF @m_errorid <> 0
			BEGIN
				CLOSE insert_lnk_cur

				DEALLOCATE insert_lnk_cur
			END
		END

		CLOSE insert_lnk_cur

		DEALLOCATE insert_lnk_cur
			--Go to Next Page BT Syn
	END --Page while end

	CLOSE insert_page_cur

	DEALLOCATE insert_page_cur

	-- After pages inserted from Ref UI, check for Tab pages and [Tabcontrol] section to be inserted if one or more Tab Pages available
	IF EXISTS (
			SELECT 'x'
			FROM ep_ui_page_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_base_req_no
				AND process_name = @tmp_processname
				AND component_name = @tmp_componentname
				AND activity_name = @tmp_activity
				AND ui_name = @tmp_ui
				AND page_bt_synonym <> '[mainscreen]'
			)
	BEGIN --if tab pages available in the UI
		IF NOT EXISTS (
				SELECT 'x'
				FROM ep_ui_section_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @tmp_processname
					AND component_name = @tmp_componentname
					AND activity_name = @tmp_activity
					AND ui_name = @tmp_ui
					AND page_bt_synonym = '[mainscreen]'
					AND section_bt_synonym = '[tabcontrol]'
				)
		BEGIN -- check for [tabcontrol] existence
			SELECT @engg_section_type_in = section_type,
				@engg_sec_cap_align = ctrl_caption_align,
				@engg_sec_cap_format = caption_Format,
				@sectionheight = height,
				@sectionwidth = width,
				@Section_width_Scalemode = Section_width_Scalemode,
				@Section_height_Scalemode = Section_height_Scalemode,
				@Sec_CollapseMode = section_collapsemode,
				--Tech-70687 
				@engg_lefttb	=	case when LeftToolbar	=	'y' then 1 else 0 end	,
				@engg_righttb	=	case when RightToolbar	=	'y' then 1 else 0 end	,
				@engg_bottomtb	=	case when TopToolbar	=	'y' then 1 else 0 end	,
				@engg_toptb		=	case when BottomToolbar	=	'y' then 1 else 0 end	
				--Tech-70687 
			FROM ep_ui_section_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_base_req_no
				AND component_name = @tmp_ref_componentname
				AND activity_name = @tmp_ref_activity
				AND ui_name = @tmp_ref_ui
				AND page_bt_synonym = '[mainscreen]'
				AND section_bt_synonym = '[tabcontrol]'

			EXEC ep_ui_section_dtl_sp_ins @ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@engg_customer_name,
				@engg_project_name,
				@engg_base_req_no,
				@tmp_processname,
				@tmp_componentname,
				@tmp_activity,
				@tmp_ui,
				'[mainscreen]',
				'[tabcontrol]',
				'N',
				'N',
				'N',
				'Left',
				'',
				0,
				0,
				'[tabcontrol]',
				1,
				@ENGG_SECTION_TYPE_IN,
				@engg_sec_cap_align,
				@engg_sec_cap_format,
				@sectionheight,
				@sectionwidth,
				@Section_width_Scalemode,
				@Section_height_Scalemode,
				@Sec_CollapseMode,
				@Sec_Collapse,
				@engg_req_no,
				@section_rowspan,
				@section_colspan,
				@Region,
				@TitlePosition,
				@CollapseDir,
				@SectionLayout,
				@XYCoordinates,
				@ColumnLayWidth,
				@Associated_Control,
				'',
				'',
				'',
				@orientation,	--TECH-75230
				@engg_bottomtb,
				@engg_toptb,
				@engg_righttb,--
				@engg_lefttb,
				@minimizedrows,
				@viewmode,
				@engg_sec_titleicon, --TECH-72114
				@m_errorid OUTPUT

			IF @m_errorid <> 0
			BEGIN
				CLOSE insert_page_cur

				DEALLOCATE insert_page_cur

				RETURN
			END
		END -- check for [tabcontrol] existence
	END --if tab pages available in the UI
	ELSE --if tab pages DO NOT available in the UI, delete [tabcontrol] section if any
	BEGIN
		IF EXISTS (
				SELECT 'x'
				FROM ep_ui_section_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @tmp_processname
					AND component_name = @tmp_componentname
					AND activity_name = @tmp_activity
					AND ui_name = @tmp_ui
					AND page_bt_synonym = '[mainscreen]'
					AND section_bt_synonym = '[tabcontrol]'
				)
		BEGIN
			EXEC ep_ui_section_dtl_sp_del @ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@engg_customer_name,
				@engg_project_name,
				@engg_base_req_no,
				@tmp_processname,
				@tmp_componentname,
				@tmp_activity,
				@tmp_ui,
				'[mainscreen]',
				'[tabcontrol]',
				@engg_req_no,
				@m_errorid OUTPUT

			IF @m_errorid <> 0
			BEGIN
				CLOSE insert_page_cur

				DEALLOCATE insert_page_cur

				RETURN
			END
		END
	END --if tab pages DO NOT available in the UI

	/*
--OutputList
Select
null 'enggad_fprowno',
null 'enggpa_fprowno',
null 'engg_c_fprowno',
null 'engg_l_fprowno',
null 'engg_m_fprowno',
null 'engg_r_fprowno',
null 'engg_y_fprowno',
null '_sec_fprowno',
*/
	SET NOCOUNT OFF
END
GO

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_maireeSpep_layHdrSav' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON ep_maireeSpep_layHdrSav TO PUBLIC
END
GO
