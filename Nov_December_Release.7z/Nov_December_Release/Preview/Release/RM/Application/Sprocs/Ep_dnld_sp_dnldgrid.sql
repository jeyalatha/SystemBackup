IF EXISTS(SELECT 'X' From SYSOBJECTS WHERE NAME ='ep_dnld_sp_dnldgrid' AND TYPE='P')
   BEGIN
        DROP PROC ep_dnld_sp_dnldgrid
   END
GO  
/********************************************************************************/ 
/*      V E R S I O N      :  PNR2.0_1403    */  
/*      Released By        :  Development Team    */  
/*      Release Comments   :  For DotNet Migration, Naming convention has been changed  for some of the out parameters by using Stub Generator.Comments will not be there for this Request ID.    */  
/*      V E R S I O N      :  2.0.3    */  
/*      Released By        :  PTech    */  
/*      Release Comments   :  Released on 16/02/2005 (Patch Release 1)    */  
/*      V E R S I O N      :  2.0.2    */  
/*      Released By        :  PTech    */  
/*      Release Comments   :  Released on  22-Jan-2004    */  
/********************************************************************************/  
/* procedure      ep_dnld_sp_dnldgrid                                           */  
/* description                                                                  */  
/********************************************************************************/  
/* project        Preview                                                       */  
/* version                                                                      */  
/********************************************************************************/  
/* referenced                                                                   */  
/* tables                                                                       */  
/********************************************************************************/  
/* development history                                                          */  
/********************************************************************************/  
/* author         Shafina Begum.B                                               */  
/* date           15/ 12/ 2003                                                  */  
/********************************************************************************/  
/* modification history                                                         */  
/********************************************************************************/  
/* modified by    Shafina Begum.B                                               */  
/* date           08/ 01/ 2004                                                  */  
/* description    To download based on the previewready flag                    */  
/********************************************************************************/  
/* modified by    Shafina Begum.B                                               */  
/* date           09/ 01/ 2004                                                  */  
/* description    To insert hdnsection and hdncontrols for the ui if defined */  
/********************************************************************************/  
/* modified by    Shafina Begum.B                                               */  
/* date           13/ 01/ 2004                                                  */  
/* description    Code commented as no request type called 'ADHOC' exists  */  
/********************************************************************************/  
/* modified by    Shafina Begum.B                                               */  
/* date           15/ 01/ 2004                                                  */  
/* description    to check whether task type for default fetch is defined   */  
/* description    to pass the processname and comp name correctly    */  
/********************************************************************************/  
/* modified by    Shafina Begum.B                                               */  
/* date           16/ 01/ 2004                                                  */  
/* description    to pass engg_req_no into req_dtl table       */  
/* description    to check ui_mst table with req_no 'BASE'       */  
/********************************************************************************/  
/* modified by    Shafina Begum.B           */  
/* date   22/ 01/ 2004 */  
/* description    to update ui_mst table and ui_req_dtl table with ui_descr  */  
/********************************************************************************/  
/********************************************************************************/  
/* modified by    Giridharan.V                                 */  
/* date           11/ 06/ 2004                                                  */  
/* description    to include task type for insertion in table ep_action_mst  */  
/***********************************************************************************/  
/* modified by    Savitha M                                      */  
/* date           04/ 03/ 2005                  */  
/* Bugid          PREVIEWENG203SYS_000223                                         */  
/* Bug description: 'Violation of PRIMARY KEY constraint        */  
/*     'ep_component_glossary_mst_lng_extn_pkey'         */  
/* modified by     :Shriram V                                     */  
/* date            :05/ 07/ 2005                 */  
/* Bugid           :PNR2.0_3132                                            */  
/* Bug description : In Download Work Request UI of Engineering Preview Component, */  
/*     when I try to download a work request I am getting the following error*/  
/*     "Violation of PRIMARY KEY constraint 'ep_ui_req_dtl_pkey'.      */  
/*     Cannot insert duplicate key in object 'ep_ui_req_dtl'.".  */  
/* modified by     :Shriram V                                   */  
/* date            :06/ 08/ 2005            */  
/* Bugid           :PNR2.0_3497                                          */  
/* Bug description :While doing Generate Preview, I am getting an Page cannot be found error */  
/********************************************************************************/  
/* modified by     : Balaji S                                    */  
/* date            : 09/ 08/ 2005                */  
/* Bugid           : PNR2.0_3517                                         */  
/* Bug description : For Adding Task type as Fetch in Action lng extn   */  
/********************************************************************************/  
/* modified by     : Balaji S                                    */  
/* date            : 11/08/2005                */  
/* Bugid           : PNR2.0_3546                                        */  
/* Bug description : Fetch Task populating Action Without considering worreq  
*******************************************************************************/  
/* modified by     : Anuradha M                                */  
/* date            : 08/09/2005         */  
/* Bugid           : PNR2.0_3775                              */  
/* Bug description : Hidden Controls Defined in Engineering Setup not */  
/*     getting inserted into EP/RE/De Tables when New UI */  
/*     is downloaded for a Comoponent.   */  
/*******************************************************************************/  
/* modified by     : Balaji S                                */  
/* date            : 21/09/2005         */  
/* Bugid           : PNR2.0_3917                              */  
/* Bug description : Hidden Controls Defined in Engineering Setup not */  
/*     getting inserted into EP/RE/De Tables when New UI */  
/*     is downloaded for a Comoponent.   */  
/*******************************************************************************/  
/* modified by     : Balaji S                                */  
/* date            : 22/09/2005         */  
/* Bugid           : PNR2.0_3934                              */  
/* Bug description : Project Hidden Section have to be insert after page */  
/*******************************************************************************/  
/*******************************************************************************/  
/* modified by     : Gowrisankar M   */  
/* date            : 27/09/2005    */  
/* Bugid           : PNR2.0_3975                               */  
/* Bug description : Error while Generating Services - 'BT Synonym is getting duplicating within the task. Change the page prefix and proceed.' *ECR : DEV_ECR_PAA_001 *Activity Name :Create Meter Over-Read Adjustment. */  
/*******************************************************************************/  
/* modified by     : Sangeetha L                                    */  
/* date            : 03-Jan-2006                    */  
/* Bugid           : PNR2.0_5265                                          */  
/* Bug description : This is a work request for new component with 2 new activities. On selecting the work request[ril_tdm_wrq_003] and clicking "Download" the following error came : "Violation of PRIMARY KEY constraint 'ep_component_glossary_mst_lng_ext













n  _pkey'. Cannot insert duplicate key in object 'ep_component_glossary_mst_lng_extn'."*/  
/*******************************************************************************/  
/* Modified by : Sangeetha L              */  
/* Modified on : 02-Feb-2006                */  
/* Bug Id      : PNR2.0_5941                                                    */  
/********************************************************************************/  
/* Modified by : Sangeetha L              */  
/* Modified on : 07-Feb-2006                */  
/* Bug Id      : PNR2.0_6101                                                    */  
/********************************************************************************/  
/* Modified by : Anuradha M              */  
/* Modified on : 27-Feb-2006                */  
/* Bug Id      : PNR2.0_6633                                              */  
/* Bug Descr   : on downloading the workrequest: Violation of PRIMARY KEY constraint 'ep_ui_req_dtl_pkey'. Cannot insert duplicate key in object 'ep_ui_req_dtl' */  
/********************************************************************************/  
/* Modified by : Sangeetha L              */  
/* Modified on : 28-Feb-2006                */  
/* Bug Id      : PNR2.0_6665                                                    */  
/********************************************************************************/  
/* Modified by : Savitha         */  
/* Modified on : 04-Mar-2006       */  
/* Bug Id      : PNR2.0_6832       */  
/* Bug Descr   : Downloading the work request gives the following error. Violation of PRIMARY KEY constraint 'ep_ui_mst_pkey'. Cannot insert duplicate key in object 'ep_ui_mst'.                                                    */  
/********************************************************************************/  
/* Modified by : Balaji S                */  
/* Modified on : 15-Mar-2006             */  
/* Bug Id      : PNR2.0_7201             */  
/* Bug Descr   : When Download Work Request is given error message pops as "UI --  
IntegrationUI is already Downloaded by the Work request        */  
/********************************************************************************/  
/* Modified by : kiruthika R             */  
/* Modified on : 30-Aug-2006             */  
/* Bug Id      : PNR2.0_10099                                                   */  
/********************************************************************************/  
/* Modified by : Arunn for PNR2.0_12169         */  
/* Modified on : 08-Feb-2007             */  
/* Bug Id  : Internal Server Error coming                                   */  
/********************************************************************************/  
/* Modified by : Anuradha M       */  
/* Modified on : 13-Feb-2007       */  
/* Bug Id      : PNR2.0_12237       */  
/********************************************************************************/  
/* Modified by : Gowrisankar M              */  
/* Modified on : 27-Apr-2007              */  
/* Description : PNR2.0_13413   */  
/********************************************************************************/  
/* Modified by : Anuradha M              */  
/* Modified on : 04-May-2007              */  
/* Description : PNR2.0_13534             */  
/********************************************************************************/  
/* modified by   : Chanheetha N A        */  
/* date     : 17-nov-2007         */  
/* BugId    : PNR2.0_16023          */  
/********************************************************************************/  
/* Modified by : Gowrisankar M        */  
/* Modified on : 13-Jun-2008        */  
/* Description : PNR2.0_17527        */  
/********************************************************************************/  
/* Modified by : Chanheetha N.A       */  
/* Modified on : 13-Jun-2008        */  
/* Description : PNR2.0_17520       */  
/********************************************************************************/  
/* Modified by : S.Sivakumar             */  
/* Modified on : 30-OCT-2008              */  
/* Description : PNR2.0_19827             */  
/********************************************************************************/  
/* Modified by   : Jeya                */  
/* Date       : 24-nov-2008              */  
/* BugId       : PNR2.0_1790              */  
/************************************************************************/  
/* Modified by   : Sree       */  
/* Date       : 14-May-2010      */  
/* CaseID        : PNR2.0_26826      */  
/************************************************************************/  
/* Modified by    : S.Sivakumar     */  
/* Date        : 14-June-2010     */  
/* CaseID       : PNR2.0_27078          */  
/* BUG DESCRIPTION : Download WorkRequest Getting Hanged   */  
/************************************************************************/  
/* Modified By       : Sangeetha G          */  
/* Date     : Sep 17 2010          */  
/* Bug Id    : PNR2.0_28333                                     */  
/* Description       : Ezee view page for Platform                      */  
/****************************************************************************/  
/* modified by  : Jeyalatha K            */  
/* date    : 11-Feb-2011                                           */  
/* Bug Id   : PNR2.0_30127           */  
/* Modified for  : Feature  Release          */  
/****************************************************************************/  
/* modified by  : Sangeetha G             */  
/* date    : 17-Feb-2011                                           */  
/* Bug Id   : PNR2.0_30255           */  
/* Modified for  : Invalid column name 'proc_upd_rows'     */  
/****************************************************************************/  
/* modified by  : Sangeetha G           */  
/* date    : 25-Feb-2011                                           */  
/* Bug Id   : PNR2.0_30348           */  
/* Modified for  : Invalid column name 'proc_upd_rows'  -line-2754  */  
/****************************************************************************/  
/* modified by   : Sangeetha G           */  
/* date    : 7-Apr-2011                                           */  
/* Bug Id   : PNR2.0_30890           */  
/* Modified for  : To  disable disposal  tasks  - during download  */  
/****************************************************************************/  
/* modified by   : Chanheetha N A          */  
/* date : 9-Jun-2011                                           */  
/* Bug Id   : PNR2.0_31788           */  
/* Modified for  : Performance Tuning for work_req download    */  
/****************************************************************************/  
/* modified by   : Sangeetha G          */  
/* date    : 17-Jun-2011                                           */  
/* Bug Id   : PNR2.0_31923           */  
/* Modified for  : During wrkreq download formal parameter error thrown    */ 
/****************************************************************************/  
/* Modified by  : Veena U                                                  */
/* Date         : 25-Feb-2015                                                  */
/* Call ID		: PLF2.0_11499                                                 */
/********************************************************************************/ 
/* Modified by  : Veena U                                                  */
/* Date         : 28-Mar-2016                                                 */
/* Call ID		: PLF2.0_17570                                               */
/********************************************************************************/ 
/* Created by  	: Kiruthika R                                               	*/
/* Date         : 13-June-2016                                                  */
/*Defect Id 	: PLF2.0_18487	(Codegen Metadata not happening for workreq other than BASE)*/
/********************************************************************************/
/* Created by  	: Kanagavel A                                               	*/
/* Date         : 27-June-2016                                                  */
/*Description 	: Activity ui name length validation part is commented */
/********************************************************************************/  
/* Created by  	: Loganayaki P                                               	*/
/* Date         : 18-OCT-2016                                                  */
/*Description 	: Insert New UI into new table for validating controls and sections Width */
/********************************************************************************/  
/* Modified by : Jeya Latha K/Ganesh Prabhu S	for callid TECH-7349				*/
/* Modified on : 14-03-2017				 											*/
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and New Feature Organization chart */
/***********************************************************************************/
/*Modified by	: Venkatesan K    Defect ID: TECH-20897      On: 30-Apr-2018      */
/* engg_devcon_codegen_comp_metadata insertion has been modified by Venkatesh	*/
/********************************************************************************/
/* Modified by  :  Venkatesan K                                                  */
/* Date         :  10_05_2018                                                    */
/* Description  :  Batch id table updation for batch track purpose.				 */
/* case id		:  TECH-20631													 */
/* Modified by  : Jeya Latha K/Venkatesan K	Date: 31-Oct-2018  Defect ID : TECH-28010 */  
/**************************************************************************************/
/* Modified by  :  Janani S                                                           */
/* Date         :  21_01_2022                                                         */
/* Description  :  To handle default reportaspx.             				          */
/* case id		:  TECH-65177													      */ 
/**************************************************************************************/
/* Modified by	:	Ponmalar A 														  */
/* Modified on	:	08/07/2022				 									      */
/* Defect ID	:	Tech-70687													      */
/* Description	:	Tool and Toolbars											      */
/**************************************************************************************/
/* Modified by	:	Ganesh Prabhu S 												  */
/* Modified on	:	08/11/2022				 									      */
/* Defect ID	:	TECH-73992													      */
/**************************************************************************************/
CREATE Procedure Ep_dnld_sp_dnldgrid  
@ctxt_language_in             engg_ctxt_language,  
@ctxt_ouinstance_in           engg_ctxt_ouinstance,  
@ctxt_service_in              engg_ctxt_service,  
@ctxt_user_in                 engg_ctxt_user,  
@engg_customer_name_in        engg_name,  
@engg_project_name_in         engg_name,  
@engg_req_descr_in            engg_description,  
@engg_req_no_in               engg_name,  
@engg_req_status_in           engg_name,  
@engg_req_type_in             engg_name,  
@guid_in                      engg_guid,  
@modeflag_in                  engg_modeflag,  
@fprowno_io                   engg_rowno,  
@m_errorid					  ENGG_SEQNO output  
  
  
as  
begin  
  
set nocount on  
  
--declaration of temporary variables  
declare @ctxt_language                  engg_ctxt_language  
declare @ctxt_ouinstance                engg_ctxt_ouinstance  
declare @ctxt_service                   engg_ctxt_service  
declare @ctxt_user                      engg_ctxt_user  
declare @engg_customer_name             engg_name  
declare @engg_project_name              engg_name  
declare @engg_req_descr                 engg_description  
declare @engg_req_no    engg_name  
declare @engg_req_status                engg_name  
declare @engg_req_type              engg_name  
declare @guid                           engg_guid  
declare @modeflag                       engg_modeflag  
declare @fprowno                        engg_rowno  
declare @comp_name_tmp					engg_name  
declare @proc_name_tmp					engg_name  
declare @getdate						engg_name  
  
select @getdate = getdate()  
  
--temporary and formal parameters mapping  
select @ctxt_language                 = @ctxt_language_in  
select @ctxt_ouinstance               = @ctxt_ouinstance_in  
select @ctxt_service                  = ltrim(rtrim(@ctxt_service_in))  
select @ctxt_user					  = ltrim(rtrim(@ctxt_user_in))  
select @engg_customer_name            = ltrim(rtrim(@engg_customer_name_in))  
select @engg_project_name             = ltrim(rtrim(@engg_project_name_in))  
select @engg_req_descr                = ltrim(rtrim(@engg_req_descr_in))  
select @engg_req_no                   = ltrim(rtrim(@engg_req_no_in))  
select @engg_req_status               = ltrim(rtrim(@engg_req_status_in))  
select @engg_req_type                 = ltrim(rtrim(@engg_req_type_in))  
select @guid                          = ltrim(rtrim(@guid_in))  
select @modeflag                      = ltrim(rtrim(@modeflag_in))  
select @fprowno                       = @fprowno_io  
  
--null checking  
if @ctxt_language = -915  
select @ctxt_language = null  
  
if @ctxt_ouinstance = -915  
select @ctxt_ouinstance = null  
  
if @ctxt_service = '~#~'  
select @ctxt_service = null  
  
if @ctxt_user = '~#~'  
select @ctxt_user = null  
  
if @engg_customer_name = '~#~'  
select @engg_customer_name = null  
  
if @engg_project_name = '~#~'  
select @engg_project_name = null  
  
if @engg_req_descr = '~#~'  
select @engg_req_descr = null  
  
if @engg_req_no = '~#~'  
select @engg_req_no = null  
  
if @engg_req_status = '~#~'  
select @engg_req_status = null  
  
if @engg_req_type = '~#~'  
select @engg_req_type = null  
  
if @guid = '~#~'  
select @guid = null  
  
if @modeflag = '~#~'  
select @modeflag = null  
  
if @fprowno = -915  
select @fprowno = null  
  
--errors mapped  
declare @msg    engg_description,  
@engg_base_req_no engg_name,  
@page_prefix_tmp engg_name,  
@cust_name_tmp   engg_name,  
@proj_name_tmp   engg_name,  
@req_no_tmp   engg_name,  
@act_name_tmp   engg_name,  
@ui_name_tmp  engg_name,  
@ui_descr_tmp  engg_name,  
@tmp_ActionType  engg_name,  
@tmp_ActionType1  engg_name,  -- Code modified for  PNR2.0_30127  
@comp_pfx_tmp  engg_name,  
@capalign_tmp  engg_description,  
@capformat_tmp  engg_description,  
@tabheight_tmp  engg_description,  
@trailbar_tmp  engg_description,  
@task_name_tmp  engg_name,  
@act_descr_tmp  engg_description,  
@proc_descr_tmp  engg_description,  
@comp_descr_tmp  engg_description,  
@bpid     engg_name,  
@funcid    engg_name,  
@comp_prefix_tmp engg_name,  
@langid_tmp   engg_seqno,  
@page_type engg_name  
  
select  @engg_base_req_no = 'BASE'  
  
  

--errors mapped  
--output parameters  
if @modeflag = 'Z'  
begin  
  
select @fprowno = @fprowno + 1  

/* if not exists (select '*' from ep_new_ui_mst (nolock)
where  customer_name   	= @engg_customer_name  
and   project_name	 	= @engg_project_name  ) 
--Code added against TECH-218 Starts
insert into ep_new_ui_mst (customer_name,project_name,req_no,process_name,component_name,activity_name,ui_name,ui_descr,createdby,createddate)
Select a.customer_name , a.project_name , a.req_no ,  
a.process_name , a.component_name , a.activity_name , a.ui_name ,   a.ui_descr ,@ctxt_user_in,GETDATE()--parameter added by 11536 for the bug id TECH-14976
From  ep_bpt_download_vw  a (nolock) 
where  a.customer_name   = @engg_customer_name  
and   a.project_name	 = @engg_project_name  
--and   a.req_no			 = rtrim(@engg_req_no)
and   a.activity_name    <> 'IntegrationActivity'  
and   Not  exists  (  
Select 'x'  from  ep_ui_req_dtl c  (nolock)  
where  c.Customer_name   = a.customer_name  
and    c.Project_name    = a.project_name  
and    c.process_name    = a.process_name  
and    c.component_name  = a.Component_Name  
and    c.activity_name   = a.activity_name  
and    c.ui_name			= a.ui_name)  */
--Code added against TECH-218 Ends0

if rtrim(@engg_req_type) = 'DEVELOPMENT'  
begin  
if exists (  
select 'x'  
--       from ep_bpt_download_vw (nolock)  
from ep_bpt_activity_ppw_vw (nolock)  
where customerid = @engg_customer_name  
and  projectid = @engg_project_name  
and  workreqid = @engg_req_no -- 'BASE'  
-- modified by shafina on 16-feb-2004  
and  previewready = 'RPW'  
and  previewready is not null  
)  
begin -- if previewready= 'RPW'  
-- modified by shafina on 30-april-2004 for PREVIEWENG203SYS_000054  
declare map_cur cursor for  
			select distinct process_name , functionid      /* Code Modified By Sree for the CaseID: PNR2.0_26826 */  
			from	fw_bpt_dr_vw a(nolock)  
			where	customer_name	= @engg_customer_name  
			and		project_name	= @engg_project_name  
			and		previewready	= 'RPW'  
  
		open map_cur  
		while (1=1)  
		begin -- map_cur  
			fetch next from map_cur  into @bpid , @funcid  

			if (@@fetch_status <> 0)  
				break  

			if not exists (select 'x'  
			from	fw_bpt_function_component_vw a (nolock)  
			where	a.customerid	= @engg_customer_name  
			and		a.projectid		= @engg_project_name  
			and		a.bpid			= @bpid  
			and		a.functionid	= @funcid)  
			begin  
				select @msg = 'Function - Component mapping is not done for function : ' + @funcid  
				exec engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
					@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
					'','','','',@m_errorid output  
				close map_cur  
				deallocate map_cur  
				return  
			end  
		end  
		close map_cur  
		deallocate map_cur  

		Declare dnld_cur cursor for  
			Select	a.customer_name , 
					a.project_name , 
					a.req_no ,  
					a.process_name , 
					a.component_name , 
					a.activity_name , 
					a.activity_descr ,  
					a.ui_name ,   
					a.ui_descr ,   
					a.process_descr , 
					a.component_descr ,  
					f.functionabbr  
			from	ep_bpt_download_vw a (nolock),  
					ep_bpt_activity_ppw_vw  p (nolock),  
					fw_bpt_function  f (nolock)  
			where	a.customer_name		= @engg_customer_name  
			and		a.project_name		= @engg_project_name  
			and		a.req_no			= rtrim(@engg_req_no)  
			and		a.customer_name		= p.customerid  
			and		a.project_name		= p.projectid  
			and		a.req_no			= p.workreqid  
			and		a.process_name		= p.bpid  
			and		a.functionid		= p.functionid  
			and		a.activity_name		= p.activityid  
			and		p.previewready		= 'RPW'  
			and		p.previewready is not null  
			and		a.customer_name		= f.customerid  
			and		a.project_name		= f.projectid  
			and		a.process_name		= f.bpid  
			and		a.functionid		= f.functionid  
	-- Code Added For BUG ID PNR2.0_27078 Starts Here  
			and		not  exists (Select 'x'  
			from  ep_ui_req_dtl c  (nolock)  
			where  c.Customer_name   = a.customer_name  
			and    c.Project_name    = a.project_name  
			and    c.process_name    = a.process_name  
			and    c.component_name  = a.Component_Name  
			and    c.activity_name   = a.activity_name  
			and    c.ui_name		 = a.ui_name  )  
-- Code Added For BUG ID PNR2.0_27078 Ends Here  
  
-- code modified by shafina on 16-feb-2005 for  
--PREVIEWENG203SYS_000209 (I have created workrequest(WRMSPINTG) in Imapact Analysis.  
--We made UI level Change WorkRequest for that Activity "IntegrationActivity".  
--But corresponding workrequest is not list out in the Download Workrequest )  
--     and  a.ui_name    <> 'IntegrationUI'  
-- code modified by shafina on 16-feb-2005 for PREVIEWENG203SYS_000209  
--(I have created workrequest(WRMSPINTG) in Imapact Analysis. We made UI level  
--Change WorkRequest for that Activity "IntegrationActivity".  
--But corresponding workrequest is not list out in the Download Workrequest )  
 
		open dnld_cur  
		while (1=1)  
		begin -- dnld_cur  
			fetch next from dnld_cur into @cust_name_tmp ,	@proj_name_tmp ,	@req_no_tmp ,  
			@proc_name_tmp ,	@comp_name_tmp ,	@act_name_tmp ,		@act_descr_tmp ,  
			@ui_name_tmp ,		@ui_descr_tmp ,		@proc_descr_tmp ,	@comp_descr_tmp ,  
			@comp_prefix_tmp  

			if (@@fetch_status <> 0)  
			break  
	-- code modified by shafina on 12-April-2004 for PREVIEWENG203SYS_000003  
			if isnull(@cust_name_tmp,'') = '' 
			begin  
				select	@msg = 'Customer name cannot be null'  
				exec	engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
					@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
					'','','','',@m_errorid output  
				close dnld_cur  
				deallocate dnld_cur  
				return 
			end  
  
			if isnull(@proj_name_tmp,'') = ''  
			begin  
				select	@msg = 'Project name cannot be null'  
				exec engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
					@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
					'','','','',@m_errorid output  
				close dnld_cur  
				deallocate dnld_cur  
				return  
			end  
  
			if isnull(@req_no_tmp,'') = ''  
			begin  
				select @msg = 'Request no cannot be null'  
				exec engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
					@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
					'','','','',@m_errorid output  
				close dnld_cur  
				deallocate dnld_cur  
				return  
			end  
  
			if isnull(@proc_name_tmp,'') = ''  
			begin  
				select	@msg = 'Process name cannot be null'  
				exec engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
					@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
					'','','','',@m_errorid output  
				close dnld_cur  
				deallocate dnld_cur  
				return  
			end  
  
			if isnull(@proc_descr_tmp,'') = ''  
			begin  
				select	@msg = 'Process description cannot be null'  
				exec engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
					@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
					'','','','',@m_errorid output  
				close dnld_cur  
				deallocate dnld_cur  
				return  
			end  
  
			if isnull(@comp_name_tmp,'') = ''  
			begin  
				select	@msg = 'Component name cannot be null'  
				exec engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
					@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
					'','','','',@m_errorid output  
				close dnld_cur  
				deallocate dnld_cur  
				return  
			end  
  
			if isnull(@comp_descr_tmp,'') = ''  
			begin  
			select	@msg = 'Component Description cannot be null'  
			exec engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
				@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
				'','','','',@m_errorid output  
			close dnld_cur  
			deallocate dnld_cur  
			return  
			end  
  
			if isnull(@act_name_tmp,'') = ''  
			begin  
				select @msg = 'Activity name cannot be null'  
				exec engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
					@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
					'','','','',@m_errorid output  
				close dnld_cur  
				deallocate dnld_cur  
				return  
			end  
  
			if isnull(@act_descr_tmp,'') = ''  
			begin  
				select	@msg = 'Activity Description cannot be null'  
				exec engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
					@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
					'','','','',@m_errorid output  
				close dnld_cur  
				deallocate dnld_cur  
				return  
			end  
  
			if isnull(@ui_name_tmp,'') = ''  
			begin  
				select	@msg = 'UI name cannot be null'  
				exec engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
					@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
					'','','','',@m_errorid output  
				close dnld_cur  
				deallocate dnld_cur  
				return  
			end  
  
			if isnull(@ui_descr_tmp,'') = ''  
			begin  
				select	@msg = 'UI Description cannot be null'  
				exec engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
					@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
					'','','','',@m_errorid output  
					close dnld_cur  
				deallocate dnld_cur  
				return  
			end   

			if not exists (select 'x' 
			from	ep_new_ui_mst (nolock)
			where	customer_name   	= @cust_name_tmp  
			and		project_name	 	= @proj_name_tmp 
			and 	process_name		= @proc_name_tmp
			and 	component_name		= @comp_name_tmp
			and 	activity_name 		= @act_name_tmp
			and 	ui_name 			= @ui_name_tmp) 
			begin 
	----Code added against TECH-218 Starts
				insert into ep_new_ui_mst 
					(customer_name,			project_name,		req_no,			process_name,			component_name,			activity_name,
					 ui_name,				ui_descr,			createdby,		createddate)
				Select @cust_name_tmp ,		@proj_name_tmp ,	@req_no_tmp ,	@proc_name_tmp ,		@comp_name_tmp ,	    @act_name_tmp ,
					@ui_name_tmp ,			@ui_descr_tmp ,	    @ctxt_user_in,	GETDATE()

				--Select a.customer_name ,	a.project_name ,	a.req_no ,		a.process_name ,		a.component_name ,		a.activity_name , 
				--	   a.ui_name ,			a.ui_descr ,		@ctxt_user_in,	GETDATE()--parameter added by 11536 for the bug id TECH-14976
				--from	ep_bpt_download_vw  a (nolock) 
				--where	a.customer_name		= @engg_customer_name  
				--and		a.project_name		= @engg_project_name  
				----and   a.req_no			= rtrim(@engg_req_no)
				--and		a.activity_name     <>'IntegrationActivity'  
				--and     not exists (select 'x'  
				--from  ep_ui_req_dtl c  (nolock)  
				--where  c.Customer_name   = a.customer_name  
				--and    c.Project_name    = a.project_name  
				--and    c.process_name    = a.process_name  
				--and    c.component_name  = a.Component_Name  
				--and    c.activity_name   = a.activity_name  
				--and    c.ui_name		 = a.ui_name) 
			end

/*  
-- code modified by shafina on 28-June-2004 for uiname + acty name length check  
if len(@act_name_tmp) + len(@ui_name_tmp) > 40  
begin  
select @msg = 'UI name and Activity name length cannot be greater than 40'  
exec engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
'','','','',@m_errorid output  
close dnld_cur  
deallocate dnld_cur  
return  
end  */
  
-- code modified by Shafina on 10-jan-2004 for populating component level parameters  
if exists (  
select 'x'  
from es_comp_param_mst (nolock)  
where customer_name = @cust_name_tmp  
and  project_name = @proj_name_tmp  
--         and  req_no   = @req_no_tmp  
and  process_name = @proc_name_tmp  
and  component_name = @comp_name_tmp  
)  
begin  
-- code modified by shafina on 18-May-2004 for PREVIEWENG203ACC_000064  
-- (Component prefix must not be updated from BPT function for the second time.)  
if not exists (  
select 'x'  
from ep_ui_req_dtl (nolock)  
where customer_name = @cust_name_tmp  
and  project_name = @proj_name_tmp  
and  process_name = @proc_name_tmp  
and  component_name = @comp_name_tmp  
)  
begin  
-- code modified by shafina on 06-May-2004 for PREVIEWENG203ACC_000054  
update es_comp_param_mst  
set  current_value    = @comp_prefix_tmp,  
-- code added by shafina on 07-Sep-2004 for PREVIEWENG203ACC_000098 (Modified Date must be updated.)  
modifiedby     = @ctxt_user,  
modifieddate    = @getdate  
where  customer_name      = @cust_name_tmp  
and    project_name       = @proj_name_tmp  
and    process_name       = @proc_name_tmp  
and   component_name     = @comp_name_tmp  
and  param_category    = 'COMPPREFIX'  
end  
end  
else  
begin  
-- code modified by shafina on 27-May-2004 for PREVIEWENG203ACC_000068  
--While downloading work request , error must be thrown if the component name has spaces.  
-- code modified on 13-Feb-2007 for the BUG ID :: PNR2.0_12237  
if charindex(' ',ltrim(rtrim(@comp_name_tmp))) <> 0  
begin  
select @msg = 'Cannot Download as Component Name : ' + @comp_name_tmp + ' Contains Spaces'  
exec engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
'','','','',@m_errorid output  
close dnld_cur  
deallocate dnld_cur  
return  
end  
  
exec  ep_default_comp_params  
@engg_customer_name,@engg_project_name,@engg_base_req_no,  
@proc_name_tmp,@comp_name_tmp,@comp_prefix_tmp  
end  
  
--  Added By feroz for populating static controls  
insert into es_stat_ctrl_type_mst  
(customer_name,project_name,ctrl_type_name,ctrl_type_descr,  
base_ctrl_type,handle_events, createdby, createddate, modifiedby, modifieddate)  
select  
@engg_customer_name,@engg_project_name,ctrl_type_name,ctrl_type_descr,  
base_ctrl_type,handle_events, host_name(), getdate(),host_name(), getdate()  
from es_stat_ctrl_type_met b (nolock)  
where  not exists (select 'x'  
from  es_stat_ctrl_type_mst a (nolock)  
where  a.customer_name  = @engg_customer_name  
and  a.project_name   = @engg_project_name  
and  a.ctrl_type_name  = b.ctrl_type_name  
)  
  
  
insert into es_comp_stat_ctrl_type_mst  
(customer_name,project_name,process_name,component_name,  
ctrl_type_name,ctrl_type_descr,base_ctrl_type,handle_events, createdby, createddate, modifiedby, modifieddate)  
select  
customer_name,project_name,@proc_name_tmp,@comp_name_tmp,ctrl_type_name,  
ctrl_type_descr,base_ctrl_type,handle_events, host_name(), getdate(),host_name(), getdate()  
from es_stat_ctrl_type_mst b (nolock)  
where b.customer_name = @engg_customer_name  
and  b.project_name = @engg_project_name  
and  not exists (select 'X'  
from  es_comp_stat_ctrl_type_mst  a (nolock)  
where  a.customer_name  = @engg_customer_name  
and  a.project_name  = @engg_project_name  
and  a.process_name  = @proc_name_tmp  
and  a.component_name  = @comp_name_tmp  
and  a.ctrl_type_name  = b.ctrl_type_name )  
  
  
delete from ep_stat_ctrl_val_mst  
where  customer_name = @engg_customer_name  
and  project_name = @engg_project_name  
  
insert into ep_stat_ctrl_val_mst  
( customer_name,project_name,ctrl_type_name,  
quick_code,quick_code_value,default_flag,  
sequence,languageid,applicable  
)  
select  
@engg_customer_name,@engg_project_name,ctrl_type_name,  
quick_code,quick_code_value,default_flag,  
sequence,languageid,applicable  
from es_stat_ctrl_val_met(nolock)  
where applicable = 'Y'  
--  Added By feroz for populating static controls  
  
-- code modified by shafina on 15-jan-2004 to check whether comp_task_type is populated  
if exists (  
select 'x'  
from es_comp_task_type_mst_vw (nolock)  
where customer_name = @cust_name_tmp  
and  project_name = @proj_name_tmp  
--         and  req_no   = @req_no_tmp  
and  process_name = @proc_name_tmp  
and  component_name = @comp_name_tmp  
)  
begin  
select @engg_req_no = rtrim(@engg_req_no)  
end  
else  
begin  
select @msg = 'Cannot Download as Task Type for Default Fetch is not Defined'  
exec engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
'','','','',@m_errorid output  
close dnld_cur  
deallocate dnld_cur  
return  
end  
  
-- modified by shafina on 27-feb-2004 to update activity_descr in ui_req_dtl table  
--      if exists (  
--         select  'x'  
--         from ep_ui_req_dtl (nolock)  
--         where customer_name  = @cust_name_tmp  
--         and  project_name  = @proj_name_tmp  
--         and  req_no    = @engg_req_no  
--         and  process_name  = @proc_name_tmp  
--         and  component_name  = @comp_name_tmp  
--         and  activity_name  = @act_name_tmp  
--      )  
--      begin  
-- code modified by shafina on 03-Sep-2004 for PREVIEWENG203SYS_000141 ( Component Descr must be updated irrespectve of the activity)  
update ep_ui_req_dtl  
set  process_descr  = @proc_descr_tmp,  
modifiedby   = @ctxt_user,  
modifieddate  = @getdate  
where customer_name  = @cust_name_tmp  
and  project_name  = @proj_name_tmp  
--       and  req_no    = @req_no_tmp  
and  process_name  = @proc_name_tmp  
and  process_descr  <> @proc_descr_tmp -- Code added for Bug Id : PNR2.0_31788  
  
update ep_ui_req_dtl  
set  component_descr  = @comp_descr_tmp,  
modifiedby   = @ctxt_user,  
modifieddate  = @getdate  
where customer_name  = @cust_name_tmp  
and  project_name  = @proj_name_tmp  
--       and  req_no    = @req_no_tmp  
and  process_name  = @proc_name_tmp  
and  component_name  = @comp_name_tmp  
and  component_descr  <> @comp_descr_tmp -- Code added for Bug Id :  PNR2.0_31788  
  
update ep_ui_req_dtl  
set  activity_descr  = @act_descr_tmp,  
modifiedby   = @ctxt_user,  
modifieddate  = @getdate  
where customer_name  = @cust_name_tmp  
and  project_name  = @proj_name_tmp  
--       and  req_no    = @req_no_tmp  
and  process_name  = @proc_name_tmp  
and  component_name  = @comp_name_tmp  
and  activity_name  = @act_name_tmp  
and  activity_descr  <> @act_descr_tmp  -- Code added for Bug Id :  PNR2.0_31788  
--      end  
-- code modified by shafina on 14-June-2004 for PREVIEWENG203ACC_000073  
-- Btsynonyms defined at projectlevel must be inserted for each component when downloaded for the first time  
if not exists (  
select 'x'  
from ep_ui_req_dtl (nolock)  
where customer_name = @cust_name_tmp  
and  project_name = @proj_name_tmp  
and  process_name = @proc_name_tmp  
and  component_name = @comp_name_tmp  
)  
begin  
insert into ep_component_glossary_mst  
(  
customer_name,  project_name, req_no,  process_name,  component_name,  
bt_synonym_name, data_type,  length,  bt_synonym_caption, glossary_sysid,  
timestamp,   createdby,  createddate,modifiedby,   modifieddate,  
ref_bt_synonym_name,bt_synonym_doc, bt_name, synonym_status,  singleinst_sample_data,  
multiinst_sample_data,wrkreqno  --chan  
)  
select  
@cust_name_tmp,  @proj_name_tmp, 'BASE',  @proc_name_tmp,  @comp_name_tmp,  
bt_synonym_name, data_type,  length,  bt_synonym_caption, newid(),  
1,     @ctxt_user,  @getdate, @ctxt_user,   @getdate,  
ref_bt_synonym_name,bt_synonym_doc, bt_name, 'U',    singleinst_sample_data,  
multiinst_sample_data,@req_no_tmp  
from ep_glossary_mst (nolock)  
where  customer_name      = @cust_name_tmp  
and    project_name       = @proj_name_tmp  
  
-- code modified by shafina on 16-feb-2005 for PREVIEWPFSUPPORT_000008  (while downloading a component , bt synonyms are net getting inserted in lang extn table.)  
--insert into ep_component_glossary_mst_lng_extn  
--(  
--customer_name,  project_name, req_no,  process_name,  component_name,  
--bt_synonym_name, data_type,  length,  bt_synonym_caption, glossary_sysid,  
--timestamp,   createdby,  createddate,modifiedby,   modifieddate,  
--ref_bt_synonym_name,bt_synonym_doc, bt_name, synonym_status,  singleinst_sample_data,  
--multiinst_sample_data,languageid,wrkreqno  --chan  
--)  
--select  
--@cust_name_tmp,  @proj_name_tmp, 'BASE',  @proc_name_tmp,  @comp_name_tmp,  
--bt_synonym_name, data_type,  length,  bt_synonym_caption, newid(),  
--1,     @ctxt_user,  @getdate, @ctxt_user,  @getdate,  
--ref_bt_synonym_name,bt_synonym_doc, bt_name, 'U',    singleinst_sample_data,  
--multiinst_sample_data,languageid ,@req_no_tmp  
--from ep_glossary_mst_lng_extn (nolock)  
--where  customer_name      = @cust_name_tmp  
--and    project_name    = @proj_name_tmp  
---- code modified by shafina on 16-feb-2005 for PREVIEWPFSUPPORT_000008  (while downloading a component , bt synonyms are net getting inserted in lang extn table.)  
  
---- Code modified for PNR2.0_13413 on 27-Apr-2007  
--insert into ep_component_glossary_mst_lng_extn  
  
--(customer_name,  project_name,  req_no,   process_name,  component_name,  
--bt_synonym_name, data_type,   length,   bt_synonym_caption, glossary_sysid,  
--languageid,   timestamp,   createdby,  createddate,  modifiedby,  
--modifieddate,  ref_bt_synonym_name,bt_synonym_doc, bt_name,   synonym_status,  
--singleinst_sample_data,     multiinst_sample_data  ,wrkreqno --chan  
--)  
--select  distinct  
--@cust_name_tmp,  @proj_name_tmp,  'BASE',   @proc_name_tmp,  @comp_name_tmp,  
--bt_synonym_name, data_type,   length,   bt_synonym_caption, newid(),  
--1,  1,     @ctxt_user,  @getdate,   @ctxt_user,  
--@getdate,   ref_bt_synonym_name,bt_synonym_doc, bt_name,   'U',  
--singleinst_sample_data,     multiinst_sample_data  ,@req_no_tmp  
--from  ep_glossary_mst a (nolock)  
--where   customer_name      = @cust_name_tmp  
--and  project_name       = @proj_name_tmp  
--and not exists (  select  's'  
--from ep_component_glossary_mst_lng_extn b (nolock)  
--where b.customer_name  = @cust_name_tmp  
--and b.project_name  = @proj_name_tmp  
--and b.req_no  = 'BASE'  
--and b.process_name  = @proc_name_tmp  
--and b.component_name = @comp_name_tmp  
--and b.bt_synonym_name = a.bt_synonym_name  
--and b.languageid  = 1)  

if not exists 
(
select 'K'
from engg_devcon_codegen_comp_metadata(nolock)
where componentname  = @comp_name_tmp )

begin --11536
	insert engg_devcon_codegen_comp_metadata
					(	chart,				state,				[pivot],				ddt,				cvs,					excelreport,				logicalextn,		
						errorxml,			instconfig,			imptoolkitdel,		spstub,				refdocs,				quicklink,					datascript,	
						edksscript,			controlextn,		customurl,			datadriventask,		seperrordll,			app,						sys,
						grc,				rtgif,				fpgrid,				sectioncollapse,	displaysepcification,	fillerrow,					gridalternaterowcolor,
						glowcorners,		niftybuttons,		smoothbuttons,		blockerrors,		linkmode,				scrolltitle,				tooltip,
						wizardhtml,			helpmode,			impdeliverables,	quicklinks,			richui,					widgetui,					selallforgridcheckbox,
						contextmenu,		extjs,				accesskey,			richtree,			richchart,				compresshtml,				compressjs,
						allstyle,			alltaskdata,		cellspacing,		applicationcss,		comments,				inplacetrialbar,			captionalignment,
						uiformat,			trialbar,			smartspan,			stylesheet,			custombr,				alllanguage,				deploydeliverables,
						platform,			appliation_rm_type,	generationpath,		multittx,			repprintdate,			componentName,				iEdk,
						statejs,			ucd,				ezreport,			cexml,				intd,					onlyxml,					reportaspx,
						webasync,			errorlookup,		taskpane,			suffixcolon,		gridfilter,				ezlookup,					labelselect,
						ReleaseVersion,		inlinetab,			split,				ellipses,			reportxml,				generatedatejs,				typebro,
						rbtnalign,			ipad5,				desktopdlv,			DeviceConfigPath,	iPhone,					ellipsesleft,				ezeewizard,	
						LayoutControls,		RTState,			SecondaryLink,		depscript_with_actname,						extjs6			
					)

	select				'y',				'n',				'n',				'y',				'n',					'n',							'n',
						'n',				'n',				'n',				'n',				'n',					'n',							'n',
						'n',				'n',				'n',				'n',				'y',					'n',							'n',		
						'n',				'n',				'n',				'y',				'n',					'n',							'n',
						'n',				'n',				'n',				'n',				'n',					'n',							'y',
						'n',				'n',				'n',				'n',				'n',					'n',							'n',
						'n',				'y',				'n',				'n',				'n',					'n',							'n',
						'n',				'n',				null,				'n',				'n',					'n',							'Left',
						'Controls Beside captions','Both',		'y',				'RSGLOBALStyles',	null,					'n',							'n',
						'DOTNET',			'SQL Server',		null,				'n',				'n',					@comp_name_tmp,					'y',
						null,				null,				null,				null,				null,					null,							'Generic Type',--code added for TECH-65177
						'y',				'y',				'n',				null,				null,					null,							null,
						null,				'y',				null,				null,				null,					null,							null,
						null,				null,				null,				null,				null,					'n',							'y',
						'y',				'y',				null,				'y',											'y'
 end
	
  
--declare lang_cursor cursor for  
--select quick_code  
--from ep_language_met (nolock)  
--where quick_code <> 1  
  
--open lang_cursor  
--while 1=1  
--begin  
--fetch next from lang_cursor into @langid_tmp  
----      customer_name, project_name, req_no, process_name, component_name, bt_synonym_name,  
--if @@fetch_status <> 0  
--break  
  
--insert into ep_component_glossary_mst_lng_extn  
  
--(customer_name,  project_name,  req_no,   process_name,  component_name,  
--bt_synonym_name, data_type,   length,   bt_synonym_caption, glossary_sysid,  
--languageid,   timestamp,   createdby,  createddate,  modifiedby,  
--modifieddate,  ref_bt_synonym_name,bt_synonym_doc, bt_name,   synonym_status,  
--singleinst_sample_data,     multiinst_sample_data  ,wrkreqno --chan  
--)  
---- code modified by Savitha M on 04-March-2005 for PREVIEWENG203SYS_000223  (Error message  
----on download for work request type Development'Violation of PRIMARY KEY constraint  
----'ep_component_glossary_mst_lng_extn_pkey'. Cannot insert duplicate key in object  
----'ep_component_glossary_mst_lng_extn'.)  
--select  distinct  
--@cust_name_tmp,  @proj_name_tmp,  'BASE',   @proc_name_tmp,  @comp_name_tmp,  
--bt_synonym_name, data_type,   length,   convert(varchar(3),@langid_tmp) + '_'+ bt_synonym_caption, newid(),    -- Code modified for PNR2.0_13413 on 27-Apr-2007  
--@langid_tmp,  1,     @ctxt_user,  @getdate,   @ctxt_user,  
--@getdate,   ref_bt_synonym_name,bt_synonym_doc, bt_name,   'U',  
--singleinst_sample_data,     multiinst_sample_data  ,@req_no_tmp  
--from  ep_glossary_mst a (nolock)  
--where   customer_name      = @cust_name_tmp  
--and  project_name       = @proj_name_tmp  
--and not exists (  select  's'  
--from ep_component_glossary_mst_lng_extn b (nolock)  
--where b.customer_name  = @cust_name_tmp  
--and b.project_name  = @proj_name_tmp  
--and b.req_no  = 'BASE'  
--and b.process_name  = @proc_name_tmp  
--and b.component_name = @comp_name_tmp  
--and b.bt_synonym_name = a.bt_synonym_name  
--and b.languageid  = @langid_tmp)  
  
  
  
--end  
--close lang_cursor  
--deallocate lang_cursor  
end  
if exists (  
select  'x'  
from ep_ui_mst (nolock)  
where customer_name  = @cust_name_tmp  
and  project_name  = @proj_name_tmp  
and  req_no    = rtrim(@engg_base_req_no)  
and  process_name  = @proc_name_tmp  
and  component_name  = @comp_name_tmp  
and  activity_name  = @act_name_tmp  
and  ui_name    = @ui_name_tmp  
)  
-- modified by shafina on 22-jan-2004 to update ui_descr in ui_mst and ui_req_dtl tables  
begin  
update ep_ui_req_dtl  
set  ui_descr   = @ui_descr_tmp,  
modifiedby   = @ctxt_user,  
modifieddate  = @getdate  
where customer_name  = @cust_name_tmp  
and  project_name  = @proj_name_tmp  
-- code modified by shafina on 10-Nov-2004 for PREVIEWENG203SYS_000175  
--(Unable to delete the Link , Duplicate BTSynonym is shown in the Link tab for client code alone.)  
--       and  req_no    = @req_no_tmp  
and  process_name  = @proc_name_tmp  
and  component_name  = @comp_name_tmp  
and  activity_name  = @act_name_tmp  
and  ui_name    = @ui_name_tmp  
and  ui_descr   <> @ui_descr_tmp -- Code added for Bug Id :  PNR2.0_31788  
  
update ep_ui_mst  
set  ui_descr   = @ui_descr_tmp,  
modifiedby   = @ctxt_user,  
modifieddate  = @getdate  
where customer_name  = @cust_name_tmp  
and  project_name  = @proj_name_tmp  
and  req_no    = rtrim(@engg_base_req_no)  
and  process_name  = @proc_name_tmp  
and  component_name  = @comp_name_tmp  
and  activity_name  = @act_name_tmp  
and  ui_name    = @ui_name_tmp  
  
end  
else  
begin -- if ui does not exist in ui_mst already  
-- Added by Shriram V on 05/07/05 foir Bug Id : PNR2.0_3132  
if not exists (  
select  'x'  
from  ep_ui_req_dtl (nolock)  
where  customer_name  = @cust_name_tmp  
and  project_name   = @proj_name_tmp  
and   req_no      = rtrim(@engg_base_req_no)  
and   process_name   = @proc_name_tmp  
and   component_name  = @comp_name_tmp  
and   activity_name   = @act_name_tmp  
and   ui_name      = @ui_name_tmp)  
  
begin  
-- End of Addition by Shriram V on 05/07/05 foir Bug Id : PNR2.0_3132  
insert into ep_ui_req_dtl  
(  
customer_name,project_name,req_no,process_name,  
component_name,activity_name,ui_name,req_descr,  
process_descr,component_descr,activity_descr,ui_descr,  
ui_status,req_status,req_download_date,  
req_sysid,ui_sysid,timestamp,createdby,  
createddate,modifiedby,modifieddate,req_publish_date  
-- code modified by shafina on 24-Aug-2004 for PREVIEWENG203SYS_000133(The sytem activity name is appearing in the left pane on the  preview)  
-- code modified by shafina on 24-Aug-2004 to rollback the fix for PREVIEWENG203SYS_000133  
--        activity_type  
)  
select  
a.customer_name,a.project_name,@engg_req_no,a.process_name,  
a.component_name,a.activity_name,a.ui_name,rtrim(@engg_req_descr),  
a.process_descr,a.component_descr,a.activity_descr,a.ui_descr,  
'D','C',@getdate,  
newid(),newid(),1,@ctxt_user,  
@getdate,@ctxt_user,@getdate,@getdate--,activity_type  
from ep_bpt_download_vw a (nolock)  
--      ep_ui_mst b (nolock)  
where a.customer_name  = @cust_name_tmp  
and  a.project_name  = @proj_name_tmp  
and  a.req_no   = @req_no_tmp  
and  a.process_name  = @proc_name_tmp  
and  a.component_name = @comp_name_tmp  
and  a.activity_name  = @act_name_tmp  
and  a.ui_name   = @ui_name_tmp  
  
end  
  
-- modified by shafina on 06-feb-2004 to default ui format values from comp_param_mst table  
  
select @capalign_tmp = isnull(current_value,'')  
from es_comp_param_mst_vw (nolock)  
where  customer_name  = @cust_name_tmp  
and  project_name = @proj_name_tmp  
and  process_name  =  @proc_name_tmp  
and  component_name = @comp_name_tmp  
and  param_category  = 'CAPTIONALIGN'  
  
select @capformat_tmp = isnull(current_value,'')  
from es_comp_param_mst_vw (nolock)  
where  customer_name  = @cust_name_tmp  
and  project_name = @proj_name_tmp  
and  process_name  =  @proc_name_tmp  
and  component_name = @comp_name_tmp  
and  param_category  = 'CAPTIONFORMAT'  
-- code modified by shafina on 01-Mar-2005  
select @tabheight_tmp = isnull(current_value,400)  
from es_comp_param_mst_vw (nolock)  
where  customer_name  = @cust_name_tmp  
and  project_name = @proj_name_tmp  
and  process_name  =  @proc_name_tmp  
and  component_name = @comp_name_tmp  
and  param_category  = 'TABHEIGHT'  
  
select @trailbar_tmp = isnull(current_value,'')  
from es_comp_param_mst_vw (nolock)  
where  customer_name  = @cust_name_tmp  
and  project_name = @proj_name_tmp  
and  process_name  =  @proc_name_tmp  
and  component_name = @comp_name_tmp  
and  param_category  = 'TRAILBAR'  
  
if lower(ltrim(rtrim(@capformat_tmp))) = ltrim(rtrim('controls beside captions'))  
select @capformat_tmp = 'bes'  
else  
if lower(ltrim(rtrim(@capformat_tmp))) = ltrim(rtrim('controls under captions'))  
select @capformat_tmp = 'und'  
  
if lower(ltrim(rtrim(@capalign_tmp))) = ltrim(rtrim('center'))  
select @capalign_tmp = 'cent'  
  
if lower(ltrim(rtrim(@trailbar_tmp))) = ltrim(rtrim('bottom'))  
select @trailbar_tmp = 'bott'  
  
insert into ep_ui_mst  
(  
customer_name,   project_name,  req_no,  
process_name,   component_name,  activity_name,  
ui_name,    ui_descr,   ui_type,  
ui_format,    caption_alignment, trail_bar,  
tab_height,    ui_sysid,   timestamp,  
createdby,    createddate,  modifiedby,  
modifieddate,   current_req_no,  ui_doc,  
base_component_name, base_activity_name, base_ui_name  ,wrkreqno, --chan  
grid_type, state_processing -- Code modified for PNR2.0_17527 on 13-Jun-2008 by Gowrisankar  
)  
select  
customer_name,   project_name, @engg_base_req_no,  
process_name,   component_name,  activity_name,  
ui_name,    ui_descr,   '',  
@capformat_tmp,   @capalign_tmp,  @trailbar_tmp,  
@tabheight_tmp,   newid(),   1,  
@ctxt_user,    @getdate,   @ctxt_user, 
@getdate,    req_no,    '',  
'',      '',     ''  ,@req_no_tmp,  
'HTM', 'No'  -- Code modified for PNR2.0_17527 on 13-Jun-2008 by Gowrisankar  
from  ep_bpt_download_vw a(nolock)  
where a.customer_name  = @cust_name_tmp 
and  a.project_name  = @proj_name_tmp  
and  a.req_no   = @req_no_tmp  
and  a.process_name = @proc_name_tmp  
and  a.component_name = @comp_name_tmp  
and  a.activity_name  = @act_name_tmp  
and  a.ui_name   = @ui_name_tmp  
and  isnull(ui_name,'') <> '' -- code added by DNR on 30/12/2003 ,we should not insert a record ,if uiname is null  
  
--  --Code Added For Bugid PNR2.0_3917  
--  exec ep_hdn_sec_ctrl_insert  
--          @ctxt_language,  @ctxt_ouinstance,  @ctxt_service,  
--          @ctxt_user,   @cust_name_tmp,   @proj_name_tmp,  
--          @engg_base_req_no, @proc_name_tmp,   @comp_name_tmp,  
--          @act_name_tmp,  @ui_name_tmp,   @m_errorid out  
  
--code added by DNR on 30/12/2003  
--for each ui ,inserting a default fetch record into ep_action_mst  
select @tmp_ActionType = task_type_name  
from es_comp_task_type_mst_vw(nolock)  
where  customer_name   = @engg_customer_name  
and   project_name   = @engg_project_name  
-- modified by shafina 0n 15-jan-2004 to pass the processname and comp name correctly  
and   process_name   = @proc_name_tmp  
and   component_name  = @comp_name_tmp  
--  and  req_no   = @engg_base_req_no  
and  default_for  = 'Fetch'  
  
--code added by DNR for getting unique prefix ID on 30/12/2003  
exec  engg_gen_prefix_id  
@cust_name_tmp , @proj_name_tmp , @comp_name_tmp , @act_name_tmp ,  
@ui_name_tmp , 'mainscreen', 'P' , 6 , @page_prefix_tmp output  
  
exec ep_ui_page_dtl_sp_ins  
@ctxt_language,  @ctxt_ouinstance,  @ctxt_service,  
@ctxt_user,   @cust_name_tmp,   @proj_name_tmp ,  
@engg_base_req_no, @proc_name_tmp,   @comp_name_tmp,  
@act_name_tmp,  @ui_name_tmp,   '[mainscreen]',  
0,     0,      '',  
@page_prefix_tmp, 1, @req_no_tmp, '' ,'',
'','','',
'','','',
'',
'','','','',		--Tech-70687	
@m_errorid out  
  
-- modified by shafina on 29-jan-2004 to alter the generation of task  
select @comp_pfx_tmp = current_value  
from es_comp_param_mst (nolock)  
where customer_name  = @cust_name_tmp  
and  project_name  = @proj_name_tmp  
and  process_name  = @proc_name_tmp  
and  component_name  = @comp_name_tmp  
and  param_category  =  'compprefix'  
  
--Code Added For BugId :  PNR2.0_3934  
--code modified by Gowrisankar on 27-09-2005 for call id PNR2.0_3975  
if not exists ( select 'x'  
from ep_ui_control_dtl(nolock)  
where  customer_name =  @cust_name_tmp  
and  project_name = @proj_name_tmp  
and  process_name = @proc_name_tmp  
and  component_name = @comp_name_tmp  
and  activity_name = @act_name_tmp  
and  ui_name   = @ui_name_tmp )  
begin  
exec ep_hdn_sec_ctrl_insert  
@ctxt_language,  @ctxt_ouinstance,  @ctxt_service,  
@ctxt_user,   @cust_name_tmp,   @proj_name_tmp,  
@engg_base_req_no, @proc_name_tmp,   @comp_name_tmp,  
@act_name_tmp,  @ui_name_tmp,  @req_no_tmp,@m_errorid out  --chan  
end  
  
--code starts -- added by chanheetha for the call id  PNR2.0_17520  
IF Exists ( select 'x'  
from  ES_UI_REFERENCE_DTL (nolock)  
where Customer_name = @engg_customer_name  
and   Project_name = @engg_project_name  
and   Map_flag  = 'Y' )  
begin  
  
declare @Ref_component_name  engg_name,@Ref_activity_name  engg_name,@Ref_ui_name    engg_name,  
@engg_rf_comp  engg_description, @engg_rf_act engg_description , @engg_rf_ui engg_description ,  
@engg_process_descr engg_description,@engg_component_descr engg_description,  
@engg_act_descr engg_description, @engg_ui_descr engg_description  
  
select @Ref_component_name = Ref_component_name,  
@Ref_activity_name  = Ref_activity_name,  
@Ref_ui_name        = Ref_ui_name,  
@engg_rf_comp    = component_descr ,  
@engg_rf_act       = activity_descr ,  
@engg_rf_ui       = ui_descr  
from  ES_UI_REFERENCE_DTL a (nolock),  
Fw_BPT_RE_NameDesc_Vw  b (nolock)  
where a.Customer_name = @engg_customer_name  
and   a.Project_name = @engg_project_name  
and   Map_flag  = 'Y'  
and   b.customer_name     = @engg_customer_name  
and   b.project_name      = @engg_project_name  
and   b.component_name    = Ref_component_name  
and   b.activity_name     = Ref_activity_name  
and   b.ui_name     = Ref_ui_name  
  
select  @engg_process_descr     =   process_descr,  
@engg_component_descr = component_descr ,  
@engg_act_descr     = activity_descr ,  
@engg_ui_descr     = ui_descr  
from   Fw_BPT_RE_NameDesc_Vw  (nolock)  
where  customer_name   = @engg_customer_name  
and  project_name   = @engg_project_name  
and     process_name    =   @proc_name_tmp  
and  component_name  = @comp_name_tmp  
and  activity_name   = @act_name_tmp  
and  ui_name   =  @ui_name_tmp  
  
IF @ui_name_tmp   <>  'IntegrationUI'  
Begin  
IF NOT EXISTS (Select 'x'  
from ES_UI_REFERENCE_USAGE_DTL a (nolock)  
where  customer_name   = @engg_customer_name  
and  project_name   = @engg_project_name  
and  component_name  = @comp_name_tmp  
and  activity_name   = @act_name_tmp  
and  ui_name   =  @ui_name_tmp   )  
begin  
  
EXEC ep_maireeSpep_layHdrSav @ctxt_ouinstance,@ctxt_user,@ctxt_language,@ctxt_service,@engg_act_descr,'','','','','','', -- -- added for request id: PNR2.0_1790  
@engg_component_descr,  
'','',@engg_customer_name,'','',  
'','','','','',  
'',@engg_process_descr,@engg_project_name, '','',  
'',@req_no_tmp,@engg_rf_act,@engg_rf_comp,@engg_rf_ui,'',0,@engg_ui_descr,'','',@m_errorid out   -- Parameter added against bugid -PNR2.0_31923 
  
Insert into ES_UI_REFERENCE_USAGE_DTL (Customer_name,Project_name,Ref_component_name,Ref_activity_name,Ref_ui_name,  
component_name,activity_name,ui_name,timestamp,createdby,createddate,modifiedby,modifieddate)  
values        (@engg_customer_name,@engg_project_name,@Ref_component_name,@Ref_activity_name,@Ref_ui_name,  
@comp_name_tmp,@act_name_tmp,@ui_name_tmp,1,@ctxt_user,getdate(),@ctxt_user,getdate())  
end  
end  
end  
--code ends -- added by chanheetha for the call id  PNR2.0_17520  
  
if exists  
(  
select 'x'  
from ep_action_mst (nolock)  
where customer_name  = @cust_name_tmp  
and  project_name  = @proj_name_tmp  
and  req_no    = rtrim(@engg_base_req_no)  
and  process_name  = @proc_name_tmp  
and  component_name  = @comp_name_tmp  
and  activity_name  = @act_name_tmp  
and  ui_name    = @ui_name_tmp  
and  task_type   is null  
)  
begin  
select @msg = 'Task Type is null for UI : ' + @ui_name_tmp  
exec engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
'','','','',@m_errorid output  
close dnld_cur  
deallocate dnld_cur  
return  
end  
  
-- modified by shafina on 27-April-2004 for PREVIEWENG203ACC_000048  
if not  exists  
(  
select 'x'  
from ep_action_mst (nolock)  
where customer_name  = @cust_name_tmp  
and  project_name  = @proj_name_tmp  
and  req_no    = rtrim(@engg_base_req_no)  
and  process_name  = @proc_name_tmp  
and  component_name  = @comp_name_tmp  
and  activity_name  = @act_name_tmp  
and  ui_name    = @ui_name_tmp  
and  page_bt_synonym = '[mainscreen]'  
--        and  task_name   = @task_name_tmp  
--CODE MODIFIED BY GIRI ON 11/JUN/2004  
--        and  task_pattern  = @tmp_ActionType  
and  task_type   = 'Fetch'  
)  
begin  
  
--CODE MODIFIED BY GIRI ON 11/JUN/2004 TO INCLUDE TASK TYPE IN EP_ACTION_MST TABLE  
  
insert into ep_action_mst  
(customer_name,project_name,req_no,process_name,component_name,activity_name,  
ui_name,page_bt_synonym,task_name,task_descr,task_seq,task_pattern,timestamp,  
createdby,createddate,modifiedby,modifieddate,primary_control_bts,task_sysid,  
ui_sysid, task_type,wrkreqno)  --chan  
select  
b.customer_name,b.project_name,b.req_no,b.process_name,b.component_name,b.activity_name,  
b.ui_name,'[MAINSCREEN]',--b.ui_name+'_FTH',  
isnull(@comp_pfx_tmp,'') + isnull(@page_prefix_tmp,'') + 'Fth','Default Fetch',1,--'Fetch',  
@tmp_ActionType,1,@ctxt_user,@getdate,'','',  
'[None]',newid(),b.ui_sysid, 'Fetch'  ,@req_no_tmp  
from ep_bpt_download_vw a (nolock) ,  
ep_ui_mst b (nolock)  
where a.customer_name  = @cust_name_tmp  
and  a.project_name  = @proj_name_tmp  
and  a.req_no   = @req_no_tmp  
and  a.process_name  = @proc_name_tmp  
and  a.component_name = @comp_name_tmp  
and  a.activity_name  = @act_name_tmp  
and  a.ui_name   = @ui_name_tmp  
and  a.customer_name  = b.customer_name  
and  a.project_name  = b.project_name  
and  a.process_name  = b.process_name  
and  a.component_name = b.component_name  
and  a.activity_name  = b.activity_name  
and  a.ui_name   = b.ui_name  
  
-- INSERTING INTO EP_PUBLISHED_ACTION_MST_LNG_EXTN  
-- code modified by Ganesh for the callid :: PNR2.0_3386 on 01/08/05  
--Code Modified For BugId :  PNR2.0_3546  
-- Code modified for PNR2.0_13413 on 27-Apr-2007  
insert into ep_action_mst_lng_extn  
(  customer_name,   project_name,   req_no,     process_name,  
component_name,   activity_name,   ui_name,     page_bt_synonym,  
task_name,     task_descr,   task_seq,     task_pattern,  
languageid,    timestamp,    createdby,     createddate,  
modifiedby,    modifieddate,   primary_control_bts,  task_sysid,  
ui_sysid,     task_type,   wrkreqno)--chan  
select  a.customer_name,   a.project_name,  a.req_no,     a.process_name,  
a.component_name,   a.activity_name,  a.ui_name,     a.page_bt_synonym,  
a.task_name,    a.task_descr,   a.task_seq,    a.task_pattern,  
1,       1,      @ctxt_user,    @getdate,  
@ctxt_user,    @getdate,    a.primary_control_bts,  newid(),  
a.ui_sysid,    a.task_type,  @req_no_tmp  
from ep_action_mst  a (nolock)  
where a.customer_name =  @cust_name_tmp  
and  a.project_name =  @proj_name_tmp  
--  and  a.req_no  =  @req_no_tmp  
and  a.process_name = @proc_name_tmp  
and  a.component_name= @comp_name_tmp  
and  a.activity_name = @act_name_tmp  
and  a.ui_name  = @ui_name_tmp  
and  a.task_type  = 'Fetch'  
and  not exists (  
select 's'  
from ep_action_mst_lng_extn c (nolock)  
where c.customer_name  = a.customer_name  
and  c.project_name  = a.project_name  
and  c.req_no   = a.req_no  
and  c.process_name  = a.process_name  
and  c.component_name = a.component_name  
and  c.activity_name  = a.activity_name  
and  c.ui_name   = a.ui_name  
and  c.page_bt_synonym = a.page_bt_synonym  
and  c.task_name   = a.task_name  
and  c.languageid  = 1)  
  
insert into ep_action_mst_lng_extn  
(  customer_name,   project_name,   req_no,     process_name,  
component_name,   activity_name,   ui_name,     page_bt_synonym,  
task_name,     task_descr,   task_seq,     task_pattern,  
languageid,    timestamp,    createdby,     createddate,  
modifiedby,    modifieddate,   primary_control_bts,  task_sysid,  
ui_sysid,     task_type,   wrkreqno)--chan  
select  a.customer_name,   a.project_name,  a.req_no,     a.process_name,  
a.component_name,   a.activity_name,  a.ui_name,     a.page_bt_synonym,  
a.task_name,    --dbo.PLF_XLTranslator_Get_Caption_FN(a.customer_name,a.project_name,a.task_descr,b.quick_code),   -- code modified for PNR2.0_13534   --13578
a.task_descr, --11537 TECH-73992
a.task_seq,    a.task_pattern,  
quick_code,    1,      @ctxt_user,    @getdate,  
@ctxt_user,    @getdate,    a.primary_control_bts,  newid(),  
a.ui_sysid,    a.task_type,    @req_no_tmp  
from ep_action_mst  a (nolock),  
ep_language_met b (nolock)  
where a.customer_name =  @cust_name_tmp  
and  a.project_name =  @proj_name_tmp  
--  and  a.req_no  =  @req_no_tmp  
and  a.process_name = @proc_name_tmp  
and  a.component_name= @comp_name_tmp  
and  a.activity_name = @act_name_tmp  
and  a.ui_name  = @ui_name_tmp  
and  a.task_type  = 'Fetch'  
and  quick_code_type =  'language_code'  
and  quick_code  <> 1  
and  not exists (  
select 's'  
from ep_action_mst_lng_extn c (nolock)  
where c.customer_name  = a.customer_name  
and  c.project_name  = a.project_name  
and  c.req_no   = a.req_no  
and  c.process_name  = a.process_name  
and  c.component_name = a.component_name  
and  c.activity_name  = a.activity_name  
and  c.ui_name   = a.ui_name  
and  c.page_bt_synonym = a.page_bt_synonym  
and  c.task_name   = a.task_name  
and  c.languageid  = quick_code)  
-- Code modified for PNR2.0_13413 on 27-Apr-2007  
  
if @m_errorid > 0  
begin  
close dnld_cur  
deallocate dnld_cur  
return  
end  
end  
  
-- Code modification for  PNR2.0_30127 starts  
  
  
-- Code comment  for  PNR2.0_30890 starts  
/*  
  
If not exists ( select 'x'  
from es_comp_task_type_mst (nolock)  
where customer_name = @engg_customer_name  
and  project_name = @engg_project_name  
and  process_name = @proc_name_tmp  
and  component_name = @comp_name_tmp  
and  task_type_name = 'Disposal'  
)  
Begin  
insert into es_comp_task_type_mst (customer_name , project_name, req_no, process_name, component_name, task_type_name, task_type_descr, default_for, refresh_on_save,  
valid_on_init, err_handle_method, incl_place_holder, cond_ml_fetch, clr_on_page_save, hdr_fetch_req, ml_fet_req, hdr_ref_req, hdr_check_req, proc_sel_rows,  
usr_role_map, trn_scope_req, comp_task_type_sysid, timestamp, createdby, createddate, modifiedby, modifieddate, task_type_doc, hdr_save_req, ml_save_req,  
fprowno_req, cbdef_req, no_placeholder, data_save_req, print_req, task_confirmation, Logic_Extensions, process_updrows) --proc_upd_rows, process_updrows)      --modified against bugid PNR2.0_30255  
Values  
(@engg_customer_name,  @engg_project_name, 'BASE', @proc_name_tmp, @comp_name_tmp,  'Disposal', 'Disposal',  'Disposal', 'N',  
'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', newid(), 1, 'MAINTUSER', getdate(), 'MAINTUSER', getdate(), 'Disposal', 'Y', 'Y',  
'N', 'N', 0, 'N', 'N', 'N', NULL ,NULL  )   --, NULL)                          --modified against bugid PNR2.0_30255  
End  
*/  
  
-- Code comment  for  PNR2.0_30890 ends  
  
  
select @tmp_ActionType1 = task_type_name  
from es_comp_task_type_mst_vw(nolock)  
where customer_name   = @engg_customer_name  
and  project_name = @engg_project_name  
and  process_name = @proc_name_tmp  
and  component_name  = @comp_name_tmp  
and  default_for  = 'Disposal'  
  
if not  exists  
(  
select 'x'  
from ep_action_mst (nolock)  
where customer_name = @cust_name_tmp  
and  project_name = @proj_name_tmp  
and  req_no   = rtrim(@engg_base_req_no)  
and  process_name = @proc_name_tmp  
and  component_name  = @comp_name_tmp  
and  activity_name = @act_name_tmp  
and  ui_name   = @ui_name_tmp  
and  page_bt_synonym = '[mainscreen]'  
and  task_type  = 'Disposal'  
)  
begin  
  
insert into ep_action_mst  
(customer_name,project_name,req_no,process_name,component_name,activity_name,  
ui_name,page_bt_synonym,task_name,task_descr,task_seq,task_pattern,timestamp,  
createdby,createddate,modifiedby,modifieddate,primary_control_bts,task_sysid,  
ui_sysid, task_type,wrkreqno)  
select  
b.customer_name,b.project_name,b.req_no,b.process_name,b.component_name,b.activity_name,  
b.ui_name,'[MAINSCREEN]', isnull(@comp_pfx_tmp,'') + isnull(@page_prefix_tmp,'') + 'Dis','Disposal',2,  
@tmp_ActionType1,1,@ctxt_user,@getdate,'','',  
'[None]',newid(),b.ui_sysid, 'Disposal'  ,@req_no_tmp  
from ep_bpt_download_vw a (nolock) ,  
ep_ui_mst b (nolock)  
where a.customer_name = @cust_name_tmp  
and  a.project_name  = @proj_name_tmp  
and  a.req_no  = @req_no_tmp  
and  a.process_name  = @proc_name_tmp  
and  a.component_name= @comp_name_tmp  
and  a.activity_name = @act_name_tmp  
and  a.ui_name  = @ui_name_tmp  
and  a.customer_name = b.customer_name  
and  a.project_name  = b.project_name  
and  a.process_name  = b.process_name  
and  a.component_name= b.component_name  
and  a.activity_name = b.activity_name  
and  a.ui_name  = b.ui_name  
  
insert into ep_action_mst_lng_extn  
(customer_name,   project_name,   req_no,     process_name,  
component_name,   activity_name,   ui_name,     page_bt_synonym,  
task_name,     task_descr,   task_seq,     task_pattern,  
languageid,    timestamp,    createdby,     createddate,  
modifiedby,    modifieddate,   primary_control_bts,  task_sysid,  
ui_sysid,     task_type,   wrkreqno)--chan  
select  a.customer_name,   a.project_name,  a.req_no,     a.process_name,  
a.component_name,   a.activity_name,  a.ui_name,     a.page_bt_synonym,  
a.task_name,    a.task_descr,   a.task_seq,    a.task_pattern,  
1,       1,      @ctxt_user,    @getdate,  
@ctxt_user,   @getdate,    a.primary_control_bts,  newid(),  
a.ui_sysid,    a.task_type,  @req_no_tmp  
from ep_action_mst  a (nolock)  
where a.customer_name = @cust_name_tmp  
and  a.project_name = @proj_name_tmp  
and  a.process_name = @proc_name_tmp  
and  a.component_name= @comp_name_tmp  
and  a.activity_name = @act_name_tmp  
and  a.ui_name  = @ui_name_tmp  
and  a.task_type  = 'Disposal'  
and  not exists ( select 's'  
from ep_action_mst_lng_extn c (nolock)  
where c.customer_name = a.customer_name  
and  c.project_name  = a.project_name  
and  c.req_no  = a.req_no  
and  c.process_name  = a.process_name  
and  c.component_name= a.component_name  
and  c.activity_name = a.activity_name  
and  c.ui_name  = a.ui_name  
and  c.page_bt_synonym = a.page_bt_synonym  
and  c.task_name  = a.task_name  
and  c.languageid = 1)  
  
insert into ep_action_mst_lng_extn  
(customer_name,   project_name,   req_no,     process_name,  
component_name,   activity_name,   ui_name,     page_bt_synonym,  
task_name,     task_descr,   task_seq,     task_pattern,  
languageid,    timestamp,    createdby,     createddate,  
modifiedby,    modifieddate,   primary_control_bts,  task_sysid,  
ui_sysid,     task_type,   wrkreqno)  
select  a.customer_name,   a.project_name,  a.req_no,     a.process_name,  
a.component_name,   a.activity_name,  a.ui_name,     a.page_bt_synonym,  
a.task_name,   --dbo.PLF_XLTranslator_Get_Caption_FN(a.customer_name,a.project_name,a.task_descr,b.quick_code),  --13578
a.task_descr,--11537 TECH-73992
a.task_seq,    a.task_pattern,  
quick_code,    1,      @ctxt_user,    @getdate,  
@ctxt_user,    @getdate,    a.primary_control_bts,  newid(),  
a.ui_sysid,    a.task_type,    @req_no_tmp  
from ep_action_mst  a (nolock),  
ep_language_met b (nolock)  
where a.customer_name = @cust_name_tmp  
and  a.project_name = @proj_name_tmp  
and  a.process_name = @proc_name_tmp  
and  a.component_name= @comp_name_tmp  
and  a.activity_name = @act_name_tmp  
and  a.ui_name  = @ui_name_tmp  
and  a.task_type  = 'Disposal'  
and  quick_code_type = 'language_code'  
and  quick_code  <> 1  
and  not exists ( select 's'  
from ep_action_mst_lng_extn c (nolock)  
where c.customer_name = a.customer_name  
and  c.project_name  = a.project_name  
and  c.req_no  = a.req_no  
and  c.process_name  = a.process_name  
and  c.component_name= a.component_name  
and  c.activity_name = a.activity_name  
and  c.ui_name  = a.ui_name  
and  c.page_bt_synonym = a.page_bt_synonym  
and  c.task_name  = a.task_name  
and  c.languageid = quick_code)  
  
if @m_errorid > 0  
begin  
close dnld_cur  
deallocate dnld_cur  
return  
end  
end  

--***
		 Declare	@ctxt_role		engg_name	= null

	--IF NOT EXISTS ( SELECT 'X'
	--				FROM	es_comp_ctrl_type_mst (NOLOCK)
	--				WHERE	Customer_name	= @cust_name_tmp
	--				AND		Project_name	= @proj_name_tmp
	--				AND		Process_name	= @proc_name_tmp
	--				AND		component_name	= @comp_name_tmp 
	--				AND		ctrl_type_name	= 'StringEdit')
	--BEGIN	
		EXEC ngplf_addcontroltype
			@ctxt_language_in,				@ctxt_ouinstance_in,		@ctxt_user_in,			@ctxt_role, 
			@cust_name_tmp,					@proj_name_tmp,				@proc_name_tmp,			@comp_name_tmp
	--END
  --**
  
-- Code modification for  PNR2.0_30127 ends  
  
  
-- code commented by shafina on 04-Aug-2004 to insert hiddencontrols properly for a ui (PREVIEWENG203ACC_000083)  
-- code modified by shafina for PREVIEWENG203ACC_000077  
-- code uncommented by shafina on 27-Sep-2004 to insert hiddencontrols properly for a ui (PREVIEWENG203ACC_000083)  
-- code modified by Anuradha on 08-09-2005 for the bug id : PNR2.0_3775  
--  if not exists( select 'x'  
--    from ep_ui_section_dtl(nolock)  
--    where customer_name  = @cust_name_tmp  
--    and project_name  = @proj_name_tmp  
--    and req_no   = @engg_base_req_no  
--    and process_name  = @proc_name_tmp  
--    and component_name  = @comp_name_tmp  
--    and activity_name  =  @act_name_tmp  
--    and ui_name   =  @ui_name_tmp  
--    and section_bt_synonym =  'PrjHdnSection'  
--    )  
--   if not exists  
--       (  
--        select 'x'  
--        from ep_ui_mst (nolock)  
--        where customer_name  = @cust_name_tmp  
--        and  project_name  = @proj_name_tmp  
--        and  req_no    = rtrim(@engg_base_req_no)  
--        and  process_name  = @proc_name_tmp  
--     and  component_name  = @comp_name_tmp  
--        and  activity_name  = @act_name_tmp  
--        and  ui_name    = @ui_name_tmp  
--       )  
--       begin  
--       -- modified by shafina on 09-jan-2004 to insert hdnsection  
--        exec ep_hdn_sec_ctrl_insert  
--          @ctxt_language,  @ctxt_ouinstance,  @ctxt_service,  
--          @ctxt_user,   @cust_name_tmp,   @proj_name_tmp,  
--          @engg_base_req_no, @proc_name_tmp,   @comp_name_tmp,  
--          @act_name_tmp,  @ui_name_tmp,   @m_errorid out  
--  
--        if @m_errorid <> 0  
--        begin  
--         close dnld_cur  
--         deallocate dnld_cur  
--         return  
--        end  
--       end  
end  
-- code modified by shafina on 14-May-2004 for PREVIEWENG203ACC_000059  
if not exists  
(  
select 'x'  
from ep_component_glossary_mst (nolock)  
where customer_name  = @cust_name_tmp  
and  project_name  = @proj_name_tmp  
and  req_no  = 'base' -- Code modified by Arunn for PNR2.0_12169 on 08-Feb-2007  
and  process_name  = @proc_name_tmp  
and  component_name  = @comp_name_tmp  
and  bt_synonym_name  = @ui_name_tmp  
)  
begin  
-- code modified by shafina on 17-June-2004 for PREVIEWENG203ACC_000073  
exec ep_component_glossary_mst_sp_ins  
@ctxt_language,  @ctxt_ouinstance,  @ctxt_service,  
@ctxt_user,   @cust_name_tmp,   @proj_name_tmp,  
@engg_base_req_no, @proc_name_tmp,   @comp_name_tmp,  
@ui_name_tmp,  '',      'Char',  
255,    @ui_descr_tmp,   @ui_descr_tmp,  
'',     'U',     '',  
'',     1,  @req_no_tmp, --chan  
@m_errorid out  
if @m_errorid > 0  
begin  
close dnld_cur  
deallocate dnld_cur  
return  
end  
end  
  
--Code Added by Shriram V on 06/08/05 for Bug Id : PNR2.0_3497  
if not exists  
(  
select 'x'  
from ep_component_glossary_mst (nolock)  
where customer_name  = @cust_name_tmp  
and  project_name  = @proj_name_tmp  
and  process_name  = @proc_name_tmp  
and  req_no  = 'base' -- Code modified by Arunn for PNR2.0_12169 on 08-Feb-2007  
and  component_name  = @comp_name_tmp  
and  bt_synonym_name  = @comp_name_tmp  
)  
begin  
-- code modified by shafina on 17-June-2004 for PREVIEWENG203ACC_000073  
exec ep_component_glossary_mst_sp_ins  
@ctxt_language,  @ctxt_ouinstance,  @ctxt_service,  
@ctxt_user,   @cust_name_tmp,   @proj_name_tmp,  
@engg_base_req_no, @proc_name_tmp,   @comp_name_tmp,  
@comp_name_tmp,  '',      'Char',  
255,    @comp_descr_tmp,   @comp_descr_tmp,  
'',     'U',     '',  
'',     1,@req_no_tmp,--chan  
@m_errorid out  
if @m_errorid > 0  
begin  
close dnld_cur  
deallocate dnld_cur  
return  
end  
end  
--Glossary Lng Extn Insert  
--if not exists  
--(  
--select 'x'  
--from ep_component_glossary_mst_lng_extn (nolock)  
--where customer_name   = @cust_name_tmp  
--and  project_name   = @proj_name_tmp  
--and  req_no  = 'base' -- Code modified by Arunn for PNR2.0_12169 on 08-Feb-2007 
--and  process_name   = @proc_name_tmp  
--and  component_name   = @comp_name_tmp  
--and  bt_synonym_name   = @comp_name_tmp  
--)  
--begin  
---- Code modified for PNR2.0_13413 on 27-Apr-2007  
--insert into ep_component_glossary_mst_lng_extn  
--( customer_name,   project_name,  req_no,  
--process_name,   component_name,  
--bt_synonym_name,  data_type,  length,  
--bt_synonym_caption,  glossary_sysid,  languageid,  
--timestamp,   createdby,  createddate,  
--modifiedby,   modifieddate,  ref_bt_synonym_name,  
--bt_synonym_doc,   bt_name,  synonym_status,  
--singleinst_sample_data,  multiinst_sample_data,wrkreqno --chan  
--)  
  
--select    @cust_name_tmp,     @proj_name_tmp,        @engg_base_req_no,  
--@proc_name_tmp,     @comp_name_tmp,  
--@comp_name_tmp,     'Char',           255,  
--@comp_descr_tmp,     newid(),  1,  
--1,    @ctxt_user,  getdate(),  
--@ctxt_user,   getdate(),  '',  
--@comp_descr_tmp,       '',   'U',  
--'',        ''  ,@req_no_tmp  
  
--insert into ep_component_glossary_mst_lng_extn  
--( customer_name,   project_name,  req_no,  
--process_name,   component_name,  
--bt_synonym_name,  data_type,  length,  
--bt_synonym_caption,  glossary_sysid,  languageid,  
--timestamp,   createdby,  createddate,  
--modifiedby,   modifieddate,  ref_bt_synonym_name,  
--bt_synonym_doc,   bt_name,  synonym_status,  
--singleinst_sample_data,  multiinst_sample_data ,wrkreqno --chan  
--)  
  
--select    @cust_name_tmp,     @proj_name_tmp,        @engg_base_req_no,  
--@proc_name_tmp,     @comp_name_tmp,  
--@comp_name_tmp,     'Char',           255,  
--convert(varchar(3),quick_code) + '_'+ @comp_descr_tmp,     newid(),  quick_code,   -- Code modified for PNR2.0_13413 on 27-Apr-2007  
--1,    @ctxt_user,  getdate(),  
--@ctxt_user,   getdate(),  '',  
--@comp_descr_tmp,       '',   'U',  
--'',        ''  ,@req_no_tmp  
---- code modified by Ganesh for the callid :: PNR2.0_3766 on 6/9/05  
--from  ep_language_met(nolock)  
--where quick_code <> 1  
  
--end -- End of Glossary Lng extn Insert  
  
-- Activity Level Insert  
if not exists  
(  
select 'x'  
from ep_component_glossary_mst (nolock)  
where customer_name  = @cust_name_tmp  
and  project_name  = @proj_name_tmp  
and  req_no  = 'base' -- Code modified by Arunn for PNR2.0_12169 on 08-Feb-2007  
and  process_name  = @proc_name_tmp  
and  component_name  = @comp_name_tmp  
and  bt_synonym_name  = @act_name_tmp  
)  
begin  
-- code modified by shafina on 17-June-2004 for PREVIEWENG203ACC_000073  
exec ep_component_glossary_mst_sp_ins  
@ctxt_language,  @ctxt_ouinstance,  @ctxt_service,  
@ctxt_user,   @cust_name_tmp,   @proj_name_tmp,  
@engg_base_req_no, @proc_name_tmp,   @comp_name_tmp,  
@act_name_tmp,  '',      'Char',  
255,    @act_descr_tmp,   @act_descr_tmp,  
'',     'U',     '',  
'',     1,  @req_no_tmp , --chan  
@m_errorid out  
if @m_errorid > 0  
begin  
close dnld_cur  
deallocate dnld_cur  
return  
end  
end  
--Glossary Lng Extn Insert  
--if not exists  
--(  
--select 'x'  
--from ep_component_glossary_mst_lng_extn (nolock)  
--where customer_name   = @cust_name_tmp  
--and  project_name   = @proj_name_tmp  
--and  req_no  = 'base' -- Code modified by Arunn for PNR2.0_12169 on 08-Feb-2007  
--and  process_name   = @proc_name_tmp  
--and  component_name   = @comp_name_tmp  
--and  bt_synonym_name   = @act_name_tmp  
--)  
--begin  
---- Code modified for PNR2.0_13413 on 27-Apr-2007  
--insert into ep_component_glossary_mst_lng_extn  
--( customer_name,   project_name,  req_no,  
--process_name,   component_name,  
--bt_synonym_name,  data_type,  length,  
--bt_synonym_caption,  glossary_sysid,  languageid,  
--timestamp,   createdby,  createddate,  
--modifiedby,   modifieddate,  ref_bt_synonym_name,  
--bt_synonym_doc,   bt_name,  synonym_status,  
--singleinst_sample_data,  multiinst_sample_data ,wrkreqno --chan  
--)  
  
--select    @cust_name_tmp,     @proj_name_tmp,        @engg_base_req_no,  
--@proc_name_tmp,     @comp_name_tmp,  
--@act_name_tmp,     'Char',           255,  
--@act_descr_tmp,     newid(),  1,  
--1,    @ctxt_user,  getdate(),  
--@ctxt_user,   getdate(),  '',  
--@act_descr_tmp,       '',   'U',  
--'',        ''  ,@req_no_tmp  
  
--insert into ep_component_glossary_mst_lng_extn  
--( customer_name,   project_name,  req_no,  
--process_name,   component_name,  
--bt_synonym_name,  data_type,  length,  
--bt_synonym_caption,  glossary_sysid,  languageid,  
--timestamp,   createdby,  createddate,  
--modifiedby,   modifieddate,  ref_bt_synonym_name,  
--bt_synonym_doc,   bt_name,  synonym_status,  
--singleinst_sample_data,  multiinst_sample_data ,wrkreqno --chan  
--)  
  
--select    @cust_name_tmp,     @proj_name_tmp,        @engg_base_req_no,  
--@proc_name_tmp,     @comp_name_tmp,  
--@act_name_tmp,     'Char',           255,  
--convert(varchar(3),quick_code) + '_'+ @act_descr_tmp,     newid(),  quick_code,   -- Code modified for PNR2.0_13413 on 27-Apr-2007  
--1,    @ctxt_user,  getdate(),  
--@ctxt_user,   getdate(),  '',  
--@act_descr_tmp,       '',   'U',  
--'',        ''  ,@req_no_tmp  
--from  ep_language_met(nolock)  
--where quick_code <> 1  
  
--end -- End of Glossary Lng extn Insert  
  
  
-- End of Activity Level Insert  
  
--End of Code Addition by Shriram V on 06/08/05 for Bug Id : PNR2.0_3497  
  
end -- dnld_cur  
close dnld_cur  
deallocate dnld_cur  
end -- if previewready= 'RPW'  
else  
begin -- else of if previewready= 'RPW'  
select @msg = 'The Selected RequestNumber cannot be downloaded'  
exec engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
'','','','',@m_errorid output  
close dnld_cur  
deallocate dnld_cur  
return  
end -- else of if previewready= 'RPW'  
end -- end of if @engg_req_type = 'DEVELOPMENT'  
  
if rtrim(@engg_req_type) = 'CHANGE'  

begin  
if exists (  
select 'x'  
--       from ep_cmt_download_vw (nolock)  
from ep_cmt_activity_ppw_vw (nolock)  
where customerid = @engg_customer_name  
and  projectid = @engg_project_name  
and  workreqid = @engg_req_no  
--       and  ImpactType  in ('R','N')  
and  previewready= 'RPW'  
)  
begin -- if previewready= 'RPW'  
-- modified by shafina on 30-april-2004 for PREVIEWENG203SYS_000054  
-- modified by shafina on 06-May-2004 for PREVIEWENG203SYS_000061  
declare map_cur cursor for  
select process_name , functionid  
from fw_cmt_cr_vw a(nolock)  
where customer_name = @engg_customer_name  
and  project_name = @engg_project_name  
-- code modified by shafina on 16-Aug-2004 for PREVIEWENG203ACC_000090 (On download of a  
--work request , eventhough function component mapping is done , it is throwing an error like 'Function Component Mapping is not done'  
--for a component that belong to someother work request.)  
and  req_no   = @engg_req_no  
and  previewready = 'RPW'  
  
open map_cur  
while (1=1)  
begin -- map_cur  
fetch next from map_cur  
into @bpid , @funcid  
if (@@fetch_status <> 0)  
break  
  
if not exists (select 'x'  
from fw_bpt_function_component_vw a (nolock)  
where a.customerid = @engg_customer_name  
and  a.projectid  = @engg_project_name  
and  a.bpid   = @bpid  
and  a.functionid = @funcid)  
begin  
select @msg = 'Function - Component mapping is not done for function : ' + @funcid  
exec engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
'','','','',@m_errorid output  
close map_cur  
deallocate map_cur  
return  
end  
end  
close map_cur  
deallocate map_cur  
  
declare dnld_cur cursor for  
select a.customer_name , a.project_name , a.req_no ,  
a.process_name , a.component_name , a.activity_name , a.activity_descr ,  
a.ui_name ,   a.ui_descr ,   a.process_descr , a.component_descr ,  
f.functionabbr  
from ep_cmt_download_vw a (nolock),  
ep_cmt_activity_ppw_vw p (nolock),  
fw_cmt_function f (nolock)  
where a.customer_name  = @engg_customer_name  
and  a.project_name  = @engg_project_name  
and  a.req_no   = rtrim(@engg_req_no)  
and  a.customer_name  = p.customerid  
and  a.project_name  = p.projectid  
and  a.req_no   = p.workreqid  
and  a.process_name  = p.bpid  
and  a.functionid  = p.functionid  
and  a.activity_name  = p.activityid  
and  p.previewready  = 'RPW'  
--     and  a.ImpactType  in ('R','N')  
and  a.customer_name  = f.customerid  
and  a.project_name  = f.projectid  
and  a.req_no   = f.workreqid  
and  a.process_name  = f.bpid  
and  a.functionid  = f.functionid  
--     and  a.ui_name    <> 'IntegrationUI'  
-- code added by Savitha on 04-March-2006 for bug id : PNR2.0_6832  
and a.username = @ctxt_user  
  
open dnld_cur  
while (1=1)  
begin -- dnld_cur  
fetch next from dnld_cur  
into @cust_name_tmp , @proj_name_tmp , @req_no_tmp ,  
@proc_name_tmp , @comp_name_tmp , @act_name_tmp ,  @act_descr_tmp ,  
@ui_name_tmp ,  @ui_descr_tmp ,  @proc_descr_tmp ,  @comp_descr_tmp ,  
@comp_prefix_tmp  
if (@@fetch_status <> 0)  
break  
  

-- code modified by shafina on 12-April-2004 for PREVIEWENG203SYS_000003  
  
if isnull(@cust_name_tmp,'') = ''  
begin  
select @msg = 'Customer name cannot be null'  
exec engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
'','','','',@m_errorid output  
close dnld_cur  
deallocate dnld_cur  
return  
end  
  
if isnull(@proj_name_tmp,'') = ''  
begin  
select @msg = 'Project name cannot be null'  
exec engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
'','','','',@m_errorid output  
close dnld_cur  
deallocate dnld_cur  
return  
end  
  
if isnull(@req_no_tmp,'') = ''  
begin  
select @msg = 'Request no cannot be null'  
exec engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
'','','','',@m_errorid output  
close dnld_cur  
deallocate dnld_cur  
return  
end  
  
if isnull(@proc_name_tmp,'') = ''  
begin  
select @msg = 'Process name cannot be null'  
exec engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
'','','','',@m_errorid output  
close dnld_cur  
deallocate dnld_cur  
return  
end  
  
if isnull(@proc_descr_tmp,'') = ''  
begin  
select @msg = 'Process description cannot be null'  
exec engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
'','','','',@m_errorid output  
close  dnld_cur  
deallocate dnld_cur  
return  
end  
  
if isnull(@comp_name_tmp,'') = ''  
begin  
select @msg = 'Component name cannot be null'  
exec engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
'','','','',@m_errorid output  
close dnld_cur  
deallocate dnld_cur  
return  
end  
  
if isnull(@comp_descr_tmp,'') = ''  
begin  
select @msg = 'Component Description cannot be null'  
exec engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
'','','','',@m_errorid output  
close dnld_cur  
deallocate dnld_cur  
return  
end  
  
if isnull(@act_name_tmp,'') = ''  
begin  
select @msg = 'Activity name cannot be null'  
exec engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
'','','','',@m_errorid output  
close dnld_cur  
deallocate dnld_cur  
return  
end  
  
if isnull(@act_descr_tmp,'') = ''  
begin  
select @msg = 'Activity Description cannot be null'  
exec engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
'','','','',@m_errorid output  
close dnld_cur  
deallocate dnld_cur  
return  
end  
  
if isnull(@ui_name_tmp,'') = ''  
begin  
select @msg = 'UI name cannot be null'  
exec engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
'','','','',@m_errorid output  
close dnld_cur  
deallocate dnld_cur  
return  
end  
  
if isnull(@ui_descr_tmp,'') = ''  
begin  
select @msg = 'UI Description cannot be null'  
exec engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
'','','','',@m_errorid output  
close dnld_cur  
deallocate dnld_cur  
return  
end  


/*
if len(@act_name_tmp) + len(@ui_name_tmp) > 40  
begin  
select @msg = 'UI name and Activity name length cannot be greater than 40'  
exec engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
'','','','',@m_errorid output  
close dnld_cur  
deallocate dnld_cur  
return  
end    */
  
-- code modified by Shafina on 10-jan-2004 for populating component level parameters  
if exists (  
select 'x'  
from es_comp_param_mst (nolock)  
where customer_name = @cust_name_tmp  
and  project_name = @proj_name_tmp  
--         and  req_no   = @req_no_tmp  
and  process_name = @proc_name_tmp  
and  component_name = @comp_name_tmp  
)  
begin  
-- code modified by shafina on 18-May-2004 for PREVIEWENG203ACC_000064 
-- (Component prefix must not be updated from BPT function for the second time.)  
if not exists ( 
select 'x'  
from ep_ui_req_dtl (nolock)  
where customer_name = @cust_name_tmp  
and  project_name = @proj_name_tmp  
and  process_name = @proc_name_tmp  
and  component_name = @comp_name_tmp  
)  
begin  
update es_comp_param_mst  
set  current_value    = @comp_prefix_tmp,  
modifiedby     = @ctxt_user,  
modifieddate    = @getdate  
where  customer_name      = @cust_name_tmp  
and    project_name       = @proj_name_tmp  
and    process_name       = @proc_name_tmp  
and    component_name     = @comp_name_tmp  
and  param_category    = 'COMPPREFIX'  
end  
end  
else  
begin  
-- code modified on 13-Feb-2007 for the BUG ID :: PNR2.0_12237  
if charindex(' ',ltrim(rtrim(@comp_name_tmp))) <> 0  
begin  
select @msg = 'Cannot Download as Component Name : ' + @comp_name_tmp + ' Contains Spaces'  
exec engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
'','','','',@m_errorid output  
close dnld_cur  
deallocate dnld_cur  
return  
end  
  
exec  ep_default_comp_params  
@engg_customer_name,@engg_project_name,@engg_base_req_no,--@engg_req_no,  
@proc_name_tmp,@comp_name_tmp,@comp_prefix_tmp  
  
end 



-- Glance new screen validation  starts
if not exists (select 'x' 
from	ep_ui_req_dtl (nolock)
where	customer_name   	= @cust_name_tmp  
and		project_name	 	= @proj_name_tmp 
and 	process_name		= @proc_name_tmp
and 	component_name		= @comp_name_tmp
and 	activity_name 		= @act_name_tmp
and 	ui_name 			= @ui_name_tmp) 
begin

if not exists (select 'x' 
from	ep_new_ui_mst (nolock)
where	customer_name   	= @cust_name_tmp  
and		project_name	 	= @proj_name_tmp 
and 	process_name		= @proc_name_tmp
and 	component_name		= @comp_name_tmp
and 	activity_name 		= @act_name_tmp
and 	ui_name 			= @ui_name_tmp) 
begin 
----Code added against TECH-218 Starts
	insert into ep_new_ui_mst 
	(customer_name,			project_name,		req_no,			process_name,			component_name,			activity_name,
	ui_name,				ui_descr,			createdby,		createddate)
	Select @cust_name_tmp ,		@proj_name_tmp ,	@req_no_tmp ,	@proc_name_tmp ,		@comp_name_tmp ,	    @act_name_tmp ,
	@ui_name_tmp ,			@ui_descr_tmp ,	    @ctxt_user_in,	GETDATE()

end

end

-- Glance new screen validation  Ends


  
 -- IF NOT EXISTS ( SELECT 'X'
	--				FROM	es_comp_ctrl_type_mst (NOLOCK)
	--				WHERE	Customer_name	= @cust_name_tmp
	--				AND		Project_name	= @proj_name_tmp
	--				AND		Process_name	= @proc_name_tmp
	--				AND		component_name	= @comp_name_tmp 
	--				AND		ctrl_type_name	= 'StringEdit')
	--BEGIN	
		EXEC ngplf_addcontroltype
			@ctxt_language_in,				@ctxt_ouinstance_in,		@ctxt_user_in,			@ctxt_role, 
			@cust_name_tmp,					@proj_name_tmp,				@proc_name_tmp,			@comp_name_tmp
	--END
  --**

--  Added By feroz for populating static controls  
insert into es_stat_ctrl_type_mst  
(customer_name,project_name,ctrl_type_name,ctrl_type_descr,  
base_ctrl_type,handle_events, createdby, createddate, modifiedby, modifieddate)  
select  
@engg_customer_name,@engg_project_name,ctrl_type_name,ctrl_type_descr,  
base_ctrl_type,handle_events, host_name(), getdate(),host_name(), getdate()  
from es_stat_ctrl_type_met b (nolock)  
where  not exists (select 'x'  
from  es_stat_ctrl_type_mst a (nolock)  
where  a.customer_name  = @engg_customer_name  
and  a.project_name   = @engg_project_name  
and  a.ctrl_type_name  = b.ctrl_type_name  
)  
  
  
insert into es_comp_stat_ctrl_type_mst  
(customer_name,project_name,process_name,component_name,  
ctrl_type_name,ctrl_type_descr,base_ctrl_type,handle_events, createdby, createddate, modifiedby, modifieddate)  
select  
customer_name,project_name,@proc_name_tmp,@comp_name_tmp,ctrl_type_name,  
ctrl_type_descr,base_ctrl_type,handle_events, host_name(), getdate(),host_name(), getdate()  
from es_stat_ctrl_type_mst b (nolock)  
where b.customer_name = @engg_customer_name  
and  b.project_name = @engg_project_name  
and  not exists (select 'X'  
from  es_comp_stat_ctrl_type_mst  a (nolock)  
where  a.customer_name  = @engg_customer_name  
and  a.project_name  = @engg_project_name  
and  a.process_name  = @proc_name_tmp  
and  a.component_name  = @comp_name_tmp  
and  a.ctrl_type_name  = b.ctrl_type_name )  
  
  
delete from ep_stat_ctrl_val_mst  
where  customer_name = @engg_customer_name  
and  project_name = @engg_project_name  
  
insert into ep_stat_ctrl_val_mst  
( customer_name,project_name,ctrl_type_name,  
quick_code,quick_code_value,default_flag,  
sequence,languageid,applicable  
)  
select  
@engg_customer_name,@engg_project_name,ctrl_type_name,  
quick_code,quick_code_value,default_flag,  
sequence,languageid,applicable  
from es_stat_ctrl_val_met(nolock)  
where applicable = 'Y'  
--  Added By feroz for populating static controls  
  
-- code modified by shafina on 15-jan-2004 to check whether comp_task_type is populated  
if exists (  
select 'x'  
from es_comp_task_type_mst_vw (nolock)  
where customer_name = @cust_name_tmp  
and  project_name = @proj_name_tmp  
--         and  req_no   = @req_no_tmp  
and  process_name = @proc_name_tmp  
and  component_name = @comp_name_tmp  
)  
begin  
select @engg_req_no = rtrim(@engg_req_no)  
end  
else  
begin  
select @msg = 'Cannot Download as Task Type for Default Fetch is not Defined'  
exec engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
'','','','',@m_errorid output  
close dnld_cur  
deallocate dnld_cur  
return  
end  
--Code modified for BugId : PNR2.0_5941  
  
if exists ( select 'x'  
from ep_ui_req_dtl(nolock)  
where customer_name = @cust_name_tmp  
and  project_name = @proj_name_tmp  
and  process_name = @proc_name_tmp  
and  component_name = @comp_name_tmp  
and  activity_name = @act_name_tmp  
and  ui_name   = @ui_name_tmp  
and  ui_name   <> 'IntegrationUI'  
and  req_status  = 'C'  
and  req_no           <> @engg_req_no   /* PNR2.0_6101  */  
)  
begin  
select  @msg = 'UI -- ' + ui_name + ' is already Downloaded by the Work request - ' + req_no + '.Please publish the Work request '+ req_no  
from   ep_ui_req_dtl(nolock)  
where  customer_name = @cust_name_tmp  
and  project_name = @proj_name_tmp  
and  process_name = @proc_name_tmp  
and  component_name = @comp_name_tmp  
and  activity_name = @act_name_tmp  
and  ui_name   = @ui_name_tmp  
and  req_status  = 'C'  
  
exec engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
'','','','',@m_errorid output  
close dnld_cur  
deallocate dnld_cur  
return  
  
end  
--Code modified for BugId : PNR2.0_5941  
-- modified by shafina on 27-feb-2004 to update activity_descr in ui_req_dtl table  
--      if exists (  
--         select  'x'  
--         from ep_ui_req_dtl (nolock)  
--         where customer_name  = @cust_name_tmp  
--         and  project_name  = @proj_name_tmp  
--         and  req_no    = @engg_req_no  
--         and  process_name  = @proc_name_tmp  
--         and  component_name  = @comp_name_tmp  
--         and  activity_name  = @act_name_tmp  
--         )  
--      begin  
update ep_ui_req_dtl  
set  process_descr  = @proc_descr_tmp,  
modifiedby   = @ctxt_user,  
modifieddate  = @getdate  
where customer_name  = @cust_name_tmp  
and  project_name  = @proj_name_tmp  
--       and  req_no    = @req_no_tmp  
and  process_name  = @proc_name_tmp  
and  process_descr  <> @proc_descr_tmp  -- Code modified for Bug Id: PNR2.0_31788  
  
update ep_ui_req_dtl  
set  component_descr  = @comp_descr_tmp,  
modifiedby   = @ctxt_user,  
modifieddate  = @getdate  
where customer_name  = @cust_name_tmp  
and  project_name  = @proj_name_tmp  
--       and  req_no    = @req_no_tmp  
and  process_name  = @proc_name_tmp  
and  component_name  = @comp_name_tmp  
and  component_descr  <> @comp_descr_tmp -- Code added for Bug Id :  PNR2.0_31788  
  
update ep_ui_req_dtl  
set  activity_descr  = @act_descr_tmp,  
modifiedby   = @ctxt_user,  
modifieddate  = @getdate  
where customer_name  = @cust_name_tmp  
and  project_name  = @proj_name_tmp  
--       and  req_no    = @req_no_tmp  
and  process_name  = @proc_name_tmp  
and  component_name  = @comp_name_tmp  
and  activity_name  = @act_name_tmp  
and  activity_descr  <> @act_descr_tmp  -- Code added for Bug Id :  PNR2.0_31788  
--      end  
-- code modified by shafina on 28-June-2004 for PREVIEWENG203ACC_000073  
-- Btsynonyms defined at projectlevel must be inserted for each component when downloaded for the first time  
if not exists (  
select 'x'  
from ep_ui_req_dtl (nolock)  
where customer_name = @cust_name_tmp  
and  project_name = @proj_name_tmp  
and  process_name = @proc_name_tmp  
and  component_name = @comp_name_tmp  
)  
begin  
insert into ep_component_glossary_mst  
(  
customer_name,  project_name, req_no,  process_name,  component_name,  
bt_synonym_name, data_type,  length,  bt_synonym_caption, glossary_sysid,  
timestamp,   createdby,  createddate,modifiedby,   modifieddate,  
ref_bt_synonym_name,bt_synonym_doc, bt_name, synonym_status, singleinst_sample_data,  
multiinst_sample_data  ,wrkreqno --chan  
)  
select  
@cust_name_tmp,  @proj_name_tmp, 'BASE',  @proc_name_tmp,  @comp_name_tmp,  
bt_synonym_name, data_type,  length,  bt_synonym_caption, newid(),  
1,     @ctxt_user,  @getdate, @ctxt_user,   @getdate,  
ref_bt_synonym_name,bt_synonym_doc, bt_name, 'U',    singleinst_sample_data,  
multiinst_sample_data  ,@req_no_tmp  
from ep_glossary_mst (nolock)  
where  customer_name      = @cust_name_tmp  
and    project_name       = @proj_name_tmp  
-- code modified by shafina on 16-feb-2005 for PREVIEWPFSUPPORT_000008  (while downloading a component , bt synonyms are net getting inserted in lang extn table.)  

--insert into ep_component_glossary_mst_lng_extn  
--(  
--customer_name,  project_name, req_no,  process_name,  component_name,  
--bt_synonym_name, data_type,  length,  bt_synonym_caption, glossary_sysid,  
--timestamp,   createdby,  createddate,modifiedby,   modifieddate,  
--ref_bt_synonym_name,bt_synonym_doc, bt_name, synonym_status,  singleinst_sample_data,  
--multiinst_sample_data,languageid  ,wrkreqno --chan  
--)  
--select  
--@cust_name_tmp,  @proj_name_tmp, 'BASE',  @proc_name_tmp,  @comp_name_tmp,  
--bt_synonym_name, data_type,  length,  bt_synonym_caption, newid(),  
--1,     @ctxt_user,  @getdate, @ctxt_user,   @getdate,  
--ref_bt_synonym_name,bt_synonym_doc, bt_name, 'U',    singleinst_sample_data,  
--multiinst_sample_data,languageid  , @req_no_tmp  
--from ep_glossary_mst_lng_extn (nolock)  
--where  customer_name      = @cust_name_tmp  
--and    project_name       = @proj_name_tmp  
---- code modified by shafina on 16-feb-2005 for PREVIEWPFSUPPORT_000008  (while downloading a component , bt synonyms are net getting inserted in lang extn table.)  
---- Code modified for PNR2.0_13413 on 27-Apr-2007  
--insert into ep_component_glossary_mst_lng_extn  
--(  
--customer_name,  project_name,  req_no,   process_name,  component_name,  
--bt_synonym_name, data_type,   length,   bt_synonym_caption, glossary_sysid,  
--languageid,   timestamp,   createdby,  createddate,  modifiedby,  
--modifieddate,  ref_bt_synonym_name,bt_synonym_doc, bt_name,   synonym_status,  
--singleinst_sample_data, multiinst_sample_data  ,wrkreqno --chan  
--)  
--select  
--@cust_name_tmp,  @proj_name_tmp,  'BASE',   @proc_name_tmp,  @comp_name_tmp,  
--bt_synonym_name, data_type,   length,   bt_synonym_caption, newid(),  
--1,  1,     @ctxt_user,  @getdate,   @ctxt_user,  
--@getdate,   ref_bt_synonym_name,bt_synonym_doc, bt_name,   'U',  
--singleinst_sample_data,     multiinst_sample_data  ,@req_no_tmp  
--from ep_glossary_mst (nolock)  
--where  customer_name      = @cust_name_tmp  
--and    project_name    = @proj_name_tmp  
--and not exists ( select 'x'  
--from   ep_component_glossary_mst_lng_extn b(nolock)  
--where   b.customer_name      =  @cust_name_tmp  
--and     b.project_name       =  @proj_name_tmp  
--and  b.req_no    = 'BASE'  
--and  b.process_name  = @proc_name_tmp  
--and  b.component_name = @comp_name_tmp  
--and  b.bt_synonym_name = bt_synonym_name  
--and  b.languageid  = 1)  

		if not exists 
		(
		select 'K'
		from engg_devcon_codegen_comp_metadata(nolock)
		where componentname  = @comp_name_tmp )
		
		begin--11536

		insert engg_devcon_codegen_comp_metadata
						(	chart,				state,				[pivot],				ddt,				cvs,					excelreport,				logicalextn,		
							errorxml,			instconfig,			imptoolkitdel,		spstub,				refdocs,				quicklink,					datascript,	
							edksscript,			controlextn,		customurl,			datadriventask,		seperrordll,			app,						sys,
							grc,				rtgif,				fpgrid,				sectioncollapse,	displaysepcification,	fillerrow,					gridalternaterowcolor,
							glowcorners,		niftybuttons,		smoothbuttons,		blockerrors,		linkmode,				scrolltitle,				tooltip,
							wizardhtml,			helpmode,			impdeliverables,	quicklinks,			richui,					widgetui,					selallforgridcheckbox,
							contextmenu,		extjs,				accesskey,			richtree,			richchart,				compresshtml,				compressjs,
							allstyle,			alltaskdata,		cellspacing,		applicationcss,		comments,				inplacetrialbar,			captionalignment,
							uiformat,			trialbar,			smartspan,			stylesheet,			custombr,				alllanguage,				deploydeliverables,
							platform,			appliation_rm_type,	generationpath,		multittx,			repprintdate,			componentName,				iEdk,
							statejs,			ucd,				ezreport,			cexml,				intd,					onlyxml,					reportaspx,
							webasync,			errorlookup,		taskpane,			suffixcolon,		gridfilter,				ezlookup,					labelselect,
							ReleaseVersion,		inlinetab,			split,				ellipses,			reportxml,				generatedatejs,				typebro,
							rbtnalign,			ipad5,				desktopdlv,			DeviceConfigPath,	iPhone,					ellipsesleft,				ezeewizard,	
							LayoutControls,		RTState,			SecondaryLink,		depscript_with_actname,						extjs6			
						)
		select				'y',				'n',				'n',				'y',				'n',					'n',							'n',
							'n',				'n',				'n',				'n',				'n',					'n',							'n',
							'n',				'n',				'n',				'n',				'y',					'n',							'n',		
							'n',				'n',				'n',				'y',				'n',					'n',							'n',
							'n',				'n',				'n',				'n',				'n',					'n',							'y',
							'n',				'n',				'n',				'n',				'n',					'n',							'n',
							'n',				'y',				'n',				'n',				'n',					'n',							'n',
							'n',				'n',				null,				'n',				'n',					'n',							'Left',
							'Controls Beside captions','Both',		'y',				'RSGLOBALStyles',	null,					'n',							'n',
							'DOTNET',			'SQL Server',		null,				'n',				'n',					@comp_name_tmp,					'y',
							null,				null,				null,				null,				null,					null,							'Generic Type',--code added for TECH-65177
							'y',				'y',				'n',				null,				null,					null,							null,
							null,				'y',				null,				null,				null,					null,							null,
							null,				null,				null,				null,				null,					'n',							'y',
							'y',				'y',				null,				'y',											'y'
		  end

  
--declare lang_cursor cursor for  
--select quick_code  
--from ep_language_met (nolock)  
--where quick_code <> 1  
  
--open lang_cursor  
--while 1=1  
--begin  
--fetch next from lang_cursor into @langid_tmp  
  
--if @@fetch_status <> 0  
--break  
  
--insert into ep_component_glossary_mst_lng_extn  
--(  
--customer_name,  project_name,  req_no,   process_name,  component_name,  
--bt_synonym_name, data_type,   length,   bt_synonym_caption, glossary_sysid,  
--languageid,   timestamp,   createdby,  createddate,  modifiedby,  
--modifieddate,  ref_bt_synonym_name,bt_synonym_doc, bt_name,   synonym_status,  
--singleinst_sample_data,     multiinst_sample_data  ,wrkreqno --chan  
--)  
--select  
--@cust_name_tmp,  @proj_name_tmp,  'BASE',   @proc_name_tmp,  @comp_name_tmp,  
--bt_synonym_name, data_type, length,   convert(varchar(3),@langid_tmp) + '_'+ bt_synonym_caption, newid(),    -- Code modified for PNR2.0_13413 on 27-Apr-2007  
--@langid_tmp,  1,     @ctxt_user,  @getdate,   @ctxt_user,  
--@getdate,   ref_bt_synonym_name,bt_synonym_doc, bt_name,   'U',  
--singleinst_sample_data,     multiinst_sample_data  ,@req_no_tmp  
--from ep_glossary_mst (nolock)  
--where  customer_name      = @cust_name_tmp  
--and    project_name       = @proj_name_tmp 
----code added by Sangeetha L for the Bug Id:PNR2.0_5265 on 03-Jan-2006  
----code added by Sangeetha L for the Bug Id:PNR2.0_6665 on 28-Feb-2006  
--and not exists ( select 'x'  
--from   ep_component_glossary_mst_lng_extn b(nolock)  
--where   b.customer_name      =  @cust_name_tmp  
--and     b.project_name       =  @proj_name_tmp  
--and  b.req_no    = 'BASE'  
--and  b.process_name  = @proc_name_tmp  
--and  b.component_name = @comp_name_tmp  
--and  b.bt_synonym_name = bt_synonym_name  
--and  b.languageid  = @langid_tmp)  
----code added by Sangeetha L for the Bug Id:PNR2.0_6665 on 28-Feb-2006  
----code added by Sangeetha L for the Bug Id:PNR2.0_5265 on 03-Jan-2006  
--end  
--close lang_cursor  
--deallocate lang_cursor  
end  
  
-- code modified by shafina on 18-feb-2004  
if exists (  
select  'x'  
--  from ep_ui_mst (nolock)  
from ep_ui_req_dtl(nolock)  
where customer_name  = @cust_name_tmp  
and  project_name  = @proj_name_tmp  
--         and  req_no    = rtrim(@engg_base_req_no)  
and  req_no    = rtrim(@req_no_tmp)  
and  process_name  = @proc_name_tmp  
and  component_name  = @comp_name_tmp  
and  activity_name  = @act_name_tmp  
and  ui_name    = @ui_name_tmp  
)  
-- modified by shafina on 22-jan-2004 to update ui_descr in ui_mst and ui_req_dtl tables  
begin  
update ep_ui_req_dtl  
set  ui_descr   = @ui_descr_tmp,  
modifiedby   = @ctxt_user,  
modifieddate  = @getdate  
where customer_name  = @cust_name_tmp  
and  project_name  = @proj_name_tmp  
--     and  req_no    = @req_no_tmp  
and  process_name  = @proc_name_tmp  
and  component_name  = @comp_name_tmp  
and  activity_name  = @act_name_tmp  
and  ui_name    = @ui_name_tmp  
and  ui_descr   <> @ui_descr_tmp -- Code added for Bug Id :  PNR2.0_31788  
end  
else  
begin -- if ui does not exist in ui_mst already  
if not exists  
(  
select 'x'  
from ep_ui_req_dtl (nolock)  
where customer_name  = @cust_name_tmp  
and  project_name  = @proj_name_tmp  
and  req_no    = @req_no_tmp  
and  process_name  = @proc_name_tmp  
and  component_name  = @comp_name_tmp  
and  activity_name  = @act_name_tmp  
and  ui_name    = @ui_name_tmp  
)  
begin  
  
  
  
insert into ep_ui_req_dtl  
(  
customer_name,project_name,req_no,process_name,  
component_name,activity_name,ui_name,req_descr,  
process_descr,component_descr,activity_descr,ui_descr,  
ui_status,req_status,req_download_date,  
req_sysid,ui_sysid,timestamp,createdby,  
createddate,modifiedby,modifieddate,req_publish_date  
--         activity_type  
)  
select  
a.customer_name,a.project_name,rtrim(@engg_req_no),a.process_name,  
a.component_name,a.activity_name,a.ui_name,rtrim(@engg_req_descr),  
a.process_descr,a.component_descr,a.activity_descr,a.ui_descr,  
'D','C',@getdate,  
newid(),newid(),1,@ctxt_user,  
@getdate,@ctxt_user,@getdate,@getdate--,activity_type  
from ep_cmt_download_vw A (nolock) 
where a.customer_name  = @cust_name_tmp  
and  a.project_name  = @proj_name_tmp  
and  a.req_no   = @req_no_tmp  
and  a.process_name  = @proc_name_tmp  
and  a.component_name = @comp_name_tmp  
and  a.activity_name  = @act_name_tmp  
and  a.ui_name   = @ui_name_tmp  
-- code added by Anuradha M on 27-02-2006 for the Bug Id : PNR2.0_6633  
and a.username = @ctxt_user  
-- code added by Anuradha M on 27-02-2006 for the Bug Id : PNR2.0_6633  
  
-- code modified by shafina on 25-Aug-2004 for updating ui descr in ui_mst table (PREVIEWENG203ACC_000064)  
update ep_ui_mst  
set  ui_descr   = @ui_descr_tmp,  
modifiedby   = @ctxt_user,  
modifieddate  = @getdate  
where customer_name  = @cust_name_tmp  
and  project_name  = @proj_name_tmp  
and  req_no    = rtrim(@engg_base_req_no)  
and  process_name  = @proc_name_tmp  
and  component_name  = @comp_name_tmp  
and  activity_name  = @act_name_tmp  
and  ui_name    = @ui_name_tmp  
end  
-- modified by shafina on 06-feb-2004 to default ui format values from comp_param_mst table  
  
select @capalign_tmp = isnull(current_value,'')  
from es_comp_param_mst_vw (nolock)  
where  customer_name  = @cust_name_tmp  
and  project_name = @proj_name_tmp  
and  process_name  =  @proc_name_tmp  
and  component_name = @comp_name_tmp  
and  param_category  = 'CAPTIONALIGN'  
  
select @capformat_tmp = isnull(current_value,'')  
from es_comp_param_mst_vw (nolock)  
where  customer_name  = @cust_name_tmp  
and  project_name = @proj_name_tmp  
and  process_name  =  @proc_name_tmp  
and  component_name = @comp_name_tmp  
and  param_category  = 'CAPTIONFORMAT'  
  
select @tabheight_tmp = isnull(current_value,400)  
from es_comp_param_mst_vw (nolock)  
where  customer_name  = @cust_name_tmp  
and  project_name = @proj_name_tmp  
and  process_name  =  @proc_name_tmp  
and  component_name = @comp_name_tmp  
and  param_category  = 'TABHEIGHT'  
  
select @trailbar_tmp = isnull(current_value,'')  
from es_comp_param_mst_vw (nolock)  
where  customer_name  = @cust_name_tmp  
and project_name = @proj_name_tmp  
and  process_name  =  @proc_name_tmp  
and  component_name = @comp_name_tmp  
and  param_category  = 'TRAILBAR'  
  
if lower(ltrim(rtrim(@capformat_tmp))) = ltrim(rtrim('controls beside captions'))  
select @capformat_tmp = 'bes'  
else  
if lower(ltrim(rtrim(@capformat_tmp))) = ltrim(rtrim('controls under captions'))  
select @capformat_tmp = 'und'  
  
if lower(ltrim(rtrim(@capalign_tmp))) = ltrim(rtrim('center'))  
select @capalign_tmp = 'cent'  
  
if lower(ltrim(rtrim(@trailbar_tmp))) = ltrim(rtrim('bottom'))  
select @trailbar_tmp = 'bott'  
  
  
if not  exists  
(  
select 'x'  
from ep_ui_mst (nolock)  
where customer_name  = @cust_name_tmp  
and  project_name  = @proj_name_tmp  
and  req_no    = rtrim(@engg_base_req_no)  
and  process_name  = @proc_name_tmp  
and  component_name  = @comp_name_tmp  
and  activity_name  = @act_name_tmp  
and  ui_name    = @ui_name_tmp  
)  
begin  
insert into ep_ui_mst   --- glance add
(  
customer_name,   project_name,  req_no,  
process_name,   component_name,  activity_name,  
ui_name,    ui_descr,   ui_type,  
ui_format,    caption_alignment, trail_bar,  
tab_height,    ui_sysid,   timestamp,  
createdby,    createddate,  modifiedby,  
modifieddate,   current_req_no,  ui_doc,  
base_component_name, base_activity_name, base_ui_name  ,wrkreqno --chan  
)  
select  
customer_name,   project_name,  @engg_base_req_no,  
process_name,   component_name,  activity_name,  
ui_name,    ui_descr,   '',  
@capformat_tmp,   @capalign_tmp,  @trailbar_tmp,  
@tabheight_tmp,   newid(),   1,  
@ctxt_user,    @getdate,   @ctxt_user,  
@getdate,    req_no,    '',  
'',      '',     ''  ,@req_no_tmp  
from  ep_cmt_download_vw A(nolock)  
where a.customer_name  = @cust_name_tmp  
and  a.project_name  = @proj_name_tmp  
and  a.req_no   = @req_no_tmp  
and  a.process_name  = @proc_name_tmp  
and  a.component_name = @comp_name_tmp  
and  a.activity_name  = @act_name_tmp  
and  a.ui_name   = @ui_name_tmp  
and  isnull(ui_name,'') <> '' -- code modified by DNR on 30/12/2003 ,we should not insert a record if ui is balnk  
-- code added by Savitha on 04-March-2006 for bug id : PNR2.0_6832  
and a.username = @ctxt_user  
  
--  --Code Added For Bugid PNR2.0_3917  
--        exec ep_hdn_sec_ctrl_insert  
--          @ctxt_language,  @ctxt_ouinstance,  @ctxt_service,  
--          @ctxt_user,   @cust_name_tmp,   @proj_name_tmp,  
--          @engg_base_req_no, @proc_name_tmp,   @comp_name_tmp,  
--          @act_name_tmp,  @ui_name_tmp,   @m_errorid out  
  
end  
/*
-- Glance new screen validation  starts
if not exists (select 'x' 
from	ep_ui_req_dtl (nolock)
where	customer_name   	= @cust_name_tmp  
and		project_name	 	= @proj_name_tmp 
and 	process_name		= @proc_name_tmp
and 	component_name		= @comp_name_tmp
and 	activity_name 		= @act_name_tmp
and 	ui_name 			= @ui_name_tmp) 
begin

if not exists (select 'x' 
from	ep_new_ui_mst (nolock)
where	customer_name   	= @cust_name_tmp  
and		project_name	 	= @proj_name_tmp 
and 	process_name		= @proc_name_tmp
and 	component_name		= @comp_name_tmp
and 	activity_name 		= @act_name_tmp
and 	ui_name 			= @ui_name_tmp) 
begin 
----Code added against TECH-218 Starts
	insert into ep_new_ui_mst 
	(customer_name,			project_name,		req_no,			process_name,			component_name,			activity_name,
	ui_name,				ui_descr,			createdby,		createddate)
	Select @cust_name_tmp ,		@proj_name_tmp ,	@req_no_tmp ,	@proc_name_tmp ,		@comp_name_tmp ,	    @act_name_tmp ,
	@ui_name_tmp ,			@ui_descr_tmp ,	    @ctxt_user_in,	GETDATE()

end

end

-- Glance new screen validation  Ends
*/
--code added by DNR on 30/12/2003  
--for each ui ,inserting a default fetch record into ep_action_mst  
select @tmp_ActionType = task_type_name  
from es_comp_task_type_mst_vw(nolock)  
where  customer_name   = @engg_customer_name  
and   project_name   = @engg_project_name  
and   process_name   = @proc_name_tmp  
and   component_name  = @comp_name_tmp  
--  and  req_no   = @engg_base_req_no  
and  default_for  = 'Fetch'  
  
--code added by DNR for getting unique prefix ID on 30/12/2003  
exec  engg_gen_prefix_id  
@engg_customer_name , @engg_project_name , @comp_name_tmp , @act_name_tmp ,  
@ui_name_tmp , 'mainscreen' , 'P' , 6 , @page_prefix_tmp output  
  
if not  exists  
(  
select 'x'  
from ep_ui_page_dtl (nolock)  
where customer_name  = @cust_name_tmp  
and  project_name  = @proj_name_tmp  
and  req_no    = rtrim(@engg_base_req_no)  
and  process_name  = @proc_name_tmp  
and  component_name  = @comp_name_tmp  
and  activity_name  = @act_name_tmp  
and  ui_name    = @ui_name_tmp  
and  page_bt_synonym  = '[mainscreen]'  
)  
begin  
-- code modified by shafina on 06-July-2004 for inserting page prefix correctly.  
exec ep_ui_page_dtl_sp_ins  
@ctxt_language,  @ctxt_ouinstance,  @ctxt_service,  
@ctxt_user,   @engg_customer_name, @engg_project_name,  
@engg_base_req_no, @proc_name_tmp,   @comp_name_tmp,  
@act_name_tmp,  @ui_name_tmp,   '[mainscreen]',  
0,     0,      '',  
@page_prefix_tmp, 1, @req_no_tmp,  '', '',
'','','',
'','','',
'', 
'','','','',		--Tech-70687	
@m_errorid out  --chan  
  
if @m_errorid > 0  
begin  
close dnld_cur  
deallocate dnld_cur  
return  
end  
end  
-- modified by shafina on 29-jan-2004 to alter the generation of task  
select @comp_pfx_tmp = current_value  
from es_comp_param_mst (nolock)  
where customer_name  = @cust_name_tmp  
and  project_name  = @proj_name_tmp  
and  process_name  = @proc_name_tmp  
and  component_name  = @comp_name_tmp  
and  param_category  =  'compprefix'  
  
--Code Added For BugId :  PNR2.0_3934  
--code modified by Gowrisankar on 27-09-2005 for call id PNR2.0_3975  
if not exists ( select 'x'  
from ep_ui_control_dtl(nolock)  
where  customer_name =  @cust_name_tmp  
and  project_name = @proj_name_tmp  
and  process_name = @proc_name_tmp  
and  component_name = @comp_name_tmp  
and  activity_name = @act_name_tmp  
and  ui_name   = @ui_name_tmp )  
begin  
exec ep_hdn_sec_ctrl_insert  
@ctxt_language,  @ctxt_ouinstance,  @ctxt_service,  
@ctxt_user,   @cust_name_tmp,   @proj_name_tmp,  
@engg_base_req_no, @proc_name_tmp,   @comp_name_tmp,  
@act_name_tmp,  @ui_name_tmp,  @req_no_tmp,@m_errorid out  --chan  
end  
  
select @task_name_tmp = isnull(@comp_pfx_tmp,'') + isnull(@page_prefix_tmp,'') + 'Fth'  
-- code modified by shafina on 28-June-2004 for task type null check  
if exists  
(  
select 'x'  
from ep_action_mst (nolock)  
where customer_name  = @cust_name_tmp  
and  project_name  = @proj_name_tmp  
and  req_no    = rtrim(@engg_base_req_no)  
and  process_name  = @proc_name_tmp  
and  component_name  = @comp_name_tmp  
and  activity_name  = @act_name_tmp  
and  ui_name    = @ui_name_tmp  
and  task_type   is null  
)  
begin  
select @msg = 'Task Type is null for UI : ' + @ui_name_tmp  
exec engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
'','','','',@m_errorid output  
close dnld_cur  
deallocate dnld_cur  
return  
end  
if not  exists  
(  
select 'x'  
from ep_action_mst (nolock)  
where customer_name  = @cust_name_tmp  
and  project_name  = @proj_name_tmp  
and  req_no    = rtrim(@engg_base_req_no)  
and  process_name  = @proc_name_tmp  
and  component_name  = @comp_name_tmp  
and  activity_name  = @act_name_tmp  
and  ui_name    = @ui_name_tmp  
and  page_bt_synonym  = '[mainscreen]'  
--        and  task_name   = @task_name_tmp  
--CODE MODIFIED BY GIRI ON 11-JUN-2004  
--        and  task_pattern  = @tmp_ActionType  
and  task_type   = 'Fetch'  
)  
begin  
  
--CODE MODIFIED BY GIRI ON 11/JUN/2004 TO INCLUDE TASK TYPE IN EP_ACTION_MST TABLE  
  
insert into ep_action_mst  
(customer_name,project_name,req_no,process_name,component_name,activity_name,  
ui_name,page_bt_synonym,task_name,task_descr,task_seq,task_pattern,timestamp,  
createdby,createddate,modifiedby,modifieddate,primary_control_bts,task_sysid,  
ui_sysid,task_type,wrkreqno )   --chan  
select  
b.customer_name,b.project_name,b.req_no,b.process_name,b.component_name,b.activity_name,  
b.ui_name,'[MAINSCREEN]',--b.ui_name+'_FTH',  
isnull(@comp_pfx_tmp,'') + isnull(@page_prefix_tmp,'') + 'Fth' ,'Default Fetch',1,--'Fetch',  
@tmp_ActionType,1,@ctxt_user,@getdate,'','',  
'[None]',newid(),b.ui_sysid, 'Fetch'  ,@req_no_tmp  
from ep_cmt_download_vw A (nolock) ,  
ep_ui_mst B (nolock)  
where a.customer_name  = @cust_name_tmp  
and  a.project_name  = @proj_name_tmp  
and  a.req_no   = @req_no_tmp  
and  a.process_name  = @proc_name_tmp  
and  a.component_name = @comp_name_tmp  
and  a.activity_name  = @act_name_tmp  
and  a.ui_name   = @ui_name_tmp  
and  a.customer_name  = b.customer_name  
and  a.project_name  = b.project_name  
and  a.process_name  = b.process_name  
and  a.component_name = b.component_name  
and  a.activity_name  = b.activity_name  
and  a.ui_name   = b.ui_name  
-- code added by Savitha on 04-March-2006 for bug id : PNR2.0_6832  
and a.username = @ctxt_user  
--Code Added For BugId : PNR2.0_3517  
--Code Modified Fro BugId : PNR2.0_3546  
-- Code modified for PNR2.0_13413 on 27-Apr-2007  
insert into ep_action_mst_lng_extn  
(  customer_name,   project_name,   req_no,     process_name,  
component_name,   activity_name,   ui_name,     page_bt_synonym,  
task_name,     task_descr,   task_seq,     task_pattern,  
languageid,    timestamp,    createdby,     createddate,  
modifiedby,    modifieddate,   primary_control_bts,  task_sysid,  
ui_sysid,     task_type,   wrkreqno)--chan  
select  a.customer_name,   a.project_name,  a.req_no,     a.process_name,  
a.component_name,   a.activity_name,  a.ui_name,     a.page_bt_synonym,  
a.task_name,    a.task_descr,   a.task_seq,    a.task_pattern,  
1,       1,      @ctxt_user,    @getdate,  
@ctxt_user,    @getdate,    a.primary_control_bts,  newid(),  
a.ui_sysid,    a.task_type,  @req_no_tmp  
from ep_action_mst  A (nolock)  
where a.customer_name =  @cust_name_tmp  
and  a.project_name =  @proj_name_tmp  
--  and  a.req_no  =  @req_no_tmp  
and  a.process_name = @proc_name_tmp  
and  a.component_name= @comp_name_tmp  
and  a.activity_name = @act_name_tmp  
and  a.ui_name  = @ui_name_tmp  
and  a.task_type  = 'Fetch'  
and  not exists (  
select 's'  
from ep_action_mst_lng_extn C (nolock)  
where c.customer_name  = a.customer_name  
and  c.project_name  = a.project_name  
and  c.req_no   = a.req_no  
and  c.process_name  = a.process_name  
and  c.component_name = a.component_name  
and  c.activity_name  = a.activity_name  
and  c.ui_name   = a.ui_name  
and  c.page_bt_synonym = a.page_bt_synonym  
and  c.task_name   = a.task_name  
and  c.languageid  = 1)  
  
  
insert into ep_action_mst_lng_extn  
(  customer_name,   project_name, req_no,     process_name,  
component_name,   activity_name,   ui_name,     page_bt_synonym,  
task_name,     task_descr,   task_seq,     task_pattern,  
languageid,    timestamp,    createdby,     createddate,  
modifiedby,    modifieddate,   primary_control_bts,  task_sysid,  
ui_sysid,     task_type,   wrkreqno) --chan  
select  a.customer_name,   a.project_name,  a.req_no,     a.process_name,  
a.component_name,   a.activity_name,  a.ui_name,     a.page_bt_synonym,  
a.task_name,   -- dbo.PLF_XLTranslator_Get_Caption_FN(a.customer_name,a.project_name,a.task_descr,b.quick_code),  --13578
a.task_descr,	--11537 TECH-73992
a.task_seq,    a.task_pattern,  
quick_code,    1,      @ctxt_user,    @getdate,  
@ctxt_user,    @getdate,    a.primary_control_bts,  newid(),  
a.ui_sysid,    a.task_type,  @req_no_tmp  
from ep_action_mst  A (nolock),  
ep_language_met B (nolock)  
where a.customer_name =  @cust_name_tmp  
and  a.project_name =  @proj_name_tmp  
--  and  a.req_no  =  @req_no_tmp  
and  a.process_name = @proc_name_tmp  
and  a.component_name= @comp_name_tmp  
and  a.activity_name = @act_name_tmp  
and  a.ui_name  = @ui_name_tmp  
and  a.task_type  = 'Fetch'  
and  quick_code_type =  'language_code'  
and  quick_code  <> 1  
and  not exists (  
select 's'  
from ep_action_mst_lng_extn C (nolock)  
where c.customer_name  = a.customer_name  
and  c.project_name  = a.project_name  
and  c.req_no   = a.req_no  
and  c.process_name  = a.process_name  
and  c.component_name = a.component_name  
and  c.activity_name  = a.activity_name  
and  c.ui_name   = a.ui_name  
and  c.page_bt_synonym = a.page_bt_synonym  
and  c.task_name   = a.task_name  
and  c.languageid  = quick_code)  
-- Code modified for PNR2.0_13413 on 27-Apr-2007  
end  
  
-- Code comment  for  PNR2.0_30890 starts  
  
/*  
If not exists ( select 'x'  
from es_comp_task_type_mst (nolock)  
where customer_name = @engg_customer_name  
and  project_name = @engg_project_name  
and  process_name = @proc_name_tmp  
and  component_name = @comp_name_tmp  
and  task_type_name = 'Disposal'  
)  
Begin  
insert into es_comp_task_type_mst (customer_name , project_name, req_no, process_name, component_name, task_type_name, task_type_descr, default_for, refresh_on_save,  
valid_on_init, err_handle_method, incl_place_holder, cond_ml_fetch, clr_on_page_save, hdr_fetch_req, ml_fet_req, hdr_ref_req, hdr_check_req, proc_sel_rows,  
usr_role_map, trn_scope_req, comp_task_type_sysid, timestamp, createdby, createddate, modifiedby, modifieddate, task_type_doc, hdr_save_req, ml_save_req,  
fprowno_req, cbdef_req, no_placeholder, data_save_req, print_req, task_confirmation, Logic_Extensions, process_updrows) --proc_upd_rows, process_updrows)  -- Code modified  for PNR2.0_30348  
Values  
(@engg_customer_name,  @engg_project_name, 'BASE', @proc_name_tmp, @comp_name_tmp,  'Disposal', 'Disposal',  'Disposal', 'N',  
'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', newid(), 1, 'MAINTUSER', getdate(), 'MAINTUSER', getdate(), 'Disposal', 'Y', 'Y',  
'N', 'N', 0, 'N', 'N', 'N', NULL , NULL) --,NULL, NULL)  -- Code modified  for PNR2.0_30348  
End  
  
*/  
  
  
-- Code comment  for  PNR2.0_30890 ends  
  
select @tmp_ActionType1 = task_type_name  
from es_comp_task_type_mst_vw(nolock)  
where customer_name   = @engg_customer_name  
and  project_name = @engg_project_name  
and  process_name = @proc_name_tmp  
and  component_name  = @comp_name_tmp  
and  default_for  = 'Disposal'  
  
if not  exists  
(  
select 'x'  
from ep_action_mst (nolock)  
where customer_name = @cust_name_tmp  
and  project_name = @proj_name_tmp  
and  req_no   = rtrim(@engg_base_req_no)  
and  process_name = @proc_name_tmp  
and  component_name  = @comp_name_tmp  
and  activity_name = @act_name_tmp  
and  ui_name   = @ui_name_tmp  
and  page_bt_synonym = '[mainscreen]'  
and  task_type  = 'Disposal'  
)  
begin  
  
insert into ep_action_mst  
(customer_name,project_name,req_no,process_name,component_name,activity_name,  
ui_name,page_bt_synonym,task_name,task_descr,task_seq,task_pattern,timestamp,  
createdby,createddate,modifiedby,modifieddate,primary_control_bts,task_sysid,  
ui_sysid, task_type,wrkreqno)  
select  
b.customer_name,b.project_name,b.req_no,b.process_name,b.component_name,b.activity_name,  
b.ui_name,'[MAINSCREEN]', isnull(@comp_pfx_tmp,'') + isnull(@page_prefix_tmp,'') + 'Dis','Disposal',2,  
@tmp_ActionType1,1,@ctxt_user,@getdate,'','',  
'[None]',newid(),b.ui_sysid, 'Disposal'  ,@req_no_tmp  
from ep_bpt_download_vw a (nolock) ,  
ep_ui_mst b (nolock)  
where a.customer_name = @cust_name_tmp  
and  a.project_name  = @proj_name_tmp  
and  a.req_no  = 'BASE'  
and  a.process_name  = @proc_name_tmp  
and  a.component_name= @comp_name_tmp  
and  a.activity_name = @act_name_tmp  
and  a.ui_name  = @ui_name_tmp  
and  a.customer_name = b.customer_name  
and  a.project_name  = b.project_name  
and  a.process_name  = b.process_name  
and  a.component_name= b.component_name  
and  a.activity_name = b.activity_name  
and  a.ui_name  = b.ui_name  
  
  
insert into ep_action_mst_lng_extn  
(customer_name,   project_name,   req_no,     process_name,  
component_name,   activity_name,   ui_name,     page_bt_synonym,  
task_name,     task_descr,   task_seq,     task_pattern,  
languageid,    timestamp,    createdby,     createddate,  
modifiedby,    modifieddate,   primary_control_bts,  task_sysid,  
ui_sysid,     task_type,   wrkreqno)--chan  
select  a.customer_name,   a.project_name,  a.req_no,     a.process_name,  
a.component_name,   a.activity_name,  a.ui_name,     a.page_bt_synonym,  
a.task_name,    a.task_descr,   a.task_seq,    a.task_pattern,  
1,       1,      @ctxt_user,    @getdate,  
@ctxt_user,    @getdate,    a.primary_control_bts,  newid(),  
a.ui_sysid,    a.task_type,  @req_no_tmp  
from ep_action_mst  a (nolock)  
where a.customer_name = @cust_name_tmp  
and a.project_name = @proj_name_tmp  
and  a.process_name = @proc_name_tmp  
and  a.component_name= @comp_name_tmp  
and  a.activity_name = @act_name_tmp  
and  a.ui_name  = @ui_name_tmp  
and  a.task_type  = 'Disposal'  
and  not exists ( select 's'  
from ep_action_mst_lng_extn c (nolock)  
where c.customer_name = a.customer_name  
and  c.project_name  = a.project_name  
and  c.req_no  = a.req_no  
and  c.process_name  = a.process_name  
and  c.component_name= a.component_name  
and  c.activity_name = a.activity_name  
and  c.ui_name  = a.ui_name  
and  c.page_bt_synonym = a.page_bt_synonym  
and  c.task_name  = a.task_name  
and  c.languageid = 1)  
  
insert into ep_action_mst_lng_extn  
(customer_name,   project_name,   req_no,     process_name,  
component_name,   activity_name,   ui_name,     page_bt_synonym,  
task_name,     task_descr,   task_seq,     task_pattern,  
languageid,    timestamp,    createdby,     createddate,  
modifiedby,    modifieddate,   primary_control_bts,  task_sysid,  
ui_sysid,     task_type,   wrkreqno)  
select  a.customer_name,   a.project_name,  a.req_no,     a.process_name,  
a.component_name,   a.activity_name,  a.ui_name,     a.page_bt_synonym,  
a.task_name,   -- dbo.PLF_XLTranslator_Get_Caption_FN(a.customer_name,a.project_name,a.task_descr,b.quick_code),  --13578
a.task_descr,--11537 TECH-73992
a.task_seq,    a.task_pattern,  
quick_code,    1,      @ctxt_user,    @getdate,  
@ctxt_user,    @getdate,    a.primary_control_bts,  newid(),  
a.ui_sysid,    a.task_type,    @req_no_tmp  
from ep_action_mst  a (nolock),  
ep_language_met b (nolock)  
where a.customer_name = @cust_name_tmp  
and  a.project_name = @proj_name_tmp  
and  a.process_name = @proc_name_tmp  
and  a.component_name= @comp_name_tmp  
and  a.activity_name = @act_name_tmp  
and  a.ui_name  = @ui_name_tmp  
and  a.task_type  = 'Disposal'  
and  quick_code_type = 'language_code'  
and  quick_code  <> 1  
and  not exists ( select 's'  
from ep_action_mst_lng_extn c (nolock)  
where c.customer_name = a.customer_name  
and  c.project_name  = a.project_name  
and  c.req_no  = a.req_no  
and  c.process_name  = a.process_name  
and  c.component_name= a.component_name  
and  c.activity_name = a.activity_name  
and  c.ui_name  = a.ui_name  
and  c.page_bt_synonym = a.page_bt_synonym  
and  c.task_name  = a.task_name  
and  c.languageid = quick_code)  
  
if @m_errorid > 0  
begin  
close dnld_cur  
deallocate dnld_cur  
return  
end  
end  
  
  
--Code modification for  PNR2.0_30127 ends  
  
  
-- code modified by shafina for PREVIEWENG203ACC_000077  
-- code uncommented by shafina on 27-Sep-2004 to insert hiddencontrols properly for a ui (PREVIEWENG203ACC_000083)  
-- code modified by Anuradha on 08-sep-2005 for the bug id : PNR2.0_3775  
--  if not exists( select 'x'  
--    from ep_ui_section_dtl(nolock)  
--    where customer_name  = @cust_name_tmp  
--    and project_name  = @proj_name_tmp  
--    and req_no   = @engg_base_req_no  
--    and process_name  = @proc_name_tmp  
--    and component_name  = @comp_name_tmp  
--    and activity_name  =  @act_name_tmp  
--    and ui_name   =  @ui_name_tmp  
--    and section_bt_synonym =  'PrjHdnSection'  
--    )  
--       if not exists  
--       (  
--        select 'x'  
--        from ep_ui_mst (nolock)  
--        where customer_name  = @cust_name_tmp  
--        and  project_name  = @proj_name_tmp  
--        and  req_no    = rtrim(@engg_base_req_no)  
--        and  process_name  = @proc_name_tmp  
--        and  component_name  = @comp_name_tmp  
--        and  activity_name  = @act_name_tmp  
--        and  ui_name    = @ui_name_tmp  
--       )  
--       begin  
--       -- modified by shafina on 09-jan-2004 to insert hdnsection  
--        exec ep_hdn_sec_ctrl_insert  
--          @ctxt_language,  @ctxt_ouinstance,  @ctxt_service,  
--          @ctxt_user,   @cust_name_tmp,   @proj_name_tmp,  
--          @engg_base_req_no, @proc_name_tmp,   @comp_name_tmp,  
--          @act_name_tmp,  @ui_name_tmp,   @m_errorid out  
--  
--        if @m_errorid <> 0  
--        begin  
--         close dnld_cur  
--         deallocate dnld_cur  
--         return  
--        end  
--        end  
end  
-- code modified by shafina on 14-May-2004 for PREVIEWENG203ACC_000059  
if not exists  
(  
select 'x'  
from ep_component_glossary_mst (nolock)  
where customer_name  = @cust_name_tmp  
and  project_name  = @proj_name_tmp  
and  req_no  = 'base' -- Code modified by Arunn for PNR2.0_12169 on 08-Feb-2007  
and  process_name  = @proc_name_tmp  
and  component_name  = @comp_name_tmp  
and  bt_synonym_name  = @ui_name_tmp  
)  
begin  
exec ep_component_glossary_mst_sp_ins  
@ctxt_language,  @ctxt_ouinstance,  @ctxt_service,  
@ctxt_user,   @cust_name_tmp,   @proj_name_tmp,  
@engg_base_req_no, @proc_name_tmp,   @comp_name_tmp,  
@ui_name_tmp,  '',      'Char',  
255,    @ui_descr_tmp,   @ui_descr_tmp,  
'', 'U',     '',  
'',     1, @req_no_tmp,--chan  
@m_errorid out  
if @m_errorid > 0  
begin  
close dnld_cur  
deallocate dnld_cur  
return  
end  
end  
-- Code Added by Shriram V on 06/08/05 for Bug Id : PNR2.0_3497  
if not exists  
(  
select 'x'  
from ep_component_glossary_mst (nolock)  
where customer_name  = @cust_name_tmp  
and  project_name  = @proj_name_tmp  
and  req_no  = 'base' -- Code modified by Arunn for PNR2.0_12169 on 08-Feb-2007  
and  process_name  = @proc_name_tmp  
and  component_name  = @comp_name_tmp  
and  bt_synonym_name  = @comp_name_tmp  
)  
begin  
-- code modified by shafina on 17-June-2004 for PREVIEWENG203ACC_000073  
exec ep_component_glossary_mst_sp_ins  
@ctxt_language,  @ctxt_ouinstance,  @ctxt_service,  
@ctxt_user,   @cust_name_tmp,   @proj_name_tmp,  
@engg_base_req_no, @proc_name_tmp,   @comp_name_tmp,  
@comp_name_tmp,  '',      'Char',  
255,    @comp_descr_tmp,   @comp_descr_tmp,  
'',     'U',     '',  
'',     1,  @req_no_tmp,--chan  
@m_errorid out  
if @m_errorid > 0  
begin  
close dnld_cur  
deallocate dnld_cur  
return  
end  
end  
--Glossary Lng Extn Insert  
--if not exists  
--(  
--select 'x'  
--from ep_component_glossary_mst_lng_extn (nolock)  
--where customer_name   = @cust_name_tmp  
--and  project_name   = @proj_name_tmp  
--and  req_no  = 'base' -- Code modified by Arunn for PNR2.0_12169 on 08-Feb-2007  
--and  process_name   = @proc_name_tmp  
--and  component_name   = @comp_name_tmp  
--and  bt_synonym_name = @comp_name_tmp  
--)  
--begin  
---- Code modified for PNR2.0_13413 on 27-Apr-2007  
--insert into ep_component_glossary_mst_lng_extn  
--( customer_name,   project_name,  req_no,  
--process_name,   component_name,  
--bt_synonym_name,  data_type,  length,  
--bt_synonym_caption,  glossary_sysid,  languageid,  
--timestamp,   createdby,  createddate,  
--modifiedby,   modifieddate,  ref_bt_synonym_name,  
--bt_synonym_doc,   bt_name,  synonym_status,  
--singleinst_sample_data,  multiinst_sample_data, wrkreqno --chan  
--)  
  
--select    @cust_name_tmp,     @proj_name_tmp,     @engg_base_req_no,  
--@proc_name_tmp,     @comp_name_tmp,  
--@comp_name_tmp,     'Char',           255,  
--@comp_descr_tmp,     newid(),  1,  
--1,    @ctxt_user,  getdate(),  
--@ctxt_user,   getdate(),  '',  
--@comp_descr_tmp,       '',   'U',  
--'',        ''  ,@req_no_tmp  
  
  
--insert into ep_component_glossary_mst_lng_extn  
--( customer_name,   project_name,  req_no,  
--process_name,   component_name,  
--bt_synonym_name,  data_type,  length,  
--bt_synonym_caption,  glossary_sysid,  languageid,  
--timestamp,   createdby,  createddate,  
--modifiedby,   modifieddate,  ref_bt_synonym_name,  
--bt_synonym_doc,   bt_name,  synonym_status,  
--singleinst_sample_data,  multiinst_sample_data ,wrkreqno --chan  
--)  
  
--select    @cust_name_tmp,     @proj_name_tmp,     @engg_base_req_no,  
--@proc_name_tmp,     @comp_name_tmp,  
--@comp_name_tmp,     'Char',           255,  
--convert(varchar(3),quick_code) + '_'+ @comp_descr_tmp,     newid(),  quick_code,  
--1,    @ctxt_user,  getdate(),  
--@ctxt_user,   getdate(),  '',  
--@comp_descr_tmp,       '',   'U',  
--'',        ''  ,@req_no_tmp  
--from  ep_language_met(nolock)  
--where quick_code <> 1   -- Code modified for PNR2.0_13413 on 27-Apr-2007  
  
  
--end -- End of Glossary Lng extn Insert  
  
-- Activity Level Insert  
if not exists  
(  
select 'x'  
from ep_component_glossary_mst (nolock)  
where customer_name  = @cust_name_tmp  
and  project_name  = @proj_name_tmp  
and  req_no  = 'base' -- Code modified by Arunn for PNR2.0_12169 on 08-Feb-2007  
and  process_name  = @proc_name_tmp  
and  component_name  = @comp_name_tmp  
and  bt_synonym_name  = @act_name_tmp  
)  
begin  
-- code modified by shafina on 17-June-2004 for PREVIEWENG203ACC_000073  
exec ep_component_glossary_mst_sp_ins  
@ctxt_language,  @ctxt_ouinstance,  @ctxt_service,  
@ctxt_user,   @cust_name_tmp,   @proj_name_tmp,  
@engg_base_req_no, @proc_name_tmp,   @comp_name_tmp,  
@act_name_tmp,  '',      'Char',  
255,    @act_descr_tmp,   @act_descr_tmp,  
'',     'U',     '',  
'',     1,  @req_no_tmp,--chan  
@m_errorid out  
if @m_errorid > 0  
begin  
close dnld_cur  
deallocate dnld_cur  
return  
end  
end  
--Glossary Lng Extn Insert  
--if not exists  
--(  
--select 'x'  
--from ep_component_glossary_mst_lng_extn (nolock)  
--where customer_name   = @cust_name_tmp  
--and  project_name   = @proj_name_tmp  
--and  req_no  = 'base' -- Code modified by Arunn for PNR2.0_12169 on 08-Feb-2007  
--and  process_name   = @proc_name_tmp  
--and  component_name   = @comp_name_tmp  
--and  bt_synonym_name   = @act_name_tmp  
--)  
--begin  
---- Code modified for PNR2.0_13413 on 27-Apr-2007  
--insert into ep_component_glossary_mst_lng_extn  
--( customer_name,   project_name,  req_no,  
--process_name,   component_name,  
--bt_synonym_name,  data_type,  length,  
--bt_synonym_caption,  glossary_sysid,  languageid,  
--timestamp,   createdby,  createddate,  
--modifiedby,   modifieddate,  ref_bt_synonym_name,  
--bt_synonym_doc,   bt_name,  synonym_status,  
--singleinst_sample_data,  multiinst_sample_data ,wrkreqno --chan  
--)  
  
--select    @cust_name_tmp,     @proj_name_tmp,        @engg_base_req_no,  
--@proc_name_tmp,     @comp_name_tmp,  
--@act_name_tmp,     'Char',           255,  
--@act_descr_tmp,     newid(),  1,  
--1,    @ctxt_user,  getdate(),  
--@ctxt_user,   getdate(),  '',  
--@act_descr_tmp,       '',   'U',  
--'',        ''  ,@req_no_tmp  
  
  
--insert into ep_component_glossary_mst_lng_extn  
--( customer_name,   project_name,  req_no,  
--process_name,   component_name,  
--bt_synonym_name,  data_type,  length,  
--bt_synonym_caption,  glossary_sysid,  languageid,  
--timestamp,   createdby,  createddate,  
--modifiedby,   modifieddate,  ref_bt_synonym_name,  
--bt_synonym_doc,   bt_name,  synonym_status,  
--singleinst_sample_data,  multiinst_sample_data ,wrkreqno --chan  
--)  
  
--select    @cust_name_tmp,     @proj_name_tmp,        @engg_base_req_no,  
--@proc_name_tmp,     @comp_name_tmp,  
--@act_name_tmp,  'Char',           255,  
--convert(varchar(3),quick_code) + '_'+ @act_descr_tmp,     newid(),  quick_code, -- code modified for PNR2.0_13534  
--1,    @ctxt_user,  getdate(),  
--@ctxt_user,   getdate(),  '',  
--@act_descr_tmp,       '',   'U',  
--'',        ''  ,@req_no_tmp  
--from  ep_language_met(nolock)  
--where quick_code <> 1   -- Code modified for PNR2.0_13413 on 27-Apr-2007  

---- NGP
----IF NOT EXISTS ( SELECT 'X' 
----					FROM	es_comp_ctrl_type_mst (NOLOCK)
----					WHERE	Customer_name	= @cust_name_tmp
----					AND		Project_name	= @proj_name_tmp
----					AND		Process_name	= @proc_name_tmp
----					AND		component_name	= @comp_name_tmp 
----					AND		ctrl_type_name	= 'StringEdit')
----	BEGIN	
----		EXEC ngplf_addcontroltype
----			@ctxt_language_in,				@ctxt_ouinstance_in,		@ctxt_user_in,			@ctxt_role, 
----			@cust_name_tmp,					@proj_name_tmp,				@proc_name_tmp,			@comp_name_tmp
----	END
----  --**
  
--end -- End of Glossary Lng extn Insert  
-- End of Activity Level Insert  
--End of Code Addition by Shriram V on 06/08/05 for Bug Id : PNR2.0_3497  
end -- dnld_cur  
close dnld_cur  
deallocate dnld_cur  
end -- if previewready= 'RPW'  
else  
begin -- else of if previewready= 'RPW'  
select @msg = 'The Selected RequestNumber cannot be downloaded'  
exec engg_error_sp 'ep_dnld_sp_dnld_hsv',1,@msg,  
@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
'','','','',@m_errorid output  
--Code Commented For Bugid PNR2.0_19827 Starts Here  
--     close dnld_cur  
--    deallocate dnld_cur  
--Code Commented For Bugid PNR2.0_19827 Ends Here  
return  

--***
	
end -- else of if previewready= 'RPW'  
end -- end of if @engg_req_type = 'CHANGE'  
-- code added by kiruthika on Aug-30-2006 for the Bug ID ::PNR2.0_10099 -- start  
declare @comp_name engg_name , @process_name engg_name  
  
/* Code Modified By Sree for the CaseID: PNR2.0_26826 --Starts  */  
-- Code Commented For BUG ID PNR2.0_27078 Starts Here  
/*if not exists (select 'X' from ep_ui_req_dtl (nolock)  
where customer_name = @cust_name_tmp  
and project_name = @proj_name_tmp  
and component_name = @comp_name)*/  
-- Code Commented For BUG ID PNR2.0_27078 Ends Here  
  
-- Code Added For BUG ID PNR2.0_27078 Starts Here  
If @engg_req_no = 'BASE'  
Begin  
Declare Synonym_cur cursor for  
Select  Distinct d.bpid,d.ComponentName  
from    fw_bpt_activity  a(nolock),  
fw_bpt_activity_ui b(nolock),  
fw_bpt_function_component d(nolock)  
where  a.CustomerID    = @cust_name_tmp  
and  a.ProjectID     = @proj_name_tmp  
and a.CustomerID   = b.CustomerID  
and  a.ProjectID     = b.ProjectID  
and  a.BPID         = b.BPID  
and  a.FunctionID    = b.FunctionID  
and  a.ActivityID    = b.ActivityID  
and  a.previewready  = 'rpw'  
and  a.CustomerID    =  d.CustomerID  
and  a.ProjectID     =  d.ProjectID  
and  a.BPID      =  d.BPID  
and  a.FunctionID    =  d.FunctionID  
and  not  exists  (  
Select 'x'  from  ep_ui_req_dtl c  (nolock)  
where c.Customer_name   = b.CustomerID  
and   c.Project_name    = b.ProjectID  
and   c.process_name    = b.BPID  
and   c.component_name = d.ComponentName  
and   c.activity_name = b.ActivityID  
and   c.ui_name  = b.uiid  
)  
End  
Else  
-- Code Added For BUG ID PNR2.0_27078 Ends Here  
Begin  
declare Synonym_cur cursor for  
select  distinct component_name,process_name  
from  ep_ui_req_dtl(nolock)  
where  customer_name  = @cust_name_tmp  
and  project_name  = @proj_name_tmp  
and   req_no    = @engg_req_no  
End -- Code Added For BUG ID PNR2.0_27078  
  
  
open  Synonym_cur  
  
while (1 = 1)  
begin  -- Synonym_cur  
fetch next from Synonym_cur  
into @comp_name, @process_name  
if @@fetch_status <> 0  
break  
  
  
insert  into  ep_component_glossary_mst  
(customer_name,    project_name,  req_no,    process_name,  
component_name,   bt_synonym_name, data_type,   length,  
bt_synonym_caption,  glossary_sysid,  timestamp,   createdby,  
createddate,    modifiedby,   modifieddate,  ref_bt_synonym_name,  
bt_synonym_doc,   bt_name,   synonym_status,  singleinst_sample_data,  
multiinst_sample_data,  wrkreqno)--chan  
select  
customer_name,     project_name,  req_no,    @process_name,  
@comp_name,     bt_synonym_name,  data_type,   length,  
bt_synonym_caption,   newid(),   timestamp,   createdby,  
getdate(),     modifiedby,   getdate(),   ref_bt_synonym_name,  
bt_synonym_doc,    '',     synonym_status,  singleinst_sample_data,  
multiinst_sample_data ,  @req_no_tmp  
from   ep_glossary_mst a (nolock)  
where a.customer_name  = @cust_name_tmp  
and  a.project_name  = @proj_name_tmp  
and  a.req_no   = 'BASE'  
and bt_synonym_name  not in (select bt_synonym_name  
from ep_component_glossary_mst c(nolock)  
where c.customer_name  = @cust_name_tmp  
and  c.project_name  = @proj_name_tmp  
and  c.req_no   = 'BASE'  
and  c.process_name  = @process_name  
and  c.component_name = @comp_name)  
-- Code modified for PNR2.0_13413 on 27-Apr-2007  

--insert into  ep_component_glossary_mst_lng_extn  
--(customer_name,  project_name,    req_no,    process_name,  component_name,  
--bt_synonym_name, data_type,     length,   bt_synonym_caption, glossary_sysid,  
--languageid, timestamp,     createdby,   createddate,  modifiedby,  
--modifieddate,  ref_bt_synonym_name,  bt_synonym_doc,  bt_name,  
--synonym_status,  singleinst_sample_data,  multiinst_sample_data, wrkreqno)--chan  
--select  
--a.customer_name, project_name,    req_no,    @process_name,   @comp_name,  
--bt_synonym_name, data_type,     length,    bt_synonym_caption,  newid(),  
--1,     a.timestamp,    a.createdby,  getdate(),    a.modifiedby,  
--getdate(),   ref_bt_synonym_name,  bt_synonym_doc,  '',  
--synonym_status,  singleinst_sample_data,  multiinst_sample_data,@req_no_tmp  
--from   ep_glossary_mst a(nolock)  
--where a.customer_name   = @cust_name_tmp  
--and  a.project_name   = @proj_name_tmp  
--and a.req_no    = 'BASE'  
--and     a.bt_synonym_name  not in (select c.bt_synonym_name  
--from ep_component_glossary_mst_lng_extn c(nolock)  
--where c.customer_name  = @cust_name_tmp  
--and  c.project_name  = @proj_name_tmp  
--and  c.req_no   = 'BASE'  
--and  c.process_name  = @process_name  
--and  c.component_name = @comp_name  
--and     c.languageid  = 1 )  
  
  
--insert into  ep_component_glossary_mst_lng_extn  
--(customer_name,  project_name,    req_no,    process_name,  component_name,  
--bt_synonym_name, data_type,     length,    bt_synonym_caption, glossary_sysid,  
--languageid,   timestamp,     createdby,   createddate,  modifiedby,  
--modifieddate,  ref_bt_synonym_name,  bt_synonym_doc,  bt_name,  
--synonym_status,  singleinst_sample_data,  multiinst_sample_data,wrkreqno)--chan  
--select  
--a.customer_name, project_name,    req_no,    @process_name,   @comp_name,  
--bt_synonym_name, data_type,     length,    dbo.PLF_XLTranslator_Get_Caption_FN(a.customer_name,a.project_name,a.bt_synonym_caption,b.quick_code),  newid(),  --13578
--b.quick_code,  a.timestamp,    a.createdby,  getdate(),    a.modifiedby,  
--getdate(),   ref_bt_synonym_name,  bt_synonym_doc,  '',  
--synonym_status,  singleinst_sample_data,  multiinst_sample_data,@req_no_tmp  
--from   ep_glossary_mst a(nolock),  
--EP_LANGUAGE_MET b(NOLOCK)  
--where a.customer_name   = @cust_name_tmp  
--and  a.project_name   = @proj_name_tmp  
--and  a.req_no    = 'BASE'  
--and     b.quick_code_type    =   'language_code'  
--and  b.quick_code   <> 1  
--and     a.bt_synonym_name  not in (select c.bt_synonym_name  
--from ep_component_glossary_mst_lng_extn c(nolock)  
--where c.customer_name  = @cust_name_tmp  
--and  c.project_name  = @proj_name_tmp  
--and  c.req_no   = 'BASE'  
--and  c.process_name  = @process_name  
--and  c.component_name = @comp_name  
--and     c.languageid  = b.quick_code )  
-- Code modified for PNR2.0_13413 on 27-Apr-2007  
  
insert into   re_glossary  
(customer_name,    project_name,  bt_synonym_name, data_type,  
length,      bt_synonym_caption, glossary_sysid,  timestamp,  
createdby,     createddate,  modifiedby,   modifieddate,  
ref_bt_synonym_name,  bt_synonym_doc,  bt_name,   synonym_status,  
component_name,    process_name  )  
select  
customer_name,    project_name,   bt_synonym_name, data_type,  
length,      bt_synonym_caption,  newid(),   timestamp,  
createdby,     getdate(),    modifiedby,   getdate(),  
ref_bt_synonym_name,     bt_synonym_doc,   '',     synonym_status,  
@comp_name,     @process_name  
from   ep_glossary_mst a (nolock)  
where a.customer_name  = @cust_name_tmp  
and  a.project_name  = @proj_name_tmp  
and  a.req_no   = 'BASE'  
and     a.bt_synonym_name  not in (select c.bt_synonym_name  
from re_glossary c(nolock)  
where c.customer_name  = @cust_name_tmp  
and  c.project_name  = @proj_name_tmp  
and  c.process_name  = @process_name  
and  c.component_name = @comp_name)  
-- Code modified for PNR2.0_13413 on 27-Apr-2007  
--insert into   re_glossary_lng_extn  
--(customer_name,   project_name,  process_name,  component_name,  
--bt_synonym_name,  data_type,   length,    bt_synonym_caption,  
--glossary_sysid,  languageid,   timestamp,   createdby,  
--createddate,   modifiedby,   modifieddate,  ref_bt_synonym_name,  
--bt_synonym_doc,  bt_name,   synonym_status)  
--select  
--a.customer_name,  project_name,  @process_name,  @comp_name,  
--bt_synonym_name,  data_type,   length,    bt_synonym_caption,  
--glossary_sysid,   1,     a.timestamp,  a.createdby,  
--getdate(),    a.modifiedby,  getdate(),   ref_bt_synonym_name,  
--bt_synonym_doc,   '',     synonym_status  
--from  ep_glossary_mst a(nolock)  
--where a.customer_name   = @cust_name_tmp  
--and  a.project_name   = @proj_name_tmp  
--and  a.req_no    = 'BASE'  
--and     a.bt_synonym_name  not in ( select c.bt_synonym_name  
--from re_glossary_lng_extn c(nolock)  
--where c.customer_name  = @cust_name_tmp  
--and  c.project_name  = @proj_name_tmp  
--and  c.process_name  = @process_name  
--and  c.component_name = @comp_name  
--and     c.languageid  = 1 )  
  
  
--insert into   re_glossary_lng_extn  
--(customer_name,   project_name,  process_name,  component_name,  
--bt_synonym_name,  data_type,   length,    bt_synonym_caption,  
--glossary_sysid,  languageid,   timestamp,   createdby,  
--createddate,   modifiedby,   modifieddate,  ref_bt_synonym_name,  
--bt_synonym_doc,  bt_name,   synonym_status)  
--select  
--a.customer_name,  project_name,  @process_name,  @comp_name,  
--bt_synonym_name,  data_type,   length,    dbo.PLF_XLTranslator_Get_Caption_FN(a.customer_name,a.project_name,a.bt_synonym_caption,b.quick_code),  --13578
--glossary_sysid,   quick_code,   a.timestamp,  a.createdby,  
--getdate(),    a.modifiedby,  getdate(),   ref_bt_synonym_name,  
--bt_synonym_doc,   '',     synonym_status  
--from  ep_glossary_mst a(nolock),  
--EP_LANGUAGE_MET b(NOLOCK)  
--where a.customer_name   = @cust_name_tmp  
--and  a.project_name   = @proj_name_tmp  
--and  a.req_no    = 'BASE'  
--and     b.quick_code_type    =    'language_code'  
--and  b.quick_code   <> 1  
--and     a.bt_synonym_name  not in ( select c.bt_synonym_name  
--from re_glossary_lng_extn c(nolock)  
--where c.customer_name  = @cust_name_tmp  
--and  c.project_name  = @proj_name_tmp  
--and  c.process_name  = @process_name  
--and  c.component_name = @comp_name  
--and     c.languageid  = b.quick_code )  
-- Code modified for PNR2.0_13413 on 27-Apr-2007  
insert into de_glossary  
(customer_name,   project_name,  bt_synonym_name, data_type,  
length,     bt_synonym_caption, glossary_sysid,  timestamp,  
createdby,    createddate,  modifiedby,   modifieddate,  
ref_bt_synonym_name, bt_synonym_doc,  bt_name,   synonym_status,  
component_name,   process_name)  
select  
customer_name,   project_name,   bt_synonym_name, data_type,  
length,     bt_synonym_caption,  newid(),   timestamp,  
createdby,    getdate(),    modifiedby,   getdate(),  
ref_bt_synonym_name,    bt_synonym_doc,   '',     synonym_status,  
@comp_name,  @process_name  
from   ep_glossary_mst a  (nolock)  
where a.customer_name  = @cust_name_tmp  
and  a.project_name  = @proj_name_tmp  
and  a.req_no  = 'BASE'  
and     a.bt_synonym_name  not in (select c.bt_synonym_name  
from de_glossary c(nolock)  
where c.customer_name  = @cust_name_tmp  
and  c.project_name  = @proj_name_tmp  
and  c.process_name  = @process_name  
and  c.component_name = @comp_name)  
-- Code modified for PNR2.0_13413 on 27-Apr-2007  
--insert into   de_glossary_lng_extn  
--(customer_name,   project_name, process_name,  component_name,  
--bt_synonym_name,  data_type,  length,   bt_synonym_caption,  
--glossary_sysid,   languageid,  timestamp,  createdby,  
--createddate,   modifiedby,  modifieddate,  ref_bt_synonym_name,  
--bt_synonym_doc,   bt_name,  synonym_status)  
--select  
--a.customer_name,   project_name,  @process_name,  @comp_name,  
--bt_synonym_name,   data_type,   length,    bt_synonym_caption,  
--glossary_sysid, 1,     a.timestamp,  a.createdby,  
--getdate(),     a.modifiedby,  getdate(),   ref_bt_synonym_name,  
--bt_synonym_doc,    '',     synonym_status  
--from   ep_glossary_mst a(nolock)  
--where a.customer_name   = @cust_name_tmp  
--and  a.project_name   = @proj_name_tmp  
--and  a.req_no    = 'BASE'  
--and     a.bt_synonym_name  not in ( select c.bt_synonym_name  
--from de_glossary_lng_extn c(nolock)  
--where c.customer_name  = @cust_name_tmp  
--and  c.project_name  = @proj_name_tmp  
--and  c.process_name  = @process_name  
--and  c.component_name = @comp_name  
--and     c.languageid  = 1 )  
  
--insert into   de_glossary_lng_extn  
--(customer_name,   project_name,  process_name, component_name,  
--bt_synonym_name,  data_type,  length,   bt_synonym_caption,  
--glossary_sysid,   languageid,  timestamp,  createdby,  
--createddate,   modifiedby,  modifieddate,  ref_bt_synonym_name,  
--bt_synonym_doc,   bt_name,  synonym_status)  
--select  
--a.customer_name,   project_name,  @process_name,  @comp_name,  
--bt_synonym_name,   data_type,   length,    dbo.PLF_XLTranslator_Get_Caption_FN(a.customer_name,a.project_name,a.bt_synonym_caption,b.quick_code),  --13578
--glossary_sysid,    quick_code,   a.timestamp,  a.createdby,  
--getdate(),     a.modifiedby,  getdate(),   ref_bt_synonym_name,  
--bt_synonym_doc,    '',     synonym_status  
--from   ep_glossary_mst a(nolock),  
--EP_LANGUAGE_MET b(NOLOCK)  
--where a.customer_name   = @cust_name_tmp  
--and  a.project_name   = @proj_name_tmp  
--and  a.req_no    = 'BASE'  
--and     b.quick_code_type    =    'language_code'  
--and  b.quick_code   <> 1  
--and     a.bt_synonym_name  not in ( select c.bt_synonym_name  
--from de_glossary_lng_extn c(nolock)  
--where c.customer_name  = @cust_name_tmp  
--and  c.project_name  = @proj_name_tmp  
--and  c.process_name  = @process_name  
--and  c.component_name = @comp_name  
--and     c.languageid  = b.quick_code )  
-- Code modified for PNR2.0_13413 on 27-Apr-2007  
  
--code starts -- added by Gowrisankar M for the call id  PNR2.0_17527  
Update ep_ui_mst  
Set  ui_type = 'Others'  
where  customer_name    = @cust_name_tmp  
and   project_name    = @proj_name_tmp  
and   process_name    = @process_name  
and   component_name   = @comp_name  
and   activity_name    = 'IntegrationActivity'  
and   ui_name      = 'IntegrationUI'  
and  isnull(ui_type,'') = ''  
--code ends -- added by Gowrisankar M for the call id  PNR2.0_17527  
  
end  
close Synonym_cur  
deallocate Synonym_cur  
-- code added by kiruthika on Aug-30-2006 for the Bug ID ::PNR2.0_10099 -- End  
  
  
--End -- Code Commented For BUG ID PNR2.0_27078  
/* Code Modified By Sree for the CaseID: PNR2.0_26826  -- End */  
end -- end of if modeflag = 'Z'  


-- code added for Multi lang popup section population starts
Update	b
Set		b.PopUp_page_bt_synonym	= a.PopUp_page_bt_synonym,
		b.PopUp_section			= a.PopUp_section,
		b.PopUp_close			= a.PopUp_close,
		b.Popup_onclick_close	= a.Popup_onclick_close
from	ep_action_mst_lng_extn  a (nolock),
		ep_action_mst_lng_extn b (nolock)
where   a.customer_name		= @cust_name_tmp
and		a.project_name		= @proj_name_tmp
and		a.process_name		= @proc_name_tmp
and		a.component_name	= @comp_name_tmp
and		a.activity_name		= @act_name_tmp
and		a.ui_name			= @ui_name_tmp
and		a.customer_name		= b.customer_name
and		a.project_name		= b.project_name
and		a.process_name		= b.process_name
and		a.component_name	= b.component_name
and		a.activity_name		= b.activity_name
and		a.ui_name			= b.ui_name
and		a.page_bt_synonym	= b.page_bt_synonym
and		a.task_name			= b.task_name
and		a.languageid		=	'1'
and		b.languageid		<>	'1'

-- code added for Multi lang popup section population Ends
 

 If exists (
			select 'X' from ep_new_ui_mst (nolock) --code added by 11536 for the bug id TECH-14976
			where	customer_name	=	@cust_name_tmp  
			and		project_name	=	@proj_name_tmp  
			and		req_no			=	rtrim(@engg_base_req_no)  
			and		process_name	=	@proc_name_tmp  
			and		component_name  =	@comp_name_tmp  
			and		activity_name	=	@act_name_tmp  
			and		ui_name			=	@ui_name_tmp
		)
			Begin 
				update ep_ui_mst
				set		SmartHide ='Y'
				where	customer_name	=	@cust_name_tmp  
				and		project_name	=	@proj_name_tmp  
				and		req_no			=	rtrim(@engg_base_req_no)  
				and		process_name	=	@proc_name_tmp  
				and		component_name  =	@comp_name_tmp  
				and		activity_name	=	@act_name_tmp  
				and		ui_name			=	@ui_name_tmp
				and		ISNULL(SmartHide,'') <> 'Y'
			end  

					if exists ( select  'x'  -- code added by 11536 for the case id TECH-20631
					from	ep_ui_req_dtl(nolock)  
					where	customer_name		=	@cust_name_tmp  
					and		project_name		=	@proj_name_tmp  
					and		req_no				=	rtrim(@req_no_tmp)  
					and		process_name		=	@proc_name_tmp  
					and		component_name		=	@comp_name_tmp  
					and		req_status			=	'c'
					)  
					begin 

						Update	FW_NIA_GenDoc_Rcn_Ecr_ICO_temp 
						set		doc_status			=	'WRDW'
						where	Customerid			=	@cust_name_tmp
						and		Projectid			=	@proj_name_tmp
						and		componentname		=	@comp_name_tmp
						and		WorkReqID			=	rtrim(@req_no_tmp) 

					End


	
  
if @engg_req_status_in not in ('dwld_ezeeview')   --Code modified for PNR2.0_28333  
--output parameters  
select  @fprowno     'fprowno_io' /* DOTNET Migration Tool Changes */  
  
set nocount off  
end  
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME= 'ep_dnld_sp_dnldgrid' AND TYPE='P')
BEGIN
	GRANT EXEC ON  ep_dnld_sp_dnldgrid TO PUBLIC
END
GO  
  
  
  
  
  
  
  
  
  
  












