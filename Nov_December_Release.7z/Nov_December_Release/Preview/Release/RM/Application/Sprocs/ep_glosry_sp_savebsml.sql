IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_glosry_sp_savebsml' AND TYPE = 'P')
BEGIN
	DROP PROC ep_glosry_sp_savebsml                            
END
GO
/******************************************************************************/
/*      V E R S I O N      :  PNR2.0_1403    */  
/*      Released By        :  Development Team    */  
/*      Release Comments   :  For DotNet Migration, Naming convention has been changed  for some of the out parameters by using Stub Generator.Comments will not be there for this Request ID.    */  
/*      V E R S I O N      :  2.0.3    */  
/*      Released By        :  PTech    */  
/*      Release Comments   :  Released on 03-Dec-2004 (Patch Release 9)    */  
/*      V E R S I O N      :  2.0.2    */  
/*      Released By        :  PTech    */  
/*      Release Comments   :  Released on  22-Jan-2004    */  
/********************************************************************************/  
/* procedure    : ep_glosry_sp_savebsml                                         */  
/* description  :                                                               */  
/********************************************************************************/  
/* project      : Preview                                                       */  
/* version      :                                                               */  
/********************************************************************************/  
/* referenced   :                                                               */  
/* tables       :                                                               */  
/********************************************************************************/  
/* development history                                                          */  
/********************************************************************************/  
/* author       : Surendar.K                                          */  
/* date         : 11/ 12/ 2003                                                  */  
/********************************************************************************/  
/* modification history                                                         */  
/********************************************************************************/  
/* modification history                                                         */  
/* Modified by : Ganesh for callid PNR2.0_3386     */  
/* Modified on : 01/08/05        */  
/* Description : Add Component Description, Activity Description and Task Description in Glossary.*/  
/********************************************************************************/  
/* modification history                                                         */  
/* Modified by : Sangeetha L for callid Platform_2.0.3.X_265   */  
/* Modified on : 01/08/05        */  
/* Description : service generated with a parameter "Name".The service got generated without any errors.But,when I tried to change the flow direction ,It is throwing an error.*/  
/* Modified by : Shriram V       */  
/* Modified on : 23/11/05        */  
/* Description : Keyword not allowded as parameter Bug Id : PNR2.0_4751  */  
/********************************************************************************/  
/* modification history                                                         */  
/* Modified by : kiruthika R       */  
/* Modified on : 23/11/05        */  
/* Description : PNR2.0_4739       */  
/********************************************************************************/  
/* Modified by : kiruthika R       */  
/* Modified on : 12/12/05        */  
/* Description : PNR2.0_4926       */  
/********************************************************************************/  
/* Modified by : kiruthika R       */  
/* Modified on : 03/03/06        */  
/* Description : PNR2.0_6778       */  
/********************************************************************************/  
/* Modified by : kiruthika R       */  
/* Modified on : 19/07/06        */  
/* Description : PNR2.0_9568       */  
/********************************************************************************/  
/* Modified By  : Date :   Description :    */  
/* S K Mohamed Mohideen 15 Jun 2006 Task Confirmation Message changes */  
/* S K Mohamed Mohideen 09 Nov 2006 Task Status Message changes  */  
/********************************************************************************/  
/* Modified By  :   Date :    Description   :    */  
/* Balaji S     28 Feb 2007  PNR2.0_12403      */  
/********************************************************************************/  
/* Modified by : Gowrisankar M              */  
/* Modified on : 27-Apr-2007              */  
/* Description : PNR2.0_13413             */  
/********************************************************************************/  
/* Modified by : kiruthika R             */  
/* Modified on : 15/05/07               */  
/* Description : PNR2.0_13644             */  
/********************************************************************************/  
/* Modified by : Balaji S              */  
/* Modified on : 04/06/07               */  
/* Description : PNR2.0_13940             */  
/********************************************************************************/  
/* Modified by : Balaji S              */  
/* Modified on : 04/06/07               */  
/* Description : PNR2.0_13947             */  
/********************************************************************************/  
/* Modified by : Anuradha M       */  
/* Modified on : 20/08/07        */  
/* Description : PNR2.0_15013        */  
/********************************************************************************/  
/* Modified by : Gowrisankar M             */  
/* Modified on : 10-Jan-2008              */  
/* Description : PNR2.0_16449              */  
/********************************************************************************/  
/* Modified by : Gowrisankar M for PNR2.0_20625         */  
/* Modified on : 16-Jan-2009                      */  
/* Description : Changes in where clauses for better performance             */  
/********************************************************************************/  
/* Modified by : Gowrisankar M             */  
/* Modified on : 25-Sep-2009                      */  
/* BugID    : PNR2.0_23408                      */  
/* Description : Validation additions and Task option enabling              */  
/********************************************************************************/  
/* modified by   : Sangeetha G           */  
/* date    : 11-Apr-2011         */  
/* BugId   : PNR2.0_30869          */  
/* modified for   : Feature Release      */  
/************************************************************************/  
/* modified by   : Sangeetha G           */  
/* date    : 27-Apr-2011         */  
/* BugId   : PNR2.0_31051          */  
/* modified for   : Cannot delete task processing message      */  
/************************************************************************/
/* modified by   : Vignesh R           */  
/* date			 : 27-5-2011         */  
/* BugId		 : PNR2.0_31581          */  
/* modified for	 : Hidden_view_bt_synonym not getting fetched.      */  
/********************************************************************************/   
/* modified by   : Gankan G														*/  
/* date			 : 19-Nov-2012													*/  
/* BugId		 : PLF2.0_01716													*/  
/* modified for	 : Code modified to include caption changes for handle changes	*/  
/********************************************************************************/ 
/* modified by			Date				Defect ID							*/
/* Veena U				08-Jun-2016			PLF2.0_18487						*/
/********************************************************************************/
/* Modified by : Jeya Latha K/Ganesh Prabhu S	for callid TECH-7349				*/
/* Modified on : 14-03-2017				 											*/
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and New Feature Organization chart */
/* Modified by  : Jeya Latha K/Venkatesan K	Date: 31-Oct-2018  Defect ID : TECH-28010 */  
/* Modified by  : Jeya Latha K				Date: 01-Nov-2019  Defect ID : TECH-39534 */  
/**************************************************************************************/
/* Modified by : Jeya Latha K               Date: 04-Dec-2019  Defect ID : TECH-40809 */
/* Modified by : Kiruthika R				Date: 27-Aug-2020  Defect ID : TECH-49351 */
/*************************************************************************************************/
/* Modified by			: Priyadharshini U														 */
/* Date					: 28-Oct-2022															 */
/* Defect ID			: TECH-73996															 */
/*************************************************************************************************/
/* Modified by : Ponmalar A					Date: 02-Dec-2022  Defect ID : TECH-75230			 */
/*************************************************************************************************/
CREATE Procedure ep_glosry_sp_savebsml  
@ctxt_language_in             engg_ctxt_language,  
@ctxt_ouinstance_in           engg_ctxt_ouinstance,  
@ctxt_service_in              engg_ctxt_service,  
@ctxt_user_in                 engg_ctxt_user,  
@engg_act_descr_in			  engg_description,  
@engg_bs_btsyn_name_in        engg_name,  
@engg_bs_datatype_in          engg_name,  
@engg_bs_length_in            engg_length,  
@engg_bs_refbtsyn_name_in     engg_name,  
@engg_bs_sdescr_in            engg_description,  
@engg_bs_spl_text_in          engg_description,  
@engg_btsdes_like_in          engg_description,  
@engg_btsyn_like_in           engg_description,  
@engg_component_in            engg_description,  
@engg_customer_name_in        engg_name,  
@engg_datatype_in             engg_type,  
@engg_from_length_in          engg_length,  
@engg_mi_sample_in         engg_documentation,  
@engg_process_descr_in        engg_description,  
@engg_project_name_in         engg_name,  
@engg_req_no_in               engg_name,  
@engg_res_btsyn_in            engg_description,  
@engg_si_sample_in          engg_documentation,  
@engg_syn_usage_in            engg_name,  
@engg_to_length_in            engg_length,  
@engg_tot_btsyn_in            engg_description,  
@engg_ui_descr_in             engg_description,  
@engg_unr_btsyn_in            engg_description,  
@guid_in                      engg_guid,  
@modeflag_in                  engg_modeflag,  
@fprowno_io                   engg_rowno,  
@m_errorid                    engg_seqno output  
as  
begin  
  
set nocount on  
  
--declaration of temporary variables  
declare @ctxt_language                engg_ctxt_language  
declare @ctxt_ouinstance              engg_ctxt_ouinstance  
declare @ctxt_service                 engg_ctxt_service  
declare @ctxt_user                    engg_ctxt_user  
declare @engg_act_descr               engg_description  
declare @engg_bs_btsyn_name           engg_name  
declare @engg_bs_datatype             engg_name  
declare @engg_bs_length               engg_length  
declare @engg_bs_refbtsyn_name        engg_name  
declare @engg_bs_sdescr               engg_description  
declare @engg_bs_spl_text             engg_description  
declare @engg_btsdes_like             engg_description  
declare @engg_btsyn_like              engg_description  
declare @engg_component               engg_description  
declare @engg_customer_name           engg_name  
declare @engg_datatype                engg_type  
declare @engg_from_length             engg_length  
declare @engg_process_descr           engg_description  
declare @engg_project_name            engg_name  
declare @engg_req_no                  engg_name  
declare @engg_res_btsyn               engg_description  
declare @engg_syn_usage               engg_name  
declare @engg_to_length               engg_length  
declare @engg_tot_btsyn               engg_description  
declare @engg_ui_descr                engg_description  
declare @engg_unr_btsyn               engg_description  
declare @guid                         engg_guid  
declare @modeflag                     engg_modeflag  
declare @fprowno                      engg_rowno  
declare @engg_mi_sample   engg_documentation  
declare @engg_si_sample   engg_documentation  
declare @langid    engg_name  
declare @act_name   engg_name  
declare @ui_name   engg_name  
  
--temporary and formal parameters mapping  
select @ctxt_language                 = @ctxt_language_in  
select @ctxt_ouinstance               = @ctxt_ouinstance_in  
select @ctxt_service                  = ltrim(rtrim(@ctxt_service_in))  
select @ctxt_user                     = ltrim(rtrim(@ctxt_user_in))  
select @engg_act_descr                = ltrim(rtrim(@engg_act_descr_in))  
select @engg_bs_btsyn_name            = ltrim(rtrim(@engg_bs_btsyn_name_in))  
select @engg_bs_datatype          = ltrim(rtrim(@engg_bs_datatype_in))  
select @engg_bs_length                = @engg_bs_length_in  
select @engg_bs_refbtsyn_name         = ltrim(rtrim(@engg_bs_refbtsyn_name_in))  
select @engg_bs_sdescr                = ltrim(rtrim(@engg_bs_sdescr_in))  
select @engg_bs_spl_text              = ltrim(rtrim(@engg_bs_spl_text_in))  
select @engg_btsdes_like              = ltrim(rtrim(@engg_btsdes_like_in))  
select @engg_btsyn_like               = ltrim(rtrim(@engg_btsyn_like_in))  
select @engg_component                = ltrim(rtrim(@engg_component_in))  
select @engg_customer_name            = ltrim(rtrim(@engg_customer_name_in))  
select @engg_datatype                 = ltrim(rtrim(@engg_datatype_in))  
select @engg_from_length              = @engg_from_length_in  
select @engg_process_descr            = ltrim(rtrim(@engg_process_descr_in))  
select @engg_project_name             = ltrim(rtrim(@engg_project_name_in))  
select @engg_req_no                   = ltrim(rtrim(@engg_req_no_in))  
select @engg_res_btsyn                = ltrim(rtrim(@engg_res_btsyn_in))  
select @engg_syn_usage                = ltrim(rtrim(@engg_syn_usage_in))  
select @engg_to_length                = @engg_to_length_in  
select @engg_tot_btsyn                = ltrim(rtrim(@engg_tot_btsyn_in))  
select @engg_ui_descr                 = ltrim(rtrim(@engg_ui_descr_in))  
select @engg_unr_btsyn                = ltrim(rtrim(@engg_unr_btsyn_in))  
select @guid                          = ltrim(rtrim(@guid_in))  
select @modeflag                      = ltrim(rtrim(@modeflag_in))  
select @fprowno                       = @fprowno_io  
select @engg_mi_sample                = ltrim(rtrim(@engg_mi_sample_in))  
select @engg_si_sample             = ltrim(rtrim(@engg_si_sample_in))  
  
--null checking  
if @ctxt_language = -915  
select @ctxt_language = null  
  
if @ctxt_ouinstance = -915  
select @ctxt_ouinstance = null  
  
if @ctxt_service = '~#~'  
select @ctxt_service = null  
  
if @ctxt_user = '~#~'  
select @ctxt_user = null  
  
if @engg_act_descr = '~#~'  
select @engg_act_descr = null  
  
if @engg_bs_btsyn_name = '~#~'  
select @engg_bs_btsyn_name = null  
  
if @engg_bs_datatype = '~#~'  
select @engg_bs_datatype = null  
  
if @engg_bs_length = -915  
select @engg_bs_length = null  
  
if @engg_bs_refbtsyn_name = '~#~'  
select @engg_bs_refbtsyn_name = null  
  
if @engg_bs_sdescr = '~#~'  
select @engg_bs_sdescr = null  
  
if @engg_bs_spl_text = '~#~'  
select @engg_bs_spl_text = null  
  
if @engg_btsdes_like = '~#~'  
select @engg_btsdes_like = null  
  
if @engg_btsyn_like = '~#~'  
select @engg_btsyn_like = null  
  
if @engg_component = '~#~'  
select @engg_component = null  
  
if @engg_customer_name = '~#~'  
select @engg_customer_name = null  
  
if @engg_datatype = '~#~'  
select @engg_datatype = null  
  
if @engg_from_length = -915  
select @engg_from_length = null  
  
if @engg_process_descr = '~#~'  
select @engg_process_descr = null  
  
if @engg_project_name = '~#~'  
select @engg_project_name = null  
  
if @engg_req_no = '~#~'  
select @engg_req_no = null  
  
if @engg_res_btsyn = '~#~'  
select @engg_res_btsyn = null  
  
if @engg_syn_usage = '~#~'  
select @engg_syn_usage = null  
  
if @engg_to_length = -915  
select @engg_to_length = null  
  
if @engg_tot_btsyn = '~#~'  
select @engg_tot_btsyn = null  
  
if @engg_ui_descr = '~#~'  
select @engg_ui_descr = null  
  
if @engg_unr_btsyn = '~#~'  
select @engg_unr_btsyn = null  
  
if @guid = '~#~'  
select @guid = null  
  
if @modeflag = '~#~'  
select @modeflag = null  
  
if @engg_mi_sample = '~#~'  
select @engg_mi_sample = null  
  
if @engg_si_sample = '~#~'  
select @engg_si_sample = null  
  
if @fprowno = -915  
select @fprowno = null  
  
--errors mapped  
select @fprowno  = isnull(@fprowno,0) + 1  

--  declare @engg_bt_name   engg_name  
declare @engg_base_req_no engg_name  
declare @cmp_name_tmp  engg_name  
--  declare @language_code  engg_name  
declare @proc_name_tmp  engg_name  
  
  
--code Modified for bugId : PNR2.0_12403  

--code modification for  PNR2.0_31051  starts 

if @modeflag = 'S'  
begin
select @fprowno  'fprowno_io' 
return  
end 
  
if @modeflag in ('I','X')  
begin  
select @fprowno  'fprowno_io' 
raiserror ('Cannot Insert Synonyms.',16,1)  
return  
end  

--code modification for  PNR2.0_31051 ends
  
select @proc_name_tmp = process_name  
from ep_ui_req_dtl(nolock)  
where customer_name = @engg_customer_name  
and  project_name = @engg_project_name  
and  req_no   = @engg_req_no  
and  process_descr = @engg_process_descr  
  
select @cmp_name_tmp = component_name  
from ep_ui_req_dtl(nolock)  
where customer_name = @engg_customer_name  
and  project_name = @engg_project_name  
and  req_no   = @engg_req_no  
and  process_name = @proc_name_tmp  
and  component_descr = @engg_component  
  
  
select @act_name = activity_name  
from ep_ui_req_dtl (nolock)  
where customer_name = @engg_customer_name  
and project_name = @engg_project_name  
and req_no  = @engg_req_no  
and process_name = @proc_name_tmp  
and component_name = @cmp_name_tmp  
and  activity_descr  = @engg_act_descr  
  
select @ui_name = ui_name  
from ep_ui_req_dtl (nolock)  
where customer_name = @engg_customer_name  
and project_name = @engg_project_name  
and req_no  = @engg_req_no  
and process_name = @proc_name_tmp  
and component_name = @cmp_name_tmp  
and  activity_name   = @act_name  
and ui_descr like @engg_ui_descr  
  
if isnull(@ui_name,'') = ''  
Begin  
select @engg_ui_descr  = replace(@engg_ui_descr,'[','%')  
select @engg_ui_descr  = replace(@engg_ui_descr,']','%')  
  
select @ui_name = ui_name  
from ep_ui_req_dtl (nolock)  
where customer_name = @engg_customer_name  
and project_name = @engg_project_name  
and req_no  = @engg_req_no  
and process_name = @proc_name_tmp  
and component_name = @cmp_name_tmp  
and  activity_name   = @act_name  
and ui_descr like @engg_ui_descr  
end  
  
if @engg_ui_descr  = 'all'  
select @ui_name = null  
  
if @engg_act_descr  = 'all'  
select @act_name = null  

--Code Commented for Defect ID : TECH-39534 Starts
-- code commentd by 11536 

	--declare @isglanceui				engg_flag,
	--		@tmp_datatype			engg_name,
	--		@tmp_btsynonymcaption	engg_desc

	--select @isglanceui = dbo.ngplf_get_isglanceui(@engg_customer_name, @engg_project_name, @cmp_name_tmp,@act_name, @ui_name) 

	--If ISNULL(@isglanceui,'') = 'y'
	--BEGIN

		--SELECT	@tmp_datatype			=	data_type,
		--		@tmp_btsynonymcaption	=	bt_synonym_caption
		--FROM	ep_component_glossary_mst (nolock)
		--where	customer_name	=	@engg_customer_name  
		--and		project_name	=	@engg_project_name  	
		--and		process_name	=	@proc_name_tmp  
		--and		component_name	=	@cmp_name_tmp 
		--and		bt_synonym_name	=	@engg_bs_btsyn_name	

		--If @modeflag <> 'D'
		--Begin 
			--IF EXISTS ( SELECT 'X'
			--				FROM	ep_component_glossary_mst (nolock)
			--				where	customer_name	=	@engg_customer_name  
			--				and		project_name	=	@engg_project_name  	
			--				and		process_name	=	@proc_name_tmp  
			--				and		component_name	=	@cmp_name_tmp 
			--				and		bt_synonym_name	=	@engg_bs_btsyn_name	
			--				and		bt_synonym_caption	<>	@engg_bs_spl_text	
			--				and		ISNULL(IsGlance,'')	=	'y'	)

			--				BEGIN
			--					RAISERROR ('BTSynonym Caption cannot be modified for the BTSynonym: "%s".  Since the caption: "%s" Created from Glance.',16,1,@engg_bs_btsyn_name,@tmp_btsynonymcaption)
			--					Return
			--				END

		--	IF EXISTS ( SELECT 'X'
		--					FROM	ep_component_glossary_mst (nolock)
		--					where	customer_name	=	@engg_customer_name  
		--					and		project_name	=	@engg_project_name  	
		--					and		process_name	=	@proc_name_tmp  
		--					and		component_name	=	@cmp_name_tmp 
		--					and		bt_synonym_name	=	@engg_bs_btsyn_name
		--					and		data_type		<>	@engg_bs_datatype
		--					and		ISNULL(IsGlance,'')	=	'y'	)

		--					BEGIN
		--						RAISERROR ('DataType mismatch for the BTSynonym: "%s". Since "%s" datatype mapped from Glance.',16,1,@engg_bs_btsyn_name,@tmp_datatype)
		--						Return
		--					END
		--END
--Code Commented for Defect ID : TECH-39534 Ends
		If @modeflag = 'D'
		Begin 
			IF EXISTS ( SELECT 'X'
							FROM	ep_component_glossary_mst (nolock)
							where	customer_name	=	@engg_customer_name  
							and		project_name	=	@engg_project_name  	
							and		process_name	=	@proc_name_tmp  
							and		component_name	=	@cmp_name_tmp 
							and		bt_synonym_name	=	@engg_bs_btsyn_name
							and		ISNULL(IsGlance,'')	=	'y'	)

							BEGIN
								RAISERROR ('Synonym cannot be deleted. Since it is created from Glance.',16,1)
								Return
							END
		END
	--END
--TECH-73996
	DECLARE @cnt_ctrlbtsyn		engg_seqno,
			@cnt_grdbtsyn		engg_seqno,
			@cnt_secbtsyn		engg_seqno,
			@cnt_pgbtsyn		engg_seqno,
			@btsynonymcaption	engg_name

	SELECT	@cnt_pgbtsyn	=	count(*)
	FROM	(	SELECT	page_bt_Synonym,ui_name
				FROM	ep_ui_page_dtl  WITH(NOLOCK)
				WHERE	customer_name		= @engg_customer_name  
				AND		project_name		= @engg_project_name  
				AND		page_bt_Synonym		= @engg_bs_btsyn_name
				GROUP BY ui_name,page_bt_Synonym ) d

	SELECT	@cnt_secbtsyn	=	count(*)
	FROM	(	SELECT	section_bt_Synonym,ui_name
				FROM	ep_ui_section_dtl  WITH(NOLOCK)
				WHERE	customer_name		= @engg_customer_name  
				AND		project_name		= @engg_project_name 
				AND		section_bt_Synonym	= @engg_bs_btsyn_name
				GROUP BY ui_name,section_bt_Synonym ) c

	SELECT	@cnt_ctrlbtsyn	=	count(*)
	FROM	(	SELECT	control_bt_Synonym,ui_name
				FROM	ep_ui_control_dtl  WITH(NOLOCK)
				WHERE	customer_name		= @engg_customer_name  
				AND		project_name		= @engg_project_name  
				AND		control_bt_Synonym	= @engg_bs_btsyn_name
				GROUP BY ui_name,control_bt_Synonym ) a
	
	SELECT	@cnt_grdbtsyn	=	count(*)
	FROM	(	SELECT	column_bt_Synonym,ui_name
				FROM	ep_ui_grid_dtl  WITH(NOLOCK)
				WHERE	customer_name		= @engg_customer_name  
				AND		project_name		= @engg_project_name
				AND		column_bt_Synonym	= @engg_bs_btsyn_name
				GROUP BY ui_name,column_bt_Synonym ) b
	
	--TECH-75230
	SELECT	@btsynonymcaption			=	bt_synonym_caption		
	FROM	ep_component_glossary_mst  WITH(NOLOCK)
	WHERE	customer_name			= @engg_customer_name  
	AND		project_name			= @engg_project_name 
	AND		process_name			<>@proc_name_tmp
	AND		component_name			<>@cmp_name_tmp
	AND		bt_synonym_name			= @engg_bs_btsyn_name
	--TECH-75230

		If @modeflag IN ( 'U','Y') AND (ISNULL(@engg_bs_spl_text_in,'') <> ISNULL(@btsynonymcaption,''))	--TECH-75230
			BEGIN
				IF @cnt_ctrlbtsyn	>	1	OR	@cnt_grdbtsyn	>	1	OR	@cnt_secbtsyn	>	1	OR @cnt_pgbtsyn	>	1
					BEGIN
						RAISERROR('Caption cannot be updated since selected Synonym Name is used in more than one User Interfaces at rowno: %i.',16,1,@fprowno)
						RETURN
					END
			END
--TECH-73996
  
-- Code modification for PNR2.0_23408 on 25-Sep-2009 by Gowrisankar M starts  
if @modeflag <> 'D'  
Begin  
  
if  (@engg_syn_usage = 'Task') and len(@engg_bs_spl_text) > 125  
begin  
exec  engg_error_sp  
'ep_glosry_sp_savebsml',4,   'Length Of Task Description cannot be greater than 125 at row <%1>',  
@ctxt_language,   @ctxt_ouinstance,@ctxt_service,  
@ctxt_user,          @fprowno,   '',  
'',                     '',    @m_errorid  output  
return  
end  
  
if  (@engg_syn_usage in ('Task Confirmation', 'Task Status Message', 'Task Processing Message')) and len(@engg_bs_spl_text) > 255  --Code Modified for PNR2.0_30869  
begin  
exec  engg_error_sp  
'ep_glosry_sp_savebsml',4,      'Length Of Task Confirmation Message / Task Status Message / Task Processing Message cannot be greater than 255 at row <%1>',   --Code modified for PNR2.0_30869  
@ctxt_language,   @ctxt_ouinstance,@ctxt_service,  
@ctxt_user,          @fprowno,   '',  
'',                     '',    @m_errorid  output  
return  
end  
-- Code modification for PNR2.0_23408 on 25-Sep-2009 by Gowrisankar M starts  
if  @engg_syn_usage not in ('Task Confirmation', 'Task Status Message', 'Task Processing Message','Task') --Code Modified for PNR2.0_30869  
begin  
-- code modified by shafina on 03-Dec-2004 for PREVIEWENG203ACC_000110 (Length Of the BT Synonym Caption Must not exceed 50 characters.)  
/*PNR2.0_13644*/  
--code Modified for bugId : PNR2.0_13940  
--Code Modified for bugId : PNR2.0_13947  
create table #ep_component_glossary_mst  
( bt_synonym_name varchar(60))  
  
-- Code modified for PNR2.0_20625; "and req_no = 'BASE'" has been included in all Preivew table where clauses  
  
insert  into #ep_component_glossary_mst  
(bt_synonym_name)  
select distinct component_name  
from ep_ui_mst(nolock)  
where customer_name   = @engg_customer_name  
and  project_name   = @engg_project_name  
and req_no   = 'BASE'  
and  process_name   = @proc_name_tmp  
and  component_name = @cmp_name_tmp  
and  component_name   = @engg_bs_btsyn_name  
union  
select distinct activity_name  
from ep_ui_mst(nolock)  
where customer_name   = @engg_customer_name  
and  project_name   = @engg_project_name  
and req_no   = 'BASE'  
and  process_name   = @proc_name_tmp  
and  component_name   = @cmp_name_tmp  
and  activity_name   = @engg_bs_btsyn_name  
union  
select distinct ui_name  
from ep_ui_mst(nolock)  
where customer_name   = @engg_customer_name  
and  project_name   = @engg_project_name  
and req_no   = 'BASE'  
and  process_name   = @proc_name_tmp  
and  component_name   = @cmp_name_tmp  
and  ui_name     = @engg_bs_btsyn_name  
union  
select control_bt_synonym  
from ep_ui_control_dtl  a(nolock),  
es_comp_ctrl_type_mst b(nolock)  
where a.customer_name   = @engg_customer_name  
and  a.project_name   = @engg_project_name  
and  a.req_no   = 'BASE'  
and  a.process_name   = @proc_name_tmp  
and  a.component_name  = @cmp_name_tmp  
and  a.control_bt_synonym = @engg_bs_btsyn_name  
and  a.customer_name   = b.customer_name  
and  a.project_name   = b.project_name  
and  a.req_no   = b.req_no  
and  a.process_name   = b.process_name  
and  a.component_name  = b.component_name  
and  a.control_type   = b.ctrl_type_name  
and  b.base_ctrl_type  <> 'label'  
union  
select column_bt_synonym  
from ep_ui_grid_dtl  a(nolock)--, -- Code modified by Gowrisankar M for PNR2.0_16449 on 10-Jan-2008  
--    es_comp_ctrl_type_mst b(nolock)  
where a.customer_name   = @engg_customer_name  
and  a.project_name   = @engg_project_name  
and  a.req_no   = 'BASE'  
and  a.process_name   = @proc_name_tmp  
and  a.component_name  = @cmp_name_tmp  
and  a.column_bt_synonym  = @engg_bs_btsyn_name  
-- Code added for Bug_id : PNR2.0_31581			Starts
union   
select hidden_view_bt_synonym  
from de_hidden_view a(nolock)  
where a.customer_name   = @engg_customer_name    
and  a.project_name   = @engg_project_name    
--and  a.req_no   = 'BASE'    
and  a.process_name   = @proc_name_tmp    
and  a.component_name  = @cmp_name_tmp    
and  a.control_bt_synonym  = @engg_bs_btsyn_name 
-- Code added for Bug_id : PNR2.0_31581			Ends 
  
if exists ( select 'x'  
from #ep_component_glossary_mst  
where bt_synonym_name = @engg_bs_btsyn_name)  
begin  
if len(@engg_bs_spl_text) > 120  -- Code modification for PNR2.0_23408 on 25-Sep-2009 by Gowrisankar M  
begin  
exec  engg_error_sp  
'ep_glosry_sp_savebsml',4,      'Length Of BT synonym Caption cannot be greater than 120 at row <%1>',  
@ctxt_language,   @ctxt_ouinstance,@ctxt_service,  
@ctxt_user,          @fprowno,   '',  
'',                     '',    @m_errorid  output  
return  
end  
end  
end  
End  -- Code modification for PNR2.0_23408 on 25-Sep-2009 by Gowrisankar M  
  
--  select @proc_name_tmp = process_name  
--  from ep_ui_req_dtl (nolock)  
--  where customer_name = @engg_customer_name  
--  and project_name = @engg_project_name  
--  and req_no  = @engg_req_no  
--  and process_descr = @engg_process_descr  
--  
--  select @cmp_name_tmp = component_name  
--  from ep_ui_req_dtl (nolock)  
--  where customer_name = @engg_customer_name  
--  and project_name = @engg_project_name  
--  and req_no  = @engg_req_no  
--  and process_name = @proc_name_tmp  
--  and component_descr = @engg_component  
--  
select @engg_base_req_no = 'BASE'  
  
-- Code modified by Mohideen on Jun 15, 2006 - Start  
if  @engg_syn_usage in ('Task Confirmation', 'Task Status Message', 'Task Processing Message','Task')  -- Code modification for PNR2.0_23408 on 25-Sep-2009 by Gowrisankar M --Code Modified for PNR2.0_30869  
begin  
if @modeflag in ('U','Y')  
begin  
if isnull(@engg_bs_spl_text, '') = ''   and  @engg_syn_usage  in ('Task')		-- code modified for  PNR2.0_31051
begin  
exec  engg_error_sp  
'ep_glosry_sp_savebsml',4,'BT synonym Caption cannot be null at row <%1>',  
@ctxt_language,  @ctxt_ouinstance, @ctxt_service,  
@ctxt_user,         @fprowno,   '',  
'',                     '',   @m_errorid  output  
return  
end  
  
if isnull(@engg_bs_refbtsyn_name, '') <> ''  
begin  
exec  engg_error_sp  
'ep_glosry_sp_savebsml',4,'For the Synonym usage "<%2>", Reference BT synonym should be blank at row : <%1>', -- Code modification for PNR2.0_23408 on 25-Sep-2009 by Gowrisankar M  
@ctxt_language,  @ctxt_ouinstance, @ctxt_service,  
@ctxt_user,         @fprowno,   @engg_syn_usage, -- Code modification for PNR2.0_23408 on 25-Sep-2009 by Gowrisankar M  
'',                     '',   @m_errorid  output  
return  
end  
  
if isnull(@engg_bs_datatype, '') <> ''  
begin  
exec  engg_error_sp  
'ep_glosry_sp_savebsml',4,      'For the Synonym usage "<%2>", Data Type should be blank at row : <%1>',-- Code modification for PNR2.0_23408 on 25-Sep-2009 by Gowrisankar M  
@ctxt_language,  @ctxt_ouinstance, @ctxt_service,  
@ctxt_user,         @fprowno,   @engg_syn_usage,-- Code modification for PNR2.0_23408 on 25-Sep-2009 by Gowrisankar M  
'',                     '',   @m_errorid  output  
return  
end  
  
if isnull(@engg_bs_length, -915) <> -915  
begin  
exec  engg_error_sp  
'ep_glosry_sp_savebsml',4,      'For the Synonym usage "<%2>", Length should be blank at row : <%1>',-- Code modification for PNR2.0_23408 on 25-Sep-2009 by Gowrisankar M  
@ctxt_language,  @ctxt_ouinstance, @ctxt_service,  
@ctxt_user,         @fprowno,   @engg_syn_usage,-- Code modification for PNR2.0_23408 on 25-Sep-2009 by Gowrisankar M  
'',                     '',   @m_errorid  output  
return  
end  
  
if isnull(@engg_bs_sdescr, '') <> ''  
begin  
exec  engg_error_sp  
'ep_glosry_sp_savebsml',4,      'For the Synonym usage "<%2>", Synonym Documentation should be blank at row : <%1>',-- Code modification for PNR2.0_23408 on 25-Sep-2009 by Gowrisankar M  
@ctxt_language,  @ctxt_ouinstance, @ctxt_service,  
@ctxt_user,         @fprowno,   @engg_syn_usage,-- Code modification for PNR2.0_23408 on 25-Sep-2009 by Gowrisankar M  
'',                     '',   @m_errorid output  
return  
end  
  
if isnull(@engg_si_sample, '') <> ''  
begin  
exec  engg_error_sp  
'ep_glosry_sp_savebsml',4,      'For the Synonym usage "<%2>", Single Instance Sample Data should be blank at row : <%1>',-- Code modification for PNR2.0_23408 on 25-Sep-2009 by Gowrisankar M  
@ctxt_language,  @ctxt_ouinstance, @ctxt_service,  
@ctxt_user,         @fprowno,   @engg_syn_usage,-- Code modification for PNR2.0_23408 on 25-Sep-2009 by Gowrisankar M  
'',                     '',   @m_errorid  output  
return  
end  
  
if isnull(@engg_mi_sample, '') <> ''  
begin  
exec  engg_error_sp  
'ep_glosry_sp_savebsml',4,      'For the Synonym usage "<%2>", Multiple Instance Sample Data should be blank at row : <%1>',-- Code modification for PNR2.0_23408 on 25-Sep-2009 by Gowrisankar M  
@ctxt_language,  @ctxt_ouinstance, @ctxt_service,  
@ctxt_user,         @fprowno,   @engg_syn_usage,-- Code modification for PNR2.0_23408 on 25-Sep-2009 by Gowrisankar M  
'',                     '',   @m_errorid  output  
return  
end  
  
select @langid   = quick_code  
from ep_language_met b (nolock)  
where quick_code_type  = 'language_code'  
and quick_code_value = 'English'  
  
if  @engg_syn_usage = 'Task Confirmation'  
begin  
update ep_action_mst  
set task_confirm_msg = @engg_bs_spl_text,  
modifiedby  = @ctxt_user,  
modifieddate  = getdate()  
where   customer_name = @engg_customer_name  
and   project_name = @engg_project_name  
and req_no = 'BASE'  
and process_name = @proc_name_tmp  
and component_name = @cmp_name_tmp  
-- Code modification for PNR2.0_23408 on 25-Sep-2009 by Gowrisankar M Starts  
--   and activity_name like isnull(@act_name, '%')  
--   and ui_name  like isnull(@ui_name, '%')  
-- Code modification for PNR2.0_23408 on 25-Sep-2009 by Gowrisankar M Ends  
and   task_name = @engg_bs_btsyn_name  
  
update ep_action_mst_lng_extn  
set task_confirm_msg = @engg_bs_spl_text,  
modifiedby  = @ctxt_user,  
modifieddate  = getdate()  
where   customer_name = @engg_customer_name  
and   project_name = @engg_project_name  
and req_no = 'BASE'  
and process_name = @proc_name_tmp  
and component_name = @cmp_name_tmp  
-- Code modification for PNR2.0_23408 on 25-Sep-2009 by Gowrisankar M Starts  
--   and activity_name like isnull(@act_name, '%')  
--   and ui_name  like isnull(@ui_name, '%')  
-- Code modification for PNR2.0_23408 on 25-Sep-2009 by Gowrisankar M Ends  
and   task_name = @engg_bs_btsyn_name  
and languageid = @langid  
end  
  
if  @engg_syn_usage = 'Task Status Message'  
begin  
update ep_action_mst  
set task_status_msg = @engg_bs_spl_text,  
modifiedby = @ctxt_user,  
modifieddate = getdate()  
where   customer_name = @engg_customer_name  
and   project_name = @engg_project_name  
and req_no = 'BASE'  
and process_name = @proc_name_tmp  
and component_name = @cmp_name_tmp  
-- Code modification for PNR2.0_23408 on 25-Sep-2009 by Gowrisankar M Starts  
--   and activity_name like isnull(@act_name, '%')  
--   and ui_name  like isnull(@ui_name, '%')  
-- Code modification for PNR2.0_23408 on 25-Sep-2009 by Gowrisankar M Ends  
and   task_name = @engg_bs_btsyn_name  
  
update ep_action_mst_lng_extn  
set task_status_msg = @engg_bs_spl_text,  
modifiedby = @ctxt_user,  
modifieddate = getdate()  
where   customer_name = @engg_customer_name  
and   project_name = @engg_project_name  
and req_no = 'BASE'  
and process_name = @proc_name_tmp  
and component_name = @cmp_name_tmp  
-- Code modification for PNR2.0_23408 on 25-Sep-2009 by Gowrisankar M Starts  
--   and activity_name like isnull(@act_name, '%')  
--   and ui_name  like isnull(@ui_name, '%')  
-- Code modification for PNR2.0_23408 on 25-Sep-2009 by Gowrisankar M Ends  
and   task_name = @engg_bs_btsyn_name  
and languageid = @langid  
end  
  
--Code Modification for PNR2.0_30869 starts  
  
  
if  @engg_syn_usage = 'Task Processing Message'  
begin  
update ep_action_mst  
set task_process_msg = @engg_bs_spl_text,  
modifiedby = @ctxt_user,  
modifieddate = getdate()  
where   customer_name = @engg_customer_name  
and   project_name = @engg_project_name  
and req_no = 'BASE'  
and process_name = @proc_name_tmp  
and component_name = @cmp_name_tmp  
and   task_name = @engg_bs_btsyn_name  
  
update ep_action_mst_lng_extn  
set task_process_msg = @engg_bs_spl_text,  
modifiedby = @ctxt_user,  
modifieddate = getdate()  
where   customer_name = @engg_customer_name  
and   project_name = @engg_project_name  
and req_no = 'BASE'  
and process_name = @proc_name_tmp  
and component_name = @cmp_name_tmp  
and   task_name = @engg_bs_btsyn_name  
and languageid = @langid  
end  
  
--Code Modification for PNR2.0_30869 ends  
  
  
-- Code addition for PNR2.0_23408 on 25-Sep-2009 by Gowrisankar M Starts  
if  @engg_syn_usage = 'Task'  
begin  
update ep_action_mst  
set task_descr = @engg_bs_spl_text,  
modifiedby = @ctxt_user,  
modifieddate = getdate()  
where   customer_name = @engg_customer_name  
and   project_name = @engg_project_name  
and req_no = 'BASE'  
and process_name = @proc_name_tmp  
and component_name = @cmp_name_tmp  
and   task_name = @engg_bs_btsyn_name  
  
update ep_action_mst_lng_extn  
set task_descr = @engg_bs_spl_text,  
modifiedby = @ctxt_user,  
modifieddate = getdate()  
where   customer_name = @engg_customer_name  
and   project_name = @engg_project_name  
and req_no = 'BASE'  
and process_name = @proc_name_tmp  
and component_name = @cmp_name_tmp  
and   task_name = @engg_bs_btsyn_name  
and languageid = @langid  
end  
-- Code addition for PNR2.0_23408 on 25-Sep-2009 by Gowrisankar M Starts  
  
insert into ep_action_mst_lng_extn  
(customer_name,  project_name,  req_no,  process_name, component_name,  activity_name,  
ui_name,  page_bt_synonym, task_name,  task_descr, task_seq,  task_pattern,  
languageid,  timestamp,  createdby, createddate, modifiedby,  modifieddate,  
primary_control_bts,  task_sysid,   ui_sysid, task_type, task_confirm_msg, task_status_msg, task_process_msg)   --Code modified for PNR2.0_30869  
select a.customer_name, a.project_name,  a.req_no, a.process_name, a.component_name, a.activity_name,  
a.ui_name,  a.page_bt_synonym,  a.task_name,  convert(varchar(3),b.quick_code) + '_'+ a.task_descr, a.task_seq,  a.task_pattern,  
b.quick_code,  a.timestamp,  a.createdby, a.createddate, a.modifiedby,  a.modifieddate,  
a.primary_control_bts, a.task_sysid,   a.ui_sysid, a.task_type, convert(varchar(3),b.quick_code) + '_'+ a.task_confirm_msg,  
convert(varchar(3),b.quick_code) + '_'+ a.task_status_msg, convert(varchar(3),b.quick_code) + '_'+ a.task_process_msg -- Code modified for PNR2.0_13413 on 27-Apr-2007   --Code modified for PNR2.0_30869  
from ep_action_mst_lng_extn a (nolock),  
ep_language_met b (nolock)  
where   a.customer_name  = @engg_customer_name  
and   a.project_name  = @engg_project_name  
and a.req_no = 'BASE'  
and a.process_name  = @proc_name_tmp  
and a.component_name = @cmp_name_tmp  
-- Code modification for PNR2.0_23408 on 25-Sep-2009 by Gowrisankar M Starts  
-- and a.activity_name  like isnull(@act_name, '%')  
-- and a.ui_name  like isnull(@ui_name, '%')  
-- Code modification for PNR2.0_23408 on 25-Sep-2009 by Gowrisankar M Ends  
and   a.task_name  = @engg_bs_btsyn_name  
and a.languageid  = @langid  
and b.quick_code_type  = 'language_code'  
and  b.quick_code <> 1   -- Code modified for PNR2.0_13413 on 27-Apr-2007  
and not  
exists (select 'x'  
from ep_action_mst_lng_extn (nolock)  
where   customer_name = a.customer_name  
and   project_name = a.project_name  
and   req_no  = a.req_no  
and process_name = a.process_name  
and component_name = a.component_name  
and   activity_name = a.activity_name  
and   ui_name  = a.ui_name  
and   page_bt_synonym = a.page_bt_synonym  
and   task_name = a.task_name  
and languageid  = b.quick_code)  
	end  
	end  
else  
begin  
-- Code modified by Mohideen on Jun 15, 2006 - End  
if  @engg_bs_refbtsyn_name  is null  
begin  
-- code modified by shafina on 27-feb-2004  
if @modeflag in ('U','Y')  
begin  
-- code modified by shafina on 13-feb-2004 for caption null check  
if @engg_bs_spl_text is null  
begin  
exec  engg_error_sp  
'ep_glosry_sp_savebsml',4,      'BT synonym Caption cannot be null at row <%1>',  
@ctxt_language,   @ctxt_ouinstance,@ctxt_service,  
@ctxt_user,          @fprowno,   '',  
'',                     '',    @m_errorid  output  
return  
end  
-- code added for BugID :: PNR2.0_15013  
if  @engg_bs_datatype = 'Integer'  
begin  
if   @engg_bs_length <= 0  
BEGIN  
EXEC engg_error_sp  
'ep_glosry_sp_savebsml', 1, 'BT length should be positive and nonzero in Row No "<%1>"',  
@ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user,  
@fprowno, '', '', '', @m_errorid  
RETURN  
END  
end  
  
--if (@engg_bs_datatype = 'Integer') and (@engg_bs_length > 4)  
--BEGIN  
--EXEC engg_error_sp  
--'ep_glosry_sp_savebsml', 1, 'Length cannot be greater than 4 for Integer datatype in Row No "<%1>"',  
--@ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user,  
--@fprowno, '', '', '', @m_errorid  
--RETURN  
--END  
-- code added for BugID :: PNR2.0_15013  
if (@engg_bs_length is  null  or @engg_bs_length  <= 0)  
and @engg_bs_datatype in ('Char' , 'Numeric')  
begin  
exec  engg_error_sp  
'ep_glosry_sp_savebsml',4,      'BT  length  cannot be Null , negative or zero at row no. <%1> ',  
@ctxt_language,   @ctxt_ouinstance,@ctxt_service,  
@ctxt_user,          @fprowno,   '',  
'',                     '',    @m_errorid  output  
return  
end  
end  
end     ---  Check  Reference BT Synonym  for null ends here  
  
---  Checking if Reference BT Synonym is not null  
if  @engg_bs_refbtsyn_name  is not null  
begin  
---   Raise error  if Reference BT Synonym is not available in the  
---   Glossary master  
if not exists  (  
select  'x'  
from  ep_component_glossary_mst(nolock)  
where customer_name    = @engg_customer_name  
and  project_name       = @engg_project_name  
and req_no = 'BASE'  
and  process_name    = @proc_name_tmp  
and  component_name    = @cmp_name_tmp  
and  bt_synonym_name    = @engg_bs_refbtsyn_name  
)  
begin  
exec  engg_error_sp  
'ep_glosry_sp_savebsml',4,    'Reference bt synonym at row <%1> is not available in Glossary for this Component.',  -- error msg modified by Gowrisankar in 15-Sep-2006  
@ctxt_language,   @ctxt_ouinstance,@ctxt_service,  
@ctxt_user,          @fprowno,   '',  
'',                     '',    @m_errorid  output  
return  
end  
  
select  @engg_bs_datatype   = data_type,  
@engg_bs_length     = length  
from ep_component_glossary_mst(nolock)  
where customer_name      = @engg_customer_name  
and   project_name        = @engg_project_name  
and req_no = 'BASE'  
and  process_name     = @proc_name_tmp  
and  component_name     = @cmp_name_tmp  
and   bt_synonym_name     = @engg_bs_refbtsyn_name  
  
if @engg_bs_spl_text is null  
begin  
select @engg_bs_spl_text   = bt_synonym_caption  
from ep_component_glossary_mst(nolock)  
where customer_name      = @engg_customer_name  
and   project_name        = @engg_project_name  
and req_no = 'BASE'  
and  process_name     = @proc_name_tmp  
and  component_name     = @cmp_name_tmp  
and   bt_synonym_name     = @engg_bs_refbtsyn_name  
end  
  
if @engg_bs_sdescr is null  
begin  
select @engg_bs_sdescr    = bt_synonym_doc  
from ep_component_glossary_mst(nolock)  
where customer_name      = @engg_customer_name  
and   project_name        = @engg_project_name  
and req_no = 'BASE'  
and  process_name     = @proc_name_tmp  
and  component_name     = @cmp_name_tmp  
and   bt_synonym_name     = @engg_bs_refbtsyn_name  
end  
  
-- code commented by shafina on 20-April-2004 for PREVIEWENG203ACC_000042  
-- code added for BugID :: PNR2.0_15013  
if  @engg_bs_datatype = 'Integer'  
begin  
if   @engg_bs_length <= 0  
BEGIN  
EXEC engg_error_sp  
'ep_glosry_sp_savebsml', 1, 'BT length should be positive and nonzero in Row No "<%1>"',  
@ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user,  
@fprowno, '', '', '', @m_errorid  
RETURN  
END  
end  
if (@engg_bs_datatype = 'Integer') and (@engg_bs_length > 4)  
BEGIN  
EXEC engg_error_sp  
'ep_glosry_sp_savebsml', 1, 'Length cannot be greater than 4 for Integer datatype in Row No "<%1>"',  
@ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user,  
@fprowno, '', '', '', @m_errorid  
RETURN  
END  
-- code added for BugID :: PNR2.0_15013  
if  (@engg_bs_length  <= 0 or @engg_bs_length  is null)  
and @engg_bs_datatype in ('Char' , 'Numeric')  
begin  
exec  engg_error_sp  
'ep_glosry_sp_savebsml',4,      'BT  length  cannot be Null , negative or zero at row no. <%1> ',  
@ctxt_language,   @ctxt_ouinstance,@ctxt_service,  
@ctxt_user,          @fprowno,   '',  
'',                     '',    @m_errorid  output  
return  
end  
  
if @engg_bs_spl_text is null    ---  
begin  
exec  engg_error_sp  
'ep_glosry_sp_savebsml',4,      'Caption must be Entered  at  row <%1>',  
@ctxt_language,   @ctxt_ouinstance,@ctxt_service,  
@ctxt_user,          @fprowno,   '',  
'',  '',    @m_errorid  output  
return  
end  
end  


---------------------------------------------------------------------------------------  
-- Checking the existence of BT synonym in  the Glossary  
---------------------------------------------------------------------------------------  
if @modeflag <> 'D'  
begin  

if   exists (  
select  'x'  
from  ep_component_glossary_mst (nolock)  
where   customer_name   = @engg_customer_name  
and   project_name       = @engg_project_name  
and req_no = 'BASE'  
and process_name     = @proc_name_tmp  
and component_name     = @cmp_name_tmp  
and   bt_synonym_name    = @engg_bs_btsyn_name  
)  
begin  
if (@engg_bs_datatype = 'Integer') and (@engg_bs_length is null ) -- PNR2.0_15013  
select @engg_bs_length = 4  
  
if @engg_bs_datatype = 'Date'  
  
--code added by kiruthika for bugid:PNR2.0_9568  
--   select @engg_bs_length = 10  
select @engg_bs_length = 11  
--code added by kiruthika  
--code added by kiruthika  
if @engg_bs_datatype = 'date-time'  
select @engg_bs_length = 25  
--code ends  
--code added by kiruthika for bug id:PNR2.0_4926  
if @engg_bs_datatype = 'time'  
select @engg_bs_length = 11  
--code ends  
  
-- updates  the Glossary master if BT synonym exist  
--code added by Sangeetha L for the bug id : Platform_2.0.3.X_265  
--bug Descr :I have generated a service with a parameter "Name".  
--The service got generated without any errors.But,when I tried to change the flow direction ,It is throwing an error  
--code commented by kiruthika for bug id:PNR2.0_6778  
--  IF LEN(LTRIM(RTRIM(@engg_bs_btsyn_name))) > 0  
--  BEGIN  
--   IF EXISTS (SELECT 'X' FROM DE_META_VBKEYWORDS (NOLOCK)  
--      WHERE  KEYWORD = @engg_bs_btsyn_name  
--     )  
--   BEGIN  
--    -- modified by Shriram V on 23/11/05 for Bug Id :PNR2.0_4571  
--  
--    EXEC ENGG_ERROR_SP  'ep_glosry_sp_savebsml',102,'KEYWORD -<%1>- NOT ALLOWED AS A PARAMETER at Row No <%2>',  
--       @CTXT_LANGUAGE, @CTXT_OUINSTANCE,@CTXT_SERVICE,@CTXT_USER,  
--       @engg_bs_btsyn_name ,@fprowno  , NULL , NULL , @m_errorid OUT  
--  
--    IF @m_errorid <> 0  
--     RETURN  
--   END  
--  END  
--code commented by kiruthika for bug id:PNR2.0_6778  
  

update  ep_component_glossary_mst  
set    ref_bt_synonym_name   = @engg_bs_refbtsyn_name,  
data_type             = @engg_bs_datatype,  
length                = @engg_bs_length,  
bt_synonym_caption    = @engg_bs_spl_text,  
bt_synonym_doc        = @engg_bs_sdescr,  
synonym_status    = 'R',  
singleinst_sample_data = isnull(@engg_si_sample,''),  
multiinst_sample_data = isnull(@engg_mi_sample,''),  
-- code added by shafina on 07-Sep-2004 for PREVIEWENG203ACC_000098 (Modified Date must be updated.)  
modifiedby    = @ctxt_user,  
modifieddate   = getdate()  
where   customer_name        = @engg_customer_name  
and   project_name         = @engg_project_name  
and  req_no = 'BASE'  
and  process_name      = @proc_name_tmp  
and  component_name      = @cmp_name_tmp  
and   bt_synonym_name      = @engg_bs_btsyn_name  
-- code added by shafina on 21-feb-2004  

-- Code added for Bug_ID : PNR2.0_31581					Starts
if exists (select 'x' from de_hidden_view nolock
where customer_name        = @engg_customer_name  
and   project_name         = @engg_project_name  
and  process_name      = @proc_name_tmp  
and  component_name      = @cmp_name_tmp 
and  hidden_view_bt_synonym = @engg_bs_btsyn_name)
begin 
update  ep_component_glossary_mst  
set    ref_bt_synonym_name   = @engg_bs_refbtsyn_name,  
data_type             = @engg_bs_datatype,  
length                = @engg_bs_length,  
bt_synonym_caption    = @engg_bs_spl_text,  
bt_synonym_doc        = @engg_bs_sdescr,  
synonym_status    = 'R',  
singleinst_sample_data = isnull(@engg_si_sample,''),  
multiinst_sample_data = isnull(@engg_mi_sample,''),  
modifiedby    = @ctxt_user,  
modifieddate   = getdate()  
where   customer_name        = @engg_customer_name  
and   project_name         = @engg_project_name  
and  process_name      = @proc_name_tmp  
and  component_name      = @cmp_name_tmp  
and   bt_synonym_name      = @engg_bs_btsyn_name  


--update  ep_component_glossary_mst_lng_extn  
--set    ref_bt_synonym_name   = @engg_bs_refbtsyn_name,  
--data_type             = @engg_bs_datatype,  
--length                = @engg_bs_length,  
--bt_synonym_caption    = @engg_bs_spl_text,  
--bt_synonym_doc        = @engg_bs_sdescr,  
--synonym_status    = 'R',  
--singleinst_sample_data = isnull(@engg_si_sample,''),  
--multiinst_sample_data = isnull(@engg_mi_sample,''),  
--modifiedby    = @ctxt_user,  
--modifieddate   = getdate()  
--where   customer_name        = @engg_customer_name  
--and   project_name         = @engg_project_name  
--and  process_name      = @proc_name_tmp  
--and  component_name      = @cmp_name_tmp  
--and   bt_synonym_name      = @engg_bs_btsyn_name  
--and  languageid    = @langid --cast(@langid as int)  
end
-- Code added for Bug_ID : PNR2.0_31581				Ends

  
-- code modified by Ganesh for the callid :: PNR2.0_3386 on 01/08/05  
select @langid    = quick_code  
from ep_language_met b (nolock)  
where quick_code_type  = 'language_code'  
and  quick_code_value = 'English'  
  
--update  ep_component_glossary_mst_lng_extn  
--set    ref_bt_synonym_name   = @engg_bs_refbtsyn_name,  
--data_type             = @engg_bs_datatype,  
--length                = @engg_bs_length,  
--bt_synonym_caption    = @engg_bs_spl_text,  
--bt_synonym_doc        = @engg_bs_sdescr,  
--synonym_status    = 'R',  
--singleinst_sample_data = isnull(@engg_si_sample,''),  
--multiinst_sample_data = isnull(@engg_mi_sample,''),  
--modifiedby    = @ctxt_user,  
--modifieddate   = getdate()  
--where   customer_name        = @engg_customer_name  
--and   project_name         = @engg_project_name  
--and  req_no = 'BASE'  
--and  process_name      = @proc_name_tmp  
--and  component_name      = @cmp_name_tmp  
--and   bt_synonym_name      = @engg_bs_btsyn_name  
--and  languageid    = @langid --cast(@langid as int)  
if exists (Select 'x' from 
			ep_ui_columngroup (nolock)
			where   customer_name   = @engg_customer_name
			and   project_name      = @engg_project_name
			and  process_name		= @proc_name_tmp
			and  component_name     = @cmp_name_tmp
			and   Group_name		 = @engg_bs_btsyn_name )
Begin
	Update  ep_ui_columngroup
	set		Group_caption		= @engg_bs_spl_text
	where   customer_name		= @engg_customer_name
	and		project_name		= @engg_project_name
	and		process_name		= @proc_name_tmp
	and		component_name		= @cmp_name_tmp
	and		Group_name			= @engg_bs_btsyn_name 
End		
if exists (Select 'x' from 
			ep_phone_columngroup (nolock)
			where   customer_name   = @engg_customer_name
			and   project_name      = @engg_project_name
			and  process_name		= @proc_name_tmp
			and  component_name     = @cmp_name_tmp
			and   Group_name		 = @engg_bs_btsyn_name )
Begin
	Update  ep_phone_columngroup
	set		Group_caption		= @engg_bs_spl_text
	where   customer_name		= @engg_customer_name
	and		project_name		= @engg_project_name
	and		process_name		= @proc_name_tmp
	and		component_name		= @cmp_name_tmp
	and		Group_name			= @engg_bs_btsyn_name 
End	
if exists (Select 'x' from 
			ep_tablet_columngroup (nolock)
			where   customer_name   = @engg_customer_name
			and   project_name      = @engg_project_name
			and  process_name		= @proc_name_tmp
			and  component_name     = @cmp_name_tmp
			and   Group_name		 = @engg_bs_btsyn_name )
Begin
	Update  ep_tablet_columngroup
	set		Group_caption		= @engg_bs_spl_text
	where   customer_name		= @engg_customer_name
	and		project_name		= @engg_project_name
	and		process_name		= @proc_name_tmp
	and		component_name		= @cmp_name_tmp
	and		Group_name			= @engg_bs_btsyn_name 
End		
  
  
-- code modified by shafina on 29-Oct-2004 for DEENG203ACC_000113(When a btsynonym's length and datatype is updated , those btsynonyms referring this must also get updated.)  
-- code commented by shafina on 24-Nov-2004 to rollback the fix given for DEENG203ACC_000113  
/*   update  b  
set    b.data_type    = a.data_type,  
b.length                = a.length,  
modifiedby    = @ctxt_user,  
modifieddate   = getdate()  
from ep_component_glossary_mst a (nolock) ,  
ep_component_glossary_mst b (nolock)  
where   a.customer_name         = rtrim(@engg_customer_name)  
and   a.project_name     = rtrim(@engg_project_name)  
and  a.process_name      = rtrim(@proc_name_tmp)  
and  a.component_name     = rtrim(@cmp_name_tmp)  
and   a.bt_synonym_name       = rtrim(@engg_bs_btsyn_name)  
and  a.customer_name         = b.customer_name  
and   a.project_name          = b.project_name  
and  a.process_name      = b.process_name  
and  a.component_name     = b.component_name  
and  a.bt_synonym_name  = b.ref_bt_synonym_name  
  
update  b  
set    b.data_type    = a.data_type, 
b.length                = a.length,  
modifiedby    = @ctxt_user,  
modifieddate   = getdate()  
from ep_component_glossary_mst_lng_extn a (nolock) ,  
ep_component_glossary_mst_lng_extn b (nolock)  
where   a.customer_name         = rtrim(@engg_customer_name)  
and   a.project_name          = rtrim(@engg_project_name)  
and  a.process_name      = rtrim(@proc_name_tmp)  
and  a.component_name     = rtrim(@cmp_name_tmp)  
and   a.bt_synonym_name       = rtrim(@engg_bs_btsyn_name)  
and  a.customer_name         = b.customer_name  
and   a.project_name          = b.project_name  
and  a.process_name      = b.process_name  
and  a.component_name     = b.component_name  
and  a.bt_synonym_name  = b.ref_bt_synonym_name*/  

end  
end  
end  
--Code added for the bugID:PLF2.0_01716	 starts
If  exists (select '*' from  sysobjects (nolock)
where name  =   'de_customer_space'
and  type   = 'U')
begin 

	if exists (select 'x'
			   from  de_fw_req_lang_bterm_synonym(nolock)
			   where customer_name   = @engg_customer_name
				and  project_name    = @engg_project_name
				and  process_name    = @proc_name_tmp
				and  component_name  = @cmp_name_tmp
				and  btsynonym       = @engg_bs_btsyn_name
				and  langid			 = @langid
				and  shortpltext     <> @engg_bs_spl_text)
	begin
				update  de_fw_req_lang_bterm_synonym
				set    longpltext=@engg_bs_spl_text,
					   shortpltext=@engg_bs_spl_text,  
					   shortdesc=@engg_bs_spl_text,   
					   longdesc=@engg_bs_spl_text
			   where customer_name   = @engg_customer_name
				and  project_name    = @engg_project_name
				and  process_name    = @proc_name_tmp
				and  component_name  = @cmp_name_tmp
				and  btsynonym       = @engg_bs_btsyn_name
				and  langid			 = @langid
				and  shortpltext     <> @engg_bs_spl_text
	
	end

end 
--Code added for the bugID:PLF2.0_01716	 starts

	-- 12545
	Declare @clientid		engg_name,  -- need to get clarification
			@workstationid	engg_name,
			@recentdownload	engg_date

	--set		@clientid			= '%'+ isnull(@clientid,'') +'%'
	--set		@desktopid			= '%'+ isnull(@desktopid,'') +'%'

	--select	@recentdownload = recentdownloaddate
	--from	ngplf_glossary_api_check (nolock)
	--where	clientid		=  @clientid
	--and     workstationid	=  @workstationid
	--and		customerID	=  @engg_customer_name
	--and		projectID		=  @engg_project_name
	--and		componentname   =  @cmp_name_tmp
	--and		languageid		=  @langid

	---- NGPLF Changes Starts
	--if	@recentdownload < getdate()
	--begin
	--	Update	ngplf_glossary_api_check 
	--	set statusflag			=	'Y',
	--		ModifiedBy			=	@ctxt_user,
	--		ModifiedDate		=	getdate()
	--	where	clientid		=  @clientid
	--	and     workstationid	=  @workstationid
	--	and		customerID		=  @engg_customer_name
	--	and		projectID		=  @engg_project_name
	--	and		componentname   =  @cmp_name_tmp
	--	and		languageid		=  @langid
	--end

--Code Added for Defect ID : TECH-39534 Starts
	--Code added by 11536 for NGPLF glossary 

	IF @modeflag NOT IN	('S','D')
	BEGIN	

			DECLARE		@ctxt_role				NGPLF_NAME

			IF EXISTS ( SELECT 'X'
							FROM	ngplf_wr_glossary (nolock)
							WHERE	CustomerID			=	@engg_customer_name  
							AND		ProjectID			=	@engg_project_name  	
							AND		ProcessName			=	@proc_name_tmp  
							AND		componentname		=	@cmp_name_tmp 
							AND		BTSynonymName		=	@engg_bs_btsyn_name	
							AND		( btsynonymcaption	<>	@engg_bs_spl_text OR DataType	<>	@engg_bs_datatype_in OR DataTypeLength	=	@engg_bs_length_in	)
							)
							BEGIN
								IF EXISTS ( SELECT 'X'
											FROM	ngplf_wr_page (nolock)
											WHERE	CustomerID			=	@engg_customer_name  
											AND		ProjectID			=	@engg_project_name  	
											AND		ProcessName			=	@proc_name_tmp  
											AND		componentname		=	@cmp_name_tmp 
											AND		PageName			=	@engg_bs_btsyn_name
											UNION
											 SELECT 'X'
											FROM	ngplf_wr_page (nolock)
											WHERE	CustomerID			=	@engg_customer_name  
											AND		ProjectID			=	@engg_project_name  	
											AND		ProcessName			=	@proc_name_tmp  
											AND		componentname		=	@cmp_name_tmp 
											AND		BTSynonymName		=	@engg_bs_btsyn_name	
											UNION
											 SELECT 'X'
											FROM	ngplf_wr_section (nolock)
											WHERE	CustomerID			=	@engg_customer_name  
											AND		ProjectID			=	@engg_project_name  	
											AND		ProcessName			=	@proc_name_tmp  
											AND		componentname		=	@cmp_name_tmp 
											AND		SectionName			=	@engg_bs_btsyn_name	
											UNION
											 SELECT 'X'
											FROM	ngplf_wr_section (nolock)
											WHERE	CustomerID			=	@engg_customer_name  
											AND		ProjectID			=	@engg_project_name  	
											AND		ProcessName			=	@proc_name_tmp  
											AND		componentname		=	@cmp_name_tmp 
											AND		BTSynonymName		=	@engg_bs_btsyn_name	
										  )
										BEGIN
											EXEC ngplf_page_sec_glossary_update		
													@ctxt_language,			@ctxt_ouinstance,		@ctxt_user,				@ctxt_role,								
													@engg_customer_name,	@engg_project_name,		@proc_name_tmp,			@cmp_name_tmp,			
													@engg_req_no,			@engg_bs_btsyn_name,	@engg_bs_spl_text,		@engg_bs_datatype_in,
													@engg_bs_length_in
										END
										ELSE
										BEGIN
											UPDATE ngplf_wr_glossary
											SET		BTSynonymCaption	=	@engg_bs_spl_text,
													DataType			=	@engg_bs_datatype_in,
													DataTypeLength		=	@engg_bs_length_in,
													ModifiedBy			=	@ctxt_user_in,
													ModifiedDate		=	GETDATE()
											WHERE	CustomerID			=	@engg_customer_name  
											AND		ProjectID			=	@engg_project_name  	
											AND		ProcessName			=	@proc_name_tmp  
											AND		componentname		=	@cmp_name_tmp 
											AND		BTSynonymName		=	@engg_bs_btsyn_name	

											UPDATE ngplf_wr_glossary_local_info
											SET		BTSynonymCaption	=	@engg_bs_spl_text,
													ModifiedBy			=	@ctxt_user_in,
													ModifiedDate		=	GETDATE()
											WHERE	CustomerID			=	@engg_customer_name  
											AND		ProjectID			=	@engg_project_name  	
											AND		ProcessName			=	@proc_name_tmp  
											AND		componentname		=	@cmp_name_tmp 
											AND		BTSynonymName		=	@engg_bs_btsyn_name	
											--code added for defectid:TECH-49351 starts
											IF EXISTS (SELECT 'x' 
													   FROM de_glossary(nolock)
													   WHERE	Customer_name		=	@engg_customer_name  
														AND		Project_name		=	@engg_project_name  	
														AND		Process_Name		=	@proc_name_tmp  
														AND		component_name		=	@cmp_name_tmp 
														AND		BT_Synonym_Name		=	@engg_bs_btsyn_name	)
											BEGIN
												UPDATE de_glossary
												SET		BT_Synonym_Caption	=	@engg_bs_spl_text,
														ModifiedBy			=	@ctxt_user_in,
														ModifiedDate		=	GETDATE()
												WHERE	Customer_name		=	@engg_customer_name  
												AND		Project_name		=	@engg_project_name  	
												AND		Process_Name		=	@proc_name_tmp  
												AND		component_name		=	@cmp_name_tmp 
												AND		BT_Synonym_Name		=	@engg_bs_btsyn_name	
											END

											UPDATE eprad
											SET    eprad.button_caption = @engg_bs_spl_text
											FROM   ep_radio_button_dtl eprad(NOLOCK),
												   ngplf_wr_enumerated rad(NOLOCK),
												   ngplf_wr_control    ctrl(NOLOCK)
											WHERE   rad.customerid				=	@engg_customer_name  
											AND		rad.projectid				=	@engg_project_name  	
											AND		rad.processname				=	@proc_name_tmp  
											AND		rad.componentname			=	@cmp_name_tmp
											AND     rad.enumbtsynonym			=   @engg_bs_btsyn_name
											AND		EnumeratedType				=	'Radio'
											AND		rad.CustomerID				=	ctrl.CustomerID
											AND		rad.ProjectID				=	ctrl.ProjectID
											AND		rad.processname				=	ctrl.processname
											AND		rad.ComponentName			=	ctrl.ComponentName
											AND		rad.activityname			=	ctrl.activityname
											AND		rad.uiname					=	ctrl.uiname
											AND		rad.pagename				=	ctrl.PageName
											AND		rad.sectionname				=	ctrl.SectionName
											AND		rad.controlname				=	ctrl.ControlName
											AND		rad.viewname				=	ctrl.ViewName

											AND		ctrl.CustomerID				=	eprad.customer_name
											AND		ctrl.ProjectID				=	eprad.project_name
											AND		ctrl.processname			=	eprad.process_name
											AND		ctrl.ComponentName			=	eprad.component_name
											AND		ctrl.activityname			=	eprad.activity_name
											AND		ctrl.uiname					=	eprad.ui_name
											AND		ctrl.PageName				=	eprad.page_bt_synonym
											AND		ctrl.SectionName			=	eprad.section_bt_synonym
											AND		ctrl.BTSynonymName			=	eprad.control_bt_synonym 
											AND		rad.customerid				=	eprad.customer_name
											AND		rad.projectid				=	eprad.project_name
											AND		rad.processname				=	eprad.process_name
											AND		rad.componentname			=	eprad.component_name
											AND		rad.activityname			=	eprad.activity_name
											AND		rad.uiname					=	eprad.ui_name
											AND		rad.PageName				=	eprad.page_bt_synonym
											AND		rad.SectionName				=	eprad.section_bt_synonym
											AND		rad.enumeratedcode			=	eprad.button_code

											UPDATE eprad
											SET    eprad.button_caption = @engg_bs_spl_text
											FROM   ep_radio_button_dtl_lng_extn eprad(NOLOCK),
												   ngplf_wr_enumerated rad(NOLOCK),
												   ngplf_wr_control    ctrl(NOLOCK)
											WHERE   rad.customerid				=	@engg_customer_name  
											AND		rad.projectid				=	@engg_project_name  	
											AND		rad.processname				=	@proc_name_tmp  
											AND		rad.componentname			=	@cmp_name_tmp
											AND     rad.enumbtsynonym			=   @engg_bs_btsyn_name
											AND		EnumeratedType				=	'Radio'
											AND		rad.CustomerID				=	ctrl.CustomerID
											AND		rad.ProjectID				=	ctrl.ProjectID
											AND		rad.processname				=	ctrl.processname
											AND		rad.ComponentName			=	ctrl.ComponentName
											AND		rad.activityname			=	ctrl.activityname
											AND		rad.uiname					=	ctrl.uiname
											AND		rad.pagename				=	ctrl.PageName
											AND		rad.sectionname				=	ctrl.SectionName
											AND		rad.controlname				=	ctrl.ControlName
											AND		rad.viewname				=	ctrl.ViewName

											AND		ctrl.CustomerID				=	eprad.customer_name
											AND		ctrl.ProjectID				=	eprad.project_name
											AND		ctrl.processname			=	eprad.process_name
											AND		ctrl.ComponentName			=	eprad.component_name
											AND		ctrl.activityname			=	eprad.activity_name
											AND		ctrl.uiname					=	eprad.ui_name
											AND		ctrl.PageName				=	eprad.page_bt_synonym
											AND		ctrl.SectionName			=	eprad.section_bt_synonym
											AND		ctrl.BTSynonymName			=	eprad.control_bt_synonym 
											AND		rad.customerid				=	eprad.customer_name
											AND		rad.projectid				=	eprad.project_name
											AND		rad.processname				=	eprad.process_name
											AND		rad.componentname			=	eprad.component_name
											AND		rad.activityname			=	eprad.activity_name
											AND		rad.uiname					=	eprad.ui_name
											AND		rad.PageName				=	eprad.page_bt_synonym
											AND		rad.SectionName				=	eprad.section_bt_synonym
											AND		rad.enumeratedcode			=	eprad.button_code
											AND     eprad.languageid            =   @langid
											
											--code added for defectid:TECH-49351 ends
										END
							END
	END
--Code Added for Defect ID : TECH-39534 Ends
	-- NGPLF Changes ends

select @fprowno  'fprowno_io'  /* DOTNET Migration Tool Changes */  
  
--output parameters  
-- select  null     'fprowno_io' /* DOTNET Migration Tool Changes */  
  
set nocount off  

end  

GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME= 'ep_glosry_sp_savebsml' AND TYPE='P')
BEGIN
	GRANT EXEC ON  ep_glosry_sp_savebsml TO PUBLIC
END
GO  
