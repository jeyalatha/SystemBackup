IF EXISTS  (SELECT 'X' FROM SYSOBJECTS WHERE NAME ='ep_layout_sp_entcsnumcnml' AND TYPE = 'P')
    BEGIN
        DROP PROC ep_layout_sp_entcsnumcnml
    END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		ep_layout_sp_entcsnumcnml.sql
********************************************************************************/
/*      V E R S I O N      :  2.0.4    */
/*      Released By        :  Ptech    */
/*      Release Comments   :  Released On 30-September-2004    */
/*      V E R S I O N      :  2.0.2    */
/*      Released By        :  PTech    */
/*      Release Comments   :  Released on  22-Jan-2004    */
/****** Object:  Stored Procedure dbo.ep_layout_sp_entcsnumcnml    Script Date: 11/6/03 5:20:38 PM ******/
/********************************************************************************/
/* Component    : Preview                                                       */
/* BO           : EP__BO                                                        */
/* BR           : EP_Layout_Mt_EntCSnUMCnML                                     */
/* Procedure    : ep_layout_sp_entcsnumcnml                                     */
/* Description  :                                                               */
/********************************************************************************/
/* Project      :                                                               */
/* Version      : 4.0.00                                                        */
/********************************************************************************/
/* Referenced   :                                                               */
/* Tables       :                                                               */
/********************************************************************************/
/* Development History                                                          */
/* Author       :                                                               */
/* Date         : 10/29/03                                                      */
/********************************************************************************/
/* Modification History                                                         */
/********************************************************************************/
/* Modified by  : Madugula Srinivas                                             */
/* Date         : 01-Nov-03                                                     */
/* Description  : Recoded the SP                                                */
/********************************************************************************/
/* modified by			Date				Defect ID							*/
/* Veena U				08-Jun-2016			PLF2.0_18487						*/
/********************************************************************************/
/* Modified by    :    Ponmalar A                                               */
/* Modified on    :    02/12/22													*/
/* Defect ID      :    TECH-75230												*/
/* Description    : Platform Release for the Month of Nov'22				    */
/********************************************************************************/
CREATE PROCEDURE ep_layout_sp_entcsnumcnml
	@ctxt_language engg_ctxt_language,
	@ctxt_ouinstance engg_ctxt_ouinstance,
	@ctxt_service engg_ctxt_service,
	@ctxt_user engg_ctxt_user,
	@engg_act_descr engg_description,
	@engg_component engg_description,
	@engg_cont_page_bts engg_name,
	@engg_cont_sec_bts engg_name,
	@engg_customer_name engg_name,
	@engg_process_descr engg_description,
	@engg_project_name engg_name,
	@engg_req_no engg_name,
	@engg_ui_descr engg_description,
	@modeflag engg_modeflag,
	@engg_cont_btsynname engg_name,
	@engg_cont_datawidth engg_flag,
	@engg_cont_descr engg_description,
	@engg_cont_doc engg_documentation,
	@engg_cont_elem_type engg_name,
	@engg_cont_horder engg_seqno,
	@engg_cont_labwidth engg_flag,
	@engg_cont_samp_data engg_documentation,
	@engg_cont_sequence engg_seqno,
	@engg_cont_tooltip engg_documentation,
	@engg_cont_vis_length engg_length,
	@engg_cont_vorder engg_seqno,
	@engg_cont_rowspan	 engg_seqno,  --Code added for TECH-75230
	@engg_cont_colspan  engg_seqno,
	@engg_cont_ctrlimg	engg_name,
	@fprowno engg_rowno,
	@engg_cont_tempid engg_name, --Input/Output
	@ctrl_temp_cat engg_name, --Input/Output
	@ctrl_temp_specific engg_documentation, --Input/Output
	@Icon_position	engg_name,	--Code added for TECH-75230
	@ButtonNature	engg_name,	--Code added for TECH-75230
	@InlineStyle	engg_nvarchar_max,	--Code added for TECH-75230
	@m_errorid INT OUTPUT
AS
BEGIN
	SET NOCOUNT ON

	SELECT @m_errorid = 0

	SELECT @ctxt_language = @ctxt_language

	SELECT @ctxt_ouinstance = @ctxt_ouinstance

	SELECT @ctxt_service = ltrim(rtrim(@ctxt_service))

	SELECT @ctxt_user = ltrim(rtrim(@ctxt_user))

	SELECT @engg_act_descr = ltrim(rtrim(@engg_act_descr))

	SELECT @engg_component = ltrim(rtrim(@engg_component))

	SELECT @engg_cont_page_bts = ltrim(rtrim(@engg_cont_page_bts))

	SELECT @engg_cont_sec_bts = ltrim(rtrim(@engg_cont_sec_bts))

	SELECT @engg_customer_name = ltrim(rtrim(@engg_customer_name))

	SELECT @engg_process_descr = ltrim(rtrim(@engg_process_descr))

	SELECT @engg_project_name = ltrim(rtrim(@engg_project_name))

	SELECT @engg_req_no = ltrim(rtrim(@engg_req_no))

	SELECT @engg_ui_descr = ltrim(rtrim(@engg_ui_descr))

	SELECT @modeflag = ltrim(rtrim(@modeflag))

	SELECT @engg_cont_btsynname = ltrim(rtrim(@engg_cont_btsynname))

	SELECT @engg_cont_descr = ltrim(rtrim(@engg_cont_descr))

	SELECT @engg_cont_doc = ltrim(rtrim(@engg_cont_doc))

	SELECT @engg_cont_elem_type = ltrim(rtrim(@engg_cont_elem_type))

	SELECT @engg_cont_horder = @engg_cont_horder

	SELECT @engg_cont_samp_data = ltrim(rtrim(@engg_cont_samp_data))

	SELECT @engg_cont_tooltip = ltrim(rtrim(@engg_cont_tooltip))

	SELECT @engg_cont_vis_length = @engg_cont_vis_length

	SELECT @engg_cont_vorder = @engg_cont_vorder

	SELECT @fprowno = @fprowno

	--null checking
	IF @ctxt_language = - 915
		SELECT @ctxt_language = NULL

	IF @ctxt_ouinstance = - 915
		SELECT @ctxt_ouinstance = NULL

	IF @ctxt_service = '~#~'
		SELECT @ctxt_service = NULL

	IF @ctxt_user = '~#~'
		SELECT @ctxt_user = NULL

	IF @engg_act_descr = '~#~'
		SELECT @engg_act_descr = NULL

	IF @engg_component = '~#~'
		SELECT @engg_component = NULL

	IF @engg_cont_page_bts = '~#~'
		SELECT @engg_cont_page_bts = NULL

	IF @engg_cont_sec_bts = '~#~'
		SELECT @engg_cont_sec_bts = NULL

	IF @engg_customer_name = '~#~'
		SELECT @engg_customer_name = NULL

	IF @engg_process_descr = '~#~'
		SELECT @engg_process_descr = NULL

	IF @engg_project_name = '~#~'
		SELECT @engg_project_name = NULL

	IF @engg_req_no = '~#~'
		SELECT @engg_req_no = NULL

	IF @engg_ui_descr = '~#~'
		SELECT @engg_ui_descr = NULL

	IF @modeflag = '~#~'
		SELECT @modeflag = NULL

	IF @engg_cont_btsynname = '~#~'
		SELECT @engg_cont_btsynname = NULL

	IF @engg_cont_descr = '~#~'
		SELECT @engg_cont_descr = NULL

	IF @engg_cont_doc = '~#~'
		SELECT @engg_cont_doc = NULL

	IF @engg_cont_elem_type = '~#~'
		SELECT @engg_cont_elem_type = NULL

	IF @engg_cont_horder = - 915
		SELECT @engg_cont_horder = NULL

	IF @engg_cont_labwidth = '~#~'
		SELECT @engg_cont_labwidth = NULL

	IF @engg_cont_samp_data = '~#~'
		SELECT @engg_cont_samp_data = NULL

	IF @engg_cont_datawidth = '~#~'
		SELECT @engg_cont_datawidth = NULL

	IF @engg_cont_tooltip = '~#~'
		SELECT @engg_cont_tooltip = NULL

	IF @engg_cont_vis_length = - 915
		SELECT @engg_cont_vis_length = NULL

	IF @engg_cont_vorder = - 915
		SELECT @engg_cont_vorder = NULL

	IF @fprowno = - 915
		SELECT @fprowno = NULL

	IF @engg_cont_sequence = - 915
		SELECT @engg_cont_sequence = NULL

	DECLARE @comp_name engg_name,
		@process_name engg_name,
		@engg_base_req_no engg_name

	SELECT @engg_base_req_no = 'BASE'

	-- 	select	@engg_req_no	=	rtrim(req_no)
	-- 	from	engg_project_vw	(nolock)
	-- 	where	customer_name	=	rtrim(@engg_customer_name)
	-- 	and	project_name	=	rtrim(@engg_project_name)	
	SELECT @process_name = rtrim(process_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_req_no)
		AND process_descr = rtrim(@engg_process_descr)

	SELECT @comp_name = rtrim(component_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_req_no)
		AND process_name = rtrim(@process_name)
		AND component_descr = rtrim(@engg_component)

	IF rtrim(@engg_cont_btsynname) IS NULL
		OR rtrim(@engg_cont_btsynname) = '~#~'
	BEGIN
		EXEC engg_error_sp 'ep_layout_sp_entcsnumcnml',
			1,
			'Control (BT Synonym) is Null',
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		IF @m_errorid <> 0
			RETURN
	END

	--output parameters
	SELECT @engg_cont_descr = rtrim(bt_synonym_caption)
	FROM ep_component_glossary_mst(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_base_req_no)
		AND component_name = rtrim(@comp_name)
		AND process_name = rtrim(@process_name)
		AND bt_synonym_name = rtrim(@engg_cont_btsynname)

	SELECT rtrim(@engg_cont_btsynname) 'engg_cont_btsynname',
		rtrim(@engg_cont_datawidth) 'engg_cont_datawidth',
		isnull(rtrim(@engg_cont_descr), '') 'engg_cont_descr',
		isnull(rtrim(@engg_cont_doc), '') 'engg_cont_doc',
		isnull(rtrim(@engg_cont_elem_type), '') 'engg_cont_elem_type',
		@engg_cont_horder 'engg_cont_horder',
		rtrim(@engg_cont_labwidth) 'engg_cont_labwidth',
		isnull(rtrim(@engg_cont_samp_data), '') 'engg_cont_samp_data',
		@engg_cont_sequence 'engg_cont_sequence',
		isnull(rtrim(@engg_cont_tooltip), '') 'engg_cont_tooltip',
		@engg_cont_vis_length 'engg_cont_vis_length',
		@engg_cont_vorder 'engg_cont_vorder',
		@fprowno 'fprowno',
		isnull(rtrim(@engg_cont_tempid), '') 'engg_cont_tempid',
		isnull(rtrim(@ctrl_temp_cat), '') 'ctrl_temp_cat',
		isnull(rtrim(@ctrl_temp_specific), '') 'ctrl_temp_specific',
		isnull(rtrim(@Icon_Position), '') 'Icon_Position',	--Code added for TECH-75230
		isnull(rtrim(@ButtonNature), '') 'ButtonNature',		--Code added for TECH-75230
		isnull(rtrim(@InlineStyle), '')  'InlineStyle'			--Code added for TECH-75230
	SET NOCOUNT OFF
END
GO

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_layout_sp_entcsnumcnml' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON ep_layout_sp_entcsnumcnml TO PUBLIC
END
GO

