IF EXISTS  (SELECT 'X' FROM SYSOBJECTS WHERE NAME ='ep_toolbar_sec_creation_sp' AND TYPE = 'P')
    BEGIN
        DROP PROC ep_toolbar_sec_creation_sp
    END
GO
/********************************************************************************/  
/* Procedure                               : ep_toolbar_sec_creation_sp			*/  
/* Description                             :									*/  
/********************************************************************************/  
/* Referenced                              :                                    */  
/* Tables                                  :									*/  
/********************************************************************************/  
/* Development history                     :                                    */  
/********************************************************************************/  
/* Author                                  : Ponmalar A/Jeya Latha K			*/  
/* Date                                    : 22-JUN-2022						*/  
/* rTrack ID                               : TECH-70687							*/  
/* Description							   : Tool and Toolbars				    */  
/********************************************************************************/
/* Modified by  : Ponmalar A/Priyadharshini U									*/
/* Modified on  : 23-Aug-2022                                                   */
/* Defect ID    : TECH-72114													*/
/* Description  : Platform Modeling for Section Title Icon						*/
/********************************************************************************/
/* Modified by			: Ponmalar A											*/
/* Date					: 29-Sep-2022											*/
/* Defect ID			: TECH-73216											*/
/********************************************************************************/
/* Modified by			: Ponmalar A											*/
/* Date					: 02-Dec-2022											*/
/* Defect ID			: TECH-75230											*/
/********************************************************************************/
CREATE PROCEDURE ep_toolbar_sec_creation_sp
 @ctxt_language             ctxt_language,  
 @ctxt_ouinstance           ctxt_ouinstance,  
 @ctxt_service              ctxt_service,  
 @ctxt_user                 ctxt_user,  
 @customer_name				engg_name,  
 @project_name				engg_name,  
 @req_no					engg_name,
 @process_name				engg_name,
 @component_name			engg_name,
 @activity_name				engg_name,
 @ui_name					engg_name,
 @page_name					engg_name,
 @section_name				engg_name,
 @toptoolbar				engg_seqno,
 @bottomtoolbar				engg_seqno,
 @lefttoolbar				engg_seqno,
 @righttoolbar				engg_seqno,
 @sidebarrequired			engg_seqno,
 @m_errorid					INT OUTPUT --To Return Execution Status
AS
BEGIN
	-- nocount should be switched on to prevent phantom rows
	SET NOCOUNT ON
	-- @m_errorid should be 0 to Indicate Success
	SET @m_errorid = 0

	DECLARE @base_req_no	engg_name,
			@tmp_page_name	engg_name,
			@tmp_sec_name	engg_name,
			@vorder			engg_seqno

	SELECT @base_req_no = 'BASE'

	--Not Null validations

	
	IF ISNULL(@customer_name,'') = ''
	BEGIN
		RAISERROR('Customer Name cannot be blank',16,1)
		RETURN
	END

	IF ISNULL(@project_name,'') = ''
	BEGIN
		RAISERROR('Project Name cannot be blank',16,1)
		RETURN
	END

	IF ISNULL(@process_name,'') = ''
	BEGIN
		RAISERROR('Process Name cannot be blank',16,1)
		RETURN
	END

	IF ISNULL(@component_name,'') = ''
	BEGIN
		RAISERROR('Component Name cannot be blank',16,1)
		RETURN
	END

	IF ISNULL(@activity_name,'') = ''
	BEGIN
		RAISERROR('Activity Name cannot be blank',16,1)
		RETURN
	END

	IF ISNULL(@ui_name,'') = ''
	BEGIN
		RAISERROR('UI Name cannot be blank',16,1)
		RETURN
	END

	SELECT @tmp_page_name = CASE WHEN ISNULL(@page_name,'') = ''    THEN '[mainscreen]' ELSE @page_name END

		--TECH-73216
		IF ISNULL(@toptoolbar,0) = 1  OR ISNULL(@bottomtoolbar,0) = 1 OR ISNULL(@lefttoolbar,0) = 1 OR ISNULL(@righttoolbar,0) = 1
		BEGIN
		IF LEN(@tmp_page_name) > 24  OR LEN(@section_name) > 24 
		BEGIN
			RAISERROR ('Length of Page/Section BT Synonym should not be greater than 24 for Toolbar & Sidebar.',16,1)
			RETURN
		END
		END		
		--TECH-73216

	IF  ISNULL(@toptoolbar,0) = 1 
	BEGIN
	SELECT @tmp_sec_name  = CASE WHEN ISNULL(@section_name,'') = '' THEN REPLACE(REPLACE(@tmp_page_name,'[',''),']','') + '_ttbar'
							ELSE @section_name+'_ttbar' END


	SELECT @vorder	=	ISNULL(MAX(vorder),0)+1
	FROM   ep_ui_section_dtl WITH (NOLOCK)
	WHERE	customer_name	= 	@customer_name
	AND		project_name	=	@project_name
	AND		req_no			=   @base_req_no
	AND		process_name	=	@process_name
	AND		component_name	=   @component_name
	AND		activity_name	=   @activity_name
	AND		ui_name			=   @ui_name
	AND     Horder			=	601

	EXEC ep_ui_section_dtl_sp_ins 
		@CTXT_LANGUAGE_IN			=	@ctxt_language,
		@CTXT_OUINSTANCE_IN			=	@ctxt_ouinstance,
		@CTXT_SERVICE_IN			=	@ctxt_service,
		@CTXT_USER_IN				=	@ctxt_user,
		@CUSTOMER_NAME_IN			=	@customer_name,
		@PROJECT_NAME_IN			=	@project_name,
		@REQ_NO_IN					=	@base_req_no,
		@PROCESS_NAME_IN			=	@process_name,
		@COMPONENT_NAME_IN			=	@component_name,
		@ACTIVITY_NAME_IN			=	@activity_name,
		@UI_NAME_IN					=	@ui_name,
		@PAGE_BT_SYNONYM_IN			=	@tmp_page_name,
		@SECTION_BT_SYNONYM_IN		=	@tmp_sec_name,
		@VISISBLE_FLAG_IN			=	'Y',
		@TITLE_REQUIRED_IN			=	'N',
		@BORDER_REQUIRED_IN			=	'N',
		@TITLE_ALIGNMENT_IN			=	'Left',
		@PARENT_SECTION_IN			=	'',
		@HORDER_IN					=	601,
		@VORDER_IN					=	@vorder,
		@SECTION_DOC_IN				=	'System generated section for Toolbar',
		@TIMESTAMP_IN				=	1,
		@ENGG_SECTION_TYPE_IN		=	'Toolbar',
		@engg_sec_cap_align			=	'',
		@engg_sec_cap_format		=	'',
		@sectionheight				=	'',
		@sectionwidth				=	100,
		@Section_width_Scalemode	=	'',
		@Section_height_Scalemode	=	'',
		@Sec_CollapseMode			=	'',
		@Sec_Collapse				=	'',
		@engg_req_no				=	@req_no,
		@section_rowspan			=	'',
		@section_colspan			=	'',
		@Region						=	'',
		@TitlePosition				=	'',
		@CollapseDir				=	'',
		@SectionLayout				=	'',
		@XYCoordinates				=	'',
		@ColumnLayWidth				=	'',
		@engg_associatedcontrol		=	'',
		@engg_mob_fullview			=	'',
		@engg_mob_responsive		=	'',
		@engg_sect_forresponsive	=	'',
		@Orientation				=	'',	--TECH-75230
		@engg_sec_bottomtb			=	'',
		@engg_sec_toptb				=	'',
		@engg_sec_righttb			=	'',
		@engg_sec_lefttb			=	'',
		@engg_sec_minrows			=	'',
		@engg_sec_vwmode			=	'',
		@engg_sec_titleicon			=	'', --TECH-72114
		@M_ERRORID					=	@m_errorid OUTPUT

	IF NOT EXISTS
	(SELECT 'X'
	 FROM ep_component_glossary_mst (NOLOCK)
	 WHERE customer_name	= @customer_name
	 AND   project_name		= @project_name
	 AND   process_name		= @process_name
	 AND   component_name	= @component_name
	 AND   bt_synonym_name	= @tmp_sec_name)
	BEGIN
	EXEC ep_component_glossary_mst_sp_ins 
		@CTXT_LANGUAGE_IN			= @ctxt_language,
		@CTXT_OUINSTANCE_IN			= @ctxt_ouinstance,
		@CTXT_SERVICE_IN			= @ctxt_service,
		@CTXT_USER_IN				= @ctxt_user,
		@CUSTOMER_NAME_IN			= @customer_name,
		@PROJECT_NAME_IN			= @project_name,
		@REQ_NO_IN					= @base_req_no,
		@PROCESS_NAME_IN			= @process_name,
		@COMPONENT_NAME_IN			= @component_name,
		@BT_SYNONYM_NAME_IN			= @tmp_sec_name,
		@REF_BT_SYNONYM_NAME_IN		= NULL,
		@DATA_TYPE_IN				= 'Char',
		@LENGTH_IN					= 20,
		@BT_SYNONYM_CAPTION_IN		= @tmp_sec_name,
		@BT_SYNONYM_DOC_IN			= @tmp_sec_name,
		@BT_NAME_IN					= '',
		@SYNONYM_STATUS_IN			= 'U',
		@SINGLEINST_SAMPLE_DATA_IN	= '',
		@MULTIINST_SAMPLE_DATA_IN	= '',
		@TIMESTAMP_IN				= 1,
		@ENGG_REQ_NO				= @req_no, 
		@M_ERRORID					= @m_errorid OUTPUT
	END

	END

	IF  ISNULL(@bottomtoolbar,0) = 1 
	BEGIN

	SELECT @tmp_sec_name  = CASE WHEN ISNULL(@section_name,'') = '' THEN REPLACE(REPLACE(@tmp_page_name,'[',''),']','') + '_btbar'
							ELSE @section_name+'_btbar' END
	
	SELECT @vorder	=	ISNULL(MAX(vorder),0)+1
	FROM   ep_ui_section_dtl WITH (NOLOCK)
	WHERE	customer_name	= 	@customer_name
	AND		project_name	=	@project_name
	AND		req_no			=   @base_req_no
	AND		process_name	=	@process_name
	AND		component_name	=   @component_name
	AND		activity_name	=   @activity_name
	AND		ui_name			=   @ui_name
	AND     Horder			=	601

	EXEC ep_ui_section_dtl_sp_ins 
		@CTXT_LANGUAGE_IN			=	@ctxt_language,
		@CTXT_OUINSTANCE_IN			=	@ctxt_ouinstance,
		@CTXT_SERVICE_IN			=	@ctxt_service,
		@CTXT_USER_IN				=	@ctxt_user,
		@CUSTOMER_NAME_IN			=	@customer_name,
		@PROJECT_NAME_IN			=	@project_name,
		@REQ_NO_IN					=	@base_req_no,
		@PROCESS_NAME_IN			=	@process_name,
		@COMPONENT_NAME_IN			=	@component_name,
		@ACTIVITY_NAME_IN			=	@activity_name,
		@UI_NAME_IN					=	@ui_name,
		@PAGE_BT_SYNONYM_IN			=	@tmp_page_name,
		@SECTION_BT_SYNONYM_IN		=	@tmp_sec_name,
		@VISISBLE_FLAG_IN			=	'Y',
		@TITLE_REQUIRED_IN			=	'N',
		@BORDER_REQUIRED_IN			=	'N',
		@TITLE_ALIGNMENT_IN			=	'Left',
		@PARENT_SECTION_IN			=	'',
		@HORDER_IN					=	601,
		@VORDER_IN					=	@vorder,
		@SECTION_DOC_IN				=	'System generated section for Toolbar',
		@TIMESTAMP_IN				=	1,
		@ENGG_SECTION_TYPE_IN		=	'Toolbar',
		@engg_sec_cap_align			=	'',
		@engg_sec_cap_format		=	'',
		@sectionheight				=	'',
		@sectionwidth				=	100,
		@Section_width_Scalemode	=	'',
		@Section_height_Scalemode	=	'',
		@Sec_CollapseMode			=	'',
		@Sec_Collapse				=	'',
		@engg_req_no				=	@req_no,
		@section_rowspan			=	'',
		@section_colspan			=	'',
		@Region						=	'',
		@TitlePosition				=	'',
		@CollapseDir				=	'',
		@SectionLayout				=	'',
		@XYCoordinates				=	'',
		@ColumnLayWidth				=	'',
		@engg_associatedcontrol		=	'',
		@engg_mob_fullview			=	'',
		@engg_mob_responsive		=	'',
		@engg_sect_forresponsive	=	'',
		@Orientation				=	'',	--TECH-75230
		@engg_sec_bottomtb			=	'',
		@engg_sec_toptb				=	'',
		@engg_sec_righttb			=	'',
		@engg_sec_lefttb			=	'',
		@engg_sec_minrows			=	'',
		@engg_sec_vwmode			=	'',
		@engg_sec_titleicon			=	'', --TECH-72114
		@M_ERRORID					=	@m_errorid OUTPUT

	IF NOT EXISTS
	(SELECT 'X'
	 FROM ep_component_glossary_mst (NOLOCK)
	 WHERE customer_name	= @customer_name
	 AND   project_name		= @project_name
	 AND   process_name		= @process_name
	 AND   component_name	= @component_name
	 AND   bt_synonym_name	= @tmp_sec_name)
	BEGIN
	EXEC ep_component_glossary_mst_sp_ins 
		@CTXT_LANGUAGE_IN			= @ctxt_language,
		@CTXT_OUINSTANCE_IN			= @ctxt_ouinstance,
		@CTXT_SERVICE_IN			= @ctxt_service,
		@CTXT_USER_IN				= @ctxt_user,
		@CUSTOMER_NAME_IN			= @customer_name,
		@PROJECT_NAME_IN			= @project_name,
		@REQ_NO_IN					= @base_req_no,
		@PROCESS_NAME_IN			= @process_name,
		@COMPONENT_NAME_IN			= @component_name,
		@BT_SYNONYM_NAME_IN			= @tmp_sec_name,
		@REF_BT_SYNONYM_NAME_IN		= NULL,
		@DATA_TYPE_IN				= 'Char',
		@LENGTH_IN					= 20,
		@BT_SYNONYM_CAPTION_IN		= @tmp_sec_name,
		@BT_SYNONYM_DOC_IN			= @tmp_sec_name,
		@BT_NAME_IN					= '',
		@SYNONYM_STATUS_IN			= 'U',
		@SINGLEINST_SAMPLE_DATA_IN	= '',
		@MULTIINST_SAMPLE_DATA_IN	= '',
		@TIMESTAMP_IN				= 1,
		@ENGG_REQ_NO				= @req_no, 
		@M_ERRORID					= @m_errorid OUTPUT
	END

	END

	IF  ISNULL(@lefttoolbar,0) = 1 
	BEGIN
	
	SELECT @tmp_sec_name  = CASE WHEN ISNULL(@section_name,'') = '' THEN REPLACE(REPLACE(@tmp_page_name,'[',''),']','') + '_ltbar'
							ELSE @section_name+'_ltbar' END

	SELECT @vorder	=	ISNULL(MAX(vorder),0)+1
	FROM   ep_ui_section_dtl WITH (NOLOCK)
	WHERE	customer_name	= 	@customer_name
	AND		project_name	=	@project_name
	AND		req_no			=   @base_req_no
	AND		process_name	=	@process_name
	AND		component_name	=   @component_name
	AND		activity_name	=   @activity_name
	AND		ui_name			=   @ui_name
	AND     Horder			=	601

	EXEC ep_ui_section_dtl_sp_ins 
		@CTXT_LANGUAGE_IN			=	@ctxt_language,
		@CTXT_OUINSTANCE_IN			=	@ctxt_ouinstance,
		@CTXT_SERVICE_IN			=	@ctxt_service,
		@CTXT_USER_IN				=	@ctxt_user,
		@CUSTOMER_NAME_IN			=	@customer_name,
		@PROJECT_NAME_IN			=	@project_name,
		@REQ_NO_IN					=	@base_req_no,
		@PROCESS_NAME_IN			=	@process_name,
		@COMPONENT_NAME_IN			=	@component_name,
		@ACTIVITY_NAME_IN			=	@activity_name,
		@UI_NAME_IN					=	@ui_name,
		@PAGE_BT_SYNONYM_IN			=	@tmp_page_name,
		@SECTION_BT_SYNONYM_IN		=	@tmp_sec_name,
		@VISISBLE_FLAG_IN			=	'Y',
		@TITLE_REQUIRED_IN			=	'N',
		@BORDER_REQUIRED_IN			=	'N',
		@TITLE_ALIGNMENT_IN			=	'Left',
		@PARENT_SECTION_IN			=	'',
		@HORDER_IN					=	601,
		@VORDER_IN					=	@vorder,
		@SECTION_DOC_IN				=	'System generated section for Toolbar',
		@TIMESTAMP_IN				=	1,
		@ENGG_SECTION_TYPE_IN		=	'Toolbar',
		@engg_sec_cap_align			=	'',
		@engg_sec_cap_format		=	'',
		@sectionheight				=	'',
		@sectionwidth				=	100,
		@Section_width_Scalemode	=	'',
		@Section_height_Scalemode	=	'',
		@Sec_CollapseMode			=	'',
		@Sec_Collapse				=	'',
		@engg_req_no				=	@req_no,
		@section_rowspan			=	'',
		@section_colspan			=	'',
		@Region						=	'',
		@TitlePosition				=	'',
		@CollapseDir				=	'',
		@SectionLayout				=	'',
		@XYCoordinates				=	'',
		@ColumnLayWidth				=	'',
		@engg_associatedcontrol		=	'',
		@engg_mob_fullview			=	'',
		@engg_mob_responsive		=	'',
		@engg_sect_forresponsive	=	'',
		@Orientation				=	'',	--TECH-75230
		@engg_sec_bottomtb			=	'',
		@engg_sec_toptb				=	'',
		@engg_sec_righttb			=	'',
		@engg_sec_lefttb			=	'',
		@engg_sec_minrows			=	'',
		@engg_sec_vwmode			=	'',
		@engg_sec_titleicon			=	'', --TECH-72114
		@M_ERRORID					=	@m_errorid OUTPUT

	IF NOT EXISTS
	(SELECT 'X'
	 FROM ep_component_glossary_mst (NOLOCK)
	 WHERE customer_name	= @customer_name
	 AND   project_name		= @project_name
	 AND   process_name		= @process_name
	 AND   component_name	= @component_name
	 AND   bt_synonym_name	= @tmp_sec_name)
	BEGIN
	EXEC ep_component_glossary_mst_sp_ins 
		@CTXT_LANGUAGE_IN			= @ctxt_language,
		@CTXT_OUINSTANCE_IN			= @ctxt_ouinstance,
		@CTXT_SERVICE_IN			= @ctxt_service,
		@CTXT_USER_IN				= @ctxt_user,
		@CUSTOMER_NAME_IN			= @customer_name,
		@PROJECT_NAME_IN			= @project_name,
		@REQ_NO_IN					= @base_req_no,
		@PROCESS_NAME_IN			= @process_name,
		@COMPONENT_NAME_IN			= @component_name,
		@BT_SYNONYM_NAME_IN			= @tmp_sec_name,
		@REF_BT_SYNONYM_NAME_IN		= NULL,
		@DATA_TYPE_IN				= 'Char',
		@LENGTH_IN					= 20,
		@BT_SYNONYM_CAPTION_IN		= @tmp_sec_name,
		@BT_SYNONYM_DOC_IN			= @tmp_sec_name,
		@BT_NAME_IN					= '',
		@SYNONYM_STATUS_IN			= 'U',
		@SINGLEINST_SAMPLE_DATA_IN	= '',
		@MULTIINST_SAMPLE_DATA_IN	= '',
		@TIMESTAMP_IN				= 1,
		@ENGG_REQ_NO				= @req_no, 
		@M_ERRORID					= @m_errorid OUTPUT
	END

	END

	IF ISNULL(@righttoolbar,0) = 1 
	BEGIN
	
	SELECT @tmp_sec_name  = CASE WHEN ISNULL(@section_name,'') = '' THEN REPLACE(REPLACE(@tmp_page_name,'[',''),']','') + '_rtbar'
							ELSE @section_name+'_rtbar' END

	SELECT @vorder	=	ISNULL(MAX(vorder),0)+1
	FROM   ep_ui_section_dtl WITH (NOLOCK)
	WHERE	customer_name	= 	@customer_name
	AND		project_name	=	@project_name
	AND		req_no			=   @base_req_no
	AND		process_name	=	@process_name
	AND		component_name	=   @component_name
	AND		activity_name	=   @activity_name
	AND		ui_name			=   @ui_name
	AND     Horder			=	601

	EXEC ep_ui_section_dtl_sp_ins 
		@CTXT_LANGUAGE_IN			=	@ctxt_language,
		@CTXT_OUINSTANCE_IN			=	@ctxt_ouinstance,
		@CTXT_SERVICE_IN			=	@ctxt_service,
		@CTXT_USER_IN				=	@ctxt_user,
		@CUSTOMER_NAME_IN			=	@customer_name,
		@PROJECT_NAME_IN			=	@project_name,
		@REQ_NO_IN					=	@base_req_no,
		@PROCESS_NAME_IN			=	@process_name,
		@COMPONENT_NAME_IN			=	@component_name,
		@ACTIVITY_NAME_IN			=	@activity_name,
		@UI_NAME_IN					=	@ui_name,
		@PAGE_BT_SYNONYM_IN			=	@tmp_page_name,
		@SECTION_BT_SYNONYM_IN		=	@tmp_sec_name,
		@VISISBLE_FLAG_IN			=	'Y',
		@TITLE_REQUIRED_IN			=	'N',
		@BORDER_REQUIRED_IN			=	'N',
		@TITLE_ALIGNMENT_IN			=	'Left',
		@PARENT_SECTION_IN			=	'',
		@HORDER_IN					=	601,
		@VORDER_IN					=	@vorder,
		@SECTION_DOC_IN				=	'System generated section for Toolbar',
		@TIMESTAMP_IN				=	1,
		@ENGG_SECTION_TYPE_IN		=	'Toolbar',
		@engg_sec_cap_align			=	'',
		@engg_sec_cap_format		=	'',
		@sectionheight				=	'',
		@sectionwidth				=	100,
		@Section_width_Scalemode	=	'',
		@Section_height_Scalemode	=	'',
		@Sec_CollapseMode			=	'',
		@Sec_Collapse				=	'',
		@engg_req_no				=	@req_no,
		@section_rowspan			=	'',
		@section_colspan			=	'',
		@Region						=	'',
		@TitlePosition				=	'',
		@CollapseDir				=	'',
		@SectionLayout				=	'',
		@XYCoordinates				=	'',
		@ColumnLayWidth				=	'',
		@engg_associatedcontrol		=	'',
		@engg_mob_fullview			=	'',
		@engg_mob_responsive		=	'',
		@engg_sect_forresponsive	=	'',
		@Orientation				=	'',	--TECH-75230
		@engg_sec_bottomtb			=	'',
		@engg_sec_toptb				=	'',
		@engg_sec_righttb			=	'',
		@engg_sec_lefttb			=	'',
		@engg_sec_minrows			=	'',
		@engg_sec_vwmode			=	'',
		@engg_sec_titleicon			=	'', --TECH-72114
		@M_ERRORID					=	@m_errorid OUTPUT

	IF NOT EXISTS
	(SELECT 'X'
	 FROM ep_component_glossary_mst (NOLOCK)
	 WHERE customer_name	= @customer_name
	 AND   project_name		= @project_name
	 AND   process_name		= @process_name
	 AND   component_name	= @component_name
	 AND   bt_synonym_name	= @tmp_sec_name)
	BEGIN
	EXEC ep_component_glossary_mst_sp_ins 
		@CTXT_LANGUAGE_IN			= @ctxt_language,
		@CTXT_OUINSTANCE_IN			= @ctxt_ouinstance,
		@CTXT_SERVICE_IN			= @ctxt_service,
		@CTXT_USER_IN				= @ctxt_user,
		@CUSTOMER_NAME_IN			= @customer_name,
		@PROJECT_NAME_IN			= @project_name,
		@REQ_NO_IN					= @base_req_no,
		@PROCESS_NAME_IN			= @process_name,
		@COMPONENT_NAME_IN			= @component_name,
		@BT_SYNONYM_NAME_IN			= @tmp_sec_name,
		@REF_BT_SYNONYM_NAME_IN		= NULL,
		@DATA_TYPE_IN				= 'Char',
		@LENGTH_IN					= 20,
		@BT_SYNONYM_CAPTION_IN		= @tmp_sec_name,
		@BT_SYNONYM_DOC_IN			= @tmp_sec_name,
		@BT_NAME_IN					= '',
		@SYNONYM_STATUS_IN			= 'U',
		@SINGLEINST_SAMPLE_DATA_IN	= '',
		@MULTIINST_SAMPLE_DATA_IN	= '',
		@TIMESTAMP_IN				= 1,
		@ENGG_REQ_NO				= @req_no, 
		@M_ERRORID					= @m_errorid OUTPUT
	END
	END

	IF  ISNULL(@sidebarrequired,0) = 1 
	BEGIN
	
	SELECT @tmp_sec_name  = 'mainscreen_sdbar'

	SELECT @vorder	=	ISNULL(MAX(vorder),0)+1
	FROM   ep_ui_section_dtl WITH (NOLOCK)
	WHERE	customer_name	= 	@customer_name
	AND		project_name	=	@project_name
	AND		req_no			=   @base_req_no
	AND		process_name	=	@process_name
	AND		component_name	=   @component_name
	AND		activity_name	=   @activity_name
	AND		ui_name			=   @ui_name
	AND     Horder			=	601

	EXEC ep_ui_section_dtl_sp_ins 
		@CTXT_LANGUAGE_IN			=	@ctxt_language,
		@CTXT_OUINSTANCE_IN			=	@ctxt_ouinstance,
		@CTXT_SERVICE_IN			=	@ctxt_service,
		@CTXT_USER_IN				=	@ctxt_user,
		@CUSTOMER_NAME_IN			=	@customer_name,
		@PROJECT_NAME_IN			=	@project_name,
		@REQ_NO_IN					=	@base_req_no,
		@PROCESS_NAME_IN			=	@process_name,
		@COMPONENT_NAME_IN			=	@component_name,
		@ACTIVITY_NAME_IN			=	@activity_name,
		@UI_NAME_IN					=	@ui_name,
		@PAGE_BT_SYNONYM_IN			=	@tmp_page_name,
		@SECTION_BT_SYNONYM_IN		=	@tmp_sec_name,
		@VISISBLE_FLAG_IN			=	'Y',
		@TITLE_REQUIRED_IN			=	'N',
		@BORDER_REQUIRED_IN			=	'N',
		@TITLE_ALIGNMENT_IN			=	'Left',
		@PARENT_SECTION_IN			=	'',
		@HORDER_IN					=	601,
		@VORDER_IN					=	@vorder,
		@SECTION_DOC_IN				=	'System generated section for Sidebar',
		@TIMESTAMP_IN				=	1,
		@ENGG_SECTION_TYPE_IN		=	'Sidebar',
		@engg_sec_cap_align			=	'',
		@engg_sec_cap_format		=	'',
		@sectionheight				=	'',
		@sectionwidth				=	100,
		@Section_width_Scalemode	=	'',
		@Section_height_Scalemode	=	'',
		@Sec_CollapseMode			=	'',
		@Sec_Collapse				=	'',
		@engg_req_no				=	@req_no,
		@section_rowspan			=	'',
		@section_colspan			=	'',
		@Region						=	'',
		@TitlePosition				=	'',
		@CollapseDir				=	'',
		@SectionLayout				=	'',
		@XYCoordinates				=	'',
		@ColumnLayWidth				=	'',
		@engg_associatedcontrol		=	'',
		@engg_mob_fullview			=	'',
		@engg_mob_responsive		=	'',
		@engg_sect_forresponsive	=	'',
		@Orientation				=	'',	--TECH-75230
		@engg_sec_bottomtb			=	'',
		@engg_sec_toptb				=	'',
		@engg_sec_righttb			=	'',
		@engg_sec_lefttb			=	'',
		@engg_sec_minrows			=	'',
		@engg_sec_vwmode			=	'',
		@engg_sec_titleicon			=	'', --TECH-72114
		@M_ERRORID					=	@m_errorid OUTPUT

	IF NOT EXISTS
	(SELECT 'X'
	 FROM ep_component_glossary_mst (NOLOCK)
	 WHERE customer_name	= @customer_name
	 AND   project_name		= @project_name
	 AND   process_name		= @process_name
	 AND   component_name	= @component_name
	 AND   bt_synonym_name	= @tmp_sec_name)
	BEGIN
	EXEC ep_component_glossary_mst_sp_ins 
		@CTXT_LANGUAGE_IN			= @ctxt_language,
		@CTXT_OUINSTANCE_IN			= @ctxt_ouinstance,
		@CTXT_SERVICE_IN			= @ctxt_service,
		@CTXT_USER_IN				= @ctxt_user,
		@CUSTOMER_NAME_IN			= @customer_name,
		@PROJECT_NAME_IN			= @project_name,
		@REQ_NO_IN					= @base_req_no,
		@PROCESS_NAME_IN			= @process_name,
		@COMPONENT_NAME_IN			= @component_name,
		@BT_SYNONYM_NAME_IN			= @tmp_sec_name,
		@REF_BT_SYNONYM_NAME_IN		= NULL,
		@DATA_TYPE_IN				= 'Char',
		@LENGTH_IN					= 20,
		@BT_SYNONYM_CAPTION_IN		= @tmp_sec_name,
		@BT_SYNONYM_DOC_IN			= @tmp_sec_name,
		@BT_NAME_IN					= '',
		@SYNONYM_STATUS_IN			= 'U',
		@SINGLEINST_SAMPLE_DATA_IN	= '',
		@MULTIINST_SAMPLE_DATA_IN	= '',
		@TIMESTAMP_IN				= 1,
		@ENGG_REQ_NO				= @req_no, 
		@M_ERRORID					= @m_errorid OUTPUT
	END
	END

	IF  ISNULL(@toptoolbar,0) = 0 
	BEGIN
	SELECT @tmp_sec_name  = CASE WHEN ISNULL(@section_name,'') = '' THEN REPLACE(REPLACE(@tmp_page_name,'[',''),']','') + '_ttbar'
							ELSE @section_name+'_ttbar' END
	
	IF EXISTS(
	SELECT 'X' FROM ep_ui_control_dtl (nolock)
	WHERE customer_name			= @customer_name
	AND   project_name			= @project_name
	AND   req_no				= @base_req_no
	AND   process_name			= @process_name
	AND   component_name		= @component_name
	AND   activity_name			= @activity_name
	AND   ui_name				= @ui_name
	AND   page_bt_synonym		= @tmp_page_name
	AND   section_bt_synonym	= @tmp_sec_name)
	BEGIN
		RAISERROR('Some of the controls are saved for the section ''%s''. Please delete the controls and proceed.',16,1,@tmp_sec_name)
		RETURN
	END
	
	ELSE 
	BEGIN
	
	DELETE
	FROM	ep_ui_section_dtl
	WHERE	customer_name	=	@customer_name
	AND		project_name	=	@project_name
	AND		req_no			=	@base_req_no
	AND		process_name	=	@process_name
	AND		component_name	=	@component_name
	AND		activity_name	=	@activity_name
	AND		ui_name			=	@ui_name
	AND		page_bt_synonym	=	@tmp_page_name
	AND		section_bt_synonym	=	@tmp_sec_name

	END
	END

	IF  ISNULL(@bottomtoolbar,0) = 0
	BEGIN
	SELECT @tmp_sec_name  = CASE WHEN ISNULL(@section_name,'') = '' THEN REPLACE(REPLACE(@tmp_page_name,'[',''),']','') + '_btbar'
							ELSE @section_name+'_btbar' END

	IF EXISTS(
	SELECT 'X' FROM ep_ui_control_dtl (nolock)
	WHERE customer_name			= @customer_name
	AND   project_name			= @project_name
	AND   req_no				= @base_req_no
	AND   process_name			= @process_name
	AND   component_name		= @component_name
	AND   activity_name			= @activity_name
	AND   ui_name				= @ui_name
	AND   page_bt_synonym		= @tmp_page_name
	AND   section_bt_synonym	= @tmp_sec_name)
	BEGIN
		RAISERROR('Some of the controls are saved for the section ''%s''. Please delete the controls and proceed.',16,1,@tmp_sec_name)
		RETURN
	END

	ELSE 
	BEGIN
	
	DELETE
	FROM	ep_ui_section_dtl
	WHERE	customer_name	=	@customer_name
	AND		project_name	=	@project_name
	AND		req_no			=	@base_req_no
	AND		process_name	=	@process_name
	AND		component_name	=	@component_name
	AND		activity_name	=	@activity_name
	AND		ui_name			=	@ui_name
	AND		page_bt_synonym	=	@tmp_page_name
	AND		section_bt_synonym	=	@tmp_sec_name

	END

	END

	IF  ISNULL(@lefttoolbar,0) = 0
	BEGIN
	SELECT @tmp_sec_name  = CASE WHEN ISNULL(@section_name,'') = '' THEN REPLACE(REPLACE(@tmp_page_name,'[',''),']','') + '_ltbar'
							ELSE @section_name+'_ltbar' END

	IF EXISTS(
	SELECT 'X' FROM ep_ui_control_dtl (nolock)
	WHERE customer_name			= @customer_name
	AND   project_name			= @project_name
	AND   req_no				= @base_req_no
	AND   process_name			= @process_name
	AND   component_name		= @component_name
	AND   activity_name			= @activity_name
	AND   ui_name				= @ui_name
	AND   page_bt_synonym		= @tmp_page_name
	AND   section_bt_synonym	= @tmp_sec_name)
	BEGIN
		RAISERROR('Some of the controls are saved for the section ''%s''. Please delete the controls and proceed.',16,1,@tmp_sec_name)
		RETURN
	END
	
	ELSE 
	BEGIN
	
	DELETE
	FROM	ep_ui_section_dtl
	WHERE	customer_name	=	@customer_name
	AND		project_name	=	@project_name
	AND		req_no			=	@base_req_no
	AND		process_name	=	@process_name
	AND		component_name	=	@component_name
	AND		activity_name	=	@activity_name
	AND		ui_name			=	@ui_name
	AND		page_bt_synonym	=	@tmp_page_name
	AND		section_bt_synonym	=	@tmp_sec_name

	END

	END

	IF  ISNULL(@righttoolbar,0) = 0
	BEGIN
	
	SELECT @tmp_sec_name  = CASE WHEN ISNULL(@section_name,'') = '' THEN REPLACE(REPLACE(@tmp_page_name,'[',''),']','') + '_rtbar'
							ELSE @section_name+'_rtbar' END
	IF EXISTS(
	SELECT 'X' FROM ep_ui_control_dtl (nolock)
	WHERE customer_name			= @customer_name
	AND   project_name			= @project_name
	AND   req_no				= @base_req_no
	AND   process_name			= @process_name
	AND   component_name		= @component_name
	AND   activity_name			= @activity_name
	AND   ui_name				= @ui_name
	AND   page_bt_synonym		= @tmp_page_name
	AND   section_bt_synonym	= @tmp_sec_name)
	BEGIN
		RAISERROR('Some of the controls are saved for the section ''%s''. Please delete the controls and proceed.',16,1,@tmp_sec_name)
		RETURN
	END
	
	ELSE 
	BEGIN
	
	DELETE
	FROM	ep_ui_section_dtl
	WHERE	customer_name	=	@customer_name
	AND		project_name	=	@project_name
	AND		req_no			=	@base_req_no
	AND		process_name	=	@process_name
	AND		component_name	=	@component_name
	AND		activity_name	=	@activity_name
	AND		ui_name			=	@ui_name
	AND		page_bt_synonym	=	@tmp_page_name
	AND		section_bt_synonym	=	@tmp_sec_name

	END

	END

	IF  ISNULL(@sidebarrequired,0) = 0
	BEGIN
	
	SELECT @tmp_sec_name  = CASE WHEN ISNULL(@section_name,'') = '' THEN REPLACE(REPLACE(@tmp_page_name,'[',''),']','') + '_sdbar'
							ELSE @section_name+'_sdbar' END

	IF EXISTS(
	SELECT 'X' FROM ep_ui_control_dtl (nolock)
	WHERE customer_name			= @customer_name
	AND   project_name			= @project_name
	AND   req_no				= @base_req_no
	AND   process_name			= @process_name
	AND   component_name		= @component_name
	AND   activity_name			= @activity_name
	AND   ui_name				= @ui_name
	AND   page_bt_synonym		= @tmp_page_name
	AND   section_bt_synonym	= @tmp_sec_name)
	BEGIN
		RAISERROR('Some of the controls are saved for the section ''%s''. Please delete the controls and proceed.',16,1,@tmp_sec_name)
		RETURN
	END

    ELSE 
	BEGIN
	
	DELETE
	FROM	ep_ui_section_dtl
	WHERE	customer_name	=	@customer_name
	AND		project_name	=	@project_name
	AND		req_no			=	@base_req_no
	AND		process_name	=	@process_name
	AND		component_name	=	@component_name
	AND		activity_name	=	@activity_name
	AND		ui_name			=	@ui_name
	AND		page_bt_synonym	=	@tmp_page_name
	AND		section_bt_synonym	=	@tmp_sec_name

	END
	END

	SET NOCOUNT OFF
END

GO 

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_toolbar_sec_creation_sp' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON ep_toolbar_sec_creation_sp TO PUBLIC
END
GO

