IF EXISTS(SELECT 'X' From SYSOBJECTS WHERE NAME ='ep_maireeSpep_lay_secspO' AND TYPE='P')
   BEGIN
        DROP PROC ep_maireeSpep_lay_secspO
   END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		ep_maireeSpep_lay_secspO.sql
********************************************************************************/
/******************************************************************************/
/* Procedure     : ep_maireeSpep_lay_secspO         */
/* Description     :          */
/******************************************************************************/
/* Project      :          */
/* EcrNo      :          */
/* Version      :          */
/******************************************************************************/
/* Referenced     :          */
/* Tables      :          */
/******************************************************************************/
/* Development history   :          */
/******************************************************************************/
/* Author      : Gowrisankar M         */
/* Date       : Apr 16 2008 10:25AM         */
/******************************************************************************/
/* Modification History   :          */
/******************************************************************************/
/* modified by   : Jeya           */
/* date     : 24-nov-2008         */
/* BugId    : PNR2.0_1790          */
/****************************************************************************/
/* modified by  : Jeyalatha K            */
/* date    : 11-Feb-2011                                           */
/* Bug Id   : PNR2.0_30127           */
/* Modified for  : Feature  Release          */
/****************************************************************************/
/* modified by  : Piranava T  			                                        */
/* date         : Oct 10 2014			                                        */
/* BugId        : PLF2.0_09035 			                                        */
/* description  : Model changes for rowspan,colspan,IsStatic,IsCallout iná layout level */
/************************************************************************************/
/* Modified by  : Veena U                                                  */
/* Date         : 25-Feb-2015                                                  */
/* Call ID		: PLF2.0_11499                                                 */
/********************************************************************************/
/* Modified by  : Veena U                                                  */
/* Date         : 28-Mar-2016                                                 */
/* Call ID		: PLF2.0_17570                                               */
/********************************************************************************/
/* modified by			Date				Defect ID							*/
/* Veena U				08-Jun-2016			PLF2.0_18487						*/
/********************************************************************************/
/* Modified by	:	Priyadharshini U 											*/
/* Modified on	:	08/07/2022				 									*/
/* Defect ID	:	Tech-70687													*/
/* Description	:	Tool and Toolbars											*/
/********************************************************************************/
/* Modified by	:	Ponmalar A 													*/
/* Modified on	:	24/Aug/2022				 									*/
/* Defect ID	:	Tech-72114													*/
/* Description	:	Platform Modeling for Section Title Icon					*/
/********************************************************************************/
/* Modified by	:	Vimal Kumar R												*/
/* Modified on	:	03/Nov/2022				 									*/
/* Defect ID	:	TECH-75230													*/
/* Description	:	Platform Release for the Month of Nov'22					*/
/********************************************************************************/
CREATE PROCEDURE ep_maireeSpep_lay_secspO
	@ctxt_ouinstance ctxt_OUInstance, --Input
	@ctxt_user ctxt_User, --Input
	@ctxt_language ctxt_Language, --Input
	@ctxt_service ctxt_Service, --Input
	@engg_act_descr ENGG_DESCRIPTION, --Input
	@engg_callout_type engg_type, --Input   -- added for request id: PNR2.0_1790
	@engg_component engg_description, --Input
	@engg_cont_page_bts engg_name, --Input
	@engg_cont_sec_bts engg_name, --Input
	@engg_customer_name engg_name, --Input
	@engg_enum_btsynname engg_name, --Input
	@engg_enum_page_bts engg_name, --Input
	@engg_enum_sec_bts engg_name, --Input
	@engg_grid_grid_code engg_name, --Input
	@engg_grid_page_bts engg_name, --Input
	@engg_grid_sec_bts engg_name, --Input
	@engg_lay_page_bts engg_name, --Input
	@engg_lnk_page_descr engg_description, --Input
	@engg_process_descr engg_description, --Input
	@engg_project_name engg_name, --Input
	@engg_radio_btsynname engg_name, --Input
	@engg_radio_page_bts engg_name, --Input
	@engg_radio_sec_bts engg_name, --Input
	@engg_req_no engg_name, --Input
	@engg_sec_page_bts engg_name, --Input
	@engg_ui_descr engg_name, --Input
	@eZee_Taskpane engg_name, --Input -- Added for the Bug ID: PNR2.0_30127
	@enggad_fprowno RowNo, --Input/Output
	@enggpa_fprowno RowNo, --Input/Output
	@engg_c_fprowno RowNo, --Input/Output
	@engg_l_fprowno RowNo, --Input/Output
	@engg_m_fprowno RowNo, --Input/Output
	@engg_r_fprowno RowNo, --Input/Output
	@engg_y_fprowno RowNo, --Input/Output
	@_sec_fprowno RowNo, --Input/Output
	@m_errorid INT OUTPUT --To Return Execution Status
AS
BEGIN
	-- nocount should be switched on to prevent phantom rows
	SET NOCOUNT ON
	-- @m_errorid should be 0 to Indicate Success
	SET @m_errorid = 0
	--declaration of temporary variables
	--temporary and formal parameters mapping
	SET @ctxt_user = ltrim(rtrim(@ctxt_user))
	SET @ctxt_service = ltrim(rtrim(@ctxt_service))
	SET @engg_act_descr = ltrim(rtrim(@engg_act_descr))
	SET @engg_component = ltrim(rtrim(@engg_component))
	SET @engg_cont_page_bts = ltrim(rtrim(@engg_cont_page_bts))
	SET @engg_cont_sec_bts = ltrim(rtrim(@engg_cont_sec_bts))
	SET @engg_customer_name = ltrim(rtrim(@engg_customer_name))
	SET @engg_enum_btsynname = ltrim(rtrim(@engg_enum_btsynname))
	SET @engg_enum_page_bts = ltrim(rtrim(@engg_enum_page_bts))
	SET @engg_enum_sec_bts = ltrim(rtrim(@engg_enum_sec_bts))
	SET @engg_grid_grid_code = ltrim(rtrim(@engg_grid_grid_code))
	SET @engg_grid_page_bts = ltrim(rtrim(@engg_grid_page_bts))
	SET @engg_grid_sec_bts = ltrim(rtrim(@engg_grid_sec_bts))
	SET @engg_lay_page_bts = ltrim(rtrim(@engg_lay_page_bts))
	SET @engg_lnk_page_descr = ltrim(rtrim(@engg_lnk_page_descr))
	SET @engg_process_descr = ltrim(rtrim(@engg_process_descr))
	SET @engg_project_name = ltrim(rtrim(@engg_project_name))
	SET @engg_radio_btsynname = ltrim(rtrim(@engg_radio_btsynname))
	SET @engg_radio_page_bts = ltrim(rtrim(@engg_radio_page_bts))
	SET @engg_radio_sec_bts = ltrim(rtrim(@engg_radio_sec_bts))
	SET @engg_req_no = ltrim(rtrim(@engg_req_no))
	SET @engg_sec_page_bts = ltrim(rtrim(@engg_sec_page_bts))
	SET @engg_ui_descr = ltrim(rtrim(@engg_ui_descr))
	SET @engg_callout_type = ltrim(rtrim(@engg_callout_type)) -- added for request id: PNR2.0_1790
	SET @eZee_Taskpane = ltrim(rtrim(@eZee_Taskpane)) -- Added for the Bug ID: PNR2.0_30127

	--null checking
	IF @ctxt_ouinstance = - 915
		SELECT @ctxt_ouinstance = NULL

	IF @ctxt_user = '~#~'
		SELECT @ctxt_user = NULL

	IF @ctxt_language = - 915
		SELECT @ctxt_language = NULL

	IF @ctxt_service = '~#~'
		SELECT @ctxt_service = NULL

	IF @engg_act_descr = '~#~'
		SELECT @engg_act_descr = NULL

	IF @engg_component = '~#~'
		SELECT @engg_component = NULL

	IF @engg_cont_page_bts = '~#~'
		SELECT @engg_cont_page_bts = NULL

	IF @engg_cont_sec_bts = '~#~'
		SELECT @engg_cont_sec_bts = NULL

	IF @engg_customer_name = '~#~'
		SELECT @engg_customer_name = NULL

	IF @engg_enum_btsynname = '~#~'
		SELECT @engg_enum_btsynname = NULL

	IF @engg_enum_page_bts = '~#~'
		SELECT @engg_enum_page_bts = NULL

	IF @engg_enum_sec_bts = '~#~'
		SELECT @engg_enum_sec_bts = NULL

	IF @engg_grid_grid_code = '~#~'
		SELECT @engg_grid_grid_code = NULL

	IF @engg_grid_page_bts = '~#~'
		SELECT @engg_grid_page_bts = NULL

	IF @engg_grid_sec_bts = '~#~'
		SELECT @engg_grid_sec_bts = NULL

	IF @engg_lay_page_bts = '~#~'
		SELECT @engg_lay_page_bts = NULL

	IF @engg_lnk_page_descr = '~#~'
		SELECT @engg_lnk_page_descr = NULL

	IF @engg_process_descr = '~#~'
		SELECT @engg_process_descr = NULL

	IF @engg_project_name = '~#~'
		SELECT @engg_project_name = NULL

	IF @engg_radio_btsynname = '~#~'
		SELECT @engg_radio_btsynname = NULL

	IF @engg_radio_page_bts = '~#~'
		SELECT @engg_radio_page_bts = NULL

	IF @engg_radio_sec_bts = '~#~'
		SELECT @engg_radio_sec_bts = NULL

	IF @engg_req_no = '~#~'
		SELECT @engg_req_no = NULL

	IF @engg_sec_page_bts = '~#~'
		SELECT @engg_sec_page_bts = NULL

	IF @engg_ui_descr = '~#~'
		SELECT @engg_ui_descr = NULL

	IF @enggad_fprowno = - 915
		SELECT @enggad_fprowno = NULL

	IF @enggpa_fprowno = - 915
		SELECT @enggpa_fprowno = NULL

	IF @engg_c_fprowno = - 915
		SELECT @engg_c_fprowno = NULL

	IF @engg_l_fprowno = - 915
		SELECT @engg_l_fprowno = NULL

	IF @engg_m_fprowno = - 915
		SELECT @engg_m_fprowno = NULL

	IF @engg_r_fprowno = - 915
		SELECT @engg_r_fprowno = NULL

	IF @engg_y_fprowno = - 915
		SELECT @engg_y_fprowno = NULL

	IF @_sec_fprowno = - 915
		SELECT @_sec_fprowno = NULL

	IF @engg_callout_type = '~#~' -- added for request id: PNR2.0_1790
		SELECT @engg_callout_type = NULL

	-- Code modification for  PNR2.0_30127 starts
	IF @eZee_Taskpane = '~#~'
		SELECT @eZee_Taskpane = NULL

	-- Code modification for  PNR2.0_30127 ends
	DECLARE @tmp_comp_name engg_name,
		@tmp_proc engg_name,
		@tmp_acty_name engg_name,
		@tmp_ui_name engg_name,
		@engg_base_req_no engg_name

	SELECT @engg_base_req_no = 'BASE'

	SELECT @tmp_proc = process_name,
		@tmp_comp_name = component_name,
		@tmp_acty_name = activity_name,
		@tmp_ui_name = ui_name
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND req_no = @engg_req_no
		AND process_descr = @engg_process_descr
		AND component_descr = @engg_component
		AND activity_descr = @engg_act_descr
		AND ui_descr = @engg_ui_descr

	/*select the min of page*/
	DECLARE @page_bt_synonym_tmp engg_name

	SELECT TOP 1 @page_bt_synonym_tmp = rtrim(page_bt_synonym)
	FROM ep_ui_page_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND req_no = @engg_base_req_no
		AND process_name = @tmp_proc
		AND component_name = @tmp_comp_name
		AND activity_name = @tmp_acty_name
		AND ui_name = @tmp_ui_name
	ORDER BY horder,
		vorder

	/*
fetch the section details for the selected activity/ui/pages and display in the
multiline
*/
	SELECT CASE 
			WHEN border_required = 'y'
				THEN 1
			WHEN border_required = 'n'
				THEN 0
			END 'engg_sec_bord_req',
		rtrim(section_bt_synonym) 'engg_sec_btsynname',
		rtrim(b.bt_synonym_caption) 'engg_sec_descr',
		rtrim(title_alignment) 'engg_sec_title_align',
		CASE 
			WHEN title_required = 'y'
				THEN 1
			WHEN title_required = 'n'
				THEN 0
			END 'engg_sec_title_req',
		CASE 
			WHEN visisble_flag = 'y'
				THEN 1
			WHEN visisble_flag = 'n'
				THEN 0
			END 'engg_sec_visible',
		rtrim(section_doc) 'engg_sect_doc',
		rtrim(SectionPrefixClass) 'engg_sec_prefix_class',
		cast(a.height AS VARCHAR(60)) + a.Section_height_Scalemode 'engg_sec_height',
		cast(a.Width AS VARCHAR(60)) + a.Section_width_Scalemode 'engg_sec_width',
		caption_Format 'engg_sec_cap_format',
		ctrl_caption_align 'engg_sec_cap_align',
		section_type 'engg_sec_type',
		a.section_collapsemode 'Sec_CollapseMode',
		isnull(Region, '') 'engg_region',
		isnull(TitlePosition, '') 'engg_title_pos',
		isnull(CollapseDir, '') 'engg_col_dir',
		isnull(SectionLayout, '') 'engg_sect_lay',
		CASE 
			WHEN SectionLayout = 'abs'
				THEN isnull(XYCoordinates, '')
			WHEN SectionLayout = 'col'
				THEN isnull(ColumnLayWidth, '')
			ELSE NULL
			END 'engg_sec_lay_con',
		ISNULL(Associated_Control, '')	'engg_associatedcontrol',
		ISNULL(Orientation, '')			'Orientation',				--Code Added for TECH-75230
		--Tech-70687
		case when a.LeftToolbar		=	'Y' then 1 else 0 end 'engg_sec_lefttb',
		case when a.RightToolbar	=	'Y'	then 1 else 0 end 'engg_sec_righttb',
		case when a.TopToolbar		=	'Y'	then 1 else 0 end 'engg_sec_toptb',
		case when a.BottomToolbar	=	'Y'	then 1 else 0 end 'engg_sec_bottomtb',
		a.MinimizedRows			'engg_sec_minrows',
		isnull(a.ViewMode,'')	'engg_sec_vwmode',
		--Tech-70687
		isnull(a.TitleIcon,'')	'engg_sec_titleicon' --TECH-72114
	FROM ep_component_glossary_mst b(NOLOCK)
	RIGHT JOIN ep_ui_section_dtl a(NOLOCK) ON b.customer_name = a.customer_name
		AND b.project_name = a.project_name
		AND b.req_no = a.req_no
		AND b.process_name = a.process_name
		AND b.component_name = a.component_name
		AND b.bt_synonym_name = a.section_bt_synonym
	WHERE a.customer_name = @engg_customer_name
		AND a.project_name = @engg_project_name
		AND a.req_no = @engg_base_req_no
		AND a.process_name = @tmp_proc
		AND a.component_name = @tmp_comp_name
		AND a.activity_name = @tmp_acty_name
		AND a.ui_name = @tmp_ui_name
		AND a.page_bt_synonym = @page_bt_synonym_tmp
		AND section_bt_synonym NOT IN (
			'PrjHdnSection',
			'[tabcontrol]'
			)
		AND a.Section_type NOT IN ('Sidebar','Toolbar')	--Tech-70687
	ORDER BY section_bt_synonym

	/*
--OutputList
Select
null 'enggad_fprowno',
null 'enggpa_fprowno',
null 'engg_c_fprowno',
null 'engg_l_fprowno',
null 'engg_m_fprowno',
null 'engg_r_fprowno',
null 'engg_y_fprowno',
null '_sec_fprowno',
null 'engg_sect_doc',
null 'engg_sec_bord_req',
null 'engg_sec_btsynname',
null 'engg_sec_cap_align',
null 'engg_sec_cap_format',
null 'engg_sec_descr',
null 'engg_sec_secpreclass',
null 'engg_sec_title_align',
null 'engg_sec_title_req',
null 'engg_sec_type',
null 'engg_sec_visible',
null 'sectionheight',
null 'sectionwidth',
*/
	SET NOCOUNT OFF
END

GO
IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME= 'ep_maireeSpep_lay_secspO' AND TYPE='P')
BEGIN
	GRANT EXEC ON  ep_maireeSpep_lay_secspO TO PUBLIC
END
GO