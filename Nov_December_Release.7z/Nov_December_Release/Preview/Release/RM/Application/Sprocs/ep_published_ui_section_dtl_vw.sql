if Exists ( Select 'x' From sysobjects Where name = 'ep_published_ui_section_dtl_vw' And type in ('V','v'))
Begin
Drop view ep_published_ui_section_dtl_vw
End
go
/************************************************************************************
procedure name and id   ep_published_ui_section_dtl_vw
description             
name of the author      
date created            
query file name         ep_published_ui_section_dtl_vw.sql
modifications history   
modified by             : Balaji D    
modified date           : Dec 31 2011   
modified purpose        : Modelling for Splitter Section.
Bug ID		            : PNR2.0_36007
************************************************************************************/
/* modified by  : Veena U   			                                        */
/* date         : Oct 10 2014			                                        */
/* BugId        : PLF2.0_09035													*/
/* description  : Model changes for rowspan,colspan,IsCallout 
				  in  layout level.												*/
/********************************************************************************/
/* Modified by  : Veena U	                                                  */
/* Date         : 07-Aug-2015                                                  */
/* Defect ID	: PLF2.0_14096                                                 */
/********************************************************************************/
/* modified by  : Veena U        */
/* date         : 28-Mar-2016              */
/* Bug ID  		: PLF2.0_17570           */
/********************************************************************************/
/* Modified by	:	Priyadharshini U 											*/
/* Modified on	:	08/06/22				 									*/
/* Defect ID	:	TECH-69624													*/
/* Description	:	Custom border, Custom actions and Responsive layout			*/
/********************************************************************************/
/* Modified by	:	Ponmalar A													*/
/* Modified on	:	11/07/22				 									*/
/* Defect ID	:	TECH-70687													*/
/* Description	:	Tool and Toolbars											*/
/********************************************************************************/
/* Modified by	:	Ponmalar A													*/
/* Modified on	:	24/08/2022				 									*/
/* Defect ID	:	TECH-72114													*/
/* Description	:	Platform modelling for Title Icon							*/
/********************************************************************************/
/* Modified by			: Priyadharshini U										*/
/* Date					: 22-Nov-2022											*/
/* Defect ID			: TECH-75230											*/
/********************************************************************************/
CREATE View ep_published_ui_section_dtl_vw
as
select 	customer_name				'customer_name',
		project_name				'project_name',
		req_no						'req_no',
		process_name				'process_name',
		component_name				'component_name',
		activity_name				'activity_name',
		ui_name						'ui_name',
		page_bt_synonym				'page_bt_synonym',
		section_bt_synonym			'section_bt_synonym',
		visisble_flag				'visisble_flag',
		title_required				'title_required',
		border_required				'border_required',
		parent_section				'parent_section',
		horder						'horder',
		vorder						'vorder',
		ui_section_sysid			'ui_section_sysid',
		page_sysid					'page_sysid',
		title_alignment				'title_alignment',
		timestamp					'timestamp',
		createdby					'createdby',
		createddate					'createddate',
		modifiedby					'modifiedby',
		modifieddate				'modifieddate',
		section_doc					'section_doc',
		section_type				'section_type',
		width						'width',
		height						'height',
		caption_Format				'caption_Format',
		SectionPrefixClass			'SectionPrefixClass',
		Section_width_Scalemode		'Section_width_Scalemode' ,
		Section_height_Scalemode	'Section_height_Scalemode',
		ctrl_caption_align			'ctrl_caption_align',
		section_prefix				'section_prefix',
		Associated_control			'Associated_control', -- Code modified for  PNR2.0_31403
        splitter_pos				'splitter_pos', --Code modified for PNR2.0_36007
		NColSpan					'NColSpan',
		NRowSpan					'NRowSpan', --PLF2.0_07805
		section_collapsemode		'section_collapsemode',
		section_collapse			'section_collapse',
		CarouselNavigation			'CarouselNavigation',
		cell_spacing				'cell_spacing',
		cell_padding				'cell_padding',
		Region						'Region',--PLF2.0_17570
		TitlePosition				'TitlePosition',
		CollapseDir					'CollapseDir',
		SectionLayout				'SectionLayout',
		XYCoordinates				'XYCoordinates',
		ColumnLayWidth				'ColumnLayWidth',
		IsPlatform					'IsPlatform',
		IsResponsive				'IsResponsive',
		mob_pop_fullview			'mob_pop_fullview',
		BorderLeftWidth				'BorderLeftWidth',	
		BorderRightWidth			'BorderRightWidth',
		BorderTopWidth				'BorderTopWidth',
		BorderBottomWidth			'BorderBottomWidth',
		BorderLeftColor				'BorderLeftColor',
		BorderRightColor			'BorderRightColor',
		BorderTopColor				'BorderTopColor',
		BorderBottomColor			'BorderBottomColor',
		BorderTopLeftRadius			'BorderTopLeftRadius',
		BorderTopRightRadius		'BorderTopRightRadius',
		BorderBottomLeftRadius		'BorderBottomLeftRadius',
		BorderBottomRightRadius		'BorderBottomRightRadius',
		BorderStyle					'BorderStyle',
		ForResponsive				'ForResponsive',		--Code added for TECH-69624
		--TECH-70687
		LeftToolbar					'LeftToolbar',
		RightToolbar				'RightToolbar',
		TopToolbar					'TopToolbar',
		BottomToolbar				'BottomToolbar',
		MinimizedRows				'MinimizedRows',
		ViewMode					'ViewMode',
		HasTitleAction				'HasTitleAction',
		--TECH-70687
		TitleIcon					'TitleIcon'	,	--TECH-72114
		Orientation					'Orientation'	--TECH-75230
from	ep_published_ui_section_dtl (nolock)

go
if exists(select 'x' from sysobjects where name = 'ep_published_ui_section_dtl_vw' and xtype = 'V')
begin
grant select on ep_published_ui_section_dtl_vw to public
end
go