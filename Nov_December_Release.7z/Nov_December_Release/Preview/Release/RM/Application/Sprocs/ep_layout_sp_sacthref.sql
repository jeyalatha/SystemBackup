IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_layout_sp_sacthref' AND TYPE = 'P')
BEGIN
	DROP PROC ep_layout_sp_sacthref
END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		ep_layout_sp_sacthref.sql
********************************************************************************/
/*      V E R S I O N      :  PNR2.0_1403    */
/*      Released By        :  Development Team    */
/*      Release Comments   :  For DotNet Migration, Naming convention has been changed  for some of the out parameters by using Stub Generator.Comments will not be there for this Request ID.    */
/*      V E R S I O N      :  2.0.4    */
/*      Released By        :  PTech    */
/*      Release Comments   :  Released on 31-12-2004 (Patch Release 4)    */
/*      V E R S I O N      :  2.0.2    */
/*      Released By        :  PTech    */
/*      Release Comments   :  Released on  22-Jan-2004    */
/********************************************************************************/
/* procedure    : ep_layout_sp_sacthref                                         */
/* description  :                                                               */
/********************************************************************************/
/* project      : Preview                                                       */
/* version      :                                                               */
/********************************************************************************/
/* referenced   :                                                               */
/* tables       :                                                               */
/********************************************************************************/
/* development history                                                          */
/********************************************************************************/
/* author       : Shafina Begum.B                                               */
/* date         : 11/ 12/ 2003                                                  */
/********************************************************************************/
/* modification history                                                         */
/********************************************************************************/
/* modified by   : Shafina Begum.B                                              */
/* date          : 07/ Jan/ 2004                                                */
/* description   : to default the alignment , format , trail bar combos   */
/********************************************************************************/
/* modified by  : Shafina Begum.B                                               */
/* date         : 09/ 01/ 2004                                                  */
/* description  : to fetch the ui from ui_mst table                             */
/********************************************************************************/
/* modified by  : Ramanujam S                                                */
/* date         : 30-nov-2005                                                  */
/* description  : New Parameter @engg_att_ui_grid_type was added               */
/********************************************************************************/
/* Modified by : Feroz                */
/* Modified on : 08/11/06               */
/* Description : State Processing             */
/********************************************************************************/
/* modified by   : Jeya           */
/* date     : 25-nov-2008         */
/* BugId    : PNR2.0_1790          */
/***************************************************************************/
/* modified by  : Jeyalatha K            */
/* date    : 11-Feb-2011                                           */
/* Bug Id   : PNR2.0_30127           */
/* Modified for  : Feature  Release          */
/***************************************************************************************************/
/* modified by  : Ganesh Prabhu S                                      						       */
/* date         : Oct 10 2014 							  */
/* BugId        : PLF2.0_09035                                          						   */
/* description  : Model changes for rowspan,colspan,IsStatic,IsCallout in  layout level            */
/***************************************************************************************************/
/* Modified by  : Veena U                                                  */
/* Date         : 25-Feb-2015                                                  */
/* Call ID		: PLF2.0_11499                                                 */
/********************************************************************************/
/* Modified by  : Kalidas S	                                                  */
/* Date         : 03-Aug-2015                                                  */
/* Defect ID	: PLF2.0_14096                                                 */
/********************************************************************************/
/* Modified by  : Veena U	                                                  */
/* Date         : 24-Dec-2015*/
/* Defect ID	: PLF2.0_16153                                                 */
/********************************************************************************/
/* Modified by  : Veena U                                                  */
/* Date         : 24-Feb-2016                                                 */
/* Defect ID	: PLF2.0_16291                                                */
/********************************************************************************/
/* Modified by  : Veena U                                                  */
/* Date         : 28-Mar-2016                                                 */
/* Call ID		: PLF2.0_17570                                               */
/********************************************************************************/
/* modified by			Date				Defect ID							*/
/* Veena U				08-Jun-2016			PLF2.0_18487						*/
/********************************************************************************/
/* Modified by : Jeya Latha K/Ganesh Prabhu S	for callid TECH-7349				*/
/* Modified on : 14-03-2017				 											*/
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and New Feature Organization chart */
/****************************************************************************************************/
/* Modified by : Ganesh Prabhu S/Ranjitha R      Defect ID:  TECH-10118      Date : 30-May-2017		*/
/* Modified by : Jeya Latha K					 Date: 25-Jul-2019			 Defect ID: TECH-36371  */
/* Modified by : Priyadharshini U/Rajeswari M	 Date: 29-Jan-2020           Defect ID : TECH-42483	*/
/****************************************************************************************************/
/* Modified by	:	Vimal Kumar R	 																*/
/* Modified on	:	08/07/2022				 														*/
/* Defect ID	:	Tech-70687																		*/
/* Description	:	Tool and Toolbars																*/
/****************************************************************************************************/
/* Modified by : Ponmalar A						Date: 29-Aug-2022       Defect ID : Tech-72114		*/
/****************************************************************************************************/
/* Modified by    :    Ponmalar A																	*/
/* Modified on    :    02/12/22																		*/
/* Defect ID      :    TECH-75230																	*/
/* Description    : Platform Release for the Month of Nov'22										*/
/****************************************************************************************************/
CREATE PROCEDURE ep_layout_sp_sacthref
	@ctxt_language_in engg_ctxt_language,
	@ctxt_ouinstance_in engg_ctxt_ouinstance,
	@ctxt_service_in engg_ctxt_service,
	@ctxt_user_in engg_ctxt_user,
	@engg_act_descr_io engg_description,
	@engg_att_ui_cap_align_io engg_name,
	@engg_att_ui_format_io engg_description,
	@engg_att_ui_trail_bar_io engg_name,
	@engg_att_ui_type_io engg_name,
	@engg_component_io engg_description,
	@engg_customer_name_io engg_name,
	@engg_process_descr_io engg_description,
	@engg_project_name_io engg_name,
	@engg_req_no_io engg_name,
	@engg_rf_act_io engg_description,
	@engg_rf_comp_io engg_description,
	@engg_rf_ui_io engg_description,
	@engg_tab_height_io engg_length,
	@engg_att_ui_grid_type engg_type,
	@State_Processing engg_name,
	@engg_callout_type engg_type, -- added for request id: PNR2.0_1790
	@ezee_taskpane engg_name, -- Added for the Bug ID:PNR2.0_30127
	@engg_tab_type engg_name, --Input/Output
	@engg_ui_name hiddencontrol, --Input/Output --added for iruledesigner
	@_txt_interfacecontrol hiddencontrol, --Input/Output
	@engg_isdevice engg_flag, --Input/Output
	@engg_smarthide engg_flag, --Input/Output
	@engg_ilbotitle engg_flag, --Input/Output
	@engg_hdrpersonalisation engg_flag,
	@engg_syst_excl_tab_ind engg_flag,
	@engg_phone engg_flag, --Input/Output
	@engg_tablet engg_flag, --Input/Output
	@engg_desk_brw engg_flag, --Input/Output
	@engg_tab_style engg_name, --Input/Output
	@engg_ui_layout engg_name, --Input/Output
	@engg_ui_laycon engg_description, --Input/Output
	@engg_tab_hdr_pos engg_name, --Input/Output
	@engg_hide_print engg_flag, --Input/Output
	@engg_page_name engg_name, --Input/Output
	@engg_sect_name engg_name, --Input/Output
	@engg_control_name engg_name, --Input/Output
	@engg_group_name engg_name, --Input/Output
	@engg_group_caption engg_description, --Input/Output
	@engg_tab_rotate engg_name, --Input/Output
	@engg_group_seqno engg_seqno,
	@engg_hide_default engg_flag,
	@engg_uisubtype engg_name,
	@engg_nativeapp engg_flag,
	@engg_popup_close engg_flag,
	@engg_titlebar_search engg_flag,
	--Code added for TECH-70687
	@engg_att_docked	engg_name,
	@engg_att_sidebar	engg_seqno,
	@engg_lefttb		engg_seqno,
	@engg_righttb		engg_seqno,
	@engg_toptb			engg_seqno,
	@engg_bottomtb		engg_seqno,
	--Code added for TECH-70687
	--Code Added for TECH-71262 starts
	@engg_cont_sec_type_bts		engg_name,
	@engg_grid_sec_type_bts		engg_name,
	@engg_grid_ctrl_type_bts	engg_name,
	--Code Added for TECH-71262 ends
	@PullToRefresh		engg_seqno,	--Code added for TECH-75230
	@m_errorid INT OUTPUT --To Return Execution Status
AS
BEGIN
	SET NOCOUNT ON

	--declaration of temporary variables
	DECLARE @ctxt_language engg_ctxt_language
	DECLARE @ctxt_ouinstance engg_ctxt_ouinstance
	DECLARE @ctxt_service engg_ctxt_service
	DECLARE @ctxt_user engg_ctxt_user
	DECLARE @engg_act_descr engg_description
	DECLARE @engg_att_ui_cap_align engg_name
	DECLARE @engg_att_ui_format engg_description
	DECLARE @engg_att_ui_trail_bar engg_name
	DECLARE @engg_att_ui_type engg_name
	DECLARE @engg_component engg_description
	DECLARE @engg_customer_name engg_name
	DECLARE @engg_process_descr engg_description
	DECLARE @engg_project_name engg_name
	DECLARE @engg_req_no engg_name
	DECLARE @engg_rf_act engg_description
	DECLARE @engg_rf_comp engg_description
	DECLARE @engg_rf_ui engg_description
	DECLARE @engg_tab_height engg_length

	--temporary and formal parameters mapping
	SELECT @ctxt_language = @ctxt_language_in

	SELECT @ctxt_ouinstance = @ctxt_ouinstance_in

	SELECT @ctxt_service = ltrim(rtrim(@ctxt_service_in))

	SELECT @ctxt_user = ltrim(rtrim(@ctxt_user_in))

	SELECT @engg_act_descr = ltrim(rtrim(@engg_act_descr_io))

	SELECT @engg_att_ui_cap_align = ltrim(rtrim(@engg_att_ui_cap_align_io))

	SELECT @engg_att_ui_format = ltrim(rtrim(@engg_att_ui_format_io))

	SELECT @engg_att_ui_trail_bar = ltrim(rtrim(@engg_att_ui_trail_bar_io))

	SELECT @engg_att_ui_type = ltrim(rtrim(@engg_att_ui_type_io))

	SELECT @engg_component = ltrim(rtrim(@engg_component_io))

	SELECT @engg_customer_name = ltrim(rtrim(@engg_customer_name_io))

	SELECT @engg_process_descr = ltrim(rtrim(@engg_process_descr_io))

	SELECT @engg_project_name = ltrim(rtrim(@engg_project_name_io))

	SELECT @engg_req_no = ltrim(rtrim(@engg_req_no_io))

	SELECT @engg_rf_act = ltrim(rtrim(@engg_rf_act_io))

	SELECT @engg_rf_comp = ltrim(rtrim(@engg_rf_comp_io))

	SELECT @engg_rf_ui = ltrim(rtrim(@engg_rf_ui_io))

	SELECT @engg_tab_height = @engg_tab_height_io

	SELECT @engg_att_ui_grid_type = ltrim(rtrim(@engg_att_ui_grid_type))

	SELECT @State_Processing = ltrim(rtrim(@State_Processing))

	SELECT @engg_callout_type = ltrim(rtrim(@engg_callout_type)) -- added for request id: PNR2.0_1790

	SELECT @ezee_taskpane = ltrim(rtrim(@ezee_taskpane)) -- Added for the Bug ID:PNR2.0_30127

	SELECT @engg_tab_type = LTRIM(RTRIM(@engg_tab_type))

	SELECT @engg_isdevice = ltrim(rtrim(@engg_isdevice))

	SELECT @engg_smarthide = ltrim(rtrim(@engg_smarthide))

	SELECT @engg_ilbotitle = ltrim(rtrim(@engg_ilbotitle))

	SELECT @engg_hdrpersonalisation = ltrim(rtrim(@engg_hdrpersonalisation))

	SELECT @engg_syst_excl_tab_ind = ltrim(rtrim(@engg_syst_excl_tab_ind))

	SELECT @engg_phone = ltrim(rtrim(@engg_phone))

	SELECT @engg_tablet = ltrim(rtrim(@engg_tablet))

	SELECT @engg_desk_brw = ltrim(rtrim(@engg_desk_brw))

	SELECT @engg_tab_style = ltrim(rtrim(@engg_tab_style))

	SELECT @engg_hide_print = ltrim(rtrim(@engg_hide_print))

	SELECT @engg_ui_layout = ltrim(rtrim(@engg_ui_layout))

	SELECT @engg_ui_layCon = ltrim(rtrim(@engg_ui_layCon))

	SELECT @engg_tab_hdr_pos = ltrim(rtrim(@engg_tab_hdr_pos))

	SELECT @engg_phone = ltrim(rtrim(@engg_phone))

	SELECT @engg_tablet = ltrim(rtrim(@engg_tablet))

	SELECT @engg_desk_brw = ltrim(rtrim(@engg_desk_brw))

	SELECT @engg_tab_style = ltrim(rtrim(@engg_tab_style))

	SELECT @engg_ui_layout = ltrim(rtrim(@engg_ui_layout))

	SELECT @engg_ui_laycon = ltrim(rtrim(@engg_ui_laycon))

	SELECT @engg_tab_hdr_pos = ltrim(rtrim(@engg_tab_hdr_pos))

	SELECT @engg_hide_print = ltrim(rtrim(@engg_hide_print))

	SELECT @engg_page_name = ltrim(rtrim(@engg_page_name))

	SELECT @engg_sect_name = ltrim(rtrim(@engg_sect_name))

	SELECT @engg_control_name = ltrim(rtrim(@engg_control_name))

	SELECT @engg_group_name = ltrim(rtrim(@engg_group_name))

	SELECT @engg_group_caption = ltrim(rtrim(@engg_group_caption))

	SELECT @engg_tab_rotate = LTRIM(rtrim(@engg_tab_rotate))

	SELECT @engg_hide_default = LTRIM(rtrim(@engg_hide_default))

	SELECT @engg_uisubtype = LTRIM(rtrim(@engg_uisubtype))

	SELECT @engg_nativeapp = LTRIM(rtrim(@engg_nativeapp))

	SELECT @engg_popup_close = LTRIM(rtrim(@engg_popup_close))
	--Code Added for TECH-71262 starts
	SELECT @engg_cont_sec_type_bts = LTRIM(rtrim(@engg_cont_sec_type_bts))	

	SELECT @engg_grid_sec_type_bts = LTRIM(rtrim(@engg_grid_sec_type_bts))	

	SELECT @engg_grid_ctrl_type_bts = LTRIM(rtrim(@engg_grid_ctrl_type_bts))
	--Code Added for TECH-71262 ends
	--null checking
	IF @ctxt_language = - 915
		SELECT @ctxt_language = NULL

	IF @ctxt_ouinstance = - 915
		SELECT @ctxt_ouinstance = NULL

	IF @ctxt_service = '~#~'
		SELECT @ctxt_service = NULL

	IF @ctxt_user = '~#~'
		SELECT @ctxt_user = NULL

	IF @engg_act_descr = '~#~'
		SELECT @engg_act_descr = NULL

	IF @engg_att_ui_cap_align = '~#~'
		SELECT @engg_att_ui_cap_align = NULL

	IF @engg_att_ui_format = '~#~'
		SELECT @engg_att_ui_format = NULL

	IF @engg_att_ui_trail_bar = '~#~'
		SELECT @engg_att_ui_trail_bar = NULL

	IF @engg_att_ui_type = '~#~'
		SELECT @engg_att_ui_type = NULL

	IF @engg_component = '~#~'
		SELECT @engg_component = NULL

	IF @engg_customer_name = '~#~'
		SELECT @engg_customer_name = NULL

	IF @engg_process_descr = '~#~'
		SELECT @engg_process_descr = NULL

	IF @engg_project_name = '~#~'
		SELECT @engg_project_name = NULL

	IF @engg_req_no = '~#~'
		SELECT @engg_req_no = NULL

	IF @engg_rf_act = '~#~'
		SELECT @engg_rf_act = NULL

	IF @engg_rf_comp = '~#~'
		SELECT @engg_rf_comp = NULL

	IF @engg_rf_ui = '~#~'
		SELECT @engg_rf_ui = NULL

	IF @engg_tab_height = - 915
		SELECT @engg_tab_height = NULL

	IF @engg_att_ui_grid_type = '~#~'
		SELECT @engg_att_ui_grid_type = NULL

	IF @State_Processing = '~#~'
		SELECT @State_Processing = NULL

	-- added for request id: PNR2.0_1790
	IF @engg_callout_type = '~#~'
		SELECT @engg_callout_type = NULL

	-- Added for the Bug ID:PNR2.0_30127
	IF @ezee_taskpane = '~#~'
		SELECT @ezee_taskpane = NULL

	IF @engg_tab_type = '~#~'
		SELECT @engg_tab_type = NULL

	IF @engg_ui_name = '~#~'
		SELECT @engg_ui_name = NULL

	IF @_txt_interfacecontrol = '~#~'
		SELECT @_txt_interfacecontrol = NULL

	IF @engg_isdevice = '~#~'
		SELECT @engg_isdevice = NULL

	IF @engg_smarthide = '~#~'
		SELECT @engg_smarthide = NULL

	IF @engg_ilbotitle = '~#~'
		SELECT @engg_ilbotitle = NULL

	IF @engg_hdrpersonalisation = '~#~'
		SELECT @engg_hdrpersonalisation = NULL

	IF @engg_syst_excl_tab_ind = '~#~'
		SELECT @engg_syst_excl_tab_ind = NULL

	IF @engg_phone = '~#~'
		SELECT @engg_phone = NULL

	IF @engg_tablet = '~#~'
		SELECT @engg_tablet = NULL

	IF @engg_desk_brw = '~#~'
		SELECT @engg_desk_brw = NULL

	IF @engg_tab_style = '~#~'
		SELECT @engg_tab_style = NULL

	IF @engg_tab_hdr_pos = '~#~'
		SELECT @engg_tab_hdr_pos = NULL

	IF @engg_tab_style = '~#~'
		SELECT @engg_tab_style = NULL

	IF @engg_hide_print = '~#~'
		SELECT @engg_hide_print = NULL

	IF @engg_ui_layout = '~#~'
		SELECT @engg_ui_layout = NULL

	IF @engg_ui_layCon = '~#~'
		SELECT @engg_ui_layCon = NULL

	IF @engg_tab_hdr_pos = '~#~'
		SELECT @engg_tab_hdr_pos = NULL

	IF @engg_phone = '~#~'
		SELECT @engg_phone = NULL

	IF @engg_tablet = '~#~'
		SELECT @engg_tablet = NULL

	IF @engg_desk_brw = '~#~'
		SELECT @engg_desk_brw = NULL

	IF @engg_tab_style = '~#~'
		SELECT @engg_tab_style = NULL

	IF @engg_ui_layout = '~#~'
		SELECT @engg_ui_layout = NULL

	IF @engg_ui_laycon = '~#~'
		SELECT @engg_ui_laycon = NULL

	IF @engg_tab_hdr_pos = '~#~'
		SELECT @engg_tab_hdr_pos = NULL

	IF @engg_hide_print = '~#~'
		SELECT @engg_hide_print = NULL

	IF @engg_page_name = '~#~'
		SELECT @engg_page_name = NULL

	IF @engg_sect_name = '~#~'
		SELECT @engg_sect_name = NULL

	IF @engg_control_name = '~#~'
		SELECT @engg_control_name = NULL

	IF @engg_group_name = '~#~'
		SELECT @engg_group_name = NULL

	IF @engg_group_caption = '~#~'
		SELECT @engg_group_caption = NULL

	IF @engg_tab_rotate = '~#~'
		SELECT @engg_tab_rotate = NULL

	IF @engg_group_seqno = - 915
		SELECT @engg_group_seqno = NULL

	IF @engg_hide_default = - 915
		SELECT @engg_hide_default = NULL

	IF @engg_uisubtype = '~#~'
		SELECT @engg_uisubtype = NULL

	IF @engg_nativeapp = '~#~'
		SELECT @engg_nativeapp = NULL

	IF @engg_popup_close = '~#~'
		SELECT @engg_popup_close = NULL

	IF @engg_titlebar_search = '~#~'
		SELECT @engg_titlebar_search = NULL
		--Code Added for TECH-71262 starts
	IF @engg_cont_sec_type_bts = '~#~'
		SELECT @engg_cont_sec_type_bts = NULL

	IF @engg_grid_sec_type_bts = '~#~'
		SELECT @engg_grid_sec_type_bts = NULL

	IF @engg_grid_ctrl_type_bts = '~#~'
		SELECT @engg_grid_ctrl_type_bts = NULL
		--Code Added for TECH-71262 ends
	--errors mapped
	DECLARE @tmp_comp_name engg_name,
		@tmp_proc engg_name,
		@tmp_acty_name engg_name,
		@tmp_ui_name engg_name,
		@tmp_ref_comp_name engg_name,
		@tmp_ref_acty_name engg_name,
		@tmp_ref_ui_name engg_name,
		@tmp_ref_comp_desc engg_description,
		@tmp_ref_acty_desc engg_description,
		@tmp_ref_ui_desc engg_description,
		@tmp_cap_align engg_name,
		@tmp_ui_format engg_description,
		@tmp_trail_bar engg_name,
		@tmp_ui_type engg_name,
		@tmp_tab_height INT,
		@tmp_uisubtype engg_name,
		@engg_base_req_no engg_name,
		-- Added for PLF2.0_14096 Starts
		@smarthide engg_name,
		@isdevice engg_name,
		@ilbotitle engg_name,
		@personalisation engg_name,
		@exclude_syst_tab_ind engg_name
		-- Added for PLF2.0_14096 ends
		,
		@enggphone engg_name,
		@enggtablet engg_name,
		@enggtabstyle engg_name,
		@isDesktop engg_flag

	SELECT @engg_base_req_no = 'BASE'

	--select process name for description
	SELECT @tmp_proc = rtrim(process_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_req_no)
		AND process_descr = rtrim(@engg_process_descr)

	--select component name for description
	SELECT @tmp_comp_name = rtrim(component_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_descr = rtrim(@engg_component)

	--select activity name for description
	SELECT @tmp_acty_name = rtrim(activity_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp_name)
		AND activity_descr = rtrim(@engg_act_descr)

	--select UI name for description
	SELECT @tmp_ui_name = min(rtrim(ui_name))
	--modified by shafina on 09-jan-2004 to fetch the ui from ui_mst table
	--modified by shafina on 08-oct-2004 to fetch the ui from ep_ui_req_dtl table
	FROM ep_ui_req_dtl(NOLOCK)
	-- from ep_ui_mst (nolock)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND process_name = rtrim(@tmp_proc)
		--modified by shafina on 16-jan-2004 comment the req_no condition
		AND req_no = rtrim(@engg_req_no)
		AND component_name = rtrim(@tmp_comp_name)
		AND activity_name = rtrim(@tmp_acty_name)

	/*get ref comp name , ref acty name , ref ui name for the selected ui*/
	SELECT @tmp_ref_comp_name = isnull(rtrim(base_component_name), ''),
		@tmp_ref_acty_name = isnull(rtrim(base_activity_name), ''),
		@tmp_ref_ui_name = isnull(rtrim(base_ui_name), '')
	-- from ep_ui_req_dtl (nolock)
	FROM ep_ui_mst(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_base_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp_name)
		AND activity_name = rtrim(@tmp_acty_name)
		AND ui_name = rtrim(@tmp_ui_name)

	/*fetch desc for ref comp name*/
	SELECT @tmp_ref_comp_desc = isnull(rtrim(component_descr), '')
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		-- code modified by shafina on 31-Dec-2004 for PREVIEWENG203ACC_000118 (Refernce UI is fetched incorrectly.)
		-- and  req_no    = rtrim(@engg_base_req_no)
		AND component_name = rtrim(@tmp_ref_comp_name)

	/*fetch desc for ref acty*/
	SELECT @tmp_ref_acty_desc = isnull(rtrim(activity_descr), '')
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		-- and  req_no    = rtrim(@engg_base_req_no)
		AND component_name = rtrim(@tmp_ref_comp_name)
		AND activity_name = rtrim(@tmp_ref_acty_name)

	/*fetch desc for ref ui*/
	SELECT @tmp_ref_ui_desc = isnull(rtrim(ui_descr), '')
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		-- and  req_no    = rtrim(@engg_base_req_no)
		AND component_name = rtrim(@tmp_ref_comp_name)
		AND activity_name = rtrim(@tmp_ref_acty_name)
		AND ui_name = rtrim(@tmp_ref_ui_name)

	-- code modified by shafina on 07-Jan-2004 to default the alignment , format , trail bar combos
	/*fetch caption_alignment for the UI*/
	SELECT @tmp_cap_align = CASE 
			WHEN upper(rtrim(caption_alignment)) = 'CENT'
				THEN 'center'
			ELSE isnull(caption_alignment, '')
			END
	FROM ep_ui_mst a(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_base_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp_name)
		AND activity_name = rtrim(@tmp_acty_name)
		AND ui_name = rtrim(@tmp_ui_name)

	/*fetch ui_format for the UI*/
	SELECT @tmp_ui_format = CASE 
			WHEN upper(rtrim(ui_format)) = 'BES'
				THEN 'controls beside captions'
			WHEN upper(rtrim(ui_format)) = 'UND'
				THEN 'controls under captions'
			WHEN upper(rtrim(ui_format)) = 'Top' --TECH-72114
				THEN 'Top Inner'
			ELSE isnull(ui_format, '')
			END
	FROM ep_ui_mst a(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_base_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp_name)
		AND activity_name = rtrim(@tmp_acty_name)
		AND ui_name = rtrim(@tmp_ui_name)

	/*fetch trail_bar for the UI*/
	SELECT @tmp_trail_bar = CASE 
			WHEN upper(rtrim(trail_bar)) = 'BOTT'
				THEN 'bottom'
			ELSE isnull(trail_bar, '')
			END
	FROM ep_ui_mst a(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_base_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp_name)
		AND activity_name = rtrim(@tmp_acty_name)
		AND ui_name = rtrim(@tmp_ui_name)

	IF @tmp_cap_align IS NULL
	BEGIN
		SELECT @tmp_cap_align = current_value
		FROM es_comp_param_mst_vw(NOLOCK)
		WHERE customer_name = rtrim(@engg_customer_name)
			AND project_name = rtrim(@engg_project_name)
			AND req_no = rtrim(@engg_req_no)
			AND process_name = rtrim(@tmp_proc)
			AND component_name = rtrim(@tmp_comp_name)
			AND upper(param_category) = 'CAPTIONALIGN'
			AND upper(param_type) = 'UIFORMAT'
	END

	IF @tmp_ui_format IS NULL
	BEGIN
		SELECT @tmp_ui_format = current_value
		FROM es_comp_param_mst_vw(NOLOCK)
		WHERE customer_name = rtrim(@engg_customer_name)
			AND project_name = rtrim(@engg_project_name)
			AND req_no = rtrim(@engg_req_no)
			AND process_name = rtrim(@tmp_proc)
			AND component_name = rtrim(@tmp_comp_name)
			AND upper(param_category) = 'CAPTIONFORMAT'
			AND upper(param_type) = 'UIFORMAT'
	END

	IF @tmp_trail_bar IS NULL
	BEGIN
		SELECT @tmp_trail_bar = current_value
		FROM es_comp_param_mst_vw(NOLOCK)
		WHERE customer_name = rtrim(@engg_customer_name)
			AND project_name = rtrim(@engg_project_name)
			AND req_no = rtrim(@engg_req_no)
			AND process_name = rtrim(@tmp_proc)
			AND component_name = rtrim(@tmp_comp_name)
			AND upper(param_category) = 'TRAILBAR'
			AND upper(param_type) = 'UIFORMAT'
	END

	/*fetch UI type for the UI*/
	SELECT @tmp_ui_type = isnull(ui_type, '')
	FROM ep_ui_mst a(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_base_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp_name)
		AND activity_name = rtrim(@tmp_acty_name)
		AND ui_name = rtrim(@tmp_ui_name)

	/*fetch tab height for the UI*/
	--code modified by chanheetha on 22-Dec-2005
	SELECT @tmp_tab_height = tab_height
	--code modified by chanheetha on 22-Dec-2005
	FROM ep_ui_mst a(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_base_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp_name)
		AND activity_name = rtrim(@tmp_acty_name)
		AND ui_name = rtrim(@tmp_ui_name)

	SELECT @tmp_uisubtype = ui_subtype
	--code modified by chanheetha on 22-Dec-2005
	FROM ep_ui_mst a(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_base_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp_name)
		AND activity_name = rtrim(@tmp_acty_name)
		AND ui_name = rtrim(@tmp_ui_name)

	---added by Ramanujam on nov-30-2005
	SELECT @engg_att_ui_grid_type = isnull(grid_type, 'HTM'),
		@State_Processing = isnull(State_Processing, 'No'),
		@engg_callout_type = isnull(callout_type, 'None'), -- added for request id: PNR2.0_1790
		@ezee_taskpane = isnull(taskpane_req, 'No') -- Added for the Bug ID:PNR2.0_30127
	FROM ep_ui_mst a(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name_io)
		AND project_name = rtrim(@engg_project_name_io)
		AND req_no = rtrim(@engg_base_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp_name)
		AND activity_name = rtrim(@tmp_acty_name)
		AND ui_name = rtrim(@tmp_ui_name)

	---added by Ramanujam Ends
	SELECT @engg_tab_type = quick_code_value
	FROM ep_ui_mst a(NOLOCK),
		ep_quick_code_mst b(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name_io)
		AND project_name = rtrim(@engg_project_name_io)
		AND req_no = rtrim(@engg_base_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp_name)
		AND activity_name = rtrim(@tmp_acty_name)
		AND ui_name = rtrim(@tmp_ui_name)
		AND Tab_Type = b.quick_code

	-- Added for PLF2.0_14096 Starts
	-- smarthide,isdevice,ilbotitle
	SELECT @smarthide = SmartHide,
		@isdevice = Is_device,
		@ilbotitle = HideIlbotitlemenu_req,
		@personalisation = personalization,
		@exclude_syst_tab_ind = Exclude_Systemtabindex --PLF2.0_16291 
		,
		@enggphone = DeviceType,
		@enggtablet = DeviceType,
		@enggtabstyle = TabStyle,
		@isDesktop = IsDesktop,
		@engg_nativeapp = NativeApplication,
		@engg_popup_close = Conditional_popupclose,
		@engg_titlebar_search = Titlebar_Search,
		@engg_ui_laycon = CASE 
			WHEN Layout = 'abs'
				THEN isnull(XYCoordinates, '')
			WHEN Layout = 'col'
				THEN isnull(ColumnLayWidth, '')
			ELSE NULL
			END,
		--Code added for TECH-70687 starts
		@engg_att_docked		=      Docked,
		@engg_att_sidebar		=		CASE
										WHEN isnull(Sidebar,'N') = 'Y' THEN 1
										ELSE 0
										END,
		@engg_lefttb			=		CASE
										WHEN isnull(LeftToolbar,'N') = 'Y' THEN 1
										ELSE 0
										END,
		@engg_righttb			=		CASE
										WHEN isnull(RightToolbar,'N') = 'Y' THEN 1
										ELSE 0
										END,
		@engg_toptb				=		CASE
										WHEN isnull(TopToolbar,'N') = 'Y' THEN 1
										ELSE 0
										END,
		@engg_bottomtb			=		CASE
										WHEN isnull(BottomToolbar,'N') = 'Y' THEN 1
										ELSE 0
										END,
		--Code added for TECH-70687 ends
		@PullToRefresh			=		CASE		--Code added for TECH-75230
										WHEN isnull(PullToRefresh,'N') = 'Y' THEN 1
										ELSE 0
										END
	FROM ep_ui_mst(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name_io)
		AND project_name = rtrim(@engg_project_name_io)
		AND req_no = rtrim(@engg_base_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp_name)
		AND activity_name = rtrim(@tmp_acty_name)
		AND ui_name = rtrim(@tmp_ui_name)
		
	-- Added for PLF2.0_14096 ends
	SELECT @enggtabstyle = parameter_text
	FROM ep_device_quick_code_met(NOLOCK)
	WHERE parameter_type = 'TabStyle'
		AND parameter_code = @enggtabstyle

	SELECT @engg_ui_layout = isnull(lay.parameter_text, ''),
		@engg_tab_hdr_pos = isnull(hdrpos.parameter_text, ''),
		@engg_tab_rotate = ISNULL(Tabrot.parameter_text, '')
	FROM ep_ui_mst a(NOLOCK)
	LEFT JOIN ep_device_quick_code_met lay(NOLOCK) ON a.Layout = lay.parameter_code
		AND lay.parameter_type = 'UILayout'
	LEFT JOIN ep_device_quick_code_met hdrpos(NOLOCK) ON a.TabPosition = hdrpos.parameter_code --code addded by 11742
		AND hdrpos.parameter_type = 'HeaderPosition'
	LEFT JOIN ep_device_quick_code_met Tabrot(NOLOCK) ON a.TabRotation = tabrot.parameter_code
		AND tabrot.parameter_type = 'TabRotation'
	WHERE customer_name = rtrim(@engg_customer_name_io)
		AND project_name = rtrim(@engg_project_name_io)
		AND req_no = rtrim(@engg_base_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp_name)
		AND activity_name = rtrim(@tmp_acty_name)
		AND ui_name = rtrim(@tmp_ui_name)

	----------------Fetch for Column Grouping
	SELECT TOP 1 @engg_page_name = rtrim(p.page_bt_synonym)
	FROM ep_ui_page_dtl p(NOLOCK)
	WHERE p.customer_name = rtrim(@engg_customer_name)
		AND p.project_name = rtrim(@engg_project_name)
		AND p.req_no = rtrim(@engg_base_req_no)
		AND p.process_name = rtrim(@tmp_proc)
		AND p.component_name = rtrim(@tmp_comp_name)
		AND p.activity_name = rtrim(@tmp_acty_name)
		AND p.ui_name = rtrim(@tmp_ui_name)
		AND p.page_bt_synonym IN (
			SELECT c.page_bt_synonym
			FROM ep_ui_control_dtl c(NOLOCK),
				es_comp_ctrl_type_mst_vw v(NOLOCK)
			WHERE p.customer_name = c.customer_name
				AND p.project_name = c.project_name
				AND p.process_name = c.process_name
				AND p.component_name = c.component_name
				AND p.activity_name = c.activity_name
				AND p.ui_name = c.ui_name
				AND p.page_bt_synonym = c.page_bt_synonym
				AND c.customer_name = v.customer_name
				AND c.project_name = v.project_name
				AND c.process_name = v.process_name
				AND c.component_name = v.component_name
				AND c.control_type = v.ctrl_type_name
				AND v.base_ctrl_type IN (
					'Grid',
					'TreeGrid'
					)
				AND isnull(IsAssorted, 'N') = 'N'
			)
	ORDER BY p.horder,
		p.vorder

	SELECT @engg_sect_name = min(s.section_bt_synonym),
		   @engg_cont_sec_type_bts = MIN(s.section_type)		--Code Added for TECH-71262
	FROM ep_ui_section_dtl s(NOLOCK),
		ep_ui_control_dtl c(NOLOCK),
		es_comp_ctrl_type_mst_vw v(NOLOCK)
	WHERE s.customer_name = rtrim(@engg_customer_name)
		AND s.project_name = rtrim(@engg_project_name)
		AND s.req_no = rtrim(@engg_base_req_no)
		AND s.process_name = rtrim(@tmp_proc)
		AND s.component_name = rtrim(@tmp_comp_name)
		AND s.activity_name = rtrim(@tmp_acty_name)
		AND s.ui_name = rtrim(@tmp_ui_name)
		AND s.page_bt_synonym = rtrim(@engg_page_name)
		AND s.customer_name = c.customer_name
		AND s.project_name = c.project_name
		AND s.process_name = c.process_name
		AND s.component_name = c.component_name
		AND s.activity_name = c.activity_name
		AND s.ui_name = c.ui_name
		AND s.page_bt_synonym = c.page_bt_synonym
		AND s.section_bt_synonym = c.section_bt_synonym
		AND c.customer_name = v.customer_name
		AND c.project_name = v.project_name
		AND c.process_name = v.process_name
		AND c.component_name = v.component_name
		AND c.control_type = v.ctrl_type_name
		AND v.base_ctrl_type IN (
			'Grid',
			'TreeGrid'
			)
		AND s.section_bt_synonym NOT IN (
			'PrjHdnSection',
			'[tabcontrol]',
			'hdnrt_stsection'
			)
		AND s.section_type NOT IN (
			'Tree',
			'chart',
			'Tree Grid'
			)
		AND isnull(IsAssorted, 'N') = 'N'

		--Code Added for TECH-71262 starts
	SELECT @engg_grid_sec_type_bts = MIN(s.section_type)		
	FROM ep_ui_section_dtl s(NOLOCK),
		ep_ui_control_dtl c(NOLOCK),
		es_comp_ctrl_type_mst_vw v(NOLOCK)
	WHERE s.customer_name = rtrim(@engg_customer_name)
		AND s.project_name = rtrim(@engg_project_name)
		AND s.req_no = rtrim(@engg_base_req_no)
		AND s.process_name = rtrim(@tmp_proc)
		AND s.component_name = rtrim(@tmp_comp_name)
		AND s.activity_name = rtrim(@tmp_acty_name)
		AND s.ui_name = rtrim(@tmp_ui_name)
		AND s.page_bt_synonym = rtrim(@engg_page_name)
		AND s.customer_name = c.customer_name
		AND s.project_name = c.project_name
		AND s.process_name = c.process_name
		AND s.component_name = c.component_name
		AND s.activity_name = c.activity_name
		AND s.ui_name = c.ui_name
		AND s.page_bt_synonym = c.page_bt_synonym
		AND s.section_bt_synonym = c.section_bt_synonym
		AND c.customer_name = v.customer_name
		AND c.project_name = v.project_name
		AND c.process_name = v.process_name
		AND c.component_name = v.component_name
		AND c.control_type = v.ctrl_type_name
		AND v.base_ctrl_type IN (
			'Grid',
			'TreeGrid'
			)
		AND s.section_bt_synonym = @engg_sect_name
		AND s.section_type NOT IN (
			'Tree',
			'chart',
			'Tree Grid'
			)
		AND ISNULL(IsAssorted, 'N') = 'N'
		--Code Added for TECH-71262 ends

	SELECT TOP 1 @engg_control_name = rtrim(a.control_bt_synonym),
				 @engg_grid_ctrl_type_bts = RTRIM(a.control_type)			--Code Added for TECH-71262
	FROM ep_ui_control_dtl a(NOLOCK),
		es_comp_ctrl_type_mst_vw b(NOLOCK)
	WHERE a.customer_name = rtrim(@engg_customer_name)
		AND a.project_name = rtrim(@engg_project_name)
		AND a.req_no = rtrim(@engg_base_req_no)
		AND a.process_name = rtrim(@tmp_proc)
		AND a.component_name = rtrim(@tmp_comp_name)
		AND a.activity_name = rtrim(@tmp_acty_name)
		AND a.ui_name = rtrim(@tmp_ui_name)
		AND a.page_bt_synonym = rtrim(@engg_page_name)
		AND a.section_bt_synonym = rtrim(@engg_sect_name)
		AND b.customer_name = a.customer_name
		AND b.project_name = a.project_name
		AND b.process_name = a.process_name
		AND b.component_name = a.component_name
		AND a.control_type = b.ctrl_type_name
		AND b.base_ctrl_type IN (
			'Grid',
			'TreeGrid'
			)
		AND isnull(IsAssorted, 'N') = 'N'
	ORDER BY a.control_bt_synonym

	SELECT TOP 1 @engg_group_caption = LTRIM(rtrim(Group_caption)),
		@engg_group_name = LTRIM(rtrim(Group_name)),
		@engg_group_seqno = isnull(groupseqno, 0)
	FROM ep_ui_columngroup(NOLOCK)
	WHERE customer_name = @engg_customer_name_io
		AND project_name = @engg_project_name_io
		AND process_name = @tmp_proc
		AND component_name = @tmp_comp_name
		AND activity_name = @tmp_acty_name
		AND ui_name = @tmp_ui_name
		AND page_bt_synonym = @engg_page_name
		AND section_bt_synonym = @engg_sect_name
		AND grid_control_bt_synonym = @engg_control_name
	ORDER BY 3

	--output parameters  
	/*fetch the ui attributes for the selected ui and display in the respective controls.*/
	SELECT rtrim(@engg_act_descr) 'engg_act_descr_io', /* DOTNET Migration Tool Changes */
		rtrim(@tmp_cap_align) 'engg_att_ui_cap_align_io', /* DOTNET Migration Tool Changes */
		rtrim(@tmp_ui_format) 'engg_att_ui_format_io', /* DOTNET Migration Tool Changes */
		rtrim(@tmp_trail_bar) 'engg_att_ui_trail_bar_io', /* DOTNET Migration Tool Changes */
		rtrim(@tmp_ui_type) 'engg_att_ui_type_io', /* DOTNET Migration Tool Changes */
		rtrim(@engg_component) 'engg_component_io', /* DOTNET Migration Tool Changes */
		rtrim(@engg_customer_name) 'engg_customer_name_io', /* DOTNET Migration Tool Changes */
		rtrim(@engg_process_descr) 'engg_process_descr_io', /* DOTNET Migration Tool Changes */
		rtrim(@engg_project_name) 'engg_project_name_io', /* DOTNET Migration Tool Changes */
		rtrim(@engg_req_no) 'engg_req_no_io', /* DOTNET Migration Tool Changes */
		isnull(@tmp_ref_acty_desc, '') 'engg_rf_act_io', /* DOTNET Migration Tool Changes */
		isnull(@tmp_ref_comp_desc, '') 'engg_rf_comp_io', /* DOTNET Migration Tool Changes */
		isnull(@tmp_ref_ui_desc, '') 'engg_rf_ui_io', /* DOTNET Migration Tool Changes */
		rtrim(@tmp_tab_height) 'engg_tab_height_io', /* DOTNET Migration Tool Changes */
		rtrim(@tmp_uisubtype) 'engg_uisubtype', /* DOTNET Migration Tool Changes */
		NULL 'fprowno',
		@engg_att_ui_grid_type 'engg_att_ui_grid_type',
		@State_Processing 'State_Processing',
		@engg_callout_type 'engg_callout_type', -- added for request id: PNR2.0_1790  
		@ezee_taskpane 'ezee_taskpane', -- Added for the Bug ID:PNR2.0_30127  
		rtrim(@tmp_ui_name) 'engg_ui_name', --Added for irule designer  
		'002' '_txt_interfacecontrol',
		@engg_tab_type 'engg_tab_type',
		CASE 
			WHEN @engg_nativeapp = 'y'
				THEN 1
			ELSE 0
			END 'engg_nativeapp',
		CASE 
			WHEN @engg_popup_close = 'y'
				THEN 1
			ELSE 0
			END 'engg_popup_close',
		-- Added for PLF2.0_14096 Starts
		CASE 
			WHEN @smarthide = 'y'
				THEN 1
			ELSE 0
			END 'engg_smarthide',
		CASE 
			WHEN @isdevice = 'y'
				THEN 1
			ELSE 0
			END 'engg_isdevice',
		CASE 
			WHEN @ilbotitle = 'y'
				THEN 1
			ELSE 0
			END 'engg_ilbotitle',
		CASE 
			WHEN @personalisation = 'y'
				THEN 1
			ELSE 0
			END 'engg_hdrpersonalisation',
		CASE 
			WHEN @exclude_syst_tab_ind = 'y'
				THEN 1
			ELSE 0
			END 'engg_syst_excl_tab_ind' --PLF2.0_16291 
		-- Added for PLF2.0_14096 ends
		,
		CASE 
			WHEN @isDesktop = 'y'
				THEN 1
			ELSE 0
			END 'engg_desk_brw', --- PLF2.0_17570
		CASE 
			WHEN @enggphone IN (
					'P',
					'B'
					)
				THEN 1
			ELSE 0
			END 'engg_phone',
		CASE 
			WHEN @enggtablet IN (
					'T',
					'B'
					)
				THEN 1
			ELSE 0
			END 'engg_tablet',
		CASE 
			WHEN @engg_titlebar_search = 'Y' THEN 1
			ELSE 0 END			'engg_titlebar_search',
		isnull(@enggtabstyle, '') 'engg_tab_style',
		isnull(@engg_ui_layout, '') 'engg_ui_layout',
		isnull(@engg_ui_laycon, '') 'engg_ui_laycon',
		isnull(@engg_tab_hdr_pos, '') 'engg_tab_hdr_pos',
		isnull(@engg_hide_print, '') 'engg_hide_print',
		isnull(@engg_page_name, '') 'engg_page_name',
		ISNULL(@engg_sect_name, '') 'engg_sect_name',
		ISNULL(@engg_control_name, '') 'engg_control_name',
		ISNULL(@engg_group_name, '') 'engg_group_name',
		ISNULL(@engg_group_caption, '') 'engg_group_caption',
		'' 'engg_new_group_cap',
		'' 'engg_new_group_name',
		@engg_tab_rotate 'engg_tab_rotate',
		@engg_group_seqno 'engg_group_seqno',
		isnull(@engg_hide_default, 'N') 'engg_hide_default',
		--Tech-70687
        @engg_lefttb		'engg_lefttb',
        @engg_righttb		'engg_righttb',
        @engg_toptb			'engg_toptb',
        @engg_bottomtb		'engg_bottomtb',
		@engg_att_sidebar	'engg_att_sidebar',
		@engg_att_docked	'engg_att_docked',
        --Tech-70687
		--Code Added for TECH-71262 starts
		@engg_cont_sec_type_bts		'engg_cont_sec_type_bts',
		@engg_grid_ctrl_type_bts	'engg_grid_ctrl_type_bts',
		@engg_grid_sec_type_bts		'engg_grid_sec_type_bts',	
		--Code Added for TECH-71262 ends
		@PullToRefresh		'PullToRefresh' --Code added for TECH-75230
	--output parameters  
	--  select  engg_act_descr                'engg_act_descr_io', /* DOTNET Migration Tool Changes */  
	--    engg_att_ui_cap_align         'engg_att_ui_cap_align_io', /* DOTNET Migration Tool Changes */  
	--    engg_att_ui_format            'engg_att_ui_format_io', /* DOTNET Migration Tool Changes */  
	--    engg_att_ui_trail_bar         'engg_att_ui_trail_bar_io', /* DOTNET Migration Tool Changes */  
	--    engg_att_ui_type              'engg_att_ui_type_io', /* DOTNET Migration Tool Changes */  
	--    engg_component                'engg_component_io', /* DOTNET Migration Tool Changes */  
	--    engg_customer_name            'engg_customer_name_io', /* DOTNET Migration Tool Changes */  
	--    engg_process_descr            'engg_process_descr_io', /* DOTNET Migration Tool Changes */  
	--    engg_project_name             'engg_project_name_io', /* DOTNET Migration Tool Changes */  
	--    engg_req_no                   'engg_req_no_io', /* DOTNET Migration Tool Changes */  
	--    engg_rf_act                   'engg_rf_act_io', /* DOTNET Migration Tool Changes */  
	--    engg_rf_comp                  'engg_rf_comp_io', /* DOTNET Migration Tool Changes */  
	--    engg_rf_ui                    'engg_rf_ui_io', /* DOTNET Migration Tool Changes */  
	--    engg_tab_height               'engg_tab_height_io', /* DOTNET Migration Tool Changes */  
	--    fprowno                       'fprowno'
	--		null 'engg_isdevice', 
	--		null 'engg_smarthide', 
	--		null 'engg_ilbotitle', 
	SET NOCOUNT OFF
END
GO

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_layout_sp_sacthref' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON ep_layout_sp_sacthref TO PUBLIC
END
GO