IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_layout_sp_savctlcnml' AND TYPE = 'P')
BEGIN
	DROP PROC ep_layout_sp_savctlcnml                                                                 
END
GO
/***********************************************************************************************/  
/* Procedure    : ep_layout_sp_savctlcnml													   */  
/* Description  :																			   */  
/***********************************************************************************************/  
/* Project      :																			   */  
/* ECR          :																			   */  
/* Version      :																			   */  
/***********************************************************************************************/  
/* Referenced   :																			   */  
/* Tables       :																			   */  
/***********************************************************************************************/  
/* Development history																		   */  
/***********************************************************************************************/  
/* Author       : ModelExplorer																   */  
/* Date         : 22/Sep/2005																   */  
/***********************************************************************************************/  
/* Modification history																		   */  
/***********************************************************************************************/  
/* Modified by  : Hamsika																	   */  
/* Date         : 17/10/2005																   */  
/* Description  : While saving,in Specify Layout "Incorrect Syntax							   */  
/* converting Varchar to integer" error is displayed.										   */  
/***********************************************************************************************/  
/*modified by      Hamsika																	   */          
/*modified date    25-Oct-2005																   */  
/*modified purpose      Platform_2.0.3.1_299(PDEV_274)										   */  
/***********************************************************************************************/  
/*modified by         :    Balaji S															   */
/*modified date       :    05-Aug-2005														   */
/*modified purpose    :    Validation To restrict numeric values for Column &				   */
/*							label Width														   */
/*BugId           Platform_2.0.3.X_53														   */
/***********************************************************************************************/  
/*modified by             Sangeetha L														   */
/*modified date           24-Aug-2005														   */
/*modified purpose        Validation To restrict KEYWORD defined AS A synonym				   */
/*BugId           Platform_2.0.3.X_265														   */
/***********************************************************************************************/  
/*modified by           Chanheetha N A														   */
/*modified date         29-Nov-2005													           */
/*BugId					PNR2.0_4824															   */
/*modified purpose      Validation To Display the Control Name which is a keyword			   */                              
/***********************************************************************************************/
/*modified by            Arunn  for PNR2.0_4964-4942										   */
/*modified date           13-Dec-2005														   */	
/*modified purpose  Validation to be added for default dataitems not to be defined as BT Synonym*/   
/***********************************************************************************************/  
/*modified by              kiruthika R														   */
/*modified date            03-Mar-2006														   */
/*modified purpose         For Bugid:PNR2.0_6778											   */
/***********************************************************************************************/  
/* modified by          : Chanheetha N A													   */  
/* modified date        : 20-Jun-2006														   */  
/* BugId       : PNR2.0_9027																   */  
/***********************************************************************************************/  
/* modified by          : Anuradha M													    */  
/* modified date        : 18-Aug-2006														   */  
/* BugId  : PNR2.0_9925																		   */ 
/***********************************************************************************************/  
/* Modified by  : kiruthika R														           */  
/* Date         : 25-Aug-2006																   */  
/* Bug ID       : PNR2.0_10027																   */  
/***********************************************************************************************/  
/* modified by  : Anuradha M															       */  
/* date         : 06-Nov-2006																   */  
/* description  : PNR2.0_10832																   */  
/***********************************************************************************************/  
/* modified by          : Chanheetha N A													   */  
/* modified date        : 13-Nov-2006														   */  
/* BugId       : PNR2.0_10930														           */  
/***********************************************************************************************/  
/* modified by          : Balaji S															   */  
/* modified date        : 25-apr-2007														   */  
/* BugId       : PNR2.0_13388																   */  
/***********************************************************************************************/  
/* Modified by  : kiruthika R																   */  
/* Date         : 22-May-2007																   */  
/* Bug ID       : PNR2.0_13748															       */  
/***********************************************************************************************/  
/* Modified by  : kiruthika R															       */  
/* Date         : 06-Jun-2007																   */  
/* Bug ID       : PNR2.0_13982															       */  
/***********************************************************************************************/  
/* Modified by  : Balaji S																	   */  
/* Date         : 12-JUN-2007																   */  
/* Bug ID       : PNR2.0_14066																   */  
/***********************************************************************************************/  
/* Modified by  : Kiruthika R																   */  
/* Date         : 13-JUL-2007															       */  
/* Bug ID       : PNR2.0_14505																   */  
/***********************************************************************************************/  
/* modified by   : Chanheetha N A															   */  
/* date     : 17-nov-2007																	   */  
/* BugId    : PNR2.0_16023																	   */  
/***********************************************************************************************/  
/* modified by   : Feroz																       */  
/* date     : 25-nov-2008															           */  
/* BugId    : PNR2.0_1790																	   */  
/***********************************************************************************************/  
/* modified by   : Jeya																	       */  
/* date     : 07-jan-2008																       */  
/* BugId    : PNR2.0_20553																       */  
/***********************************************************************************************/  
/* modified by   : Gowrisankar M															   */  
/* date     : 07-May-2009																	   */  
/* BugId    : PNR2.0_22165												                       */  
/* Description   : Commenting the Contextmenu population									   */  
/***********************************************************************************************/  
/* modified by    : Sangeetha G																   */  
/* date     : 22-June-2009																       */  
/* BugId    : PNR2.0_22560															           */  
/* Description    : To validate non-Grid controls existing in the Grid Sections.			   */  
/***********************************************************************************************/  
/* modified by    : S.Sivakumar																   */  
/* date     : 26-June-2009																	   */  
/* BugId    : PNR2.0_22690																	   */  
/* Description    : For Chnaging control type when the mapped control type has				   */  
/*       Spin Controls																	       */  
/***********************************************************************************************/  
/* modified by     : Sangeetha G															   */  
/* date     : 7-July-2009																	   */  
/* BugId      : PNR2.0_22818																   */  
/* Description     : Grid shoulb be defined under a  seperate section - Err thrown  when  grid */  
/*           ctrl type is changed.															   */  
/***********************************************************************************************/  
/* modified by  : Feroz																	       */  
/* date         : 04-Aug-2009																   */  
/* Bug Id   : PNR2.0_2179																	   */  
/* Description  : Phase 3 Features - ListEdit, AttachDocument, Image & DateHighlight		   */  
/***********************************************************************************************/  
/* Modified By     : Feroz																	   */  
/* Date       : 26-Aug-2009																	   */  
/* Description     : PNR2.0_23463															   */  
/***********************************************************************************************/  
/* Modified By     : Feroz																       */  
/* Date       : 10-Sep-2009																       */  
/* Description     : PNR2.0_23766														       */  
/***********************************************************************************************/  
/* modified by  : Ganesh Prabhu S                                      						   */  
/* date         : Oct 10 2014                                      							   */  
/* BugId        : PLF2.0_09035                                          					   */  
/* description  : Model changes for rowspan,colspan,IsStatic,IsCallout in  layout level        */  
/***********************************************************************************************/  
/* Modified by  : Veena U																	   */
/* Date         : 25-Feb-2015																   */
/* Call ID		: PLF2.0_11499																   */
/***********************************************************************************************/  
/* Modified by  : Kalidas S																	   */
/* Date         : 03-Aug-2015																   */
/* Defect ID	: PLF2.0_14096																   */
/***********************************************************************************************/
    /* Modified by  : Veena U																   */
/* Date         : 02-Feb-2016                                                                  */
/* Defect ID	: PLF2.0_16291													               */
/***********************************************************************************************/
/* Modified by  : Veena U                                                                      */
/* Date         : 28-Mar-2016                                                                  */
/* Call ID		: PLF2.0_17570                                                                 */
/***********************************************************************************************/ 
/* Modified by  : Kiruthika R                                                                  */
/* Date         : 26-May-2016                                                                  */
/* Call ID		: PLF2.0_18487													               */
/***********************************************************************************************/ 
/* modified by			Date				Defect ID										   */
/* Veena U				08-Jun-2016			PLF2.0_18487									   */
/***********************************************************************************************/
/* modified by                    Date                       Defect ID						   */
/* Veena U                        15-Jun-2016                PLF2.0_18888					   */
/***********************************************************************************************/
/* Modified by : Jeya Latha K/Ganesh Prabhu S	for callid TECH-7349						   */
/* Modified on : 14-03-2017				 													   */
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and			   */
/*				New Feature Organization chart												   */
/***********************************************************************************************/
/* Modified by : Ganesh Prabhu S/Ranjitha R      for callid  TECH-10118                        */
/* Modified on : 30-May-2017                                                                   */
/* Description : Platform Feature Release                                                      */
/***********************************************************************************************/
/* Modified by  : JeyaLatha K/Ranjitha R	Date: 31-Jan-2018  Defect ID : TECH-18349		   */  
/***********************************************************************************************/
/* Modified by  : Ranjitha R	Date: 28-Feb-2018  Defect ID : TECH-19347					   */  
/***********************************************************************************************/
/* Modified by  : Ranjitha R	Date: 29-Mar-2018  Defect ID : TECH-20326					   */  
/***********************************************************************************************/
/* Modified by  : Venkatesan K	Date: 04-Apr-2018  Defect ID : TECH-20308					   */  
/*Description	: Allow to change the control type from link to datahyperlink or datahyperlink */ 
/*		to link eventhough if traversal details exists for the control						   */
/***********************************************************************************************/
/* Modified by  : Jeya Latha K	Date: 30-Apr-2018  Defect ID : TECH-20897					   */  
/***********************************************************************************************/
/* Modified by  : Ranjitha R 					  Date: 31-May-2018		Defect ID : TECH-21893 */  
/* Modified by	: Jeya Latha K					  Defect ID: TECH-27036 On: 11-Oct-2018		   */
/* Modified by	: Jeya Latha K					  Defect ID: TECH-27286 On: 22-Oct-2018		   */
/* Modified By  : Jeya Latha K					  Date: 08-Jan-2019		Defect ID: TECH-28436  */
/* Modified by  : Jeya Latha K/Venkatesan K       Date: 17-Jun-2019		Defect ID : TECH-34971 */
/* Modified by : Jeya Latha K					  Date: 28-Jun-2019     Defect ID: TECH-35368  */
/* Modified by : Jeya Latha K					  Date: 25-Jul-2019     Defect ID: TECH-36371  */
/* Modified by : Jeya Latha K/Hareesh K           Date: 30-Aug-2019		Defect ID: TECH-37471  */
/* Modified by : Jeya Latha K			          Date: 01-Nov-2019		Defect ID: TECH-39534  */
/* Modified by : Priyadharshini U/Rajeswari M	  Date: 29-Jan-2020     Defect ID: TECH-42483  */
/* Modified by : Jeya Latha K                     Date: 27-May-2020		Defect ID: TECH-46646  */
/* Modified by : Manoj S						  Date: 24-Jan-2021		Defect ID: TECH-52773  */
/* Modified by : Manoj S						  Date: 23-Feb-2021		Defect ID: TECH-55716  */
/* Modified by : Srikanth S						  Date: 29-April-2021   Defect ID: TECH-57798  */
/* Modified by : Rajeswari M/Priyadharshini U     Date: 28-Jul-2021     Defect ID : TECH-60451 */
/* TECH-60451  : Launching Help&Link UIs, Popup sections and Grid Extensions in Side Drawer    */
/* TECH-63527  : Associate Control added in ep_ui_control_dtl for Multiselectcombo			   */ 
/***********************************************************************************************/
/* Modified by : Deepika S						  Date: 12-Feb-2022     Defect ID : TECH-65312 */
/* TECH-65312  : Validation (Attachment with desc) added for the Attachment control types	   */	
/***********************************************************************************************/
/* Modified by : Ponmalar A/Jeya Latha K		  Date: 13-Apr-2022     Defect ID : TECH-68066 */
/* TECH-68066  : Post and Pre Tasks for Attachment controls									   */	
/***********************************************************************************************/
/* Modified by	:	Priyadharshini U/VimalKumar R											   */
/* Modified on	:	08/06/22				 												   */
/* Defect ID	:	TECH-69624																   */
/* Description	:	Custom border, Custom actions and Responsive layout						   */
/***********************************************************************************************/
/* Modified by	:	Ponmalar A																   */
/* Modified on	:	11-July-22				 												   */
/* Defect ID	:	TECH-70687																   */
/* Description	:	Tool and Toolbars														   */
/***********************************************************************************************/
/* Modified by	:	Ponmalar A/Priyadharshini U												   */
/* Modified on	:	27-July-22				 												   */
/* Defect ID	:	TECH-71262																   */
/* Description	:	Platform Features for the Month of July'22								   */
/***********************************************************************************************/
/* Modified by : Jeya Latha K/Ponmalar A          Date: 28-Jul-2022     Defect ID : TECH-71109 */
/***********************************************************************************************/
/* Modified by	:	Priyadharshini U														   */
/* Modified on	:	27-Aug-22				 												   */
/* Defect ID	:	TECH-72114																   */
/***********************************************************************************************/
/* Modified by			: Ponmalar A															*/
/* Date					: 29-Sep-2022															*/
/* Defect ID			: TECH-73216															*/
/***********************************************************************************************/
/* Modified by			: Ponmalar A/Priyadharshini U											*/
/* Date					: 27-Oct-2022															*/
/* Defect ID			: TECH-73996															*/
/************************************************************************************************/
/* Modified by			: Manoj S															*/
/* Date					: 10-Oct-2022															*/
/* Defect ID			: TECH-73370															*/
/************************************************************************************************/
/* Modified by : Ponmalar A						Date: 02-Dec-2022       Defect ID : TECH-75230 */
/***********************************************************************************************/
CREATE PROCEDURE ep_layout_sp_savctlcnml  
 @ctxt_language                                              engg_ctxt_language,  --Input   
 @ctxt_ouinstance                                            engg_ctxt_ouinstance,  --Input   
 @ctxt_service     											 engg_ctxt_service,  --Input   
 @ctxt_user                                             	 engg_ctxt_user,  --Input   
 @engg_act_descr                                             engg_description,  --Input   
 @engg_component                                             engg_description,  --Input   
 @engg_cont_btsynname                                        engg_name,  --Input   
 @engg_cont_datawidth                                        engg_flag,  --Input   
 @engg_cont_descr                                            engg_description,  --Input   
 @engg_cont_doc                                              engg_documentation,  --Input   
 @engg_cont_elem_type                                        engg_name,  --Input   
 @engg_cont_horder                                           engg_seqno,  --Input   
 @engg_cont_labwidth                                      	 engg_flag,  --Input   
 @engg_cont_page_bts                                         engg_name,  --Input   
 @engg_cont_samp_data                                        engg_documentation,  --Input   
 @engg_cont_sec_bts                                          engg_name,  --Input   
 @engg_cont_sequence                                         engg_seqno,  --Input   
 @engg_cont_tooltip                                          engg_documentation,  --Input   
 @engg_cont_vis_length                                       engg_length,  --Input   
 @engg_cont_vorder                                           engg_seqno,  --Input   
 @engg_customer_name                                         engg_name,  --Input   
 @engg_enum_page_bts                                         engg_name,  --Input   
 @engg_enum_sec_bts                                          engg_name,  --Input   
 @engg_grid_page_bts                                         engg_name,  --Input   
 @engg_grid_sec_bts											 engg_name,  --Input   
 @engg_lnk_page_descr                                        engg_description,  --Input   
 @engg_process_descr                                         engg_description,  --Input   
 @engg_project_name                                          engg_name,  --Input   
 @engg_radio_page_bts                                        engg_name,  --Input   
 @engg_radio_sec_bts                                         engg_name,  --Input   
 @engg_req_no                                                engg_name,  --Input   
 @engg_ui_descr                                              engg_description,  --Input   
 @guid                                                       engg_guid,  --Input   
 @modeflag                                                   engg_modeflag,  --Input   
 @fprowno                                                    engg_rowno,  --Input/Output   
 @engg_label_class											 engg_name,  --Input   
 @engg_control_class                                         engg_name,  --Input   
 @engg_label_image_class                                     engg_name,  --Input   
 @engg_control_image_class                                   engg_name,  --Input   
 @engg_tab_sequence                                          engg_seqno,  --Input   
 @engg_tab_stopforhelp                                       engg_flag,  --Input   
 @engg_cont_rowspan											 engg_seqno, --Input   
 @engg_cont_colspan											 engg_seqno, --Input   
 @engg_cont_ctrlimg											 engg_name, --Input   
 @engg_del_controls											 engg_documentation, --Input/Output  
 @set_user_pref            									 checkflag_int, --Input 
 @freezecount              									 engg_seqno, --Input 
 @engg_cont_tempid											 engg_name, --Input   
 @ctrl_temp_cat            									 engg_name, --Input 
 @ctrl_temp_specific									   	 engg_documentation, --Input
 @engg_MSC_Ass_control										 engg_name,--Input --code added  for the defect id:TECH-63527
 --Ranjitha  
 @AccessKey													 engg_code,
 @Icon_class												 engg_name,
 @Icon_position												 engg_name,
 @Cont_class_ext6											 engg_name,
 @engg_dynamicstyle											 engg_flag,
 @engg_imageasdata											 engg_flag,
 @engg_extnreqd												 engg_seqno,   --Input
 @engg_extension											 engg_code,     --Input
 @Engg_cont_forresponsive									 engg_seqno,   --Input	--Code added for TECH-69624	
 @engg_cont_customborder									 engg_code, --Input		--Code added for TECH-69624	
 @engg_cont_customaction									 engg_code, --Input		--Code added for TECH-69624
 @engg_cont_control_format									 engg_name, --Input		--Code Added for the Defect Id TECH-72114
 @ButtonNature												 engg_name,				--Tech-75230
 @InlineStyle												 engg_nvarchar_max,		--Tech-75230
 @m_errorid													 engg_seqno OUTPUT --To Return Execution Status   
as
Begin
	-- nocount should be switched on to prevent phantom rows
	Set nocount on
	-- @m_errorid should be 0 to Indicate Success
	Set @m_errorid = 0

	--declaration of temporary variables

	--temporary and formal parameters mapping

	Set @ctxt_service              = ltrim(rtrim(@ctxt_service))
	Set @ctxt_user                 = ltrim(rtrim(@ctxt_user))
	Set @engg_act_descr = ltrim(rtrim(@engg_act_descr))
	Set @engg_component            = ltrim(rtrim(@engg_component))
	Set @engg_cont_btsynname       = ltrim(rtrim(@engg_cont_btsynname))
	Set @engg_cont_datawidth       = ltrim(rtrim(@engg_cont_datawidth))
	Set @engg_cont_descr           = ltrim(rtrim(@engg_cont_descr))
	Set @engg_cont_doc             = ltrim(rtrim(@engg_cont_doc))
	Set @engg_cont_elem_type       = ltrim(rtrim(@engg_cont_elem_type))
	Set @engg_cont_labwidth        = ltrim(rtrim(@engg_cont_labwidth))
	Set @engg_cont_page_bts        = ltrim(rtrim(@engg_cont_page_bts))
	Set @engg_cont_samp_data       = ltrim(rtrim(@engg_cont_samp_data))
	Set @engg_cont_sec_bts         = ltrim(rtrim(@engg_cont_sec_bts))
	Set @engg_cont_tooltip         = ltrim(rtrim(@engg_cont_tooltip))
	Set @engg_customer_name        = ltrim(rtrim(@engg_customer_name))
	Set @engg_enum_page_bts        = ltrim(rtrim(@engg_enum_page_bts))
	Set @engg_enum_sec_bts         = ltrim(rtrim(@engg_enum_sec_bts))
	Set @engg_grid_page_bts        = ltrim(rtrim(@engg_grid_page_bts))
	Set @engg_grid_sec_bts         = ltrim(rtrim(@engg_grid_sec_bts))
	Set @engg_lnk_page_descr       = ltrim(rtrim(@engg_lnk_page_descr))
	Set @engg_process_descr        = ltrim(rtrim(@engg_process_descr))
	Set @engg_project_name         = ltrim(rtrim(@engg_project_name))
	Set @engg_radio_page_bts       = ltrim(rtrim(@engg_radio_page_bts))
	Set @engg_radio_sec_bts        = ltrim(rtrim(@engg_radio_sec_bts))
	Set @engg_req_no               = ltrim(rtrim(@engg_req_no))
	Set @engg_ui_descr             = ltrim(rtrim(@engg_ui_descr))
	Set @guid                      = ltrim(rtrim(@guid))
	Set @modeflag                  = ltrim(rtrim(@modeflag))
	Set @engg_label_class          = ltrim(rtrim(@engg_label_class))
	Set @engg_control_class        = ltrim(rtrim(@engg_control_class))
	Set @engg_label_image_class    = ltrim(rtrim(@engg_label_image_class))
	Set @engg_control_image_class  = ltrim(rtrim(@engg_control_image_class))
	Set @engg_tab_stopforhelp      = ltrim(rtrim(@engg_tab_stopforhelp))
	Set @engg_cont_ctrlimg         = ltrim(rtrim(@engg_cont_ctrlimg))
	Set @engg_del_controls         = ltrim(rtrim(@engg_del_controls))
	Set @engg_cont_tempid          = ltrim(rtrim(@engg_cont_tempid)) 
	Set @ctrl_temp_cat             = ltrim(rtrim(@ctrl_temp_cat))
	Set @ctrl_temp_specific        = ltrim(rtrim(@ctrl_temp_specific))
	--Ranjitha
	Set @engg_MSC_Ass_control      = ltrim(rtrim(@engg_MSC_Ass_control)) ----code added  for the defect id:TECH-63527
	Set @AccessKey				   = ltrim(rtrim(@AccessKey))
	Set @Icon_class				   = ltrim(rtrim(@Icon_class))
	Set @Icon_position             = ltrim(rtrim(@Icon_position))
	Set @Cont_class_ext6           = ltrim(rtrim(@Cont_class_ext6))
	Set @engg_dynamicstyle         = ltrim(rtrim(@engg_dynamicstyle))
	Set @engg_imageasdata          = ltrim(rtrim(@engg_imageasdata))
	--code added on 19th July 2021
	Set @engg_extension			   = ltrim(rtrim(@engg_extension))
	Set @engg_cont_control_format  = ltrim(rtrim(@engg_cont_control_format))	--Code Added for the Defect Id TECH-72114
	
	
	--null checking

	IF @ctxt_language = -915
		Select @ctxt_language = null  

	IF @ctxt_ouinstance = -915
		Select @ctxt_ouinstance = null  

	IF @ctxt_service = '~#~' 
		Select @ctxt_service = null  

	IF @ctxt_user = '~#~' 
		Select @ctxt_user = null  

	IF @engg_act_descr = '~#~' 
		Select @engg_act_descr = null  

	IF @engg_component = '~#~' 
		Select @engg_component = null  

	IF @engg_cont_btsynname = '~#~' 
		Select @engg_cont_btsynname = null  

	IF @engg_cont_datawidth = '~#~' 
		Select @engg_cont_datawidth = null  

	IF @engg_cont_descr = '~#~' 
		Select @engg_cont_descr = null  

	IF @engg_cont_doc = '~#~' 
		Select @engg_cont_doc = null  

	IF @engg_cont_elem_type = '~#~' 
		Select @engg_cont_elem_type = null  

	IF @engg_cont_horder = -915
		Select @engg_cont_horder = null  

	IF @engg_cont_labwidth = '~#~' 
		Select @engg_cont_labwidth = null  

	IF @engg_cont_page_bts = '~#~' 
		Select @engg_cont_page_bts = null  

	IF @engg_cont_samp_data = '~#~' 
		Select @engg_cont_samp_data = null  

	IF @engg_cont_sec_bts = '~#~' 
		Select @engg_cont_sec_bts = null  

	IF @engg_cont_sequence = -915
		Select @engg_cont_sequence = null  

	IF @engg_cont_tooltip = '~#~' 
		Select @engg_cont_tooltip = null  

	IF @engg_cont_vis_length = -915
		Select @engg_cont_vis_length = null  

	IF @engg_cont_vorder = -915
		Select @engg_cont_vorder = null  

	IF @engg_customer_name = '~#~' 
		Select @engg_customer_name = null  

	IF @engg_enum_page_bts = '~#~' 
		Select @engg_enum_page_bts = null  

	IF @engg_enum_sec_bts = '~#~' 
		Select @engg_enum_sec_bts = null  

	IF @engg_grid_page_bts = '~#~' 
		Select @engg_grid_page_bts = null  

	IF @engg_grid_sec_bts = '~#~' 
		Select @engg_grid_sec_bts = null  

	IF @engg_lnk_page_descr = '~#~' 
		Select @engg_lnk_page_descr = null  

	IF @engg_process_descr = '~#~' 
		Select @engg_process_descr = null  

	IF @engg_project_name = '~#~' 
		Select @engg_project_name = null  

	IF @engg_radio_page_bts = '~#~' 
		Select @engg_radio_page_bts = null  

	IF @engg_radio_sec_bts = '~#~' 
		Select @engg_radio_sec_bts = null  

	IF @engg_req_no = '~#~' 
		Select @engg_req_no = null  

	IF @engg_ui_descr = '~#~' 
		Select @engg_ui_descr = null  

	IF @guid = '~#~' 
		Select @guid = null  

	IF @modeflag = '~#~' 
		Select @modeflag = null  

	IF @fprowno = -915
		Select @fprowno = null  

	IF @engg_label_class = '~#~' 
		Select @engg_label_class = null  

	IF @engg_control_class = '~#~' 
		Select @engg_control_class = null  

	IF @engg_label_image_class = '~#~' 
		Select @engg_label_image_class = null  

	IF @engg_control_image_class = '~#~' 
		Select @engg_control_image_class = null  

	IF @engg_tab_sequence = -915
		Select @engg_tab_sequence = null  

	IF @engg_tab_stopforhelp = '~#~' 
		Select @engg_tab_stopforhelp = null  

	IF @engg_cont_rowspan = -915
		Select @engg_cont_rowspan = null  

	IF @engg_cont_colspan = -915
		Select @engg_cont_colspan = null  

	IF @engg_cont_ctrlimg = '~#~' 
		Select @engg_cont_ctrlimg = null  

	IF @engg_del_controls = '~#~' 
		Select @engg_del_controls = null  

	IF @set_user_pref = -915
		Select @set_user_pref = null  

	IF @freezecount = -915
		Select @freezecount = null  

	IF @engg_cont_tempid = '~#~'
		Select @engg_cont_tempid = null     
		
	IF @ctrl_temp_cat = '~#~' 
		Select @ctrl_temp_cat = null  

	IF @ctrl_temp_specific = '~#~' 
		Select @ctrl_temp_specific = null  	
--Ranjitha		

	IF @engg_MSC_Ass_control = '~#~' --code added  for the defect id:TECH-63527
		Select @engg_MSC_Ass_control = null  

	IF @AccessKey = '~#~' 
		Select @AccessKey = null
		
	IF @Icon_class = '~#~' 
		Select @Icon_class = null
		
	IF @Icon_position = '~#~' 
		Select @Icon_position = null
		
	IF @Cont_class_ext6 = '~#~' 
		Select @Cont_class_ext6 = null	

	IF @engg_dynamicstyle = '~#~' 
		Select @engg_dynamicstyle = null	

	IF @engg_imageasdata = '~#~' 
		Select @engg_imageasdata = null	

	IF @engg_extnreqd = -915 
		Select @engg_extnreqd = null	

	IF @engg_extension = '~#~' 
		Select @engg_extension = null	

	IF @Engg_cont_forresponsive = -915 
		Select @Engg_cont_forresponsive = null	--Code added for TECH-69624

	IF @engg_cont_customborder = '~#~' 
		Select @engg_cont_customborder = null	--Code added for TECH-69624

	IF @engg_cont_customaction = '~#~' 
		Select @engg_cont_customaction = null	--Code added for TECH-69624
	
	IF @engg_cont_control_format = '~#~' 
		Select @engg_cont_control_format = null	--Code Added for the Defect Id TECH-72114

	IF @ButtonNature = '~#~'	--Tech-75230
		Select @ButtonNature = null	

	IF @InlineStyle = '~#~'		--Tech-75230
		Select @InlineStyle = null	

	--If @modeflag = 'S
	--	Return		
	
if @ctrl_temp_cat  IS NULL
begin
	set		@engg_cont_tempid=null
end


	if exists (select 'x' from vid_ilbo_tmp where ilbodescription = @engg_ui_descr )
	Begin
		Exec  uid_ep_layout_sp_savctlcnml 
			@ctxt_language,			@ctxt_ouinstance,		@ctxt_service ,			@ctxt_user,			@engg_act_descr,		@engg_component,
			@engg_cont_btsynname,	@engg_cont_datawidth,	@engg_cont_descr  ,		@engg_cont_doc,		@engg_cont_elem_type,	@engg_cont_horder   ,
			@engg_cont_labwidth ,	@engg_cont_page_bts ,	@engg_cont_samp_data,	@engg_cont_sec_bts, @engg_cont_sequence ,	@engg_cont_tooltip,
			@engg_cont_vis_length , @engg_cont_vorder   ,	@engg_customer_name,	@engg_enum_page_bts,@engg_enum_sec_bts  ,	@engg_grid_page_bts ,
			@engg_grid_sec_bts  ,	@engg_lnk_page_descr,	@engg_process_descr ,	@engg_project_name ,@engg_radio_page_bts,	@engg_radio_sec_bts ,
			@engg_req_no  ,			@engg_ui_descr,			@guid ,					@modeflag ,			@fprowno  ,				@engg_label_class   ,
			@engg_control_class ,	@engg_label_image_class,@engg_control_image_class,@engg_tab_sequence,@engg_tab_stopforhelp ,@engg_cont_rowspan  ,
			@engg_cont_colspan  ,	@engg_cont_ctrlimg  ,	@engg_del_controls  ,	@set_user_pref,		@freezecount ,			@engg_cont_tempid ,
			@m_errorid            
	end
	Else
	Begin		
		DECLARE --@IUDModeFlag   varchar(2),  
				@msg				engg_documentation,  
				@tmp_proc			engg_name,  
				@tmp_comp			engg_name,  
				@tmp_act			engg_name,  
				@tmp_ui				engg_name,  
				@tmp_ctl			engg_name,  
				@engg_base_req_no	engg_name,  
--@control_id_tmp  engg_name,  
--@count    engg_name,  
				@control_id			engg_name,  
-- @view_name   engg_name,  
--    @tmp_ActionName  engg_name,  
--    @tmp_Action_Desc engg_description,  
--    @seq_no    int,  
				@event_req			engg_flag,  
				@help_req			engg_flag,  
				@old_help_req		engg_flag,  
				@zoom_req			engg_flag,  
				@editable			engg_flag,  
--    @tmp_ActionType  engg_name,  
				@page_prefix_tmp	engg_name,  
				@page_prefix_tmp2	engg_name, 
				@column_bt_synonym	engg_name,   
				@tmp_control_type	engg_name,  
				@task_name			engg_name,  
	--@ui_pfx_tmp   engg_name,  
				@cont_bt_caption	engg_name,  
				@base_ctrl_type_tmp engg_name,  
				@visible			engg_flag,  
				@ctrl_id_old		engg_name,  
				@enumcap			engg_description,  
				@label_scale_mode   engg_name,  
				@l_cnt				engg_rowno,  
				@l_char             engg_name,  
				@l_num				engg_name,  
				@data_scale_mode	engg_name,  
				@d_cnt				engg_rowno,  
				@d_char				engg_name,  
				@d_num				engg_name,  
-- Code modified by Chanheetha N A For the issue :PNR2.0_9027 on 20-Jun-2006  
				@traversal_ctl      engg_name,  
				@traversal_help_req engg_flag,  
-- Code modified by Chanheetha N A For the issue :PNR2.0_9027 on 20-Jun-2006  
				@spin_req			engg_flag,  
				@QlikLink			engg_flag, 
				@QlikLink_pre		engg_flag,  
				@page_prefix_sec	engg_name,  
				@tmp_cotrol_id		engg_name,  
--@len    engg_code,  
				@report_req			engg_flag , -- code modified by Anuradha on 06-Nov-2006 for the Bug ID :: PNR2.0_10832  
				@sampledata         engg_documentation,  
				@extjs_ctrl_type	engg_name,  -- code added by Feroz for ext js --PNR2.0_1790  
				@page_prefix_section engg_prefix, -- code added by Sivakumar for BUG ID PNR2.0_22690  
				@appid				engg_name,
				@Sheetid			engg_name,
				@cont_name			engg_name,
				@len_app			engg_seqno,
				@len_sht			engg_seqno,
				@max_horder			engg_seqno,
				@page_prefix_tmp1	engg_name,
				@up_flag			engg_flag,
				@NodeIconReqd		engg_flag,
				@NodeIconCls		engg_flag,
				@engg_btsynonym		engg_name,
				@CreatingFor		engg_name,
				@tmp_Sectiontype	engg_name,
				@IsDataGrid			engg_flag, --Code Added for Defect ID : TECH-39534
				@RenderAs			engg_name,
				@IsChips			engg_flag,
				@selectionreqdforList	engg_flag,
				@PaginatationReqd	engg_flag,
				@UpdateTaskReqd		engg_flag,
				@DeleteTaskReqd		engg_flag,
				@basectrl_type_name	 engg_name,  --code added for TECH-63527
				@tmp_ctrltype         engg_name, --code added for TECH-63527
				@tmp_assoc_basectrl_type   engg_name,  --code added for TECH-63527
				@control_prefix		engg_name	--TECH-75230
  
	select	@sampledata		= @engg_cont_samp_data  
  
-- Code modification  for PNR2.0_23541 starts   
	declare @user_pref					engg_flag  
	-- Code modification  for PNR2.0_36309 starts  
	Declare @Label_Link					engg_flag   
	Declare @old_Label_Link_req			engg_flag   
	Declare @traversal_Label_Link_req	engg_flag  
-- Code modification  for PNR2.0_36309 ends   
	Declare @phone_in					engg_flag,
			@tablet_in					engg_flag,
			@Devicetype					engg_flag
 
	if isnull(@set_user_pref,'')  in ('',0)  
		select  @user_pref  = 'Y'  
  
	if isnull(@set_user_pref,'')  = 1  
		select  @user_pref  = 'N'  
  
-- Code modification  for PNR2.0_23541 ends  

	if @engg_cont_sec_bts like 'hdnspin%'  
	begin   
		raiserror('No Changes Allowed for the Section ''%s''',16,1,@engg_cont_sec_bts)  
		return  
	end  
  
	declare @error_tmp   engg_rowno  
  
-- Code Added for PNR2.0_32228 Starts  
	Declare @del_flag		engg_flag ,
			@del_flag_ph	engg_flag
  

--kanagavel
	declare	@section_type	engg_name
	declare	@Map_count		engg_rowno
	declare	@ui_subtype		engg_name
  
	select @del_flag = 'F'  
-- Code Added for PNR2.0_32228 End  
	select @engg_base_req_no = 'BASE'   
--  select @seq_no = 0  
-- incrementing  Fprow number  
	
	select @fprowno = @fprowno + 1    
-- code modified by shafina on 24-Nov-2004 for selecting sequence = 1 when it is 0  
	if @engg_cont_sequence = 0  
		select @engg_cont_sequence  = 1  
  
--GETTING THE PROCESS NAME FOR DESCRIPTION  
	Select  @tmp_proc   = process_name  
	from	ep_ui_req_dtl  (nolock)  
	where	customer_name	= @engg_customer_name  
	and		project_name	= @engg_project_name  
	and     req_no			= @engg_req_no  
	and		process_descr   = @engg_process_descr  
  
--GETTING THE COMPONENT NAME FOR THE DESCRIPTION  
	Select  @tmp_comp  = Component_name  
	from	ep_ui_req_dtl  (nolock)  
	where	customer_name   = @engg_customer_name  
	and		project_name	= @engg_project_name  
	and     req_no			= @engg_req_no  
	and		process_name    = @tmp_proc  
	and		component_descr = @engg_component  
  
--GETTING THE ACTIVITY NAME FOR THE DESCRIPTION  
	Select  @tmp_act    = activity_name  
	from	ep_ui_req_dtl (nolock)  
	where	customer_name   = @engg_customer_name  
	and		project_name	= @engg_project_name  
	and     req_no			= @engg_req_no  
	and		process_name	= @tmp_proc  
	and		component_name  = @tmp_comp  
	and		activity_descr  = @engg_act_descr  
  
--GETTING THE UI NAME FOR THE DESCRIPTION  
	Select  @tmp_ui      = ui_name  
	from	ep_ui_req_dtl (nolock)  
	where	customer_name   = @engg_customer_name  
	and		project_name	= @engg_project_name  
	and req_no			= @engg_req_no 
	and		process_name	= @tmp_proc  
	and		component_name  = @tmp_comp  
	and		activity_name   = @tmp_act  
	and		ui_descr		= @engg_ui_descr  
  
	Select	@ui_subtype = ui_subtype 
	from	ep_ui_mst (nolock)
	where	customer_name		= rtrim(@engg_customer_name)
	and		project_name		= rtrim(@engg_project_name)
	and		process_name		= rtrim(@tmp_proc)
	and		component_name		= rtrim(@tmp_comp)
	and		activity_name		= rtrim(@tmp_act)
	and		ui_name				= rtrim(@tmp_ui)
	
	-- NGPLF Changes Starts
	DECLARE	@ctxt_role	ENGG_NAME	
	set @ctxt_role = null
	--TECH-75230
	SELECT	@control_prefix	= control_prefix
	FROM	ep_ui_control_dtl (NOLOCK)
	WHERE	customer_name	= rtrim(@engg_customer_name)
	and		project_name	= rtrim(@engg_project_name)
	and		process_name	= rtrim(@tmp_proc)
	and		component_name	= rtrim(@tmp_comp)
	and		activity_name	= rtrim(@tmp_act)
	and		ui_name			= rtrim(@tmp_ui)
	and		page_bt_synonym	= rtrim(@engg_cont_page_bts)
	and		section_bt_synonym = rtrim(@engg_cont_sec_bts)
	and		control_bt_synonym = rtrim(@engg_cont_btsynname)
	--TECH-75230



	IF @modeflag in ('I', 'X', 'U', 'Y')
	BEGIN   
		IF EXISTS ( SELECT	'X'
					FROM	ep_ui_mst (NOLOCK)
					WHERE	customer_name			= @engg_customer_name
					AND		project_name			= @engg_project_name
					AND		process_name			= @tmp_proc
					AND		component_name			= @tmp_comp
					AND		activity_name			= @tmp_act
					AND		ui_name					= @tmp_ui
					AND		ISNULL(ISGLANCE, 'N')	= 'Y')
		BEGIN
			EXEC ngplf_validate_specifylayout
			@ctxt_language,			@ctxt_ouinstance,		@ctxt_user,				@Ctxt_role,			@engg_customer_name,
			@engg_project_name,		@tmp_proc,				@tmp_comp,				@tmp_act,			@tmp_ui,
			@engg_cont_sec_bts,		@engg_cont_elem_type,	'HCT'
		END	
	END	
	-- NGPLF Changes ends
--TECH-52773 starts
IF  exists 
( select 'X' from es_comp_ctrl_type_mst (nolock)
where customer_name = @engg_customer_name
and		project_name	= @engg_project_name
and		req_no			= @engg_base_req_no
and		process_name	= @tmp_proc
and		component_name	= @tmp_comp
and		ctrl_type_name	= @engg_cont_elem_type
and		base_ctrl_type  = 'EDIT'
and		isnull(visisble_flag,'')  = 'Y'
and		isnull(editable_flag,'')  = 'N'
)
and     @Cont_class_ext6 = 'Icon'
BEGIN 

RAISERROR('For Display Only controls kindly provide valid control class at ronw no %i',16,6,@fprowno)
RETURN

END
--TECH-52773 Ends

----TECH-71109
--IF ISNULL(@modeflag,'') IN ('I','X','U','Y')
--BEGIN
--IF EXISTS
--(SELECT 'X'�
--�FROM ep_ui_mst WITH (NOLOCK)
--�WHERE��customer_name�� �= rtrim(@engg_customer_name)
--�AND�� �project_name�� � = rtrim(@engg_project_name)
--�AND�� �req_no�� ��� ��� = rtrim(@engg_base_req_no)
--�AND�� �process_name�� � = rtrim(@tmp_proc)
--�AND�� �component_name�� = rtrim(@tmp_comp)
--�AND�� �activity_name�� �= rtrim(@tmp_act)
--�AND�� �ui_name�� ��� ���= rtrim(@tmp_ui)
--�AND�� �DeviceType�� ��� = 'P')
--BEGIN
--�� ��� �IF EXISTS(
--        SELECT  'X'
--        FROM    es_comp_ctrl_type_mst_extn extn (NOLOCK),
--                es_comp_ctrl_type_mst    mst (nolock)
--        WHERE	mst.customer_name		= extn.customer_name
--        AND     mst.project_name        = extn.project_name
--        AND     mst.Process_name        = extn.process_name
--        AND     mst.component_name      = extn.component_name
--        AND     mst.base_Control_type   = extn.base_Control_type
--        AND     mst.Ctrl_type_name      = extn.ctrl_type_name

--        AND     extn.customer_name      = RTRIM(@engg_customer_name)
--        AND     extn.project_name       = RTRIM(@engg_project_name)
--        AND     extn.process_name       = RTRIM(@tmp_proc)
--        AND     extn.component_name     = RTRIM(@tmp_comp)
--        AND     extn.ctrl_type_name     = RTRIM(@engg_cont_elem_type)
--        AND     extn.base_ctrl_type     = 'GRID'
--        AND     ISNULL(mst.Datagrid, 'N')    = 'N'
--        AND     ISNULL(extn.IsMobile,'N')    = 'N'
--        AND     ISNULL(extn.IsList,'N')      = 'N')
--        BEGIN
--            RAISERROR ('Grid control should have ''Is List'' attribute for MobileUI.',16,1)
--        END
--END
--END
----TECH-71109

		--TECH-69624 (14469)
		IF ISNULL(@modeflag,'') IN ('U','Y','D')	AND ISNULL(@engg_cont_doc,'') = 'System generated for Custom Action'
		BEGIN
			RAISERROR('System generated controls for Custom action cannot be updated / deleted.',16,1,@fprowno)
		RETURN
		END
		--TECH-69624 (14469)

		--TECH-70687

		IF  EXISTS 
		( SELECT 'X' FROM es_comp_ctrl_type_mst (nolock)
		WHERE customer_name		= @engg_customer_name
		AND		project_name	= @engg_project_name
		AND		req_no			= @engg_base_req_no
		AND		process_name	= @tmp_proc
		AND		component_name	= @tmp_comp
		AND		ctrl_type_name	= @engg_cont_elem_type
		AND		base_ctrl_type  NOT IN ('Link','Button','DataHyperLink')
		)
		AND		EXISTS 
		(SELECT 'X' 
		 FROM	ep_ui_section_dtl (NOLOCK)
		 WHERE  customer_name		= @engg_customer_name
		AND		project_name		= @engg_project_name
		AND		req_no				= @engg_base_req_no
		AND		process_name		= @tmp_proc
		AND		component_name		= @tmp_comp
		AND     page_bt_synonym		=  @engg_cont_page_bts
		AND     section_bt_synonym  = @engg_cont_sec_bts	
		 AND    section_type		= 'Sidebar')
		BEGIN 		
		RAISERROR('Only Link,Button and DataHyperLink controls are allowed in Sidebar at row no %i.',16,6,@fprowno)
		RETURN	
		END

		IF  EXISTS 
		( SELECT 'X' FROM es_comp_ctrl_type_mst (nolock)
		WHERE customer_name		= @engg_customer_name
		AND		project_name	= @engg_project_name
		AND		req_no			= @engg_base_req_no
		AND		process_name	= @tmp_proc
		AND		component_name	= @tmp_comp
		AND		ctrl_type_name	= @engg_cont_elem_type
		AND		base_ctrl_type  NOT IN ('Label','DataHyperLink','Combo','Button','CheckBox','Edit','DisplayOnly',
										'RadioButton','ListView','Slider','Line','Link','Assorted','ListEdit')
		)
		AND		EXISTS 
		(SELECT 'X' 
		 FROM	ep_ui_section_dtl (NOLOCK)
		 WHERE  customer_name		= @engg_customer_name
		AND		project_name		= @engg_project_name
		AND		req_no				= @engg_base_req_no
		AND		process_name		= @tmp_proc
		AND		component_name		= @tmp_comp
		AND     page_bt_synonym		=  @engg_cont_page_bts
		AND     section_bt_synonym  = @engg_cont_sec_bts	
		 AND    section_type		= 'Toolbar')
		BEGIN 		
		RAISERROR('Only Header controls are allowed in Toolbar at row no %i.',16,6,@fprowno)
		RETURN	
		END
	--TECH-70687

		--TECH-73996
	IF ISNULL(@modeflag,'')	IN ('U','Y')
		BEGIN
			IF EXISTS (	SELECT	'X'
					FROM	es_comp_ctrl_type_mst WITH(NOLOCK)
					WHERE	customer_name	= @engg_customer_name
					AND		project_name	= @engg_project_name
					AND		process_name	= @tmp_proc
					AND		component_name	= @tmp_comp
					AND		ctrl_type_name	= @engg_cont_elem_type 
					AND		visisble_flag	= 'n'	
					AND	EXISTS( SELECT 'X' FROM
								ep_ui_state_control_dtl with(nolock)
								WHERE	customer_name		=	@engg_customer_name
								AND		project_name		=	@engg_project_name
								AND		process_name		=	@tmp_proc
								AND		component_name		=	@tmp_comp
								AND		activity_name		=	@tmp_act
								AND		ui_name				=	@tmp_ui
								AND		page_bt_synonym		=	@engg_cont_page_bts
								AND		section_bt_synonym	=	@engg_cont_sec_bts
								AND		control_bt_synonym	=	@engg_cont_btsynname ))
				BEGIN
					RAISERROR('Selected Control ''%s'' cannot be made as hidden.Since it is involved in RT State.Error at rowno: %i.',16,1,@engg_cont_btsynname,@fprowno)
					RETURN
				END

		IF EXISTS (	SELECT	'X'
					FROM	es_comp_ctrl_type_mst WITH(NOLOCK)
					WHERE	customer_name	= @engg_customer_name
					AND		project_name	= @engg_project_name
					AND		process_name	= @tmp_proc
					AND		component_name	= @tmp_comp
					AND		ctrl_type_name	= @engg_cont_elem_type 
					AND		visisble_flag	= 'n'	
					AND	EXISTS (	SELECT 'X'
									FROM	iruledb..fw_req_ilbo_rule_property_stmt a(nolock)
									JOIN	iruledb..fw_req_ilbo_rule_property_value b(nolock)
									ON		a.CustomerName	=	b.customername
									AND		a.projectname	=	b.projectname
									AND		a.ComponentName	=	b.ComponentName
									AND		a.ILBOCode		=	b.ILBOCode
									AND		a.StmtID		=	b.StmtID
									JOIN	iruledb..inf_req_rule_ilbo_control_view_details c (nolock)
									ON		a.customername	=	c.customername
									AND		a.projectname	=	c.projectname
									AND		a.ComponentName	=	c.ComponentName
									AND		a.ilbocode		=	c.ilbocode
									AND		a.controlid		=	c.controlid
									AND		a.viewname		=	c.viewname
									WHERE	c.CustomerName	=	@engg_customer_name
									AND		c.ProjectName		=	@engg_project_name
									AND		c.ProcessName		=	@tmp_proc
									AND		c.ComponentName		=	@tmp_comp
									AND		c.ActivityName		=	@tmp_act
									AND		c.ILBOCode			=	@tmp_ui
									AND		c.TabName			=	@engg_cont_page_bts
									AND		c.SectionName		=	@engg_cont_sec_bts
									AND		c.BTSynonym			=	@engg_cont_btsynname
									AND		b.PropertyName		=	'Hide'
									AND		b.PropertyValue		=	'true' ))
				BEGIN
					RAISERROR('Selected Control ''%s'' cannot be made as hidden.Since it is involved in iRule State. Error at rowno: %i.',16,1,@engg_cont_btsynname,@fprowno)
					RETURN
				END
END
	--TECH-73996


--TECH-55716 Starts
 IF  exists 
( select 'X' from  ep_ui_section_dtl a(nolock)
join es_comp_ctrl_type_mst b(nolock)
on      a.customer_name     = b.customer_name
and		a.project_name	    = b.project_name
and		a.process_name	    = b.process_name
and		a.component_name	= b.component_name
and     a.customer_name     = @engg_customer_name
and		a.project_name	    = @engg_project_name
and		a.req_no			= @engg_base_req_no
and		a.process_name	    = @tmp_proc
and		a.component_name	= @tmp_comp
and     a.activity_name     = @tmp_act
and     a.ui_name			= @tmp_ui
and     a.page_bt_synonym   = @engg_cont_page_bts
and     a.section_bt_synonym = @engg_cont_sec_bts
and		b.ctrl_type_name	= @engg_cont_elem_type
and     b.caption_req      = 'y'
and     a.section_type      = 'Map'
)
BEGIN 
RAISERROR('For controls defined in Map section,caption required property is not allowed.',16,1)
RETURN
END
 IF  exists 
( select 'X' from ep_ui_section_dtl (nolock)
where   customer_name       = @engg_customer_name
and		project_name	    = @engg_project_name
and		req_no			    = @engg_base_req_no
and		process_name	    = @tmp_proc
and		component_name	    = @tmp_comp
and     activity_name       = @tmp_act
and     ui_name			    = @tmp_ui
and     page_bt_synonym     = @engg_cont_page_bts
and     section_bt_synonym  = @engg_cont_sec_bts
and     section_type        = 'Map'
and     @engg_cont_vorder   > 1
)
BEGIN 
RAISERROR('For controls defined in Map section vertical order should not be greater than 1..',16,1) 
RETURN
END
--TECH-55716 Ends
--TECH-71109
--Tech-75230
--IF ISNULL(@modeflag,'') IN ('I','X','U','Y')
--BEGIN
--IF EXISTS
--(SELECT 'X' 
-- FROM ep_ui_mst WITH (NOLOCK)
-- WHERE	customer_name	= rtrim(@engg_customer_name)
-- AND	project_name	= rtrim(@engg_project_name)
-- AND	req_no			= rtrim(@engg_base_req_no)
-- AND	process_name	= rtrim(@tmp_proc)
-- AND	component_name	= rtrim(@tmp_comp)
-- AND	activity_name	= rtrim(@tmp_act)
-- AND	ui_name			= rtrim(@tmp_ui)
-- AND	DeviceType		= 'P')
--BEGIN
--		IF EXISTS(
--		SELECT  'X'
--		FROM	es_comp_ctrl_type_mst_extn extn (NOLOCK),
--				es_comp_ctrl_type_mst	mst (nolock)
--		WHERE	mst.customer_name			= extn.customer_name
--		AND		mst.project_name			= extn.project_name
--		AND		mst.Process_name			= extn.process_name
--		AND		mst.component_name			= extn.component_name
--		AND		mst.base_ctrl_type			= extn.base_ctrl_type
--		AND		mst.Ctrl_type_name			= extn.ctrl_type_name

--		AND		extn.customer_name			= RTRIM(@engg_customer_name)
--		AND		extn.project_name			= RTRIM(@engg_project_name)
--		AND		extn.process_name			= RTRIM(@tmp_proc)
--		AND		extn.component_name			= RTRIM(@tmp_comp)
--		AND     extn.ctrl_type_name			= RTRIM(@engg_cont_elem_type)
--		AND		extn.base_ctrl_type			= 'GRID'
--		AND		ISNULL(mst.Datagrid, 'N')	= 'N'
--		AND     ISNULL(extn.IsMobile,'N')	= 'N'
--		AND		ISNULL(extn.IsList,'N')		= 'N')
--		BEGIN
--			RAISERROR ('Grid control should have ''Is List'' attribute for MobileUI.',16,1)
--		END
--END

--END
--Tech-75230
--TECH-71109
--kanagavel
	If exists (Select 'x' 
	from	ep_ui_section_dtl(nolock)
	where	customer_name		= rtrim(@engg_customer_name)
	and		project_name		= rtrim(@engg_project_name)
	and		process_name		= rtrim(@tmp_proc)
	and		component_name		= rtrim(@tmp_comp)
	and		activity_name		= rtrim(@tmp_act)
	and		ui_name				= rtrim(@tmp_ui)	
	and		page_bt_synonym		= @engg_cont_page_bts
	and		section_bt_synonym	= @engg_cont_sec_bts
	and		section_type		= 'MobileCalendar') -- changed for the Defect id: TECH-21893
	Begin 
		Raiserror ('''Mobile Calendar'' Sections can not be modified.', 16, 1)
		Return
	End 

	--IF @modeflag = 'D' and @engg_cont_doc = 'System Generated'
	--BEGIN
	--	RAISERROR ('System defined controls cannot be deleted.', 16,1 )
	--	RETURN
	--END
-- Code added for callid TECH-16126 starts
-- Code added for Defect Id: TECH-19347 starts
/**  
	Check for the Controls created for Mobile Grid. */
	if @modeflag in ('U','Y')
	Begin
		If exists (Select 'x' 
		from	ep_ui_control_dtl ctrl(nolock),
				es_comp_ctrl_type_mst comp(nolock)
		where	ctrl.customer_name		= rtrim(@engg_customer_name)
		and		ctrl.project_name		= rtrim(@engg_project_name)
		and		ctrl.process_name		= rtrim(@tmp_proc)
		and		ctrl.component_name		= rtrim(@tmp_comp)
		and		ctrl.activity_name		= rtrim(@tmp_act)
		and		ctrl.ui_name			= rtrim(@tmp_ui)	
		and		ctrl.page_bt_synonym	= @engg_cont_page_bts
		and     ctrl.section_bt_synonym	= @engg_cont_sec_bts
		and     ctrl.control_bt_synonym	in (Select @engg_cont_btsynname
		from    ep_ui_section_dtl (nolock)
		where   customer_name		= rtrim(@engg_customer_name) 
		and		project_name		= rtrim(@engg_project_name)  
		and		req_no				= 'BASE'  
		and		process_name		= rtrim(@tmp_proc)  
		and		component_name		= rtrim(@tmp_comp)
		and		activity_name		= rtrim(@tmp_act)
		and		ui_name				= rtrim(@tmp_ui)
		and		page_bt_synonym		= @engg_cont_page_bts
		and		section_bt_synonym	= @engg_cont_sec_bts
		and     section_type        = 'MobileGrid')

		and     ctrl.customer_name  = comp.customer_name
		and     ctrl.project_name	= comp.project_name
		and     ctrl.process_name   = comp.process_name
		and     ctrl.component_name = comp.component_name  
		and     ctrl.control_type	= comp.ctrl_type_name
		and     base_ctrl_type		<> 'Grid')

		Begin 
			Raiserror ('System Defined Controls cannot be modified.', 16, 1)
			Return
		End 
		else if exists (Select 'x' 
		from	ep_ui_control_dtl ctrl (nolock),
				ep_ui_section_dtl sec (nolock)
		where	ctrl.customer_name		= @engg_customer_name
		and		ctrl.project_name		= @engg_project_name
		and		ctrl.process_name		= @tmp_proc
		and		ctrl.component_name		= @tmp_comp
		and		ctrl.activity_name		= @tmp_act
		and		ctrl.ui_name			= @tmp_ui
		and		ctrl.page_bt_synonym	= @engg_cont_page_bts
		and		ctrl.section_bt_synonym	= @engg_cont_sec_bts
		and     ctrl.control_bt_synonym	= @engg_cont_btsynname
		and		section_type			= 'MobileGrid'
		and     ctrl.customer_name		= sec.customer_name
		and     ctrl.project_name		= sec.project_name
		and     ctrl.process_name		= sec.process_name
		and     ctrl.component_name		= sec.component_name
		and     ctrl.activity_name		= sec.activity_name
		and     ctrl.ui_name			= sec.ui_name
		and     ctrl.page_bt_synonym	= sec.page_bt_synonym
		and     ctrl.section_bt_synonym	= sec.section_bt_synonym)
		begin
		
			EXEC	plf_mobilegrid_validation
								@ctxt_language			= @ctxt_language,
								@ctxt_ouinstance		= @ctxt_ouinstance,
								@ctxt_user				= @ctxt_user,
								@ctxt_role				= @ctxt_role,
								@Customer_Name			= @engg_customer_name,
								@Project_Name			= @engg_project_name,
								@Process_Name			= @tmp_proc,
								@Component_Name			= @tmp_comp,
								@Activity_Name			= @tmp_act,
								@UI_Name				= @tmp_ui,
								@Page_Name				= @engg_cont_page_bts,
								@Section_Name			= @engg_cont_sec_bts,
								@Control_BT_synonym		= @engg_cont_btsynname,
								@ControlType			= @engg_cont_elem_type
					

			Update	ctrl set ctrl.control_type	= @engg_cont_elem_type
			from	ep_ui_control_dtl ctrl (nolock),
					ep_ui_section_dtl sec (nolock)
			where	ctrl.customer_name		= @engg_customer_name
			and		ctrl.project_name		= @engg_project_name
			and		ctrl.process_name		= @tmp_proc
			and		ctrl.component_name		= @tmp_comp
			and		ctrl.activity_name		= @tmp_act
			and		ctrl.ui_name			= @tmp_ui
			and		ctrl.page_bt_synonym	= @engg_cont_page_bts
			and		ctrl.section_bt_synonym	= @engg_cont_sec_bts
			and     ctrl.control_bt_synonym	= @engg_cont_btsynname
			and		section_type			= 'MobileGrid'

			and     ctrl.customer_name		= sec.customer_name
			and     ctrl.project_name		= sec.project_name
			and     ctrl.process_name		= sec.process_name
			and     ctrl.component_name		= sec.component_name
			and     ctrl.activity_name		= sec.activity_name
			and     ctrl.ui_name			= sec.ui_name
			and     ctrl.page_bt_synonym	= sec.page_bt_synonym
			and     ctrl.section_bt_synonym	= sec.section_bt_synonym
			--Code added on 19th July 2021
			--and		ctrl.ExtensionReqd		= @engg_extnreqd --Code added for TECH-60451
		end
	End

	if @modeflag = 'D' and  exists (Select 'x' 
	from	ep_ui_control_dtl ctrl(nolock)
	where	customer_name		= rtrim(@engg_customer_name)
	and		project_name		= rtrim(@engg_project_name)
	and		process_name		= rtrim(@tmp_proc)
	and		component_name		= rtrim(@tmp_comp)
	and		activity_name		= rtrim(@tmp_act)
	and		ui_name				= rtrim(@tmp_ui)	
	and		page_bt_synonym		= @engg_cont_page_bts
	and     section_bt_synonym	= @engg_cont_sec_bts
	and     control_bt_synonym	= (Select @engg_cont_btsynname
	from    ep_ui_section_dtl (nolock)
	where   customer_name		= rtrim(@engg_customer_name) 
	and		project_name		= rtrim(@engg_project_name)  
	and		req_no				= 'BASE'  
	and		process_name		= rtrim(@tmp_proc)  
	and		component_name		= rtrim(@tmp_comp)
	and		activity_name		= rtrim(@tmp_act)
	and		ui_name				= rtrim(@tmp_ui)
	and		page_bt_synonym		= @engg_cont_page_bts
	and		section_bt_synonym	= @engg_cont_sec_bts
	and     section_type        = 'MobileGrid'))
	Begin 
		Raiserror ('System Defined Controls cannot be Deleted.', 16, 1)
		Return
	End 
-- Code added for Defect Id: TECH-19347 ends
-- Code added for callid TECH-16126 ends

-- Code added for callid TECH-18349 starts
	if exists (select 'x'
	from	es_comp_ctrl_type_mst mst (nolock),
			es_comp_ctrl_type_mst_extn extn (nolock)
	where	mst.customer_name	= rtrim(@engg_customer_name)
	and     mst.project_name	= rtrim(@engg_project_name)
	and		mst.process_name    = rtrim(@tmp_proc)  
	and     mst.component_name  = rtrim(@tmp_comp)
	and     mst.ctrl_type_name	= @engg_cont_elem_type
	and		MultiFileSelect		= 'Y'
	and     mst.base_ctrl_type  = 'Edit'   
	and		mst.customer_name	= extn.customer_name  
	and		mst.project_name	= extn.project_name  
	and		mst.process_name	= extn.process_name
	and		mst.component_name	= extn.component_name
	and		mst.ctrl_type_name	= extn.ctrl_type_name)
	begin
		Raiserror('Multi File Select is Applicable only for Grid Columns. Please remove that attribute from Mapped control type in Row No %i',16,1,@fprowno)
		return
	end
-- Code added for callid TECH-18349 ends
	If  isnull(@ui_subtype,'') = 'Dashboard' and @modeflag in('I','X','U','Y','D')
	begin   
		if not exists(select 'x'
		from	es_comp_ctrl_type_mst(nolock)
		where	customer_name	= @engg_customer_name
		and		project_name	= @engg_project_name
		and		req_no			= @engg_base_req_no
		and		process_name	= @tmp_proc
		and		component_name	= @tmp_comp
		and		ctrl_type_name	= @engg_cont_elem_type
		and		base_ctrl_type  = 'EDIT'
		and		isnull(visisble_flag,'')  = 'N'
		union
		select 'x'
		from	es_comp_ctrl_type_mst(nolock)
		where	customer_name		= @engg_customer_name
		and		project_name		= @engg_project_name
		and		req_no				= @engg_base_req_no
		and		process_name		= @tmp_proc
		and		component_name		= @tmp_comp
		and		ctrl_type_name		= @engg_cont_elem_type
		and		base_ctrl_type  in  ('Link') 
		and		isnull(visisble_flag,'')  = 'N')
		begin
			raiserror('Only Hidden Edit & Hidden Link Controls can be created for the UI Subtype ''Dashboard'' in Format tab.',16,1)
			return
		end
	end

-- Code added for Defect Id: TECH-19347 starts
	if exists (select 'x'
	from	es_comp_ctrl_type_mst mst (nolock),
			es_comp_ctrl_type_mst_extn extn (nolock)
	where	mst.customer_name	= rtrim(@engg_customer_name)
	and     mst.project_name	= rtrim(@engg_project_name)
	and		mst.process_name    = rtrim(@tmp_proc)  
	and     mst.component_name  = rtrim(@tmp_comp)
	and     mst.ctrl_type_name	= @engg_cont_elem_type
	and		Metadatabasedlink	= 'Y'
	and     mst.base_ctrl_type  = 'Link'   
	and		mst.customer_name	= extn.customer_name  
	and		mst.project_name	= extn.project_name  
	and		mst.process_name	= extn.process_name
	and		mst.component_name	= extn.component_name
	and		mst.ctrl_type_name	= extn.ctrl_type_name)
	begin
		Raiserror('Meta Data Based Link feature can be enabled for the Base Control type ''DataHyperLink'' for Header Section.Error at Row No %i',16,1,@fprowno)
		return
	end
-- Code added for Defect Id: TECH-19347 ends

/* For section type "SpecialChart" */

--Added for PLF2.0_14096 Starts 

			
	If  @modeflag in('I','X','U','Y')   and @engg_cont_tempid is not null and @ctrl_temp_cat is not null
	begin   
		if not exists(select 'x'
		from	es_comp_ctrl_type_mst(nolock)
		where	customer_name	= @engg_customer_name
		and		project_name	= @engg_project_name
		and		req_no			= @engg_base_req_no
		and		process_name	= @tmp_proc
		and		component_name	= @tmp_comp
		and		ctrl_type_name	= @engg_cont_elem_type
		and		base_ctrl_type  in  ('EDIT')  
		and		editable_flag	= 'N'
		union
		select 'x'
		from	es_comp_ctrl_type_mst(nolock)
		where	customer_name	= @engg_customer_name
		and		project_name	= @engg_project_name
		and		req_no			= @engg_base_req_no
		and		process_name	= @tmp_proc
		and		component_name	= @tmp_comp
		and		ctrl_type_name	= @engg_cont_elem_type
		and		base_ctrl_type  in  ('DataHyperlink') ---Changed
		--and editable_flag  = 'N'
		)
		begin
			raiserror('Template ID is applicable only for displayonly and datahyperlink',16,1)
			return
		end
	end


--Added for PLF2.0_14096 Ends 
	If  @modeflag in('I','X','U','Y')  
	Begin
		If exists (Select 'x' 
		from	ep_phone_section_dtl(nolock)
		where	customer_name		= rtrim(@engg_customer_name)
		and		project_name		= rtrim(@engg_project_name)
		and		process_name		= rtrim(@tmp_proc)
		and		component_name		= rtrim(@tmp_comp)
		and		activity_name		= rtrim(@tmp_act)
		and		ui_name				= rtrim(@tmp_ui)	
		and		page_bt_synonym		= @engg_cont_page_bts
		and		parent_section		= @engg_cont_sec_bts)
		Begin 
			Raiserror('The Section %d is a parent section for Phone. Hence controls cannot be saved in this Section',16,4,@engg_cont_sec_bts)
			Return
		End

		If exists (Select 'x' 
		from	ep_tablet_section_dtl(nolock)
		where	customer_name		= rtrim(@engg_customer_name)
		and		project_name		= rtrim(@engg_project_name)
		and		process_name		= rtrim(@tmp_proc)
		and		component_name		= rtrim(@tmp_comp)
		and		activity_name		= rtrim(@tmp_act)
		and		ui_name				= rtrim(@tmp_ui)	
		and		page_bt_synonym		= @engg_cont_page_bts
		and		parent_section		= @engg_cont_sec_bts)
		Begin 
			Raiserror('The Section %d is a parent section for Tablet. Hence controls cannot be saved in this Section',16,4,@engg_cont_sec_bts)
			Return
		End
	End

	if @modeflag in('U', 'Y', 'I', 'X','Z')
	begin 
		select  @section_type= section_type
		from  ep_ui_section_dtl (nolock)
		where  customer_name		= @engg_customer_name
		and    project_name			= @engg_project_name
		and    process_name			= @tmp_proc
		and    component_name		= @tmp_comp
		and    activity_name		= @tmp_act
		and    ui_name				= @tmp_ui
  		and    page_bt_synonym		= @engg_cont_page_bts
   		and    section_bt_synonym	= @engg_cont_sec_bts
		and	   section_type		 in ('ButtonBar','SpecialChart','Map')
			--and    req_no				= @engg_req_no
		if @section_type='ButtonBar'
		begin
			if  not exists (select 'X' 
			from	es_comp_ctrl_type_mst (nolock)
			where	customer_name		=	@engg_customer_name
			and		project_name		=	@engg_project_name
			and		process_name		=	@tmp_proc
			and		component_name		=	@tmp_comp
			and		ctrl_type_name		=	@engg_cont_elem_type
			and		base_ctrl_type		in ('Button','EDIT')
			and 	@engg_cont_elem_type not in ('Filler','Filler2') )
			begin 
				Raiserror('Only Button and EDIT control is allowed for section type ButtonBar',16,1)
				return
			end
		end

		if @section_type='SpecialChart'
		begin
			if  not exists ( select 'X' 
			from	es_comp_ctrl_type_mst (nolock)
			where	customer_name		=	@engg_customer_name
			and		project_name		=	@engg_project_name
			and		process_name		=	@tmp_proc
			and		component_name		=	@tmp_comp
			and		ctrl_type_name		=	@engg_cont_elem_type
			and		base_ctrl_type		= 'EDIT'
			and		editable_flag		= 'Y')
			begin 
				Raiserror('Only EDIT control is allowed for section type SpecialChart',16,1)
				return
			end
		end
		if @section_type='Map'
		begin
			if  not exists ( select 'X' 
			from	es_comp_ctrl_type_mst (nolock)
			where	customer_name		=	@engg_customer_name
			and		project_name		=	@engg_project_name
			and		process_name		=	@tmp_proc
			and		component_name		=	@tmp_comp
			and		ctrl_type_name		=	@engg_cont_elem_type
			and		base_ctrl_type		in ('Button','EDIT'))
			begin 
				Raiserror('Only Button and EDIT control is allowed for section type Map',16,1)
				return
			end
		end		
	end

--Kanagavel starts
	if @modeflag in('U', 'Y', 'I', 'X','Z')
	begin 
		if exists (select  'X'
		from  ep_ui_section_dtl (nolock)
		where  customer_name	= @engg_customer_name
		and    project_name		= @engg_project_name
		and    process_name		= @tmp_proc
		and    component_name	= @tmp_comp
		and    activity_name	= @tmp_act
		and    ui_name			= @tmp_ui
  		and    page_bt_synonym	= @engg_cont_page_bts
   		and    section_bt_synonym= @engg_cont_sec_bts
		and	   section_type		='Map')
		begin 
			select @Map_count = count( distinct b.Map_In_Req)
			from   ep_ui_control_dtl a(nolock),es_comp_ctrl_type_mst b (nolock)
			where  a.customer_name		=	@engg_customer_name
			and    a.project_name		=	@engg_project_name
			and    a.process_name		=	@tmp_proc
			and    a.component_name		=	@tmp_comp
			and    a.activity_name		=	@tmp_act
			and    a.ui_name			=	@tmp_ui
			and    a.page_bt_synonym	= @engg_cont_page_bts
			and    a.section_bt_synonym	= @engg_cont_sec_bts
			and	   a.customer_name		=	b.customer_name	
			and	   a.project_name		=	b.project_name
			and	   a.process_name		=	b.process_name
			and	   a.component_name		=	b.component_name
			and	   a.control_type		= b.ctrl_type_name						
			and	   b.base_ctrl_type		=	'EDIT'
			and	   b.Map_In_Req			=	'Y' 

			if @Map_count >1
			begin
				raiserror('Only one control is allowed to have map in req property as Y',16,1)
				return
			end
						
			select @Map_count = count( distinct b.Map_Out_Req)
			from   ep_ui_control_dtl a(nolock),es_comp_ctrl_type_mst b (nolock)
			where  a.customer_name		=	@engg_customer_name
			and    a.project_name		=	@engg_project_name
			and    a.process_name		=	@tmp_proc
			and    a.component_name		=	@tmp_comp
			and    a.activity_name		=	@tmp_act
			and    a.ui_name			=	@tmp_ui
			and    a.page_bt_synonym	= @engg_cont_page_bts
			and    a.section_bt_synonym	= @engg_cont_sec_bts
			and	   a.customer_name		=	b.customer_name	
			and	   a.project_name		=	b.project_name
			and	   a.process_name		=	b.process_name
			and	   a.component_name		=	b.component_name
			and	   a.control_type		= b.ctrl_type_name									
			and	   b.base_ctrl_type		=	'EDIT'
			and	   b.Map_Out_Req		=	'Y' 

			if @Map_count >1
			begin
				raiserror('Only one control is allowed to have map Out req property as Y',16,1)
				return
			end	
		end		
	end						
  
	Select  @tmp_ctl    = base_ctrl_type,  
			@help_req	= help_req,  
			@event_req  = event_handling_req,  
			@zoom_req	= zoom_req,  
			@editable	= editable_flag,  
			@visible	= visisble_flag,  
			@spin_req	= spin_required,--added by Ramanujam for spin ctrl chk,  
			@report_req = report_req, -- code modified by Anuradha on 06-Nov-2006 for the Bug ID :: PNR2.0_10832  
			@Label_Link =   Label_Link --Bug ID:PNR2.0_36309  
			,@Qliklink	= Qliklink  
	from	es_comp_ctrl_type_mst_vw (nolock)  
	where	customer_name   = @engg_customer_name  
	and		project_name	= @engg_project_name  
	and		process_name	= @tmp_proc  
	and		component_name  = @tmp_comp  
	and		ctrl_type_name  = @engg_cont_elem_type  
	and     req_no			= @engg_base_req_no  

	
-- On 21-Mar-2018 Ends

			


/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P begin*/  
	select	@tmp_control_type	= control_type ,
			@tmp_cotrol_id		= control_id
	from	ep_ui_control_dtl (nolock)  
	where	customer_name		= @engg_customer_name  
	and		project_name		= @engg_project_name  
	and		process_name		= @tmp_proc  
	and		component_name		= @tmp_comp  
	and		activity_name		= @tmp_act  
	and		ui_name				= @tmp_ui  
	and		page_bt_synonym		= @engg_cont_page_bts  
	and		section_bt_synonym  = @engg_cont_sec_bts  
	and		control_bt_synonym  = @engg_cont_btsynname  
--	and		req_no				= @engg_base_req_no  
/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P End*/  

--Added by Kanagavel For Treegrid Deletion
	If @modeflag  = 'D' and   exists (Select 'K' 
	from	es_comp_ctrl_type_mst_vw (nolock)  
	where	customer_name		= @engg_customer_name  
	and		project_name   		= @engg_project_name  
	and		process_name   		= @tmp_proc  
	and		component_name		= @tmp_comp  
	and		ctrl_type_name		= @engg_cont_elem_type  
	and		req_no      		= @engg_base_req_no 
	and		base_ctrl_type	in ('Slider', 'TreeGrid' ))
	--and   renderas		=	'IsTreeGrid' )
	begin 
		If exists (select 'K'
		from	ep_ui_grid_dtl (nolock)  
		where	customer_name		= @engg_customer_name  
		and		project_name		= @engg_project_name  
		and		process_name		= @tmp_proc  
		and		component_name		= @tmp_comp  
		and		activity_name		= @tmp_act  
		and		ui_name				= @tmp_ui  
		and		page_bt_synonym		= @engg_cont_page_bts  
		and		section_bt_synonym  = @engg_cont_sec_bts  
		and		control_bt_synonym  = @engg_cont_btsynname)	
			Delete 	ep_ui_grid_dtl 
			where	customer_name   = @engg_customer_name  
			and		project_name	= @engg_project_name  
			and		process_name	= @tmp_proc  
			and		component_name  = @tmp_comp  
			and		activity_name   = @tmp_act  
			and		ui_name			= @tmp_ui  
			and		page_bt_synonym = @engg_cont_page_bts  
			and		section_bt_synonym  = @engg_cont_sec_bts  
			and		control_bt_synonym  = @engg_cont_btsynname
	end 

--Added by Kanagavel For Stacked Link Deletion
	If @modeflag  = 'D' and @tmp_ctl = 'StackedLinks'
	begin 
		If exists (select 'K'
		from ep_ui_grid_dtl (nolock)  
		where customer_name		= @engg_customer_name  
		and  project_name		= @engg_project_name  
		and  process_name		= @tmp_proc  
		and  component_name		= @tmp_comp  
		and  activity_name		= @tmp_act  
		and  ui_name			= @tmp_ui  
		and  page_bt_synonym	= @engg_cont_page_bts  
		and  section_bt_synonym = @engg_cont_sec_bts  
		and  control_bt_synonym = @engg_cont_btsynname)	
			Delete 	ep_ui_grid_dtl 
			where	customer_name		= @engg_customer_name  
			and		project_name		= @engg_project_name  
			and		process_name		= @tmp_proc  
			and		component_name		= @tmp_comp  
			and		activity_name		= @tmp_act  
			and		ui_name				= @tmp_ui  
			and		page_bt_synonym		= @engg_cont_page_bts  
			and		section_bt_synonym  = @engg_cont_sec_bts  
			and		control_bt_synonym  = @engg_cont_btsynname
	end 
		-- Added for Rule Builder Starts Defect ID: TECH-35368
		IF	ISNULL(@modeflag,'') IN ('I','X')
		AND EXISTS (SELECT 'X'
		from  ep_ui_control_dtl b(nolock),es_comp_ctrl_type_mst_Extn a (nolock)
		where	b.customer_name			=	@engg_customer_name
		and		b.project_name			=	@engg_project_name
		and		b.process_name			=	@tmp_proc	
		and		b.component_name		=	@tmp_comp	
		and		b.activity_name			=	@tmp_act	
		and		b.ui_name				=	@tmp_ui	
		and		b.page_bt_synonym		=	@engg_cont_page_bts	
		and		b.section_bt_synonym	=	@engg_cont_sec_bts
		and		 a.customer_name		=	b.customer_name	
		and		 a.project_name			=	b.project_name
		and		 a.process_name			=	b.process_name
		and		 a.component_name		=	b.component_name
		and		 b.control_type			=	a.ctrl_type_name
		and		 a.base_ctrl_type		=	'GRID'
		and		 a.RuleBuilder			=	'Y' 
		)
		BEGIN
			Raiserror('User defined Controls cannot be associated with the Rule Builder Enabled Control.', 16, 1)
			Return
		END
		-- Added for Rule Builder Ends Defect ID: TECH-35368

		-- Calendar Control Validation Starts
		IF	ISNULL(@modeflag,'') IN ('I','X')
		AND EXISTS (SELECT 'X'
		from  ep_ui_control_dtl b(nolock),es_comp_ctrl_type_mst_Extn a (nolock)
		where	b.customer_name			=	@engg_customer_name
		and		b.project_name			=	@engg_project_name
		and		b.process_name			=	@tmp_proc	
		and		b.component_name		=	@tmp_comp	
		and		b.activity_name			=	@tmp_act	
		and		b.ui_name				=	@tmp_ui	
		and		b.page_bt_synonym		=	@engg_cont_page_bts	
		and		b.section_bt_synonym	=	@engg_cont_sec_bts
		and		 a.customer_name		=	b.customer_name	
		and		 a.project_name			=	b.project_name
		and		 a.process_name			=	b.process_name
		and		 a.component_name		=	b.component_name
		and		 b.control_type			=	a.ctrl_type_name
		and		 a.base_ctrl_type		=	'GRID'
		and		 a.CalendarControl		=	'Y' 
		)
		BEGIN
			Raiserror('User defined Controls cannot be associated with the Calendar attribute Enabled Control.', 16, 1)
			Return
		END
		-- Calendar Control Validation Ends

----------Template Related Errors-----
	if @modeflag in('U', 'Y', 'I', 'X','Z')
	Begin
		If exists (Select 'x' from	
		es_template_mst	(nolock)
		where	customer_name	= @engg_customer_name
		and		project_name	= @engg_project_name
		and		TemplateID		= @engg_cont_tempid)
		Begin
			Raiserror ('System	Template "%s" cannot be used as a template. Error in Row %i.',16,4,@engg_cont_tempid,@fprowno)
			Return
		End
	
		if isnull(@engg_cont_tempid,'') = '' and isnull(@ctrl_temp_cat,'') <>''
		Begin
		--Raiserror ('Template Category cannot be specified as the Template ID is blank. Error in Row %i.',16,4,@fprowno)
		--Return
			update ep_ui_control_dtl
			set @engg_cont_tempid = 'y'
			where customer_name       = @engg_customer_name
			and project_name          = @engg_project_name
			and process_name          = @tmp_proc 
			and component_name        = @tmp_comp 
			and  activity_name        = @tmp_act  
			and  ui_name              = @tmp_ui  
			and  page_bt_synonym      = @engg_cont_page_bts  
			and  section_bt_synonym   = @engg_cont_sec_bts  
			and  control_bt_synonym   = @engg_cont_btsynname	
			--and	 ExtensionReqd		  =	@engg_extnreqd --Code added for TECH-60451
		End	
	
		if isnull(@engg_cont_tempid,'') = '' and isnull(@ctrl_temp_specific,'') <>''
		Begin
			Raiserror ('Template Specification cannot be specified as the Template ID is blank. Error in Row %i.',16,4,@fprowno)
			Return
		End

	--code commented by venkatesan K 30Mar 2017
	/*IF EXISTS  ( Select 'X'
	from ep_new_ui_mst (nolock)
	where 	customer_name  = @engg_customer_name
	and 	project_name     = @engg_project_name
	and 	process_name     = @tmp_proc 
	and 	component_name   = @tmp_comp 
	and 	activity_name   = @tmp_act  
	and 	ui_name         = @tmp_ui ) and    ISNULL( @ctrl_temp_cat,'') = 'Placeholder Based' 
 	Begin 
	Raiserror ('For the new ui''s ,only column basd template is applicable . Error in Row %i.',16,4,@fprowno)
	return
	end*/
	End

	Select  @ctrl_temp_cat		= parameter_code
	from	ep_device_quick_code_met (nolock)
	where 	parameter_type		= 'TemplateCategory'
	and		parameter_text		= @ctrl_temp_cat

--9547 starts  
	if @modeflag not in ('S','Z')  
	begin  
		if exists ( select 'x'  
		from	ep_ui_control_dtl a(nolock),  
				ep_ui_section_dtl b(nolock)  
		where	b.customer_name		= @engg_customer_name  
		and		b.project_name		= @engg_project_name  
		and		b.process_name		= @tmp_proc  
		and		b.component_name	= @tmp_comp  
		and		b.activity_name		= @tmp_act  
		and		b.ui_name			= @tmp_ui  
		and		b.page_bt_synonym   = @engg_cont_page_bts  
		and		b.section_bt_synonym = @engg_cont_sec_bts  
		and		b.customer_name		= a.customer_name  
		and		b.project_name		= a.project_name  
		and		b.process_name		= a.process_name  
		and		b.component_name	= a.component_name  
		and		b.activity_name		= a.activity_name  
		and		b.ui_name			= a.ui_name  
		and		b.page_bt_synonym	= a.page_bt_synonym  
		and		b.section_bt_synonym = a.section_bt_synonym  
		and		( a.control_bt_synonym   like 'BBar_'+@engg_cont_sec_bts+'_edt' or   
				a.control_bt_synonym   like 'Pop_'+@engg_cont_sec_bts+'_edt'  or  
				a.control_bt_synonym   like 'Pop_'+@engg_cont_sec_bts+'_tsk' )   
		and		b.section_type in ('ButtonBar','PopUp'))  
		 begin   
		   select @msg = 'Default Controls added for ButtonBar or PopUp sections cannot be modified in rowno:'+ltrim(rtrim(cast(@fprowno as char)))+', Kindly contact Tech team.'  
		   raiserror(@msg,16,1)  
		   return  
		 end  
	end  
--9547 ends 
	
	
	select  @tmp_sectiontype	= section_type
	from	ep_ui_section_dtl (nolock)
	where  customer_name		= @engg_customer_name
	and    project_name			= @engg_project_name
	and    process_name			= @tmp_proc
	and    component_name		= @tmp_comp
	and    activity_name		= @tmp_act
	and    ui_name				= @tmp_ui
  	and    page_bt_synonym		= @engg_cont_page_bts
   	and    section_bt_synonym	= @engg_cont_sec_bts

	
	IF @modeflag in ('I', 'X' )
	BEGIN
		if @tmp_sectiontype='ListItem'	AND 
			not exists ( select 'X' 
						from	es_comp_ctrl_type_mst  with(NOLOCK)
						where	customer_name		= @engg_customer_name
						and		project_name		= @engg_project_name
						and		process_name		= @tmp_proc
						and		component_name		= @tmp_comp                
						AND     ctrl_type_name		= @engg_cont_elem_type
						AND     ((base_ctrl_type    IN ('Link', 'DataHyperLink'))
								OR base_ctrl_type     = 'Edit' AND editable_flag = 'N'))
        begin 
			Raiserror('Only DisplayOnly and DataHyperLink controls are allowed for section type ListItem',16,1)
			return    
		end    
	END

	IF (@modeflag in ('I', 'X', 'U', 'Y' )	
		AND @engg_cont_elem_type	IN ('HLINE', 'VLINE')
		AND NOT EXISTS ( select 'X' 
					from	ep_ui_mst  with(NOLOCK)
                    WHERE	customer_name		= customer_name
                    AND     project_name		= project_name
                    AND     process_name		= process_name
                    AND     component_name		= component_name   
					AND		activity_name		= @tmp_act
					AND		ui_name				= @tmp_ui                
					AND		DeviceType			IN ('P', 'T', 'B'))
		)				 
    begin 
        Raiserror('''HLINE'' & ''VLINE'' Control types are applicable only for mobile UIs.',16,1)
        return    
    end  

	SELECT	@IsDataGrid			= 'N'
	SELECT	@IsChips			= 'N'

	select	@base_ctrl_type_tmp = base_ctrl_type ,
			@IsDataGrid			= ISNULL(DataGrid ,'N') --Code Added for Defect ID : TECH-39534			
	from	es_comp_ctrl_type_mst_vw (nolock)  
	where	customer_name		= @engg_customer_name  
	and		project_name		= @engg_project_name  
	and		process_name		= @tmp_proc  
	and		component_name		= @tmp_comp  
	and		ctrl_type_name		= @engg_cont_elem_type  
	and		req_no				= @engg_base_req_no 

	select	@IsChips			= ISNULL(IsChips, 'N')
	from	es_comp_ctrl_type_mst_extn (nolock)  
	where	customer_name		= @engg_customer_name  
	and		project_name		= @engg_project_name  
	and		process_name		= @tmp_proc  
	and		component_name		= @tmp_comp  
	and		ctrl_type_name		= @engg_cont_elem_type  
	and		req_no				= @engg_base_req_no 

	--select 'tt', @IsDataGrid, @IsChips
	---- Added for TECH-37471 Starts
	--IF (@modeflag in ('I', 'X', 'U', 'Y' )	
	--AND @base_ctrl_type_tmp	= 'Grid'
	--AND (@IsDataGrid	= 'N' --Code Added for Defect ID : TECH-39534
	--	AND @IsChips	= 'N'
	--	AND @RenderAs	<> 'Tag')
	--AND EXISTS ( select 'X' 
	--			from	ep_ui_mst  with(NOLOCK)
 --               WHERE	customer_name		= customer_name
 --               AND     project_name		= project_name
 --               AND     process_name		= process_name
 --               AND     component_name		= component_name   
	--			AND		activity_name		= @tmp_act
	--			AND		ui_name				= @tmp_ui                
	--			AND		DeviceType			IN ('P', 'T', 'B'))
	--)				 
 --   begin 
 --       Raiserror('Please use ''Mobile Grid'' for mobile UIs.',16,1)
 --       return    
 --   end  

	---- Added for TECH-37471 Ends

	IF @modeflag in ('I', 'X', 'U', 'Y' )	
	BEGIN	
		IF NOT EXISTS ( select 'X' 
					from	ep_ui_mst  with(NOLOCK)
                    WHERE	customer_name		= customer_name
                    AND     project_name		= project_name
                    AND     process_name		= process_name
                    AND     component_name		= component_name   
					AND		activity_name		= @tmp_act
					AND		ui_name				= @tmp_ui                
					AND		DeviceType			IN ('P', 'T', 'B'))
		AND (@engg_dynamicstyle	 = '1' OR @engg_imageasdata = '1')				 
		begin 
		
			Raiserror('''Dynamic style'' & ''ImageAsData'' are applicable only for mobile UIs.',16,1)
			return    
		end    

		
		IF  (@engg_dynamicstyle	 = '1' OR @engg_imageasdata = '1')	
		AND NOT EXISTS (SELECT 'X'
						FROM	es_comp_ctrl_Type_mst typ (nolock)
						WHERE	customer_name		= customer_name
						AND     project_name		= project_name
						AND     process_name		= process_name
						AND     component_name		= component_name  
						AND		ctrl_type_name		= @engg_cont_elem_type
						AND		(Base_ctrl_Type		IN ('DataHyperLink', 'Link')
								OR (Base_ctrl_Type = 'Edit' AND Editable_flag = 'N'))
						)
		BEGIN
			Raiserror('''Dynamic style'' & ''ImageAsData'' are applicable only for DisplayOnly and DataHyperLink controls of mobile UIs.',16,1)
			return    
		end    
	
		IF  (@engg_dynamicstyle	 = '1' OR @engg_imageasdata = '1')	
		AND NOT EXISTS (SELECT 'X'
						FROM	es_comp_ctrl_Type_mst typ (nolock)
						WHERE	customer_name		= customer_name
						AND     project_name		= project_name
						AND     process_name		= process_name
						AND     component_name		= component_name  
						AND		ctrl_type_name		= @engg_cont_elem_type
						AND		@engg_cont_elem_type IN ('DataHyperLink', 'DisplayOnly'))
		BEGIN
			Raiserror('''Dynamic style'' & ''ImageAsData'' are applicable only for DisplayOnly and DataHyperLink controls of mobile UIs.',16,1)
			return    
		end    

	END
	
				

	if @modeflag = 'D'  
	begin  
		If exists (Select 'x' from ep_phone_control_dtl(nolock)
		where	customer_name		= @engg_customer_name
		and		project_name		= @engg_project_name
		and		process_name		= @tmp_proc
		and		component_name		= @tmp_comp
		and		activity_name		= @tmp_act
		and		ui_name				= @tmp_ui
		and		page_bt_synonym		= @engg_cont_page_bts
		and     section_bt_synonym	= @engg_cont_sec_bts	
		and		control_bt_synonym	= @engg_cont_btsynname)
		or exists (Select 'x' from ep_tablet_control_dtl(nolock)
		where	customer_name		= @engg_customer_name
		and		project_name		= @engg_project_name
		and		process_name		= @tmp_proc
		and		component_name		= @tmp_comp
		and		activity_name		= @tmp_act
		and		ui_name				= @tmp_ui
		and		page_bt_synonym		= @engg_cont_page_bts
		and     section_bt_synonym	= @engg_cont_sec_bts
		and		control_bt_synonym	= @engg_cont_btsynname	)
		Begin
			insert into ep_ui_control_del_dtl   
				(customer_name,			project_name,			process_name,			component_name,			activity_name,  
				ui_name,				page_bt_synonym,		section_bt_synonym,		control_bt_synonym,		control_type,  
				req_no,					guid,					Deletion_type)  
		   Values  
			   (@engg_customer_name,	@engg_project_name,		@tmp_proc,				@tmp_comp,				@tmp_act,   
			   @tmp_ui,					@engg_cont_page_bts,	@engg_cont_sec_bts,		@engg_cont_btsynname,	@tmp_control_type, 
			   @engg_base_req_no,		@guid,					'Control')  
		     
			select @del_flag_ph = 'F'  
			
		
			If isnull(@engg_del_controls,'') = ''  
			Begin  
				 select @engg_del_controls = @engg_cont_btsynname  
			End  
			Else  
			Begin  
				select @engg_del_controls = isnull(@engg_del_controls,'') + ', ' + @engg_cont_btsynname  
			End  
		End  
		Else  
		Begin  
			select @del_flag_ph = 'T'  
		End  
	End
 
 
-- Code Added for PNR2.0_32228 Starts  
	if @modeflag = 'D'  
	begin  
		 If exists ( select 'x'  
		 from de_fw_des_ilbo_Service_view_datamap (nolock)  
		 where customer_name		= @engg_customer_name  
		 and   project_name			= @engg_project_name  
		 and   process_name			= @tmp_proc  
		 and   component_name		= @tmp_comp  
		 and   activity_name		= @tmp_act  
		 and   ilbocode				= @tmp_ui  
		 and   page_bt_synonym		= @engg_cont_page_bts  
		 and   control_bt_synonym	= @engg_cont_btsynname) 
		Begin  
			if not exists (select 'x'
			from	ep_ui_control_del_dtl (nolock)
			where	customer_name		= @engg_customer_name
			and		project_name		= @engg_project_name  
			and     req_no				= 'BASE'
			and		process_name		= @tmp_proc  
			and		component_name		= @tmp_comp  
			and		activity_name		= @tmp_act  
			and		ui_name				= @tmp_ui  
			and		page_bt_synonym		= @engg_cont_page_bts  
			and		section_bt_synonym	= @engg_cont_sec_bts
			and		control_bt_synonym	= @engg_cont_btsynname
			and     control_type		= @tmp_control_type)
			begin
				insert into ep_ui_control_del_dtl 
					(customer_name,			project_name,			process_name,		component_name,			activity_name,			ui_name,  
					page_bt_synonym,		section_bt_synonym,		control_bt_synonym, control_type,			req_no,					guid, 
					Deletion_type )--,change_Type) --11536 
				Values  
					(@engg_customer_name,		@engg_project_name,		@tmp_proc,			  @tmp_comp,				@tmp_act,				@tmp_ui,  
					 @engg_cont_page_bts,		@engg_cont_sec_bts,		@engg_cont_btsynname, @tmp_control_type,		@engg_base_req_no,		@guid, 
					'Control' )--,'delete')  
			end

			select @del_flag = 'F'  
		  -- Code Modified for Bug Id :PNR2.0_33469 Starts  
			 If isnull(@engg_del_controls,'') = ''  
			Begin  
				select @engg_del_controls = @engg_cont_btsynname  
			End  
			Else  
			Begin  
				select @engg_del_controls = isnull(@engg_del_controls,'') + ', ' + @engg_cont_btsynname  
			End   
	  -- Code Modified for Bug Id :PNR2.0_33469 Ends  
		End  
		 Else  
		 Begin  
		  select @del_flag = 'T'  
		 End  

	/** 
		Deleting the hidden control, when corresponding control has been deleted for Edit Mask.  
		Code added for the Defect id: TECH-20326 starts. */

			delete from ep_component_glossary_mst_lng_extn
			where	customer_name		= @engg_customer_name  
			and		project_name		= @engg_project_name  
			and		process_name		= @tmp_proc  
			and		component_name		= @tmp_comp 
			and		bt_synonym_name		= 'h'+@engg_cont_btsynname+'_rd'
	
			delete from ep_component_glossary_mst 
			where	customer_name		= @engg_customer_name  
			and		project_name		= @engg_project_name  
			and		process_name		= @tmp_proc  
			and		component_name		= @tmp_comp 
			and		bt_synonym_name		= 'h'+@engg_cont_btsynname+'_rd'

			delete from ep_ui_control_dtl  
			where	customer_name		= @engg_customer_name  
			and		project_name		= @engg_project_name  
			and		process_name		= @tmp_proc  
			and		component_name		= @tmp_comp  
			and		activity_name		= @tmp_act  
			and		ui_name				= @tmp_ui  
			and		page_bt_synonym		= '[mainscreen]'
			and		section_bt_synonym  = 'PrjhdnSection'
			and		control_type		= 'HiddenEdit'  
			and		control_bt_synonym	= 'h'+ @engg_cont_btsynname + '_rd'  
	/** Code added for the Defect id: TECH-20326 ends.*/ 

 -- Code added for Bug Id :PNR2.0_33469 Starts  
	Declare @task  engg_name  
	  
	 If isnull(@tmp_ctl,'') in ('Button', 'Link')  
	 Begin  
		  select	@task    = b.task_name  
		  from		ep_ui_control_dtl a (nolock),  
					ep_action_mst b (nolock)  
		  where		a.customer_name		= b.customer_name  
		  and		a.project_name		= b.project_name  
		  and		a.process_name		= b.process_name  
		  and		a.component_name	= b.component_name  
		  and		a.activity_name		= b.activity_name  
		  and		a.ui_name			= b.ui_name  
		  and		a.page_bt_synonym	= b.page_bt_synonym  
		  and		a.control_bt_synonym= b.primary_control_bts  
  
		  and  a.customer_name			= @engg_customer_name  
		  and  a.project_name			= @engg_project_name  
		  and  a.process_name			= @tmp_proc  
		  and  a.component_name			= @tmp_comp  
		  and  a.activity_name			= @tmp_act  
		  and  a.ui_name				= @tmp_ui  
		  and  a.page_bt_synonym		= @engg_cont_page_bts  
		  and  a.control_bt_synonym		= @engg_cont_btsynname  
  
		  If exists ( select 'x'  
		  from	de_task_service_map (nolock)  
		  where customer_name	= @engg_customer_name  
		  and	project_name	= @engg_project_name  
		  and	process_name	= @tmp_proc  
		  and	component_name  = @tmp_comp  
		  and	activity_name	= @tmp_act  
		  and	ui_name			= @tmp_ui  
		  and	task_name		= @task )  
		  and not exists (Select 'x' --code modified by 11536 for the bug id TECH-18659
			 from ep_ui_control_del_dtl a (nolock)
			  where a.customer_name		= @engg_customer_name  
			  and   a.project_name		= @engg_project_name  
			  and   a.process_name		= @tmp_proc 
			  and   a.component_name	= @tmp_comp 
			  and   a.activity_name		= @tmp_act  
			  and   a.ui_name			= @tmp_ui  
			  and   a.page_bt_synonym	= @engg_cont_page_bts 
			  and   a.control_bt_synonym	= @engg_cont_btsynname )

		  Begin  
			   insert into ep_ui_control_del_dtl   
					(customer_name,			project_name,			process_name,			component_name,			activity_name,			ui_name,  
					page_bt_synonym,		section_bt_synonym,		control_bt_synonym,		control_type,			req_no,					guid, 
					Deletion_type)  
			   Values  
					(@engg_customer_name,	@engg_project_name,		@tmp_proc,				@tmp_comp,				@tmp_act,				@tmp_ui,  
					 @engg_cont_page_bts,	@engg_cont_sec_bts,		@engg_cont_btsynname,	@tmp_control_type,		@engg_base_req_no,		@guid, 
					 'Control')  
     
			   select @del_flag = 'F'  
    
				If isnull(@engg_del_controls,'') = ''  
				Begin  
					select @engg_del_controls = @engg_cont_btsynname  
				End  
				Else  
				Begin  
					select @engg_del_controls = isnull(@engg_del_controls,'') + ', ' + @engg_cont_btsynname  
				End  
			End  
			Else  
			Begin  
				select @del_flag = 'T'  
			End  
		End  
 -- Code added for Bug Id :PNR2.0_33469 Ends   
	End  

-- Code added against Tech-218 to update associated control for chart section starts
	If @modeflag in ('D')  
	Begin  
		update	b set
				b.Associated_control = null
		from	ep_ui_control_dtl  a(nolock),
				ep_ui_section_dtl b(nolock), 
				es_comp_ctrl_type_mst c(nolock)
	    where	a.customer_name		= @engg_customer_name  
		and		a.project_name		= @engg_project_name  
		and		a.process_name		= @tmp_proc  
		and		a.component_name	= @tmp_comp  
		and		a.activity_name		= @tmp_act  
		and		a.ui_name			= @tmp_ui  
		and		a.page_bt_synonym	= @engg_cont_page_bts  
		and		a.section_bt_synonym= @engg_cont_sec_bts  
		and		a.control_bt_synonym= @engg_cont_btsynname 
		and		b.customer_name		= a.customer_name
		and		b.project_name		= a.project_name
		and		b.process_name		= a.process_name
		and		b.component_name	= a.component_name
		and		b.activity_name		= a.activity_name
		and		b.ui_name			=a.ui_name
		and		b.page_bt_synonym	=a.page_bt_synonym
		and		b.section_bt_synonym=a.section_bt_synonym
		and		b.section_type		='chart'
		and		b.customer_name		= c.customer_name
		and		b.project_name		= c.project_name
		and		b.process_name		= c.process_name
		and		b.component_name	= c.component_name
		and		a.control_type		= c.ctrl_type_name
		and		c.base_ctrl_type	in ('Edit')
		--and		a.ExtensionReqd		=	@engg_extnreqd --Code added for TECH-60451
	end 
-- Code added against Tech-218 to update associated control for chart section ends 
-- Code Added for PNR2.0_32228 End   
-- Code Added for the BugId: PNR2.0_28003 Starts  
	if @modeflag in('U', 'Y', 'I', 'X')  
	BEGIN  
  /* PLF2.0_18888 
 IF EXISTS  
 (  
 SELECT 'X'  
 FROM ep_ui_section_dtl (NOLOCK)  
 WHERE customer_name    = @engg_customer_name  
 AND   project_name    = @engg_project_name  
 AND   process_name    = @tmp_proc  
 AND   component_name   = @tmp_comp  
 AND   activity_name    = @tmp_act  
 AND   ui_name       = @tmp_ui  
 AND   page_bt_synonym   = @engg_cont_page_bts  
 AND   section_bt_synonym  = @engg_cont_sec_bts  
 AND   upper(isnull(visisble_flag,''))  = 'N'  
 AND  req_no       = @engg_base_req_no  
 )  
 BEGIN  
  If @base_ctrl_type_tmp = 'Grid'  
  Begin  
   RAISERROR('Grid Control cannot be defined in Hidden Section.Error at Rowno:%i',16,1, @fprowno)  
   RETURN  
  End  
 END  
  */ --PLF2.0_18888  ends
  
		 if exists (select 'x'  
		 from  es_comp_ctrl_type_mst  (nolock)  
		 where customer_name = @engg_customer_name  
		 and  project_name = @engg_project_name  
		 and  process_name = @tmp_proc  
		 and  component_name = @tmp_comp  
		 and  ctrl_type_name = @tmp_control_type  
		 and  base_ctrl_type = 'Grid'  
		 and isnull(visisble_flag,'') <> 'Y'  )  
		 begin  
			 Raiserror ('''Visible'' Attribute is not selected for the mapped Control Type Name.Error at Rowno:%i',16,1,@fprowno)  
			 return  
		 end  
  
		 if exists (select 'x'  
		 from  es_comp_ctrl_type_mst  (nolock)  
		 where customer_name = @engg_customer_name  
		 and  project_name = @engg_project_name  
		 and  process_name = @tmp_proc  
		 and  component_name = @tmp_comp  
		 and  ctrl_type_name = @engg_cont_elem_type    --kanagavel
		 and  base_ctrl_type = 'Grid'  
		 and  isnull(visisble_rows,0) = 0  )  
		 begin  
			 Raiserror ('Visible Rows value is Zero for the selected Grid Control Type Name. Error at Rowno:%i',16,1, @fprowno)  
			 return  
		 end  
	End  
-- Code Added for the BugId: PNR2.0_28003 Starts  
-- Code commented for PNR2.0_22818 (starts)  
/*   
-- code modification  for  PNR2.0_22560 starts  
if @modeflag in('U', 'Y', 'I', 'X')  
BEGIN  
IF  @tmp_ctl = 'grid'  
begin  
If exists (select '*' from  ep_ui_control_dtl (nolock)  
where   customer_name     =  @engg_customer_name  
and    project_name      =  @engg_project_name  
and    process_name      =  @tmp_proc  
and    component_name    =  @tmp_comp  
and    activity_name     =  @tmp_act  
and    ui_name           =  @tmp_ui  
and    page_bt_synonym   =  @engg_cont_page_bts  
and    section_bt_synonym   =  @engg_cont_sec_bts )  
Begin  
Select  @msg =   'Control already defined under the section <%2> .Define grid in a seperate section . Check Row <%1>'  
EXEC    ENGG_ERROR_SP  'ep_layout_sp_savctlcnml',  
3,  
@msg,  
@CTXT_LANGUAGE,  
@CTXT_OUINSTANCE,  
@CTXT_SERVICE,  
@CTXT_USER,  
@fprowno,  
@engg_cont_sec_bts,  
'',  
'',  
@M_ERRORID  Output  
RETURN  
End  
end  
If exists (select '*' from  ep_ui_control_dtl  a   (nolock),  
es_comp_ctrl_type_mst_vw b  (nolock)  
where   a.customer_name     =  @engg_customer_name  
and     a.project_name      =  @engg_project_name  
and     a.process_name      =  @tmp_proc  
and     a.component_name   =  @tmp_comp  
and     a.activity_name     =  @tmp_act  
and     a.ui_name         =  @tmp_ui  
and     a.page_bt_synonym   =  @engg_cont_page_bts  
and     a.section_bt_synonym   =  @engg_cont_sec_bts  
  
and     a.customer_name     =  b.customer_name  
and     a.project_name      =  b.project_name  
and     a.process_name      =  b.process_name  
and     a.component_name    =  b.component_name  
and     a.control_type   =  b.ctrl_type_name  
and     b.base_ctrl_type  in  ('grid') )  
Begin  
Select  @msg =   'Another control cannot be defined under this section <%2> as it already contains a Grid . Check Row <%1>'  
EXEC    ENGG_ERROR_SP  'ep_layout_sp_savctlcnml',  
3,  
@msg,  
@CTXT_LANGUAGE,  
@CTXT_OUINSTANCE,  
@CTXT_SERVICE,  
@CTXT_USER,  
@fprowno,  
@engg_cont_sec_bts,  
'',  
'',  
@M_ERRORID  Output  
RETURN  
End  
END  
-- code modification  for  PNR2.0_22560 ends  
*/  
-- Code commented for PNR2.0_22818 (ends)   
-- Added by feroz for static  
	if exists (select 'x'  
	from   es_comp_stat_ctrl_type_mst (nolock)  
	where  customer_name   = @engg_customer_name  
	and   project_name   = @engg_project_name  
	and   process_name   = @tmp_proc  
	and   component_name  = @tmp_comp  
	and   ctrl_type_name  = @engg_cont_elem_type  )  
	begin  
		if isnull(@engg_cont_samp_data,'') <> ''  
		begin  
			raiserror('sample data is not applicable for static control types',16,1)  
			return  
		end  
		Select  @event_req  = handle_events,  
				@tmp_ctl    = base_ctrl_type  
		from	es_comp_stat_ctrl_type_mst (nolock)  
		where	customer_name		= @engg_customer_name  
		and		project_name		= @engg_project_name  
		and		process_name		= @tmp_proc  
		and		component_name		= @tmp_comp  
		and		ctrl_type_name		= @engg_cont_elem_type  
	end  
  
--added by Ramanujam starts on 10/3/ 2006--- for spin control  
	select	@page_prefix_sec = page_prefix  
	from	ep_ui_page_dtl(nolock)  
	where	customer_name		= @engg_customer_name  
	and		project_name		= @engg_project_name  
	and		process_name		= @tmp_proc  
	and		component_name		= @tmp_comp  
	and		activity_name		= @tmp_act  
	and		ui_name				= @tmp_ui  
	and		page_bt_synonym		= @engg_cont_page_bts  
--added by Ramanujam ends on 10/3/ 2006--- for spin control 
 
--- start code adde by feroz for ext js --PNR2.0_1790  
	select  @extjs_ctrl_type = Extjs_Ctrl_type  
	from    es_comp_ctrl_type_mst_vw (nolock)  
	where   customer_name   = @engg_customer_name  
	and		project_name    = @engg_project_name  
	and		process_name    = @tmp_proc  
	and		component_name  = @tmp_comp  
	and		ctrl_type_name  = @engg_cont_elem_type  
	and		req_no			= @engg_base_req_no  
	and		is_extjs_control= 'y'  
  
	if @modeflag = 'D' and isnull(@del_flag, 'T') = 'T' -- Code Modified for PNR2.0_32228 Starts  ,
		and isnull(@del_flag_ph,'T') = 'T'
	begin  
		if @extjs_ctrl_type in ('TextType Writer', 'Marquee Ticker', 'EMail', 'Bar Code')  
		begin  
			delete from ep_action_mst  
			where   customer_name		= @engg_customer_name  
			and		project_name		= @engg_project_name  
			and		process_name		= @tmp_proc  
			and		component_name		= @tmp_comp  
			and		activity_name		= @tmp_act  
			and		ui_name				= @tmp_ui  
			and		primary_control_bts in (select  column_bt_synonym  
			from	ep_ui_grid_dtl (nolock)  
			where   customer_name		= @engg_customer_name  
			and		project_name		= @engg_project_name  
			and		process_name		= @tmp_proc  
			and		component_name		= @tmp_comp  
			and		activity_name		= @tmp_act  
			and		ui_name				= @tmp_ui  
			and		page_bt_synonym		= @engg_cont_page_bts  
			and		section_bt_synonym	= @engg_cont_sec_bts  
			and		control_bt_synonym	= @engg_cont_btsynname)  
  
			delete from ep_ui_traversal_dtl  
			where   customer_name		= @engg_customer_name  
			and		project_name		= @engg_project_name  
			and		process_name		= @tmp_proc  
			and		component_name		= @tmp_comp  
			and		activity_name		= @tmp_act  
			and		ui_name				= @tmp_ui  
			and		page_bt_synonym		= @engg_cont_page_bts  
			and		section_bt_synonym  = @engg_cont_sec_bts  
			and		control_bt_synonym  in (select  column_bt_synonym  
			from	ep_ui_grid_dtl (nolock)  
			where   customer_name		= @engg_customer_name  
			and		project_name		= @engg_project_name  
			and		process_name		= @tmp_proc  
			and		component_name		= @tmp_comp  
			and		activity_name		= @tmp_act  
			and		ui_name				= @tmp_ui  
			and		page_bt_synonym		= @engg_cont_page_bts  
			and		section_bt_synonym  = @engg_cont_sec_bts  
			and		control_bt_synonym  = @engg_cont_btsynname)  
  
			delete from ep_component_glossary_mst  
			where	customer_name		= @engg_customer_name  
			and		project_name		= @engg_project_name  
			and		process_name		= @tmp_proc  
			and		component_name		= @tmp_comp  
			and		bt_synonym_name  in  ( select  column_bt_synonym  
			from	ep_ui_grid_dtl (nolock)  
			where   customer_name		= @engg_customer_name  
			and		project_name		= @engg_project_name  
			and		process_name		= @tmp_proc  
			and		component_name		= @tmp_comp  
			and		activity_name		= @tmp_act  
			and		ui_name				= @tmp_ui  
			and		page_bt_synonym		= @engg_cont_page_bts  
			and		section_bt_synonym  = @engg_cont_sec_bts  
			and		control_bt_synonym  = @engg_cont_btsynname)  
  
			delete from ep_component_glossary_mst_lng_extn  
			where   customer_name   = @engg_customer_name  
			and    project_name     = @engg_project_name  
			and    process_name     = @tmp_proc  
			and    component_name   = @tmp_comp  
			and  bt_synonym_name  in  ( select  column_bt_synonym  
			from  ep_ui_grid_dtl (nolock)  
			where   customer_name   = @engg_customer_name  
			and    project_name     = @engg_project_name  
			and    process_name     = @tmp_proc  
			and    component_name   = @tmp_comp  
			and    activity_name    = @tmp_act  
			and    ui_name			= @tmp_ui  
			and    page_bt_synonym  = @engg_cont_page_bts  
			and  section_bt_synonym = @engg_cont_sec_bts  
			and  control_bt_synonym = @engg_cont_btsynname)  
  
			delete from ep_ui_grid_dtl  
			where	customer_name		= @engg_customer_name  
			and		project_name		= @engg_project_name  
			and		process_name		= @tmp_proc  
			and		component_name		= @tmp_comp  
			and		activity_name		= @tmp_act  
			and		ui_name				= @tmp_ui  
			and		page_bt_synonym		= @engg_cont_page_bts  
			and		section_bt_synonym  = @engg_cont_sec_bts  
			and		control_bt_synonym  = @engg_cont_btsynname  
		end  
/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P begin*/  
		if exists ( select 'X' 
		from	es_comp_ctrl_type_mst(nolock)   
		where	customer_name		= @engg_customer_name  
		and		project_name		= @engg_project_name  
		and     process_name		= @tmp_proc  
		and     component_name		= @tmp_comp  
		and		ctrl_type_name		= @engg_cont_elem_type  
		and		base_ctrl_type		='Listedit')  
	   begin  
			if exists( Select 'X'  
			from	ep_listedit_control_map(nolock)  
			where	customer_name	= @engg_customer_name  
			and		project_name	= @engg_project_name  
			and		process_name	= @tmp_proc  
			and		component_name  = @tmp_comp  
			and		activity_name   = @tmp_act  
			and		ui_name		    = @tmp_ui  
			and		listedit_synonym= @engg_cont_btsynname )  
			begin  
			   select @msg = 'Control BT Synonym ' + @engg_cont_btsynname + ' is in use(Listedit). Cannot Delete. at row no: ' + convert(char(3), @fprowno)  
			   exec engg_error_sp 'ep_layout_sp_savctlcnml',  
			   5,  
			   @msg,  
			   @ctxt_language,  
			   @ctxt_ouinstance,  
			   @ctxt_service,  
			   @ctxt_user,  
			  '',  
			   '',  
			   '',  
			   '',  
			   @m_errorid output  
			   return  
			end  
  
			if exists( Select 'X'  
		    from	ep_listedit_column_dtl(nolock)  
		    where customer_name		= @engg_customer_name  
			and  project_name		= @engg_project_name  
			and  process_name		= @tmp_proc  
			and  component_name		= @tmp_comp  
			and  activity_name		= @tmp_act  
			and  ui_name			= @tmp_ui  
			and  listedit_synonym	= @engg_cont_btsynname  )  
		   begin  
			   select @msg = 'Control BT Synonym ' + @engg_cont_btsynname + ' is in use(Listedit). Cannot Delete. at row no: ' + convert(char(3), @fprowno)  
			   exec engg_error_sp 'ep_layout_sp_savctlcnml',  
			   5,  
			   @msg,  
			   @ctxt_language,  
			   @ctxt_ouinstance,  
			   @ctxt_service,  
			   @ctxt_user,  
			   '',  
			   '',  
			   '',  
			   '',  
			   @m_errorid output  
			   return  
		   end  
    
		   if exists( Select 'X'  
		   from		ep_resolvelist_data_map(nolock)  
		   where	customer_name  = @engg_customer_name  
		   and		project_name   = @engg_project_name  
		   and		process_name   = @tmp_proc  
		   and		component_name = @tmp_comp  
		   and		activity_name  = @tmp_act  
		   and		ui_name		   = @tmp_ui  
		   and		listedit_synonym= @engg_cont_btsynname  )  
			begin  
				select @msg = 'Control BT Synonym ' + @engg_cont_btsynname + ' is in use(Listedit). Cannot Delete. at row no: ' + convert(char(3), @fprowno)  
				exec engg_error_sp 'ep_layout_sp_savctlcnml',  
				5,  
				@msg,  
				@ctxt_language,  
				@ctxt_ouinstance,  
				@ctxt_service,  
				@ctxt_user,  
				'',  
				'',  
				'',  
				'',  
				@m_errorid output  
				return  
			end  
		end									
		if exists ( select 'X' 
		from	es_comp_ctrl_type_mst(nolock)   
		where	customer_name		= @engg_customer_name  
		and		project_name		= @engg_project_name  
		and     process_name		= @tmp_proc  
		and     component_name		= @tmp_comp  
		and		ctrl_type_name		= @engg_cont_elem_type  
	   --and  base_ctrl_type		='edit'  
		and  associatedlist_req		= 'y'  )  
		begin  
			if exists( Select 'X'  
			from ep_listedit_control_map(nolock)  
			where customer_name		= @engg_customer_name  
			and  project_name		= @engg_project_name  
			and  process_name		= @tmp_proc  
			and  component_name		= @tmp_comp  
			and  activity_name		= @tmp_act  
			and  ui_name			= @tmp_ui  
			and  page_bt_synonym	= @engg_cont_page_bts  
			and  mapped_bt_synonym	= @engg_cont_btsynname  )  
			begin  
				 raiserror('Control BT Synonym  is in use(Listedit).Kindly unmap and proceed',16,1)  
				 return  
			end  
  
			if exists( Select 'X'  
			from ep_resolvelist_data_map(nolock)  
			where customer_name		= @engg_customer_name  
			and  project_name		= @engg_project_name  
			and  process_name		= @tmp_proc  
			and  component_name		= @tmp_comp  
			and  activity_name		= @tmp_act  
			and  ui_name			= @tmp_ui  
			and  page_bt_synonym	= @engg_cont_page_bts   
			and  mapped_bt_synonym	= @engg_cont_btsynname  )  
			begin  
				raiserror('Control BT Synonym  is in use(Listedit).Kindly unmap and proceed',16,1)  
				return  
			end  
		end  
		if exists (Select 'X'  
		from	ep_resolvelist_data_map(nolock)  
		where	customer_name		= @engg_customer_name  
		and		project_name		= @engg_project_name  
		and		process_name		= @tmp_proc  
		and		component_name		= @tmp_comp  
		and		activity_name		= @tmp_act  
		and		ui_name				= @tmp_ui  
		and		mapped_bt_syn_page  = @engg_cont_page_bts   
		and		data_mapped_synonym = @engg_cont_btsynname)   
		begin  
			raiserror('Control BT Synonym  is in use(Listedit).Kindly unmap and proceed',16,1)  
			return  
		end  
/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P End*/  
	end  

	if @modeflag in('U', 'Y', 'I', 'X', 'D')  
	begin  
	if exists( select  'x'  
	from	ep_ui_section_dtl (nolock)  
	where	customer_name		= @engg_customer_name  
	and		project_name		= @engg_project_name  
	and		process_name		= @tmp_proc  
	and		component_name		= @tmp_comp 
	and		activity_name		= @tmp_act  
	and		ui_name				= @tmp_ui  
	and		page_bt_synonym		= @engg_cont_page_bts  
	and		section_bt_synonym	= @engg_cont_sec_bts  
	and		section_type		in ('Text Scroller', 'Formatted Text','Report List', 'Property Window', 'Pivot', 'Tree Grid', 'IFrame', 'RSS Feed')  
	and		req_no				= @engg_base_req_no )  
	begin  
		raiserror('Insertion/Modification/Deletion not allowed  for ExtJs Section',16,1)  
		return  
	end  
end  
--- end code adde by feroz for ext js --PNR2.0_1790  
--Code Added by Swmainathan R. on 01/10/2005 Starts  
	IF @modeflag in('U', 'Y')  
	BEGIN  
		IF EXISTS (SELECT 'X'  
		FROM	ep_ui_section_dtl (NOLOCK)  
		WHERE	customer_name		= @engg_customer_name  
		AND		project_name		= @engg_project_name  
		AND		process_name		= @tmp_proc  
		AND		component_name		= @tmp_comp  
		AND		activity_name		= @tmp_act  
		AND		ui_name				= @tmp_ui  
		AND		page_bt_synonym		= @engg_cont_page_bts  
		AND		section_bt_synonym  = @engg_cont_sec_bts  
		AND		section_type		= 'Tree'  
		AND		req_no				= @engg_base_req_no  )  
		BEGIN  
			RAISERROR('Modification not allowed  for Section Type of Tree',16,1)  
			RETURN  
		END  
/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P begin*/  
		if @tmp_control_type <> @engg_cont_elem_type  
		begin  
			   if exists ( select 'X' 
			   from		es_comp_ctrl_type_mst(nolock)   
			   where	customer_name		= @engg_customer_name  
			   and		project_name		= @engg_project_name  
			   and		process_name		= @tmp_proc  
			   and		component_name		= @tmp_comp  
			   and		ctrl_type_name		= @tmp_control_type  
			   and		base_ctrl_type		='Listedit' )  
			   begin  
					if exists( Select 'X'  
					from	ep_listedit_control_map(nolock)  
					where	customer_name	= @engg_customer_name  
					and		project_name	= @engg_project_name  
					and		process_name	= @tmp_proc  
					and		component_name  = @tmp_comp  
					and		activity_name	= @tmp_act  
					and		ui_name			= @tmp_ui  
					and		listedit_synonym= @engg_cont_btsynname  )  
					begin  
					   raiserror('Control BT Synonym  is in use(Listedit).Cannot modify',16,1)  
					   return  
					end  
  
					if exists( Select 'X'  
					from	ep_listedit_column_dtl(nolock)  
					where	customer_name		= @engg_customer_name  
					and		project_name		= @engg_project_name  
					and		process_name		= @tmp_proc  
					and		component_name		= @tmp_comp  
					and		activity_name		= @tmp_act  
					and		ui_name				= @tmp_ui  
					and		listedit_synonym	= @engg_cont_btsynname )  
					begin  
					   raiserror('Control BT Synonym  is in use(Listedit).Cannot modify',16,1)  
					   return  
				    end  
    
					if exists( Select 'X'  
					from	ep_resolvelist_data_map(nolock)  
					where	customer_name		= @engg_customer_name  
					and		project_name		= @engg_project_name  
					and		process_name		= @tmp_proc  
					and		component_name		= @tmp_comp  
					and		activity_name		= @tmp_act  
					and		ui_name				= @tmp_ui  
					and		listedit_synonym	= @engg_cont_btsynname )  
					begin  
					   raiserror('Control BT Synonym  is in use(Listedit).Cannot modify',16,1)  
					   return  
					end  
				end   
				if exists ( select 'X' 
				from	es_comp_ctrl_type_mst(nolock)   
				where	customer_name		= @engg_customer_name  
				and		project_name		= @engg_project_name  
				and     process_name		= @tmp_proc  
				and     component_name		= @tmp_comp  
				and		ctrl_type_name		= @tmp_control_type  
				and		associatedlist_req  = 'y')  
				begin  
					if exists( Select 'X'  
					from ep_listedit_control_map(nolock)  
					where customer_name		= @engg_customer_name  
					and  project_name		= @engg_project_name  
					and  process_name		= @tmp_proc  
					and  component_name		= @tmp_comp  
					and  activity_name		= @tmp_act 
					and  ui_name			= @tmp_ui  
					and  page_bt_synonym	= @engg_cont_page_bts  
					and  mapped_bt_synonym  = @engg_cont_btsynname )  
				    begin  
					   raiserror('Control BT Synonym  is in use(Listedit).Cannot modify',16,1)  
					   return  
				    end  
  
			   if exists( Select 'X'  
			   from		ep_resolvelist_data_map(nolock)  
			   where	customer_name		= @engg_customer_name  
			   and		project_name		= @engg_project_name  
			   and		process_name		= @tmp_proc  
			   and		component_name		= @tmp_comp  
			   and		activity_name		= @tmp_act  
			   and		ui_name				= @tmp_ui  
			   and		page_bt_synonym		= @engg_cont_page_bts  
			   and		mapped_bt_synonym	= @engg_cont_btsynname  )  
			   begin  
				   raiserror('Control BT Synonym is in use(Listedit).Cannot modify',16,1)  
				   return  
			   end  
			end  
  
			if exists ( Select 'X'  
			from	ep_resolvelist_data_map(nolock)  
			where	customer_name	= @engg_customer_name  
			and		project_name	= @engg_project_name  
			and		process_name	= @tmp_proc  
			and		component_name  = @tmp_comp  
			and		activity_name   = @tmp_act  
			and		ui_name			= @tmp_ui  
			and		mapped_bt_syn_page= @engg_cont_page_bts   
			and		data_mapped_synonym= @engg_cont_btsynname  )   
		   begin  
			   raiserror('Control BT Synonym  is in use(Listedit).Cannot modify',16,1)  
			   return  
		   end  
	   end  
/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P End*/  
	END  
  
	IF @modeflag in('I', 'X')  
	BEGIN  
		IF EXISTS (  SELECT 'X'  
		FROM ep_ui_section_dtl (NOLOCK)  
		WHERE customer_name		= @engg_customer_name  
		AND   project_name		= @engg_project_name  
		AND   process_name		= @tmp_proc  
		AND   component_name	= @tmp_comp  
		AND   activity_name		= @tmp_act  
		AND   ui_name			= @tmp_ui  
		AND   page_bt_synonym   = @engg_cont_page_bts  
		AND   section_bt_synonym= @engg_cont_sec_bts  
		AND   section_type		= 'Tree'  
		AND   req_no			= @engg_base_req_no )  
		BEGIN  
			RAISERROR('Controls cannot be added for Section Type of Tree',16,1)  
			RETURN  
		END  
--Code commented by chanheetha N A for the call id : PNR2.0_10930  
---added by Ramanujam on 10 mar 2006 --starts  
--   IF EXISTS (SELECT 'X'  
--     FROM ep_ui_control_dtl (NOLOCK)  
--     WHERE customer_name    = @engg_customer_name  
--  AND   project_name    = @engg_project_name  
--     AND   process_name    = @tmp_proc  
--     AND   component_name   = @tmp_comp  
--     AND   activity_name    = @tmp_act  
--     AND   ui_name       = @tmp_ui  
--     AND   page_bt_synonym   = @engg_cont_page_bts  
--     AND   section_bt_synonym  = @engg_cont_sec_bts  
--     AND  req_no       = @engg_base_req_no  
--     and  control_bt_synonym  = @engg_cont_btsynname  
--  
--      )  
--   BEGIN  
--     if @base_ctrl_type_tmp = 'Edit'  
--     begin  
--  
--      if @engg_cont_elem_type  <> @tmp_control_type  
--     begin  
--  
--       RAISERROR('Cannot modify control type since spin required is checked',16,1)  
--       RETURN  
--      end  
--   end  
--  
--   END  
---added by Ramanujam on 10 mar 2006 --starts  
--Code commented by chanheetha N A for the call id : PNR2.0_10930  
	END  
  
	IF @modeflag ='D'  
	BEGIN  
		IF EXISTS  (  SELECT 'X'  
		FROM	ep_ui_section_dtl (NOLOCK)  
		WHERE	customer_name		= @engg_customer_name  
		AND		project_name		= @engg_project_name  
		AND		process_name		= @tmp_proc  
		AND		component_name		= @tmp_comp  
		AND		activity_name		= @tmp_act  
		AND		ui_name				= @tmp_ui  
		AND		page_bt_synonym		= @engg_cont_page_bts  
		AND		section_bt_synonym  = @engg_cont_sec_bts  
		AND		section_type		= 'Tree'  
		AND		req_no				= @engg_base_req_no  )  
		BEGIN  
			RAISERROR('Deletion not allowed for Section Type of Tree',16,1)  
			RETURN  
		END  
	END  
--Code Added by Swmainathan R. on 01/10/2005 Ends  
--Check whether activity is selected. If not display error message  
	If @engg_act_descr Is Null  
	begin  
		Select  @msg = 'Select Activity'  
		EXEC    ENGG_ERROR_SP   'ep_layout_sp_savctlcnml',  
			1,			@msg,		@CTXT_LANGUAGE,			@CTXT_OUINSTANCE,		@CTXT_SERVICE,			@CTXT_USER,  
			'',			'',			'',						'',						@M_ERRORID  Output  
		RETURN  
	end  
  
--Check whether UI is selected. If not display error message  
	If @engg_ui_descr Is Null  
	begin  
		Select  @msg =   'Select User Interface'  
		EXEC    ENGG_ERROR_SP    'ep_layout_sp_savctlcnml',  
			2,			@msg,		@CTXT_LANGUAGE,			@CTXT_OUINSTANCE,		@CTXT_SERVICE,			@CTXT_USER,  
			'',			'',			'',						'',						@M_ERRORID  Output  
		RETURN  
	end  
  
--Check whether Page BT is selected. If not display error message  
	If @engg_cont_page_bts Is Null  
	begin  
		Select  @msg =   'Select page (BT Synonym)'  
		EXEC    ENGG_ERROR_SP  'ep_layout_sp_savctlcnml',  
			3,			@msg,			@CTXT_LANGUAGE,			@CTXT_OUINSTANCE,			@CTXT_SERVICE,			@CTXT_USER,  
			'',			'',				'',						'',							@M_ERRORID  Output  
		RETURN  
	end  
  
--For each row, if Section BTSynonym Name is not entered, display error message.  
	If @engg_cont_sec_bts Is Null  
	begin  
		Select  @msg =   'Select section (BT Synonym)'  
		EXEC    ENGG_ERROR_SP  'ep_layout_sp_savctlcnml',  
			3,			@msg,			@CTXT_LANGUAGE,			@CTXT_OUINSTANCE,			@CTXT_SERVICE,			@CTXT_USER,  
			'',			'',				'',						'',							@M_ERRORID  Output  
		RETURN  
	end  

--Code Added For BugId Platform_2.0.3.X_53  
	if charindex('.',@engg_cont_datawidth) > 1  
	begin  
		Select  @msg =   'Data Width Cannot be Numeric at Rowno <%1>'  
		EXEC    ENGG_ERROR_SP  'ep_layout_sp_savctlcnml',  
			3,			@msg,			@CTXT_LANGUAGE,			@CTXT_OUINSTANCE,			@CTXT_SERVICE,			@CTXT_USER,  
			@fprowno,	'',				'',						'',							@M_ERRORID  Output  
		RETURN  
	end 
	 
	if charindex('.',@engg_cont_labwidth) > 1  
	begin  
		Select  @msg =   'Label Width Cannot be Numeric at Rowno <%1>'  
		EXEC    ENGG_ERROR_SP  'ep_layout_sp_savctlcnml',  
			3,			@msg,		@CTXT_LANGUAGE,				@CTXT_OUINSTANCE,			@CTXT_SERVICE,			@CTXT_USER,  
			@fprowno,	'',			'',							'',						    @M_ERRORID  Output  
		RETURN  
	end  
-- modified by shafina on 10-dec-2004 to check for parent section  
	If  exists ( select 'x'  
	from	ep_ui_section_dtl (nolock)  
	where	customer_name		= @engg_customer_name  
	and		project_name		= @engg_project_name  
	and		process_name		= @tmp_proc  
	and		component_name		= @tmp_comp  
	and		activity_name		= @tmp_act  
	and		ui_name				= @tmp_ui  
	and		page_bt_synonym		= @engg_cont_page_bts  
	and		parent_section		= @engg_cont_sec_bts )  
	begin  
		Select  @msg =   'Selected Section (BT Synonym) is a parent section.Cannot add controls to it.'  
		EXEC    ENGG_ERROR_SP  'ep_layout_sp_savctlcnml',  
			9,			@msg,			@CTXT_LANGUAGE,			@CTXT_OUINSTANCE,		@CTXT_SERVICE,			@CTXT_USER,  
			'',			'',				'',						'',						@M_ERRORID  Output  
		RETURN  
	end  
  
--For each row, if Section BTSynonym Name is not entered, display error message.  
	If @engg_cont_btsynname Is Null  
	begin  
		Select  @msg =   'Control(BT Synonym) for Row ' + convert(char(5), @fprowno) + ' is null'  
		EXEC ENGG_ERROR_SP  'ep_layout_sp_savctlcnml',  
			3,			@msg,			@CTXT_LANGUAGE,			@CTXT_OUINSTANCE,		@CTXT_SERVICE,			@CTXT_USER,  
			'',			'',				'',						'',						@M_ERRORID  Output  
		RETURN  
	end  
  --to restrict the fw context parameter as control starts TECH-73370

  if @modeflag in ('I','X')
  begin 
  IF EXISTS (  
    SELECT 'x'  
    FROM DE_QUICK_CODE_MST(NOLOCK)  
    WHERE quick_code_type = 'PreDefined_BT'  
     AND quick_code_value = @engg_cont_btsynname  
    )  
  BEGIN  
   SELECT @msg = 'Default dataitems can not be defined as  BT Synonym at Row No:' + convert(VARCHAR(10), @fprowno)  
   
   EXEC engg_error_sp ep_layout_sp_savctlcnml,  
    '1',  
    @msg,  
    @ctxt_language,  
    @ctxt_ouinstance,  
    @ctxt_service,  
    @ctxt_user,  
    '',  
    '',  
    '',  
    '',  
    @m_errorid OUTPUT  
  
   IF @m_errorid <> 0  
    RETURN  
    
  end
  end
  --to restrict the fw context parameter as control ends TECH-73370

--For each row, if Control BTSynonym Name contains blank spaces , display error message.    
	select	@error_tmp = dbo.ep_check_spl_char(@engg_cont_btsynname)  
  
-- code modified by shafina on 09-April-2004 for PREVIEWENG203ACC_000012  
	if @modeflag <> 'D'  
	begin  
		if @error_tmp = 1  
		begin  
			Select @msg = 'BT Synonym for Row ' + convert(char(5), @fprowno) + ' contains special characters.'  
			EXEC ENGG_ERROR_SP 'ep_layout_sp_savctlcnml',  
				4,			@msg,		@CTXT_LANGUAGE,			@CTXT_OUINSTANCE,		@CTXT_SERVICE,			@CTXT_USER,  
				'',			'',			'',						'',						@M_ERRORID Output  
			RETURN  
		end  
-- code modified by shafina on 07-July-2004 for PREVIEWENG203ACC_000076  

--code added by kiruthika for bugid:PNR2.0_10027  
		if rtrim(@engg_cont_btsynname) = 'HdnWFDocKey'  
		begin  
			select @msg  = 'Control name cannot be "HdnWFDocKey" Error at row no ' + convert(char(5), @fprowno)  
			exec engg_error_sp 'en_layout_sp_savsecscml',  
				4,			@msg,		@ctxt_language,		@ctxt_ouinstance,			@ctxt_service,			@ctxt_user,  
				'',			'',			'',					'',							@m_errorid  output  
			return  
		end 
		 
		if rtrim(@engg_cont_btsynname) = 'HdnWFOrgUnit'  
		begin  
			select @msg  = 'Control name cannot be "HdnWFOrgUnit" Error at row no ' + convert(char(5), @fprowno)  
			exec engg_error_sp 'en_layout_sp_savsecscml',  
				4,			@msg,		@ctxt_language,		@ctxt_ouinstance,			@ctxt_service,			@ctxt_user,  
				'',			'',			'',					'',							@m_errorid  output  
			return  
		end  
--code added by kiruthika for bugid:PNR2.0_10027  
-- Length of the BT Synonym must not exceed 30 characters.  
-- code modified by shafina on 19-Nov-2004 for PREVIEWENG203ACC_000076(Length of the BT Synonym must not exceed 28 characters)  
--code added by kiruthika for bugid:PNR2.0_14505  
		if len(@engg_cont_btsynname) > 19 and @spin_req = 'Y'  
		begin  
			select @msg  = 'Length of Control BT Synonym should not be greater than 19 for spin control at Row no:' + convert(char(5), @fprowno)  
			exec engg_error_sp 'en_layout_sp_savsecscml',  
				4,			@msg,		@ctxt_language,			@ctxt_ouinstance,			@ctxt_service,			@ctxt_user,  
				'',			'',			'',						'',							@m_errorid  output  
			return  
		end  
  
		if len(@engg_cont_btsynname) > 28  
		begin  
			select @msg  = 'Length of Control BT Synonym must not be greater than 28 for Row ' + convert(char(5), @fprowno)  
			exec engg_error_sp 'en_layout_sp_savsecscml',  
				4,			@msg,		@ctxt_language,			@ctxt_ouinstance,			@ctxt_service,			@ctxt_user,  
				'',			'',			'',						'',							@m_errorid  output  
			return  
		end   
-- code added by Gowrisankar for PNR2.0_4942 on 13-Dec-2005  
		if exists ( select 'x'  
		from	re_quick_code_mst   (nolock)  
		where	quick_code_type  =  'RE_CONTEXT'  
		and		quick_code_value = @engg_cont_btsynname )  
		Begin  
			select @msg  ='Default dataitems can not be defined as Control BT Synonym at Row No:' + cast(@fprowno as varchar(10))  
			exec engg_error_sp 'ep_layout_sp_savctlcnml',  
				4,			@msg,			@ctxt_language,			@ctxt_ouinstance,		@ctxt_service,				@ctxt_user,  
				'',			'',				'',						'',						@m_errorid  output  
			return  
		end  -- code added by Gowrisankar for PNR2.0_4942 on 13-Dec-2005  
--For each row , If Horder is not entered , display error message. 
--code added by Sangeetha L for the bug id : Platform_2.0.3.X_265  
--bug Descr :I have generated a service with a parameter "Name".  
--The service got generated without any errors.But,when I tried to change the flow direction ,It is throwing an error  
--code commented by kiruthika for bug id:PNR2.0_6778  
--   if len(ltrim(rtrim(@engg_cont_btsynname))) > 0  
--   begin  
--    if exists (select 'x' from de_meta_vbkeywords (nolock)  
--       where  keyword = @engg_cont_btsynname  
--      )  
--    begin  
-- -- Code modified by Chanheetha N A on 29-Nov-2005 for the BUG ID:PNR2.0_4824  
--                 set @msg ='The Keyword "'+ @engg_cont_btsynname +'" not allowed as a Control Name'  
--     exec engg_error_sp  'en_layout_sp_savsecscml',102, @msg,  
--        @ctxt_language, @ctxt_ouinstance,@ctxt_service,@ctxt_user,  
--        null , null , null , null , @m_errorid out  
--     if @m_errorid <> 0  
--      return  
--    end  
--   end  
--code commented by kiruthika for bug id:PNR2.0_6778   
		if @engg_cont_horder is null  
		begin  
			Select  @msg =   'Horizontal Order for Row ' + convert(char(5), @fprowno) + ' is null'  
			EXEC    ENGG_ERROR_SP  'ep_layout_sp_savctlcnml',  
				7,			@msg,			@CTXT_LANGUAGE,			@CTXT_OUINSTANCE,		@CTXT_SERVICE,		@CTXT_USER,  
				'',			'',				'',						'',						@M_ERRORID  Output  
			RETURN  
		end  
  
--For each row , If Horder is negative or zero, display error message.  
		if @engg_cont_horder < 1  
		begin  
			Select  @msg =   'Horizontal Order for Row ' + convert(char(5), @fprowno) + ' cannot be negative or zero'  
			EXEC    ENGG_ERROR_SP  'ep_layout_sp_savctlcnml',  
				10,			@msg,			@CTXT_LANGUAGE,			@CTXT_OUINSTANCE,		@CTXT_SERVICE,		@CTXT_USER,  
				'',			'',				'',						'',  
			@M_ERRORID  Output  
			RETURN  
		end  
  
		--For each row , If Vorder is not entered , display error message.  
		if @engg_cont_vorder is null  
		begin  
			Select  @msg =   'Vertical Order for Row ' + convert(char(5), @fprowno) + ' is null'  
			EXEC    ENGG_ERROR_SP  'ep_layout_sp_savctlcnml',  
				7,			@msg,			@CTXT_LANGUAGE,			@CTXT_OUINSTANCE,		@CTXT_SERVICE,		@CTXT_USER,  
				'',			'',				'',						'',						@M_ERRORID  Output  
			RETURN  
		end  
  
--For each row , If Vorder is not entered , display error message.  
		if @engg_cont_vorder < 1  
		begin  
			Select  @msg =   'Vertical Order for Row ' + convert(char(5), @fprowno) + ' cannot be negative or zero'  
			EXEC    ENGG_ERROR_SP  'ep_layout_sp_savctlcnml',  
				11,				@msg,		@CTXT_LANGUAGE,			@CTXT_OUINSTANCE,		@CTXT_SERVICE,		@CTXT_USER,  
				'',				'',			'',						'',						@M_ERRORID  Output  
			RETURN  
		end  
-- code modified by shafina on 22-Dec-2004 for  PREVIEWENG203ACC_000116 (In control_dtl table, label_column_scalemode and data_column_scalemode are added.)  
		if isnull(@engg_cont_datawidth,'') <> ''  
		begin  
			if isnumeric(left(@engg_cont_datawidth,1)) <> 1  
			begin  
				Select  @msg =   'Data Column Width for Row ' + convert(char(5), @fprowno) + ' must start with a number'  
				EXEC ENGG_ERROR_SP  'ep_layout_sp_savctlcnml',  
						11,     @msg,        @CTXT_LANGUAGE,		@CTXT_OUINSTANCE,		CTXT_SERVICE,	@CTXT_USER,		'',          '',  
						'',     '',          @M_ERRORID  Output  
				RETURN  
			end  

			select @engg_cont_datawidth = replace(@engg_cont_datawidth,' ','')  
			select @d_cnt = 1  
			while (1=1)  
			begin  
				select @d_char = substring(@engg_cont_datawidth , @d_cnt , 1 )  
				if isnumeric(@d_char) = 1  
				begin  
					select @d_num = isnull(@d_num,'') + @d_char  
					select @d_cnt = @d_cnt + 1  
				end  
				else  
				begin  
					break  
				end  
			end  
  
			select @data_scale_mode		= substring(@engg_cont_datawidth , @d_cnt , len(@engg_cont_datawidth) - @d_cnt + 1)  
			select @engg_cont_datawidth = @d_num  

-- code modified by shafina on 18-feb-2005 for PREVIEWPFSUPPORT_000012 (When scale mode is not specified for column width , '%' must be taken as default scale mode)  
			if isnull(@data_scale_mode,'') = ''  
				select @data_scale_mode = '%'  
-- code modified by shafina on 18-feb-2005 for PREVIEWPFSUPPORT_000012 (When scale mode is not specified for column width , '%' must be taken as default scale mode)  
  
			if @data_scale_mode not in ('Px' , 'C' , '%')  
			begin  
				Select  @msg =   'Data Scale Mode must be Px , C or % for Row ' + convert(char(5), @fprowno)  
				EXEC ENGG_ERROR_SP  'ep_layout_sp_savctlcnml',  
						11,          @msg,        @CTXT_LANGUAGE,		@CTXT_OUINSTANCE,	@CTXT_SERVICE,	@CTXT_USER,		'',       '',  
						'',          '',          @M_ERRORID  Output  
				RETURN  
			end  
		end  
  
		if isnull(@engg_cont_labwidth,'') <> ''  
		begin  
			if isnumeric(left(@engg_cont_labwidth,1)) <> 1  
			begin  
				Select  @msg =   'Label Column Width for Row ' + convert(char(5), @fprowno) + ' must start with a number'  
				EXEC  ENGG_ERROR_SP  'ep_layout_sp_savctlcnml',  
						11,          @msg,        @CTXT_LANGUAGE,		@CTXT_OUINSTANCE,		@CTXT_SERVICE, @CTXT_USER,		'',          '',  
						'',          '',          @M_ERRORID  Output  
				RETURN  
			end  
  
			select @engg_cont_labwidth = replace(@engg_cont_labwidth,' ','')  
			select @l_cnt = 1  
			while (1=1)  
			begin  
				select @l_char = substring(@engg_cont_labwidth , @l_cnt , 1 )  
				if isnumeric(@l_char) = 1  
				begin  
					select @l_num = isnull(@l_num,'') + @l_char  
					select @l_cnt = @l_cnt + 1  
				end  
				else  
				begin  
					break  
				end  
			end  
			select @label_scale_mode	= substring(@engg_cont_labwidth , @l_cnt , len(@engg_cont_labwidth) - @l_cnt + 1)   
			select @engg_cont_labwidth	= @l_num   
-- code modified by shafina on 18-feb-2005 for PREVIEWPFSUPPORT_000012 (When scale mode is not specified for column width , '%' must be taken as default scale mode)  
			if isnull(@label_scale_mode,'') = ''  
				select @label_scale_mode = '%'  
-- code modified by shafina on 18-feb-2005 for PREVIEWPFSUPPORT_000012 (When scale mode is not specified for column width , '%' must be taken as default scale mode)  
			if @label_scale_mode not in ('Px' , 'C' , '%')  
			begin  
				Select  @msg =   'Label Scale Mode must be Px , C or % for Row ' + convert(char(5), @fprowno)  
				EXEC  ENGG_ERROR_SP  'ep_layout_sp_savctlcnml',  
					  11,          @msg,        @CTXT_LANGUAGE,		@CTXT_OUINSTANCE,		@CTXT_SERVICE, @CTXT_USER,		'',          '',  
					  '',          '',          @M_ERRORID  Output  
				RETURN  
			end  
		end  
	end  
  
--GETTING THE CTRL NAME FOR THE DESCRIPTION  
-- code modified by shafina on 09-April-2004 for PREVIEWENG203ACC_000011  
	Select  @tmp_ctl     = base_ctrl_type,  
			@help_req	 = help_req,  
			@event_req	 = event_handling_req,  
			@zoom_req	 = zoom_req,  
			@editable	 = editable_flag,  
			@visible     = visisble_flag,  
			@report_req  = report_req, -- code modified by Anuradha on 06-Nov-2006 for the Bug ID :: PNR2.0_10832  
			@Label_Link  = Label_Link --Bug ID:PNR2.0_36309  
	from	es_comp_ctrl_type_mst_vw (nolock)  
	where	customer_name   = @engg_customer_name  
	and		project_name	= @engg_project_name  
	and		process_name	= @tmp_proc  
	and		component_name  = @tmp_comp  
	and		ctrl_type_name  = @engg_cont_elem_type  
	and		req_no			= @engg_base_req_no  
  
-- Added by feroz for static  
	if exists (select 'x'  
	from	es_comp_stat_ctrl_type_mst (nolock)  
	where	customer_name   = @engg_customer_name  
	and		project_name	= @engg_project_name  
	and		process_name	= @tmp_proc  
	and		component_name  = @tmp_comp  
	and		ctrl_type_name  = @engg_cont_elem_type  )  
	begin  
		Select  @event_req		= handle_events,  
				@tmp_ctl		= base_ctrl_type  
		from    es_comp_stat_ctrl_type_mst (nolock)  
		where	customer_name   = @engg_customer_name  
		and		project_name	= @engg_project_name  
		and		process_name	= @tmp_proc  
		and		component_name  = @tmp_comp  
		and		ctrl_type_name  = @engg_cont_elem_type  
	end  
  
-- code modified by shafina on 30-Nov-2004 for PREVIEWENG203SYS_000181 (When we give a sample data to button control its accepting.And in generated preview its showing the button without any caption details but with symbol "X".)  
-- code removed by shafina on 10-Dec-2004 to rollback the fix given for PREVIEWENG203ACC_000095  
-- code modified by shafina on 19-Aug-2004 to rollback the fix given for PREVIEWENG203ACC_000086  
--  if @modeflag <> 'D'  
--  begin  
-- -- code modified by shafina on 11-Aug-2004 for checking whether FILLER is given as BTSynonym.- PREVIEWENG203ACC_000086  
--   if @engg_cont_btsynname = 'FILLER' and @tmp_ctl <> 'Filler'  
--   begin  
--    select @msg  = 'Control cannot have FILLER as its BT Synonym at Row No' + convert(char(5), @fprowno)  
--    exec engg_error_sp 'en_layout_sp_savsecscml',  
--          4,  
--          @msg,  
--          @ctxt_language,  
--          @ctxt_ouinstance,  
--          @ctxt_service,  
--          @ctxt_user,  
--          '',  
--          '',  
--          '',  
--          '',  
--          @m_errorid  output  
--    return  
--   end  
--   if @engg_cont_btsynname <> 'FILLER' and @tmp_ctl = 'Filler'  
--   begin  
--    select @msg  = 'Filler Control must have FILLER only as its BT Synonym at Row No' + convert(char(5), @fprowno)  
--    exec engg_error_sp 'en_layout_sp_savsecscml',  
--          4,  
--          @msg,  
--          @ctxt_language,  
--          @ctxt_ouinstance,  
--          @ctxt_service,  
--          @ctxt_user,  
--          '',  
--          '',  
--          '',  
--          '',  
--      @m_errorid  output  
--    return  
--   end  
--  end  
--For each row that is fetched, if Section BT Synonym Name is createed, display error message.  
	If  @modeflag in('U', 'Y')  
-- MODIFIED BY SHAFINA ON 21-JAN-2004  
	begin  
--Code Added by Swmainathan R. on 01/10/2005 Starts  
		IF EXISTS (SELECT 'X'  
		FROM	ep_ui_section_dtl (NOLOCK)  
		WHERE	customer_name		= @engg_customer_name  
		AND		project_name		= @engg_project_name  
		AND		process_name		= @tmp_proc  
		AND		component_name		= @tmp_comp  
		AND		activity_name		= @tmp_act  
		AND		ui_name				= @tmp_ui  
		AND		page_bt_synonym		= @engg_cont_page_bts  
		AND		section_bt_synonym  = @engg_cont_sec_bts  
		AND		section_type		= 'Tree'  
		AND		req_no				= @engg_base_req_no )  
		BEGIN  
			RAISERROR('Cannot modify Section Layout if Section Type is Tree',16,1)  
			RETURN  
		END  
--Code Added by Swmainathan R. on 01/10/2005 Ends  
		if Not Exists( Select  'A' 
		from	ep_ui_control_dtl (nolock)  
		where	customer_name		= @engg_customer_name  
		and		project_name		= @engg_project_name  
		and		process_name		= @tmp_proc  
		and		component_name		= @tmp_comp  
		and		activity_name		= @tmp_act  
		and		ui_name				= @tmp_ui  
		and		page_bt_synonym		= @engg_cont_page_bts  
		and		section_bt_synonym  = @engg_cont_sec_bts  
		and		control_bt_synonym  = @engg_cont_btsynname  
		and     req_no				= @engg_base_req_no )  
--Platform_2.0.3.X_417  
		begin  
			select  @msg =    'BT Synonym cannot be modified at Row No: <%1>'  
			EXEC  ENGG_ERROR_SP  'en_projct_sp_saveuicfml',  
				6,				@msg,			@CTXT_LANGUAGE,			@CTXT_OUINSTANCE,			@CTXT_SERVICE,			@CTXT_USER,  
				@fprowno,		'',				'',						'',							@M_ERRORID  Output  
			return  -- Added for PNR2.0_22818  
		end  
--Platform_2.0.3.X_417  
/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P begin*/  
--select @tmp_control_type  = control_type  
--from ep_ui_control_dtl (nolock)  
--where customer_name   = @engg_customer_name  
--and  project_name   = @engg_project_name  
--and  process_name   = @tmp_proc  
--and  component_name   = @tmp_comp  
--and  activity_name   = @tmp_act  
--and  ui_name     = @tmp_ui  
--and  page_bt_synonym   = @engg_cont_page_bts  
--and  section_bt_synonym  = @engg_cont_sec_bts  
--and  control_bt_synonym  = @engg_cont_btsynname  
--and  req_no     = @engg_base_req_no  
/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P End*/  
  
-- code modified by shafina on 02-mar-2004  
		select	@base_ctrl_type_tmp = base_ctrl_type  
		from	es_comp_ctrl_type_mst_vw (nolock)  
		where	customer_name		= @engg_customer_name  
		and		project_name		= @engg_project_name  
		and		process_name		= @tmp_proc  
		and		component_name		= @tmp_comp  
		and		ctrl_type_name		= @tmp_control_type  
		and		req_no				= @engg_base_req_no  
  
--Code Added by chanheetha N A for the call id : PNR2.0_10930  
		if @tmp_control_type <> @engg_cont_elem_type  
		begin  
			if exists ( select 'x'  
			from    es_comp_ctrl_type_mst (nolock)  
			where	customer_name		= @engg_customer_name  
			and		project_name		= @engg_project_name  
			and		process_name		= @tmp_proc  
			and		component_name		= @tmp_comp  
			and     ctrl_type_name      = @tmp_control_type  
			and     Spin_required       = 'y')  
			BEGIN  
-- Code Added For Bug ID PNR2.0_22690 Starts  
				Select  @page_prefix_section= page_prefix  
				from	ep_ui_page_dtl(nolock)  
				where   customer_name	= rtrim(@engg_customer_name)  
				and		project_name	= rtrim(@engg_project_name)  
				and		req_no			= 'BASE'  
				and		process_name	= rtrim(@tmp_proc)  
				and		component_name  = rtrim(@tmp_comp)  
				and		activity_name	= rtrim(@tmp_act)  
				and		ui_name			= rtrim(@tmp_ui)  
				and		page_bt_synonym = @engg_cont_page_bts  
				Delete  From	Ep_Action_Mst  
				Where	customer_name	= @engg_customer_name  
				and		project_name	= @engg_project_name  
				and		process_name	= @tmp_proc  
				and		Component_Name  = @tmp_comp 
				and		activity_name	= @tmp_act  
				and		ui_name			= @tmp_ui  
				and		page_bt_synonym = @engg_cont_page_bts  
				and		Primary_Control_Bts = 'hdn_'+ @engg_cont_btsynname + '_SPIN'  
  
				Delete  From ep_action_mst_lng_extn  
				Where	customer_name		= @engg_customer_name  
				and		project_name		= @engg_project_name  
				and		process_name		= @tmp_proc  
				and		Component_Name		= @tmp_comp  
				and		activity_name		= @tmp_act  
				and		ui_name				= @tmp_ui  
				and		page_bt_synonym		= @engg_cont_page_bts  
				and		Primary_Control_Bts = 'hdn_'+ @engg_cont_btsynname + '_SPIN'  
  
				Delete  From Ep_ui_Control_Dtl  
				Where	customer_name	= @engg_customer_name  
				and		project_name	= @engg_project_name  
				and		process_name	= @tmp_proc  
				and		Component_Name  = @tmp_comp  
				and		activity_name	= @tmp_act  
				and		ui_name			= @tmp_ui  
				and		page_bt_synonym = @engg_cont_page_bts  
				and		Section_Bt_Synonym = 'hdnspin_'+@page_prefix_section+'_sec'  
				and		Control_BT_SYnonym = 'hdn_'+ @engg_cont_btsynname + '_SPIN'  
  
				if not exists  (  Select *  
				From	Ep_ui_Control_Dtl (Nolock)  
				Where	customer_name	= @engg_customer_name  
				and		project_name	= @engg_project_name  
				and		process_name	= @tmp_proc  
				and		Component_Name  = @tmp_comp  
				and		activity_name	= @tmp_act  
				and		ui_name			= @tmp_ui  
				and		page_bt_synonym = @engg_cont_page_bts  
				and		Section_Bt_Synonym = 'hdnspin_'+@page_prefix_section+'_sec'  )  
				Begin  
					Delete  From Ep_ui_section_Dtl  
					Where	customer_name	= @engg_customer_name  
					and		project_name	= @engg_project_name  
					and		process_name	= @tmp_proc  
					and		Component_Name  = @tmp_comp  
					and		activity_name	= @tmp_act  
					and		ui_name			= @tmp_ui  
					and		page_bt_synonym = @engg_cont_page_bts  
					and		Section_Bt_Synonym = 'hdnspin_'+@page_prefix_section+'_sec'  
			   End  
-- Code Added For Bug ID PNR2.0_22690 Ends  
--RAISERROR('Cannot modify control type since spin required is checked',16,1) -- Code Commented For Bug ID PNR2.0_22690  
--RETURN -- Code Commented For Bug ID PNR2.0_22690   
		END  
	end  
--Code Added by chanheetha N A for the call id : PNR2.0_10930   
	if exists  ( select 'x'  
	from	ep_ui_traversal_dtl (nolock)  
	where	customer_name		=  @engg_customer_name  
	and		project_name		=  @engg_project_name  
	and		process_name		=  @tmp_proc  
	and		component_name		=  @tmp_comp  
	and		activity_name		=  @tmp_act  
	and		ui_name				=  @tmp_ui  
	and		page_bt_synonym		=  @engg_cont_page_bts  
	and		section_bt_synonym  =  @engg_cont_sec_bts  
	and		control_bt_synonym  =  @engg_cont_btsynname  
	and		req_no				=  @engg_base_req_no  
	and		linked_component   <>  ''  
	and		linked_activity    <>  ''  
	and		linked_ui		   <>  ''  )  
	begin  
		if  @tmp_control_type <> @engg_cont_elem_type  
		begin  
-- code modified by shafina on 16-Aug-2004 for PREVIEWENG203ACC_000089 ( Eventhough Help Details exists in Traversal table , it is allowing to change the datatype og help control if the base control type is same )  
			select	@old_help_req = help_req  
			from	es_comp_ctrl_type_mst (nolock)  
			where	customer_name	= @engg_customer_name  
			and		project_name	= @engg_project_name  
			and		process_name	= @tmp_proc  
			and		component_name	= @tmp_comp  
			and		ctrl_type_name	= @tmp_control_type  
  
--code Added for the Bug ID:PNR2.0_36309 starts  
			select	@old_Label_Link_req = Label_Link  
			from	es_comp_ctrl_type_mst (nolock)  
			where	customer_name	= @engg_customer_name  
			and		project_name	= @engg_project_name  
			and		process_name	= @tmp_proc  
			and		component_name	= @tmp_comp  
			and		ctrl_type_name	= @tmp_control_type  
--code Added for the Bug ID:PNR2.0_36309 ends  
  
  --validation modified by 11536	for the case id TECH-20308
			if @base_ctrl_type_tmp <> @tmp_ctl  
			begin  
				declare @base_ctrl_type_tmp1 engg_name, @tmp_ctl1 engg_name

				set  @base_ctrl_type_tmp1	=	@base_ctrl_type_tmp
				set	 @tmp_ctl1				=	@tmp_ctl

				select @base_ctrl_type_tmp1 = case when @base_ctrl_type_tmp		like '%link%' then 'link' else @base_ctrl_type_tmp end
				select @tmp_ctl1			= case when @tmp_ctl				like '%link%' then 'link' else @tmp_ctl end

				if @base_ctrl_type_tmp1 <> @tmp_ctl1  
				begin
					select @msg = 'Control Type cannot be updated as this control exists as a link or help or Label-Link' --code Modified for the Bug ID:PNR2.0_36309  
					exec engg_error_sp		'engg_layout_sp_savctlcnml',  
						9,			@msg,		@ctxt_language,			@ctxt_ouinstance,		@ctxt_service,			@ctxt_user,  
						'',			'',			'',						'',						@m_errorid out  
					if @m_errorid <> 0  
						return  
				end  
			End --validation ends

				--if @base_ctrl_type_tmp <> @tmp_ctl  
			--begin  
				--select @msg = 'Control Type cannot be updated as this control exists as a link or help or Label-Link' --code Modified for the Bug ID:PNR2.0_36309  
				--exec engg_error_sp  
				--'engg_layout_sp_savctlcnml',  
				--9,  
				--@msg,  
				--@ctxt_language,  
				--@ctxt_ouinstance,  
				--@ctxt_service,  
				--@ctxt_user,  
				--'',  
				--'',  
				--'',  
				--'',  
				--@m_errorid out  
				--if @m_errorid <> 0  
					--return  
			--end  

			if @old_help_req <> @help_req  
			begin  
				select @msg = 'Control Type cannot be updated as this control exists as a help'  
				exec engg_error_sp		'engg_layout_sp_savctlcnml',  
					9,		@msg,		@ctxt_language,			@ctxt_ouinstance,		@ctxt_service,			@ctxt_user,  
					'',		'',			'',						'',						@m_errorid out  
				if @m_errorid <> 0  
					return  
			end  
--code Added for the Bug ID:PNR2.0_36309 starts  
			if @old_Label_Link_req <> @Label_Link  
			begin  
				select @msg = 'Control Type cannot be updated as this control exists as a Label-Link'  
				exec engg_error_sp		'engg_layout_sp_savctlcnml',
					9,		@msg		,@ctxt_language,			@ctxt_ouinstance,	@ctxt_service,			@ctxt_user,
					'',		'',			'',							'',					@m_errorid out  
				if @m_errorid <> 0  
					return  
			end  
			--code Added for the Bug ID:PNR2.0_36309 ends  
		end  
	end  
	if exists  ( select 'x'  
	from ep_ui_grid_dtl (nolock)  
	where customer_name		=  @engg_customer_name  
	and  project_name		=  @engg_project_name  
	and  process_name		=  @tmp_proc  
	and  component_name		=  @tmp_comp  
	and  activity_name		=  @tmp_act  
	and  ui_name			=  @tmp_ui  
	and  page_bt_synonym    =  @engg_cont_page_bts  
	and  section_bt_synonym =  @engg_cont_sec_bts  
	and  control_bt_synonym =  @engg_cont_btsynname  
	and  req_no				=  @engg_base_req_no  )  
	begin  
		if  @tmp_control_type <> @engg_cont_elem_type  
		begin  
			if @base_ctrl_type_tmp <> @tmp_ctl  
			begin  
				select @msg = 'Control Type cannot be updated as this control exists as a grid control'  
				exec engg_error_sp	'engg_layout_sp_savctlcnml',  
					9,			@msg,		@ctxt_language,			@ctxt_ouinstance,		@ctxt_service,			@ctxt_user,  
					'',			'',			'',						'',						@m_errorid out  
				if @m_errorid <> 0  
					return  
			end  
		end  
	end 
	----******************************************** 22/feb/2018

	--if  (@tmp_control_type <> @engg_cont_elem_type)  and (isnull(@modeflag,'') in ('U','Y'))
	--begin  
	--	if exists  ( select 'x'  
	--	from	de_fw_Des_ilbo_Service_view_Datamap (nolock)  
	--	where customer_name		=  @engg_customer_name  
	--	and  project_name		=  @engg_project_name  
	--	and  process_name		=  @tmp_proc  
	--	and  component_name		=  @tmp_comp  
	--	and  activity_name		=  @tmp_act  
	--	and  ilbocode			=  @tmp_ui  
	--	and  page_bt_synonym    =  @engg_cont_page_bts  	
	--	and  control_bt_synonym =  @engg_cont_btsynname  )  
	--	begin  
	--		insert into ep_ui_control_del_dtl   
	--			(customer_name,			project_name,			process_name,			component_name,			activity_name,  
	--			ui_name,				page_bt_synonym,		section_bt_synonym,		control_bt_synonym,		control_type,  
	--			req_no,					guid,					Deletion_type)  
	--	   Values  
	--		   (@engg_customer_name,	@engg_project_name,		@tmp_proc,				@tmp_comp,				@tmp_act,   
	--		   @tmp_ui,					@engg_cont_page_bts,	@engg_cont_sec_bts,		@engg_cont_btsynname,	@tmp_control_type, 
	--		   @engg_base_req_no,		@guid,					'UpdateControl')  
		     
	--		select @up_flag = 'U'  
			
	--		If isnull(@engg_del_controls,'') = ''  
	--		Begin  
	--			 select @engg_del_controls = @engg_cont_btsynname  
	--		End  
	--		Else  
	--		Begin  
	--			select @engg_del_controls = isnull(@engg_del_controls,'') + ', ' + @engg_cont_btsynname  
	--		End  
	--	End  
	--	Else  
	--	Begin  
	--		select @up_flag = 'Y'  
	--	End  
	--		--if @base_ctrl_type_tmp <> @tmp_ctl  
	--		--begin  
	--		--	Raiserror('Control is involved in service generation.'  ,16,1)				
	--		--	return  
	--		--end  
		
	--end 
	----***************************22/feb/2018
	if exists  ( select 'x'  
	from ep_enum_value_dtl (nolock)  
	where customer_name		=  @engg_customer_name  
	and  project_name		=  @engg_project_name  
	and  process_name		=  @tmp_proc  
	and  component_name		=  @tmp_comp  
	and  activity_name		=  @tmp_act  
	and  ui_name			=  @tmp_ui  
	and  page_bt_synonym    =  @engg_cont_page_bts  
	and  section_bt_synonym =  @engg_cont_sec_bts  
	and  control_bt_synonym =  @engg_cont_btsynname  
	and  req_no				=  @engg_base_req_no  )  
	begin  
		if  @tmp_control_type <> @engg_cont_elem_type  
		begin  
			if @base_ctrl_type_tmp <> @tmp_ctl  
			begin  
				select @msg = 'Control Type cannot be updated as this control exists as a combo control'  
				exec engg_error_sp		'engg_layout_sp_savctlcnml',  
					9,			@msg,		@ctxt_language,			@ctxt_ouinstance,		@ctxt_service,			@ctxt_user,  
					'',			'',			'',						'',						@m_errorid out  
				if @m_errorid <> 0  
					return  
			end  
		end  
	end  
	if exists  (select 'x'  
	from	ep_radio_button_dtl (nolock)  
	where	customer_name		=  @engg_customer_name  
	and		project_name		=  @engg_project_name  
	and		process_name		=  @tmp_proc  
	and		component_name		=  @tmp_comp  
	and		activity_name		=  @tmp_act  
	and		ui_name				=  @tmp_ui  
	and		page_bt_synonym		=  @engg_cont_page_bts  
	and		section_bt_synonym  =  @engg_cont_sec_bts  
	and		control_bt_synonym  =  @engg_cont_btsynname  
	and		req_no				=  @engg_base_req_no  )  
	begin  
		if  @tmp_control_type <> @engg_cont_elem_type  
		begin  
			if @base_ctrl_type_tmp <> @tmp_ctl  
			begin  
				select @msg = 'Control Type cannot be updated as this control exists as a radio button'  
				exec engg_error_sp		'engg_layout_sp_savctlcnml',  
					9,			@msg,		@ctxt_language,			@ctxt_ouinstance,		@ctxt_service,			@ctxt_user,  
					'',			'',			'',						'',						@m_errorid out  
				if @m_errorid <> 0  
					return  
			end  
		end  
	end  
end  
  
--For each row, if Section BTSynonym Name already exists for another Page or Section or control or Grid Control, display error message.
-- code commented by shafina on 16-Nov-2004 for PREVIEWENG203SYS_000178 (Unable to delete the controls in specifylayout. Platform has accepted same control name for both Page Name and controls. It didnt validate while creating, but on deletion it is validating)
If @Modeflag in ('I','X')--,'U','Y')  
Begin  
	If  Exists( Select  'A' 
	from	ep_ui_page_dtl (nolock)  
	where  customer_name		= @engg_customer_name  
	and		project_name		= @engg_project_name  
	and		process_name		= @tmp_proc  
	and		component_name		= @tmp_comp  
	and		activity_name		= @tmp_act  
	and		ui_name				= @tmp_ui  
	--and   page_bt_synonym		= @engg_cont_page_bts  
	and		page_bt_synonym		= @engg_cont_btsynname  
	and		req_no				= @engg_base_req_no  )  
	begin  
		select @msg = 'Control Bt Synonym ' + @engg_cont_btsynname + ' already exists in the UI as a Page BT synonym'  
		EXEC   ENGG_ERROR_SP 'en_comp_sp_savcon_hsv',  
			7,				@msg,			@CTXT_LANGUAGE,			@CTXT_OUINSTANCE,		@CTXT_SERVICE,			@CTXT_USER,  
			'',				'',				'',						'',						@M_ERRORID  Output  
			RETURN  
	end          	
end 

-- Code Modified by Hamsika for the Bug ID : Platform_2.0.3.1_299(PDEV_274)  
--Code Modified for BugId : PNR2.0_13388  
If @Modeflag in ('I','X')--,'U','Y')  
Begin  
	IF LEN(LTRIM(RTRIM(@engg_cont_btsynname))) > 0  
	BEGIN  
		IF EXISTS (SELECT 'X' 
		FROM	DE_META_VBKEYWORDS (NOLOCK)  
		WHERE	KEYWORD = @engg_cont_btsynname  )  
		BEGIN  
			EXEC ENGG_ERROR_SP  'engg_layout_sp_savctlcnml',102,'Keyword not Allowed as a Parameter',  
				@CTXT_LANGUAGE,		@CTXT_OUINSTANCE,	@CTXT_SERVICE,	@CTXT_USER,		NULL ,	NULL , 
				NULL ,				NULL ,				@m_errorid OUT  
			IF @m_errorid <> 0  
				RETURN  
		END  
	END  
End  
-- Code Modified by Hamsika for the Bug ID : Platform_2.0.3.1_299(PDEV_274)  
/* Code Modified for the Case ID:PNR2.0_30667 By Shakthi P Begin*/  
--if @modeflag ='I'   
--Begin   
--if  @engg_cont_btsynname ='hdnrt_stcontrol'  
--select  @msg = 'Control Bt Synonym "' + @engg_cont_btsynname + '" should not be used.It is default Hidden Control Bt Synonym'    
--Else if  @engg_cont_btsynname ='Prj_hdn_ctrl'  
--select  @msg = 'Control Bt Synonym "' + @engg_cont_btsynname + '" should not be used.It is default Page Control Bt Synonym'  
--begin  
--EXEC  ENGG_ERROR_SP 'en_comp_sp_savcon_hsv',    
--7, 
--@msg,    
--@CTXT_LANGUAGE,    
--@CTXT_OUINSTANCE,    
--@CTXT_SERVICE,    
--@CTXT_USER,    
--'',    
--'',    
--'',    
--'',    
--@M_ERRORID  Output    
--RETURN    
--end  
--End    
/* Code Modified for the Case ID:PNR2.0_30667 By Shakthi P End*/  
/* Code Modified for the Case ID:PNR2.0_30693 By Sangeetha G begin*/  
if @modeflag in ('I'  ,'X')  
Begin    
	if  @engg_cont_btsynname in ('hdnrt_stcontrol'  ,'Prj_hdn_ctrl')  
	begin    
		select  @msg = 'Control Bt Synonym "' + @engg_cont_btsynname + '" should not be used.It is default Hidden Control Bt Synonym'    
		EXEC  ENGG_ERROR_SP 'en_comp_sp_savcon_hsv',    
			7,			@msg,		@CTXT_LANGUAGE,			@CTXT_OUINSTANCE,		@CTXT_SERVICE,			@CTXT_USER,    
			'',			'',			'',						'',						@M_ERRORID  Output    
			RETURN    
	end    
End   
/* Code Modified for the Case ID:PNR2.0_30693 By Sangeetha G End*/  
If  @modeflag in('I', 'X')  
and Exists( Select 'A' 
from	ep_ui_section_dtl (nolock)  
where	customer_name		= @engg_customer_name  
and		project_name		= @engg_project_name  
and		process_name		= @tmp_proc  
and		component_name		= @tmp_comp  
and		activity_name		= @tmp_act  
and		ui_name				= @tmp_ui  
--and  page_bt_synonym		= @engg_cont_page_bts  
and   section_bt_synonym	= @engg_cont_btsynname  
and     req_no				= @engg_base_req_no )  
begin  
	select  @msg = 'Control Bt Synonym ' + @engg_cont_btsynname + ' already exists in the UI as Section Bt Synonym'  
	EXEC  ENGG_ERROR_SP 'en_comp_sp_savcon_hsv',  
		7,			@msg,			@CTXT_LANGUAGE,				@CTXT_OUINSTANCE,			@CTXT_SERVICE,			@CTXT_USER,  
		'',			'',				'',							'',							@M_ERRORID  Output  
	RETURN  
end  
  
If  @modeflag in('I', 'X')  
and Exists( Select 'A' 
from	ep_ui_control_dtl (nolock)  
where	customer_name		= @engg_customer_name  
and		project_name		= @engg_project_name  
and		process_name		= @tmp_proc  
and		component_name		= @tmp_comp  
and		activity_name		= @tmp_act  
and		ui_name				= @tmp_ui  
--and	page_bt_synonym		= @engg_cont_page_bts  
and		control_bt_synonym  = @engg_cont_btsynname  
and     req_no				= @engg_base_req_no )  
begin  
	select  @msg = 'Control Bt Synonym ' + @engg_cont_btsynname + ' already exists in the UI as Control Bt Synonym'  
	EXEC  ENGG_ERROR_SP 'en_comp_sp_savcon_hsv',  
		7,			@msg,			@CTXT_LANGUAGE,				@CTXT_OUINSTANCE,			@CTXT_SERVICE,			@CTXT_USER,  
		'',			'',				'',							'',							@M_ERRORID  Output  
	RETURN  
end 
	 
 ---Access key UI Level validation added by Ganesh Prabhu Starts
If  @modeflag in('I', 'U')  
and Exists( Select 'A' 
from	ep_ui_control_dtl (nolock)  
where	customer_name		= @engg_customer_name  
and		project_name		= @engg_project_name  
and		process_name		= @tmp_proc  
and		component_name		= @tmp_comp  
and		activity_name		= @tmp_act  
and		ui_name				= @tmp_ui  
--and	page_bt_synonym		= @engg_cont_page_bts  
and		accesskey			= @AccessKey  )  
begin  
	raiserror ('Given Access key already exists for other control in this ui, Kindly change the access key and proceed.',16,1)
	RETURN  
end  
  
---Access key UI Level validation added by Ganesh Prabhu Ends
-- code modified by shafina on 25-Aug-2004 for PREVIEWENG203ACC_000093 ( When a control bt synonym / column bt synonym is repeated within a UI , it's length must not exceed 24 characters.)  
if @modeflag in ('I' , 'X' ) and  
exists (  select 'X'  
from	ep_ui_control_dtl (nolock)  
where	customer_name		=  @engg_customer_name  
and		project_name		=  @engg_project_name  
and		process_name		=  @tmp_proc  
and		component_name		=  @tmp_comp  
and		activity_name		=  @tmp_act  
and		ui_name				=  @tmp_ui  
and		control_bt_synonym	= rtrim(@engg_cont_btsynname)  
union  
select 'X'  
from	ep_ui_grid_dtl (nolock)  
where	customer_name		=  @engg_customer_name  
and		project_name		=  @engg_project_name  
and		process_name		=  @tmp_proc  
and		component_name		=  @tmp_comp  
and		activity_name		=  @tmp_act  
and		ui_name				=  @tmp_ui  
and		column_bt_synonym	= rtrim(@engg_cont_btsynname)) and len (@engg_cont_btsynname) > 24  
begin  
	exec engg_error_sp 'ep_layout_sp_savctlcnml',2,'Control (BT Synonym):<%2> length must not exceed 24 at row:<%1>',  
		@ctxt_language,		@ctxt_ouinstance,		@ctxt_service,		@ctxt_user,		@fprowno,		@engg_cont_btsynname,
		'',					'',						@m_errorid output  
	if @m_errorid > 0  
		return  
end  
  
if @modeflag in ('I' , 'X' ) and  
exists ( Select  'A' 
from	ep_ui_grid_dtl (nolock)  
where	customer_name		=  @engg_customer_name  
and		project_name		=  @engg_project_name  
and		process_name		=  @tmp_proc  
and		component_name		=  @tmp_comp  
and		activity_name		=  @tmp_act  
and		ui_name				=  @tmp_ui  
--and   page_bt_synonym		=  @engg_cont_page_bts  
and    column_bt_synonym	=  @engg_cont_btsynname  
and    req_no				=  @engg_base_req_no )  
begin  
	select  @msg = 'Control Bt Synonym ' + @engg_cont_btsynname + ' already exists in the UI as Grid Column Bt Synonym'  
	EXEC  ENGG_ERROR_SP 'en_comp_sp_savcon_hsv',  
		7,			@msg,			@CTXT_LANGUAGE,			@CTXT_OUINSTANCE,		@CTXT_SERVICE,			@CTXT_USER,  
		'',			'',				'',						'',						@M_ERRORID  Output  
	RETURN  
end  

-- code modified by shafina on 01-Sep-2004 for PREVIEWENG203ACC_000095 (When a new BT synonym is entered , it must be checked whether it exists as a hidden view already.)  
if @modeflag in ('I' , 'X' ) and  
exists ( Select  'A' 
from	de_hidden_view (nolock)  
where	customer_name		=  @engg_customer_name  
and		project_name		=  @engg_project_name  
and		process_name		=  @tmp_proc  
and		component_name		=  @tmp_comp  
and		activity_name		=  @tmp_act  
and		ui_name				=  @tmp_ui  
--and   page_name			=  @engg_cont_page_bts  
and		hidden_view_bt_synonym=  @engg_cont_btsynname)  
begin  
	select  @msg = 'Control Bt Synonym ' + @engg_cont_btsynname + ' already exists in the UI as Hidden View Bt Synonym'  
	EXEC  ENGG_ERROR_SP 'en_comp_sp_savcon_hsv',  
		7,			@msg,			@CTXT_LANGUAGE,			@CTXT_OUINSTANCE,		@CTXT_SERVICE,			@CTXT_USER,  
		'',			'',				'',						'',						@M_ERRORID  Output  
	RETURN  
end  
-- code modified by shafina on 10-Dec-2004 for PREVIEWENG203ACC_000095 (When a new BT synonym is entered , it must be checked whether it exists as a scratch variable already.)  
if @modeflag in ('I' , 'X' ) and  
exists ( Select  'A' 
from	de_scratch_variable (nolock)  
where	customer_name		=  @engg_customer_name  
and		project_name		=  @engg_project_name  
and		process_name		=  @tmp_proc  
and		component_name		=  @tmp_comp  
and		activity_name		=  @tmp_act  
and		ui_name				=  @tmp_ui  
--and   page_name			=  @engg_cont_page_bts  
and		scratch_name		=  @engg_cont_btsynname)  
begin  
	select  @msg = 'Control Bt Synonym ' + @engg_cont_btsynname + ' already exists in the UI as User Defined Scratch Variable'  
	EXEC  ENGG_ERROR_SP 'en_comp_sp_savcon_hsv',  
		7,		@msg,		@CTXT_LANGUAGE,			@CTXT_OUINSTANCE,		@CTXT_SERVICE,			@CTXT_USER,  
		'',		'',			'',						'',						@M_ERRORID  Output  
	RETURN  
end  

-- code modified by shafina on 06-Dec-2004 for PREVIEWPF204ACC_000001 (Default Scratch variables must not be used as user defined bt synonyms.)  
if @modeflag in ('I' , 'X' ) and  
exists ( select 'x'  
from	de_scratch_variables_sys (nolock)  
where	btsynonym		= @engg_cont_btsynname)  
-- code modified by shafina on 22-Dec-2004 for PREVIEWENG203ACC_000115 (Modeflag must not be allowed to be entered as bt synonym.)  
or @engg_cont_btsynname = 'Modeflag'  
begin  
	select  @msg = 'Control Bt Synonym ' + @engg_cont_btsynname + ' already exists as a Default Scratch Variable'  
	exec  engg_error_sp 'en_comp_sp_savcon_hsv',  
		7,        @msg,        @ctxt_language,        @ctxt_ouinstance,		@ctxt_service,		@ctxt_user,			'',           '',  
		'',       '',          @m_errorid  output  
	return  
end  
  
if @modeflag <> 'D'  
begin  
	if @engg_cont_vis_length < 0  
	begin  
		select  @msg = 'Visible Length for row ' + convert(char(5), @fprowno) + ' cannot be negative'  
		exec engg_error_sp 'en_layout_sp_savctlcnml',
			10,		@msg,	@ctxt_language,		@ctxt_ouinstance,		@ctxt_service,		@ctxt_user,  
			'',		'',		'',					'',						@m_errorid output  
		if @m_errorid <> 0  
			return  
	end  
end  
  
--For each row that is selected for deletion, if controls exists as enum control, display error message.  
If @modeflag = 'D'  
begin  
	if exists( Select 'A' 
	from	ep_enum_value_dtl (nolock)  
	where	customer_name		= @engg_customer_name  
	and		project_name		= @engg_project_name  
	and		req_no				= @engg_base_req_no  
	and		process_name		= @tmp_proc  
	and		component_name		= @tmp_comp  
	and		activity_name		= @tmp_act  
	and		ui_name				= @tmp_ui  
	and		page_bt_synonym		= @engg_cont_page_bts  
	and		section_bt_synonym	= @engg_cont_sec_bts  
	and		control_bt_synonym	= @engg_cont_btsynname)  
	begin  
		select @msg = 'Control BT Synonym ' + @engg_cont_btsynname + ' is in use(Enumerated). Cannot Delete. at row no: ' + convert(char(3), @fprowno)  
		exec engg_error_sp 'ep_layout_sp_savctlcnml',  
			5,			@msg,			@ctxt_language,			@ctxt_ouinstance,			@ctxt_service,			@ctxt_user,  
			'',			'',				'',						'',							@m_errorid output  
		return  
	end  
  
	if exists( Select 'A' 
	from	ep_ui_traversal_dtl (nolock)  
	where	customer_name		= @engg_customer_name  
	and		project_name		= @engg_project_name  
	and		req_no				= @engg_base_req_no  
	and		process_name		= @tmp_proc  
	and		component_name		= @tmp_comp  
	and		activity_name		= @tmp_act  
	and		ui_name				= @tmp_ui  
	and		page_bt_synonym		= @engg_cont_page_bts  
	and		section_bt_synonym	= @engg_cont_sec_bts  
	and		control_bt_synonym	= @engg_cont_btsynname  
	-- modified by shafina on 18-Apr-2004 for PREVIEWENG203ACC_000038  
	and		isnull(linked_component,'') <> ''  
	and		isnull(linked_activity,'')	<> ''  
	and		isnull(linked_ui,'')		<> ''  )  
	begin  
		select @msg = 'Control BT Synonym ' + @engg_cont_btsynname + ' is in use(Traversal). Cannot Delete. at row no: ' + convert(char(3), @fprowno)  
		exec engg_error_sp 'ep_layout_sp_savctlcnml',  
			5,			@msg,			@ctxt_language,				@ctxt_ouinstance,			@ctxt_service,				@ctxt_user,  
			'',			'',				'',							'',							@m_errorid output  
		return  
	end  
  
	if exists( Select 'A' 
	from	ep_ui_grid_dtl grd (nolock)
	where	customer_name		= @engg_customer_name  
	and		project_name		= @engg_project_name  
	and		req_no				= @engg_base_req_no  
	and		process_name		= @tmp_proc  
	and		component_name		= @tmp_comp  
	and		activity_name		= @tmp_act  
	and		ui_name				= @tmp_ui  
	and		page_bt_synonym		= @engg_cont_page_bts  
	and		section_bt_synonym	= @engg_cont_sec_bts  
	and		control_bt_synonym	= @engg_cont_btsynname
	and		not exists (select 'x' 
	from	es_comp_ctrl_type_mst (nolock)
	where	customer_name		= @engg_customer_name  
	and		project_name		= @engg_project_name  
	and		req_no				= @engg_base_req_no  
	and		process_name		= @tmp_proc  
	and		component_name		= @tmp_comp  
	and		ctrl_type_name		= @engg_cont_elem_type
	and		base_Ctrl_type		= 'Slider'))
	begin  
		select @msg = 'Control BT Synonym ' + @engg_cont_btsynname + ' is in use(Grid). Cannot Delete. at row no: ' + convert(char(3), @fprowno)  
		exec engg_error_sp 'ep_layout_sp_savctlcnml',  
			5,			@msg,		@ctxt_language,			@ctxt_ouinstance,		@ctxt_service,			@ctxt_user,  
			'',			'',			'',						'',						@m_errorid output  
		return  
	end 
		 
	if exists( Select 'A' 
	from	ep_radio_button_dtl (nolock)  
	where	customer_name		= @engg_customer_name  
	and		project_name		= @engg_project_name  
	and		req_no				= @engg_base_req_no  
	and		process_name		= @tmp_proc  
	and		component_name		= @tmp_comp  
	and		activity_name		= @tmp_act  
	and		ui_name				= @tmp_ui  
	and		page_bt_synonym		= @engg_cont_page_bts  
	and		section_bt_synonym	= @engg_cont_sec_bts  
	and		control_bt_synonym	= @engg_cont_btsynname)  
	begin  
		select @msg = 'Control BT Synonym ' + @engg_cont_btsynname + ' is in use(Radio Button). Cannot Delete. at row no: ' + convert(char(3), @fprowno)  
		exec engg_error_sp 'ep_layout_sp_savctlcnml',  
			5,			@msg,		@ctxt_language,			@ctxt_ouinstance,		@ctxt_service,			@ctxt_user,  
			'',			'',			'',						'',						@m_errorid output  
		return  
	end  
end  
  
-- code modified by shafina on 31-Dec-2005 for PREVIEWENG203ACC_000124 (In section layout tab , when i try to delete a control 'Error converting datatype varchar 30% to a datatype of int')  
/*Modification made by Muthupandi S for Bug id : PNR2.0_31754 Starts */  
if @modeflag = 'D'    
begin    
	if exists (select 'X' 
	from	ep_ui_pageevents_dtl  (nolock)  
	where	customer_name	= @engg_customer_name    
	and		project_name	= @engg_project_name     
	and		process_name	= @tmp_proc     
	and		component_name	= @tmp_comp    
	and		activity_name	= @tmp_act    
	and		ui_name			= @tmp_ui     
	and		task_onclick in (select task_name 
	from	ep_action_mst (nolock) --Code modified for the Bug ID:PNR2.0_32352  
	where	customer_name	= @engg_customer_name    
	and		project_name	= @engg_project_name     
	and		process_name	= @tmp_proc    
	and		component_name  = @tmp_comp    
	and		activity_name	= @tmp_act    
	and		ui_name			= @tmp_ui    
	and		page_bt_synonym = @engg_cont_page_bts    
	and		primary_control_bts =@engg_cont_btsynname))    
	begin    
		select @msg = 'The task of the Control ' +'"'+ @engg_cont_btsynname +'"'+ 'is used as a PageEvent.Hence control cannot be deleted. Check Specify Page Events Link'  
		raiserror(@msg,16,1)    
		return    
	end    
end    

/*Modification made by Muthupandi S for Bug id : PNR2.0_31754 Ends */  
    
/*Modification made by Muthupandi S for Bug id : PNR2.0_32543 Starts*/  
if @modeflag = 'D'    
begin    
	if exists (select 'X' 
	from	ep_layout_ezeeview_sp  (nolock)  
	where	customer_name	= @engg_customer_name    
	and		project_name	= @engg_project_name 
	and		process_name	= @tmp_proc     
	and		component_name	= @tmp_comp    
	and		activity_name	= @tmp_act    
	and		ui_name			= @tmp_ui   
	and		page_bt_synonym = @engg_cont_page_bts   
	and		Link_ControlName= @engg_cont_btsynname)  
	begin    
		select @msg = 'The link control ' +'"'+ @engg_cont_btsynname +'"' + ' is Mapped with an ezee view sp.Hence control cannot be deleted. Check Specify ezee view Link'  
		raiserror(@msg,16,1)    
		return    
	end    
end  
/*Modification made by Muthupandi S for Bug id : PNR2.0_32543 Ends*/  

-- Code modification for PNR2.0_22818  starts  
--kanagavel
declare	@datagrid	engg_flag

select	@datagrid = b.Datagrid 
from	ep_ui_control_dtl a (nolock) ,   
		es_comp_ctrl_type_mst_vw b  (nolock)  
where   a.customer_name			=  @engg_customer_name  
and     a.project_name			=  @engg_project_name  
and     a.process_name			=  @tmp_proc  
and     a.component_name		=  @tmp_comp  
and     a.activity_name			=  @tmp_act  
and     a.ui_name				=  @tmp_ui  
and     a.page_bt_synonym		=  @engg_cont_page_bts  
and     a.section_bt_synonym	=  @engg_cont_sec_bts  
and     a.control_bt_synonym	<> @engg_cont_btsynname  
  
and     a.customer_name     	=  b.customer_name  
and     a.project_name      	=  b.project_name  
and     a.process_name      	=  b.process_name  
and     a.component_name    	=  b.component_name  
and     a.control_type			=  b.ctrl_type_name  
and     b.base_ctrl_type		in ('grid')

if isnull(@datagrid,'N') <>'Y'
begin
	if @modeflag in('U', 'Y', 'I', 'X')  
	BEGIN  
	--		If exists (select '*' from  ep_ui_control_dtl a (nolock) ,  
	--		es_comp_ctrl_type_mst_vw b  (nolock)  ,
	--		ep_ui_section_dtl c(nolock)
	--		where   a.customer_name			=  @engg_customer_name  
	--		and     a.project_name			=  @engg_project_name  
	--		and     a.process_name			=  @tmp_proc  
	--		and     a.component_name		=  @tmp_comp  
	--		and     a.activity_name			=  @tmp_act  
	--		and     a.ui_name				=  @tmp_ui  
	--		and     a.page_bt_synonym		=  @engg_cont_page_bts  
	--		and     a.section_bt_synonym	=  @engg_cont_sec_bts  
	--		and     a.control_bt_synonym    <> @engg_cont_btsynname  

	--		and     a.customer_name     	=  b.customer_name  
	--		and     a.project_name      	=  b.project_name  
	--		and     a.process_name      	=  b.process_name  
	--		and     a.component_name    	=  b.component_name  
	--		and     a.control_type			=  b.ctrl_type_name  
	--		and     b.base_ctrl_type		in ('grid')  
	--		and		isnull(IsAssorted,'N')  = 'N'
	--		--and		c.section_type		<> 'MobCalendar'
	--		and		c.customer_name			= a.customer_name
	--		and		c.project_name			= a.project_name
	--		and		c.process_name			= a.process_name 
	--		and		c.component_name		= a.component_name
	--		and		c.activity_name			= a.activity_name
	--		and		c.ui_name				= a.ui_name
	--		and		c.page_bt_synonym		= a.page_bt_synonym
	--		and		c.section_bt_synonym	= a.section_bt_synonym)
	----and		c.section_type			<> 'Carousel' ) -- PLF2.0_18487
	--		Begin  
	--			Select  @msg =   'The section <%2> contains a Grid .Define the control in another section . Check Row <%1>'  
	--			EXEC    ENGG_ERROR_SP  'ep_layout_sp_savctlcnml',  
	--			3,  
	--			@msg,  
	--			@CTXT_LANGUAGE,  
	--			@CTXT_OUINSTANCE,  
	--			@CTXT_SERVICE,  
	--			@CTXT_USER,  
	--			@fprowno,  
	--			@engg_cont_sec_bts,  
	--			'',  
	--			'',  
	--			@M_ERRORID  Output  
	--			RETURN  
	--		End  
		IF  @tmp_ctl = 'grid'  
		begin  
		

			If exists (select '*' 
			from	ep_ui_control_dtl a (nolock)  ,
					ep_ui_section_dtl c(nolock),
					es_comp_ctrl_type_mst b(nolock)
			where   a.customer_name     = @engg_customer_name  
			and    a.project_name		= @engg_project_name  
			and    a.process_name		= @tmp_proc  
			and  a.component_name		= @tmp_comp  
			and    a.activity_name		= @tmp_act  
			and    a.ui_name			= @tmp_ui  
			and    a.page_bt_synonym	= @engg_cont_page_bts  
			and    a.section_bt_synonym = @engg_cont_sec_bts
			and    a.control_bt_synonym <> @engg_cont_btsynname

			and		c.customer_name		= a.customer_name
			and		c.project_name		= a.project_name
			and		c.process_name		= a.process_name 
			and		c.component_name	= a.component_name
			and		c.activity_name		= a.activity_name
			and		c.ui_name			= a.ui_name
			and		c.page_bt_synonym	= a.page_bt_synonym
			and		c.section_bt_synonym= a.section_bt_synonym
			and     c.section_type		<> 'MobileGrid'  -- added for Defect Id: TECH-19347 starts
			--and		c.section_type	<> 'Carousel' 

			and		a.customer_name		= b.customer_name
			and		a.process_name		= b.process_name
			and		a.project_name		= b.project_name
			and		a.component_name	= b.component_name
			and		a.control_type		= b.ctrl_type_name
			and		b.base_ctrl_type	not in ('Pivot', 'Button') -- Added for Pivot control TECH-28436 
			and		ISNULL(IsAssorted,'N') = 'N')
			Begin  
				Select  @msg =   'Control(s) already defined under the section <%2>.Define grid in a seperate section . Check Row <%1>'  
				EXEC    ENGG_ERROR_SP  'ep_layout_sp_savctlcnml',  
					3,			@msg,				@CTXT_LANGUAGE,			@CTXT_OUINSTANCE,		@CTXT_SERVICE,			@CTXT_USER,  
					@fprowno,	@engg_cont_sec_bts, '',						'',						@M_ERRORID  Output  
				RETURN  
			End  
		end  
	end
end 

if @modeflag in('U', 'Y', 'I', 'X')   
BEGIN  
	If exists (select 'X' 
	from	ep_ui_control_dtl a (nolock) ,  
			es_comp_ctrl_type_mst_vw b  (nolock)  ,
			ep_ui_section_dtl c(nolock)
	where   a.customer_name			=  @engg_customer_name  
	and     a.project_name			=  @engg_project_name  
	and     a.process_name			=  @tmp_proc  
	and     a.component_name		=  @tmp_comp  
	and     a.activity_name			=  @tmp_act  
	and     a.ui_name				=  @tmp_ui  
	and     a.page_bt_synonym		=  @engg_cont_page_bts  
	and     a.section_bt_synonym	=  @engg_cont_sec_bts  
	and     a.control_bt_synonym    =  @engg_cont_btsynname  
	   
	and     a.customer_name     	=  b.customer_name  
	and     a.project_name      	=  b.project_name  
	and     a.process_name      	=  b.process_name  
	and     a.component_name    	=  b.component_name  
	and     a.control_type			=  b.ctrl_type_name  
	and     b.base_ctrl_type		=  'Assorted'  
	--and   b.base_ctrl_type		in ('grid')  
	--and	isnull(IsAssorted,'N')	= 'Y'

	and		c.customer_name			= a.customer_name
	and		c.project_name			= a.project_name
	and		c.process_name			= a.process_name 
	and		c.component_name		= a.component_name
	and		c.activity_name			= a.activity_name
	and		c.ui_name				= a.ui_name
	and		c.page_bt_synonym		= a.page_bt_synonym
	and		c.section_bt_synonym	= a.section_bt_synonym
	and		c.visisble_flag			= 'N')
	Begin	
		Raiserror ('Assorted Grid controls cannot be created in Hidden Section.',16,4)
		Return
	End
End  
  
  --code added  for the defect id:TECH-63527 starts
		
        SELECT @tmp_ctrltype		=	 control_type
	    FROM ep_ui_control_Dtl WITH (NOLOCK)
		WHERE customer_name			=  @engg_customer_name  
	    AND	  project_name			=  @engg_project_name  
		AND	  process_name			=  @tmp_proc  
	    AND   component_name		=  @tmp_comp  
		AND	  activity_name			=  @tmp_act  
	    AND	  ui_name			    =  @tmp_ui  
		AND	  control_bt_synonym    =  @engg_msc_ass_control
		
	
			SELECT	@basectrl_type_name	=	base_ctrl_type
			FROM	es_comp_ctrl_type_mst (nolock)
			WHERE	customer_name		= @engg_customer_name
			AND		project_name		= @engg_project_name
			AND		process_name		= @tmp_proc
			AND		component_name		= @tmp_comp
			AND		ctrl_type_name		= @engg_cont_elem_type
			
			SELECT	@tmp_assoc_basectrl_type	=	base_ctrl_type
			FROM	es_comp_ctrl_type_mst (nolock)
			WHERE	customer_name				=   @engg_customer_name
			AND		project_name				=   @engg_project_name
			AND		process_name				=   @tmp_proc
			AND		component_name				=   @tmp_comp
			AND		ctrl_type_name				=   @tmp_ctrltype
		
		

IF ISNULL(@modeflag,'') IN ('I','X','U','Y') 
BEGIN 
	IF ISNULL(@basectrl_type_name,'') NOT IN ('LISTVIEW') AND ISNULL(@engg_msc_ass_control,'') <> '' AND  (ISNULL(@engg_cont_elem_type,'') NOT IN ('FileSize','FileType'))		--Code Added for TECH-71262
	BEGIN
    		RAISERROR('Control can be associated for the MultiSelectCombo (ListView)/FileSize & FileType. Please associate control column at row no: %i',16,1,@fprowno)
			RETURN
	END
END

IF ISNULL(@modeflag,'') IN ('I','X','U','Y') AND  ISNULL(@engg_msc_ass_control,'') <> ''
BEGIN
	IF NOT EXISTS( SELECT 'X' FROM
	              ep_ui_control_Dtl WITH (NOLOCK)
				  WHERE	customer_name		=  @engg_customer_name  
				  AND	project_name		=  @engg_project_name  
				  AND	process_name		=  @tmp_proc  
				  AND   component_name		=  @tmp_comp  
				  AND	activity_name		=  @tmp_act  
				  AND	ui_name				=  @tmp_ui  
				  AND	control_bt_synonym	=  @engg_MSC_Ass_control)
		BEGIN
			RAISERROR('Associated control is not available for this UI. Please check at row no:%i',16,1,@fprowno)
			RETURN
		END

		IF ISNULL(@tmp_assoc_basectrl_type,'') NOT IN ('Edit','DisplayOnly')  
		BEGIN
		   RAISERROR('Only Edit/Display  controls can be associated for the MultiSelectCombo .Please check at row no:%i',16,1,@fprowno)
		   RETURN
		END
END

--code added  for the defect id:TECH-63527 ends

--Code Added for TECH-71262 starts 
		IF @engg_cont_elem_type IN ('FileSize','FileType') AND ISNULL(@engg_msc_ass_control,'') = ''
		BEGIN
			RAISERROR('Please associate Attachment enabled Edit Control in the Associate Control at row no:%i.',16,1,@fprowno)
		    RETURN
		END
--Code Added for TECH-71262 ends by 14469


--Code Added for TECH-71262 by 13639
	IF ISNULL(@modeflag,'') IN ('I','X','U','Y') 
	BEGIN
	IF ISNULL(@engg_msc_ass_control,'') <> '' and isnull(@engg_cont_elem_type,'') in ('filetype','filesize')
	BEGIN
	IF NOT  EXISTS( SELECT 'X' FROM
	              ep_ui_control_dtl con WITH (NOLOCK)
				  join es_comp_ctrl_type_mst mst with(nolock)
				  on  mst.customer_name			=	con.customer_name
				  and mst.project_name			=	con.project_name
				  and mst.process_name			=	con.process_name
				  and mst.component_name		=	con.component_name
				  and mst.ctrl_type_name		=	con.control_type
				  WHERE	con.customer_name		=  @engg_customer_name  
				  AND	con.project_name		=  @engg_project_name  
				  AND	con.process_name		=  @tmp_proc  
				  AND   con.component_name		=  @tmp_comp  
				  AND	con.activity_name		=  @tmp_act  
				  AND	con.ui_name				=  @tmp_ui  
				  AND	mst.attach_document		=	'y'
				  AND	mst.AttachmentWithDesc	=	'y'
				  AND	con.control_bt_synonym	=	@engg_msc_ass_control)
	BEGIN
	RAISERROR('Filesize & Filetype controls type should be associated with Attachment enabled controls.Please check at row no:%i',16,1,@fprowno)
	RETURN
	END				  	
END
END

--Code Added for TECH-71262 ends by 13639

if @modeflag in('U', 'Y', 'I', 'X')  
BEGIN  
/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P begin*/  
	if exists ( select 'X'  
	from	ep_ui_control_dtl a(nolock),  
			es_comp_ctrl_type_mst b(nolock)  
	where   a.customer_name     =  @engg_customer_name  
	and     a.project_name		=  @engg_project_name  
	and     a.process_name      =  @tmp_proc  
	and     a.component_name	=  @tmp_comp  
	and     a.activity_name     =  @tmp_act  
	and     a.ui_name			=  @tmp_ui  
	and     a.control_bt_synonym=  @engg_cont_btsynname  
	and     a.customer_name     =  b.customer_name  
	and     a.project_name      =  b.project_name  
	and     a.process_name      =  b.process_name  
	and     a.component_name    =  b.component_name  
	and     a.control_type		=  b.ctrl_type_name  
	and     b.base_ctrl_type	= 'Listedit'   )  
    /*Modification made by Muthupandi S for Bug id : PNR2.0_36051 Starts*/  
	begin  
		if  exists (select 'X' 
		from	ep_listedit_control_map b (nolock)  
		where	b.customer_name     =  @engg_customer_name  
		and		b.project_name      =  @engg_project_name  
		and		b.process_name      =  @tmp_proc  
		and		b.component_name	=  @tmp_comp  
		and		b.activity_name     =  @tmp_act  
		and		b.ui_name			=  @tmp_ui  
		and		b.listedit_synonym  =  @engg_cont_btsynname  
		union  
		select 'X' 
		from	ep_listedit_column_dtl c(nolock) 
		where	c.customer_name		=  @engg_customer_name  
		and		c.project_name      =  @engg_project_name  
		and		c.process_name      =  @tmp_proc  
		and		c.component_name	=  @tmp_comp  
		and		c.activity_name     =  @tmp_act  
		and		c.ui_name			=  @tmp_ui  
		and		c.listedit_synonym  =  @engg_cont_btsynname)  
		begin  
			if not exists ( select 'X'  
			from	ep_ui_control_dtl a(nolock)  
			where	customer_name		=  @engg_customer_name  
			and		project_name		=  @engg_project_name  
			and		process_name		=  @tmp_proc  
			and		component_name		=  @tmp_comp  
			and		activity_name		=  @tmp_act  
			and		ui_name				=  @tmp_ui  
			and		control_bt_synonym  =  @engg_cont_btsynname  
			and		control_type		= @engg_cont_elem_type)  
         /*Modification made by Muthupandi S for Bug id : PNR2.0_36051 Ends*/        
			begin    
				raiserror('Control BT Synonym already in use as Listedit.',16,1)  
				 return  
			end  
		END  
	end      
/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P End*/  
END

---Data grid section should allow only one control other than grid
-- Code modification for PNR2.0_22818  ends  

if @modeflag <> 'D'  
begin  
	declare @count_dg engg_seqno

	if exists (select 'X'
	from	ep_ui_control_dtl a (nolock) ,   
			es_comp_ctrl_type_mst_vw b  (nolock)  
	where   a.customer_name				=  @engg_customer_name  
	and     a.project_name				=  @engg_project_name  
	and     a.process_name				=  @tmp_proc  
	and     a.component_name			=  @tmp_comp  
	and     a.activity_name				=  @tmp_act  
	and     a.ui_name					=  @tmp_ui  
	and     a.page_bt_synonym			=  @engg_cont_page_bts  
	and     a.section_bt_synonym		=  @engg_cont_sec_bts  
	and     a.control_bt_synonym		= @engg_cont_btsynname  
  
	and     a.customer_name     	=  b.customer_name  
	and     a.project_name      	=  b.project_name  
	and     a.process_name      	=  b.process_name  
	and     a.component_name    	= b.component_name  
	and     a.control_type			=  b.ctrl_type_name  
	and     b.datagrid				=  'Y' )
	begin 
		select @count_dg       =  count(control_bt_synonym)
		from  ep_ui_control_dtl  (nolock) 
		where   customer_name		=  @engg_customer_name  
		and     project_name		=  @engg_project_name  
		and     process_name		=  @tmp_proc  
		and     component_name		=  @tmp_comp  
		and     activity_name		=  @tmp_act  
		and     ui_name				=  @tmp_ui  
		and     page_bt_synonym		=  @engg_cont_page_bts  
		and     section_bt_synonym	=  @engg_cont_sec_bts  
					
		if @count_dg > 2
		begin 
			raiserror(' For the section : %s can have Only one control other than grid',16,1,@engg_cont_sec_bts)
			return	
		end 
	end 

	--TECH-69624 (14469)
		IF ISNULL(@modeflag,'') IN ('I','X','U','Y') AND ISNULL(@engg_cont_forresponsive,0)<>0
		BEGIN
			IF EXISTS
			(SELECT 'X'
			 FROM	ep_ui_section_dtl WITH (NOLOCK)
			 WHERE   customer_name		=  @engg_customer_name  
			 AND     project_name		=  @engg_project_name  
			 AND     process_name		=  @tmp_proc  
			 AND     component_name		=  @tmp_comp  
			 AND     activity_name		=  @tmp_act  
			 AND     ui_name			=  @tmp_ui  
			 AND     page_bt_synonym	=  @engg_cont_page_bts  
			 AND     section_bt_synonym	=  @engg_cont_sec_bts  
			 AND	 sectionlayout		<> 'Responsive')
			 BEGIN
				RAISERROR('Section layout should be ''Responsive'' at rowno: %i',16,1,@fprowno)
				RETURN
			 END
		END
		--TECH-69624 (14469)

		--Code added by 14469 for TECH-73216 starts
		--IF ISNULL(@modeflag,'')	IN ('I','X') 
		--AND EXISTS (SELECT 'X' 
		--FROM ep_ui_page_dtl (NOLOCK)
		--WHERE  customer_name	= @engg_customer_name
		--AND	   project_name		= @engg_project_name
		--AND	   req_no			= @engg_base_req_no
		--AND	   page_bt_synonym  = @engg_cont_btsynname
		--UNION
		--SELECT 'X' 
		--FROM ep_ui_section_dtl (NOLOCK)
		--WHERE  customer_name	= @engg_customer_name
		--AND	   project_name		= @engg_project_name
		--AND	   req_no			= @engg_base_req_no
		--AND	   section_bt_synonym  = @engg_cont_btsynname
		--UNION
		--SELECT 'X' 
		--FROM ep_ui_control_dtl (NOLOCK)
		--WHERE  customer_name	= @engg_customer_name
		--AND	   project_name		= @engg_project_name
		--AND	   req_no			= @engg_base_req_no
		--AND	   control_bt_synonym  = @engg_cont_btsynname
		--UNION
		--SELECT 'X' 
		--FROM ep_ui_grid_dtl (NOLOCK)
		--WHERE  customer_name	= @engg_customer_name
		--AND	   project_name		= @engg_project_name
		--AND	   req_no			= @engg_base_req_no
		--AND	   column_bt_synonym  = @engg_cont_btsynname
		--UNION
		--SELECT 'X' 
		--FROM de_hidden_view (NOLOCK)
		--WHERE  customer_name	= @engg_customer_name
		--AND	   project_name		= @engg_project_name
		--AND	   control_bt_synonym = @engg_cont_btsynname)
		--BEGIN
		--	RAISERROR ('Btsynonym name should be unique for Customer Project level.',16,1)
		--	RETURN
		--END
		--Code added by 14469 for TECH-73216 ends

	If  exists( Select  'A' 
	from	ep_ui_control_dtl (nolock)  
	where	customer_name		= @engg_customer_name  
	and		project_name		= @engg_project_name  
	and		process_name		= @tmp_proc  
	and		component_name		= @tmp_comp  
	and		activity_name		= @tmp_act  
	and		ui_name				= @tmp_ui  
	and		page_bt_synonym		= @engg_cont_page_bts  
	and		section_bt_synonym  = @engg_cont_sec_bts  
	and		control_bt_synonym  = @engg_cont_btsynname  
	and     req_no				= @engg_base_req_no )  
	begin  
--modified by shafina on 22-jan-2004  
-- to delete the rows in traversal table when control_type is updated..  
		if exists  ( select 'x'  
		from	ep_ui_traversal_dtl (nolock)  
		where	customer_name		= @engg_customer_name  
		and		project_name		= @engg_project_name  
		and		process_name		= @tmp_proc  
		and		component_name		= @tmp_comp  
		and		activity_name		= @tmp_act  
		and		ui_name				= @tmp_ui  
		and		page_bt_synonym		= @engg_cont_page_bts  
		and		section_bt_synonym	= @engg_cont_sec_bts  
		and		control_bt_synonym	= @engg_cont_btsynname  
		and		req_no				= @engg_base_req_no  
		and		isnull(linked_component,'') = ''  
		and		isnull(linked_activity,'')	= ''  
		and		isnull(linked_ui,'')		= '' )  
		begin  
			select	@tmp_control_type  = control_type  
			from	ep_ui_control_dtl (nolock)  
			where	customer_name   = @engg_customer_name  
			and		project_name	= @engg_project_name  
			and		process_name	= @tmp_proc  
			and		component_name  = @tmp_comp  
			and		activity_name   = @tmp_act  
			and		ui_name			= @tmp_ui  
			and		page_bt_synonym = @engg_cont_page_bts  
			and		section_bt_synonym  = @engg_cont_sec_bts  
			and		control_bt_synonym  = @engg_cont_btsynname  
			and		req_no			= @engg_base_req_no  
  
			if  @tmp_control_type <> @engg_cont_elem_type  
			begin  
-- code modified by shafina on 20-Nov-2004 for Primary key modification in traversal tables.  
				delete  from  ep_ui_traversal_dtl  
				where	customer_name   = @engg_customer_name  
				and		project_name	= @engg_project_name  
				and		req_no			= @engg_base_req_no  
				and		process_name	= @tmp_proc  
				and		component_name  = @tmp_comp  
				and		activity_name	= @tmp_act  
				and		ui_name			= @tmp_ui  
				and		page_bt_synonym = @engg_cont_page_bts  
				and		section_bt_synonym = @engg_cont_sec_bts  
				and		control_bt_synonym = @engg_cont_btsynname  
				and		isnull(linked_component,'') = ''  
				and		isnull(linked_activity,'') = ''  
				and		isnull(linked_ui,'')  = ''  
			end  
		end  

-- code modified by shafina on 17-Aug-2004 for PREVIEWENG203ACC_000085 ( ctrlid must be updated only if modeflag in 'u','y')  
		if @modeflag in ('U','Y')  
		begin  
			if @base_ctrl_type_tmp <> @tmp_ctl  
			begin  
				select	@ctrl_id_old  = control_id  
				from	ep_ui_control_dtl   (nolock)  
				where	customer_name		= @engg_customer_name  
				and		project_name		= @engg_project_name  
				and		process_name		= @tmp_proc  
				and		component_name		= @tmp_comp  
				and		activity_name		= @tmp_act  
				and		ui_name				= @tmp_ui  
				and		page_bt_synonym		= @engg_cont_page_bts  
				and		section_bt_synonym  = @engg_cont_sec_bts  
				and		control_bt_synonym  = @engg_cont_btsynname  
				and     req_no				= @engg_base_req_no  
				

				Update  ep_ui_control_dtl  set
						control_id   = '',  
						view_name    = ''  
				where	customer_name		= @engg_customer_name  
				and		project_name		= @engg_project_name  
				and		process_name		= @tmp_proc  
				and		component_name		= @tmp_comp  
				and		activity_name		= @tmp_act  
				and		ui_name				= @tmp_ui  
				and		page_bt_synonym		= @engg_cont_page_bts  
				and		section_bt_synonym  = @engg_cont_sec_bts  
				and		control_bt_synonym  = @engg_cont_btsynname  
				and     req_no				= @engg_base_req_no 
				--and		ExtensionReqd		= @engg_extnreqd --Code added for TECH-60451
				
				exec ep_controlid_generation  
					@engg_customer_name  , @engg_project_name , @engg_base_req_no ,  @tmp_proc  , @tmp_comp   , @tmp_act   ,  
					@tmp_ui     ,		  @engg_cont_btsynname, @tmp_ctl   ,		 @editable    ,@visible   , @control_id out  
				
				Update  ep_ui_control_dtl set
						control_id   = @control_id,  
						view_name    = @control_id,  
				-- code added by shafina on 07-Sep-2004 for PREVIEWENG203ACC_000098 (Modified Date must be updated.)  
						modifiedby   = @ctxt_user,  
						modifieddate = getdate()  
				where  customer_name    = @engg_customer_name  
				and   project_name		= @engg_project_name  
				and   process_name		= @tmp_proc  
				and   component_name    = @tmp_comp  
				and   activity_name		= @tmp_act  
				and   ui_name			= @tmp_ui  
				and   page_bt_synonym   = @engg_cont_page_bts  
				and   section_bt_synonym= @engg_cont_sec_bts  
				and   control_bt_synonym= @engg_cont_btsynname  
				and   req_no			= @engg_base_req_no  
				--and		ExtensionReqd	= @engg_extnreqd --Code added for TECH-60451
-- code modified by shafina on 12-Aug-2004 for updating control id in Grid_Dtl table (PREVIEWENG203ACC_000085)  
				Update  ep_ui_grid_dtl set 
						control_id   = @control_id,  
						modifiedby   = @ctxt_user,  
						modifieddate = getdate()  
				where  customer_name    = @engg_customer_name  
				and   project_name		= @engg_project_name  
				and   process_name		= @tmp_proc  
				and   component_name	= @tmp_comp  
				and   activity_name		= @tmp_act  
				and   ui_name			= @tmp_ui  
				and   page_bt_synonym   = @engg_cont_page_bts  
				and   section_bt_synonym= @engg_cont_sec_bts  
				and   control_bt_synonym= @engg_cont_btsynname  
				and   req_no			= @engg_base_req_no  
				and   control_id		= @ctrl_id_old  
			end  
		end  
-- code modified by shafina on 09-Sep-2004 for PREVIEWENG203SYS_000144 (Enumerated value is not comin in combo)  
  
		if exists  (select 'x'  
		from	ep_enum_value_dtl (nolock)  
		where	customer_name		=  @engg_customer_name  
		and		project_name		=  @engg_project_name  
		and		process_name		=  @tmp_proc  
		and		component_name		=  @tmp_comp  
		and		activity_name		=  @tmp_act  
		and		ui_name				=  @tmp_ui  
		and		page_bt_synonym		=  @engg_cont_page_bts  
		and		section_bt_synonym  =  @engg_cont_sec_bts  
		and		control_bt_synonym  =  @engg_cont_btsynname  
		and		req_no				=  @engg_base_req_no)  
		and		@tmp_ctl			= 'combo'  
		begin  
			select @engg_cont_samp_data  = ''  
			select @enumcap     = ''  
  
			declare enum_curr cursor for  
			select	enum_caption  
			from	ep_enum_value_dtl (nolock)  
			where	customer_name	= @engg_customer_name  
			and		project_name	= @engg_project_name  
			and		req_no			= @engg_base_req_no  
			and		process_name	= @tmp_proc  
			and		component_name  = @tmp_comp  
			and		activity_name	= @tmp_act  
			and		ui_name			= @tmp_ui  
			and		page_bt_synonym = @engg_cont_page_bts  
			and		section_bt_synonym = @engg_cont_sec_bts  
			and		control_bt_synonym = @engg_cont_btsynname  
			order  by default_flag desc  
			open enum_curr  
  
			while 1=1  
			begin  
				fetch  next from enum_curr  into @enumcap  
				if  @@fetch_status <> 0  
					break  
				select @engg_cont_samp_data = @engg_cont_samp_data + ltrim(rtrim(@enumcap)) + '~'  
			end  
			close  enum_curr  
			deallocate enum_curr  
  
			if len(@engg_cont_samp_data) > 0  
				select @engg_cont_samp_data = substring(@engg_cont_samp_data, 1, len(@engg_cont_samp_data) -1)  
		end  
--code modified by kiruthika for bugid:PNR2.0_13982  
  
		if exists  (select 'x'  
		from	ep_enum_value_dtl (nolock)  
		where	customer_name	  =  @engg_customer_name  
		and		project_name      =  @engg_project_name  
		and		process_name      =  @tmp_proc  
		and		component_name    =  @tmp_comp  
		and		activity_name     =  @tmp_act  
		and		ui_name           =  @tmp_ui  
		and		page_bt_synonym   =  @engg_cont_page_bts  
		and		section_bt_synonym=  @engg_cont_sec_bts  
		and		control_bt_synonym=  @engg_cont_btsynname  
		and		req_no            =  @engg_base_req_no)  
		and		@tmp_ctl		  = 'combo'  
		begin  
			if isnull(@sampledata,'') <> '' and  (@sampledata <> @engg_cont_samp_data)  
			begin  
				raiserror('sample data is not applicable for enumerated combo',16,1)  
				return  
			end  
		end 
		
 
--Code Modified by Hamsika for the Fix Note : _DM_FN_099  
		If @engg_tab_stopforhelp = '1'  
			select @engg_tab_stopforhelp ='Y'  
		Else  
			select @engg_tab_stopforhelp ='N'  
--Code Modified by Hamsika for the Fix Note : _DM_FN_099  
		Update  ep_ui_control_dtl set 
				control_type		= @engg_cont_elem_type,  
				visisble_length		= @engg_cont_vis_length,  
				horder				= @engg_cont_horder,  
				vorder				= @engg_cont_vorder,  
				proto_tooltip		= @engg_cont_tooltip,   
				sample_data			= @engg_cont_samp_data,  
				control_doc			= @engg_cont_doc,  
				data_column_width   = isnull(@engg_cont_datawidth,0),  
				label_column_width  = isnull(@engg_cont_labwidth,0), 
				label_column_scalemode	= @label_scale_mode,  
				data_column_scalemode	= @data_scale_mode,  
				order_seq			= isnull(@engg_cont_sequence,1),  
				tab_seq				= isnull(@engg_tab_sequence,0),  
				help_tabstop		= @engg_tab_stopforhelp,  
				--Code Modified for the Bug ID:PNR2.0_29237 Starts  
				LabelClass			= @engg_label_class,  
				ControlClass		= @engg_control_class,  
				LabelImageClass		= @engg_label_image_class,  
				ControlImageClass	= @engg_control_image_class,  
				--Code Modified for the Bug ID:PNR2.0_29237 ends  
				Set_User_Pref		= @user_pref, -- Added for PNR2.0_23541   
				modifiedby			= @ctxt_user,  
				modifieddate		= getdate(),  
				freezecount			= isnull(@freezecount,0), --added for PNR2.0_26860  
				controlimage		= @Engg_cont_Ctrlimg,  
				rowspan				= @Engg_cont_rowspan,  
				colspan				= @Engg_cont_colspan ,
				Templateid			= @engg_cont_tempid,  -- kanagavel 
				TemplateCategory	= @ctrl_temp_cat,
				TemplateSpecific	= @ctrl_temp_specific,
				-- code added by Ranjitha
				AccessKey				= @AccessKey,
				icon_class				= @Icon_class,
				icon_position			= @Icon_position,
				Control_class_ext6		= @Cont_class_ext6,
				dynamicstyle			= case when @engg_dynamicstyle = '1' then 'Y' else 'N' end,
				imageasdata				= case when @engg_imageasdata = '1' then 'Y' else 'N' end,-- code ends
				ExtensionReqd			=	case when @engg_extnreqd='1' then 'Yes' else 'No' end, --Code added for TECH-60451
				AssociateControl		= @engg_MSC_Ass_control, ---code added  for the defect id:TECH-63527
				ForResponsive			= @Engg_cont_forresponsive,	--Code added for TECH-69624
				ControlFormat			= @engg_cont_control_format,	--Code Added for the Defect Id TECH-72114
				ButtonNature			= @ButtonNature,	--Tech-75230
				InlineStyle				= @InlineStyle		--Tech-75230
		where	customer_name		= @engg_customer_name  
		and		project_name		= @engg_project_name  
		and		process_name		= @tmp_proc  
		and		component_name		= @tmp_comp  
		and		activity_name		= @tmp_act  
		and		ui_name				= @tmp_ui  
		and		page_bt_synonym		= @engg_cont_page_bts  
		and		section_bt_synonym  = @engg_cont_sec_bts  
		and		control_bt_synonym  = @engg_cont_btsynname  
		and		req_no				= @engg_base_req_no  
	end  

	If not exists(  Select 'A' 
	from	ep_ui_control_dtl (nolock)  
	where	customer_name		= @engg_customer_name  
	and		project_name		= @engg_project_name  
	and		process_name		= @tmp_proc  
	and		component_name		= @tmp_comp  
	and		activity_name		= @tmp_act  
	and		ui_name				= @tmp_ui  
	and		page_bt_synonym		= @engg_cont_page_bts  
	and		section_bt_synonym  = @engg_cont_sec_bts  
	and		control_bt_synonym  = @engg_cont_btsynname  
	and     req_no				= @engg_base_req_no )  
	begin  
-- code modified by shafina on 23-jan-2004 to create the generation of controlID  
-- To Generate Control ID/View Names for the newly inserted controls  
--   select @ui_pfx_tmp  = page_prefix  
--   from ep_ui_page_dtl (nolock)  
--   where  customer_name    = @engg_customer_name  
--  and   project_name    = @engg_project_name  
--   and     req_no       = @engg_base_req_no  
--   and   process_name    = @tmp_proc  
--   and   component_name   = @tmp_comp  
--   and   activity_name    = @tmp_act  
--   and   ui_name       = @tmp_ui  
--   and  page_bt_synonym  = '[mainscreen]'  
-- code modified on shafina on 27-May-2004 for PREVIEWENG203ACC_000066  
-- (controlids are getting duplicated in some cases.)  
-- code modified by shafina on 11-Aug-2004 for PREVIEWENG203ACC_000085 - controlid generation logic is changed  
		exec ep_controlid_generation  
			@engg_customer_name  ,	@engg_project_name ,	@engg_base_req_no ,  @tmp_proc    , @tmp_comp   , @tmp_act   ,  
			@tmp_ui     ,			@engg_cont_btsynname,	@tmp_ctl   ,		 @editable    , @visible   , @control_id out  
-- code modified by shafina on 07-feb-2004 To create the generation control_id  
/*  select @control_id_tmp = null  
  
select @control_id_tmp  = max(right(isnull(control_id,'001') , 3))  
from ep_ui_control_dtl (nolock)  
where  customer_name    = @engg_customer_name  
and   project_name    = @engg_project_name  
and     req_no       = @engg_base_req_no  
and   process_name    = @tmp_proc  
and   component_name   = @tmp_comp  
and   activity_name    = @tmp_act  
and   ui_name       = @tmp_ui  
and  isnumeric(right(isnull(control_id,'001') , 3)) = 1  
--   and   page_bt_synonym   = @engg_cont_page_bts  
--   and  section_bt_synonym = @engg_cont_sec_bts  
select @control_id_tmp = right(isnull(@control_id_tmp,'001') , 3)  
select @count   = @control_id_tmp + 1  
-- modified by shafina on 04-feb-2004 to create generation of control id  
if len(@count) = 1  
begin  
select @control_id = isnull(@ui_pfx_tmp,'') + '_' + '00' + @count  
end  
if len(@count) = 2  
begin  
select @control_id = isnull(@ui_pfx_tmp,'') + '_' + '0' + @count  
end  
if len(@count) = 3  
begin  
select @control_id = isnull(@ui_pfx_tmp,'') + '_' + @count  
end  
*/  
-- modified by shafina on 28-jan-2004 to insert view_name  
--   select @view_name = @engg_cont_sec_bts + '_' + @count  
-- to input parameters component prefix and label control are passed as to  
-- common insert sp - Ramachandran.T 25 Dec 2003  
--code added by DNR for getting unique prefix ID on 30/12/2003  
		exec engg_gen_prefix_id 
			@engg_customer_name,	@engg_project_name,		@tmp_comp,		@tmp_act,		@tmp_ui,	@engg_cont_btsynname,		'C',
			6,						@page_prefix_tmp output  
		select	@engg_cont_sequence  = isnull(@engg_cont_sequence,1),  
				@engg_cont_datawidth = isnull(@engg_cont_datawidth,0),  
				@engg_cont_labwidth  = isnull(@engg_cont_labwidth,0)  
 
		select @engg_tab_sequence =  isnull (@engg_tab_sequence ,0)  		
		
		exec  ep_ui_control_dtl_sp_ins  
			@ctxt_language,		@ctxt_ouinstance,  @ctxt_service,		@ctxt_user,				@engg_customer_name,	@engg_project_name,  
			@engg_base_req_no,  @tmp_proc,		   @tmp_comp,			@tmp_act,				@tmp_ui,				@engg_cont_page_bts,    
			@engg_cont_sec_bts, @engg_cont_btsynname,@control_id,  
--            @view_name,  
--@control_id, -- view_name  
			@engg_cont_elem_type,  @engg_cont_vis_length,  @engg_cont_horder,  @engg_cont_vorder,  @engg_cont_sequence,    @engg_cont_datawidth,  
			@engg_cont_labwidth,   @engg_cont_tooltip,     @engg_cont_samp_data,@engg_cont_doc,    @page_prefix_tmp,		'',  
			@label_scale_mode,	   @data_scale_mode,	   @engg_label_class ,  @engg_control_class,@engg_label_image_class ,@engg_control_image_class  ,  
			@engg_tab_sequence ,   @engg_tab_stopforhelp , 1,					@engg_req_no, --chan 
			@user_pref,     --  Added for  PNR2.0_23541    
			@freezecount, --added for PNR2.0_26860  
			@Engg_cont_Ctrlimg,  @Engg_cont_rowspan,		@Engg_cont_colspan, @engg_cont_tempid,  @ctrl_temp_cat,			@ctrl_temp_specific,
			--Ranjitha
			@AccessKey,			 @Icon_class,				@Icon_position,		@Cont_class_ext6,	@engg_dynamicstyle,		@engg_imageasdata,
			@engg_extnreqd, ---Code added for TECH-60451
			@engg_msc_ass_control,--code added for TECH-63527
			@Engg_cont_forresponsive,--Code added for TECH-69624
			@engg_cont_control_format,	--Code Added for the Defect Id TECH-72114
			@ButtonNature,		@InlineStyle,	--Tech-75230
			@m_errorid out  
  
		if @m_errorid <> 0  
			return  
  
		if @Modeflag in ('I','X')
		Begin
			Select	@devicetype		= ''
			Select	@Devicetype		= isnull(devicetype,'')
			from	ep_ui_mst(nolock)
			where	customer_name		= rtrim(@engg_customer_name)
			and		project_name		= rtrim(@engg_project_name)
			and		req_no				= rtrim(@engg_base_req_no)
			and		process_name		= rtrim(@tmp_proc)
			and		component_name		= rtrim(@tmp_comp)
			and		activity_name		= rtrim(@tmp_act)
			and		ui_name				= rtrim(@tmp_ui)

			If isnull(@devicetype,'') = '' 
					Select @phone_in		= null, @tablet_in	= null
			If isnull(@devicetype,'') = 'P' 
					Select @phone_in		= 1, @tablet_in	= null
			If isnull(@devicetype,'') = 'T' 
					Select @phone_in		= null, @tablet_in	= 1
			If isnull(@devicetype,'') = 'B' 
					Select @phone_in		= 1 , @tablet_in	= 1

/* 
			if (@devicetype in ('P', 'B'))
			begin 
	--Exec ep_layout_phone_tablet_ins_sp 
				Exec ep_layout_phone_ins_sp 
					@ctxt_language,		@ctxt_ouinstance,	@ctxt_service,		@ctxt_user,		@tmp_act,		@tmp_comp,		@engg_customer_name,
					@engg_cont_page_bts,@engg_cont_sec_bts, @engg_cont_btsynname,null,			@tmp_proc,		@engg_project_name,@engg_req_no,
					@tmp_ui,			@phone_in,			@tablet_in,			'Control',		null,			@m_errorid
			end

			if (@devicetype in ('T', 'B'))
			begin
				Exec ep_layout_tablet_ins_sp 
					@ctxt_language,			@ctxt_ouinstance,		@ctxt_service,		@ctxt_user,			@tmp_act,		@tmp_comp,
					@engg_customer_name,	@engg_cont_page_bts,	@engg_cont_sec_bts, @engg_cont_btsynname,null,			@tmp_proc,
					@engg_project_name,		@engg_req_no,			@tmp_ui,			@phone_in,			@tablet_in,		'Control',
					null,					@m_errorid
			End  */
		end 

-- start code added BY feroz for ext js --PNR2.0_1790  
		If exists (select 'X' 
		from	es_comp_ctrl_type_mst (nolock)  
		where	customer_name	= @engg_customer_name  
		and		project_name	= @engg_project_name  
		and		req_no			= @engg_base_req_no  
		and		process_name	= @tmp_proc  
		and		component_name  = @tmp_comp  
		and		ctrl_type_name  = @engg_cont_elem_type  
		and		isnull(Is_Extjs_Control, 'N') = 'Y'  
		and		isnull(Extjs_Ctrl_type, '') <> '')  
		begin   
			if not exists ( select 'x'  
			from	ep_ext_js_control_dtl (nolock)  
			where	customer_name	= @engg_customer_name  
			and		project_name	= @engg_project_name  
			and		req_no			= @engg_base_req_no  
			and		process_name	= @tmp_proc  
			and		component_name  = @tmp_comp  
			and		activity_name	= @tmp_act  
			and		ui_name			= @tmp_ui  
			and		page_bt_synonym = @engg_cont_page_bts  
			and		section_bt_synonym = @engg_cont_sec_bts  
			and		control_bt_synonym = @engg_cont_btsynname )  
			begin  
				insert into ep_ext_js_control_dtl (  
					customer_name,		project_name,		 req_no,			process_name,		component_name,		activity_name,		ui_name,   
					page_bt_synonym,	section_bt_synonym,	control_bt_synonym, Extjs_Ctrl_type,	Ctrl_height,  
					ctrl_width,			Control_Class,		RVW_Task,			Callout_Task,		Type_Delay,			Type_Direction,		Fade_Delay,   
					Fade_Direction,		Loop_Count,			sample_data,		wrkreqno,			createdby,			createddate,		modifiedby,    
					modifieddate,		feature_name )  
				select  
					@engg_customer_name, @engg_project_name,@engg_base_req_no,		@tmp_proc,			@tmp_comp ,			@tmp_act ,			@tmp_ui,      
					@engg_cont_page_bts, @engg_cont_sec_bts,@engg_cont_btsynname,   @engg_cont_elem_type,NULL,				NULL,				NULL, 
					NULL,				 NULL,			    NULL,					NULL,				 NULL,				NULL,				NULL,     
					@engg_cont_samp_data,NULL,				@ctxt_user,				getdate(),			@ctxt_user,			getdate(),			@extjs_ctrl_type  
			end   
			else  
			begin  
				update  ep_ext_js_control_dtl  
				set		sample_data	= @engg_cont_samp_data,  
						modifiedby		= @ctxt_user,  
						modifieddate	= getdate()  
				where	customer_name	= @engg_customer_name  
				and		project_name	= @engg_project_name  
				and		req_no			= @engg_base_req_no  
				and		process_name	= @tmp_proc  
				and		component_name  = @tmp_comp  
				and		activity_name	= @tmp_act  
				and		ui_name			= @tmp_ui  
				and		page_bt_synonym = @engg_cont_page_bts  
				and		section_bt_synonym = @engg_cont_sec_bts  
				and		control_bt_synonym = @engg_cont_btsynname  
			end  
		end  
-- enf code added by feroz for ext js --PNR2.0_1790  
	end  
end  
  
-- modified by shafina on 21-jan-2004 to insert into glossry table when modeflag<>'d'  
	if @modeflag <> 'D'  
	begin  
-- modified by vasu date:28-12-2003  
-- to insert control bt synonyms in glossary  
-- modified by shafina on 13-jan-2004 to insert the length of btsynonym  
		declare @btLength engg_rowno  
		select  @btLength = isnull(@engg_cont_vis_length,20)  
-- code modified by shafina on 09-June-2004 for PREVIEWENG203ACC_000072  
		if @engg_cont_vis_length = 0  
			select @btLength = 20  
		if not exists(  select 'x'  
		from	ep_component_glossary_mst (nolock )  
		where	customer_name	= @engg_customer_name  
		and		project_name	= @engg_project_name  
		and		req_no			= @engg_base_req_no  
		and		process_name	= @tmp_proc  
		and		component_name	= @tmp_comp  
		and		bt_synonym_name = @engg_cont_btsynname )  
		begin  
-- code modified by shafina on 24-feb-2004  

			exec ep_generate_caption @engg_cont_btsynname , @cont_bt_caption out  
-- code modified by shafina on 17-June-2004 for PREVIEWENG203ACC_000073  
			exec ep_component_glossary_mst_sp_ins  
				@ctxt_language,		@ctxt_ouinstance,	@ctxt_service,		@ctxt_user,		@engg_customer_name,  
				@engg_project_name,	@engg_base_req_no,  @tmp_proc,			@tmp_comp,		@engg_cont_btsynname,  
				null,				'Char',				@btLength ,			@cont_bt_caption , @engg_cont_btsynname ,  
				'' ,				'U',				'',					'',				1,  
				@engg_req_no, --chan  
				@m_errorid  out  
  
			IF @m_errorid <> 0  
				RETURN  
		end  
  
-- code added by shafina on 18-feb-2004 to insert into traversal table  
		if not exists  ( select 'x'  
		from	ep_ui_traversal_dtl (nolock)  
		where	customer_name	= @engg_customer_name  
		and		project_name	= @engg_project_name  
		and		req_no			= @engg_base_req_no  
		and		process_name	= @tmp_proc  
		and		component_name  = @tmp_comp  
		and		activity_name	= @tmp_act  
		and		ui_name			= @tmp_ui  
		and		page_bt_synonym = @engg_cont_page_bts  
		and		section_bt_synonym = @engg_cont_sec_bts  
		and		control_bt_synonym = @engg_cont_btsynname  )  
		begin  
-- Code modified by Chanheetha N A For the issue :PNR2.0_9027 on 20-Jun-2006  
			Select  @traversal_ctl			= base_ctrl_type,  
					@traversal_help_req		= help_req,  
					@traversal_Label_Link_req= Label_Link --code Added for the Bug ID:PNR2.0_36309  
			from    es_comp_ctrl_type_mst_vw (nolock)  
			where	customer_name   = @engg_customer_name  
			and		project_name    = @engg_project_name  
			and		process_name    = @tmp_proc  
			and		component_name  = @tmp_comp  
			and		ctrl_type_name  = @engg_cont_elem_type  
			and		req_no			= @engg_base_req_no  
			and		base_ctrl_type in ('Edit','Link','DataHyperlink','CheckBox','Combo','RadioButton') --code Added for the Bug ID:PNR2.0_36309  
-- Code modified by Chanheetha N A For the issue :PNR2.0_9027 on 20-Jun-2006  
-- code added by shafina on 19-july-2004 to insert help task into traversal table.  
-- code modified by shafina on 27-Aug-2004 for PREVIEWENG203ACC_000045 (to insert link task into traversal table for base ctrl type link even if help req = 'Y'.)  
-- Code modified by Chanheetha N A For the issue :PNR2.0_9027 on 20-Jun-2006  
--   if @tmp_ctl = 'Link'  
			if @traversal_ctl in ('Link','DataHyperlink') -- code modified for the Bug ID: PNR2.0_33805  
-- Code modified by Chanheetha N A For the issue :PNR2.0_9027 on 20-Jun-2006  
			begin  
				exec ep_ui_traversal_dtl_sp_ins  
					@ctxt_language,		@ctxt_ouinstance,		@ctxt_service,		@ctxt_user,		@engg_customer_name,		@engg_project_name, 
					@engg_base_req_no,  @tmp_proc,				@tmp_comp,			@tmp_act,		@tmp_ui,					@engg_cont_page_bts,  
					@engg_cont_sec_bts, @engg_cont_btsynname,	'Lnk',				'',				'',							'', 
					'' ,				1,						@engg_req_no ,		'',				'',							'', 
					'',					@m_errorid out --chan  
				if @m_errorid <> 0  
					return  
			end  
-- Code modified by Chanheetha N A For the issue :PNR2.0_9027 on 20-Jun-2006  
--code Added for the Bug ID:PNR2.0_36309 starts  
			if @traversal_ctl in ('Edit','CheckBox','Combo','RadioButton') and isnull(@traversal_Label_Link_req,'n') = 'y'  
			begin  
				exec ep_ui_traversal_dtl_sp_ins  
					@ctxt_language,		@ctxt_ouinstance,	@ctxt_service,		@ctxt_user,		@engg_customer_name,		@engg_project_name, 
					@engg_base_req_no,  @tmp_proc,			@tmp_comp,			@tmp_act,		@tmp_ui,					@engg_cont_page_bts,  
					@engg_cont_sec_bts, @engg_cont_btsynname,'Lnk',				'',				'',							'', 
					'' ,				1,					@engg_req_no ,		'',				'',							'',
					'',					@m_errorid out   
				if @m_errorid <> 0  
					return  
			end  
--code Added for the Bug ID:PNR2.0_36309 ends  
--   if @help_req = 'y'  
-- Code modified by Anuradha M for the Bug : PNR2.0_9925 on 18-Aug-2006  
			if (@traversal_help_req = 'y') and ( @traversal_ctl <> 'Link' )  
-- Code modified by Chanheetha N A For the issue :PNR2.0_9027 on 20-Jun-2006  
			begin  
				exec ep_ui_traversal_dtl_sp_ins  
					@ctxt_language,  @ctxt_ouinstance,	@ctxt_service,  @ctxt_user, @engg_customer_name,@engg_project_name, @engg_base_req_no, 
					@tmp_proc,		 @tmp_comp,			@tmp_act,		@tmp_ui,    @engg_cont_page_bts,@engg_cont_sec_bts, @engg_cont_btsynname,
					'Hlp',			'',					'',				'',			'',					1,					@engg_req_no ,
					'',				'',					'',				'',			@m_errorid out --chan  
				if @m_errorid <> 0  
				return  
			end  
		end  
--code modified by shafina on 27-jan-2004 to insert into flow_br_mst table  
		exec ep_task_generation  
			@ctxt_language,    @ctxt_ouinstance,    @ctxt_service,  @ctxt_user,     @engg_customer_name,    @engg_project_name,  
			@engg_base_req_no,  @tmp_proc,			@tmp_comp,		@tmp_act,		@tmp_ui,				@engg_cont_page_bts,  
			@engg_cont_sec_bts, @engg_cont_btsynname, '',			@tmp_ctl,		@event_req,				@help_req,  
			@zoom_req,			@editable,			'CONTROL',		@report_req,	@engg_req_no, -- code modified by Anuradha on 06-Nov-2006 for the Bug ID :: PNR2.0_10832  
			@m_errorid output  
			 
-- Code commented by Gowrisankar M for PNR2.0_22165 on 07-May-2009 - Begins  
--   -- Added by Jeya PNR2.0_20553  
--   exec ep_ui_contextmenu_task_dtl_SP_INS  
--   @ctxt_language,  @ctxt_ouinstance, @ctxt_service,   @ctxt_user,  
--   @engg_customer_name, @engg_project_name, @engg_base_req_no,  @tmp_proc,  
--   @tmp_comp,  @tmp_act,  @tmp_ui,   @engg_cont_page_bts,  
--   @engg_req_no,  @m_errorid output  
--  
--   -- Added by Jeya PNR2.0_20553  
-- Code commented by Gowrisankar M for PNR2.0_22165 on 07-May-2009 - Begins  

--added by Ramanujam on 1/3/2006--starts  
		if @tmp_ctl  = 'Edit' and @spin_req = 'y'   
		begin  
			exec  ep_create_Spin  
				@ctxt_ouinstance,	@ctxt_user,		@CTXT_LANGUAGE,  @ctxt_service, @engg_customer_name, @engg_project_name,  
				@tmp_proc,			@tmp_comp,		@tmp_act,		 @tmp_ui,		@engg_base_req_no,	 @engg_cont_page_bts,  
				@engg_cont_sec_bts, @modeflag,		@engg_cont_btsynname,@engg_cont_elem_type,@engg_req_no,@m_errorid out --chan  
  
			if @m_errorid <> 0  
				return  
		end  	
	/** 
	 For Inserting Hidden Controls for the Control having Edit Mask Feature. 
	 Code added for the Defect id: TECH-20326 starts. */
		If	exists (select 'x'
		from	ep_ui_control_dtl (nolock)
		where	customer_name		= @engg_customer_name
		and		project_name		= @engg_project_name
		and		process_name		= @tmp_proc
		and		component_name		= @tmp_comp
		and		activity_name		= @tmp_act
		and		ui_name				= @tmp_ui
		and		page_bt_synonym		= '[mainscreen]'
		and		section_bt_synonym	= 'PrjhdnSection'
		and		control_bt_synonym	=  'h'+ @engg_cont_btsynname + '_rd')
		or		(isnull(@tmp_ctl,'')= 'Edit')		
		Begin
			Exec ep_editmask_ins		@ctxt_language,				@ctxt_ouinstance,		@ctxt_service,			@ctxt_user,			@engg_customer_name,
				@engg_project_name,		@tmp_proc,					@tmp_comp,				@tmp_act,				@tmp_ui,			@engg_cont_page_bts,
				@engg_cont_sec_bts,		@engg_cont_btsynname,		'',						@engg_cont_elem_type,	'Hdr',				@engg_base_req_no,
				@m_errorid
		End
	/** Code added for the Defect id: TECH-20326 ends.*/  
--added by Ramanujam on 1/3/2006 --Ends  
	end  
/*code added by vijay on 29/12/03 for inserting into ep_action_mst*/  
	If @modeflag = 'D'  and isnull(@del_flag, 'T') = 'T' -- Code Modified for PNR2.0_32228 Starts 
	and isnull(@del_flag_ph,'T') = 'T' 
	begin  
---added by Ramanujam Starts 09/3/2006    
		if @tmp_ctl  = 'Edit' and @spin_req = 'y'  
		begin  --edit  
			declare @comp_pfx_del  engg_name,  
		--@ui_pfx_del   engg_name,  
					@ctrl_pfx_del  engg_name  
--@bt_syn_caption  engg_name   
			select	@ctrl_pfx_del  = control_prefix  
			from	ep_ui_control_dtl (nolock)  
			where	customer_name   = @engg_customer_name  
			and		project_name	= @engg_project_name  
			and		process_name	= @tmp_proc  
			and		component_name  = @tmp_comp  
			and		activity_name   = @tmp_act  
			and		ui_name			= @tmp_ui  
			and		page_bt_synonym = @engg_cont_page_bts  
			and		section_bt_synonym  = 'hdnspin_'+ @page_prefix_sec + '_sec'--@engg_sec_btsynname  
			and		control_bt_synonym  = 'hdn_'+ @engg_cont_btsynname + '_SPIN'  
--PNR2.0_13748  
			delete from ep_ui_state_control_dtl  
			where	customer_name	   = @engg_customer_name  
			and		project_name       = @engg_project_name  
			and		process_name       = @tmp_proc  
			and		component_name     = @tmp_comp  
			and		activity_name      = @tmp_act  
			and		ui_name            = @tmp_ui  
			and		page_bt_synonym    = @engg_cont_page_bts  
			and		section_bt_synonym = 'hdnspin_'+@page_prefix_sec+'_sec'  
			and		control_bt_synonym = 'hdn_'+ @engg_cont_btsynname + '_SPIN'  
  
			delete from ep_ui_control_dtl  
			where	customer_name		= @engg_customer_name  
			and		project_name		= @engg_project_name  
			and		process_name		= @tmp_proc  
			and		component_name		= @tmp_comp  
			and		activity_name		= @tmp_act  
			and		ui_name				= @tmp_ui  
			and		page_bt_synonym		= @engg_cont_page_bts  
			and		section_bt_synonym  = 'hdnspin_'+@page_prefix_sec+'_sec'  
			and		control_type		= 'HiddenEdit'  
			and		control_bt_synonym	= 'hdn_'+ @engg_cont_btsynname + '_SPIN'  

--PNR2.0_13748  
			delete from ep_ui_state_control_dtl  
			where	customer_name      = @engg_customer_name  
			and		project_name        = @engg_project_name  
			and		process_name        = @tmp_proc  
			and		component_name      = @tmp_comp  
			and		activity_name       = @tmp_act  
			and		ui_name             = @tmp_ui  
			and		page_bt_synonym     = @engg_cont_page_bts  
			and		section_bt_synonym  = @engg_cont_sec_bts  
			and		control_bt_synonym  = @engg_cont_btsynname  
			and		req_no              = @engg_base_req_no  

			delete from ep_ui_control_dtl  
			where	customer_name		= @engg_customer_name  
			and		project_name		= @engg_project_name  
			and		process_name		= @tmp_proc  
			and		component_name		= @tmp_comp  
			and		activity_name		= @tmp_act  
			and		ui_name				= @tmp_ui  
			and		page_bt_synonym		= @engg_cont_page_bts  
			and		section_bt_synonym  = @engg_cont_sec_bts  
			and		control_bt_synonym  = @engg_cont_btsynname  
			and		control_type		= @engg_cont_elem_type  
			and     req_no				= @engg_base_req_no  
  
			delete	ep_Spin_Control_dtl  
			where	customer_name   = @engg_customer_name  
			and		project_name	= @engg_project_name  
			and		process_name	= @tmp_proc  
			and		component_name  = @tmp_comp  
			and		activity_name   = @tmp_act  
			and		ui_name			= @tmp_ui  
			and		page_bt_synonym = @engg_cont_page_bts  
			and		section_bt_synonym= @engg_cont_sec_bts  
			and		control_bt_synonym= @engg_cont_btsynname  
			and		control_type	= @engg_cont_elem_type  
  
--Code Modified by chanheetha N A for the call id : PNR2.0_10930  
			if not exists ( select 'x'  
			from    ep_ui_control_dtl (nolock) 
			where	customer_name		= @engg_customer_name  
			and		project_name		= @engg_project_name  
			and		process_name		= @tmp_proc  
			and		component_name		= @tmp_comp  
			and		activity_name		= @tmp_act  
			and		ui_name				= @tmp_ui  
			and		page_bt_synonym		= @engg_cont_page_bts  
			and		section_bt_synonym  = 'hdnspin_'+@page_prefix_sec+'_sec' )  
			begin  
--PNR2.0_13748  
				delete from ep_ui_state_section_dtl 
				where	customer_name		= @engg_customer_name  
				and		project_name		= @engg_project_name  
				and		process_name		= @tmp_proc  
				and		component_name		= @tmp_comp  
				and		activity_name		= @tmp_act  
				and		ui_name				= @tmp_ui  
				and		page_bt_synonym		= @engg_cont_page_bts  
				and		section_bt_synonym  = 'hdnspin_'+@page_prefix_sec+'_sec'  
  
				delete from ep_ui_section_dtl  
				where	customer_name		= @engg_customer_name  
				and		project_name		= @engg_project_name  
				and		process_name		= @tmp_proc  
				and		component_name		= @tmp_comp  
				and		activity_name		= @tmp_act  
				and		ui_name				= @tmp_ui  
				and		page_bt_synonym		= @engg_cont_page_bts  
				and		section_bt_synonym  = 'hdnspin_'+@page_prefix_sec+'_sec'  
			end  
--Code Modified by chanheetha N A for the call id : PNR2.0_10930  
			select	@comp_pfx_del   = current_value  
			from	es_comp_param_mst (nolock)  
			where	customer_name   = @engg_customer_name  
			and		project_name	= @engg_project_name  
			and		process_name	= @tmp_proc  
			and		component_name  = @tmp_comp  
			and		param_category  = 'compprefix'  
  
			delete	EP_ACTION_MST  
			where	customer_name   = @engg_customer_name  
			and		project_name	= @engg_project_name  
			and		process_name	= @tmp_proc  
			and		component_name  = @tmp_comp  
			and		activity_name   = @tmp_act  
			and		ui_name			= @tmp_ui  
			and		page_bt_synonym = @engg_cont_page_bts  
			and		task_name		= @comp_pfx_del + '_' + @page_prefix_sec + @ctrl_pfx_del+ 'Ui'  
  
			delete ep_action_mst_lng_extn  
			where  customer_name	= @engg_customer_name  
			and  project_name		= @engg_project_name  
			and  process_name		= @tmp_proc  
			and  component_name		= @tmp_comp  
			and  activity_name		= @tmp_act  
			and  ui_name			= @tmp_ui  
			and  page_bt_synonym	= @engg_cont_page_bts  
			and  task_name			= @comp_pfx_del + '_' + @page_prefix_sec + @ctrl_pfx_del+ 'Ui'  
  
			declare	@t1 engg_code  
			select	@t1 = 0  
			update	ep_ui_control_dtl set 
					vorder	= @t1 ,  
					@t1		= @t1+1  
			where  customer_name    = @engg_customer_name  
			and   project_name		= @engg_project_name  
			and   process_name		= @tmp_proc  
			and   component_name	= @tmp_comp  
			and   activity_name		= @tmp_act  
			and   ui_name			= @tmp_ui  
			and   page_bt_synonym   = @engg_cont_page_bts  
			and  section_bt_synonym = 'hdnspin_'+@page_prefix_sec+'_sec'  
			and  control_type		= 'HiddenEdit'  
---added by Ramanujam ends 09/3/2006  
		end --edit  
  
		If exists(  Select 'A' 
		from	ep_ui_control_dtl (nolock)  
		where	customer_name		= @engg_customer_name  
		and		project_name		= @engg_project_name  
		and		process_name		= @tmp_proc  
		and		component_name		= @tmp_comp  
		and		activity_name		= @tmp_act  
		and		ui_name				= @tmp_ui  
		and		page_bt_synonym		= @engg_cont_page_bts  
		and		section_bt_synonym  = @engg_cont_sec_bts  
		and		control_bt_synonym  = @engg_cont_btsynname  
		and     req_no				= @engg_base_req_no )  
		begin  
-- code modified by shafina on 21-April-2004 for PREVIEWENG203ACC_000045  
			declare task_del_cur insensitive cursor  for 
			select task_name  
			from	ep_action_mst a(nolock),  
					ep_ui_control_dtl b(nolock)  
			where	a.customer_name		=	@engg_customer_name  
			and		a.project_name		=	@engg_project_name  
			and		a.req_no			=	@engg_base_req_no  
			and		a.process_name		=	@tmp_proc  
			and		a.component_name	=	@tmp_comp  
			and		a.activity_name		=	@tmp_act  
			and		a.ui_name			=	@tmp_ui  
			and		a.page_bt_synonym	=	@engg_cont_page_bts  
			and		a.customer_name		=	b.customer_name  
			and		a.project_name		=	b.project_name  
			and		a.req_no			=	b.req_no  
			and		a.process_name		=	b.process_name  
			and		a.component_name	=	b.component_name  
			and		a.activity_name		=	b.activity_name  
			and		a.ui_name			=	b.ui_name  
			and		a.page_bt_synonym	=	b.page_bt_synonym  
			and		b.section_bt_synonym=	@engg_cont_sec_bts  
			and		b.control_bt_synonym=	@engg_cont_btsynname  
			and		a.primary_control_bts=	@engg_cont_btsynname   
			open task_del_cur    
			while (1=1)  
			begin  
				fetch next from task_del_cur  into @task_name  
				if @@fetch_status <> 0  
					break  
				if isnull(@task_name,'') <> ''  
				begin  
					if exists   (select 'x' 
					from	ep_flowbr_mst (nolock)  
					where	customer_name	=   @engg_customer_name  
					and		project_name    =   @engg_project_name  
					and		req_no          =   @engg_base_req_no  
					and		process_name    =	@tmp_proc  
					and		component_name	=	@tmp_comp  
					and		activity_name   =	@tmp_act  
					and		ui_name			=	@tmp_ui  
					and		page_bt_synonym =	@engg_cont_page_bts  
					and		task_name       =   @task_name  )  
					begin  
						delete	ep_flowbr_mst  
						where	customer_name	=   @engg_customer_name  
						and		project_name    =   @engg_project_name  
						and		req_no          =   @engg_base_req_no  
						and		process_name    =   @tmp_proc  
						and		component_name  =   @tmp_comp  
						and		activity_name   =   @tmp_act  
						and		ui_name			=   @tmp_ui  
						and		page_bt_synonym =   @engg_cont_page_bts  
						and		task_name       =   @task_name  
					end  
					if exists   (select 'x' from  ep_action_section_map (nolock)  
					where	customer_name	=   @engg_customer_name  
					and		project_name    =   @engg_project_name  
					and		req_no          =   @engg_base_req_no  
					and		process_name    =   @tmp_proc  
					and		component_name  =   @tmp_comp  
					and		activity_name   =   @tmp_act  
					and		ui_name			=   @tmp_ui  
					and		page_bt_synonym =   @engg_cont_page_bts  
					and		task_name       =   @task_name  )  
					begin  
						delete	ep_action_section_map  
						where	customer_name	=	@engg_customer_name  
						and		project_name    =	@engg_project_name  
						and		req_no          =	@engg_base_req_no  
						and		process_name    =	@tmp_proc  
						and		component_name  =	@tmp_comp  
						and		activity_name   =	@tmp_act  
						and		ui_name			=	@tmp_ui  
						and		page_bt_synonym =	@engg_cont_page_bts  
						and		task_name       =   @task_name  
					end  

					exec ep_action_mst_sp_del  
						@ctxt_language,		@ctxt_ouinstance,	@ctxt_service,		@ctxt_user,		@engg_customer_name,			  @engg_project_name,  
						@engg_base_req_no,  @tmp_proc,			@tmp_comp,			@tmp_act,		@tmp_ui,	 @engg_cont_page_bts, @task_name,
						@m_errorid output  
  
					if @m_errorid <> 0  
					begin  
						close task_del_cur  
						deallocate task_del_cur  
						return  
					end  
				end  
			end  
			close task_del_cur  
			deallocate task_del_cur  
  
			delete  from	ep_ui_traversal_dtl  
			where	customer_name		= @engg_customer_name  
			and		project_name		= @engg_project_name  
			and		req_no				= @engg_base_req_no  
			and		process_name		= @tmp_proc  
			and		component_name		= @tmp_comp  
			and		activity_name		= @tmp_act  
			and		ui_name				= @tmp_ui  
			and		page_bt_synonym		= @engg_cont_page_bts  
			and		section_bt_synonym	= @engg_cont_sec_bts  
			and		control_bt_synonym	= @engg_cont_btsynname  
			and		isnull(linked_component,'') = ''  
			and		isnull(linked_activity,'') = ''  
			and		isnull(linked_ui,'')  = ''  
	--code modified for bugid : PNR2.0_14066  
			delete  from	ep_ui_state_control_dtl  
			where	customer_name		= @engg_customer_name  
			AND		project_name		= @engg_project_name  
			AND		process_name		= @tmp_proc  
			AND		component_name		= @tmp_comp  
			AND		activity_name		= @tmp_act  
			AND		ui_name				= @tmp_ui  
			AND		page_bt_synonym		= @engg_cont_page_bts  
			AND		section_bt_synonym  = @engg_cont_sec_bts  
			and		control_bt_synonym	= @engg_cont_btsynname  
   
			exec  ep_ui_control_dtl_sp_del  
				@ctxt_language,  @ctxt_ouinstance,  @ctxt_service,  @ctxt_user,  @engg_customer_name,  @engg_project_name,  @engg_base_req_no,  
				@tmp_proc,		 @tmp_comp,			@tmp_act,		@tmp_ui,	 @engg_cont_page_bts,  @engg_cont_sec_bts,  @engg_cont_btsynname,  
				@m_errorid out  
  
		-- start added by feroz for ext js --PNR2.0_1790  
			exec ep_ext_js_control_dtl_sp_del  
				@ctxt_language,  @ctxt_ouinstance,  @ctxt_service,  @ctxt_user,  @engg_customer_name,  @engg_project_name,  @engg_base_req_no,  
				@tmp_proc,		 @tmp_comp,			@tmp_act,		@tmp_ui,	 @engg_cont_page_bts,  @engg_cont_sec_bts,  @engg_cont_btsynname,  
				@m_errorid out  
  
			Delete	from ep_layout_ezeeview_spparamlist  
			where	customer_name	= @engg_customer_name  
			and		project_name	= @engg_project_name  
			and		req_no			= @engg_base_req_no  
			and		process_name	= @tmp_proc  
			and		component_name  = @tmp_comp  
			and		activity_name	= @tmp_act  
			and		ui_name			= @tmp_ui  
			and		Mapped_Control	= @engg_cont_btsynname  
-- end added by feroz for ext js --PNR2.0_1790  
-- modified by shafina on 07-feb-2004 to check for existence of btsynonym  
-- modified by shafina on 09-Apr-2004 for PREVIEWENG203ACC_000013  
/*   declare @cnt int  
select @cnt = 0  
select @cnt = count('x')  
from ep_ui_page_dtl (nolock)  
where customer_name = @engg_customer_name  
and  project_name = @engg_project_name  
and  page_bt_synonym = @engg_cont_btsynname  
select @cnt = @cnt +  (  select count('x')  
from ep_ui_section_dtl (nolock)  
where customer_name = @engg_customer_name  
and  project_name = @engg_project_name  
and  section_bt_synonym = @engg_cont_btsynname  )   
select @cnt = @cnt +  (  select count('x')  
from ep_ui_control_dtl (nolock)  
where customer_name = @engg_customer_name  
and  project_name = @engg_project_name  
and  control_bt_synonym = @engg_cont_btsynname  )  
 select @cnt = @cnt +  (  select count('x')  
from ep_ui_grid_dtl (nolock)  
where customer_name = @engg_customer_name  
and  project_name = @engg_project_name  
and  column_bt_synonym = @engg_cont_btsynname  )  
if @cnt  = 0  
begin  
if exists  (select 'x'  
from ep_component_glossary_mst (nolock)  
where  customer_name =   @engg_customer_name  
and    project_name    =   @engg_project_name  
and    req_no         =   @engg_base_req_no  
and  process_name =  @tmp_proc  
and  component_name =  @tmp_comp  
and    bt_synonym_name = @engg_cont_btsynname)  
begin  
exec ep_component_glossary_mst_sp_del  
@ctxt_language,  @ctxt_ouinstance,  @ctxt_service,  @ctxt_user,  @engg_customer_name,  @engg_project_name,  @engg_base_req_no,  @tmp_proc,  
@tmp_comp,  @engg_cont_btsynname,  @m_errorid out   
if @m_errorid <> 0  
return  
end  
end*/  
			end  
		end  

-- code added by Feroz for Ext js --PNR2.0_1790  
		if @modeflag <> 'S'  
		begin  
			if exists ( select 'x'  
			from    es_comp_ctrl_type_mst_vw (nolock)  
			where   customer_name   = @engg_customer_name  
			and		project_name    = @engg_project_name  
			and		process_name    = @tmp_proc  
			and		component_name  = @tmp_comp  
			and		ctrl_type_name  = @engg_cont_elem_type  
			and		req_no			= @engg_base_req_no  
			and		Is_Extjs_Control= 'y')  
			begin  
				select  @extjs_ctrl_type = Extjs_Ctrl_type  
				from    es_comp_ctrl_type_mst_vw (nolock)  
				where   customer_name   = @engg_customer_name  
				and		project_name    = @engg_project_name  
				and		process_name    = @tmp_proc  
				and		component_name  = @tmp_comp  
				and		ctrl_type_name  = @engg_cont_elem_type  
				and		req_no			= @engg_base_req_no  
				and		is_extjs_control= 'y'  
  
				if len(@engg_cont_btsynname) > 25  
				begin  
					select @msg  = 'Length of Control BT Synonym should not be greater than 25 for ExtJs Control at Row no:' + convert(char(5), @fprowno)  
					exec engg_error_sp 'en_layout_sp_savsecscml',  
						4,			@msg,		@ctxt_language,			@ctxt_ouinstance,	@ctxt_service,		@ctxt_user,  
						'',			'',			'',						'',					@m_errorid  output  
					return  
				end
				if @modeflag in ('U', 'Y')  
				Begin  
					if  @tmp_control_type <> @engg_cont_elem_type  
					begin  
						select @msg = 'Control Type cannot be updated for extjs control'  
						exec engg_error_sp		'engg_layout_sp_savctlcnml',  
							9,			@msg,			@ctxt_language,			@ctxt_ouinstance,			@ctxt_service,			@ctxt_user,	
							'',			'',				'',						'',							@m_errorid out  
						if @m_errorid <> 0  
							return  
					end  
				End  
  
				if @extjs_ctrl_type in ('TextType Writer', 'Marquee Ticker', 'EMail', 'Bar Code')  
				begin  
					if exists  (select 'X' 
					from	ep_ext_js_control_dtl (nolock)  
					where	customer_name		= @engg_customer_name  
					and		project_name		= @engg_project_name  
					and		process_name		= @tmp_proc  
					and		component_name		= @tmp_comp  
					and		activity_name		= @tmp_act  
					and		ui_name				= @tmp_ui  
					and		page_bt_synonym		= @engg_cont_page_bts  
					and		section_bt_synonym	= @engg_cont_sec_bts  
					and		control_bt_synonym	= @engg_cont_btsynname  
					and		feature_name		= @extjs_ctrl_type  )  
					begin  
						update  ep_ext_js_control_dtl set  
								sample_Data		= @engg_cont_samp_data  
						where	customer_name	= @engg_customer_name  
						and		project_name	= @engg_project_name  
						and		process_name	= @tmp_proc  
						and		component_name	= @tmp_comp  
						and		activity_name	= @tmp_act  
						and		ui_name			= @tmp_ui  
						and		page_bt_synonym = @engg_cont_page_bts  
						and		section_bt_synonym= @engg_cont_sec_bts  
						and		control_bt_synonym= @engg_cont_btsynname  
						and		feature_name	= @extjs_ctrl_type  
					end  
					exec ep_create_extnjs_controls_sp  
						@ctxt_ouinstance,  @ctxt_user,  @ctxt_language,  @ctxt_service,  @engg_customer_name,  @engg_project_name,  @tmp_proc,  
						@tmp_comp,		   @tmp_act,	@tmp_ui,		 @engg_base_req_no,@engg_cont_page_bts,@engg_cont_sec_bts,  @engg_cont_btsynname,  
						@engg_cont_elem_type, @engg_cont_samp_data,		 @extjs_ctrl_type,  @modeflag,			@engg_req_no,		@m_errorid output  
				end  
			end  
		end  
-- code added by Feroz for Ext js --PNR2.0_1790 
---QlikLink Starts
--Check if the Length is greater that 20
		if len(@engg_cont_btsynname) > 20 and @Qliklink = 'Y'  
		begin  
			Raiserror( 'Length of Control BT Synonym should not be greater than 20 for QlikLink control at Row no: %i' ,16,1,@fprowno)  
			return  
		end  

		Select	@QlikLink_pre		= QlikLink
		from	es_comp_ctrl_type_mst (nolock)
		where	customer_name		= @engg_customer_name  
		and		project_name		= @engg_project_name  
		and		process_name		= @tmp_proc  
		and		component_name		= @tmp_comp  
		and		ctrl_type_name		= @tmp_control_type

		Select	@max_horder			= max(isnull(Horder,0))+1
		from	ep_ui_control_dtl (nolock)
		where	customer_name		= @engg_customer_name  
		and		project_name		= @engg_project_name  
		and		process_name		= @tmp_proc  
		and		component_name		= @tmp_comp  
		and		activity_name		= @tmp_act  
		and		ui_name				= @tmp_ui  
		and		page_bt_synonym		= '[mainscreen]'  
		and		section_bt_Synonym	= 'PrjhdnSection'

-- If QlikLink is deleted
		if @modeflag = 'D'
		Begin
			If exists (	Select 'X' from ep_ui_control_dtl(nolock)
			where	customer_name		= @engg_customer_name  
			and		project_name		= @engg_project_name  
			and		process_name		= @tmp_proc  
			and		component_name		= @tmp_comp  
			and		activity_name		= @tmp_act  
			and		ui_name				= @tmp_ui  
			and		page_bt_synonym		= @engg_cont_page_bts  
			and		section_bt_synonym	= @engg_cont_sec_bts  
			and		control_bt_synonym	= @engg_cont_btsynname
			and		@QlikLink			= 'Y')
			Begin
				Select	@appid				= isnull(propertycontrol,'')
				from	ep_ui_control_association_map(nolock)
				where	customer_name		= @engg_customer_name  
				and		project_name		= @engg_project_name  
				and		process_name		= @tmp_proc  
				and		component_name		= @tmp_comp  
				and		activity_name		= @tmp_act  
				and		ui_name				= @tmp_ui  
				and		page_bt_synonym		= @engg_cont_page_bts  
				and		section_bt_synonym	= @engg_cont_sec_bts  
				and		control_id			= @control_id 
				and		propertyname		= 'AppCtrl'
			
				Select	@sheetid			= isnull(propertycontrol,'')
				from	ep_ui_control_association_map(nolock)
				where	customer_name		= @engg_customer_name  
				and		project_name		= @engg_project_name  
				and		process_name		= @tmp_proc  
				and		component_name		= @tmp_comp  
				and		activity_name		= @tmp_act  
				and		ui_name				= @tmp_ui  
				and		page_bt_synonym		= @engg_cont_page_bts  
				and		section_bt_synonym	= @engg_cont_sec_bts  
				and		control_id			= @control_id 
				and		propertyname		= 'SheetCtrl'

				Delete from ep_ui_control_association_map
				where	customer_name		= @engg_customer_name  
				and		project_name		= @engg_project_name  
				and		process_name		= @tmp_proc  
				and		component_name		= @tmp_comp  
				and		activity_name		= @tmp_act  
				and		ui_name				= @tmp_ui  
				and		page_bt_synonym		= @engg_cont_page_bts  
				and		section_bt_synonym	= @engg_cont_sec_bts  
				and		control_id			= @control_id 
		
				Delete from ep_ui_control_dtl
				where	customer_name		= @engg_customer_name  
				and		project_name		= @engg_project_name  
				and		process_name		= @tmp_proc  
				and		component_name		= @tmp_comp  
				and		activity_name		= @tmp_act  
				and		ui_name				= @tmp_ui  
				and		page_bt_synonym		= '[mainscreen]'  
				and		section_bt_synonym	= 'PrjhdnSection'
				and		control_bt_synonym  in (@appid, @sheetid)			
			End
		End
		
-- If QlikLink is Updated
		If @modeflag in ('U','Y')
		Begin
			If exists (	Select 'X' from ep_ui_control_dtl(nolock)
			where	customer_name		= @engg_customer_name  
			and		project_name		= @engg_project_name  
			and		process_name		= @tmp_proc  
			and		component_name		= @tmp_comp  
			and		activity_name		= @tmp_act  
			and		ui_name				= @tmp_ui  
			and		page_bt_synonym		= @engg_cont_page_bts  
			and		section_bt_synonym	= @engg_cont_sec_bts  
			and		control_bt_synonym	= @engg_cont_btsynname
			and		@QlikLink_pre		= 'Y'
			and		@QlikLink			<> 'Y')
			Begin
	
				Select	@appid				= isnull(propertycontrol,'')
				from	ep_ui_control_association_map(nolock)
				where	customer_name		= @engg_customer_name  
				and		project_name		= @engg_project_name  
				and		process_name		= @tmp_proc  
				and		component_name		= @tmp_comp  
				and		activity_name		= @tmp_act  
				and		ui_name				= @tmp_ui  
				and		page_bt_synonym		= @engg_cont_page_bts  
				and		section_bt_synonym	= @engg_cont_sec_bts  
				and		control_id			= @tmp_cotrol_id 
				and		propertyname		= 'AppCtrl'

				Select	@sheetid			= isnull(propertycontrol,'')
				from	ep_ui_control_association_map(nolock)
				where	customer_name		= @engg_customer_name  
				and		project_name		= @engg_project_name  
				and		process_name		= @tmp_proc  
				and		component_name		= @tmp_comp  
				and		activity_name		= @tmp_act  
				and		ui_name				= @tmp_ui  
				and		page_bt_synonym		= @engg_cont_page_bts  
				and		section_bt_synonym	= @engg_cont_sec_bts  
				and		control_id			= @tmp_cotrol_id 
				and		propertyname		= 'SheetCtrl'
		
				Delete from ep_ui_control_association_map
				where	customer_name		= @engg_customer_name  
				and		project_name		= @engg_project_name  
				and		process_name		= @tmp_proc  
				and		component_name		= @tmp_comp  
				and		activity_name		= @tmp_act  
				and		ui_name				= @tmp_ui  
				and		page_bt_Synonym		= @engg_cont_page_bts  
				and		section_bt_synonym	= @engg_cont_sec_bts  
				and		control_id			= @tmp_cotrol_id 
	
				Delete from ep_ui_control_dtl
				where	customer_name		= @engg_customer_name  
				and		project_name		= @engg_project_name  
				and		process_name		= @tmp_proc  
				and		component_name		= @tmp_comp  
				and		activity_name		= @tmp_act  
				and		ui_name				= @tmp_ui  
				and		page_bt_synonym		= '[mainscreen]'  
				and		section_bt_synonym	= 'PrjhdnSection'
				and		control_bt_synonym  in (@appid, @sheetid)
			End
		End
		If exists (	Select 'X' from ep_ui_control_dtl(nolock)
		where	customer_name		= @engg_customer_name  
		and		project_name		= @engg_project_name  
		and		process_name		= @tmp_proc  
		and		component_name		= @tmp_comp  
		and		activity_name		= @tmp_act  
		and		ui_name				= @tmp_ui  
		and		page_bt_synonym		= @engg_cont_page_bts  
		and		section_bt_synonym	= @engg_cont_sec_bts  
		and		control_bt_synonym	= @engg_cont_btsynname
		and		@QlikLink_pre		<> 'Y'
		and		@QlikLink			= 'Y'
		and		@modeflag			in ('Y','U'))
		or		@modeflag  in ('I','X') and @QlikLink = 'Y'		 
		Begin 
			Select @len_app			= len(@engg_cont_btsynname)		
			Select @len_sht			= len(@engg_cont_btsynname)		
			--- create a unique AppCtrl			
			WHILE (	@len_app > 0 )
			Begin
				Select @appid	= @engg_cont_btsynname + '_aid'					
				If not exists (	Select 'X' from ep_ui_control_dtl(nolock)
				where	customer_name		= @engg_customer_name  
				and		project_name		= @engg_project_name  
				and		process_name		= @tmp_proc  
				and		component_name		= @tmp_comp  
				and		activity_name		= @tmp_act  
				and		ui_name				= @tmp_ui  
				and		control_bt_synonym	= @appid)	
				Begin
					Break
				End
				Else
				Begin
					Select @cont_name = substring(@engg_cont_btsynname, 1,@len_app - 1)
					Select @len_app	  = len(@cont_name)
				End
			End
		--- create a unique SheetCtrl
			WHILE (	@len_sht > 0 )
			Begin
				Select @sheetid	= @engg_cont_btsynname + '_sid'
								
				If not exists (	Select 'X' from ep_ui_control_dtl(nolock)
				where	customer_name		= @engg_customer_name  
				and		project_name		= @engg_project_name  
				and		process_name		= @tmp_proc  
				and		component_name		= @tmp_comp  
				and		activity_name		= @tmp_act  
				and		ui_name				= @tmp_ui  
				and		control_bt_synonym	= @sheetid)	
				Begin
					Break
				End
				Else
				Begin
					Select @cont_name = substring(@engg_cont_btsynname, 1,@len_sht - 1)
					Select @len_sht	  = len(@cont_name)
				End
			End		
		
		--Insert appctrl and sheetctrl
			Insert into ep_ui_control_dtl
				(customer_name,			project_name,		req_no,				process_name,			component_name,			activity_name,			ui_name,
				page_bt_synonym,		section_bt_synonym,	control_bt_synonym,	control_type,			horder,					vorder,					order_seq,
				data_column_width,		label_column_width,	ui_control_sysid,	ui_section_sysid,		timestamp,				createdby,				createddate,
				modifiedby,				modifieddate,		control_id,			view_name,				visisble_length,		proto_tooltip,			sample_data,
				control_doc,			control_prefix,		label_control_id,	label_column_scalemode,	data_column_scalemode,	tab_seq,				help_tabstop,
				LabelClass,				ControlClass,		LabelImageClass,	ControlImageClass,		wrkreqno,				AccessKey,					Set_User_Pref,
				freezecount,			controlimage,		colspan,			rowspan,				TemplateID,
				--Code added on 19th July 2021
				ExtensionReqd,			AssociateControl,	ForResponsive,		ControlFormat,
				ButtonNature,			InlineStyle)	--Tech-75230
			Select
				@engg_customer_name,	@engg_project_name,	'BASE',				@tmp_proc,				@tmp_comp,				@tmp_act,				@tmp_ui,
				'[mainscreen]',			'PrjhdnSection',	@appid,				'DisplayOnly',			@max_horder,			1,						1,
				0,						0,					newid(),			newid(),				1,						@ctxt_user,				getdate(),
				@ctxt_user,				getdate(),			'DSP'+@appid,		'DSP'+@appid,			null,					'',						'',					
				@appid,					@appid,				'',					'',						'',						0,						'N',			
				'',						'',					'',					'',						@engg_req_no,			'',				'Y',
				0,						'',					'',					'',						'',
				--Code added for TECH-60451
				@engg_extnreqd,			@engg_MSC_Ass_control,---code added  for the defect id:TECH-63527
				@Engg_cont_forresponsive,	--Code added for TECH-69624
				@engg_cont_control_format,	--Code Added for the Defect Id TECH-72114
				@ButtonNature,			@InlineStyle	--Tech-75230
				Union
				Select
				@engg_customer_name,	@engg_project_name,	'BASE',				@tmp_proc,				@tmp_comp,				@tmp_act,				@tmp_ui,
				'[mainscreen]',			'PrjhdnSection',	@sheetid,			'DisplayOnly',			@max_horder,			2,						1,
				0,						0,					newid(),			newid(),				1,						@ctxt_user,				getdate(),
				@ctxt_user,				getdate(),			'DSP'+@sheetid,		'DSP'+@sheetid,			null,					'',						'',					
				@sheetid,				@sheetid,			'',					'',						'',						0,						'N',			
				'',						'',					'',					'',						@engg_req_no,			'',			    'Y',
				0,						'',					'',					'',						'',
				----Code added for TECH-60451
				@engg_extnreqd,			@engg_MSC_Ass_control,---code added  for the defect id:TECH-63527
				@Engg_cont_forresponsive,	--Code added for TECH-69624
				@engg_cont_control_format,	--Code Added for the Defect Id TECH-72114
				@ButtonNature,			@InlineStyle	--Tech-75230
		
		---Insert a Bt
			If not exists ( select	'X' from de_business_term (nolock)
			where	customer_name   = @engg_customer_name
			And		project_name	= @engg_project_name
			And		process_name	= @tmp_proc
			And		component_name  = @tmp_comp
			And		bt_name			= 'engg_name')
			Begin
				Insert into de_business_term
					(customer_name,			project_name,			process_name,		component_name,			bt_name,		bt_descr,
					data_type,				bt_sysid,				timestamp,			createdby,				createddate,	modifiedby,
					modifieddate,			length,					precision_type,		ecrno)
				values
					(@engg_customer_name,   @engg_project_name,		@tmp_proc,			@tmp_comp,				'engg_name',		'engg_name',
					'Char',					newid(),				1,					@ctxt_user,				getdate(),		@ctxt_user,
					getdate(),				60,						null,				@engg_req_no)
			End

		---Insert appid into glossary 
			if not exists (	Select 'X' from ep_component_glossary_mst(nolock)
			where	customer_name		= @engg_customer_name
			and		project_name		= @engg_project_name
			and		process_name		= @tmp_proc
			and		component_name		= @tmp_comp
			and		bt_synonym_name		= @appid)
			Begin
				insert into ep_component_glossary_mst
					(customer_name,			project_name,			req_no,					process_name,			component_name,		bt_synonym_name,
					data_type,				length,					bt_synonym_caption,		glossary_sysid,			timestamp,			createdby,
					createddate,			modifiedby,				modifieddate,			ref_bt_synonym_name,	bt_synonym_doc,		bt_name,
					synonym_status,			singleinst_sample_data, multiinst_sample_data,	wrkreqno)
				select
					@engg_customer_name,	@engg_project_name,		'BASE',					@tmp_proc,				@tmp_comp,			@appid,
					'Char',					60,						@appid,					newid(),				1,					@ctxt_user,
					getdate(),				@ctxt_user,				getdate(),				null,					@appid,				'engg_name',
					'R',					'',						'',						@engg_req_no
			end 
		---Insert sheetid into glossary 
			if not exists (	Select 'X' from ep_component_glossary_mst(nolock)
			where	customer_name		= @engg_customer_name
			and		project_name		= @engg_project_name
			and		process_name		= @tmp_proc
			and		component_name		= @tmp_comp
			and		bt_synonym_name		= @sheetid)
			Begin
				insert into ep_component_glossary_mst
					(customer_name,			project_name,			req_no,					process_name,			component_name,		bt_synonym_name,
					data_type,				length,					bt_synonym_caption,		glossary_sysid,			timestamp,			createdby,
					createddate,			modifiedby,				modifieddate,			ref_bt_synonym_name,	bt_synonym_doc,		bt_name,
					synonym_status,			singleinst_sample_data, multiinst_sample_data,	wrkreqno)
				select
					@engg_customer_name,	@engg_project_name,		'BASE',					@tmp_proc,				@tmp_comp,			@sheetid,
					'Char',					60,						@sheetid,				newid(),				1,					@ctxt_user,
					getdate(),				@ctxt_user,				getdate(),				null,					@sheetid,			'engg_name',
					'R',					'',						'',						@engg_req_no
			End
		
		-- Code commented due to EP/RE lng extn purge Starts by 11537
		/*
		---Insert appid and sheetid into glossary lng mst
			if not exists (	Select 'X' from ep_component_glossary_mst_lng_extn(nolock)
			where	customer_name		= @engg_customer_name
			and		project_name		= @engg_project_name
			and		process_name		= @tmp_proc
			and		component_name		= @tmp_comp
			and		languageid			= 1
			and		(bt_synonym_name	= @appid
			or		bt_synonym_name		= @sheetid))		
			Begin
			
				insert into ep_component_glossary_mst_lng_extn
					( customer_name,	project_name,		req_no,					process_name,			component_name,		bt_synonym_name,
					data_type,			length,				bt_synonym_caption,		glossary_sysid,			languageid,			timestamp,
					createdby,			createddate,		modifiedby,				modifieddate,			ref_bt_synonym_name,bt_synonym_doc
					,bt_name,			synonym_status,		singleinst_sample_data,	multiinst_sample_data,	wrkreqno )
				select
					a.customer_name,	a.project_name,		a.req_no,				a.process_name,			a.component_name,  a.bt_synonym_name,
					a.data_type,		a.length,			a.bt_synonym_caption,	newid(),				1,					1,
					@ctxt_user,			getdate(),			@ctxt_user,				getdate(),				null,				a.bt_synonym_doc,
					a.bt_name,			a.synonym_status,	'',						'',						@engg_req_no
				from	ep_component_glossary_mst  a (nolock)
				where	a.customer_name = @engg_customer_name
				and		a.project_name	= @engg_project_name
				and		req_no			= @engg_req_no
				and		process_name	= @tmp_proc
				and		component_name	= @tmp_comp
				and		bt_synonym_name	in (@appid,@sheetid)
				and		not exists (select 's'
				from	ep_component_glossary_mst_lng_extn c (nolock)
				where	c.customer_name		= a.customer_name
				and		c.project_name		= a.project_name
				and		c.req_no			= a.req_no
				and		c.process_name		= a.process_name
				and		c.component_name	= a.component_name
				and		c.bt_synonym_name	= a.bt_synonym_name
				and		c.languageid		= 1)
			End
		*/
		-- Code commented due to EP/RE lng extn purge Ends by 11537

		--Insert appctrl and sheetctrl in ep_ui_control_association_map
			Insert into ep_ui_control_association_map
				(customer_name,			project_name,		req_no,				process_name,			component_name,			activity_name,			ui_name,
				page_bt_synonym,		section_bt_synonym,	Control_id,			view_name,				propertyname,			propertycontrol,		property_controlid,
				property_viewname,		createdby,			createddate,		modifiedby,				modifieddate)
			Select
				@engg_customer_name,	@engg_project_name,	'BASE',				@tmp_proc,				@tmp_comp,				@tmp_act,				@tmp_ui,
				@engg_cont_page_bts,	@engg_cont_sec_bts, @control_id,		@control_id,			'AppCtrl',				@appid,					'DSP'+@appid,
				'DSP'+@appid,			@ctxt_user,			getdate(),			@ctxt_user,				getdate()
			Union
				Select
				@engg_customer_name,	@engg_project_name,	'BASE',				@tmp_proc,				@tmp_comp,				@tmp_act,				@tmp_ui,
				@engg_cont_page_bts,	@engg_cont_sec_bts, @control_id,		@control_id,				'SheetCtrl',			@sheetid,				'DSP'+@sheetid,
				'DSP'+@sheetid,			@ctxt_user,				getdate(),		@ctxt_user,				getdate()
		End
---QlikLink Ends
-- code added for PLF2.0_16291  starts
		if @modeflag <> 'S'  
		begin  
			if exists ( select 'x'  
			from    es_comp_ctrl_type_mst	(nolock)  
			where   customer_name   = @engg_customer_name  
			and		project_name    = @engg_project_name  
			and		process_name    = @tmp_proc  
			and		component_name  = @tmp_comp  
			and		ctrl_type_name  = @engg_cont_elem_type  
			and		IsPivot			= 'y')  
			begin    
	
				if @modeflag in ('U', 'Y')  
				Begin  
					if  @tmp_control_type <> @engg_cont_elem_type  
					begin  
						Raiserror('Control Type cannot be updated to a pivot grid. Error at Row %d' ,16,4,@fprowno)
						Return
					End
				End
			End
		End
-- code added for PLF2.0_16291 ends
--------------------------Code added against the DEFECT ID : TECH-65312 starts ------------------------------------------------------
	if @modeflag in  ('I','Y','U','X')  
	begin
	if  exists (Select 'x'
		from	es_comp_ctrl_type_mst(nolock)  
		where	customer_name	= @engg_customer_name  
		and		project_name	= @engg_project_name  
		and		process_name	= @tmp_proc  
		and		component_name  = @tmp_comp  
		and		ctrl_type_name  = @engg_cont_elem_type 
		and		base_ctrl_type	= 'Edit' 
		and		Attach_document  = 'Y' 
		and		isnull(save_doc_content_to_db,'n')<>'y'
		and		isnull(AttachmentWithDesc,'n')<>'y')
		begin
			raiserror('For the Attachment control "%s" in section "%s", Attachment with Desc is mandatory. Kindly change the Control Type.',16,1,@engg_cont_btsynname,@engg_cont_sec_bts)
			return
		end
		if  exists (Select 'x'
		from	es_comp_ctrl_type_mst(nolock)  
		where	customer_name	= @engg_customer_name  
		and		project_name	= @engg_project_name  
		and		process_name	= @tmp_proc  
		and		component_name  = @tmp_comp  
		and		ctrl_type_name  = @engg_cont_elem_type 
		and		base_ctrl_type	= 'Edit' 
		and		image_upload    = 'Y' 
		and		isnull(save_image_content_to_db,'n')<>'y'
		and		isnull(AttachmentWithDesc,'n')<>'y')
		begin
			raiserror('For the Attachment control "%s" in section "%s", Attachment with Desc is mandatory. Kindly change the Control Type.',16,1,@engg_cont_btsynname,@engg_cont_sec_bts)
			return
		end

end
--------------------------Code added against the DEFECT ID : TECH-65312 ends ------------------------------------------------------
-- Code added By Feroz for Image Control / Ataach Document Control hidden view creation  
--Code Modified for the Bug ID:PNR2.0_29431 starts  
--select 'first', @tmp_cotrol_id, @modeflag
	if @modeflag <> 'S'  
	begin  
		if exists (select 'X' from es_comp_ctrl_type_mst (nolock)   
		where	customer_name		= @engg_customer_name  
		and		project_name		= @engg_project_name  
		and		process_name		= @tmp_proc  
		and     component_name		= @tmp_comp  
		and		ctrl_type_name		= @engg_cont_elem_type  
		and		(attach_document	= 'Y'	
		and  AttachmentWithDesc		='y'))  
		Begin
			Exec ep_attachdoc_hiddenview_ins_sp 
					@ctxt_language,			@ctxt_ouinstance,			@ctxt_service,			@ctxt_user,				@engg_customer_name,
					@engg_project_name,		@tmp_proc,					@tmp_comp,				@tmp_act,				@tmp_ui,
					@engg_cont_page_bts,	@engg_cont_sec_bts,			@engg_cont_btsynname,	'',						@engg_req_no,			--@hidden_vew_bt_synonym,
					@tmp_control_type,		@engg_cont_elem_type,		@tmp_cotrol_id,			@tmp_cotrol_id,			@modeflag,				
					@del_flag,				@del_flag_ph,				'HDR',					@m_errorid
		End
	
	-- Code added for Defect ID : May2020 starts
		if exists (select 'x' 
		from	es_comp_ctrl_type_mst mst(nolock),
				es_comp_ctrl_type_mst_extn extn (nolock)    
		where	mst.customer_name		= @engg_customer_name  
		and		mst.project_name		= @engg_project_name  
		and		mst.process_name		= @tmp_proc  
		and     mst.component_name		= @tmp_comp  
		and		mst.ctrl_type_name		= @engg_cont_elem_type  
		and		mst.customer_name		= extn.customer_name  
		and		mst.project_name		= extn.project_name  
		and		mst.process_name		= extn.process_name
		and		mst.component_name		= extn.component_name
		and		mst.ctrl_type_name		= extn.ctrl_type_name
		and		mst.base_ctrl_type		 = extn.base_ctrl_type 
		and		(mst.base_ctrl_type		= 'Edit'	
		and		Dynamicfileupload		= 'Y'
		and		image_icon				= 'Y'))  
		Begin
		
			Exec ep_Dynamicfileupload_hdnview_sp 
				@ctxt_language,			@ctxt_ouinstance,			@ctxt_service,			@ctxt_user,				@engg_customer_name,
				@engg_project_name,		@tmp_proc,					@tmp_comp,				@tmp_act,				@tmp_ui,
				@engg_cont_page_bts,	@engg_cont_sec_bts,			@engg_cont_btsynname,	'',						@engg_req_no,			
				@tmp_control_type,		@engg_cont_elem_type,		@tmp_cotrol_id,			@tmp_cotrol_id,			@modeflag,				
				@del_flag,				@del_flag_ph,				'HDR',					@m_errorid
		End
-- Code added for Defect ID : May2020 ends

	-- Code added for Defect ID : TECH-18349 starts
		if exists (select 'x' 
		from	es_comp_ctrl_type_mst mst(nolock),
				es_comp_ctrl_type_mst_extn extn (nolock)    
		where	mst.customer_name		= @engg_customer_name  
		and		mst.project_name		= @engg_project_name  
		and		mst.process_name		= @tmp_proc  
		and     mst.component_name		= @tmp_comp  
		and		mst.ctrl_type_name		= @engg_cont_elem_type  
		and		mst.customer_name		= extn.customer_name  
		and		mst.project_name		= extn.project_name  
		and		mst.process_name		= extn.process_name
		and		mst.component_name		= extn.component_name
		and		mst.ctrl_type_name		= extn.ctrl_type_name
		and		mst.base_ctrl_type		 = extn.base_ctrl_type 
		and		(attach_document		= 'Y'	
		and		AttachmentWithDesc		= 'y'
		and		Dynamicfileupload		= 'Y'))  
		Begin
			Exec ep_Dynamicfileupload_hdnview_sp 
				@ctxt_language,			@ctxt_ouinstance,			@ctxt_service,			@ctxt_user,				@engg_customer_name,
				@engg_project_name,		@tmp_proc,					@tmp_comp,				@tmp_act,				@tmp_ui,
				@engg_cont_page_bts,	@engg_cont_sec_bts,			@engg_cont_btsynname,	'',						@engg_req_no,			
				@tmp_control_type,		@engg_cont_elem_type,		@tmp_cotrol_id,			@tmp_cotrol_id,			@modeflag,				
				@del_flag,				@del_flag_ph,				'HDR',					@m_errorid
		End
-- Code added for Defect ID : TECH-18349 ends

-- Code added for Defect ID : TECH-18349 starts
		if exists (select 'x' 
		from	es_comp_ctrl_type_mst mst(nolock),
				es_comp_ctrl_type_mst_extn extn (nolock)    
		where	mst.customer_name		= @engg_customer_name  
		and		mst.project_name		= @engg_project_name  
		and		mst.process_name		= @tmp_proc  
		and     mst.component_name		= @tmp_comp  
		and		mst.ctrl_type_name		= @engg_cont_elem_type  
		and		mst.customer_name		= extn.customer_name  
		and		mst.project_name		= extn.project_name  
		and		mst.process_name		= extn.process_name
		and		mst.component_name		= extn.component_name
		and		mst.ctrl_type_name		= extn.ctrl_type_name
		and		mst.base_ctrl_type		 = extn.base_ctrl_type 
		and		(MetaDataBasedLink		= 'Y'	
		and		mst.base_ctrl_type		in ('DataHyperLink', 'Link'))
		)  
		Begin
			Exec ep_MetaDataBasedLink_hdnview_sp 
					@ctxt_language,			@ctxt_ouinstance,			@ctxt_service,			@ctxt_user,				@engg_customer_name,
					@engg_project_name,		@tmp_proc,					@tmp_comp,				@tmp_act,				@tmp_ui,
					@engg_cont_page_bts,	@engg_cont_sec_bts,			@engg_cont_btsynname,	'',						@engg_req_no,			
					@tmp_control_type,		@engg_cont_elem_type,		@tmp_cotrol_id,			@tmp_cotrol_id,			@modeflag,				
					@del_flag,				@del_flag_ph,				'HDR',					@m_errorid
		End
-- Code added for Defect ID : TECH-18349 ends

-- Code Added for the Defect ID TECH-27286 Starts
		Declare @rowcountctrl	engg_name
		DECLARE @horder			engg_seqno
		DECLARE @vorder			engg_seqno

		SET	@rowcountctrl	= 'h'+@engg_cont_btsynname +'_rwcnt'
		SET	@horder			= 1001
		SET @vorder			= 1

		if exists (select 'x' 
		from	es_comp_ctrl_type_mst mst(nolock),
				es_comp_ctrl_type_mst_extn extn (nolock)    
		where	mst.customer_name		= @engg_customer_name  
		and		mst.project_name		= @engg_project_name  
		and		mst.process_name		= @tmp_proc  
		and     mst.component_name		= @tmp_comp  
		and		mst.ctrl_type_name		= @engg_cont_elem_type  
		and		mst.customer_name		= extn.customer_name  
		and		mst.project_name		= extn.project_name  
		and		mst.process_name		= extn.process_name
		and		mst.component_name		= extn.component_name
		and		mst.ctrl_type_name		= extn.ctrl_type_name
		and		mst.base_ctrl_type		 = extn.base_ctrl_type 
		and		SelectedRowcount		= 'Y'	
		and		mst.base_ctrl_type		= 'Grid'
		)  
		Begin
			IF NOT EXISTS (SELECT 'X'
			from	ep_ui_control_dtl (nolock)
			where	customer_name		= @engg_customer_name
			and		project_name		= @engg_project_name
			and		process_name		= @tmp_proc
			and		component_name		= @tmp_comp
			and		activity_name		= @tmp_act
			and		ui_name				= @tmp_ui
			and		page_bt_synonym		= @engg_cont_page_bts
			and		section_bt_synonym	= @engg_cont_sec_bts
			and		control_bt_synonym	= @rowcountctrl
			)
			BEGIN
				INSERT INTO EP_UI_CONTROL_DTL
					( CUSTOMER_NAME,		PROJECT_NAME,		REQ_NO,				PROCESS_NAME,		COMPONENT_NAME,			ACTIVITY_NAME,		
					UI_NAME,				PAGE_BT_SYNONYM,	SECTION_BT_SYNONYM,	control_bt_synonym,	CONTROL_TYPE,			HORDER,
					VORDER,					ORDER_SEQ,			DATA_COLUMN_WIDTH,	LABEL_COLUMN_WIDTH,	UI_CONTROL_SYSID,		UI_SECTION_SYSID,
					TIMESTAMP,				CREATEDBY,			CREATEDDATE,		MODIFIEDBY,			MODIFIEDDATE,			CONTROL_ID,
					VIEW_NAME,				VISISBLE_LENGTH,	PROTO_TOOLTIP,		SAMPLE_DATA,		CONTROL_DOC,			CONTROL_PREFIX,
					LABEL_CONTROL_ID,		LABEL_COLUMN_SCALEMODE,DATA_COLUMN_SCALEMODE,TAB_SEQ,		HELP_TABSTOP,			LABELCLASS,
					CONTROLCLASS,			LABELIMAGECLASS,	CONTROLIMAGECLASS,	Set_User_Pref,		wrkreqno,				
					--Code added on 19th July 2021
					EXTENSIONREQD,			ASSOCIATECONTROL,	ForResponsive,		ControlFormat,	--Code added for TECH-69624
					ButtonNature,			InlineStyle)	--Tech-75230
				select
					CUSTOMER_NAME,			PROJECT_NAME,		REQ_NO,				PROCESS_NAME,		COMPONENT_NAME,			ACTIVITY_NAME,		
					UI_NAME,				page_bt_synonym,	section_bt_synonym,	@rowcountctrl,		'HiddenEdit',			@horder,
					@vorder,				ORDER_SEQ,			DATA_COLUMN_WIDTH,	LABEL_COLUMN_WIDTH,	UI_CONTROL_SYSID,		UI_SECTION_SYSID,
					TIMESTAMP,				CREATEDBY,			CREATEDDATE,		MODIFIEDBY,			MODIFIEDDATE,			'HDN' + @rowcountctrl,
					'HDN' + @rowcountctrl,	VISISBLE_LENGTH,	PROTO_TOOLTIP,		SAMPLE_DATA,		'System',				CONTROL_PREFIX,
					LABEL_CONTROL_ID,		LABEL_COLUMN_SCALEMODE,DATA_COLUMN_SCALEMODE,TAB_SEQ,		HELP_TABSTOP,			LABELCLASS,
					CONTROLCLASS,			LABELIMAGECLASS,	CONTROLIMAGECLASS,	Set_User_Pref,		wrkreqno,
					--Code added for TECH-60451
					@engg_extnreqd,			@engg_MSC_Ass_control, ---code added  for the defect id:TECH-63527
					@Engg_cont_forresponsive,	--Code added for TECH-69624
					@engg_cont_control_format,	--Code Added for the Defect Id TECH-72114
					@ButtonNature,			@InlineStyle	--Tech-75230
				from	ep_ui_control_dtl (nolock)
				where	customer_name		= @engg_customer_name
				and		project_name		= @engg_project_name
				and		process_name		= @tmp_proc
				and		component_name		= @tmp_comp
				and		activity_name		= @tmp_act
				and		ui_name				= @tmp_ui
				and		page_bt_synonym		= @engg_cont_page_bts
				and		section_bt_synonym	= @engg_cont_sec_bts
				and		control_bt_synonym	= @engg_cont_btsynname
			END
		END

		if not exists (select 'x' 
		from	es_comp_ctrl_type_mst mst(nolock),
				es_comp_ctrl_type_mst_extn extn (nolock)    
		where	mst.customer_name		= @engg_customer_name  
		and		mst.project_name		= @engg_project_name  
		and		mst.process_name		= @tmp_proc  
		and     mst.component_name		= @tmp_comp  
		and		mst.ctrl_type_name		= @engg_cont_elem_type  
		and		mst.customer_name		= extn.customer_name  
		and		mst.project_name		= extn.project_name  
		and		mst.process_name		= extn.process_name
		and		mst.component_name		= extn.component_name
		and		mst.ctrl_type_name		= extn.ctrl_type_name
		and		mst.base_ctrl_type		 = extn.base_ctrl_type 
		and		SelectedRowcount		= 'Y'	
		and		mst.base_ctrl_type		= 'Grid'
		)  
		Begin
		
			IF EXISTS (SELECT 'X'
			from	ep_ui_control_dtl (nolock)
			where	customer_name		= @engg_customer_name
			and		project_name		= @engg_project_name
			and		process_name		= @tmp_proc
			and		component_name		= @tmp_comp
			and		activity_name		= @tmp_act
			and		ui_name				= @tmp_ui
			and		page_bt_synonym		= @engg_cont_page_bts
			and		section_bt_synonym	= @engg_cont_sec_bts
			and		control_bt_synonym	= @rowcountctrl
			)
			BEGIN
				
				DELETE
				from	ep_ui_control_dtl 
				where	customer_name		= @engg_customer_name
				and		project_name		= @engg_project_name
				and		process_name		= @tmp_proc
				and		component_name		= @tmp_comp
				and		activity_name		= @tmp_act
				and		ui_name				= @tmp_ui
				and		page_bt_synonym		= @engg_cont_page_bts
				and		section_bt_synonym	= @engg_cont_sec_bts
				and		control_bt_synonym	= @rowcountctrl
		
			END
		
		END
		
-- Code Added for the Defect ID TECH-27286 Ends


		declare @hidden_vew_bt_synonym		engg_name,  @engg_cont_btsynname_tmp	engg_name  
		declare @hidden_vew_bt_synonym_tmp	engg_name,	@ctxt_attach_doc			engg_name,  
				@count						int  
		 if @tmp_control_type <> @engg_cont_elem_type  
		 begin  
			if not exists (select 'X' from es_comp_ctrl_type_mst(nolock)   
			where	customer_name		= @engg_customer_name  
			and		project_name		= @engg_project_name  
			and     process_name		= @tmp_proc  
			and     component_name		= @tmp_comp  
			and		ctrl_type_name		= @engg_cont_elem_type  
			and		(image_upload		= 'Y'  
			  or  attach_document		= 'Y')  
			and		(save_image_content_to_db = 'y'  
			  or  save_doc_content_to_db ='y')
			  UNION
			  SELECT 'x'
			FROM es_comp_ctrl_type_mst mst(NOLOCK),
				es_comp_ctrl_type_mst_extn extn(NOLOCK)
			WHERE mst.customer_name = @engg_customer_name
				AND mst.project_name = @engg_project_name
				AND mst.process_name = @tmp_proc
				AND mst.component_name = @tmp_comp
				AND mst.ctrl_type_name = @engg_cont_elem_type
				AND mst.customer_name = extn.customer_name
				AND mst.project_name = extn.project_name
				AND mst.process_name = extn.process_name
				AND mst.component_name = extn.component_name
				AND mst.ctrl_type_name = extn.ctrl_type_name
				AND mst.base_ctrl_type = extn.base_ctrl_type
				AND (
					mst.base_ctrl_type		= 'Edit'	
					and		Dynamicfileupload		= 'Y'
					and		image_icon				= 'Y'
					)
			  
			  )  
			begin  
			
				 delete from de_hidden_view_usage  
				 where  customer_name	= @engg_customer_name  
				 and	project_name	= @engg_project_name  
				 and	process_name	= @tmp_proc  
				 and	component_name	= @tmp_comp  
				 and	activity_name	= @tmp_act  
				 and	ui_name			= @tmp_ui  
		 /* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P */  
				 and  control_page_name  = @engg_cont_page_bts  
				 and  control_bt_sysnonym= @engg_cont_btsynname  
				 and  hidden_view_bt_sysnonym  like ('hdi'+@hidden_vew_bt_synonym+'%')  
       
				 delete from de_hidden_view  
				 where  customer_name	= @engg_customer_name  
				 and	project_name	= @engg_project_name  
				 and	process_name	= @tmp_proc  
				 and	component_name	= @tmp_comp  
				 and	activity_name	= @tmp_act  
				 and	ui_name			= @tmp_ui  
				 and	page_name		= @engg_cont_page_bts  
				 and	section_name	= @engg_cont_sec_bts  
				 and	control_bt_synonym = @engg_cont_btsynname  
				 and	hidden_view_bt_synonym  like ('hdi'+@hidden_vew_bt_synonym+'%')  
			end  
		end 

		if exists (select 'X' from es_comp_ctrl_type_mst_vw(nolock)   
		where	customer_name		= @engg_customer_name  
		and		project_name		= @engg_project_name  
		and		process_name		= @tmp_proc  
		and     component_name		= @tmp_comp  
		and		ctrl_type_name		= @engg_cont_elem_type  
		and		(image_upload		= 'Y'  
		 or		attach_document		= 'Y')  
		and		(save_image_content_to_db = 'y'  
		 or		save_doc_content_to_db ='y')
		 UNION
		 SELECT 'x'
			FROM es_comp_ctrl_type_mst mst(NOLOCK),
				es_comp_ctrl_type_mst_extn extn(NOLOCK)
			WHERE mst.customer_name = @engg_customer_name
				AND mst.project_name = @engg_project_name
				AND mst.process_name = @tmp_proc
				AND mst.component_name = @tmp_comp
				AND mst.ctrl_type_name = @engg_cont_elem_type
				AND mst.customer_name = extn.customer_name
				AND mst.project_name = extn.project_name
				AND mst.process_name = extn.process_name
				AND mst.component_name = extn.component_name
				AND mst.ctrl_type_name = extn.ctrl_type_name
				AND mst.base_ctrl_type = extn.base_ctrl_type
				AND (
					mst.base_ctrl_type		= 'Edit'	
					and		Dynamicfileupload		= 'Y'
					and		image_icon				= 'Y'
					)
		 )  
		begin 
		
			IF NOT EXISTS   (SELECT  'X'
			FROM    de_hidden_view (NOLOCK)
			WHERE   customer_name	= @engg_customer_name
			AND		project_name	= @engg_project_name
			AND		process_name	= @tmp_proc
			AND		component_name	= @tmp_comp
			AND		ui_name			= @tmp_ui
			AND		page_name		= @engg_cont_page_bts
			AND		section_name	= @engg_cont_sec_bts
			AND		control_bt_synonym= @engg_cont_btsynname )
			BEGIN 
		
				set @count= 0  
				--TECH-75230
				--if len(@engg_cont_btsynname) >25  
				--begin   
				--	select @engg_cont_btsynname_tmp  = left(@engg_cont_btsynname,23)  
				-- end  
				-- ELSE   
				-- BEGIN  
				--	select @engg_cont_btsynname_tmp  = @engg_cont_btsynname  
				-- END
				--TECH-75230
				 while (1=1)  
				 begin  
					  --select @hidden_vew_bt_synonym = 'hdi' + @engg_cont_btsynname_tmp   --TECH-75230
					  select @hidden_vew_bt_synonym = 'hdi' + @control_prefix  --TECH-75230
				 if @count = 0  
				 begin  
					select @hidden_vew_bt_synonym_tmp =   @hidden_vew_bt_synonym  
				 end  
				 else  
				 begin  
					select @hidden_vew_bt_synonym_tmp =  @hidden_vew_bt_synonym + cast(@count as varchar)  
				 end  
				 if exists ( select  'x' from  ep_ui_page_dtl (nolock)  
				 where	customer_name		= @engg_customer_name  
				 and	project_name		= @engg_project_name  
				 and    process_name		= @tmp_proc  
				 and    component_name		= @tmp_comp   
				 and    activity_name		= @tmp_act  
				 and	ui_name				= @tmp_ui  
				 and	page_bt_synonym		= @hidden_vew_bt_synonym_tmp  
				 Union		
				 select 'x'  
				 from	ep_ui_section_dtl  a(nolock)  
				 where  customer_name		= @engg_customer_name  
				 and	project_name		= @engg_project_name  
				 and	process_name		= @tmp_proc  
				 and	component_name		= @tmp_comp  
				 and	activity_name		= @tmp_act  
				 and	ui_name				= @tmp_ui  
				 and	page_bt_synonym		= @engg_cont_page_bts  
				 and	section_bt_synonym  = @hidden_vew_bt_synonym_tmp  
				 and    req_no				= @engg_base_req_no   
				 Union  
				 Select 'x' from ep_ui_control_dtl (nolock)  
				 where	customer_name		= @engg_customer_name  
				 and	project_name		= @engg_project_name  
				 and	process_name		= @tmp_proc  
				 and	component_name		= @tmp_comp  
				 and	activity_name		= @tmp_act  
				 and	ui_name				= @tmp_ui  
				 and	page_bt_synonym		= @engg_cont_page_bts  
				 and	control_bt_synonym  = @hidden_vew_bt_synonym_tmp  
				 and    req_no				= @engg_base_req_no  
				 Union  
				 Select  'x' from ep_ui_grid_dtl (nolock)  
				 where  customer_name		=  @engg_customer_name  
				 and	project_name		=  @engg_project_name  
				 and	process_name		=  @tmp_proc  
				 and	component_name		=  @tmp_comp  
				 and	activity_name		=  @tmp_act  
				 and	ui_name				=  @tmp_ui  
				 and	page_bt_synonym		=  @engg_cont_page_bts  
				 and	column_bt_synonym	=  @hidden_vew_bt_synonym_tmp  
				 and    req_no				=  @engg_base_req_no   
				 Union  
				 Select  'x' from de_hidden_view (nolock)  
				 where  customer_name		=  @engg_customer_name  
				 and	project_name		=  @engg_project_name  
				 and	process_name		=  @tmp_proc  
				 and	component_name		=  @tmp_comp  
				 and	activity_name		=  @tmp_act  
				 and	ui_name				=  @tmp_ui  
				 and	page_name			=  @engg_cont_page_bts  
				 and	hidden_view_bt_synonym  =  @hidden_vew_bt_synonym_tmp  
				 Union  
				 Select  'x' from de_scratch_variable (nolock)  
				 where  customer_name		=  @engg_customer_name  
				 and   project_name			=  @engg_project_name  
				 and   process_name			=  @tmp_proc  
				 and   component_name		=  @tmp_comp  
				 and   activity_name		=  @tmp_act  
				 and   ui_name				=  @tmp_ui  
				 and   page_name			=  @engg_cont_page_bts  
				 and   scratch_name			=  @hidden_vew_bt_synonym_tmp  
				 Union  
				 select 'x'  
				 from	de_scratch_variables_sys (nolock)  
				 where	customer_name		=  @engg_customer_name  
				 and	project_name		=  @engg_project_name  
				 and	process_name		=  @tmp_proc  
				 and	component_name		=  @tmp_comp  
				 and	btsynonym			= @hidden_vew_bt_synonym_tmp )  
				begin  
					select @count = @count + 1  
				end  
				else  
				begin  
					break  
				end  
			end  
			
			select  @hidden_vew_bt_synonym =   @hidden_vew_bt_synonym_tmp   
			if not exists(  select 'x'  from ep_component_glossary_mst (nolock )  
			where	customer_name	= @engg_customer_name  
			and		project_name	= @engg_project_name  
			and		req_no			= @engg_base_req_no  
			and		process_name	= @tmp_proc  
			and		component_name	= @tmp_comp  
			and		bt_synonym_name = @hidden_vew_bt_synonym  )  
			begin   	---- Code added for newly added property isvarbinary in control types begins
				IF EXISTS (SELECT  'X'  FROM  es_comp_ctrl_type_mst(NOLOCK)
				WHERE   customer_name	= @engg_customer_name
				AND		project_name	= @engg_project_name
				AND		process_name	= @tmp_proc
				AND		component_name	= @tmp_comp
				AND		ctrl_type_name	= @engg_cont_elem_type
				AND		(image_upload	= 'Y'
				OR		attach_document	= 'Y')
				AND		(save_image_content_to_db	= 'y'
				OR		save_doc_content_to_db		= 'y')
				AND		is_varbinary='y')
				BEGIN
					SELECT  @ctxt_attach_doc = 'varbinary(max)'
					IF EXISTS ( SELECT  'x' 
					FROM    de_business_term(NOLOCK)
					WHERE   customer_name	= @engg_customer_name
					AND		project_name	= @engg_project_name
					AND		process_name	= @tmp_proc
					AND		component_name	= @tmp_comp
					AND		length			= 8000
					AND		data_type		= 'varbinary' )
					BEGIN 
					   SELECT	@ctxt_attach_doc = bt_name
					   FROM		de_business_term(NOLOCK)
					   WHERE	customer_name	= @engg_customer_name
					   AND		project_name	= @engg_project_name
					   AND		process_name	= @tmp_proc
					   AND		component_name	= @tmp_comp
					   AND		length			= 8000
					   AND		data_type		= 'varbinary'
				   END 
				   ELSE
				   BEGIN
					   INSERT  INTO de_business_term
						   ( customer_name ,	project_name ,		process_name ,		component_name ,		bt_name ,		bt_descr ,		data_type ,
							 bt_sysid ,			timestamp ,			createdby ,			createddate ,			modifiedby ,	modifieddate ,	length ,
							 precision_type ,	Generatedby ,		ecrno)
					   VALUES  ( 
							@engg_customer_name ,@engg_project_name ,@tmp_proc ,		@tmp_comp ,				@ctxt_attach_doc , @ctxt_attach_doc,
							'varbinary' ,		 NEWID() ,			1 ,					@ctxt_user ,			GETDATE() ,		   @ctxt_user ,
							 GETDATE() ,		 8000 ,				null ,				'' ,					@engg_base_req_no)
				   END		
				   EXEC ep_component_glossary_mst_sp_ins 
						@ctxt_language,		@ctxt_ouinstance,		@ctxt_service,			@ctxt_user,			@engg_customer_name,	@engg_project_name, @engg_base_req_no,
                        @tmp_proc,			@tmp_comp,				@hidden_vew_bt_synonym, NULL,				'varbinary', -- Code Modified By Feroz For Bug Id :PNR2.0_23766
                        8000,				@hidden_vew_bt_synonym, @hidden_vew_bt_synonym, @ctxt_attach_doc,	'U',					'', 
						'',					1,						@engg_req_no,			@m_errorid OUTPUT 

				  IF @m_errorid <> 0
					  RETURN
 
				  INSERT  INTO RE_GLOSSARY( 
						customer_name ,		project_name ,		bt_synonym_name ,		process_name ,		component_name ,		data_type ,
						length ,			bt_synonym_caption ,glossary_sysid ,		timestamp ,			createdby ,				createddate ,
						modifiedby ,		modifieddate ,		ref_bt_synonym_name ,	bt_synonym_doc ,	bt_name ,				synonym_status ,
						singleinst_sample_data ,multiinst_sample_data ,rcnno)
				  VALUES  ( 
						@engg_customer_name ,@engg_project_name ,@hidden_vew_bt_synonym ,@tmp_proc ,		@tmp_comp ,				'varbinary' ,
						8000 ,				 @hidden_vew_bt_synonym ,NEWID() ,			 1 ,				@ctxt_user ,			GETDATE() ,
						@ctxt_user ,		 GETDATE() ,			'' ,				@hidden_vew_bt_synonym ,@ctxt_attach_doc ,	'R' ,
						'' ,				 '' ,					'')
									
					--INSERT  INTO RE_GLOSSARY_LNG_EXTN( 
					--	customer_name ,		 project_name ,		 process_name ,			component_name ,	bt_synonym_name ,		data_type ,
					--	length ,			 bt_synonym_caption ,glossary_sysid ,		languageid ,		timestamp ,				createdby ,
					--	createddate ,		 modifiedby ,		 modifieddate ,			ref_bt_synonym_name ,bt_synonym_doc ,		bt_name ,
					--	synonym_status ,	 singleinst_sample_data ,multiinst_sample_data ,rcnno)
					--SELECT  
					--	@engg_customer_name ,@engg_project_name ,@tmp_proc ,			@tmp_comp ,			@hidden_vew_bt_synonym ,'varbinary' ,
					--	8000 ,				 @hidden_vew_bt_synonym ,NEWID() ,			quick_code ,		1 ,						@ctxt_user ,
					--	GETDATE() ,			 @ctxt_user ,		GETDATE() ,				'' ,				@hidden_vew_bt_synonym ,@ctxt_attach_doc ,
					--	'R' ,				 '' ,				'' ,					''
					--FROM    EP_LANGUAGE_MET (NOLOCK)
					
				 INSERT  INTO DE_GLOSSARY( 
					customer_name ,		project_name ,		component_name ,		process_name ,		bt_synonym_name ,		data_type ,
                    length ,			bt_synonym_caption ,glossary_sysid ,		timestamp ,			createdby ,				createddate ,
                    modifiedby ,		modifieddate ,		ref_bt_synonym_name ,	bt_synonym_doc ,	bt_name ,				synonym_status ,
					singleinst_sample_data ,multiinst_sample_data ,ecrno )
                 VALUES  ( 
					@engg_customer_name ,@engg_project_name ,@tmp_comp ,			@tmp_proc ,			@hidden_vew_bt_synonym , 'varbinary' ,
                    8000 ,				 @hidden_vew_bt_synonym ,NEWID() ,			1 ,					@ctxt_user ,			  GETDATE() ,
                    @ctxt_user ,		GETDATE() ,				 '' ,				@hidden_vew_bt_synonym , @ctxt_attach_doc ,	 'R' ,
                    '' ,				'' ,				'')
								
                --INSERT  INTO DE_GLOSSARY_LNG_EXTN ( 
				--	customer_name ,		project_name ,		process_name ,			component_name ,	bt_synonym_name ,		data_type ,
				--	length ,			bt_synonym_caption ,glossary_sysid ,		languageid ,		timestamp ,				createdby ,
                --    createddate ,		modifiedby ,		modifieddate ,			ref_bt_synonym_name ,bt_synonym_doc ,		bt_name ,
                --    synonym_status ,	singleinst_sample_data , multiinst_sample_data ,ecrno )
                --SELECT  
				--	@engg_customer_name ,@engg_project_name ,@tmp_proc ,			@tmp_comp ,			@hidden_vew_bt_synonym ,'varbinary' ,
				--	8000 ,				 @hidden_vew_bt_synonym ,NEWID() ,			quick_code ,		1 ,						@ctxt_user ,
                --    GETDATE() ,			@ctxt_user ,		GETDATE() ,				'' ,				@hidden_vew_bt_synonym ,@ctxt_attach_doc ,	
				--	'R' ,					'' ,			'' ,					''
                --FROM    EP_LANGUAGE_MET (NOLOCK)
			END
			ELSE  ---- Code added for newly added property isvarbinary in control types ends
			begin	
			
				select @ctxt_attach_doc = 'ctxt_attach_doc'  

				if exists( select 'x'  
				from	de_business_term(nolock)  
				where	customer_name		= @engg_customer_name  
				and		project_name		= @engg_project_name  
				and		process_name		= @tmp_proc  
				and		component_name		= @tmp_comp  
				and		length				= 4000  
				and		data_type			= 'char' )  
				 begin   
					  select	@ctxt_attach_doc = bt_name  
					  from		de_business_term(nolock)  
					  where		customer_name	= @engg_customer_name  
					  and		project_name	= @engg_project_name  
					  and		process_name	= @tmp_proc  
					  and		component_name	= @tmp_comp  
					  and		length			= 4000  
					  and		data_type		= 'char'  
				 end   
				 else   
				 begin  
					insert into de_business_term (
						customer_name,		project_name,		process_name,		component_name,		bt_name,		bt_descr,
						data_type,			bt_sysid,			timestamp,			createdby,			createddate,	modifiedby,
						modifieddate,		length,				precision_type,		Generatedby,		ecrno)  
					values (
						@engg_customer_name,@engg_project_name,	@tmp_proc,			@tmp_comp,			@ctxt_attach_doc,
						@ctxt_attach_doc,	'CHAR',				NEWID(),			1,					@ctxt_user,
						getdate(),			@ctxt_user,			getdate(),			4000,				null,
						'',					@engg_base_req_no)  
				end  

				 exec ep_component_glossary_mst_sp_ins  
					@ctxt_language,		@ctxt_ouinstance,		@ctxt_service,		@ctxt_user,			@engg_customer_name,  
					@engg_project_name, @engg_base_req_no,		@tmp_proc,			@tmp_comp,			@hidden_vew_bt_synonym,
					null,				'Char', -- Code Modified By Feroz For Bug Id :PNR2.0_23766  
					4000 ,				@hidden_vew_bt_synonym ,@hidden_vew_bt_synonym, @ctxt_attach_doc ,'U',  
					'',					'',						1,					@engg_req_no,		@m_errorid  output   
  
				if @m_errorid <> 0  
					return  
   
				insert into RE_GLOSSARY(
					customer_name,		project_name,		bt_synonym_name,		process_name,	component_name,  
					data_type,			length,				bt_synonym_caption,		glossary_sysid,	timestamp,  
					createdby,			createddate,		modifiedby,				modifieddate,	ref_bt_synonym_name,  
					 bt_synonym_doc,	bt_name,			synonym_status,			singleinst_sample_data,
					 multiinst_sample_data,	rcnno)  
				values (
					@engg_customer_name,@engg_project_name,	@hidden_vew_bt_synonym,	@tmp_proc,			@tmp_comp,  
					'char',				4000,				@hidden_vew_bt_synonym,	newid(),			1,  
					 @ctxt_user,		getdate(),			@ctxt_user,				getdate(),			'',  
					 @hidden_vew_bt_synonym,@ctxt_attach_doc,'R',					'',					'',				'')  
           
				--insert into RE_GLOSSARY_LNG_EXTN (
				--	customer_name,			project_name,		process_name,			component_name,		bt_synonym_name,
				--	data_type,				length,				bt_synonym_caption,		glossary_sysid,		languageid,
				--	timestamp,				createdby,			createddate,			modifiedby,			modifieddate,
				--	ref_bt_synonym_name,	bt_synonym_doc,		bt_name,				synonym_status,		singleinst_sample_data,
				--	multiinst_sample_data,	rcnno)  
				--select  
				--	@engg_customer_name,	@engg_project_name, @tmp_proc,				@tmp_comp,			@hidden_vew_bt_synonym,
				--	'char',					4000,				@hidden_vew_bt_synonym,	newid(),			quick_code,
				--	1,						@ctxt_user,			getdate(),				@ctxt_user,			getdate(),
				--	'',						@hidden_vew_bt_synonym,						@ctxt_attach_doc,	'R',
				--	'',						'',					''  
				--from  EP_LANGUAGE_MET (NOLOCK)  
       
				insert into DE_GLOSSARY (
					customer_name,			project_name,		component_name,			process_name,		bt_synonym_name,  
					data_type,				length,				bt_synonym_caption,		glossary_sysid,		timestamp,  
					createdby,				createddate,		modifiedby,				modifieddate,		ref_bt_synonym_name,
					bt_synonym_doc,			bt_name,synonym_status,						singleinst_sample_data,
					multiinst_sample_data,	ecrno)   
				Values (
					@engg_customer_name,	@engg_project_name,	@tmp_comp,				@tmp_proc,			@hidden_vew_bt_synonym,  
					'char',					4000,				@hidden_vew_bt_synonym,	newid(),			1,  
					@ctxt_user,				getdate(),			@ctxt_user,				getdate(),			'',
					@hidden_vew_bt_synonym, @ctxt_attach_doc,	'R',					'',					'',				'')  
          
				--insert into DE_GLOSSARY_LNG_EXTN (
				--	customer_name,			project_name,		process_name,			component_name,		bt_synonym_name,
				--	data_type,				length,				bt_synonym_caption,		glossary_sysid,		languageid,
				--	timestamp,				createdby,			createddate,			modifiedby,			modifieddate,
				--	ref_bt_synonym_name,	bt_synonym_doc,		bt_name,				synonym_status,		singleinst_sample_data,
				--	multiinst_sample_data,	ecrno)  
				--select  
				--	@engg_customer_name,	@engg_project_name,	@tmp_proc,				@tmp_comp,			@hidden_vew_bt_synonym,
				--	'char',					4000,				@hidden_vew_bt_synonym,	newid(),			quick_code,
				--	1,						@ctxt_user,			getdate(),				@ctxt_user,			getdate(),
				--	'',						@hidden_vew_bt_synonym,@ctxt_attach_doc,	'R',				'',
				--	'',						''  
				--  from  EP_LANGUAGE_MET (NOLOCK)  
			end
		end 
		
		if not exists ( select 'x'  
		from	de_hidden_view (nolock)  
		where	customer_name		= @engg_customer_name  
		and		project_name		= @engg_project_name  
		and		process_name		= @tmp_proc  
		and		component_name		= @tmp_comp  
		and		activity_name		= @tmp_act  
		and		ui_name				= @tmp_ui  
		and		page_name			= @engg_cont_page_bts  
		and		section_name		= @engg_cont_sec_bts  
		and		control_bt_synonym	= @engg_cont_btsynname  
		and		hidden_view_bt_synonym = @hidden_vew_bt_synonym)  
			select	@control_id=control_id
			from	ep_ui_control_dtl(nolock)
			where	customer_name	= @engg_customer_name
			AND		project_name	= @engg_project_name
			AND		process_name	= @tmp_proc
			AND		component_name	= @tmp_comp
			AND		activity_name	= @tmp_act
			AND		ui_name			= @tmp_ui
			AND		page_bt_synonym = @engg_cont_page_bts
			AND		section_bt_synonym = @engg_cont_sec_bts
			AND		control_bt_synonym = @engg_cont_btsynname
			begin  
				insert into de_hidden_view  
					(customer_name,			project_name,		process_name,		component_name,			activity_name,		ui_name, 
					page_name,				section_name,		control_bt_synonym,	hidden_view_bt_synonym, transfer_flag,		hidden_view_sysid, 
					control_sysid,			timestamp,			createdby,			createddate,			modifiedby,			modifieddate,  
					control_id,				view_name,			new_control_bt_synonym,HIDDEN_VIEW_SOURCE,	ecrno)  
				select  
					@engg_customer_name,	@engg_project_name, @tmp_proc,			@tmp_comp,				@tmp_act,			@tmp_ui, 
					@engg_cont_page_bts,	@engg_cont_sec_bts, @engg_cont_btsynname,@hidden_vew_bt_synonym, 'N',				newid(), 
					newid(),				1,					@ctxt_user,			getdate(),				@ctxt_user,			getdate(),  
					@control_id,			@hidden_vew_bt_synonym,@hidden_vew_bt_synonym,NULL,				NULL  
			end  
		end
	 END
  
	if @modeflag = 'D'  and isnull(@del_flag, 'T') = 'T' -- Code Modified for PNR2.0_32228 Starts  
	and isnull(@del_flag_ph,'T') = 'T'
	begin  
	
		  delete from de_hidden_view_usage  
		  where	customer_name	= @engg_customer_name  
		  and	project_name	= @engg_project_name  
		  and	process_name	= @tmp_proc  
		  and	component_name	= @tmp_comp  
		  and	activity_name	= @tmp_act  
		  and	ui_name			= @tmp_ui  
	  /* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P */  
		  and	control_page_name = @engg_cont_page_bts  
		  and	control_bt_sysnonym= @engg_cont_btsynname  
	  --and  hidden_view_bt_sysnonym  = @hidden_vew_bt_synonym  
  
		  delete from de_hidden_view  
		  where	customer_name	= @engg_customer_name  
		  and	project_name	= @engg_project_name  
		  and	process_name	= @tmp_proc  
		  and	component_name	= @tmp_comp  
		  and	activity_name	= @tmp_act  
		  and	ui_name			= @tmp_ui  
		  and	page_name		= @engg_cont_page_bts  
		  and	section_name	= @engg_cont_sec_bts  
		  and	control_bt_synonym = @engg_cont_btsynname  
		  --and  hidden_view_bt_synonym  = @hidden_vew_bt_synonym  
	end  
end  
----Code Modified for the Bug ID:PNR2.0_29431 ends  
  
-- Code added By Feroz for Image Control / Ataach Document Control hidden view creation  
  
-- Code added By Feroz For List Edit  
if @modeflag not in ( 'S', 'D') -- Code Added for PNR2.0_32228 Starts  
begin  
	if @tmp_control_type <> @engg_cont_elem_type  
	begin  
		exec ep_create_listedit_task  
			@ctxt_ouinstance,		@ctxt_user,			@ctxt_language,			@ctxt_service,			@engg_customer_name,		@engg_project_name,  
			@tmp_proc,				@tmp_comp,			@tmp_act,				@tmp_ui,				@engg_base_req_no,			@engg_cont_page_bts,  
			@engg_cont_sec_bts,		@engg_cont_btsynname,@tmp_control_type,		'D',					@engg_req_no,				@m_errorid output  
	end  
  
	if exists ( select 'x'  
	from    es_comp_ctrl_type_mst_vw (nolock)  
	where   customer_name   = @engg_customer_name  
	and		project_name    = @engg_project_name  
	and		process_name    = @tmp_proc  
	and		component_name  = @tmp_comp  
	and		ctrl_type_name  = @engg_cont_elem_type  
	and		req_no			= @engg_base_req_no  
	and		(listrefilltask_req = 'Y'  
	or		onfocustask_req		= 'Y'))  
	begin  
		exec ep_create_listedit_task  
			@ctxt_ouinstance,		@ctxt_user,			@ctxt_language,			@ctxt_service,			@engg_customer_name,		@engg_project_name,  
			@tmp_proc,				@tmp_comp,			@tmp_act,				@tmp_ui,				@engg_base_req_no,			@engg_cont_page_bts,  
			@engg_cont_sec_bts,		@engg_cont_btsynname,@engg_cont_elem_type,  @modeflag,				@engg_req_no,				@m_errorid output  
	end  
end  
  
-- Code added By Feroz For List Edit   
-- Modified By feroz for bug id :PNR2.0_23463  
-- Added by Feroz for Date highlight -- start  
If @modeflag in ('I', 'X', 'U', 'Y')  
Begin  
	select	@base_ctrl_type_tmp = base_ctrl_type  
	from	es_comp_ctrl_type_mst_vw (nolock)  
	where	customer_name		= @engg_customer_name  
	and		project_name		= @engg_project_name  
	and		process_name		= @tmp_proc  
	and		component_name		= @tmp_comp  
	and		ctrl_type_name		= @engg_cont_elem_type  
	and		req_no				= @engg_base_req_no  
  
	if @base_ctrl_type_tmp = 'ListEdit'  
	begin  
		if not exists ( select 'x'  
		from	ep_date_highlight_column (nolock)  
		where	customer_name	= @engg_customer_name  
		and     project_name	= @engg_project_name  
		and     component_name	= @tmp_comp  
		and     process_name	= @tmp_proc  
		and		activity_name	= @tmp_act  
		and		ui_name			= @tmp_ui  
		and     listedit_synonym= @engg_cont_btsynname)  
		begin   
			insert into ep_date_highlight_column  
				(customer_name,			project_name,		req_no,				process_name,			component_name,			listedit_synonym, 
				listedit_column_synonym,
				createdby,				createddate,		wrkreqno,			activity_name,			ui_name)  
			select  
				@engg_customer_name,	@engg_project_name, @engg_base_req_no,	@tmp_proc  ,			@tmp_comp,				@engg_cont_btsynname, 
				@engg_cont_btsynname + '_listdate',
				@ctxt_user,				getdate(),			@engg_req_no,		@tmp_act,				@tmp_ui  
			union  
			select  
				@engg_customer_name,	@engg_project_name,	@engg_base_req_no,	@tmp_proc  ,			@tmp_comp,				@engg_cont_btsynname, 
				@engg_cont_btsynname + '_color',
				@ctxt_user,				getdate(),			@engg_req_no,		@tmp_act,				@tmp_ui  
			union  
			select  
				@engg_customer_name,	@engg_project_name, @engg_base_req_no,	@tmp_proc  ,			@tmp_comp,				@engg_cont_btsynname, 
				@engg_cont_btsynname + '_tooltip', 
				@ctxt_user,				getdate(),			@engg_req_no,		@tmp_act,				@tmp_ui  
		end  
	end  
end  
If @modeflag in ('D')  
Begin  
	delete from ep_date_highlight_column  
	where	customer_name	= @engg_customer_name  
	and     project_name	= @engg_project_name  
	and     component_name	= @tmp_comp  
	and     process_name	= @tmp_proc  
	and		activity_name	= @tmp_act  
	and		ui_name			= @tmp_ui  
	and     listedit_synonym = @engg_cont_btsynname  
end  
-- Added by Feroz for Date highlight -- End  
-- Modified By feroz for bug id :PNR2.0_23463  
--Kanagavel For Stacklinks Starts

If @modeflag in ('I', 'X')  
Begin  
	if exists (select 'x'  
	from    es_comp_ctrl_type_mst_vw (nolock)  
	where   customer_name	= @engg_customer_name  
	and    project_name		= @engg_project_name  
	and    process_name		= @tmp_proc  
	and    component_name	= @tmp_comp  
	and    ctrl_type_name	= @engg_cont_elem_type  
	and    req_no     		= @engg_base_req_no  
	and    base_ctrl_type	=  'StackedLinks' )
	begin 
		if len (@engg_cont_btsynname) >24
		begin 
			raiserror('Synonym name %s should not be greater than 24 characters',16,1,@engg_cont_btsynname)
			return
		end 
		insert ep_ui_grid_dtl (
			customer_name,		project_name,		req_no,				process_name,		component_name,			activity_name,		ui_name,
			page_bt_synonym,	section_bt_synonym,	control_bt_synonym,	column_bt_synonym,	column_type,			column_no,			grid_sysid,
			ui_control_sysid,	timestamp,			createdby,			createddate,		modifiedby,				modifieddate,		control_id,
			view_name,			visible_length,		proto_tooltip,		sample_data,		col_doc,				column_prefix,		wrkreqno,
			Set_User_Pref,		default_required,	ColumnClass,		iskey,				Kyseq_no,				visible,			Forcefit,
			TemplateID)	
		select 	
			@engg_customer_name,@engg_project_name,'Base',				@tmp_proc,			@tmp_comp,				@tmp_act ,			@tmp_ui ,
			@engg_cont_page_bts,@engg_cont_sec_bts,@engg_cont_btsynname,@engg_cont_btsynname+'_an','Edit',			'1',				newid(),
			newid(),			1,					@ctxt_user,			getdate(),			@ctxt_user,				getdate(),			@control_id,
			'activityname',		null,				null,				'',					@engg_cont_btsynname+'_an','',				'',
			'',					null,				null,				null,				null,					'Yes',				null,
			null
		union
		select 	
			@engg_customer_name,@engg_project_name,'Base',				@tmp_proc,			@tmp_comp,				@tmp_act ,			@tmp_ui ,
			@engg_cont_page_bts,@engg_cont_sec_bts,@engg_cont_btsynname,@engg_cont_btsynname+'_lc','Link',			'2',				newid(),
			newid(),			1,					@ctxt_user,			getdate(),			@ctxt_user,				getdate(),			@control_id,
			'caption',			null,				null,				'',					@engg_cont_btsynname+'_lc','',				'',
			'',					null,				null,				null,				null,					'Yes',				null,					
			null
		union
		select 	
			@engg_customer_name,@engg_project_name,'Base',				@tmp_proc,			@tmp_comp,				@tmp_act ,			@tmp_ui ,
			@engg_cont_page_bts,@engg_cont_sec_bts, @engg_cont_btsynname,@engg_cont_btsynname+'_cn','Edit',			'3',				newid(),
			newid(),			1,					@ctxt_user,			getdate(),			@ctxt_user,				getdate(),			@control_id,
			'componentname',	null,				null,				'',					@engg_cont_btsynname+'_cn','',				'',
			'',					null,				null,				null,				null,					'Yes',				null,
			null
		union
		select 	
			@engg_customer_name,@engg_project_name,'Base',				@tmp_proc,			@tmp_comp,				@tmp_act ,			@tmp_ui ,
			@engg_cont_page_bts,@engg_cont_sec_bts, @engg_cont_btsynname,@engg_cont_btsynname+'_in','Edit',			'4',				newid(),
			newid(),			1,					@ctxt_user,			getdate(),			@ctxt_user,				getdate(),			@control_id,
			'ilboname',			null,				null,				'',					@engg_cont_btsynname+'_in','',				'',
			'',					null,				null,				null,				null,				'Yes',					null,
			null
		union
		select 	
			@engg_customer_name,@engg_project_name,'Base',				@tmp_proc,			@tmp_comp,				@tmp_act ,			@tmp_ui ,
			@engg_cont_page_bts,@engg_cont_sec_bts, @engg_cont_btsynname,@engg_cont_btsynname+'_lt','Edit',			'5',				newid(),
			newid(),			1,					@ctxt_user,			getdate(),			@ctxt_user,				getdate(),			@control_id,
			'launchtype',		null,				null,				'',					@engg_cont_btsynname+'_lt','',				'',
			'',					null,				null,				null,				null,					'Yes',				null,
			null
		union
		select 	
			@engg_customer_name,@engg_project_name,'Base',				@tmp_proc,			@tmp_comp,				@tmp_act ,			@tmp_ui ,
			@engg_cont_page_bts,@engg_cont_sec_bts,@engg_cont_btsynname,@engg_cont_btsynname+'_ln','Edit',			'6',				newid(),
			newid(),			1,					@ctxt_user,			getdate(),			@ctxt_user,				getdate(),			@control_id,
			'linkname',			null,				null,				'',					@engg_cont_btsynname+'_ln','',				'',
			'',					null,				null,				null,				null,					'Yes',				null,
			null
		union
		select 	
			@engg_customer_name,@engg_project_name,'Base',				 @tmp_proc,			@tmp_comp,				@tmp_act ,			@tmp_ui ,
			@engg_cont_page_bts,@engg_cont_sec_bts, @engg_cont_btsynname,@engg_cont_btsynname+'_mt','Edit',			'7',				newid(),
			newid(),			1,					@ctxt_user,			getdate(),			@ctxt_user,				getdate(),			@control_id,
			'modeltype',		null,				null,				'',					@engg_cont_btsynname+'_mt','',				'',
			'',					null,				null,				null,				null,					'Yes',				null,
			null
		union
		select 	
			@engg_customer_name,@engg_project_name,'Base',				@tmp_proc,			@tmp_comp,				@tmp_act ,			@tmp_ui ,
			@engg_cont_page_bts,@engg_cont_sec_bts,@engg_cont_btsynname,@engg_cont_btsynname+'_tt','Edit',			'8',				newid(),
			newid(),			1,					@ctxt_user,			getdate(),			@ctxt_user,				getdate(),			@control_id,
			'target',			null,				null,				'',					@engg_cont_btsynname+'_tt','',				'',
			'',					null,				null,				null,				null,					'Yes',				null,	
			null

		Create table #Stacked_columns (id int identity , column_name varchar(60))		
--Insert #Stacked_columns values ((@engg_cont_btsynname+'_an'),(@engg_cont_btsynname+'_lc'),
--(@engg_cont_btsynname+'_cn'),(@engg_cont_btsynname+'_in'),(@engg_cont_btsynname+'_lt'),(@engg_cont_btsynname+'_ln'),(@engg_cont_btsynname+'_mt'),
--(@engg_cont_btsynname+'_tt'))
--code modified for bugid :PLF2.0_18487
		Insert #Stacked_columns(Column_name)
		select @engg_cont_btsynname+'_an' 
		union
		select @engg_cont_btsynname+'_lc'
		union
		select @engg_cont_btsynname+'_cn'
		union
		select @engg_cont_btsynname+'_in'
		union
		select @engg_cont_btsynname+'_lt'
		union
		select @engg_cont_btsynname+'_ln'
		union
		select @engg_cont_btsynname+'_tt'
		union
		select @engg_cont_btsynname+'_mt'

		declare @temp_column_name engg_name , @cnt engg_seqno , @count_stack  engg_seqno 

		set @cnt 	= 1 
		set @count_stack  = 8 
		while ( @count_stack > @cnt )
		begin 
			select	@temp_column_name =column_name
			from	#Stacked_columns
			where	id = @cnt

			exec engg_gen_prefix_id 
				@engg_customer_name,		@engg_project_name,			@tmp_comp,			@tmp_act,		@tmp_ui,		@temp_column_name,
				'C',						6,							@page_prefix_tmp output 

			update	ep_ui_grid_dtl set
					column_prefix	= @page_prefix_tmp
			where	customer_name	= @engg_customer_name  
			and		project_name	= @engg_project_name  
			and		process_name	= @tmp_proc  
			and		component_name	= @tmp_comp  
			and		activity_name	= @tmp_act  
			and		ui_name			= @tmp_ui  
			and		page_bt_synonym = @engg_cont_page_bts  
			and		section_bt_synonym = @engg_cont_sec_bts  
			and		control_bt_synonym = @engg_cont_btsynname 
			and		column_bt_synonym  = @temp_column_name

			set @cnt  = @cnt +1
		end
		drop table #Stacked_columns

		if not exists(  select 'X' 
		from	ep_component_glossary_mst(nolock)
		where	customer_name		= @engg_customer_name	
		and		project_name		= @engg_project_name	
		and		process_name		= @tmp_proc				
		and		component_name		= @tmp_comp
		and		bt_synonym_name		= @engg_cont_btsynname+'_an')		
		begin 
			insert ep_component_glossary_mst (
				customer_name,		project_name,		req_no,			process_name,			component_name,			bt_synonym_name,	   data_type,
				length,				bt_synonym_caption, glossary_sysid,	timestamp,				createdby,				createddate,		   modifiedby,
				modifieddate,		ref_bt_synonym_name,bt_synonym_doc, bt_name,				synonym_status,			singleinst_sample_data,multiinst_sample_data,
				wrkreqno)
			select  
				customer_name,		project_name,		req_no,			process_name,			component_name,			column_bt_synonym,		'Char',
				20,					column_bt_synonym,	newid(),		1,						@ctxt_user,				getdate(),				@ctxt_user,
				getdate(),			column_bt_synonym,	column_bt_synonym,'',					'R',					null,					null,
				'Base'
			from	ep_ui_grid_dtl(nolock)
			where	customer_name	= @engg_customer_name  
			and		project_name	= @engg_project_name  
			and		process_name	= @tmp_proc  
			and		component_name	= @tmp_comp  
			and		activity_name	= @tmp_act  
			and		ui_name			= @tmp_ui  
			and		page_bt_synonym = @engg_cont_page_bts  
			and		section_bt_synonym = @engg_cont_sec_bts  
			and		control_bt_synonym = @engg_cont_btsynname 

			-- Code commented due to EP/RE lng extn purge Starts by 11537
			/*
			insert ep_component_glossary_mst_lng_extn (
				customer_name,		project_name,		req_no,				process_name,			component_name,			bt_synonym_name,		data_type,
				length,				bt_synonym_caption,	
				glossary_sysid,		languageid,			timestamp,			createdby,				createddate,
				modifiedby,			modifieddate,		ref_bt_synonym_name,bt_synonym_doc,			bt_name,				synonym_status,			singleinst_sample_data,
				multiinst_sample_data,wrkreqno)
			select  
				a.customer_name,	project_name,		req_no,				process_name,			component_name,			column_bt_synonym,		'Char',
				20,					cast (b.quick_code as varchar (40))+'_'+column_bt_synonym,
				newid(),			b.quick_code,		1,					@ctxt_user,				getdate(),				@ctxt_user,				getdate(),
				column_bt_synonym,	column_bt_synonym,	'',					'R',					null,					null,					'Base'
			from	ep_ui_grid_dtl a (nolock) , ep_language_met b (nolock)
			where	a.customer_name		= @engg_customer_name  
			and		project_name		= @engg_project_name  
			and		process_name		= @tmp_proc  
			and		component_name		= @tmp_comp  
			and		activity_name		= @tmp_act  
			and		ui_name				= @tmp_ui  
			and		page_bt_synonym		= @engg_cont_page_bts  
			and		section_bt_synonym	= @engg_cont_sec_bts  
			and		control_bt_synonym	= @engg_cont_btsynname 
			*/
			-- Code commented due to EP/RE lng extn purge Ends by 11537

		end 

		declare @engg_cont_col_btsynname  engg_name
		set		@engg_cont_col_btsynname = @engg_cont_btsynname +'_lc'
					  
		exec ep_task_generation
			@ctxt_language,    @ctxt_ouinstance,    @ctxt_service,			@ctxt_user,		@engg_customer_name,    @engg_project_name,  
			@engg_base_req_no, @tmp_proc,			@tmp_comp,				@tmp_act,		@tmp_ui,				@engg_cont_page_bts,  
			@engg_cont_sec_bts,@engg_cont_btsynname,@engg_cont_col_btsynname,'Link',		'Y',					'N',  
			'N',			  'N',					'column',				'N',			@engg_req_no,			@m_errorid output  
	end
end
--Kanagavel For Stacklinks Starts
--select @control_id =  control_id
--from	ep_ui_control_dtl   (nolock)
--where  customer_name    = @engg_customer_name  
--and   project_name    = @engg_project_name  
--and   process_name    = @tmp_proc  
--and component_name   = @tmp_comp  
--and   activity_name    = @tmp_act  
--and   ui_name       = @tmp_ui  
--and   page_bt_synonym   = @engg_cont_page_bts  
--and   section_bt_synonym  = @engg_cont_sec_bts  
--and   control_bt_synonym  = @engg_cont_btsynname  
--and     req_no       = @engg_base_req_no  
--If isnull(@control_id,'') = ''
--begin
--exec ep_controlid_generation  
--@engg_customer_name  , @engg_project_name , @engg_base_req_no ,  
--@tmp_proc    , @tmp_comp   , @tmp_act   ,  
--@tmp_ui     , @engg_cont_btsynname, @tmp_ctl   ,  
--@editable    , @visible   , @control_id out 
--End

  -- Code for Slider Starts
Declare	@slidertype		engg_name

If @modeflag in ('I', 'X')  
Begin  
	if exists ( select 'x'  
	from    es_comp_ctrl_type_mst_vw ctrl (nolock)  ,
			es_comp_ctrl_type_mst_extn extn (nolock)
	where	ctrl.customer_name   = @engg_customer_name  
	and		ctrl.project_name    = @engg_project_name  
	and		ctrl.process_name    = @tmp_proc  
	and		ctrl.component_name  = @tmp_comp  
	and		ctrl.ctrl_type_name  = @engg_cont_elem_type  
	and		ctrl.req_no     	= @engg_base_req_no  
	and		ctrl.customer_name   = extn.customer_name  
	and		ctrl.project_name    = extn.project_name
	and		ctrl.process_name    = extn.process_name
	and		ctrl.component_name  = extn.component_name
	and		ctrl.ctrl_type_name  = extn.ctrl_type_name
	and		ctrl.base_ctrl_type  in (  'RSSlider' , 'Slider'))
--and		extn.SliderType		 = 'Dynamic' )
	begin 
		if len(@engg_cont_btsynname) >24
		begin 
			raiserror('Synonym name %s should not be greater than 24 characters',16,1,@engg_cont_btsynname)
			return
		end 

		select  @slidertype = extn.SliderType
		from    es_comp_ctrl_type_mst_vw ctrl (nolock)  ,
				es_comp_ctrl_type_mst_extn extn (nolock)
		where  ctrl.customer_name   = @engg_customer_name  
		and    ctrl.project_name    = @engg_project_name  
		and    ctrl.process_name    = @tmp_proc  
		and    ctrl.component_name  = @tmp_comp  
		and    ctrl.ctrl_type_name  = @engg_cont_elem_type  
		and    ctrl.req_no     		= @engg_base_req_no  
		and	   ctrl.customer_name   = extn.customer_name  
		and    ctrl.project_name    = extn.project_name
		and    ctrl.process_name    = extn.process_name
		and    ctrl.component_name  = extn.component_name
		and    ctrl.ctrl_type_name  = extn.ctrl_type_name
		and    ctrl.base_ctrl_type  in (  'RSSlider' , 'Slider')
		if isnull(@slidertype,'') = 'Dynamic'
		Begin
			insert ep_ui_grid_dtl (customer_name,project_name,req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,column_bt_synonym,column_type,column_no,grid_sysid,ui_control_sysid,timestamp,createdby,createddate,modifiedby,modifieddate,control_id,view_name,visible_length,proto_tooltip,sample_data,col_doc,column_prefix,wrkreqno,Set_User_Pref,default_required,ColumnClass,iskey,Kyseq_no,visible,Forcefit,TemplateID)	
			select 	@engg_customer_name,@engg_project_name,'Base',@tmp_proc,@tmp_comp,@tmp_act ,@tmp_ui ,@engg_cont_page_bts,
			@engg_cont_sec_bts,@engg_cont_btsynname,@engg_cont_btsynname+'_sv','Edit','1',newid(),newid(),1,@ctxt_user,
			getdate(),@ctxt_user,getdate(),@engg_cont_btsynname,'startvalue',null,null,'',@engg_cont_btsynname+'_sv','','','',null,
			null,null, null,'Yes',null,null
	union
	select 	@engg_customer_name,@engg_project_name,'Base',@tmp_proc,@tmp_comp,@tmp_act ,@tmp_ui ,@engg_cont_page_bts,
	@engg_cont_sec_bts,@engg_cont_btsynname,@engg_cont_btsynname+'_ev','Edit','2',newid(),newid(),1,@ctxt_user,
	getdate(),@ctxt_user,getdate(),@engg_cont_btsynname,'endvalue',null,null,'',@engg_cont_btsynname+'_ev','','','',null,
	null,null, null,'Yes',null,null
	union
	select 	@engg_customer_name,@engg_project_name,'Base',@tmp_proc,@tmp_comp,@tmp_act ,@tmp_ui ,@engg_cont_page_bts,
	@engg_cont_sec_bts,@engg_cont_btsynname,@engg_cont_btsynname+'_stp','Edit','3',newid(),newid(),1,@ctxt_user,
	getdate(),@ctxt_user,getdate(),@engg_cont_btsynname,'stepvalue',null,null,'',@engg_cont_btsynname+'_stp','','','',null,
	null,null, null,'Yes',null,null
	union
	--select 	@engg_customer_name,@engg_project_name,'Base',@tmp_proc,@tmp_comp,@tmp_act ,@tmp_ui ,@engg_cont_page_bts,
	--@engg_cont_sec_bts,@engg_cont_btsynname,@engg_cont_btsynname+'_val','Edit','4',newid(),newid(),1,@ctxt_user,
	--getdate(),@ctxt_user,getdate(),@control_id,'value',null,null,'',@engg_cont_btsynname+'_val','','','',null,
	--null,null, null,'Yes',null,null
	--union
	select 	@engg_customer_name,@engg_project_name,'Base',@tmp_proc,@tmp_comp,@tmp_act ,@tmp_ui ,@engg_cont_page_bts,
	@engg_cont_sec_bts,@engg_cont_btsynname,@engg_cont_btsynname+'_min','Edit','5',newid(),newid(),1,@ctxt_user,
	getdate(),@ctxt_user,getdate(),@engg_cont_btsynname,'minvalue',null,null,'',@engg_cont_btsynname+'_min','','','',null,
	null,null, null,'Yes',null,null
	union
	select 	@engg_customer_name,@engg_project_name,'Base',@tmp_proc,@tmp_comp,@tmp_act ,@tmp_ui ,@engg_cont_page_bts,
	@engg_cont_sec_bts,@engg_cont_btsynname,@engg_cont_btsynname+'_max','Edit','6',newid(),newid(),1,@ctxt_user,
	getdate(),@ctxt_user,getdate(),@engg_cont_btsynname,'maxvalue',null,null,'',@engg_cont_btsynname+'_max','','','',null,
	null,null, null,'Yes',null,null



	Create table #Slider_columns (id int identity , column_name varchar(60))		
	--Insert #Stacked_columns values ((@engg_cont_btsynname+'_an'),(@engg_cont_btsynname+'_lc'),
	--(@engg_cont_btsynname+'_cn'),(@engg_cont_btsynname+'_in'),(@engg_cont_btsynname+'_lt'),(@engg_cont_btsynname+'_ln'),(@engg_cont_btsynname+'_mt'),
	--(@engg_cont_btsynname+'_tt'))
	--code modified for bugid :PLF2.0_18487
	Insert #Slider_columns(Column_name)
	select @engg_cont_btsynname+'_sv' 
	union
	select @engg_cont_btsynname+'_ev'
	union
	select @engg_cont_btsynname+'_stp'
	union
	--select @engg_cont_btsynname+'_val'
	--union
	select @engg_cont_btsynname+'_min'
	union
	select @engg_cont_btsynname+'_max'

	declare @temp_slider_col engg_name , @tot engg_seqno , @count_slide  engg_seqno 
	set @tot 	= 1 
	set @count_slide  = 8 
	while ( @count_slide > @tot )
	begin 
	select @temp_slider_col =column_name
	from #Slider_columns
	where id = @tot

	exec engg_gen_prefix_id @engg_customer_name,@engg_project_name,@tmp_comp,@tmp_act,    
	@tmp_ui,@temp_slider_col,'C',6,@page_prefix_tmp output 

	update ep_ui_grid_dtl
	set column_prefix = @page_prefix_tmp
	where  customer_name = @engg_customer_name  
	and  project_name  = @engg_project_name  
	and  process_name  = @tmp_proc  
	and  component_name = @tmp_comp  
	and  activity_name = @tmp_act  
	and  ui_name   = @tmp_ui  
	and  page_bt_synonym  = @engg_cont_page_bts  
	and  section_bt_synonym = @engg_cont_sec_bts  
	and  control_bt_synonym = @engg_cont_btsynname 
	and column_bt_synonym    = @temp_slider_col

	set @tot  = @tot +1
	End
	drop table #Slider_columns
End
Else if isnull(@slidertype,'') = 'Static'
Begin
	insert ep_ui_grid_dtl (customer_name,project_name,req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,column_bt_synonym,column_type,column_no,grid_sysid,ui_control_sysid,timestamp,createdby,createddate,modifiedby,modifieddate,control_id,view_name,visible_length,proto_tooltip,sample_data,col_doc,column_prefix,wrkreqno,Set_User_Pref,default_required,ColumnClass,iskey,Kyseq_no,visible,Forcefit,TemplateID)	
	select 	@engg_customer_name,@engg_project_name,'Base',@tmp_proc,@tmp_comp,@tmp_act ,@tmp_ui ,@engg_cont_page_bts,
	@engg_cont_sec_bts,@engg_cont_btsynname,@engg_cont_btsynname+'_ev','Edit','1',newid(),newid(),1,@ctxt_user,
	getdate(),@ctxt_user,getdate(),@engg_cont_btsynname,'endvalue',null,null,'',@engg_cont_btsynname+'_ev','','','',null,
	null,null, null,'Yes',null,null

	select @temp_slider_col = @engg_cont_btsynname+'_ev'

	exec engg_gen_prefix_id @engg_customer_name,@engg_project_name,@tmp_comp,@tmp_act,    
	@tmp_ui,@temp_slider_col,'C',6,@page_prefix_tmp output 

	update ep_ui_grid_dtl
	set column_prefix = @page_prefix_tmp
	where  customer_name = @engg_customer_name  
	and  project_name  = @engg_project_name  
	and  process_name  = @tmp_proc  
	and  component_name = @tmp_comp  
	and  activity_name = @tmp_act  
	and  ui_name   = @tmp_ui  
	and  page_bt_synonym  = @engg_cont_page_bts  
	and  section_bt_synonym = @engg_cont_sec_bts  
	and  control_bt_synonym = @engg_cont_btsynname 
	and column_bt_synonym    = @temp_slider_col


End
--end


---drop table #Slider_columns
 

if not exists	    (  select 'X' 
				   from ep_component_glossary_mst(nolock)
				   where customer_name	= @engg_customer_name	
				   and	 project_name			= @engg_project_name	
				   and	 process_name			= @tmp_proc				
				   and	 component_name	= @tmp_comp
				   and	 bt_synonym_name	= @engg_cont_btsynname+'_ev'
				  --and	 bt_synonym_name	= @engg_cont_btsynname+'_sv'
)		
begin 

insert ep_component_glossary_mst (customer_name,project_name,req_no,process_name,component_name,bt_synonym_name,data_type,length,bt_synonym_caption,glossary_sysid,
								  timestamp,createdby,createddate,modifiedby,modifieddate,ref_bt_synonym_name,bt_synonym_doc,bt_name,synonym_status,singleinst_sample_data,
								  multiinst_sample_data,wrkreqno)
select  customer_name,project_name,req_no,process_name,component_name,column_bt_synonym,'Char',20,column_bt_synonym,newid(),
1,@ctxt_user,getdate(),@ctxt_user,getdate(),column_bt_synonym,column_bt_synonym,'','R',null,
null,'Base'
from ep_ui_grid_dtl(nolock)
where  customer_name = @engg_customer_name  
and  project_name  = @engg_project_name  
and  process_name  = @tmp_proc  
and  component_name = @tmp_comp  
and  activity_name = @tmp_act  
and  ui_name   = @tmp_ui  
and  page_bt_synonym  = @engg_cont_page_bts  
and  section_bt_synonym = @engg_cont_sec_bts  
and  control_bt_synonym = @engg_cont_btsynname 

-- Code commented due to EP/RE lng extn purge Starts by 11537
/*
insert ep_component_glossary_mst_lng_extn (customer_name,project_name,req_no,process_name,component_name,bt_synonym_name,data_type,length,bt_synonym_caption,
										   glossary_sysid,languageid,timestamp,createdby,createddate,modifiedby,modifieddate,ref_bt_synonym_name,bt_synonym_doc,
										   bt_name,synonym_status,singleinst_sample_data,multiinst_sample_data,wrkreqno)
select  a.customer_name,project_name,req_no,process_name,component_name,column_bt_synonym,'Char',20,cast (b.quick_code as varchar (40))+'_'+column_bt_synonym,newid(),
b.quick_code,1,@ctxt_user,getdate(),@ctxt_user,getdate(),column_bt_synonym,column_bt_synonym,'','R',null,
null,'Base'
from ep_ui_grid_dtl a (nolock) , ep_language_met b (nolock)
where  a.customer_name = @engg_customer_name  
and  project_name  = @engg_project_name  
and  process_name  = @tmp_proc  
and  component_name = @tmp_comp  
and  activity_name = @tmp_act  
and  ui_name   = @tmp_ui  
and  page_bt_synonym= @engg_cont_page_bts  
and  section_bt_synonym = @engg_cont_sec_bts  
and  control_bt_synonym = @engg_cont_btsynname 

-- Code commented due to EP/RE lng extn purge Ends by 11537
*/
end 

 
end


end

  -- Code for Slider Ends

if exists (select 'x' from sysobjects (nolock) where name = 'de_customer_space' and type = 'u')  
begin  
update de_customer_space  
set  validate_req   = 'Y'  
where customername   = @engg_customer_name  
and  projectname   = @engg_project_name  
and     processname      = @tmp_proc  
and     componentname    = @tmp_comp  
end  


-- Code added against Tech-218 to update associated control for chart section starts
If @modeflag in ('I', 'X', 'U', 'Y','Z')  
Begin  
  
  update b
  set b.Associated_control=a.control_id
  from ep_ui_control_dtl  a(nolock),ep_ui_section_dtl b(nolock), es_comp_ctrl_type_mst c(nolock)
  where a.customer_name = @engg_customer_name  
		and  a.project_name  = @engg_project_name  
		and  a.process_name  = @tmp_proc  
		and  a.component_name = @tmp_comp  
		and  a.activity_name = @tmp_act  
		and  a.ui_name   = @tmp_ui  
		and  a.page_bt_synonym= @engg_cont_page_bts  
		and  a.section_bt_synonym = @engg_cont_sec_bts  
		and  a.control_bt_synonym = @engg_cont_btsynname 
		and  b.customer_name	=a.customer_name
		and  b.project_name		=a.project_name
		and  b.process_name		=a.process_name
		and	 b.component_name	=a.component_name
		and  b.activity_name	=a.activity_name
		and	 b.ui_name			=a.ui_name
		and	 b.page_bt_synonym	=a.page_bt_synonym
		and	 b.section_bt_synonym =a.section_bt_synonym
		and	 b.section_type='chart'
		and  b.customer_name	=c.customer_name
		and  b.project_name		=c.project_name
		and  b.process_name		=c.process_name
		and	 b.component_name	=c.component_name
		and  a.control_type		=c.ctrl_type_name
		and  c.base_ctrl_type	in ('Edit')
		--Code added on 19th July 2021
		--and	 a.ExtensionReqd  =@engg_extnreqd --Code added for TECH-60451

end 
-- Code added against Tech-218 to update associated control for chart section ends
  
  -- For Tag Control Starts
 SELECT @RenderAs = 'N'
 
If @modeflag in ('I', 'X', 'U', 'Y')  
Begin  
		IF ISNULL(@IsChips, 'N') = 'Y'
			SELECT @RenderAs = 'Tag'	

	if exists ( select 'x'  
	from    es_comp_ctrl_type_mst_vw (nolock)  
	where   customer_name   = @engg_customer_name  
	and		project_name    = @engg_project_name  
	and		process_name    = @tmp_proc  
	and		component_name  = @tmp_comp  
	and		ctrl_type_name  = @engg_cont_elem_type  
	and		req_no     	    = @engg_base_req_no 
	and		renderas		= 'Tag'
	and		not exists(select 'x'
	from	ep_ui_grid_dtl (nolock)
	where   customer_name		= @engg_customer_name  
	and		project_name		= @engg_project_name  
	and		process_name		= @tmp_proc  
	and		component_name		= @tmp_comp
	and     activity_name		= @tmp_act
	and     ui_name				= @tmp_ui
	and		page_bt_synonym		= @engg_cont_page_bts  
	and		section_bt_synonym	= @engg_cont_sec_bts  
	and		control_bt_synonym	= @engg_cont_btsynname ))
	begin 
		SELECT @RenderAs = 'Tag'		
	End
	IF @RenderAs = 'Tag'
	Begin
		if len (@engg_cont_btsynname) >24
		begin 
			raiserror('Synonym name %s should not be greater than 24 characters',16,1,@engg_cont_btsynname)
			return
		end 
				
		insert ep_ui_grid_dtl (customer_name,project_name,req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,
			control_bt_synonym,column_bt_synonym,column_type,column_no,grid_sysid,ui_control_sysid,timestamp,createdby,createddate,modifiedby,
			modifieddate,control_id,view_name,visible_length,proto_tooltip,sample_data,col_doc,column_prefix,wrkreqno,Set_User_Pref,default_required,
			ColumnClass,iskey,Kyseq_no,visible,Forcefit,TemplateID)	
		select 	@engg_customer_name,@engg_project_name,'Base',@tmp_proc,@tmp_comp,@tmp_act ,@tmp_ui ,@engg_cont_page_bts,@engg_cont_sec_bts,
			@engg_cont_btsynname,@engg_cont_btsynname+'_ky','DisplayOnly','1',newid(),newid(),1,@ctxt_user, getdate(),@ctxt_user,
			getdate(),@control_id,'tagkeyfield',null,null,'',@engg_cont_btsynname+'_ky','','','',null,
			null,null, null,'Yes',null,null
		union
		select 	@engg_customer_name,@engg_project_name,'Base',@tmp_proc,@tmp_comp,@tmp_act ,@tmp_ui ,@engg_cont_page_bts,
			@engg_cont_sec_bts,@engg_cont_btsynname,@engg_cont_btsynname+'_va','DisplayOnly','2',newid(),newid(),1,@ctxt_user,
			getdate(),@ctxt_user,getdate(),@control_id,'tagvalue',null,null,'',@engg_cont_btsynname+'_va','','','',null,
			null,null, null,'Yes',null,null
		union
		select 	@engg_customer_name,@engg_project_name,'Base',@tmp_proc,@tmp_comp,@tmp_act ,@tmp_ui ,@engg_cont_page_bts,
			@engg_cont_sec_bts,@engg_cont_btsynname,@engg_cont_btsynname+'_sq','Edit','3',newid(),newid(),1,@ctxt_user,
			getdate(),@ctxt_user,getdate(),@control_id,'tagseqno',null,null,'',@engg_cont_btsynname+'_sq','','','',null,
			null,null, null,'Yes',null,null
		


		Create table #tag_columns (id int identity , column_name varchar(60))				
		Insert #tag_columns(Column_name)
		select @engg_cont_btsynname+'_ky' 
		union
		select @engg_cont_btsynname+'_va'
		union
		select @engg_cont_btsynname+'_sq'
		

		--declare @temp_column_name engg_name , @cnt engg_seqno , @count_stack  engg_seqno 
		set @cnt 	= 1 
		set @count_stack  = 3 

		while ( @count_stack >= @cnt )
		begin 
			select	@temp_column_name =column_name
			from	#tag_columns
			where	id = @cnt

			exec engg_gen_prefix_id @engg_customer_name,@engg_project_name,@tmp_comp,@tmp_act,    
			@tmp_ui,@temp_column_name,'C',6,@page_prefix_tmp output 

			update ep_ui_grid_dtl
			set column_prefix = @page_prefix_tmp
			where  customer_name = @engg_customer_name  
			and  project_name  = @engg_project_name  
			and  process_name  = @tmp_proc  
			and  component_name = @tmp_comp  
			and  activity_name = @tmp_act  
			and  ui_name   = @tmp_ui  
			and  page_bt_synonym  = @engg_cont_page_bts  
			and  section_bt_synonym = @engg_cont_sec_bts  
			and  control_bt_synonym = @engg_cont_btsynname 
			and column_bt_synonym    = @temp_column_name

			set @cnt  = @cnt +1

		end

		drop table #tag_columns
		
		if not exists   (  select 'X' 
		from	ep_component_glossary_mst(nolock)
		where	customer_name	= @engg_customer_name	
		and		project_name	= @engg_project_name	
		and		process_name	= @tmp_proc				
		and		component_name	= @tmp_comp
		and		bt_synonym_name	= @engg_cont_btsynname+'_ky'
		)		
		begin 

		insert ep_component_glossary_mst (customer_name,project_name,req_no,process_name,component_name,bt_synonym_name,data_type,length,bt_synonym_caption,glossary_sysid,
										  timestamp,createdby,createddate,modifiedby,modifieddate,ref_bt_synonym_name,bt_synonym_doc,bt_name,synonym_status,singleinst_sample_data,
										  multiinst_sample_data,wrkreqno)
		select  customer_name,project_name,req_no,process_name,component_name,column_bt_synonym,'Char',20,column_bt_synonym,newid(),
		1,@ctxt_user,getdate(),@ctxt_user,getdate(),column_bt_synonym,column_bt_synonym,'','R',null,
		null,'Base'
		from ep_ui_grid_dtl(nolock)
		where  customer_name = @engg_customer_name  
		and  project_name  = @engg_project_name  
		and  process_name  = @tmp_proc  
		and  component_name = @tmp_comp  
		and  activity_name = @tmp_act  
		and  ui_name   = @tmp_ui  
		and  page_bt_synonym  = @engg_cont_page_bts  
		and  section_bt_synonym = @engg_cont_sec_bts  
		and  control_bt_synonym = @engg_cont_btsynname 

		-- Code commented due to EP/RE lng extn purge Starts by 11537
		/*
		insert ep_component_glossary_mst_lng_extn (customer_name,project_name,req_no,process_name,component_name,bt_synonym_name,data_type,length,bt_synonym_caption,
												   glossary_sysid,languageid,timestamp,createdby,createddate,modifiedby,modifieddate,ref_bt_synonym_name,bt_synonym_doc,
												   bt_name,synonym_status,singleinst_sample_data,multiinst_sample_data,wrkreqno)
		select  a.customer_name,project_name,req_no,process_name,component_name,column_bt_synonym,'Char',20,cast (b.quick_code as varchar (40))+'_'+column_bt_synonym,newid(),
		b.quick_code,1,@ctxt_user,getdate(),@ctxt_user,getdate(),column_bt_synonym,column_bt_synonym,'','R',null,
		null,'Base'
		from ep_ui_grid_dtl a (nolock) , ep_language_met b (nolock)
		where  a.customer_name = @engg_customer_name  
		and  project_name  = @engg_project_name  
		and  process_name  = @tmp_proc  
		and  component_name = @tmp_comp  
		and  activity_name = @tmp_act  
		and  ui_name   = @tmp_ui  
		and  page_bt_synonym= @engg_cont_page_bts  
		and  section_bt_synonym = @engg_cont_sec_bts  
		and  control_bt_synonym = @engg_cont_btsynname 

		-- Code commented due to EP/RE lng extn purge Ends by 11537
		*/
		end 


 end
End
-- For Tag Control Ends


	-- Added for TECH-37471 Starts
	--IF (@modeflag in ('I', 'X', 'U', 'Y' )	
	--AND @base_ctrl_type_tmp	= 'Grid'
	--AND (@IsDataGrid	= 'N' --Code Added for Defect ID : TECH-39534
	--	AND @IsChips	= 'N'
	--	AND @RenderAs	<> 'Tag')
	--AND EXISTS ( select 'X' 
	--			from	ep_ui_mst  with(NOLOCK)
 --               WHERE	customer_name		= customer_name
 --               AND     project_name		= project_name
 --               AND     process_name		= process_name
 --               AND     component_name		= component_name   
	--			AND		activity_name		= @tmp_act
	--			AND		ui_name				= @tmp_ui                
	--			AND		DeviceType			IN ('P', 'T', 'B'))
	--)				 
 --   begin 
 --       Raiserror('Please use ''Mobile Grid'' for mobile UIs.',16,1)
 --       return    
 --   end  

	-- Added for TECH-37471 Ends

		--IF (@modeflag in ('I', 'X', 'U', 'Y' )	
		--AND @base_ctrl_type_tmp	= 'Grid'
		--AND @RenderAs	<> 'Tag' --Code Added for Defect ID : TECH-39534
		--AND EXISTS ( select 'X' 
		--			from	ep_ui_mst  with(NOLOCK)
		--			WHERE	customer_name		= customer_name
		--			AND     project_name		= project_name
		--			AND     process_name		= process_name
		--			AND     component_name		= component_name   
		--			AND		activity_name		= @tmp_act
		--			AND		ui_name				= @tmp_ui                
		--			AND		DeviceType			IN ('P', 'T', 'B'))
		--)				 
		--begin 
		--	Raiserror('Please use ''Mobile Grid'' for mobile UIs.',16,1)
		--	return    
		--end  

-- For Multi-Selector Grid Starts

If @modeflag in ('I', 'X', 'U', 'Y')  
Begin  
	if exists ( select 'x'  
	from    es_comp_ctrl_type_mst_vw (nolock)  
	where   customer_name   = @engg_customer_name  
	and		project_name    = @engg_project_name  
	and		process_name    = @tmp_proc  
	and		component_name  = @tmp_comp  
	and		ctrl_type_name  = @engg_cont_elem_type  
	and		req_no     	    = @engg_base_req_no 
	and		renderas		= 'MultiSelectorGrid')
	begin 
		
		if len (@engg_cont_btsynname) >24
		begin 
			raiserror('Synonym name %s should not be greater than 23 characters',16,1,@engg_cont_btsynname)
			return
		end 
				
		insert ep_ui_grid_dtl (customer_name,project_name,req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,
			control_bt_synonym,column_bt_synonym,column_type,column_no,grid_sysid,ui_control_sysid,timestamp,createdby,createddate,modifiedby,
			modifieddate,control_id,view_name,visible_length,proto_tooltip,sample_data,col_doc,column_prefix,wrkreqno,Set_User_Pref,default_required,
			ColumnClass,iskey,Kyseq_no,visible,Forcefit,TemplateID)	
		select 	@engg_customer_name,@engg_project_name,'Base',@tmp_proc,@tmp_comp,@tmp_act ,@tmp_ui ,@engg_cont_page_bts,@engg_cont_sec_bts,
			@engg_cont_btsynname,@engg_cont_btsynname+'_msk','DisplayOnly','1',newid(),newid(),1,@ctxt_user, getdate(),@ctxt_user,
			getdate(),@control_id,'multiselectkey',null,null,'',@engg_cont_btsynname+'_msk','','','',null,
			null,null, null,'Yes',null,null
		union
		select 	@engg_customer_name,@engg_project_name,'Base',@tmp_proc,@tmp_comp,@tmp_act ,@tmp_ui ,@engg_cont_page_bts,
			@engg_cont_sec_bts,@engg_cont_btsynname,@engg_cont_btsynname+'_msv','DisplayOnly','2',newid(),newid(),1,@ctxt_user,
			getdate(),@ctxt_user,getdate(),@control_id,'multiselectval',null,null,'',@engg_cont_btsynname+'_msv','','','',null,
			null,null, null,'Yes',null,null
		union
		select 	@engg_customer_name,@engg_project_name,'Base',@tmp_proc,@tmp_comp,@tmp_act ,@tmp_ui ,@engg_cont_page_bts,
			@engg_cont_sec_bts,@engg_cont_btsynname,@engg_cont_btsynname+'_mss','Edit','3',newid(),newid(),1,@ctxt_user,
			getdate(),@ctxt_user,getdate(),@control_id,'multiselectseq',null,null,'',@engg_cont_btsynname+'_mss','','','',null,
			null,null, null,'Yes',null,null
		
		Create table #multi_select (id int identity , column_name varchar(60))				
		Insert #multi_select(Column_name)
		select @engg_cont_btsynname+'_msk' 
		union
		select @engg_cont_btsynname+'_msv'
		union
		select @engg_cont_btsynname+'_mss'
		--declare @temp_column_name engg_name , @cnt engg_seqno , @count_stack  engg_seqno 
			set @cnt 			= 1 
			set @count_stack	= 3 

			while ( @count_stack >= @cnt )
			begin 
				select	@temp_column_name =	column_name
				from	#multi_select
				where	id = @cnt
				exec engg_gen_prefix_id 
						@engg_customer_name,		@engg_project_name,		@tmp_comp,		@tmp_act,		@tmp_ui,	@temp_column_name,
						'C',						6,						@page_prefix_tmp output 
			
				update	ep_ui_grid_dtl
				set		column_prefix	= @page_prefix_tmp
				where	customer_name	= @engg_customer_name  
				and		project_name	= @engg_project_name  
				and		process_name	= @tmp_proc  
				and		component_name	= @tmp_comp  
				and		activity_name	= @tmp_act  
				and		ui_name			= @tmp_ui  
				and		page_bt_synonym = @engg_cont_page_bts  
				and		section_bt_synonym = @engg_cont_sec_bts  
				and		control_bt_synonym = @engg_cont_btsynname 
				and		column_bt_synonym  = @temp_column_name

				set @cnt  = @cnt +1
			end
			drop table #multi_select
		
			if not exists   (  select 'X' 
			from	ep_component_glossary_mst(nolock)
			where	customer_name	= @engg_customer_name	
			and		project_name	= @engg_project_name	
			and		process_name	= @tmp_proc				
			and		component_name	= @tmp_comp
			and		bt_synonym_name	= @engg_cont_btsynname+'_msk')		
			begin
				insert ep_component_glossary_mst (
					customer_name,		project_name,		req_no,				process_name,			component_name,		bt_synonym_name,
					data_type,			length,				bt_synonym_caption,	glossary_sysid,			timestamp,			createdby,
					createddate,		modifiedby,			modifieddate,		ref_bt_synonym_name,	bt_synonym_doc,		bt_name,
					synonym_status,		singleinst_sample_data,					multiinst_sample_data,	wrkreqno)
				select  
					customer_name,		project_name,		req_no,				process_name,			component_name,		column_bt_synonym,
					'Char',				20,					column_bt_synonym,	newid(),				1,					@ctxt_user,
					getdate(),			@ctxt_user,			getdate(),			column_bt_synonym,		column_bt_synonym,	'',
					'R',				null,				null,				'Base'
				from	ep_ui_grid_dtl(nolock)
				where	customer_name		= @engg_customer_name  
				and		project_name		= @engg_project_name  
				and		process_name		= @tmp_proc  
				and		component_name		= @tmp_comp  
				and		activity_name		= @tmp_act  
				and		ui_name				= @tmp_ui  
				and		page_bt_synonym		= @engg_cont_page_bts  
				and		section_bt_synonym	= @engg_cont_sec_bts  
				and		control_bt_synonym	= @engg_cont_btsynname 

				-- Code commented due to EP/RE lng extn purge Starts by 11537
				/*
				insert ep_component_glossary_mst_lng_extn (
					customer_name,		project_name,		req_no,				process_name,			component_name,			bt_synonym_name,
					data_type,			length,				bt_synonym_caption,	glossary_sysid,			languageid,				timestamp,
					createdby,			createddate,		modifiedby,			modifieddate,			ref_bt_synonym_name,	bt_synonym_doc,
					bt_name,			synonym_status,		singleinst_sample_data,multiinst_sample_data,wrkreqno)
				select  
					a.customer_name,	project_name,		req_no,				process_name,			component_name,			column_bt_synonym,
					'Char',				20,					cast (b.quick_code as varchar (40))+'_'+column_bt_synonym,
					newid(),			b.quick_code,		1,					@ctxt_user,				getdate(),				@ctxt_user,
					getdate(),			column_bt_synonym,	column_bt_synonym,	'',						'R',					null,
					null,				'Base'
				from	ep_ui_grid_dtl a (nolock) , 
						ep_language_met b (nolock)
				where	a.customer_name		= @engg_customer_name  
				and		project_name		= @engg_project_name  
				and		process_name		= @tmp_proc  
				and		component_name		= @tmp_comp  
				and		activity_name		= @tmp_act  
				and		ui_name				= @tmp_ui  
				and		page_bt_synonym		= @engg_cont_page_bts  
				and		section_bt_synonym	= @engg_cont_sec_bts  
				and		control_bt_synonym	= @engg_cont_btsynname 

				-- Code commented due to EP/RE lng extn purge Ends by 11537
				*/
			end 
		end
	End
-- For Multi-Selector Grid Ends

-- For Row Expander Starts
Declare @ctrl_id_re		engg_name

If @modeflag in ('I', 'X', 'U', 'Y')  
Begin
	if exists ( select 'x'  
	from    es_comp_ctrl_type_mst_vw (nolock)  
	where   customer_name   = @engg_customer_name  
	and		project_name    = @engg_project_name  
	and		process_name    = @tmp_proc  
	and		component_name  = @tmp_comp  
	and		ctrl_type_name  = @engg_cont_elem_type  
	and		req_no     	    = @engg_base_req_no 
	and		renderas		= 'RowExpander')
	begin 
		if not exists (select 'x'
		from	ep_ui_Grid_dtl (nolock)
		where	customer_name		= @engg_customer_name
		and		project_name		= @engg_project_name
		and		req_no				= 'Base'
		and		process_name		= @tmp_proc
		and		component_name		= @tmp_comp
		and		activity_name		= @tmp_act
		and		ui_name				= @tmp_ui
		and		page_bt_synonym		= @engg_cont_page_bts
		and		section_bt_synonym	= @engg_cont_sec_bts
		and		control_bt_synonym	= @engg_cont_btsynname
		and		column_bt_synonym	= @engg_cont_btsynname+'__nodexp')
		Begin
			if len (@engg_cont_btsynname) >20
			begin 
				raiserror('Synonym name %s should not be greater than 20 characters for Row Expander.',16,1,@engg_cont_btsynname)
				return
			end 	

			select	@ctrl_id_re = control_id
			from	ep_ui_control_dtl (nolock)
			where	customer_name		= @engg_customer_name
			and		project_name		= @engg_project_name
			and		process_name		= @tmp_proc
			and		component_name		= @tmp_comp
			and		activity_name		= @tmp_act
			and		ui_name				= @tmp_ui
			and		page_bt_synonym		= @engg_cont_page_bts
			and		section_bt_synonym	= @engg_cont_sec_bts
			and     control_bt_synonym  = @engg_cont_btsynname

			insert ep_ui_grid_dtl (
				customer_name,			project_name,			req_no,				process_name,			component_name,			activity_name,
				ui_name,				page_bt_synonym,		section_bt_synonym,	control_bt_synonym,		column_bt_synonym,		column_type,
				column_no,				grid_sysid,				ui_control_sysid,	timestamp,				createdby,				createddate,
				modifiedby,				modifieddate,			control_id,			view_name,				visible_length,			proto_tooltip,
				sample_data,			col_doc,				column_prefix,		wrkreqno,				Set_User_Pref,			default_required,
				ColumnClass,			iskey,					Kyseq_no,			visible,				Forcefit,				TemplateID)	
			select 	
				@engg_customer_name,	@engg_project_name,		'Base',				@tmp_proc,				@tmp_comp,				@tmp_act ,
				@tmp_ui ,				@engg_cont_page_bts,	@engg_cont_sec_bts,	@engg_cont_btsynname,	@engg_cont_btsynname+'__nodexp',
				'Edit',					'1',					newid(),			newid(),				1,						@ctxt_user, 
				getdate(),				@ctxt_user,				getdate(),			@ctrl_id_re,			'__nodeexpand',
				null,					null,					'',					@engg_cont_btsynname+'__nodexp',
				'nodexp',				'Base',					'',					null,					null,					null, 
				null,					'NO',					null,				null

			if not exists   (  select 'X' 
			from	ep_component_glossary_mst(nolock)
			where	customer_name	= @engg_customer_name	
			and		project_name	= @engg_project_name	
			and		process_name	= @tmp_proc				
			and		component_name	= @tmp_comp
			and		bt_synonym_name	= @engg_cont_btsynname+'__nodexp')		
			begin 
				insert ep_component_glossary_mst (
					customer_name,		project_name,			req_no,				process_name,			component_name,			bt_synonym_name,
					data_type,			length,					bt_synonym_caption,	glossary_sysid,			timestamp,				createdby,
					createddate,		modifiedby,				modifieddate,		ref_bt_synonym_name,	bt_synonym_doc,			bt_name,synonym_status,
					singleinst_sample_data,multiinst_sample_data,wrkreqno)
				select  
					customer_name,		project_name,			req_no,				process_name,			component_name,			column_bt_synonym,
					'Char',				20,						column_bt_synonym,	newid(),				1,						@ctxt_user,
					getdate(),			@ctxt_user,				getdate(),			column_bt_synonym,		column_bt_synonym,		'',
					'R',				null,					null,				'Base'
				from	ep_ui_grid_dtl(nolock)
				where	customer_name		= @engg_customer_name  
				and		project_name		= @engg_project_name  
				and		process_name		= @tmp_proc  
				and		component_name		= @tmp_comp  
				and		activity_name		= @tmp_act  
				and		ui_name				= @tmp_ui  
				and		page_bt_synonym		= @engg_cont_page_bts  
				and		section_bt_synonym	= @engg_cont_sec_bts  
				and		control_bt_synonym	= @engg_cont_btsynname 
				and		column_bt_synonym	= @engg_cont_btsynname+'__nodexp'

				-- Code commented due to EP/RE lng extn purge Starts by 11537
				/*
				insert ep_component_glossary_mst_lng_extn (
					customer_name,			project_name,		req_no,				process_name,			component_name,
					bt_synonym_name,		data_type,			length,				bt_synonym_caption,		glossary_sysid,
					languageid,				timestamp,			createdby,			createddate,			modifiedby,
					modifieddate,			ref_bt_synonym_name,bt_synonym_doc,		bt_name,				synonym_status,
					singleinst_sample_data,	multiinst_sample_data,wrkreqno)
				select  
					a.customer_name,		project_name,		req_no,				process_name,			component_name,
					column_bt_synonym,		'Char',				20,					cast (b.quick_code as varchar (40))+'_'+column_bt_synonym,
					newid(),				b.quick_code,		1,					@ctxt_user,				getdate(),
					@ctxt_user,				getdate(),			column_bt_synonym,	column_bt_synonym,		'',	
					'R',					null,				null,				'Base'
				from	ep_ui_grid_dtl a (nolock) , ep_language_met b (nolock)
				where	a.customer_name		= @engg_customer_name  
				and		project_name		= @engg_project_name  
				and		process_name		= @tmp_proc  
				and		component_name		= @tmp_comp  
				and		activity_name		= @tmp_act  
				and		ui_name				= @tmp_ui  
				and		page_bt_synonym		= @engg_cont_page_bts  
				and		section_bt_synonym	= @engg_cont_sec_bts  
				and		control_bt_synonym	= @engg_cont_btsynname 
				and		column_bt_synonym	= @engg_cont_btsynname+'__nodexp'
				*/
				-- Code commented due to EP/RE lng extn purge Ends by 11537

			end 
		End
	End
End
-- For Row Expander Ends
--Base Control Type Tree Grid Starts
If @modeflag in ('I', 'X', 'U', 'Y')  -- Modeflag Starts
Begin  
	if exists ( select 'x'  
	from    es_comp_ctrl_type_mst_vw (nolock)  
	where   customer_name   = @engg_customer_name  
	and		project_name    = @engg_project_name  
	and		process_name    = @tmp_proc  
	and		component_name  = @tmp_comp  
	and		ctrl_type_name  = @engg_cont_elem_type  
	and		req_no     	    = @engg_base_req_no 
	and		base_ctrl_type	= 'TreeGrid')   -- Tree Grid Starts
	--and		RenderAs		= 'IsTreeGrid')		 
	begin 
		if not exists (select 'x'
		from	ep_ui_Grid_dtl (nolock)
		where	customer_name		= @engg_customer_name
		and		project_name		= @engg_project_name
		and		req_no				= 'Base'
		and		process_name		= @tmp_proc
		and		component_name		= @tmp_comp
		and		activity_name		= @tmp_act
		and		ui_name				= @tmp_ui
		and		page_bt_synonym		= @engg_cont_page_bts
		and		section_bt_synonym	= @engg_cont_sec_bts
		and		control_bt_synonym	= @engg_cont_btsynname
		and		view_name			= '__nodeid')	 
		Begin
			if len (@engg_cont_btsynname) >23
			begin 
				raiserror('Synonym name %s should be less than 24 characters for TreeGrid.',16,1,@engg_cont_btsynname)
				return
			end
		--Exec engg_treecol_prefix	@engg_customer_name, engg_project_name, tmp_comp, @tmp_act, @tmp_ui, @engg_cont_btsynname, @page_prefix_tmp output, @page_prefix_tmp1 output, @page_prefix_tmp2 output

		--select @column_bt_synonym = '__nodeid'
		
		--exec engg_gen_prefix_id @engg_customer_name,@engg_project_name,@tmp_comp,@tmp_act,    
		--@tmp_ui,@column_bt_synonym,'C',6,@page_prefix_tmp output    
		
		--select @column_bt_synonym = '__parentnodeid'
		--exec engg_gen_prefix_id @engg_customer_name,@engg_project_name,@tmp_comp,@tmp_act,    
		--@tmp_ui,@column_bt_synonym,'C',6,@page_prefix_tmp1 output    
		
		--select @column_bt_synonym = '__nodeexpand'
		--exec engg_gen_prefix_id @engg_customer_name,@engg_project_name,@tmp_comp,@tmp_act,    
		--@tmp_ui,@column_bt_synonym,'C',6,@page_prefix_tmp2 output    
		
		
		--insert ep_ui_grid_dtl (customer_name,project_name,req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,
		--	control_bt_synonym,column_bt_synonym,column_type,column_no,grid_sysid,ui_control_sysid,timestamp,createdby,createddate,modifiedby,
		--	modifieddate,control_id,view_name,visible_length,proto_tooltip,sample_data,col_doc,column_prefix,wrkreqno,Set_User_Pref,default_required,
		--	ColumnClass,iskey,Kyseq_no,visible,Forcefit,TemplateID)	
		--select 	@engg_customer_name,@engg_project_name,'Base',@tmp_proc,@tmp_comp,@tmp_act ,@tmp_ui ,@engg_cont_page_bts,@engg_cont_sec_bts,
		--	@engg_cont_btsynname,@page_prefix_tmp+'__nodeid','Edit','1',newid(),newid(),1,@ctxt_user, getdate(),@ctxt_user,
		--	getdate(),@control_id,'__nodeid',null,null,'',@engg_cont_btsynname,@page_prefix_tmp,'','',null,
		--	null,null, null,'NO',null,null
			insert ep_ui_grid_dtl (
				customer_name,			project_name,			req_no,					process_name,			component_name,
				activity_name,			ui_name,				page_bt_synonym,		section_bt_synonym,		control_bt_synonym,
				column_bt_synonym,		column_type,			column_no,				grid_sysid,				ui_control_sysid,
				timestamp,				createdby,				createddate,			modifiedby,				modifieddate,
				control_id,				view_name,				visible_length,			proto_tooltip,			sample_data,
				col_doc,				column_prefix,			wrkreqno,				Set_User_Pref,			default_required,
				ColumnClass,			iskey,					Kyseq_no,				visible,				Forcefit,
				TemplateID)	
			select 	
				@engg_customer_name,	@engg_project_name,		'Base',					@tmp_proc,				@tmp_comp,
				@tmp_act ,				@tmp_ui ,				@engg_cont_page_bts,	@engg_cont_sec_bts,		@engg_cont_btsynname,
				@engg_cont_btsynname+'_nid',
				'Edit',					'1',					newid(),				newid(),				1,
				@ctxt_user,				getdate(),				@ctxt_user,				getdate(),				@control_id,'__nodeid',
				null,					null,					'',						@engg_cont_btsynname,	@page_prefix_tmp,
				'',						'',						null,					null,					null, 
				null,					'NO',					null,					null
			union
			select 	
				@engg_customer_name,	@engg_project_name,		'Base',					@tmp_proc,				@tmp_comp,
				@tmp_act ,				@tmp_ui ,				@engg_cont_page_bts,	@engg_cont_sec_bts,		@engg_cont_btsynname,
				@engg_cont_btsynname+'_pid',
				'Edit',					'2',					newid(),				newid(),				1,
				@ctxt_user,				getdate(),				@ctxt_user,				getdate(),				@control_id,'__parentnodeid',
				null,					null,					'',						@engg_cont_btsynname,	@page_prefix_tmp1,
				'',						'',						null,					null,					null, 
				null,					'NO',					null,					null
			union
			select 	
					@engg_customer_name,	@engg_project_name,		'Base',					@tmp_proc,				@tmp_comp,		
					@tmp_act ,				@tmp_ui ,				@engg_cont_page_bts,	@engg_cont_sec_bts,		@engg_cont_btsynname,
					@engg_cont_btsynname+'_nex',
					'Edit',					'3',					newid(),				newid(),				1,						
					@ctxt_user,				getdate(),				@ctxt_user,getdate(),	@control_id,'__nodeexpand',
					null,					null,					'',						@engg_cont_btsynname,	@page_prefix_tmp2,
					'',						'',						null,					null,					null, 
					null,					'NO',					null,					null


		END

		select	@NodeIconReqd	= isnull(NodeIconReqd,'N') ,
				@NodeIconCls	= isnull(NodeCustomClass,'N')
		from    es_comp_ctrl_type_mst_extn (nolock)  
		where   customer_name   = @engg_customer_name  
		and		project_name    = @engg_project_name  
		and		process_name    = @tmp_proc  
		and		component_name  = @tmp_comp  
		and		ctrl_type_name  = @engg_cont_elem_type  
		and		req_no     	    = @engg_base_req_no 
		and		base_ctrl_type	= 'TreeGrid'

			
		IF isnull(@NodeIconReqd,'N') = 'Y'  
		BEGIN
		if not exists (select 'x' --13705 for TECH-57798
		from	ep_ui_Grid_dtl (nolock)
		where	customer_name		= @engg_customer_name
		and		project_name		= @engg_project_name
		and		req_no				= 'Base'
		and		process_name		= @tmp_proc
		and		component_name		= @tmp_comp
		and		activity_name		= @tmp_act
		and		ui_name				= @tmp_ui
		and		page_bt_synonym		= @engg_cont_page_bts
		and		section_bt_synonym	= @engg_cont_sec_bts
		and		control_bt_synonym	= @engg_cont_btsynname
		and		view_name			= '__icon')	 
		begin 
				insert ep_ui_grid_dtl (
					customer_name,			project_name,			req_no,					process_name,			component_name,
					activity_name,			ui_name,				page_bt_synonym,		section_bt_synonym,		control_bt_synonym,
					column_bt_synonym,		column_type,			column_no,				grid_sysid,				ui_control_sysid,
					timestamp,				createdby,				createddate,			modifiedby,				modifieddate,
					control_id,				view_name,				visible_length,			proto_tooltip,			sample_data,
					col_doc,				column_prefix,			wrkreqno,				Set_User_Pref,			default_required,
					ColumnClass,			iskey,					Kyseq_no,				visible,				Forcefit,
					TemplateID)	
				select 	
					@engg_customer_name,	@engg_project_name,		'Base',					@tmp_proc,				@tmp_comp,		
					@tmp_act ,				@tmp_ui ,				@engg_cont_page_bts,	@engg_cont_sec_bts,		@engg_cont_btsynname,
					@engg_cont_btsynname+'_nic',
					'Edit',					'1001',					newid(),				newid(),				1,						
					@ctxt_user,				getdate(),				@ctxt_user,getdate(),	@control_id,			'__icon',
					null,					null,					'',						@engg_cont_btsynname,	@page_prefix_tmp2,
					'',						'Y',						'N',					null,					null, 
					null,					'NO',					null,					null
		end
		END
		IF isnull(@NodeIconCls,'N') = 'Y'  
		BEGIN
		if not exists (select 'x' --13705 for TECH-57798
		from	ep_ui_Grid_dtl (nolock)
		where	customer_name		= @engg_customer_name
		and		project_name		= @engg_project_name
		and		req_no				= 'Base'
		and		process_name		= @tmp_proc
		and		component_name		= @tmp_comp
		and		activity_name		= @tmp_act
		and		ui_name				= @tmp_ui
		and		page_bt_synonym		= @engg_cont_page_bts
		and		section_bt_synonym	= @engg_cont_sec_bts
		and		control_bt_synonym	= @engg_cont_btsynname
		and		view_name			= '__icls')	 
		begin 
				insert ep_ui_grid_dtl (
					customer_name,			project_name,			req_no,					process_name,			component_name,
					activity_name,			ui_name,				page_bt_synonym,		section_bt_synonym,		control_bt_synonym,
					column_bt_synonym,		column_type,			column_no,				grid_sysid,				ui_control_sysid,
					timestamp,				createdby,				createddate,			modifiedby,				modifieddate,
					control_id,				view_name,				visible_length,			proto_tooltip,			sample_data,
					col_doc,				column_prefix,			wrkreqno,				Set_User_Pref,			default_required,
					ColumnClass,			iskey,					Kyseq_no,				visible,				Forcefit,
					TemplateID)	
				select 	
					@engg_customer_name,	@engg_project_name,		'Base',					@tmp_proc,				@tmp_comp,		
					@tmp_act ,				@tmp_ui ,				@engg_cont_page_bts,	@engg_cont_sec_bts,		@engg_cont_btsynname,
					@engg_cont_btsynname+'_cls',
					'Edit',					'1002',					newid(),				newid(),				1,						
					@ctxt_user,				getdate(),				@ctxt_user,getdate(),	@control_id,			'__icls',
					null,					null,					'',						@engg_cont_btsynname,	@page_prefix_tmp2,
					'',						'Y',						'N',					null,					null, 
					null,					'NO',					null,					null
	    end
		END

		Create table #treegrid_columns (id int identity , column_name varchar(60))		
		Insert #treegrid_columns(Column_name)
		select @engg_cont_btsynname+'_nid'
		union
		select @engg_cont_btsynname+'_pid'
		union
		select @engg_cont_btsynname+'_nex'

		IF isnull(@NodeIconReqd,'') = 'Y'	 
		BEGIN
					Insert #treegrid_columns(Column_name)
						select @engg_cont_btsynname+'_nic'
		END
		IF isnull(@NodeIconCls,'') = 'Y'	 
		BEGIN
			Insert #treegrid_columns(Column_name)
					select @engg_cont_btsynname+'_cls'
		END

		--declare @temp_column_name engg_name , @cnt engg_seqno , @count_stack  engg_seqno 
		set @cnt 			= 1 
		set @count_stack	= 8 
		while ( @count_stack > @cnt )
		begin 
			select	@temp_column_name =column_name
			from	#treegrid_columns
			where	id = @cnt

			exec engg_gen_prefix_id 
				@engg_customer_name,		@engg_project_name,		@tmp_comp,		@tmp_act,		@tmp_ui,		@temp_column_name,
				'C',						6,						@page_prefix_tmp output 

			update	ep_ui_grid_dtl
			set		column_prefix	= @page_prefix_tmp
			where	customer_name	= @engg_customer_name  
			and		project_name	= @engg_project_name  
			and		process_name	= @tmp_proc  
			and		component_name	= @tmp_comp  
			and		activity_name	= @tmp_act  
			and		ui_name			= @tmp_ui  
			and		page_bt_synonym = @engg_cont_page_bts  
			and		section_bt_synonym = @engg_cont_sec_bts  
			and		control_bt_synonym = @engg_cont_btsynname 
			and		column_bt_synonym  = @temp_column_name

			set @cnt  = @cnt +1
		end
		drop table #treegrid_columns

		if not exists   (   select 'X' 
							from	ep_component_glossary_mst(nolock)
							where	customer_name	= @engg_customer_name	
							and		project_name	= @engg_project_name	
							and		process_name	= @tmp_proc				
							and		component_name	= @tmp_comp
							and		bt_synonym_name	= @engg_cont_btsynname+'_nid') 
		begin 
					insert ep_component_glossary_mst (
						customer_name,		project_name,		req_no,				process_name,		component_name,			bt_synonym_name,
						data_type,			length,				bt_synonym_caption, glossary_sysid,		timestamp,				createdby,
						createddate,		modifiedby,			modifieddate,		ref_bt_synonym_name,bt_synonym_doc,			bt_name,
						synonym_status,		singleinst_sample_data,multiinst_sample_data,wrkreqno)
					select  
						customer_name,		project_name,		req_no,				process_name,		component_name,			column_bt_synonym,
						'Char',				20,					column_bt_synonym,	newid(),			1,						@ctxt_user,
						getdate(),			@ctxt_user,			getdate(),			column_bt_synonym,	column_bt_synonym,		'',
						'R',				null,				null,				'Base'
					from	ep_ui_grid_dtl(nolock)
					where	customer_name	= @engg_customer_name  
					and		project_name	= @engg_project_name  
					and		process_name	= @tmp_proc  
					and		component_name	= @tmp_comp  
					and		activity_name	= @tmp_act  
					and		ui_name			= @tmp_ui  
					and		page_bt_synonym = @engg_cont_page_bts  
					and		section_bt_synonym = @engg_cont_sec_bts  
					and		control_bt_synonym = @engg_cont_btsynname 

					-- Code commented due to EP/RE lng extn purge Starts by 11537
					/*
					insert ep_component_glossary_mst_lng_extn (
						customer_name,		project_name,		req_no,				process_name,		component_name,			bt_synonym_name,
						data_type,			length,				bt_synonym_caption, glossary_sysid,		languageid,				timestamp,
						createdby,			createddate,		modifiedby,			modifieddate,		ref_bt_synonym_name,	bt_synonym_doc,
						bt_name,			synonym_status,		singleinst_sample_data,multiinst_sample_data,wrkreqno)
					select  
						a.customer_name,	project_name,		req_no,				process_name,		component_name,			column_bt_synonym,
						'Char',				20,					cast (b.quick_code as varchar (40))+'_'+column_bt_synonym,
						newid(),			b.quick_code,		1,					@ctxt_user,			getdate(),				@ctxt_user,
						getdate(),			column_bt_synonym,	column_bt_synonym,	'',					'R',					null,
						null,				'Base'
					from	ep_ui_grid_dtl a (nolock) , 
							ep_language_met b (nolock)
					where	a.customer_name		= @engg_customer_name  
					and		project_name		= @engg_project_name  
					and		process_name		= @tmp_proc  
					and		component_name		= @tmp_comp  
					and		activity_name		= @tmp_act  
					and		ui_name				= @tmp_ui  
					and		page_bt_synonym		= @engg_cont_page_bts  
					and		section_bt_synonym	= @engg_cont_sec_bts  
					and		control_bt_synonym	= @engg_cont_btsynname 
					*/
					-- Code commented due to EP/RE lng extn purge Ends by 11537
		end 

		if not exists   (   select 'X' 
							from	ep_component_glossary_mst(nolock)
							where	customer_name	= @engg_customer_name	
							and		project_name	= @engg_project_name	
							and		process_name	= @tmp_proc				
							and		component_name	= @tmp_comp
							and		bt_synonym_name	= @engg_cont_btsynname+'_nic')	AND isnull(@NodeIconReqd,'N') = 'Y'   --Fail
		begin 
					insert ep_component_glossary_mst (
						customer_name,		project_name,		req_no,				process_name,		component_name,			bt_synonym_name,
						data_type,			length,				bt_synonym_caption, glossary_sysid,		timestamp,				createdby,
						createddate,		modifiedby,			modifieddate,		ref_bt_synonym_name,bt_synonym_doc,			bt_name,
						synonym_status,		singleinst_sample_data,multiinst_sample_data,wrkreqno)
					select  
						customer_name,		project_name,		req_no,				process_name,		component_name,			column_bt_synonym,
						'Char',				20,					column_bt_synonym,	newid(),			1,						@ctxt_user,
						getdate(),			@ctxt_user,			getdate(),			column_bt_synonym,	column_bt_synonym,		'',
						'R',				null,				null,				'Base'
					from	ep_ui_grid_dtl(nolock)
					where	customer_name	= @engg_customer_name  
					and		project_name	= @engg_project_name  
					and		process_name	= @tmp_proc  
					and		component_name	= @tmp_comp  
					and		activity_name	= @tmp_act  
					and		ui_name			= @tmp_ui  
					and		page_bt_synonym = @engg_cont_page_bts  
					and		section_bt_synonym = @engg_cont_sec_bts  
					and		control_bt_synonym = @engg_cont_btsynname 
					and		column_bt_synonym = @engg_cont_btsynname + '_nic'

					-- Code commented due to EP/RE lng extn purge Starts by 11537
					/*
					insert ep_component_glossary_mst_lng_extn (
						customer_name,		project_name,		req_no,				process_name,		component_name,			bt_synonym_name,
						data_type,			length,				bt_synonym_caption, glossary_sysid,		languageid,				timestamp,
						createdby,			createddate,		modifiedby,			modifieddate,		ref_bt_synonym_name,	bt_synonym_doc,
						bt_name,			synonym_status,		singleinst_sample_data,multiinst_sample_data,wrkreqno)
					select  
						a.customer_name,	project_name,		req_no,				process_name,		component_name,			column_bt_synonym,
						'Char',				20,					cast (b.quick_code as varchar (40))+'_'+column_bt_synonym,
						newid(),			b.quick_code,		1,					@ctxt_user,			getdate(),				@ctxt_user,
						getdate(),			column_bt_synonym,	column_bt_synonym,	'',					'R',					null,
						null,				'Base'
					from	ep_ui_grid_dtl a (nolock) , 
							ep_language_met b (nolock)
					where	a.customer_name		= @engg_customer_name  
					and		project_name		= @engg_project_name  
					and		process_name		= @tmp_proc  
					and		component_name		= @tmp_comp  
					and		activity_name		= @tmp_act  
					and		ui_name				= @tmp_ui  
					and		page_bt_synonym		= @engg_cont_page_bts  
					and		section_bt_synonym	= @engg_cont_sec_bts  
					and		control_bt_synonym	= @engg_cont_btsynname 
					and		column_bt_synonym = @engg_cont_btsynname + '_nic'
					*/
					-- Code commented due to EP/RE lng extn purge Ends by 11537
		end 

		if not exists   (  select 'X' 
							from	ep_component_glossary_mst(nolock)
							where	customer_name	= @engg_customer_name	
							and		project_name	= @engg_project_name	
							and		process_name	= @tmp_proc				
							and		component_name	= @tmp_comp
							and		bt_synonym_name	= @engg_cont_btsynname+'_cls')	AND ISNULL(@NodeIconCls, 'N') = 'Y'			--Fail
		begin 
					insert ep_component_glossary_mst (
						customer_name,		project_name,		req_no,				process_name,		component_name,			bt_synonym_name,
						data_type,			length,				bt_synonym_caption, glossary_sysid,		timestamp,				createdby,
						createddate,		modifiedby,			modifieddate,		ref_bt_synonym_name,bt_synonym_doc,			bt_name,
						synonym_status,		singleinst_sample_data,multiinst_sample_data,wrkreqno)
					select  
						customer_name,		project_name,		req_no,				process_name,		component_name,			column_bt_synonym,
						'Char',				20,					column_bt_synonym,	newid(),			1,						@ctxt_user,
						getdate(),			@ctxt_user,			getdate(),			column_bt_synonym,	column_bt_synonym,		'',
						'R',				null,				null,				'Base'
					from	ep_ui_grid_dtl(nolock)
					where	customer_name	= @engg_customer_name  
					and		project_name	= @engg_project_name  
					and		process_name	= @tmp_proc  
					and		component_name	= @tmp_comp  
					and		activity_name	= @tmp_act  
					and		ui_name			= @tmp_ui  
					and		page_bt_synonym = @engg_cont_page_bts  
					and		section_bt_synonym = @engg_cont_sec_bts  
					and		control_bt_synonym = @engg_cont_btsynname 
					and		column_bt_synonym = @engg_cont_btsynname + '_cls'

					-- Code commented due to EP/RE lng extn purge Starts by 11537
					/*
					insert ep_component_glossary_mst_lng_extn (
						customer_name,		project_name,		req_no,				process_name,		component_name,			bt_synonym_name,
						data_type,			length,				bt_synonym_caption, glossary_sysid,		languageid,				timestamp,
						createdby,			createddate,		modifiedby,			modifieddate,		ref_bt_synonym_name,	bt_synonym_doc,
						bt_name,			synonym_status,		singleinst_sample_data,multiinst_sample_data,wrkreqno)
					select  
						a.customer_name,	project_name,		req_no,				process_name,		component_name,			column_bt_synonym,
						'Char',				20,					cast (b.quick_code as varchar (40))+'_'+column_bt_synonym,
						newid(),			b.quick_code,		1,					@ctxt_user,			getdate(),				@ctxt_user,
						getdate(),			column_bt_synonym,	column_bt_synonym,	'',					'R',					null,
						null,				'Base'
					from	ep_ui_grid_dtl a (nolock) , 
							ep_language_met b (nolock)
					where	a.customer_name		= @engg_customer_name  
					and		project_name		= @engg_project_name  
					and		process_name		= @tmp_proc  
					and		component_name		= @tmp_comp  
					and		activity_name		= @tmp_act  
					and		ui_name				= @tmp_ui  
					and		page_bt_synonym		= @engg_cont_page_bts  
					and		section_bt_synonym	= @engg_cont_sec_bts  
					and		control_bt_synonym	= @engg_cont_btsynname 
					and		column_bt_synonym = @engg_cont_btsynname + '_cls'
					*/
					-- Code commented due to EP/RE lng extn purge Ends by 11537

			end 
	--	end -- Tree Grid Ends
		-- Event Generation starts
		If exists (select 'x'
		from	es_ctrl_type_events_mst (nolock)
		where	customer_name   = @engg_customer_name  
		and		project_name    = @engg_project_name  
		and		process_name    = @tmp_proc  
		and		component_name  = @tmp_comp  
		and		ctrl_type_name  = @engg_cont_elem_type  
			--and		req_no		= @engg_base_req_no 
		and		@base_ctrl_type_tmp in ('TreeGrid'))   
		Begin
			Exec ep_layout_save_events_gen 
				@ctxt_language,			@ctxt_ouinstance,		@ctxt_service,			@ctxt_user,			@engg_customer_name,
				@engg_project_name,		@tmp_proc,				@tmp_comp,				@tmp_act,			@tmp_ui,		
				@engg_cont_page_bts,	@engg_cont_sec_bts,		@engg_cont_btsynname,	@engg_base_req_no,	@engg_cont_elem_type,
				@base_ctrl_type_tmp,	'',			'',			@m_errorid out
		End
		-- Event Generation Ends
	End -- TreeGrid enda
	-- Organization Chart Starts
	if exists ( select 'x'  
	from    es_comp_ctrl_type_mst_extn (nolock)  
	where   customer_name			= @engg_customer_name  
	and		project_name			= @engg_project_name  
	and		process_name			= @tmp_proc  
	and		component_name			= @tmp_comp  
	and		ctrl_type_name			= @engg_cont_elem_type  
	and		req_no     				= @engg_base_req_no 
	and		base_ctrl_type			= 'TreeGrid'
	and		isnull(IsOrgChart,'')	= 'Y')  
	begin 
		if not exists (select 'x'
		from	ep_ui_Grid_dtl (nolock)
		where	customer_name		= @engg_customer_name
		and		project_name		= @engg_project_name
		and		req_no				= 'Base'
		and		process_name		= @tmp_proc
		and		component_name		= @tmp_comp
		and		activity_name		= @tmp_act
		and		ui_name				= @tmp_ui
		and		page_bt_synonym		= @engg_cont_page_bts
		and		section_bt_synonym	= @engg_cont_sec_bts
		and		control_bt_synonym	= @engg_cont_btsynname
		and		view_name			= '__nodetype')
		Begin
			select @page_prefix_tmp2	= ''
			select @column_bt_synonym	= '__nodetype'
			exec engg_gen_prefix_id 
					@engg_customer_name,	@engg_project_name,		@tmp_comp,		@tmp_act,		@tmp_ui,		@column_bt_synonym,
					'C',					6,						@page_prefix_tmp2 output   

			insert ep_ui_grid_dtl (
					customer_name,			project_name,		req_no,				process_name,			component_name,			activity_name,
					ui_name,				page_bt_synonym,	section_bt_synonym,	control_bt_synonym,		column_bt_synonym,		column_type,
					column_no,				grid_sysid,			ui_control_sysid,	timestamp,				createdby,				createddate,
					modifiedby,				modifieddate,		control_id,view_name,visible_length,		proto_tooltip,			sample_data,
					col_doc,				column_prefix,		wrkreqno,			Set_User_Pref,			default_required,		ColumnClass,
					iskey,					Kyseq_no,			visible,			Forcefit,				TemplateID)	
			select 	
					@engg_customer_name,	@engg_project_name,	'Base',				@tmp_proc,				@tmp_comp,				@tmp_act ,
					@tmp_ui ,				@engg_cont_page_bts,@engg_cont_sec_bts,	@engg_cont_btsynname,	@page_prefix_tmp2+'__nodetype',
					'Edit',					'4',				newid(),			newid(),				1,						@ctxt_user, 
					getdate(),				@ctxt_user,			getdate(),			@control_id,			'__nodetype',			null,
					null,					'',					@engg_cont_btsynname,@page_prefix_tmp2,		'',						'',
					null,					null,				null,				null,					'NO',					null,
					null
			
				if not exists   (  select 'X' 
				from	ep_component_glossary_mst(nolock)
				where	customer_name	= @engg_customer_name	
				and		project_name	= @engg_project_name	
				and		process_name	= @tmp_proc				
				and		component_name	= @tmp_comp
				and		bt_synonym_name	= @page_prefix_tmp2+'__nodetype')		
				begin 
					insert ep_component_glossary_mst (
							customer_name,				project_name,			req_no,			process_name,			component_name,
							bt_synonym_name,			data_type,				length,			bt_synonym_caption,		glossary_sysid,
							timestamp,					createdby,				createddate,	modifiedby,				modifieddate,
							ref_bt_synonym_name,		bt_synonym_doc,			bt_name,		synonym_status,			singleinst_sample_data,
							multiinst_sample_data,		wrkreqno)
					select  
							customer_name,				project_name,			req_no,			process_name,			component_name,
							column_bt_synonym,			'Char',					20,				column_bt_synonym,		newid(),
							1,							@ctxt_user,				getdate(),		@ctxt_user,				getdate(),
							column_bt_synonym,			column_bt_synonym,		'',				'R',					null,
							null,						'Base'
					from	ep_ui_grid_dtl(nolock)
					where	customer_name	= @engg_customer_name  
					and		project_name	= @engg_project_name  
					and		process_name	= @tmp_proc  
					and		component_name	= @tmp_comp  
					and		activity_name	= @tmp_act  
					and		ui_name			= @tmp_ui  
					and		page_bt_synonym = @engg_cont_page_bts  
					and		section_bt_synonym = @engg_cont_sec_bts  
					and		control_bt_synonym = @engg_cont_btsynname 
					and		column_bt_synonym  = @page_prefix_tmp2+'__nodetype'

					-- Code commented due to EP/RE lng extn purge Starts by 11537
					/*
					insert ep_component_glossary_mst_lng_extn (
							customer_name,		project_name,		req_no,				process_name,		component_name,			bt_synonym_name,
							data_type,			length,				bt_synonym_caption,	
							glossary_sysid,		languageid,			timestamp,			createdby,			createddate,			modifiedby,			
							modifieddate,		ref_bt_synonym_name,bt_synonym_doc,		bt_name,			synonym_status,			singleinst_sample_data,
							multiinst_sample_data,wrkreqno)
					select  
							a.customer_name,	project_name,		req_no,				process_name,		component_name,			column_bt_synonym,
							'Char',				20,					cast (b.quick_code as varchar (40))+'_'+column_bt_synonym,
							newid(),			b.quick_code,		1,					@ctxt_user,			getdate(),				@ctxt_user,
							getdate(),			column_bt_synonym,	column_bt_synonym,	'',					'R',					null,
							null,				'Base'
					from	ep_ui_grid_dtl a (nolock) , 
							ep_language_met b (nolock)
					where	a.customer_name		= @engg_customer_name  
					and		project_name		= @engg_project_name  
					and		process_name		= @tmp_proc  
					and		component_name		= @tmp_comp  
					and		activity_name		= @tmp_act  
					and		ui_name				= @tmp_ui  
					and		page_bt_synonym		= @engg_cont_page_bts  
					and		section_bt_synonym	= @engg_cont_sec_bts  
					and		control_bt_synonym	= @engg_cont_btsynname 
					and		column_bt_synonym	= @page_prefix_tmp2+'__nodetype'
					*/
					-- Code commented due to EP/RE lng extn purge Ends by 11537

				end 
			End
		end	-- Organization Chart End	
	end  -- Modeflag Ends
--Base Control Type Tree Grid Starts

Declare	@multiselect engg_flag

SELECT @CreatingFor = ''

-- Added for Rule Builder & Calendar Starts Defect ID: TECH-35368
If @modeflag in ('I', 'X', 'U', 'Y')  -- Modeflag Starts
Begin
		
	if exists ( select 'x'  
	from    es_comp_ctrl_type_mst_vw (nolock)  
	where   customer_name   = @engg_customer_name  
	and		project_name    = @engg_project_name  
	and		process_name    = @tmp_proc  
	and		component_name  = @tmp_comp  
	and		ctrl_type_name  = @engg_cont_elem_type  
	and		req_no     	    = @engg_base_req_no 
	and		renderas		= 'RB_METADATA')	 
	Begin

		SELECT	@multiselect	= ISNULL(MultiSelectComboforRB, 'N')
		FROM	es_comp_ctrl_type_mst_extn (nolock)
		where   customer_name   = @engg_customer_name  
		and		project_name    = @engg_project_name  
		and		process_name    = @tmp_proc  
		and		component_name  = @tmp_comp  
		and		ctrl_type_name  = @engg_cont_elem_type  

		IF	ISNULL(@multiselect, 'N')	= 'Y'
			SELECT	@CreatingFor		= 'RulebuilderMS'
		ELSE 
			SELECT	@CreatingFor		= 'Rulebuilder'
	END

	if exists ( select 'x'  
	from    es_comp_ctrl_type_mst_vw (nolock)  
	where   customer_name   = @engg_customer_name  
	and		project_name    = @engg_project_name  
	and		process_name    = @tmp_proc  
	and		component_name  = @tmp_comp  
	and		ctrl_type_name  = @engg_cont_elem_type  
	and		req_no     	    = @engg_base_req_no 
	and		renderas		= 'Calendar_event')	 
	Begin
		SELECT	@CreatingFor		= 'Calendar'
	END

	-- Added for the Defect ID: TECH-37471 Starts for Gantt Control

	if exists ( select 'x'  
	from    es_comp_ctrl_type_mst_vw (nolock)  
	where   customer_name   = @engg_customer_name  
	and		project_name    = @engg_project_name  
	and		process_name    = @tmp_proc  
	and		component_name  = @tmp_comp  
	and		ctrl_type_name  = @engg_cont_elem_type  
	and		req_no     	    = @engg_base_req_no 
	and		base_Ctrl_Type	= 'TreeGrid'
	and		renderas		= 'GANTT')	 
	Begin
		SELECT	@CreatingFor		= 'Gantt'
	END


	IF @CreatingFor IN ('RulebuilderMS', 'Rulebuilder',  'Calendar' , 'Gantt') 
	BEGIN
		UPDATE es_comp_ctrl_type_mst SET
						visisble_rows	= 5000
		WHERE	customer_name			= @engg_customer_name
		AND		project_name			= @engg_project_name
		AND		req_no					= @engg_base_req_no
		AND		process_name			= @tmp_proc
		AND		component_name			= @tmp_comp
		AND		ctrl_type_name			= @engg_cont_elem_type  
		AND		renderas				= 'RB_METADATA'
	
		UPDATE es_comp_ctrl_type_mst SET
						visisble_rows	= 33
		WHERE	customer_name			= @engg_customer_name
		AND		project_name			= @engg_project_name
		AND		req_no					= @engg_base_req_no
		AND		process_name			= @tmp_proc
		AND		component_name			= @tmp_comp
		AND		ctrl_type_name			= @engg_cont_elem_type  
		AND		renderas				LIKE 'Calendar_%'

		Exec ep_BTcreation_sp
								@ctxt_OUInstance			= @ctxt_OUInstance,
								@ctxt_User					= @ctxt_User,
								@ctxt_Language				= @ctxt_Language,
								@ctxt_Service				= @ctxt_Service,
								@engg_customer_name			= @engg_customer_name,
								@engg_project_name			= @engg_project_name,
								@engg_process_name			= @tmp_proc,
								@engg_component_name		= @tmp_comp,
								@engg_controltype_name		= @engg_cont_elem_type,								
								@engg_req_no				= @engg_req_no,								
								@CreatingFor				= @CreatingFor,
								@m_errorid					= @m_errorid output
	
		Exec ep_controltypecreation_sp
								@ctxt_OUInstance			= @ctxt_OUInstance,
								@ctxt_User					= @ctxt_User,
								@ctxt_Language				= @ctxt_Language,
								@ctxt_Service				= @ctxt_Service,
								@engg_customer_name			= @engg_customer_name,
								@engg_project_name			= @engg_project_name,
								@engg_process_name			= @tmp_proc,
								@engg_component_name		= @tmp_comp,
								@engg_controltype_name		= @engg_cont_elem_type,								
								@engg_req_no				= @engg_req_no,								
								@CreatingFor				= @CreatingFor,
								@m_errorid					= @m_errorid output
		
		IF @multiselect	= 'Y'
		BEGIN
		
			Exec ep_controlcreation_sp
									@ctxt_OUInstance			= @ctxt_OUInstance,
									@ctxt_User					= @ctxt_User,
									@ctxt_Language				= @ctxt_Language,
									@ctxt_Service				= @ctxt_Service,
									@engg_customer_name			= @engg_customer_name,
									@engg_project_name			= @engg_project_name,
									@engg_process_name			= @tmp_proc,
									@engg_component_name		= @tmp_comp,
									@engg_activity_name			= @tmp_act,
									@engg_ui_name				= @tmp_ui,
									@engg_page_name				= @engg_cont_page_bts,
									@engg_section_name			= @engg_cont_sec_bts,
									@engg_control_name			= @engg_cont_btsynname,
									@engg_req_no				= @engg_req_no,
									@ModeFlag					= @ModeFlag,
									@CreatingFor				= @CreatingFor,
									@m_errorid					= @m_errorid output
		END
		ELSE
		BEGIN
		
			Exec ep_controlcreation_sp
									@ctxt_OUInstance			= @ctxt_OUInstance,
									@ctxt_User					= @ctxt_User,
									@ctxt_Language				= @ctxt_Language,
									@ctxt_Service				= @ctxt_Service,
									@engg_customer_name			= @engg_customer_name,
									@engg_project_name			= @engg_project_name,
									@engg_process_name			= @tmp_proc,
									@engg_component_name		= @tmp_comp,
									@engg_activity_name			= @tmp_act,
									@engg_ui_name				= @tmp_ui,
									@engg_page_name				= @engg_cont_page_bts,
									@engg_section_name			= @engg_cont_sec_bts,
									@engg_control_name			= @engg_cont_btsynname,
									@engg_req_no				= @engg_req_no,
									@ModeFlag					= @ModeFlag,
									@CreatingFor				= @CreatingFor,
									@m_errorid					= @m_errorid output
		END
		IF @multiselect	= 'Y'
		BEGIN
		
			Exec ep_columncreation_sp
								@ctxt_OUInstance			= @ctxt_OUInstance,
								@ctxt_User					= @ctxt_User,
								@ctxt_Language				= @ctxt_Language,
								@ctxt_Service				= @ctxt_Service,
								@engg_customer_name			= @engg_customer_name,
								@engg_project_name			= @engg_project_name,
								@engg_process_name			= @tmp_proc,
								@engg_component_name		= @tmp_comp,
								@engg_activity_name			= @tmp_act,
								@engg_ui_name				= @tmp_ui,
								@engg_page_name				= @engg_cont_page_bts,
								@engg_section_name			= @engg_cont_sec_bts,
								@engg_control_name			= @engg_cont_btsynname,
								@engg_column_name			= '',
								@engg_req_no				= @engg_req_no,
								@ModeFlag					= @ModeFlag,
								@CreatingFor				= @CreatingFor,
								@m_errorid					= @m_errorid output
		END
		ELSE
		BEGIN
			Exec ep_columncreation_sp
								@ctxt_OUInstance			= @ctxt_OUInstance,
								@ctxt_User					= @ctxt_User,
								@ctxt_Language				= @ctxt_Language,
								@ctxt_Service				= @ctxt_Service,
								@engg_customer_name			= @engg_customer_name,
								@engg_project_name			= @engg_project_name,
								@engg_process_name			= @tmp_proc,
								@engg_component_name		= @tmp_comp,
								@engg_activity_name			= @tmp_act,
								@engg_ui_name				= @tmp_ui,
								@engg_page_name				= @engg_cont_page_bts,
								@engg_section_name			= @engg_cont_sec_bts,
								@engg_control_name			= @engg_cont_btsynname,
								@engg_column_name			= '',
								@engg_req_no				= @engg_req_no,
								@ModeFlag					= @ModeFlag,
								@CreatingFor				= @CreatingFor,
								@m_errorid					= @m_errorid output
		END

		Select @engg_btsynonym = @engg_cont_btsynname + '_SQL'

		if not exists(  select 'x'
		from	ep_component_glossary_mst (nolock)
		where	customer_name		= @engg_customer_name
		and		project_name		= @engg_project_name
		and		req_no				= @engg_base_req_no
		and		process_name		= @tmp_proc
		and		component_name		= @tmp_comp
		and		bt_synonym_name		= @engg_btsynonym)
		begin
			
				
			exec ep_component_glossary_mst_sp_ins
												@ctxt_language,
												@ctxt_ouinstance,
												@ctxt_service,
												@ctxt_user,
												@engg_customer_name,
												@engg_project_name,									
												@engg_base_req_no,
												@tmp_proc,
												@tmp_comp,
												@engg_btsynonym,
												null,
												'Char',
												@btLength ,
												@engg_btsynonym,
												@engg_btsynonym,
												'' ,
												'U',
												'',
												'',
												1,
												@engg_req_no,
												@m_errorid out
					if @m_errorid <> 0
					return
		end

		UPDATE ep_ui_grid_dtl SET
						TreeColumn		= 'Y'
		WHERE	Customer_name			=	@engg_customer_name
		AND		Project_name			=	@engg_project_name
		AND		Process_name			=	@tmp_proc
		AND		Component_name			=	@tmp_comp
		AND		Activity_name			=	@tmp_act
		AND		Ui_name					=	@tmp_ui
		AND		Page_bt_synonym			=	@engg_cont_page_bts
		AND		Section_bt_synonym		=	@engg_cont_sec_bts
		AND		Control_bt_synonym		=	@engg_cont_btsynname
		and		View_name				=	'taskid'		

	End
END
-- Added for Rule Builder & Calendar Ends Defect ID: TECH-35368

-- Added for the Defect ID: TECH-37471 Starts for Set & Leave focus Events

		EXEC ep_set_leave_focusevent_ins_sp
								@ctxt_language, 	@ctxt_ouinstance,		@ctxt_service,			@ctxt_user,		@engg_customer_name,	@engg_project_name,
								@engg_base_req_no,	@tmp_proc,				@tmp_comp,				@tmp_act,		@tmp_ui,				@engg_cont_page_bts,
								@engg_cont_sec_bts,	@engg_cont_btsynname,	'',						@engg_cont_elem_type,	@modeflag,		@m_errorid OUT
	
-- Added for the Defect ID: TECH-37471 Endss for Set & Leave focus Events

		
IF EXISTS ( SELECT 'X'
FROM	ep_ui_section_dtl (nolock)
WHERE	customer_name			= @engg_customer_name
AND		project_name			= @engg_project_name
AND		req_no					= @engg_base_req_no
AND		process_name			= @tmp_proc
AND		component_name			= @tmp_comp
AND		activity_name			= @tmp_act
AND		ui_name					= @tmp_ui
AND		page_bt_synonym			= @engg_cont_page_bts
AND		section_bt_synonym		= @engg_cont_sec_bts
AND		section_type			= 'ListItem'
) AND  @modeflag in ('I', 'X', 'U', 'Y' )
 AND @engg_dynamicstyle = '1'
	
BEGIN

		EXEC Hiddenview_Creation_sp
								@ctxt_ouinstance				= @ctxt_ouinstance,
								@ctxt_user						= @ctxt_user,
								@ctxt_language					= @ctxt_language,
								@ctxt_service					= @ctxt_service,								
								@engg_customer					= @engg_customer_name,
								@engg_project					= @engg_project_name,
								@engg_ProcessName				= @tmp_proc,
								@engg_componentname				= @tmp_comp,
								@engg_activityname				= @tmp_act,
								@engg_uiname					= @tmp_ui,
								@engg_pagesynonym				= @engg_cont_page_bts,
								@engg_sectionsynonym			= @engg_cont_sec_bts,
								@engg_controlsynonym			= @engg_cont_btsynname,								
								@creatingFor					= 'ListItemMobility',
								@m_errorid						= @m_errorid output
END
ELSE IF EXISTS ( SELECT 'X'
FROM	ep_ui_section_dtl (nolock)
WHERE	customer_name			= @engg_customer_name
AND		project_name			= @engg_project_name
AND		req_no					= @engg_base_req_no
AND		process_name			= @tmp_proc
AND		component_name			= @tmp_comp
AND		activity_name			= @tmp_act
AND		ui_name					= @tmp_ui
AND		page_bt_synonym			= @engg_cont_page_bts
AND		section_bt_synonym		= @engg_cont_sec_bts
AND		section_type			= 'ListItem'
) AND  @modeflag in ('I', 'X', 'U', 'Y' )
 AND @engg_dynamicstyle = '0'
	
BEGIN

		DELETE 
		FROM	de_hidden_view
		WHERE	customer_name			= @engg_customer_name
		AND		project_name			= @engg_project_name		
		AND		process_name			= @tmp_proc
		AND		component_name			= @tmp_comp
		AND		activity_name			= @tmp_act
		AND		ui_name					= @tmp_ui
		AND		page_name				= @engg_cont_page_bts
		AND		section_name			= @engg_cont_sec_bts
		AND		control_bt_synonym		= @engg_cont_btsynname

		DELETE 
		FROM	ep_nativeapp_mapping
		WHERE	customer_name			= @engg_customer_name
		AND		project_name			= @engg_project_name		
		AND		process_name			= @tmp_proc
		AND		component_name			= @tmp_comp
		AND		activity_name			= @tmp_act
		AND		ui_name					= @tmp_ui
		AND		page_bt_synonym			= @engg_cont_page_bts
		AND		section_bt_synonym		= @engg_cont_sec_bts
		AND		control_Hidden_bt_synonym= @engg_cont_btsynname + '_style'

END

IF @modeflag = 'D' AND @engg_dynamicstyle = '1'
BEGIN
	DELETE FROM de_hidden_View
	WHERE	customer_name			= @engg_customer_name
	AND		project_name			= @engg_project_name	
	AND		process_name			= @tmp_proc
	AND		component_name			= @tmp_comp
	AND		activity_name			= @tmp_act
	AND		ui_name					= @tmp_ui
	AND		page_name				= @engg_cont_page_bts
	AND		section_name			= @engg_cont_sec_bts
	AND		control_bt_synonym		= @engg_cont_btsynname
END

-- **********

IF @modeflag = 'D' AND ISNULL(@Icon_class,'') = 'Dynamic'
BEGIN
	DELETE FROM de_hidden_View
	WHERE	customer_name			= @engg_customer_name
	AND		project_name			= @engg_project_name	
	AND		process_name			= @tmp_proc
	AND		component_name			= @tmp_comp
	AND		activity_name			= @tmp_act
	AND		ui_name					= @tmp_ui
	AND		page_name				= @engg_cont_page_bts
	AND		section_name			= @engg_cont_sec_bts
	AND		control_bt_synonym		= @engg_cont_btsynname
END

IF ISNULL(@Icon_class,'') = 'Dynamic'  AND @modeflag <> 'D' 
BEGIN

		EXEC Hiddenview_Creation_sp
								@ctxt_ouinstance				= @ctxt_ouinstance,
								@ctxt_user						= @ctxt_user,
								@ctxt_language					= @ctxt_language,
								@ctxt_service					= @ctxt_service,								
								@engg_customer					= @engg_customer_name,
								@engg_project					= @engg_project_name,
								@engg_ProcessName				= @tmp_proc,
								@engg_componentname				= @tmp_comp,
								@engg_activityname				= @tmp_act,
								@engg_uiname					= @tmp_ui,
								@engg_pagesynonym				= @engg_cont_page_bts,
								@engg_sectionsynonym			= @engg_cont_sec_bts,
								@engg_controlsynonym			= @engg_cont_btsynname,								
								@creatingFor					= 'DynamicIconClass',
								@m_errorid						= @m_errorid output
END
ELSE IF ISNULL(@Icon_class,'') <> 'Dynamic' and  ISNULL(@Icon_class,'') = ''
	
BEGIN

		DELETE 
		FROM	de_hidden_view
		WHERE	customer_name			= @engg_customer_name
		AND		project_name			= @engg_project_name		
		AND		process_name			= @tmp_proc
		AND		component_name			= @tmp_comp
		AND		activity_name			= @tmp_act
		AND		ui_name					= @tmp_ui
		AND		page_name				= @engg_cont_page_bts
		AND		section_name			= @engg_cont_sec_bts
		AND		control_bt_synonym		= @engg_cont_btsynname
		AND		hidden_view_bt_synonym	LIKE 'hdiDIC%'

END

	SELECT	@selectionreqdforList	= ISNULL(IsSelectionReqdList, 'N')
	FROM	es_comp_ctrl_type_mst_extn (nolock)
	WHERE	customer_name	= @engg_customer_name
	AND		project_name	= @engg_project_name
	AND		process_name	= @tmp_proc
	AND		component_name	= @tmp_comp
	AND		ctrl_type_name	= @engg_cont_elem_type
	AND		Base_ctrl_type	= @tmp_ctl

IF ISNULL(@selectionreqdforList, 'N') = 'Y' AND @Modeflag <> 'D'
	BEGIN
	
			Exec ep_columncreation_sp
								@ctxt_OUInstance			= @ctxt_OUInstance,
								@ctxt_User					= @ctxt_User,
								@ctxt_Language				= @ctxt_Language,
								@ctxt_Service				= @ctxt_Service,
								@engg_customer_name			= @engg_customer_name,
								@engg_project_name			= @engg_project_name,
								@engg_process_name			= @tmp_proc,
								@engg_component_name		= @tmp_comp,
								@engg_activity_name			= @tmp_act,
								@engg_ui_name				= @tmp_ui,
								@engg_page_name				= @engg_cont_page_bts,
								@engg_section_name			= @engg_cont_sec_bts,
								@engg_control_name			= @engg_cont_btsynname,
								@engg_column_name			= '',
								@engg_req_no				= 'BASE',
								@ModeFlag					= @ModeFlag,
								@CreatingFor				= 'ListItemType',
								@m_errorid					= @m_errorid output
	END
-- For MobileGrid
		IF EXISTS (SELECT 'x'
		FROM	es_comp_ctrl_type_mst_extn extn (NOLOCK) 
		JOIN	es_comp_ctrl_type_mst mst (NOLOCK)	--Tech-75230
		ON		mst.customer_name	=	extn.customer_name
		AND		mst.project_name	=	extn.project_name
		AND		mst.process_name	=	extn.process_name
		AND		mst.component_name	=	extn.component_name
		AND		mst.ctrl_type_name	=	extn.ctrl_type_name
		AND		mst.base_ctrl_type	=	extn.base_ctrl_type
		WHERE	mst.customer_name	= @engg_customer_name
		AND		mst.project_name	= @engg_project_name
		AND		mst.req_no			= @engg_base_req_no
		AND		mst.process_name	= @tmp_proc
		AND		mst.component_name	= @tmp_comp
		AND		mst.ctrl_type_name	= @engg_cont_elem_type
		AND		mst.base_ctrl_type  = 'GRID'
		AND		ISNULL(mst.Datagrid,'N')	='N'		--Tech-75230
		--and		(ISNULL(IsMobile, 'N') = 'Y'
		--OR ISNULL(IsList, 'N') = 'Y') -- Added for Tech-71109
		)
		BEGIN
			IF @modeflag in ('I', 'X', 'U', 'Y')
			BEGIN
				SELECT	--@PaginatationReqd	= ISNULL(PaginationReqd, 'N'), for TECH-71109
						@UpdateTaskReqd		= ISNULL(UpdateTaskReqd, 'N'),
						@DeleteTaskReqd		= ISNULL(DeleteTaskReqd, 'N')
				FROM	es_comp_ctrl_type_mst_extn (nolock)
				where	customer_name	= @engg_customer_name
				and		project_name	= @engg_project_name
				and		req_no			= @engg_base_req_no
				and		process_name	= @tmp_proc
				and		component_name	= @tmp_comp
				and		ctrl_type_name	= @engg_cont_elem_type
				and		base_ctrl_type  = 'GRID'
				--and		(ISNULL(IsMobile, 'N') = 'Y'
				--OR ISNULL(IsList, 'N') = 'Y') -- Added for TECH-71109

			
				EXEC ep_paginationgrid_ins_sp @ctxt_OUInstance,
						@ctxt_User,
						@ctxt_Language,
						@ctxt_Service,
						@engg_customer_name,
						@engg_project_name,
						@tmp_proc,
						@tmp_comp,
						@tmp_act,
						@tmp_ui,
						@engg_base_req_no,
						@engg_cont_page_bts,
						@engg_cont_sec_bts,
						@engg_cont_btsynname,--'',
						'',
						'',
						'MobileGrid',
						'',
						'',
						'',
						--@engg_control_type,	@engg_basecontrol_type,		@engg_renderas,
						@modeflag,
						@engg_req_no,
						@PaginatationReqd,
						@UpdateTaskReqd,
						@DeleteTaskReqd,				
						@m_errorid OUTPUT
				END
				ELSE IF @modeflag = 'D'
				BEGIN
					DELETE
					FROM	ep_Action_mst 
					WHERE	customer_name			= @engg_customer_name
					AND		project_name			= @engg_project_name		
					AND		process_name			= @tmp_proc
					AND		component_name			= @tmp_comp
					AND		activity_name			= @tmp_act
					AND		ui_name					= @tmp_ui
					AND		page_bt_synonym			= @engg_cont_page_bts
					AND		primary_control_bts		= @engg_cont_btsynname
				END
			END

		----Code added for defectid TECH-68066 by 14469 starts

	DECLARE @Pre_Taskname engg_name, @Post_Taskname engg_name,	@Pre_Taskdesc	engg_name, @Post_Taskdesc engg_name,
			@comp_pfx_tmp engg_name, @ui_pfx_tmp engg_name, @ctrl_pfx_tmp engg_name, @control_caption engg_name,
			@BrowsePreTask engg_name, @BrowsePostTask engg_name,  @BrowsePreTaskDesc engg_name, @BrowsePostTaskDesc engg_name,  --15Jul2022
			@DeletePreTask engg_name, @DeletePostTask engg_name,  @DeletePreTaskDesc engg_name, @DeletePostTaskDesc engg_name,
			@ClearTask	   engg_name, @ClearTaskDesc  engg_name --TECH-73996

	SELECT	@comp_pfx_tmp	= current_value
	FROM	es_comp_param_mst (NOLOCK)
	WHERE	customer_name	= rtrim(@engg_customer_name)
	and		project_name	= rtrim(@engg_project_name)
	and		process_name	= rtrim(@tmp_proc)
	and		component_name	= rtrim(@tmp_comp)
	and		param_category	= 'compprefix' 

	SELECT	@ui_pfx_tmp		= page_prefix
	FROM	ep_ui_page_dtl (NOLOCK)
	WHERE	customer_name	= rtrim(@engg_customer_name)
	and		project_name	= rtrim(@engg_project_name)
	and		process_name	= rtrim(@tmp_proc)
	and		component_name	= rtrim(@tmp_comp)
	and		req_no			= rtrim(@engg_base_req_no)
	and 	activity_name   = rtrim(@tmp_act)
	and		ui_name			= rtrim(@tmp_ui)
	and		page_bt_synonym	= '[mainscreen]'
	
	SELECT	@ctrl_pfx_tmp	= control_prefix
	FROM	ep_ui_control_dtl (NOLOCK)
	WHERE	customer_name	= rtrim(@engg_customer_name)
	and		project_name	= rtrim(@engg_project_name)
	and		process_name	= rtrim(@tmp_proc)
	and		component_name	= rtrim(@tmp_comp)
	and		activity_name	= rtrim(@tmp_act)
	and		ui_name			= rtrim(@tmp_ui)
	and		page_bt_synonym	= rtrim(@engg_cont_page_bts)
	and		section_bt_synonym = rtrim(@engg_cont_sec_bts)
	and		control_bt_synonym = rtrim(@engg_cont_btsynname)

	SELECT  @control_caption	=	bt_synonym_caption
	FROM	ep_component_glossary_mst (NOLOCK)
	WHERE	customer_name		= rtrim(@engg_customer_name)
	AND		project_name		= rtrim(@engg_project_name)
	AND		process_name		= rtrim(@tmp_proc)
	AND		component_name		= rtrim(@tmp_comp)
	AND		bt_synonym_name		= rtrim(@engg_cont_btsynname)

	SELECT @Pre_Taskname  =  @comp_pfx_tmp + @ui_pfx_tmp + @ctrl_pfx_tmp + 'PrUI',
		   @Post_Taskname  = @comp_pfx_tmp + @ui_pfx_tmp + @ctrl_pfx_tmp + 'PsUI',

		   @BrowsePreTask  = @comp_pfx_tmp + @ui_pfx_tmp + @ctrl_pfx_tmp + 'BrPrUI',			--15jul2022
		   @BrowsePostTask  = @comp_pfx_tmp + @ui_pfx_tmp + @ctrl_pfx_tmp + 'BrPsUI',
		   @DeletePreTask  = @comp_pfx_tmp + @ui_pfx_tmp + @ctrl_pfx_tmp + 'DePrUI',
		   @DeletePostTask  = @comp_pfx_tmp + @ui_pfx_tmp + @ctrl_pfx_tmp + 'DePsUI',
		   @ClearTask		= @comp_pfx_tmp + @ui_pfx_tmp + @ctrl_pfx_tmp + 'ClUI', --TECH-73996

		   @Pre_Taskdesc   = 'Pre Task for attachment of ' + @control_caption,
		   @Post_Taskdesc  = 'Post Task for attachment of ' + @control_caption,

		   @BrowsePreTaskDesc	= 'Browse Pre Task for attachment of ' + @control_caption,   --15jul2022
		   @BrowsePostTaskDesc	= 'Browse Post Task for attachment of ' + @control_caption,
		   @DeletePreTaskDesc	= 'Delete Pre Task for attachment of ' + @control_caption,
		   @DeletePostTaskDesc	= 'Delete Post Task for attachment of ' + @control_caption,
		   @ClearTaskDesc		= 'Clear Task for attachment of ' + @control_caption	--TECH-73996

	IF ISNULL(@modeflag,'') IN ('I','X','U','Y') AND  EXISTS(
	SELECT 'X'
	FROM es_comp_ctrl_type_mst_extn WITH (NOLOCK)
	WHERE customer_name		    =	@engg_customer_name
	AND	  project_name		    =	@engg_project_name
	AND	  process_name		    =	@tmp_proc
	AND	  component_name	    =	@tmp_comp
	AND	  ctrl_type_name		=	@engg_cont_elem_type
	AND	  base_ctrl_type		=	'Edit'
	AND	  ISNULL(PreTask,'')	=	'y'
	)
	BEGIN
		EXEC ep_action_mst_sp_ins
					@CTXT_LANGUAGE_IN			= @ctxt_language,  
					@CTXT_OUINSTANCE_IN			= @ctxt_ouinstance, 
					@CTXT_SERVICE_IN			= @ctxt_service,
					@CTXT_USER_IN				= @ctxt_user, 
					@CUSTOMER_NAME_IN			= @engg_customer_name,
					@PROJECT_NAME_IN			= @engg_project_name,
					@REQ_NO_IN					= @engg_base_req_no,
					@PROCESS_NAME_IN			= @tmp_proc,
					@COMPONENT_NAME_IN			= @tmp_comp,
					@ACTIVITY_NAME_IN			= @tmp_act,
					@UI_NAME_IN					= @tmp_ui,
					@PAGE_BT_SYNONYM_IN			= @engg_cont_page_bts,
					@TASK_NAME_IN				= @Pre_Taskname,
					@TASK_DESCR_IN				= @Pre_Taskdesc ,
					@TASK_SEQ_IN				= 0,
					@TASK_PATTERN_IN			= 'UI' ,	
					@PRIMARY_CONTROL_BTS_IN		= @engg_cont_btsynname,
					@BASE_TASK_TYPE_IN			= 'UI',
					@TIMESTAMP_IN				= 1 ,
					@engg_req_no				= @engg_req_no,
					@M_ERRORID					= @m_errorid	output								
	END
	
	IF ISNULL(@modeflag,'') IN ('I','X','U','Y') AND  EXISTS(
	SELECT 'X'
	FROM es_comp_ctrl_type_mst_extn WITH (NOLOCK)
	WHERE customer_name		    =	@engg_customer_name
	AND	  project_name		    =	@engg_project_name
	AND	  process_name		    =	@tmp_proc
	AND	  component_name	    =	@tmp_comp
	AND	  ctrl_type_name		=	@engg_cont_elem_type
	AND	  base_ctrl_type		=	'Edit'
	AND	  ISNULL(PostTask,'')	=	'y')
	BEGIN
		EXEC ep_action_mst_sp_ins
					@CTXT_LANGUAGE_IN			= @ctxt_language,  
					@CTXT_OUINSTANCE_IN			= @ctxt_ouinstance, 
					@CTXT_SERVICE_IN			= @ctxt_service,
					@CTXT_USER_IN				= @ctxt_user, 
					@CUSTOMER_NAME_IN			= @engg_customer_name,
					@PROJECT_NAME_IN			= @engg_project_name,
					@REQ_NO_IN					= @engg_base_req_no,
					@PROCESS_NAME_IN			= @tmp_proc,
					@COMPONENT_NAME_IN			= @tmp_comp,
					@ACTIVITY_NAME_IN			= @tmp_act,
					@UI_NAME_IN					= @tmp_ui,
					@PAGE_BT_SYNONYM_IN			= @engg_cont_page_bts,
					@TASK_NAME_IN				= @Post_Taskname,
					@TASK_DESCR_IN				= @Post_Taskdesc ,
					@TASK_SEQ_IN				= 0,
					@TASK_PATTERN_IN			= 'UI' ,	
					@PRIMARY_CONTROL_BTS_IN		= @engg_cont_btsynname,
					@BASE_TASK_TYPE_IN			= 'UI',
					@TIMESTAMP_IN				= 1 ,
					@engg_req_no				= @engg_req_no,
					@M_ERRORID					= @m_errorid	output									
	END
----Code added for defectid TECH-68066 by 14469 ends

	--15jul2022
	IF ISNULL(@modeflag,'') IN ('I','X','U','Y') AND  EXISTS(
	SELECT 'X'
	FROM es_comp_ctrl_type_mst_extn WITH (NOLOCK)
	WHERE customer_name		    =	@engg_customer_name
	AND	  project_name		    =	@engg_project_name
	AND	  process_name		    =	@tmp_proc
	AND	  component_name	    =	@tmp_comp
	AND	  ctrl_type_name		=	@engg_cont_elem_type
	AND	  base_ctrl_type		=	'Edit'
	AND	  ISNULL(BrowsePreTask,'')	=	'y')
	BEGIN
		EXEC ep_action_mst_sp_ins
					@CTXT_LANGUAGE_IN			= @ctxt_language,  
					@CTXT_OUINSTANCE_IN			= @ctxt_ouinstance, 
					@CTXT_SERVICE_IN			= @ctxt_service,
					@CTXT_USER_IN				= @ctxt_user, 
					@CUSTOMER_NAME_IN			= @engg_customer_name,
					@PROJECT_NAME_IN			= @engg_project_name,
					@REQ_NO_IN					= @engg_base_req_no,
					@PROCESS_NAME_IN			= @tmp_proc,
					@COMPONENT_NAME_IN			= @tmp_comp,
					@ACTIVITY_NAME_IN			= @tmp_act,
					@UI_NAME_IN					= @tmp_ui,
					@PAGE_BT_SYNONYM_IN			= @engg_cont_page_bts,
					@TASK_NAME_IN				= @BrowsePreTask,
					@TASK_DESCR_IN				= @BrowsePreTaskDesc ,
					@TASK_SEQ_IN				= 0,
					@TASK_PATTERN_IN			= 'UI' ,	
					@PRIMARY_CONTROL_BTS_IN		= @engg_cont_btsynname,
					@BASE_TASK_TYPE_IN			= 'UI',
					@TIMESTAMP_IN				= 1 ,
					@engg_req_no				= @engg_req_no,
					@M_ERRORID					= @m_errorid	output									
	END

	IF ISNULL(@modeflag,'') IN ('I','X','U','Y') AND  EXISTS(
	SELECT 'X'
	FROM es_comp_ctrl_type_mst_extn WITH (NOLOCK)
	WHERE customer_name		    =	@engg_customer_name
	AND	  project_name		    =	@engg_project_name
	AND	  process_name		    =	@tmp_proc
	AND	  component_name	    =	@tmp_comp
	AND	  ctrl_type_name		=	@engg_cont_elem_type
	AND	  base_ctrl_type		=	'Edit'
	AND	  ISNULL(BrowsePostTask,'')	=	'y')
	BEGIN
		EXEC ep_action_mst_sp_ins
					@CTXT_LANGUAGE_IN			= @ctxt_language,  
					@CTXT_OUINSTANCE_IN			= @ctxt_ouinstance, 
					@CTXT_SERVICE_IN			= @ctxt_service,
					@CTXT_USER_IN				= @ctxt_user, 
					@CUSTOMER_NAME_IN			= @engg_customer_name,
					@PROJECT_NAME_IN			= @engg_project_name,
					@REQ_NO_IN					= @engg_base_req_no,
					@PROCESS_NAME_IN			= @tmp_proc,
					@COMPONENT_NAME_IN			= @tmp_comp,
					@ACTIVITY_NAME_IN			= @tmp_act,
					@UI_NAME_IN					= @tmp_ui,
					@PAGE_BT_SYNONYM_IN			= @engg_cont_page_bts,
					@TASK_NAME_IN				= @BrowsePostTask,
					@TASK_DESCR_IN				= @BrowsePostTaskDesc ,
					@TASK_SEQ_IN				= 0,
					@TASK_PATTERN_IN			= 'UI' ,	
					@PRIMARY_CONTROL_BTS_IN		= @engg_cont_btsynname,
					@BASE_TASK_TYPE_IN			= 'UI',
					@TIMESTAMP_IN				= 1 ,
					@engg_req_no				= @engg_req_no,
					@M_ERRORID					= @m_errorid	output									
	END

	IF ISNULL(@modeflag,'') IN ('I','X','U','Y') AND  EXISTS(
	SELECT 'X'
	FROM es_comp_ctrl_type_mst_extn WITH (NOLOCK)
	WHERE customer_name		    =	@engg_customer_name
	AND	  project_name		    =	@engg_project_name
	AND	  process_name		    =	@tmp_proc
	AND	  component_name	    =	@tmp_comp
	AND	  ctrl_type_name		=	@engg_cont_elem_type
	AND	  base_ctrl_type		=	'Edit'
	AND	  ISNULL(DeletePreTask,'')	=	'y')
	BEGIN
		EXEC ep_action_mst_sp_ins
					@CTXT_LANGUAGE_IN			= @ctxt_language,  
					@CTXT_OUINSTANCE_IN			= @ctxt_ouinstance, 
					@CTXT_SERVICE_IN			= @ctxt_service,
					@CTXT_USER_IN				= @ctxt_user, 
					@CUSTOMER_NAME_IN			= @engg_customer_name,
					@PROJECT_NAME_IN			= @engg_project_name,
					@REQ_NO_IN					= @engg_base_req_no,
					@PROCESS_NAME_IN			= @tmp_proc,
					@COMPONENT_NAME_IN			= @tmp_comp,
					@ACTIVITY_NAME_IN			= @tmp_act,
					@UI_NAME_IN					= @tmp_ui,
					@PAGE_BT_SYNONYM_IN			= @engg_cont_page_bts,
					@TASK_NAME_IN				= @DeletePreTask,
					@TASK_DESCR_IN				= @DeletePreTaskDesc ,
					@TASK_SEQ_IN				= 0,
					@TASK_PATTERN_IN			= 'UI' ,	
					@PRIMARY_CONTROL_BTS_IN		= @engg_cont_btsynname,
					@BASE_TASK_TYPE_IN			= 'UI',
					@TIMESTAMP_IN				= 1 ,
					@engg_req_no				= @engg_req_no,
					@M_ERRORID					= @m_errorid	output									
	END

	
	IF ISNULL(@modeflag,'') IN ('I','X','U','Y') AND  EXISTS(
	SELECT 'X'
	FROM es_comp_ctrl_type_mst_extn WITH (NOLOCK)
	WHERE customer_name		    =	@engg_customer_name
	AND	  project_name		    =	@engg_project_name
	AND	  process_name		    =	@tmp_proc
	AND	  component_name	    =	@tmp_comp
	AND	  ctrl_type_name		=	@engg_cont_elem_type
	AND	  base_ctrl_type		=	'Edit'
	AND	  ISNULL(DeletePostTask,'')	=	'y')
	BEGIN
		EXEC ep_action_mst_sp_ins
					@CTXT_LANGUAGE_IN			= @ctxt_language,  
					@CTXT_OUINSTANCE_IN			= @ctxt_ouinstance, 
					@CTXT_SERVICE_IN			= @ctxt_service,
					@CTXT_USER_IN				= @ctxt_user, 
					@CUSTOMER_NAME_IN			= @engg_customer_name,
					@PROJECT_NAME_IN			= @engg_project_name,
					@REQ_NO_IN					= @engg_base_req_no,
					@PROCESS_NAME_IN			= @tmp_proc,
					@COMPONENT_NAME_IN			= @tmp_comp,
					@ACTIVITY_NAME_IN			= @tmp_act,
					@UI_NAME_IN					= @tmp_ui,
					@PAGE_BT_SYNONYM_IN			= @engg_cont_page_bts,
					@TASK_NAME_IN				= @DeletePostTask,
					@TASK_DESCR_IN				= @DeletePostTaskDesc ,
					@TASK_SEQ_IN				= 0,
					@TASK_PATTERN_IN			= 'UI' ,	
					@PRIMARY_CONTROL_BTS_IN		= @engg_cont_btsynname,
					@BASE_TASK_TYPE_IN			= 'UI',
					@TIMESTAMP_IN				= 1 ,
					@engg_req_no				= @engg_req_no,
					@M_ERRORID					= @m_errorid	output									
	END
	--15jul2022

	--TECH-73996
	IF ISNULL(@modeflag,'') IN ('I','X','U','Y') AND  EXISTS(
	SELECT 'X'
	FROM es_comp_ctrl_type_mst_extn WITH (NOLOCK)
	WHERE customer_name		    =	@engg_customer_name
	AND	  project_name		    =	@engg_project_name
	AND	  process_name		    =	@tmp_proc
	AND	  component_name	    =	@tmp_comp
	AND	  ctrl_type_name		=	@engg_cont_elem_type
	AND	  base_ctrl_type		=	'Edit'
	AND	  ISNULL(ClearTask,'')	=	'y')
	BEGIN
		EXEC ep_action_mst_sp_ins
					@CTXT_LANGUAGE_IN			= @ctxt_language,  
					@CTXT_OUINSTANCE_IN			= @ctxt_ouinstance, 
					@CTXT_SERVICE_IN			= @ctxt_service,
					@CTXT_USER_IN				= @ctxt_user, 
					@CUSTOMER_NAME_IN			= @engg_customer_name,
					@PROJECT_NAME_IN			= @engg_project_name,
					@REQ_NO_IN					= @engg_base_req_no,
					@PROCESS_NAME_IN			= @tmp_proc,
					@COMPONENT_NAME_IN			= @tmp_comp,
					@ACTIVITY_NAME_IN			= @tmp_act,
					@UI_NAME_IN					= @tmp_ui,
					@PAGE_BT_SYNONYM_IN			= @engg_cont_page_bts,
					@TASK_NAME_IN				= @ClearTask,
					@TASK_DESCR_IN				= @ClearTaskDesc ,
					@TASK_SEQ_IN				= 0,
					@TASK_PATTERN_IN			= 'UI' ,	
					@PRIMARY_CONTROL_BTS_IN		= @engg_cont_btsynname,
					@BASE_TASK_TYPE_IN			= 'UI',
					@TIMESTAMP_IN				= 1 ,
					@engg_req_no				= @engg_req_no,
					@M_ERRORID					= @m_errorid	output									
	END
	--TECH-73996

	--TECH-73996
	DECLARE @hiddenbtsynonym engg_name

	SELECT @hiddenbtsynonym	=	'hdnauto'+@ctrl_pfx_tmp

	IF ISNULL(@modeflag,'')	IN ('I','X')
		BEGIN
			IF EXISTS ( SELECT 'X'
						FROM	es_quick_code_met WITH (NOLOCK)
						WHERE	CustomerName	=	@engg_customer_name
						AND		ProjectName		=	@engg_project_name
						AND		ParameterCode	=	'HiddenViewCreation'
						AND		ParameterText	=	'AUTO_POPULATE_HDNVIEW_COMBO'
						AND		ParameterValue	=	'Y' )
						AND		ISNULL(@base_ctrl_type_tmp,'')	=	'Combo'
					BEGIN
							INSERT INTO DE_HIDDEN_VIEW 
										(	customer_name,			project_name,				process_name,			component_name,		
											activity_name,			ui_name,					page_name,				section_name,
											Control_bt_synonym,		hidden_view_bt_synonym,		transfer_flag,			hidden_view_sysid,	
											control_sysid,			timestamp,	
											createdby,				createddate,				modifiedby,				modifieddate,
											control_id,				view_name,					new_control_bt_synonym,	HIDDEN_VIEW_SOURCE,	
											ecrno,					IsGlance )
							SELECT
										@engg_customer_name,	@engg_project_name,				@tmp_proc,				@tmp_comp,		
										@tmp_act,				@tmp_ui,						@engg_cont_page_bts,	@engg_cont_sec_bts,	
										@engg_cont_btsynname,	@hiddenbtsynonym,				'N',					newid(),
										newid(),					1,
										@ctxt_user,				getdate(),						@ctxt_user,				getdate(),
										@control_id,			@control_id,					@hiddenbtsynonym,		NULL,
										'BASE',					NULL

							INSERT INTO ep_component_glossary_mst 
									(	customer_name,			project_name,					req_no,					process_name,
										component_name,			bt_synonym_name,				data_type,				length,
										bt_synonym_caption,		glossary_sysid,					timestamp,				
										createdby,				createddate,					modifiedby,				modifieddate,
										ref_bt_synonym_name,	bt_synonym_doc,					bt_name,				synonym_status,
										singleinst_sample_data,	multiinst_sample_data,			wrkreqno,				IsGlance )
							SELECT
										@engg_customer_name,		@engg_project_name,				@engg_base_req_no,		@tmp_proc,
										@tmp_comp,					@hiddenbtsynonym,				'Char',					60,
										@hiddenbtsynonym,			newid(),							1,
										@ctxt_user,					getdate(),						@ctxt_user,				getdate(),
										NULL,						@hiddenbtsynonym,				'',						'U',
										NULL,						NULL,							@engg_base_req_no,		NULL

						END 
			END
			--TECH-73996




--output parameters  
	select  @fprowno						'fprowno',  
			@engg_del_controls				'engg_del_controls' 

				
	/* 
	--OutputList
		Select
		null 'fprowno', 
		null 'engg_del_controls', 
	*/
End
	
Set nocount off

End
GO

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_layout_sp_savctlcnml' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON ep_layout_sp_savctlcnml	TO PUBLIC
END
GO



