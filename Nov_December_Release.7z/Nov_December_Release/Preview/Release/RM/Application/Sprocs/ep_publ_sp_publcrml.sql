IF EXISTS  (SELECT 'X' FROM SYSOBJECTS WHERE NAME ='ep_publ_sp_publcrml' AND TYPE = 'P')
    BEGIN
        DROP PROC ep_publ_sp_publcrml
    END
GO
/*      V E R S I O N      :  PNR2.0_25308    */
/*      Released By        :  Development Team    */
/*      Release Comments   :  Phase 4 Release    */
/*      V E R S I O N      :  PNR2.0_1403    */
/*      Released By        :  Development Team    */
/*      Release Comments   :  For DotNet Migration, Naming convention has been changed  for some of the out parameters by using Stub Generator.Comments will not be there for this Request ID.    */
/*      V E R S I O N      :  2.0.3    */
/*      Released By        :  PTech    */
/*      Release Comments   :  Released on 21/02/05 (Patch Release 3)    */
/*      V E R S I O N      :  2.0.3     */
/*      Released By        :  PTech    */
/*      Release Comments   :  Released on 02-02-2005(Patch Release 6)    */
/*      V E R S I O N      :  2.0.2    */
/*      Released By        :  PTech    */
/*      Release Comments   :  Released on  22-Jan-2004    */
/********************************************************************************/
/* procedure    : ep_publ_sp_publcrml                                           */
/* description  :                                                               */
/********************************************************************************/
/* project      :                                                               */
/* version      :                                                               */
/********************************************************************************/
/* referenced   :                                                               */
/* tables       :                                                               */
/********************************************************************************/
/* development history                                                          */
/********************************************************************************/
/* author       : Shafina Begum.B                                               */
/* date         : 05/ 12/ 2003                                                  */
/********************************************************************************/
/* modification history                                                         */
/********************************************************************************/
/* modified by  : Shafina Begum.B                                               */
/* date         : 31/ 12/ 2003                                                  */
/* description  : To Populate the published tables with the proper reqno instead of BASE*/
/* description  : To Populate the published glossary mst tables only with the  */
/*      bt synonyms that exist for the UI        */
/********************************************************************************/
/* modified by    Shafina Begum.B                                               */
/* date           08/ 01/ 2004                                                  */
/* description    To publish based on the previewready flag                     */
/********************************************************************************/
/* modified by    Shafina Begum.B                                               */
/* date           14/ 01/ 2004                                                  */
/* description    To update the previewready flag                       */
/********************************************************************************/
/* modified by    Shafina Begum.B                                               */
/* date           15/ 01/ 2004                                                  */
/* description    To partially publish the reqno */
/* description    To comment the check of req_status = 'C' and 'P' in req_dtl table*/
/* description    to update the req_status as 'P' for a particular UI..   */
/********************************************************************************/
/* modified by    Shafina Begum.B                                               */
/* date           16/ 01/ 2004    */
/* description    to insert control_prefix,column_prefix,page_btsynonym in the published table*/
/* description    to ROLLBACK TO PREVIOUS STATE (NOT INSERTING PAGE_BTSYNONYM) */
/********************************************************************************/
/* modified by  : B.Shafina Begum                                               */
/* date         : 20-jan-2004                                                 */
/* description  : To replace select with set                                    */
/* description  : To insert the existing sysids into publ tables and not generating newids*/
/* modified by  : S.Balaji                                                 */
/* date         : 22-jul-2004                                                 */
/* bug Id   : PNR2.0_3328             */
/* description  : While publishing Work request - GTS_LINK_WRQ_001 Violation of */
/* 'Fw_Cmt_Task_PK'. Cannot insert duplicate key in object 'Fw_Cmt_Task'.       */
/********************************************************************************/
/* modification history                                                         */
/* Modified by : Ganesh for callid PNR2.0_3386         */
/* Modified on : 01/08/05               */
/* Description : Add Component Description, Activity Description and Task Description in Glossary.*/
/********************************************************************************/
/* modification history                                                         */
/* Modified by : Gowri for callid PNR2.0_3932         */
/* Modified on : 22/09/05               */
/* Description : Defaulting From Reference UI.Validation to be Added For Control Duplication.*/
/********************************************************************************/
/* modification history                                                         */
/* Modified by : Gowri for callid PNR2.0_3967     */
/* Modified on : 23/09/05        */
/* Description : Validation Should be Added For Control Duplication Within Page.*/
/********************************************************************************/
/* modification history                                                             */
/* Modified by : Gowrisankar for callid PNR2.0_4079            */
/* Modified on : 03/09/05                   */
/* Description : Modification of the Enumerated Caption based on the language extension*/
/*********************************************************************************/
/* modification history                                                          */
/* Modified by : Hamsika               */
/* Modified on : 03/11/05                */
/* Description : Case ID : Platform_2.0.3.1_65 Case Desc : When ,I try to publish*/
/* the Work Request ,I am getting an error "Violation of PRIMARY KEY constraint  */
/* 'ep_published_tree_sample_data_pkey'. Cannot insert duplicate key in object  */
/* 'ep_published_tree_sample_data'" "            */
/********************************************************************************/
/* Modified by : Balaji S for callid PNR2.0_6079        */
/* Modified on : 07/02/06               */
/* Description : Publish Should be sequence          */
/********************************************************************************/
/* Modified by : Anuradha M for callid PNR2.0_8428        */
/* Modified on : 12/05/06               */
/* Description : validation for work request publish       */
/********************************************************************************/
/* Modified by : Chanheetha N A        */
/* Modified on : 16-Jun-2006              */
/* Description : PNR2.0_8997             */
/********************************************************************************/
/* Modified by : kiruthika R              */
/* Modified on : 19/06/06               */
/* Description : PNR2.0_9012             */
/********************************************************************************/
/* Modified by : Chanheetha N A             */
/* Modified on : 20-Jun-2006              */
/* Description : PNR2.0_9038             */
/********************************************************************************/
/* Modified By  : Date :   Description :    */
/* S K Mohamed Mohideen 15 Jun 2006 Task Confirmation Message changes */
/********************************************************************************/
/* Modified by : Balaji S              */
/* Modified on : 24-Aug-2006              */
/* Description : PNR2.0_10009             */
/********************************************************************************/
/* Modified by : kiruthika R              */
/* Modified on : 06/09/06               */
/* Description : PNR2.0_10166             */
/********************************************************************************/
/* Modified By  : Date :   Description :    */
/* S K Mohamed Mohideen 09 Nov 2006 Task Status Message changes  */
/********************************************************************************/
/* Modified by : Anuradha M             */
/* Modified on : 17-Nov-2006              */
/* Description : PNR2.0_11042             */
/********************************************************************************/
/* Modified by : Feroz                */
/* Modified on : 08/11/06               */
/* Description : State Processing             */
/********************************************************************************/
/* Modified by : Chanheetha N A             */
/* Modified on : 22-Mar-2007              */
/* Description : PNR2.0_12773              */
/********************************************************************************/
/* Modified by : Chanheetha N A             */
/* Modified on : 27-Mar-2007              */
/* Description : PNR2.0_12824              */
/********************************************************************************/
/* Modified by : Gowrisankar M             */
/* Modified on : 21-May-2007              */
/* Description : PNR2.0_13724              */
/********************************************************************************/
/* Modified by  : Balaji S                 */
/* Date         : 05-Jun-2007                                                     */
/* Bug ID       : PNR2.0_13970               */
/*************************************************************************************/
/* Modified by  : Chanheetha N A                     */
/* Date         : 25-Jul-2007                                                     */
/* Bug ID       : PNR2.0_14661                */
/*************************************************************************************/
/* Modified by  : Kiruthika R                     */
/* Date         : 17-Oct-2007                                                     */
/* Bug ID       : PNR2.0_15683                */
/*************************************************************************************/
/* Modified by  : Balaji S                 */
/* Date         : 23-Jan-2008                                                        */
/* Bug ID       : PNR2.0_16560             */
/*************************************************************************************/
/* Modified by  : S.Sivakumar              */
/* Date         : 21-MAY-2008              */
/* Bug ID       : PNR2.0_18002              */
/************************************************************************************/
/* modified by  : Jeya Latha K   */
/* date         : 25-Apr-2008                                                  */
/* Bug Id   : PNR2.0_1476                */
/************************************************************************/
/* modified by  : Jeya Latha K  */
/* date : 13-May-2008      */
/* Bug Id   : PNR2.0_1522                      */
/************************************************************************/
/* Modified by  : Gopinath S              */
/* Date         : 06-OCT-2008              */
/* Bug ID       : PNR2.0_19480              */
/*************************************************************************************/
/* modified by   : Jeya           */
/* date     : 25-nov-2008         */
/* BugId    : PNR2.0_1790          */
/************************************************************************/
/* modified by  : Sangeetha G                                           */
/* date         : 19-May-2009                                           */
/* Bug Id  : PNR2.0_22275       */
/* modified for : To include page focus in state processing  */
/********************************************************************************************************/
/* modified by    : Sangeetha G         */
/* date     : 22-June-2009        */
/* BugId    : PNR2.0_22560          */
/* Description    : To validate non-Grid controls existing in the Grid Sections.  */
/********************************************************************************************************/
/* modified by    : Sangeetha G         */
/* date     : 7-July-2009        */
/* BugId    : PNR2.0_22818         */
/* Description    : All columns of a grid cannot be hidden for a states  */
/********************************************************************************************************/
/* modified by  : Feroz                                                */
/* date         : 04-Aug-2009                                                   */
/* Bug Id   : PNR2.0_2179             */
/* Description  : Phase 3 Features - ListEdit, AttachDocument, Image & DateHighlight */
/********************************************************************************/
/* Modified By     : Feroz           */
/* Date       : 26-Aug-2009         */
/* Description     : PNR2.0_23463          */
/******************************************************************************/
/* Modified By : Gopinath S             */
/* Date  : 14-oct-2009            */
/* Description : PNR2.0_24356             */
/* Description : work req publish is taking long time          */
/******************************************************************************/
/* Modified By     : Chanheetha N A        */
/* Date      : 23-Oct-2009         */
/* Bug Id      : PNR2.0_24424         */
/* Description     : Pagename added for mapped controls to launch EzeeView Link from model  */
/*************************************************************************************************************************/
/* Modified By					: Jeya Latha K								 */
/* Date							: 08-Feb-2010								 */
/* Description					: PNR2.0_25863 								 */
/******************************************************************************/
/* Modified By					: 	Sangeetha G		*/
/* Date						: 	05-Apr-10		*/
/* Bugid					: 	PNR2.0_26335		*/
/* Modified For					: 	Traversal table schema change	*/
/**********************************************************************************************/
/* Modified By					: Sangeetha G 			              */
/* Date						: 28-Apr-2010				      */
/* Bug Id 					: PNR2.0_26701 				      */
/* Description					: Column addition for ListEdit Resolve tables */
/***********************************************************************************************/
/* Modified By					: Chanheetha N A		              */
/* Date						: 19-May-2010				      */
/* Bug Id 					: PNR2.0_26860 				      */
/* Description					: Column addition for freezecount  */
/***********************************************************************************************/
/* Modified By					: Chanheetha N A		              */
/* Date						: 16-Jun-2010				      */
/* Bug Id 					: PNR2.0_26475 				      */
/* Description					: status_flag Column is not required          */
/***********************************************************************************************/
/* Modified By       : Sangeetha G															   */
/* Date				 : Sep 17 2010															   */
/* Bug Id			 : PNR2.0_28333	                                                           */
/* Description       : Ezee view page for Platform     	*/
/***********************************************************************************************/
/* modified by		: Jeyalatha K 											*/
/* date				: 11-Feb-2011                                           */
/* Bug Id			: PNR2.0_30127											*/
/* Modified for		: Feature  Release										*/
/****************************************************************************/
/* modified by   : Sangeetha G           */  
/* date			 : 11-Apr-2011         */  
/* BugId		 : PNR2.0_30869          */  
/* modified for		 : Feature Release      */  
/****************************************************************************/
/* modified by	: Balaji D											   		*/
/* modified on	: May 18 2011												*/
/* Bug ID		: PNR2.0_31403 												*/
/* Case Desc	: Tree Grid Feature Enhancement.							*/
/****************************************************************************/  
/* modified by	: Balaji D											   		*/
/* modified on	: July 05 2011												*/
/* Bug ID		: PNR2.0_32209 												*/
/* Case Desc	: For Deleting UI Page Events Details.						*/
/****************************************************************************/
/* modified by	: Gankan.G											   		*/
/* modified on	: 15-July-2011												*/
/* Bug ID		: PNR2.0_32385 												*/
/* Case Desc	: Code modified to populate language extn tables reference 	*/
/*				  to their base tables										*/
/****************************************************************************/
/* modified by	: Balaji D											   		*/
/* modified on	: 15-Oct-2011												*/
/* Bug ID		: PNR2.0_33856 												*/
/* Case Desc	: While publishing workrequest, it is taking 15 to 20 mins 	*/
/****************************************************************************/
/* modified by	: Balaji D											   		*/
/* modified on	: 15-Oct-2011												*/
/* Bug ID		: PNR2.0_34035 												*/
/* Case Desc	: Chart table schema change									*/
/********************************************************************************/
/* modified by  :	Muthupandi S												*/
/* date         :	01-December-2011											*/
/* Bug ID		:	PNR2.0_34596 												*/
/* Description	:	Validation added to avoid adding a new section with the existing */
/*					section name across UI										*/
/********************************************************************************/
/* modified by	: Balaji D											   		*/
/* modified on	: Dec 31 2011												*/
/* Bug ID		: PNR2.0_35984 												*/
/* Case Desc	: Modelling for Splitter Section.							*/
/****************************************************************************/
/* modified by  : Balaji D  			                                    */
/* date         : July 02 2012			                                    */
/* BugId        : PLF2.0_00961 			                                    */
/* Case Desc    : PopUpSection,Button Right Align,Page/Button/Link Images.  */
/****************************************************************************/ 
/* modified by  :	Kiruthika R												*/
/* date         :	06-Mar-2013												*/
/* Bug ID		:	PLF2.0_03710 											*/
/* Description	:	Customlist implementation for header edit controls.		*/
/****************************************************************************/
/* modified by  :	Gankan G												*/
/* date         :	28-May-2013												*/
/* Bug ID		:	PLF2.0_04721 											*/
/* Description	:	Code modified to handle equal	tabwidth				*/
/****************************************************************************/
/* modified by  :	Shakthi P														 */
/* date         :	26-FEB-2014												     	 */
/* Bug ID		:	PLF2.0_07676 													 */
/* Description	:	Changes for 2.x-3.x iEDK Tab Index,Custom CSS inclusion, Grid Tool */
/*Bar Hiding, Grid Tool Bar With Only Pagination, Grid Without Column Seperator and Grid Without Row Seperator	*/
/*************************************************************************************/
/* modified by  :	 Shakthi P             															*/
/* date         : 12-Mar-2014            														*/
/* Bug ID  		: PLF2.0_07805          														  */
/* Description 	: Changes for Section Level RowSpan, ColSpan, Filler Section - Control Level RowSpan        			  */
/*********************************************************************************/
/* modified by  : Loganayaki P             										*/
/* date         : 19-Mar-2014            										*/
/* Bug ID  		: PLF2.0_07770          									   */
/* Description 	: To reduce time taken to publish Workreq        			    */
/*********************************************************************************/
/* modified by  : Shakthi P                                                     	 */
/* date         : 30 May 2014                                                 	     */
/* Bug Id       : PLF2.0_08470                                      	        	 */
/* Description  : Tooltip Not Required.ForceFit,Grid Column Caption Not Required 	 */
/* There is log of changes so,no modification History                            	 */
/*************************************************************************************/
/* modified by  :	Kanagavel														 */
/* date         :	13-Jun-2014												     	 */
/* Bug ID		:	PLF2.0_08772 													 */
/* Description	:	Changes for 2.x-3.x iEDK Tab Index,Custom CSS inclusion, Grid Tool */
/*Bar Hiding, Grid Tool Bar With Only Pagination, Grid Without Column Seperator and Grid Without Row Seperator	*/
/* More changes, so, no modification history										*/
/*************************************************************************************/
/* modified by  : Veena U   			                                        */
/* date         : Oct 10 2014			                                        */
/* BugId        : PLF2.0_09035													*/
/* description  : Model changes for rowspan,colspan,IsStatic,IsCallout 
				  in  layout level.												*/
/********************************************************************************/
/* Modified by  : Veena U                                                  */
/* Date         : 25-Feb-2015                                                  */
/* Call ID		: PLF2.0_11499                                                 */
/********************************************************************************/  
/* Modified by  : Veena U	                                                  */
/* Date         : 07-Aug-2015                                                  */
/* Defect ID	: PLF2.0_14096                                                 */
/********************************************************************************/
/* Modified by  : Veena U	                                                  */
/* Date         : 24-Dec-2015*/
/* Defect ID	: PLF2.0_16153                                                 */
/********************************************************************************/
/* Modified by  : Veena U	                                                  */
/* Date         : 02-Feb-2016                                                  */
/* Defect ID	: PLF2.0_16291													*/
/********************************************************************************/
/* Created by  	: Veena U                                                */
/* Date         : 16-March-2016                                                  */
/*Defect Id 	: PLF2.0_17326												*/
/********************************************************************************/ 
/* Modified by  : Veena U                                                  */
/* Date         : 28-Mar-2016                                                 */
/* Call ID		: PLF2.0_17570                                               */
/********************************************************************************/ 
/* modified by			Date				Defect ID							*/
/* Veena U				08-Jun-2016			PLF2.0_18487						*/
/********************************************************************************/
/* Modified by : Jeya Latha K/Ganesh Prabhu S	for callid TECH-7349				*/
/* Modified on : 14-03-2017				 											*/
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and New Feature Organization chart */
/***********************************************************************************/
/* Modified by : Ganesh Prabhu S/Ranjitha R      for callid  TECH-10118                   */
/* Modified on : 30-May-2017                                                                                        */
/* Description : Platform Feature Release                                                              */
/********************************************************************************/
/* Modified by  : Jeya Latha K		Date: 16-Aug-2017  Defect ID	:TECH-12776	*/  
/********************************************************************************/
/* Modified by  : Jeya Latha K		Date: 21-Nov-2017  Defect ID	:TECH-16126	*/  
/********************************************************************************/
/* Modified by  : Jeya Latha K		Date: 30-Apr-2018  Defect ID : TECH-20897 */  
/********************************************************************************/
/* Modified by  :  Venkatesan K                                                  */
/* Date         :  10_05_2018                                                    */
/* Description  :  Batch id table updation for batch track purpose.				 */
/* case id		:  TECH-20631													 */
/**************************************************************************************/
/* Modified By : Jeya Latha K/ Venkatesan K Date: 04-Dec-2018	Defect ID: TECH-28806 */
/* Modified By : Jeya Latha K				Date: 08-Jan-2019   Defect ID: TECH-28436 */
/* Modified By : Jeya Latha K/Venkatesan K	Date: 06-Mar-2019	Defect ID: TECH-32100 */
/* Modified by : Jeya Latha K/Venkatesan K  Date: 17-Jun-2019   Defect ID: TECH-34971 */
/* Modified by : Jeya Latha K				Date: 28-Jun-2019   Defect ID: TECH-35368 */
/* Modified by : Jeya Latha K				Date: 25-Jul-2019   Defect ID: TECH-36371 */
/* Modified by : Jeya Latha K				Date: 01-Nov-2019   Defect ID: TECH-39534 */
/**********************************************************************************************/
/* Modified by : Jeya Latha K                    Date: 04-Dec-2019  Defect ID : TECH-40809    */
/* Modified by : Priyadharshini U/Rajeswari M	 Date: 29-Jan-2020  Defect ID : TECH-42483	  */
/* Modified by : Rajeswari M/Jeya Latha K		 Date: 27-Feb-2020  Defect ID : TECH-43307    */
/* Modified by : Rajeswari M/Jeya Latha K		 Date: 24-Apr-2020  Defect ID : TECH-45546    */
/* Modified by : Rajeswari M/Jeya Latha K		 Date: 06-May-2020  Defect ID : TECH-45828    */ 
/**********************************************************************************************/
/* Modified by  : Rajeswari M		Date: 24-Apr-2020  Defect ID	:TECH-45546				  */
/* Modified by  : Rajeswari M       Date: 24-Apr-2020  Defect ID    :TECH-45546				  */
/**********************************************************************************************/
/* Modified by	: Deepika S			Date: 30-OCT-2020  Defect ID	:TECH-50097				  */
/* Modified by  : Rajeswari M/Priyadharshini U Date: 28-Jul-2021  Defect ID : TECH-60451      */
/* TECH-60451   : Launching Help&Link UIs, Popup sections and Grid Extensions in Side Drawer  */
/* TECH-63527   : Associate Control added in ep_ui_control_dtl for Multiselectcombo		      */ 
/**********************************************************************************************/
/* Modified By	: Venkatesan K																  */
/* Defect ID	: TECH-66583																  */
/* Modified on	: 24Feb2022																	  */
/* Description	: RVW 2.0 Model publish table implementation for control and task property.   */
/**********************************************************************************************/
/* Modified By	: Ponmalar A/Priyadharshini U												  */
/* Defect ID	: TECH-68066																  */
/* Modified on	: 13-Apr-2022																  */
/* Description	: Post and Pre Tasks for Attachment controls.								  */
/**********************************************************************************************/
/* modified by  : Venkatesan K																  */
/* Date         : 13-APR-2022																  */
/* Defect ID	: TECH-68067																  */
/* Description  : Provision to download all the attachments as bulk in Grid Control.		  */
/**********************************************************************************************/
/* Modified by	:	Priyadharshini U 														  */
/* Modified on	:	08/06/22				 												  */
/* Defect ID	:	TECH-69624																  */
/* Description	:	Custom border, Custom actions and Responsive layout						  */
/**********************************************************************************************/
/* Modified by	:	Ponmalar A / Vimal Kumar R												  */
/* Modified on	:	08/07/2022				 												  */
/* Defect ID	:	Tech-70687																  */
/* Description	:	Tool and Toolbars														  */
/**********************************************************************************************/
/* Modified by : Priyadharshini U  															  */
/* Modified on : 27-July-2022																  */
/* Defect ID   : TECH-71262																	  */
/* Description : Platform Features for the Month of July'22									  */
/**********************************************************************************************/
/* Modified by : Vimal Kumar R  															  */
/* Modified on : 27-July-2022																  */
/* Defect ID   : TECH-71262																	  */
/* Description : Platform Features for the Month of July'22									  */
/**********************************************************************************************/
/* Modified by : Ponmalar A/Priyadharshini U												  */
/* Modified on : 24-Aug-2022																  */
/* Defect ID   : TECH-72114																	  */
/* Description : Platform Release for the month of August'22								  */
/**********************************************************************************************/
/* Modified by : Ponmalar A						Date: 30-Sep-2022  Defect ID : TECH-73216     */ 
/**********************************************************************************************/
/* Modified by : Athul M / Vimal Kumar R													  */
/* Modified on : 27-Oct-2022																  */
/* Defect ID   : TECH-73996																	  */
/* Description : Addition of attributes for control types in setup ui preferences screen	  */
/**********************************************************************************************/
/* Modified by : Manoj S																	  */
/* Modified on : 31-Oct-2022																  */
/* Defect ID   : TECH-74029																	  */
/**********************************************************************************************/
/* Modified by : Ponmalar A/Priyadharshini U												  */
/* Modified on : 01-Dec-2022																  */
/* Defect ID   : TECH-75230																	  */
/* Description : Platform Features for the Month of Nov'22									  */
/**********************************************************************************************/
CREATE PROCEDURE ep_publ_sp_publcrml
@ctxt_language_in             engg_ctxt_language,
@ctxt_ouinstance_in           engg_ctxt_ouinstance,
@ctxt_service_in              engg_ctxt_service,
@ctxt_user_in                 engg_ctxt_user,
@engg_customer_name_in        engg_name,
@engg_project_name_in		  engg_name,
@engg_req_descr_in            engg_description,
@engg_req_no_in               engg_name,
@modeflag_in                  engg_modeflag,
@auto_complete				  engg_name,
@fprowno_io                   engg_rowno,
@m_errorid engg_rowno output
as
begin


set nocount on

--declaration of temporary variables
declare @ctxt_language                 engg_ctxt_language
declare @ctxt_ouinstance               engg_ctxt_ouinstance
declare @ctxt_service                  engg_ctxt_service
declare @ctxt_user                     engg_ctxt_user
declare @engg_customer_name            engg_name
declare @engg_project_name			   engg_name
declare @engg_req_descr                engg_description
declare @engg_req_no                   engg_name
declare @modeflag                      engg_modeflag
declare @fprowno                       engg_rowno
declare @base_task_type				   engg_name
declare @date       engg_name
declare @pre_workreq_tmp    engg_name
declare @depstatereq engg_name /*Modification made by Muthupandi S for Bug id : PNR2.0_34596 Starts*/
declare @act_depstate engg_name
declare @ui_depstate engg_name
declare @sec_depstate engg_name/*Modification made by Muthupandi S for Bug id : PNR2.0_34596 Ends*/


--temporary and formal parameters mapping
set @ctxt_language                 = @ctxt_language_in
set @ctxt_ouinstance               = @ctxt_ouinstance_in
set @ctxt_service				   = ltrim(rtrim(@ctxt_service_in))
set @ctxt_user                     = ltrim(rtrim(@ctxt_user_in))
set @engg_customer_name            = ltrim(rtrim(@engg_customer_name_in))
set @engg_project_name             = ltrim(rtrim(@engg_project_name_in))
set @engg_req_descr                = ltrim(rtrim(@engg_req_descr_in))
set @engg_req_no                   = ltrim(rtrim(@engg_req_no_in))
set @modeflag                      = ltrim(rtrim(@modeflag_in))
set @auto_complete                      = ltrim(rtrim(@auto_complete))
set @fprowno                       = @fprowno_io

select @date = getdate()

--null checking
if @ctxt_language = -915
select @ctxt_language = null

if @ctxt_ouinstance = -915
select @ctxt_ouinstance = null

if @ctxt_service = '~#~'
select @ctxt_service = null

if @ctxt_user = '~#~'
select @ctxt_user = null

if @engg_customer_name = '~#~'
select @engg_customer_name = null

if @engg_project_name = '~#~'
select @engg_project_name = null

if @engg_req_descr = '~#~'
select @engg_req_descr = null

if @engg_req_no = '~#~'
select @engg_req_no = null

if @modeflag = '~#~'
select @modeflag = null

if @auto_complete = '~#~'
select @auto_complete = null


if @fprowno = -915
select @fprowno = null

--errors mapped
--output parameters
--  select  fprowno                       'fprowno'
declare  @bt_synonym_tmp  engg_documentation

select @fprowno = @fprowno + 1

declare @timestamp_tmp	engg_timestamp
Set		@timestamp_tmp	=	1	

if @modeflag not in ('Z','U','Y')
return

declare @msg     engg_documentation,
@engg_base_req_no  engg_name,
@customer_name_temp  engg_name,
@project_name_temp   engg_name,
@process_name_temp   engg_name,
@component_name_temp  engg_name,
@activity_name_temp  engg_name,
@ui_name_temp   engg_name,
@cust_name_temp   engg_name,
@proj_name_temp   engg_name,
@req_tmp    engg_name,
@proc_name_temp   engg_name,
@comp_name_temp   engg_name,
@act_name_temp   engg_name,
@func_name_temp   engg_name,
@control_bt_synonym  engg_name,
@ui_name    engg_name,
-- code added by kiruthika for the Bug id :: PNR2.0_10166 - start
@task_name    engg_name,
@language    engg_name,
-- code added by kiruthika for the Bug id :: PNR2.0_10166 - end
@bt_synonym_name  engg_name,
@activitydescr_tmp  engg_description,
@listedit_col_synonym engg_name -- JL --Code Added for Defect ID : TECH-39534

if isnull(@auto_complete,'') = 'Current'
Begin
--  declare  @task_page_tmp   engg_name,
--     @task_name    engg_name,
--     @task_descr    engg_description,
--   @task_seq    engg_seqno,
--     @task_pattern   engg_name,
--     @primary_control_bts engg_name,
--     @flow_page    engg_name,
--     @flow_task_name   engg_name,
--     @flowbr_name   engg_name,
--     @flowbr_descr   engg_description,
--     @flowbr_sequence  engg_seqno,
--     @control_id    engg_name,
--     @view_name    engg_name,
--     @event_name    engg_name,
--     @map_flag    engg_flag,
--     @link_page    engg_name,
--     @link_section   engg_name,
--     @link_control   engg_name,
--     @link_type    engg_name,
--     @linked_component  engg_name,
--     @linked_activity  engg_name,
--     @linked_ui    engg_name

select @engg_base_req_no  = 'BASE'
--code added by shafina on 08-Jan-2004 To publish based on the previewready flag
--code uncommented by shafina on 15-jan-2004 to partially publish based on the previewready flag
-- code modified by shafina on 16-jan-2004
-- code commented by shafina on 15-Apr-2004 for PREVIEWENG203ACC_000035
/* if @engg_req_no = 'BASE'
begin
if not exists
(
select 'X'
--      from ep_bpt_download_vw (nolock)
from ep_bpt_activity_ppw_vw (nolock)
where customerid = @engg_customer_name
and  projectid = @engg_project_name
and  workreqid = @engg_req_no -- 'BASE'
and  previewready= 'RPP'
--and  previewready is not null
)
begin
select @msg = 'Selected request number is not ready for publish'
exec engg_error_sp  ep_publ_sp_publcrml,
7,
@msg,
@ctxt_language,
@ctxt_ouinstance,
@ctxt_service,
@ctxt_user,
'',
'',
'',
'',
@m_errorid out
return
end
end
else
begin
if not exists
(
select 'X'
--     from ep_cmt_download_vw (nolock)
from ep_cmt_activity_ppw_vw (nolock)
where customerid = @engg_customer_name
and  projectid = @engg_project_name
and  workreqid = @engg_req_no
and  previewready= 'RPP'
--and  previewready is not null
)
begin
select @msg = 'Selected request number is not ready for publish'
exec engg_error_sp  ep_bpt_activity_ppw_vw,
6,
@msg,
@ctxt_language,
@ctxt_ouinstance,
@ctxt_service,
@ctxt_user,
'',
'',
'',
'',
@m_errorid out
return
end
end*/

--  if exists( select 'X' from ep_ui_req_dtl
--     where customer_name =  (@engg_customer_name)
--     and  project_name =  (@engg_project_name)
--     and  req_no   =  (@engg_req_no)
--     and  req_status  = 'P')
--  begin
--   select @msg = 'Selected request number is already published'
--   exec engg_error_sp  ep_publ_sp_publcrml,
--         1,
--         @msg,
--         @ctxt_language,
--         @ctxt_ouinstance,
--         @ctxt_service,
--         @ctxt_user,
--         '',
--         '',
--         '',
--         '',
--         @m_errorid out
--   return
--  end

--Code Modified For BugId : PNR2.0_3932
declare @ctrl_bts_temp engg_name
declare @page_bts_temp engg_name

select  @ui_name_temp = a.ui_name,
@ctrl_bts_temp = a.control_bt_synonym,
@page_bts_temp = a.page_bt_synonym
from  ep_ui_control_dtl  a(nolock),
ep_ui_req_dtl  b(nolock)
where  a.customer_name =  b.customer_name
and  a.project_name =  b.project_name
and  a.process_name =  b.process_name
and  a.component_name= b.component_name
and  a.activity_name =  b.activity_name
and  a.ui_name  =  b.ui_name
and  b.customer_name =  rtrim(@engg_customer_name)
and  b.project_name =  rtrim(@engg_project_name)
and  b.req_no  =  rtrim(@engg_req_no)
group by a.customer_name, a.project_name, a.process_name, a.component_name, a.activity_name, a.ui_name, a.page_bt_synonym, a.control_bt_synonym
having count(*) > 1


if isnull(@ui_name_temp,'') <> ''
begin
select @msg = 'For the UI :'+@ui_name_temp+' the Control :'+@ctrl_bts_temp+' is defined more then once in the Page : '+@page_bts_temp
exec engg_error_sp  'ep_pubact_sp_publgrid',
6,
@msg,
@ctxt_language,
@ctxt_ouinstance,
@ctxt_service,
@ctxt_user,
'',
'',
'',
'',
@m_errorid out
return
end
--code Modified For BugId : PNR2.0_3967
declare @col_bts_temp engg_name

select  @ui_name_temp = a.ui_name,
@col_bts_temp = a.column_bt_synonym,
@page_bts_temp = a.page_bt_synonym
from  ep_ui_grid_dtl  a(nolock),
ep_ui_req_dtl b(nolock)
where  a.customer_name =  b.customer_name
and a.project_name =  b.project_name
and a.process_name =  b.process_name
and a.component_name= b.component_name
and a.activity_name =  b.activity_name
and a.ui_name =  b.ui_name
and b.customer_name =  rtrim(@engg_customer_name)
and b.project_name =  rtrim(@engg_project_name)
and b.req_no =  rtrim(@engg_req_no)
group by a.customer_name, a.project_name, a.process_name, a.component_name, a.activity_name, a.ui_name, a.page_bt_synonym, a.column_bt_synonym
having count(*) > 1

if isnull(@ui_name_temp,'') <> '' and not exists (select 'x' from ep_systemdefined_views (nolock) 
								where ViewName  = @col_bts_temp)
begin
select @msg = 'For the UI :'+@ui_name_temp+' the Column :'+@col_bts_temp+' is defined more then once in the Page : '+@page_bts_temp
exec engg_error_sp  'ep_publ_sp_publcrml',
6,
@msg,
@ctxt_language,
@ctxt_ouinstance,
@ctxt_service,
@ctxt_user,
'',
'',
'',
'',
@m_errorid out
return
end

select @ui_name_temp = '', @col_bts_temp = ''

select  @ui_name_temp = a.ui_name,
@col_bts_temp = column_bt_synonym
from  ep_ui_control_dtl a (nolock),
ep_ui_grid_dtl   b (nolock),
ep_ui_req_dtl  c (nolock)
where  a.customer_name = b.customer_name
and a.project_name  = b.project_name
and a.process_name  =  b.process_name
and a.component_name = b.component_name
and a.activity_name  =  b.activity_name
and a.ui_name  =  b.ui_name
and a.page_bt_synonym = b.page_bt_synonym
and a.customer_name  =  c.customer_name
and a.project_name  =  c.project_name
and a.process_name  =  c.process_name
and a.component_name = c.component_name
and a.activity_name  =  c.activity_name
and a.ui_name  =  c.ui_name
and c.customer_name  =  rtrim(@engg_customer_name)
and c.project_name  =  rtrim(@engg_project_name)
and c.req_no  =  rtrim(@engg_req_no)
and a.control_bt_synonym = b.column_bt_synonym


if isnull(@ui_name_temp,'') <> ''
begin
select @msg =  'For the UI :'+@ui_name_temp+ ' Column BT Synonym '+@col_bts_temp+ ' can not be same as Control BT Synonym'
exec engg_error_sp  'ep_publ_sp_publcrml',
6,
@msg,
@ctxt_language,
@ctxt_ouinstance,
@ctxt_service,
@ctxt_user,
'',
'',
'',
'',
@m_errorid out
return
end
/*Modification made by Muthupandi S for Bug id : PNR2.0_34596 Starts*/
select @depstatereq = current_value from es_project_param_mst (nolock)
						where customer_name = @engg_customer_name
						and project_name = @engg_project_name
						and param_category = 'DEPSTATEREQ' 

/*
Declare @tmp_Sectionname	engg_name,
		@tmp_activityname	engg_name

select	@tmp_Sectionname			= sec.section_bt_synonym,
		@tmp_activityname			= sec.activity_name,
		@ui_name_temp				= sec.ui_name
FROM	ep_ui_section_dtl sec (nolock),
		ep_ui_req_dtl req (nolock)
where	sec.customer_name			= req.customer_name
and		sec.project_name			= req.project_name
and		sec.process_name			= req.process_name
and		sec.component_name			= req.component_name
and		sec.activity_name			= req.activity_name
and		sec.ui_name					= req.ui_name

and		req.customer_name			= rtrim(@engg_customer_name)
and		req.project_name			= rtrim(@engg_project_name)
and		req.req_no					= rtrim(@engg_req_no)
and		section_type				= 'ListItem'
and		isnull(Associated_control,'')= ''

if isnull(@tmp_Sectionname,'') <> '' and isnull(@tmp_activityname,'') <> '' and isnull(@ui_name_temp,'') <> ''
begin
	select @msg = 'For the UI : '+@ui_name_temp + ' in the Activity : '+ @tmp_activityname + ', Section BT Synonym '+@tmp_Sectionname+' must be associated with Grid control.'
	exec engg_error_sp  ep_pubact_sp_publgrid,	6,	@msg,
		@ctxt_language,		@ctxt_ouinstance,	@ctxt_service,	@ctxt_user,	'',	'',	'',	'',	@m_errorid out
	return
end

*/

if @modeflag = 'Z'
begin
	if @depstatereq = 'Y'
	begin 
	select  @act_depstate = a.activity_name,
	@ui_depstate = a.ui_name,
	@sec_depstate = a.section_bt_synonym
	from  ep_ui_section_dtl  a(nolock),
	ep_ui_req_dtl b(nolock)
	where  a.customer_name =  b.customer_name
	and a.project_name =  b.project_name
	and a.process_name =  b.process_name
	and a.component_name= b.component_name
	and a.activity_name =  b.activity_name
	and a.ui_name =  b.ui_name
	and b.customer_name =  rtrim(@engg_customer_name)
	and b.project_name =  rtrim(@engg_project_name)
	and b.req_no =  rtrim(@engg_req_no)
	group by a.customer_name, a.project_name, a.process_name, a.component_name, a.activity_name, a.ui_name,a.section_bt_synonym
	having count(*) > 1


	if isnull(@ui_depstate,'') <> ''
	begin
	select @msg = 'In an UI :'+'"'+@ui_depstate+'"'+' under the activity '+'"'+@act_depstate+'"'+', section'+ '"'+@sec_depstate+ '"'+' is defined more than once' 
	exec engg_error_sp  'ep_publ_sp_publcrml',
	6,
	@msg,
	@ctxt_language,
	@ctxt_ouinstance,
	@ctxt_service,
	@ctxt_user,
	'',
	'',
	'',
	'',
	@m_errorid out
	return
end
end
end
/*Modification made by Muthupandi S for Bug id : PNR2.0_34596 Ends*/

-- code added by Anuradha on 12-May-2006 for the Bug id ::PNR2.0_8428 - Start
if not  exists (select  'x'
from  ep_ui_req_dtl a(nolock)
where  a.customer_name  =  @engg_customer_name
and  a.project_name  =  @engg_project_name
and  a.req_no  = @engg_req_no
and  a.req_status  = 'c')
begin
select @msg =  'work request : ' + @engg_req_no + ' is already published'
exec engg_error_sp
ep_publ_sp_publcrml,1,@msg,@ctxt_language,@ctxt_ouinstance,
@ctxt_service,@ctxt_user,@pre_workreq_tmp,'','','',@m_errorid out
return
end
-- code added by Anuradha on 12-May-2006 for the Bug id ::PNR2.0_8428 - end
--- validations for inplace video and completion chart
		declare @count_cc engg_seqno,
				@count_sec_cc	engg_seqno,
				@count_iv engg_seqno,
				@count_sec_iv engg_seqno,
				@count_link	engg_seqno,
				@count_sec_comp engg_seqno,
				@count_sec_inplace engg_seqno
				
		select @count_cc = count(distinct ctrl.control_bt_synonym) ,
		@count_sec_cc = count(distinct ctrl.section_bt_synonym) 
		from  ep_ui_section_dtl sec(nolock),
		es_comp_ctrl_type_mst comp(nolock),
		ep_ui_control_dtl	ctrl	(nolock),
		ep_ui_req_dtl req(nolock)
		where	sec.customer_name			=	req.customer_name
		and		sec.process_name			=	req.process_name
		and		sec.project_name			=	req.project_name
		and		sec.activity_name			=	req.activity_name
		and		sec.component_name			=	req.component_name
		and		sec.ui_name					=	req.ui_name
		and     comp.customer_name			=	ctrl.customer_name	
		and		comp.project_name			=	ctrl.project_name
		and		comp.process_name			=	ctrl.process_name
		and		comp.component_name			=	ctrl.component_name
		and		comp.ctrl_type_name			=	ctrl.control_type	
		and		req.customer_name			=	ctrl.customer_name
		and		req.project_name			=	ctrl.project_name
		and		req.process_name			=	ctrl.process_name
		and		req.component_name			=	ctrl.component_name
		and		req.activity_name			=	ctrl.activity_name
		and		req.ui_name					=	ctrl.ui_name
		and		ctrl.page_bt_synonym		=	sec.page_bt_synonym
		and		ctrl.section_bt_synonym		=	sec.section_bt_synonym	
		and		req.customer_name			= 	@engg_customer_name
		and		req.project_name			= 	@engg_project_name
		and		req.req_no					=   rtrim(@engg_req_no)
  		and		section_type				=	'Completion Chart'
  		and		comp.base_ctrl_type			=	'EDIT'
		and		(comp.Isfallback= 'y' or comp.config_parameter= 'y' or comp.config_value= 'y')

		select @count_sec_comp	= COUNT(distinct section_bt_synonym)
		from ep_ui_section_dtl(nolock)
		where 	customer_name			= 	@engg_customer_name
		and		project_name			= 	@engg_project_name
		and		req_no					=   rtrim(@engg_req_no)
  		and		section_type				=	'Completion Chart' 
  		
  		if @count_cc < (3 * @count_sec_cc) or (@count_cc = 0 and @count_sec_comp <> 0)
			begin 
			Raiserror('Three Edit controls with property as Is Fallback, Configuration Parameter and Is Data must be defined for the Section Type Completion chart',16,1)
			return
			end
		
		select @count_iv	= count(distinct ctrl.control_bt_synonym) ,
		@count_sec_iv		= count(distinct ctrl.section_bt_synonym) 
		from  ep_ui_section_dtl sec(nolock),
		es_comp_ctrl_type_mst comp(nolock),
		ep_ui_control_dtl	ctrl	(nolock),
		ep_ui_req_dtl req(nolock)
		where	sec.customer_name			=	req.customer_name
		and		sec.process_name			=	req.process_name
		and		sec.project_name			=	req.project_name
		and		sec.activity_name			=	req.activity_name
		and		sec.component_name			=	req.component_name
		and		sec.ui_name					=	req.ui_name
		and     comp.customer_name			=	ctrl.customer_name	
		and		comp.project_name			=	ctrl.project_name
		and		comp.process_name			=	ctrl.process_name
		and		comp.component_name			=	ctrl.component_name
		and		comp.ctrl_type_name			=	ctrl.control_type	
		and		req.customer_name			=	ctrl.customer_name
		and		req.project_name			=	ctrl.project_name
		and		req.process_name			=	ctrl.process_name
		and		req.component_name			=	ctrl.component_name
		and		req.activity_name			=	ctrl.activity_name
		and		req.ui_name					=	ctrl.ui_name
		and		ctrl.page_bt_synonym		=	sec.page_bt_synonym
		and		ctrl.section_bt_synonym		=	sec.section_bt_synonym	
		and		req.customer_name			= 	@engg_customer_name
		and		req.project_name			= 	@engg_project_name
		and		req.req_no					=   rtrim(@engg_req_no)
		and		section_type				=	'Inplace Video'
		and		comp.base_ctrl_type			=	'EDIT'
		and		(comp.Isfallback= 'y' or comp.config_parameter= 'y')
		
		select @count_sec_inplace	= COUNT(distinct section_bt_synonym)
		from ep_ui_section_dtl(nolock)
		where 	customer_name			= 	@engg_customer_name
		and		project_name			= 	@engg_project_name
		and		req_no					=   rtrim(@engg_req_no)
  		and		section_type			=	'Inplace Video' 

				if @count_iv < (2 * @count_sec_iv)  or (@count_iv = 0 and @count_sec_inplace <> 0)
				begin 
					Raiserror('Two Edit controls with property as Is Fallback and Configuration Parameter must be defined for the section type Inplace Video ',16,1)
					return
				end
		
		select @count_link	= count(distinct ctrl.control_bt_synonym) ,
		@count_sec_iv		= count(distinct ctrl.section_bt_synonym) 
		from  ep_ui_section_dtl sec(nolock),
		es_comp_ctrl_type_mst comp(nolock),
		ep_ui_control_dtl	ctrl	(nolock),
		ep_ui_req_dtl req(nolock)
		where	sec.customer_name			=	req.customer_name
		and		sec.process_name			=	req.process_name
		and		sec.project_name			=	req.project_name
		and		sec.activity_name			=	req.activity_name
		and		sec.component_name			=	req.component_name
		and		sec.ui_name					=	req.ui_name
		and     comp.customer_name			=	ctrl.customer_name	
		and		comp.project_name			=	ctrl.project_name
		and		comp.process_name			=	ctrl.process_name
		and		comp.component_name			=	ctrl.component_name
		and		comp.ctrl_type_name			=	ctrl.control_type	
		and		req.customer_name			=	ctrl.customer_name
		and		req.project_name			=	ctrl.project_name
		and		req.process_name			=	ctrl.process_name
		and		req.component_name			=	ctrl.component_name
		and		req.activity_name			=	ctrl.activity_name
		and		req.ui_name					=	ctrl.ui_name
		and		ctrl.page_bt_synonym		=	sec.page_bt_synonym
		and		ctrl.section_bt_synonym		=	sec.section_bt_synonym	
		and		req.customer_name			= 	@engg_customer_name
		and		req.project_name			= 	@engg_project_name
		and		req.req_no					=   rtrim(@engg_req_no)
		and		section_type				=	'Inplace Video'
		and		comp.base_ctrl_type			=	'Link'
				if (@count_link <   @count_sec_iv )or (@count_link = 0 and @count_sec_iv <> 0)
				begin 
					Raiserror('One Link control must be defined for the section type Inplace Video ',16,1)
					return
				end
--validation added for inplace video and completion chart ends
--code added by chanheetha N A on 16-06-2006 for the call id: PNR2.0_8997
--code modified by kiruthika for bug id:PNR2.0_9012
--code modified for the call id : PNR2.0_9038

if exists ( select 'x'
from  ep_ui_traversal_dtl a(nolock),
ep_ui_req_dtl       c (nolock)
where c.customer_name   =   @engg_customer_name
and  c.project_name   =   @engg_project_name
and  c.req_no    =  @engg_req_no
and     c.customer_name   =   a.customer_name
and     c.project_name   =   a.project_name
and     c.process_name   =   a.process_name
and     c.component_name     =   a.component_name
and     c.activity_name    =   a.activity_name
and     c.ui_name     =   a.ui_name
and     not exists    ( select 'x'
from ep_action_mst b(nolock)
where a.customer_name   =   b.customer_name
and a.project_name   =   b.project_name
and   a.process_name   =   b.process_name
and  a.component_name     =   b.component_name
and   a.activity_name    =   b.activity_name
and   a.ui_name     =   b.ui_name
and   a.page_bt_synonym    =   b.page_bt_synonym
and   a.control_bt_synonym =   b.primary_control_bts
union
select 'x'
from ngplf_wr_template_action tmp(nolock)
where a.customer_name		=   tmp.CustomerID
and a.project_name			=   tmp.ProjectID
and   a.process_name		=   tmp.ProcessName
and   a.component_name		=   tmp.ComponentName
and   a.activity_name		=   tmp.ActivityName
and   a.ui_name				=   tmp.UIName
and   a.page_bt_synonym		=   tmp.PageName
--and   a.control_bt_synonym	=    tmp.ActionName	
and   a.control_bt_synonym	=    tmp.controlname+'_'+tmp.ActionName

)
)

begin

select  @control_bt_synonym = a.control_bt_synonym,
@ui_name            = a.ui_name
from  ep_ui_traversal_dtl a(nolock),
ep_ui_req_dtl    c (nolock)
where c.customer_name   =   @engg_customer_name
and  c.project_name   =   @engg_project_name
and  c.req_no    =  @engg_req_no
and     c.customer_name   =   a.customer_name
and     c.project_name   =   a.project_name
and     c.process_name   =   a.process_name
and     c.component_name     =   a.component_name
and     c.activity_name    =   a.activity_name
and     c.ui_name     =   a.ui_name
and     not exists    ( select 'x'
from ep_action_mst b(nolock)
where a.customer_name   =   b.customer_name
and a.project_name   =   b.project_name
and   a.process_name   =   b.process_name
and   a.component_name     =   b.component_name
and   a.activity_name    =   b.activity_name
and   a.ui_name     =   b.ui_name
and   a.page_bt_synonym    =   b.page_bt_synonym
and   a.control_bt_synonym =   b.primary_control_bts
-- Code added for TECH-28806 Starts
UNION
select 'x'
from ngplf_wr_template_action tmp(nolock)
where a.customer_name		=   tmp.CustomerID
and a.project_name			=   tmp.ProjectID
and   a.process_name		=   tmp.ProcessName
and   a.component_name		=   tmp.ComponentName
and   a.activity_name		=   tmp.ActivityName
and   a.ui_name				=   tmp.UIName
and   a.page_bt_synonym		=   tmp.PageName
--and   a.control_bt_synonym	=    tmp.ActionName
and   a.control_bt_synonym	=    tmp.controlname+'_'+tmp.ActionName
)
-- Code added for TECH-28806 Ends

select @msg =  'Traversal Information Exists without the Task for the Control "'+ @control_bt_synonym +'" in the UI "'+ @ui_name +'". please check the same'
exec engg_error_sp
ep_publ_sp_publcrml,1,@msg,@ctxt_language,@ctxt_ouinstance,
@ctxt_service,@ctxt_user,@pre_workreq_tmp,'','','',@m_errorid out
return
end
--TECH-74029 starts
if exists ( select 'x'
from  ep_listedit_control_map a(nolock), 
	  ep_ui_req_dtl       c (nolock)
where	c.customer_name   =   @engg_customer_name
and		c.project_name   =   @engg_project_name
and		c.req_no    =  @engg_req_no
and     c.customer_name   =   a.customer_name
and     c.project_name   =   a.project_name
and     c.process_name   =   a.process_name
and     c.component_name     =   a.component_name
and     c.activity_name    =   a.activity_name
and     c.ui_name     =   a.ui_name
and     not exists    ( select 'x'
from ep_listedit_column_dtl b(nolock)
where a.customer_name   =   b.customer_name
and a.project_name   =   b.project_name
and   a.process_name   =   b.process_name
and  a.component_name     =   b.component_name
and   a.activity_name    =   b.activity_name
and   a.ui_name     =   b.ui_name
and   a.listedit_synonym =   b.listedit_synonym
))
begin

select  @control_bt_synonym = a.listedit_synonym,--TECH-74029
		@ui_name            = a.ui_name
from  ep_listedit_control_map a(nolock),
ep_ui_req_dtl    c (nolock)
where c.customer_name   =   @engg_customer_name
and  c.project_name   =   @engg_project_name
and  c.req_no    =  @engg_req_no
and     c.customer_name   =   a.customer_name
and     c.project_name   =   a.project_name
and     c.process_name   =   a.process_name
and     c.component_name     =   a.component_name
and     c.activity_name    =   a.activity_name
and     c.ui_name     =   a.ui_name
and     not exists    ( select 'x'
from ep_listedit_column_dtl b(nolock)
where a.customer_name   =   b.customer_name
and a.project_name   =   b.project_name
and   a.process_name   =   b.process_name
and  a.component_name     =   b.component_name
and   a.activity_name    =   b.activity_name
and   a.ui_name     =   b.ui_name
and   a.listedit_synonym =   b.listedit_synonym
)
select @msg =  'Columns has not defined for the List Edit controls "' +  @control_bt_synonym +'" in the UI "'+ @ui_name +'".'
exec engg_error_sp
ep_publ_sp_publcrml,1,@msg,@ctxt_language,@ctxt_ouinstance,
@ctxt_service,@ctxt_user,@pre_workreq_tmp,'','','',@m_errorid out
return
end
--TECH-74029 ends

--Code Added for Defect ID : TECH-39534 Starts
-- JL Starts
if exists ( select 'x'
from  ep_listedit_control_map a(nolock), --Code Modified for Defect ID : TECH-50097
	  ep_ui_req_dtl       c (nolock)
where	c.customer_name   =   @engg_customer_name
and		c.project_name   =   @engg_project_name
and		c.req_no    =  @engg_req_no
and     c.customer_name   =   a.customer_name
and     c.project_name   =   a.project_name
and     c.process_name   =   a.process_name
and     c.component_name     =   a.component_name
and     c.activity_name    =   a.activity_name
and     c.ui_name     =   a.ui_name
and     not exists    ( select 'x'
from ep_resolvelist_data_map b(nolock)
where a.customer_name   =   b.customer_name
and a.project_name   =   b.project_name
and   a.process_name   =   b.process_name
and  a.component_name     =   b.component_name
and   a.activity_name    =   b.activity_name
and   a.ui_name     =   b.ui_name
and   a.listedit_synonym =   b.listedit_synonym
))
begin

select  @control_bt_synonym = a.listedit_synonym,
		@ui_name            = a.ui_name
from  ep_listedit_column_dtl a(nolock),
ep_ui_req_dtl    c (nolock)
where c.customer_name   =   @engg_customer_name
and  c.project_name   =   @engg_project_name
and  c.req_no    =  @engg_req_no
and     c.customer_name   =   a.customer_name
and     c.project_name   =   a.project_name
and     c.process_name   =   a.process_name
and     c.component_name     =   a.component_name
and     c.activity_name    =   a.activity_name
and     c.ui_name     =   a.ui_name
and     not exists    ( select 'x'
from ep_resolvelist_data_map b(nolock)
where a.customer_name   =   b.customer_name
and a.project_name   =   b.project_name
and   a.process_name   =   b.process_name
and  a.component_name     =   b.component_name
and   a.activity_name    =   b.activity_name
and   a.ui_name     =   b.ui_name
and   a.listedit_synonym =   b.listedit_synonym
)
select @msg =  'Resolve has not done for the List Edit controls "' +  @control_bt_synonym +'" in the UI "'+ @ui_name +'".'
exec engg_error_sp
ep_publ_sp_publcrml,1,@msg,@ctxt_language,@ctxt_ouinstance,
@ctxt_service,@ctxt_user,@pre_workreq_tmp,'','','',@m_errorid out
return
end
-- JL ENDs
--Code Added for Defect ID : TECH-39534 Ends
--code commented by 11536 for glance check

-- code added by kiruthika on 5-sep-2006 for the Bug ID :: PNR2.0_10166 - start
if exists (  Select  'x'
from  ep_action_mst   a (nolock),
ep_ui_req_dtl       b (nolock)
where   b.customer_name    = @engg_customer_name
and   b.project_name    = @engg_project_name
and   b.req_no         = @engg_req_no
and     b.customer_name   = a.customer_name
and     b.project_name   = a.project_name
and     b.process_name   = a.process_name
and     b.component_name     = a.component_name
group by a.customer_name, a.project_name, a.process_name, a.component_name, a.task_name
having count(distinct task_descr) > 1
)
begin
Select  @task_name =  a.task_name
from  ep_action_mst   a (nolock),
ep_ui_req_dtl       b (nolock)
where   b.customer_name    = @engg_customer_name
and   b.project_name    = @engg_project_name
and   b.req_no         = @engg_req_no
and     b.customer_name   = a.customer_name
and     b.project_name   = a.project_name
and     b.process_name   = a.process_name
and     b.component_name     = a.component_name
group by a.customer_name, a.project_name, a.process_name, a.component_name, a.task_name
having count(distinct task_descr) > 1

select @msg =  'For the Task name "'+ @task_name + '" more than one task description exists within the component. Please change the same'
exec engg_error_sp
ep_publ_sp_publcrml,1,@msg,@ctxt_language,@ctxt_ouinstance,
@ctxt_service,@ctxt_user,@pre_workreq_tmp,'','','',@m_errorid out
return
end

if exists (  Select  'x'
from  ep_action_mst_lng_extn   a (nolock) ,
ep_ui_req_dtl       b (nolock)
where   b.customer_name    = @engg_customer_name
and   b.project_name    = @engg_project_name
and   b.req_no         = @engg_req_no
and     b.customer_name   = a.customer_name
and     b.project_name   = a.project_name
and     b.process_name   = a.process_name
and     b.component_name     = a.component_name
group by a.customer_name, a.project_name, a.process_name, a.component_name, a.task_name, a.languageid
having count(distinct task_descr) > 1
)
begin

Select  @task_name =  a.task_name,
@language =  b.quick_code_value
from  ep_action_mst_lng_extn  a (nolock),
ep_language_met    b (nolock),
ep_ui_req_dtl       c (nolock)
where   c.customer_name   = @engg_customer_name
and   c.project_name   = @engg_project_name
and   c.req_no        = @engg_req_no
and     c.customer_name   = a.customer_name
and     c.project_name   = a.project_name
and   c.process_name   = a.process_name
and     c.component_name     = a.component_name
and     a.languageid = b.quick_code
group by a.customer_name, a.project_name, a.process_name, a.component_name, a.task_name, a.languageid, b.quick_code_value
having count(distinct task_descr) > 1

select @msg =  'In the "'+  @language + '" language, For the Task name "'+ @task_name + '" more than one task description exists within the component. Please change the same'
exec engg_error_sp
ep_publ_sp_publcrml,1,@msg,@ctxt_language,@ctxt_ouinstance,
@ctxt_service,@ctxt_user,@pre_workreq_tmp,'','','',@m_errorid out
return
end
-- code added by kiruthika  on 5-sep-2006 for the Bug ID :: PNR2.0_10166 - End

--Code Commented for bugId : PNR2.0_13970
-- code added  by Anuradha on 16-Nov-2006 for Bug Id :: PNR2.0_11042
--    if exists(
--     select 'x'
--     from  ep_component_glossary_mst_lng_extn A (nolock),
--      ep_ui_req_dtl    b (nolock)
--     where A.customer_name  = @engg_customer_name
--     and A.Project_name  = @engg_project_name
--     and b.req_no  =  @engg_req_no
--     and a.customer_name  =  b.customer_name
--     and a.Project_name  = b.Project_name
--     and a.process_name  =  b.process_name
--     and a.component_name =  b.component_name
--     and  len(a.bt_synonym_caption) > 60
--    )
--    begin
--
--     select  @bt_synonym_name =  a.bt_synonym_name,
--      @language  =  c.quick_code_value
--     from  ep_component_glossary_mst_lng_extn A (nolock),
--      ep_ui_req_dtl    b (nolock),
--      ep_language_met      c (nolock)
--     where A.customer_name  = @engg_customer_name
--     and A.Project_name  = @engg_project_name
--     and b.req_no  =  @engg_req_no
--     and a.customer_name  =  b.customer_name
--     and a.Project_name  = b.Project_name
--     and a.process_name  =  b.process_name
--     and a.component_name =  b.component_name
--     and  len(a.bt_synonym_caption) > 60
--     and a.languageid  =  c.quick_code
--
--     select @msg =  'In the "'+  @language + '" language, For the synonym "'+  @bt_synonym_name + '" the length of BT synonym caption exceeds 60 characters. Please change the same.'
--     exec engg_error_sp
--       ep_publ_sp_publcrml,1,@msg,@ctxt_language,@ctxt_ouinstance,
--       @ctxt_service,@ctxt_user,@pre_workreq_tmp,'','','',@m_errorid out
--     return
--    end

-- code added  by Anuradha on 16-Nov-2006 for Bug Id :: PNR2.0_11042
--code added by chanheetha N A on 16-06-2006 for the call id: PNR2.0_8997



-- code modification  for  PNR2.0_22560 starts
/*select @msg = ''

select  @msg = 'The  section ' + a.section_bt_synonym + ' in comp\activity\ui\page : ' + a.component_name+'\'+a.activity_name+'\'+ a.ui_name + '\'+ a.page_bt_synonym
+ 'has header control along with a grid. Specify the Grid in a seperate section.'
from  ep_ui_req_dtl      d(nolock),
ep_ui_control_dtl  a(nolock),
es_comp_ctrl_type_mst  b(nolock),
ep_ui_section_dtl c(nolock)

where   d.customer_name    = @engg_customer_name
and    d.project_name    = @engg_project_name
and    d.req_no         = @engg_req_no

and d.customer_name    =  a.customer_name   -- code Modification by Gopinath S for the Call ID PNR2.0_24356 begins
and  d.project_name    =  a.project_name
and  d.process_name    =  a.process_name
and  d.component_name   = a.component_name
and     d.activity_name  =  a.activity_name
and     d.ui_name  =  a.ui_name   -- code Modification by Gopinath S for the Call ID PNR2.0_24356 ends
and  a.section_bt_synonym <> 'PrjHdnSection'

and		c.customer_name			= a.customer_name
and		c.project_name			= a.project_name
and		c.process_name			= a.process_name 
and		c.component_name		= a.component_name
and		c.activity_name			= a.activity_name
and		c.ui_name				= a.ui_name
and		c.page_bt_synonym		= a.page_bt_synonym
and		c.section_bt_synonym	= a.section_bt_synonym
and		c.section_type			<> 'Carousel'

and  a.customer_name   = b.customer_name
and  a.project_name   = b.project_name
and  a.req_no    = b.req_no -- code added by Gopinath S for the Call ID PNR2.0_24356
and  a.process_name   = b.process_name
and  a.component_name  = b.component_name
and  a.control_type   = b.ctrl_type_name
and  b.base_ctrl_type  <> 'Grid'
and  exists ( select 'x'
from ep_ui_grid_dtl   c(nolock),
es_comp_ctrl_type_mst  e(nolock),
ep_ui_control_dtl f (nolock)
where c.customer_name   = a.customer_name
and  c.project_name   = a.project_name
and  c.req_no    = a.req_no -- code added by Gopinath S for the Call ID PNR2.0_24356
and  c.process_name   = a.process_name
and  c.component_name  = a.component_name
and  c.activity_name   = a.activity_name
and  c.ui_name    = a.ui_name
and  c.page_bt_synonym  = a.page_bt_synonym
and  c.section_bt_synonym = a.section_bt_synonym

and c.customer_name   = f.customer_name
and  c.project_name   = f.project_name
and  c.req_no    = f.req_no -- code added by Gopinath S for the Call ID PNR2.0_24356
and  c.process_name   = f.process_name
and  c.component_name  = f.component_name
and  c.activity_name   = f.activity_name
and  c.ui_name    = f.ui_name
and  c.page_bt_synonym  = f.page_bt_synonym
and  c.section_bt_synonym = f.section_bt_synonym
and c.control_bt_synonym = f.control_bt_synonym

and  f.customer_name   = e.customer_name
and  f.project_name   = e.project_name
and  f.req_no    = e.req_no -- code added by Gopinath S for the Call ID PNR2.0_24356
and  f.process_name   = e.process_name
and  f.component_name  = e.component_name
and  f.control_type   = e.ctrl_type_name
and  e.base_ctrl_type  <> 'ListEdit')
order by a.customer_name, a.project_name, a.process_name, a.component_name, a.activity_name, a.ui_name, a.page_bt_synonym, a.section_bt_synonym, a.control_bt_synonym

if isnull(@msg , '') <> ''
begin
exec   engg_error_sp 'ep_pubact_sp_publgrid', 1, @msg,
@ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user,
'', '', '', '', @m_errorid
return
end*/
		--commented by 11536 for glance 
	--select   @msg = ''
	
	--select @msg = 'The  section ' + a.section_bt_synonym + ' in comp\activity\ui\page : ' + a.component_name+'\'+a.activity_name+'\'+ a.ui_name + '\'+ a.page_bt_synonym
	--+ 'contains more than one grid . A section can contain only one Grid.'
	--from    ep_ui_req_dtl    d(nolock),
	--ep_ui_control_dtl  a (nolock) ,
	--es_comp_ctrl_type_mst  b (nolock)
	
	--where   d.customer_name    = @engg_customer_name
	--and    d.project_name    = @engg_project_name
	--and    d.req_no         = @engg_req_no
	
	--and d.customer_name    =  rtrim(a.customer_name)
	--and  d.project_name    =  rtrim(a.project_name)
	--and  d.process_name    =  rtrim(a.process_name)
	--and  d.component_name   =  rtrim(a.component_name)
	--and     d.activity_name  =  rtrim(a.activity_name)
	--and     d.ui_name  =  rtrim(a.ui_name)
	--and  a.section_bt_synonym <> 'PrjHdnSection'
	
	--and   a.customer_name  = b.customer_name
	--and     a.project_name  = b.project_name
	--and     a.process_name  = b.process_name
	--and     a.component_name = b.component_name
	--and     a.control_type  = b.ctrl_type_name
	--and b.base_ctrl_type = 'grid'
	----and 	isnull(isassorted,'N')  = 'N'
	--group by  a.customer_name, a.project_name,a.process_name, a.component_name, a.activity_name ,a.ui_name, a.page_bt_synonym, a.section_bt_synonym
	--having  count(*) >  1

if isnull(@msg , '') <> ''
begin
exec   engg_error_sp 'ep_pubact_sp_publgrid', 1, @msg,
@ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user,
'', '', '', '', @m_errorid
return
end

-- code modification  for  PNR2.0_22560 ends

-- Code modification for PNR2.0_22818 starts

If exists (select  '*' from ep_ui_req_dtl d (nolock),
ep_ui_state_column_dtl  a (nolock)

where   d.customer_name    =  @engg_customer_name
and    d.project_name    =  @engg_project_name
and    d.req_no         =  @engg_req_no

and  d.customer_name   =  a.customer_name
and    d.project_name   =  a.project_name
and    d.process_name   =  a.process_name
and    d.component_name   =  a.component_name
)

BEGIN


select
a.customer_name,a.project_name,a.process_name,a.component_name,a.activity_name,
a.ui_name,a.page_bt_synonym,a.section_bt_synonym,a.control_bt_synonym,count(*) 'count1'
into #ep_validate_column
from    ep_ui_req_dtl  d (nolock),
ep_ui_grid_dtl a(nolock)

where   d.customer_name    =  @engg_customer_name
and    d.project_name    =  @engg_project_name
and    d.req_no         =  @engg_req_no

and   d.customer_name   =  a.customer_name
and    d.project_name   =  a.project_name
and    d.process_name   =  a.process_name
and    d.component_name   =  a.component_name
and    d.activity_name   =  a.activity_name
and     d.ui_name  =  a.ui_name
group by a.customer_name,a.project_name,a.process_name,a.component_name,a.activity_name,
a.ui_name,a.page_bt_synonym,a.section_bt_synonym,a.control_bt_synonym

select
a.customer_name,a.project_name,a.process_name,a.component_name,a.activity_name,
a.ui_name,a.page_bt_synonym,a.state_id,a.section_bt_synonym,a.control_bt_synonym,count(*) 'cnt_state'
into #ep_validate_state_column
from    ep_ui_req_dtl  d (nolock),
ep_ui_state_column_dtl a(nolock)

where   d.customer_name    =  @engg_customer_name
and    d.project_name    =  @engg_project_name
and    d.req_no         =  @engg_req_no

and   d.customer_name   =  a.customer_name
and    d.project_name   =  a.project_name
and    d.process_name   =  a.process_name
and    d.component_name   =  a.component_name
and    d.activity_name   =  a.activity_name
and     d.ui_name  =  a.ui_name
and     a.visible  =  'N'
group by a.customer_name,a.project_name,a.process_name,a.component_name,a.activity_name,
a.ui_name,a.page_bt_synonym,a.state_id,a.section_bt_synonym,a.control_bt_synonym


select   @msg = ''

select @msg = 'In the state : ' + b.state_id + ' defined for comp\activity\ui\page : ' + a.component_name+'\'+a.activity_name+'\'+ a.ui_name + '\'+ a.page_bt_synonym
+ ' all the columns of the Grid : ' + a.control_bt_synonym + ' are hidden.Hide the grid section to hide a grid'

from  ep_ui_req_dtl d (nolock),
#ep_validate_column a  (nolock),
#ep_validate_state_column b (nolock)

where  d.customer_name   =  (@engg_customer_name)
and    d.project_name   =  (@engg_project_name)
and    d.req_no      =  (@engg_req_no)

and   d.customer_name   =  a.customer_name
and    d.project_name   =  a.project_name
and    d.process_name   =  a.process_name
and    d.component_name   =  a.component_name
and    d.activity_name   =  a.activity_name
and     d.ui_name  =  a.ui_name

and   a.customer_name   =  b.customer_name
and    a.project_name   =  b.project_name
and    a.process_name   =  b.process_name
and    a.component_name   =  b.component_name
and    a.activity_name   =  b.activity_name
and     a.ui_name  =  b.ui_name
and     a.page_bt_synonym =  b.page_bt_synonym
and     a.section_bt_synonym =  b.section_bt_synonym
and     a.control_bt_synonym =  b.control_bt_synonym
and     a.count1  =  b.cnt_state


if isnull(@msg , '') <> ''
begin
exec   engg_error_sp 'ep_pubact_sp_publgrid', 1, @msg,
@ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user,
'', '', '', '', @m_errorid
return
end


END

-- Code modification for PNR2.0_22818 ends

if exists (
select 'X'
from ep_ui_req_dtl (nolock)
where customer_name =  (@engg_customer_name)
and  project_name =  (@engg_project_name)
and  req_no   =  (@engg_req_no)
--and  req_status  = 'C'
)

begin--1
-- code modified by shafina on 15-jan-2004 starts
if @engg_req_no = 'BASE'
begin
declare main_cur cursor
for
select distinct r.customer_name , r.project_name , --Code modified for the Bug ID:PNR2.0_33856
r.process_name , r.component_name , r.activity_name ,
r.ui_name
from ep_ui_req_dtl r (nolock),
ep_bpt_download_vw b(nolock),
ep_bpt_activity_ppw_vw p(nolock)
where r.customer_name =  (@engg_customer_name)
and  r.project_name =  (@engg_project_name)
and  r.req_no  =  (@engg_req_no)
and  r.customer_name =  b.customer_name
and  r.project_name =  b.project_name
and  r.req_no  =  b.req_no
and  r.process_name = b.process_name
and  r.component_name= b.component_name
and  r.activity_name = b.activity_name
and  r.ui_name  = b.ui_name
-- code commented by shafina on 18-feb-2005 for PREVIEWENG203SYS_000211(The status of the Work request is not getting changed to published status even after publishing )
--    and  r.activity_name <> 'IntegrationActivity'
--    and  r.ui_name  <> 'IntegrationUI'
and  b.customer_name =  p.customerid
and  b.project_name =  p.projectid
and  b.req_no  =  p.workreqid
and  b.process_name = p.bpid
and  b.functionid = p.functionid
and  b.activity_name = p.activityid
--     and  p.previewready = 'RPP'
--    and  b.previewready is not null
and  r.ui_name   <>  ''
-- code modified by giri on 14-jan-2004 starts
--    and  ui_name   <>  ''
--    and  activity_name  in  (
--           select  activityid
--           from  fw_bpt_activity (nolock)
--           where  customerid = (@engg_customer_name)
--           and  projectid = (@engg_project_name)
--           and  previewready= 'RPW' -- 'RPP' ??
--           )
-- code modified by giri on 14-jan-2004 ends
end
else
begin
declare main_cur cursor
for
select distinct r.customer_name , r.project_name ,--Code modified for the Bug ID:PNR2.0_33856
r.process_name , r.component_name , r.activity_name ,
r.ui_name
from ep_ui_req_dtl r (nolock),
ep_cmt_download_vw c(nolock),
ep_cmt_activity_ppw_vw p(nolock)
where r.customer_name =  (@engg_customer_name)
and  r.project_name =  (@engg_project_name)
and  r.req_no  =  (@engg_req_no)
and  r.customer_name =  c.customer_name
and  r.project_name =  c.project_name
and  r.req_no  =  c.req_no
and  r.process_name = c.process_name
and  r.component_name= c.component_name
and  r.activity_name = c.activity_name
and  r.ui_name  = c.ui_name
--    and  r.activity_name <> 'IntegrationActivity'
--    and  r.ui_name  <> 'IntegrationUI'
and  c.customer_name =  p.customerid
and  c.project_name =  p.projectid
and  c.req_no  =  p.workreqid
and  c.process_name = p.bpid
and  c.functionid = p.functionid
and  c.activity_name = p.activityid
--     and  p.previewready = 'RPP'
--and  c.previewready is not null
and  r.ui_name   <>  ''
-- code modified by giri on 14-jan-2004 starts
--    and  ui_name   <>  ''
--    and  activity_name  in  (
--           select  activityid
--           from  fw_bpt_activity (nolock)
--           where  customerid = (@engg_customer_name)
--           and projectid = (@engg_project_name)
--           and  previewready= 'RPW' -- 'RPP' ??
--           )
end
-- code modified by shafina on 15-jan-2004 ends
open main_cur

while 1 = 1
begin --main_cur
fetch  next from main_cur
into @customer_name_temp , @project_name_temp ,
@process_name_temp , @component_name_temp , @activity_name_temp ,
@ui_name_temp

if @@fetch_status <> 0
begin
break
end

-- code added by shafina on 04-feb-2004 to implement validation logic
-- VALIDATION
exec ep_validation_sp
@ctxt_language,   @ctxt_ouinstance,   @ctxt_service,
@ctxt_user,    @customer_name_temp,  @project_name_temp,
@engg_base_req_no,  @process_name_temp,   @component_name_temp,
@activity_name_temp, @ui_name_temp,    @m_errorid output
if @m_errorid <> 0
begin
close main_cur
deallocate main_cur
return
end

/*Code added for the Defect Id Tech-70687 starts*/
Declare @sectionname NVARCHAR(MAX)
SELECT  @sectionname = STUFF(
(SELECT ','+ section_bt_synonym
FROM ep_ui_section_dtl WITH (NOLOCK)       
WHERE customer_name  =  rtrim(@engg_customer_name)
AND  project_name	 =  rtrim(@engg_project_name)
and	 process_name	 =  rtrim(@process_name_temp)
and  component_name  =  rtrim(@component_name_temp)
and  activity_name   =  rtrim(@activity_name_temp)
and  ui_name		 =  rtrim(@ui_name_temp)
AND  horder			 =  601
AND section_bt_synonym NOT IN (SELECT DISTINCT a.section_bt_synonym            
FROM ep_ui_section_dtl (NOLOCK) a
JOIN ep_ui_control_dtl (NOLOCK) b
ON a.customer_name	=  b.customer_name
AND a.project_name	=  b.project_name
AND a.process_name	=  b.process_name
AND	a.component_name=  b.component_name
AND a.activity_name	=  b.activity_name
AND a.ui_name		=  b.ui_name
AND a.page_bt_synonym	 = b.page_bt_synonym
AND a.section_bt_synonym = b.section_bt_synonym
WHERE a.customer_name		=  rtrim(@engg_customer_name)
AND   a.project_name		=  rtrim(@engg_project_name)
and	  a.process_name		=  rtrim(@process_name_temp)
and   a.component_name		=  rtrim(@component_name_temp)
and   a.activity_name		=  rtrim(@activity_name_temp)
and   a.ui_name				=  rtrim(@ui_name_temp)
AND   a.horder = 601) 
FOR XML PATH ('')), 1, 1, ''
) 

SELECT @msg = 'For the UI : '+@ui_name_temp+', Some of the toolbar sections ['+@sectionname+'] does not have any controls.'

IF EXISTS(
SELECT 'X'  --> 6
FROM ep_ui_section_dtl WITH (NOLOCK)       
WHERE customer_name  =  rtrim(@engg_customer_name)
AND  project_name	 =  rtrim(@engg_project_name)
and	 process_name	 =  rtrim(@process_name_temp)
and  component_name  =  rtrim(@component_name_temp)
and  activity_name   =  rtrim(@activity_name_temp)
and  ui_name		 =  rtrim(@ui_name_temp)
AND  horder			 =  601
AND section_bt_synonym NOT IN (SELECT DISTINCT a.section_bt_synonym            
FROM ep_ui_section_dtl (NOLOCK) a
JOIN ep_ui_control_dtl (NOLOCK) b
ON a.customer_name	=  b.customer_name
AND a.project_name	=  b.project_name
AND a.process_name	=  b.process_name
AND	a.component_name=  b.component_name
AND a.activity_name	=  b.activity_name
AND a.ui_name		=  b.ui_name
AND a.page_bt_synonym	 = b.page_bt_synonym
AND a.section_bt_synonym = b.section_bt_synonym
WHERE a.customer_name		=  rtrim(@engg_customer_name)
AND   a.project_name		=  rtrim(@engg_project_name)
and	  a.process_name		=  rtrim(@process_name_temp)
and   a.component_name		=  rtrim(@component_name_temp)
and   a.activity_name		=  rtrim(@activity_name_temp)
and   a.ui_name				=  rtrim(@ui_name_temp)
AND   a.horder = 601) )
BEGIN
	RAISERROR (@msg,16,1)
	RETURN
END

/*Code added for the Defect Id Tech-70687 starts*/



--exec PLF_Process_Multi_Lang_Caption @engg_customer_name,@engg_project_name,@process_name_temp,@component_name_temp,@engg_req_no

-- page layout validation starts

if exists  (select 'x'
from  ep_ui_section_dtl (nolock)
where customer_name = @engg_customer_name
and  project_name = @engg_project_name
and	 process_name = @process_name_temp
and  component_name = @component_name_temp
and  activity_name = @activity_name_temp
and  ui_name   = @ui_name_temp
and  (horder   = 0 or vorder = 0))
begin
select @m_errorid = 5
--Code Modified for bugId : PNR2.0_11746
raiserror ('For Component : %s, Activity: %s, Page Layout is not defined for one or more of the pages.',16,1,@component_name_temp,@activity_name_temp)
return
end

-- page layout validation ends
--validation added by 11536 for checking glance ui
	
	declare @isglance engg_name
	select  @isglance=dbo.ngplf_get_isglanceui (@customer_name_temp,@project_name_temp,@process_name_temp,@component_name_temp,@activity_name_temp,@ui_name_temp)

	If isnull(@isglance,'N') = 'N'
Begin	--  @isglance starts

--Code Modified For bugId : PNR2.0_6079
--Code added against TECH-218 starts
if exists( select 'x'
from ep_ui_req_dtl  a(nolock),ep_new_ui_mst b(nolock)
where 	a.customer_name		 =	@customer_name_temp
and   	a.project_name		 =	@project_name_temp
and   	a.req_no			 =	@engg_req_no
and		a.process_name		 =  @process_name_temp
and  	a.component_name	 =	@component_name_temp
and  	a.activity_name		 =  @activity_name_temp
and  	a.ui_name			 =  @ui_name_temp
and		a.customer_name		 =	b.customer_name  
and		a.project_name		 =	b.project_name	
and		a.process_name		 =	b.process_name	
and		a.component_name	 =	b.component_name	
and		a.activity_name	     =	b.activity_name
and		a.ui_name			 =  b.ui_name )
begin 
       
      Exec ep_ui_layout_validation @customer_name_temp,@project_name_temp,@process_name_temp,
	@component_name_temp,@activity_name_temp,@ui_name_temp,'','','Page', @ctxt_user_in

end

select   @msg = ''
	
	select @msg = 'The  section ' + a.section_bt_synonym + ' in comp\activity\ui\page : ' + a.component_name+'\'+a.activity_name+'\'+ a.ui_name + '\'+ a.page_bt_synonym
	+ 'contains more than one grid . A section can contain only one Grid.'
	from    ep_ui_req_dtl    d(nolock),
	ep_ui_control_dtl  a (nolock) ,
	es_comp_ctrl_type_mst  b (nolock)
	
	where   d.customer_name    = @engg_customer_name
	and    d.project_name    = @engg_project_name
	and    d.req_no         = @engg_req_no
	
	and d.customer_name    =  rtrim(a.customer_name)
	and  d.project_name    =  rtrim(a.project_name)
	and  d.process_name    =  rtrim(a.process_name)
	and  d.component_name   =  rtrim(a.component_name)
	and     d.activity_name  =  rtrim(a.activity_name)
	and     d.ui_name  =  rtrim(a.ui_name)
	and  a.section_bt_synonym <> 'PrjHdnSection'
	
	and   a.customer_name  = b.customer_name
	and     a.project_name  = b.project_name
	and     a.process_name  = b.process_name
	and     a.component_name = b.component_name
	and     a.control_type  = b.ctrl_type_name
	and b.base_ctrl_type = 'grid'
	--and 	isnull(isassorted,'N')  = 'N'
	-- Added for Calendar Starts Defect ID: TECH-35368
	and a.section_bt_synonym not in (
	Select distinct section_bt_synonym 
	from	ep_ui_control_dtl ctl (nolock),
			es_comp_ctrl_type_mst_extn ext (nolock)
	where	ctl.customer_name		= ext.customer_name
	and		ctl.project_name		= ext.project_name
	and		ctl.process_name		= ext.process_name
	and		ctl.component_name		= ext.component_name
	and		ctl.control_type		= ext.ctrl_type_name
	and		ext.base_ctrl_type		= 'Grid'
	and		ext.CalendarControl		= 'Y'

	and		ctl.customer_name		= (@engg_customer_name)
	and		ctl.project_name		= (@engg_project_name)
	and		ctl.req_no				= (@engg_req_no)
	UNION
	Select distinct section_bt_synonym 
	from	ep_ui_control_dtl ctl (nolock),
			es_comp_ctrl_type_mst_extn ext (nolock)
	where	ctl.customer_name		= ext.customer_name
	and		ctl.project_name		= ext.project_name
	and		ctl.process_name		= ext.process_name
	and		ctl.component_name		= ext.component_name
	and		ctl.control_type		= ext.ctrl_type_name
	and		ext.base_ctrl_type		= 'TreeGrid'
	and		ext.GanttControl		= 'Y'

	and		ctl.customer_name		= (@engg_customer_name)
	and		ctl.project_name		= (@engg_project_name)
	and		ctl.req_no				= (@engg_req_no)	
	)-- Added for Calendar Ends Defect ID: TECH-35368

	group by  a.customer_name, a.project_name,a.process_name, a.component_name, a.activity_name ,a.ui_name, a.page_bt_synonym, a.section_bt_synonym
	having  count(*) >  1
END


--  @isglance Ends
--Code added against TECH-218 ends

--Code Modified For bugId : PNR2.0_6079
if exists ( select 'x'
from ep_ui_req_dtl a(nolock),
ep_ui_req_dtl b(nolock)
where a.customer_name  =  (@customer_name_temp)
and  a.project_name  =  (@project_name_temp)
and  a.req_no   = (@engg_req_no)
and  a.process_name  = (@process_name_temp)
and  a.component_name = (@component_name_temp)
and  a.activity_name  = (@activity_name_temp)
and  a.ui_name   = (@ui_name_temp)
and  a.req_status  = 'C'
and  a.customer_name  = b.customer_name
and  a.project_name  = b.project_name
and  a.req_no   <>  b.req_no
and  a.req_status  = b.req_status
and  a.process_name  = b.process_name
and  a.component_name = b.component_name
and  a.activity_name  = b.activity_name
and  a.ui_name   = b.ui_name
and  a.createddate  >   b.createddate)
begin
select @pre_workreq_tmp = b.req_no,
@activitydescr_tmp = b.activity_descr
from ep_ui_req_dtl a(nolock),
ep_ui_req_dtl b(nolock)
where a.customer_name  =  (@customer_name_temp)
and  a.project_name  =  (@project_name_temp)
and  a.req_no   = (@engg_req_no)
and  a.process_name  = (@process_name_temp)
and  a.component_name = (@component_name_temp)
and  a.activity_name  = (@activity_name_temp)
and  a.ui_name   = (@ui_name_temp)
and  a.req_status  = 'C'
and  a.customer_name  = b.customer_name
and  a.project_name  = b.project_name
and  a.req_no   <>  b.req_no
and  a.req_status  = b.req_status
and  a.process_name  = b.process_name
and  a.component_name = b.component_name
and  a.activity_name  = b.activity_name
and  a.ui_name   = b.ui_name
and  a.createddate  >   b.createddate

select @msg = 'Please Publish the Previous Work Request : <%1>, Activity <%2>  is in unpublished status'
exec engg_error_sp
ep_publ_sp_publcrml,1,@msg,@ctxt_language,@ctxt_ouinstance,
@ctxt_service,@ctxt_user,@pre_workreq_tmp,@activitydescr_tmp,'','',@m_errorid out

close main_cur
deallocate main_cur
return
end

-- Code moved for PNR2.0_13724 on 21-May-2007

delete from ep_published_ui_state_dtl
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)

delete from ep_published_ui_state_section_dtl
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)

delete from ep_published_ui_state_control_dtl
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no  =  (@engg_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)

delete from ep_published_ui_state_task_dtl
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)

delete from ep_published_ui_state_task_mst
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)

-- Code added for Extn js by Jeya -- PNR2.0_1790
delete from ep_published_ui_state_column_dtl
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)

delete from ep_published_ui_state_page_dtl
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)
---Deleting device tables
--Delete device tables



delete from ep_published_ui_device_dtl
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)

delete from ep_published_ui_device_page_dtl
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)

delete from ep_published_ui_device_section_dtl
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)

delete from ep_published_ui_device_control_dtl
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)

delete from ep_published_ui_device_grid_dtl
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)
-- Code added for Extn js by Jeya -- PNR2.0_1790
--code added by kiruthika for bugid:PLF2.0_03710
			delete from	ep_published_custom_listedit
			where 	customer_name 	= @customer_name_temp
			and  	project_name 	= @project_name_temp
			and  	req_no   		= @engg_req_no
			and  	process_name 	= @process_name_temp
			and  	component_name 	= @component_name_temp
			and  	activity_name 	= @activity_name_temp
			and  	ui_name   		= @ui_name_temp	

			insert into ep_published_custom_listedit
			(customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, listedit_synonym, list_search_id,
			 list_search_context, list_index_search, list_recurrent_search, list_search_delay, list_select_column, list_result_column, list_width,
			 createdby, createddate, modifiedby, modifieddate)
			select distinct
			customer_name, project_name, @engg_req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, listedit_synonym, list_search_id,
			 list_search_context, list_index_search, list_recurrent_search, list_search_delay, list_select_column, list_result_column, list_width,
			 @ctxt_user, @date, @ctxt_user, @date
			from	ep_custom_listedit (nolock)
			where 	customer_name 	= @customer_name_temp
			and  	project_name 	= @project_name_temp
			and  	process_name 	= @process_name_temp
			and  	component_name 	= @component_name_temp
			and  	activity_name 	= @activity_name_temp
			and  	ui_name   		= @ui_name_temp	
--code added by kiruthika for bugid:PLF2.0_03710

-- Added By Jeya Latha K for Contextual Links and control Extensions Start

			delete from	ep_published_contextual_links
			where 	customer_name 	= @customer_name_temp
			and  	project_name 	= @project_name_temp
			and  	req_no   		= @engg_req_no
			and  	process_name 	= @process_name_temp
			and  	component_name 	= @component_name_temp
			and  	activity_name 	= @activity_name_temp
			and  	ui_name   		= @ui_name_temp	

			insert into ep_published_contextual_links
			(customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_name, control_bt_synonym,
			contextual_link_name, contextual_link_seq, task_description, extend_as, source_from, tolltiptext, linked_componentname, linked_activityname,
			linked_uiname, subscription_name, task_name, createdby, createddate, modifiedby, modifieddate, task_type)
			select 
			customer_name, project_name, @engg_req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_name, control_bt_synonym,
			contextual_link_name, contextual_link_seq, task_description, extend_as, source_from, tolltiptext, linked_componentname, linked_activityname,
			linked_uiname, subscription_name, task_name, @ctxt_user, @date, @ctxt_user, @date, task_type
			from	ep_contextual_links (nolock)
			where 	customer_name 	= @customer_name_temp
			and  	project_name 	= @project_name_temp
			and  	req_no   		= @engg_base_req_no
			and  	process_name 	= @process_name_temp
			and  	component_name 	= @component_name_temp
			and  	activity_name 	= @activity_name_temp
			and  	ui_name   		= @ui_name_temp	

			delete from	ep_published_control_extensions
			where 	customer_name 	= @customer_name_temp
			and  	project_name 	= @project_name_temp
			and  	req_no   		= @engg_req_no
			and  	process_name 	= @process_name_temp
			and  	component_name 	= @component_name_temp
			and  	activity_name 	= @activity_name_temp
			and  	ui_name   		= @ui_name_temp	

			insert into ep_published_control_extensions
			(customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_name, control_bt_synonym,
			controlextension_name, controlextension_seq, task_description, extend_as, source_from, tooltiptext, linked_componentname, linked_activityname,
			linked_uiname, subscription_name, task_name, createdby, createddate, modifiedby, modifieddate, task_type, image_path)		-- Code Modified for the BugID PNR2.0_25863
			select 
			customer_name, project_name, @engg_req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_name, control_bt_synonym,
			controlextension_name, controlextension_seq, task_description, extend_as, source_from, tooltiptext, linked_componentname, linked_activityname,
			linked_uiname, subscription_name, task_name, @ctxt_user, @date, @ctxt_user, @date, task_type, image_path
			from	ep_control_extensions (nolock)
			where 	customer_name 	= @customer_name_temp
			and  	project_name 	= @project_name_temp
			and  	req_no   		= @engg_base_req_no
			and  	process_name 	= @process_name_temp
			and  	component_name 	= @component_name_temp
			and  	activity_name 	= @activity_name_temp
			and  	ui_name   		= @ui_name_temp	

-- Added By Jeya Latha K for Contextual Links  and control Extensions  End

-- Code moved for PNR2.0_13724 on 21-May-2007

--Logic to update in ep_ui_mst hideprint if atleast one template given in UI

If exists (select 'K'
			from		ep_ui_control_dtl a(nolock)  
			where	a.customer_name					=	@customer_name_temp	
			and		a.project_name					=	@project_name_temp		
			and		a.req_no								=  @engg_base_req_no
			and		a.process_name					=	@process_name_temp	
			and		a.component_name				=	@component_name_temp	
			and		a.activity_name					=	@activity_name_temp 
			and		a.ui_name							=	@ui_name_temp
			and		isnull(a.TemplateID,'')			<> ''	
			union
			select 'K'
			from		ep_ui_grid_dtl b(nolock) , ep_ui_section_dtl c (nolock)
			where	b.customer_name					=	 c.customer_name
			and		b.project_name					=	 c.project_name		
			and		b.process_name					=	 c.process_name
			and		b.component_name				=	 c.component_name
			and		b.activity_name					=	 c.activity_name
			and		b.ui_name							=	 c.ui_name
			and		b.page_bt_synonym				=	 c.page_bt_synonym
			and		b.section_bt_synonym			=	 c.section_bt_synonym
			and		b.customer_name					=	@customer_name_temp	
			and		b.project_name					=	@project_name_temp		
			and		b.req_no								=  @engg_base_req_no
			and		b.process_name					=	@process_name_temp	
			and		b.component_name				=	@component_name_temp	
			and		b.activity_name					=	@activity_name_temp 
			and		b.ui_name							=	@ui_name_temp
			and		c.section_type						<>	'SmartBar'
			and		isnull(b.TemplateID,'')			<> ''	 )
				begin 
			
					Update ep_ui_mst 
					set Hide_Print = 'y'
					where customer_name =  (@customer_name_temp)
					and project_name =  (@project_name_temp)
					and req_no  =  (@engg_base_req_no)
					and process_name = (@process_name_temp)
					and component_name = (@component_name_temp)
					and activity_name = (@activity_name_temp)
					and ui_name  = (@ui_name_temp)
				end

-- For Deleting Existing Records EP_PUBLISHED_UI_MST
delete ep_published_ui_mst
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)

-- INSERTING INTO EP_PUBLISHED_UI_MST
insert into ep_published_ui_mst
(
customer_name,   project_name,           req_no,
process_name,        component_name,   activity_name,
ui_name,             ui_descr,
ui_type,             ui_format,             caption_alignment,
trail_bar,           tab_height,             ui_doc,
base_component_name,    base_activity_name,     base_ui_name,
ui_sysid,             createdby,             createddate,
modifiedby,             modifieddate, timestamp,
grid_type,     state_processing,   callout_type, -- added for request id: PNR2.0_1790
taskpane_req -- Added for the Bug ID:PNR2.0_30127
,New_Line_Ui,Tab_Type,PostLaunchTask,TabPosition,SmartHide,is_device,HideIlbotitlemenu_req,personalization,Exclude_Systemtabindex
,DeviceType,TabStyle,IsDesktop,Hide_Print,
Layout,XYCoordinates,ColumnLayWidth,TabHeaderPostion,TabRotation,hide_imp_defaults,ui_subtype,DBName,
IsGlance, NativeApplication,	Conditional_popupclose,	Titlebar_Search,
Sidebar,Docked,LeftToolbar,RightToolbar,TopToolbar,BottomToolbar,	--Code added for TECH-70687
TemplateJSON, StyleSheet, ConfigurationXML, TemplateJSONDBC, StyleSheetDBC, ConfigurationXMLDBC, --TECH-72114
PullToRefresh)	--TECH-75230
select
customer_name,   project_name,           @engg_req_no,
--req_no,
--modified by Shafina on 31-Dec-2003 to populate the published tables with the proper request number
process_name,        component_name,   activity_name,
ui_name,             ui_descr,
ui_type,             ui_format,             caption_alignment,
trail_bar,           tab_height,     ui_doc,
base_component_name,    base_activity_name,     base_ui_name,
newid(),        @ctxt_user,          @date,
@ctxt_user,          @date,           1,
grid_type,    state_processing,   callout_type, -- added for request id: PNR2.0_1790
taskpane_req ,New_Line_Ui,Tab_Type,PostLaunchTask,TabPosition,SmartHide,is_device,HideIlbotitlemenu_req-- Added for the Bug ID:PNR2.0_30127
,personalization,Exclude_Systemtabindex,DeviceType,TabStyle,IsDesktop,Hide_Print,
Layout,XYCoordinates,ColumnLayWidth,TabHeaderPostion,TabRotation,hide_imp_defaults,ui_subtype,DBName,
IsGlance, NativeApplication,	Conditional_popupclose,	Titlebar_Search,
Sidebar,Docked,LeftToolbar,RightToolbar,TopToolbar,BottomToolbar,	--Code added for TECH-70687
TemplateJSON, StyleSheet, ConfigurationXML, TemplateJSONDBC, StyleSheetDBC, ConfigurationXMLDBC, --TECH-72114
PullToRefresh	--TECH-75230
from ep_ui_mst (nolock)
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_base_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)

-- For Deleting UI Page Details
delete ep_published_ui_page_dtl
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)

-- INSERTING INTO EP_PUBLISHED_UI_PAGE_DTL
insert into ep_published_ui_page_dtl
(
customer_name,  project_name,  req_no,
process_name,  component_name,  activity_name,
ui_name, page_bt_synonym, horder,
vorder,    page_doc,   page_prefix,
ui_page_sysid,  ui_sysid,   createdby,
createddate,  modifiedby,   modifieddate,
timestamp, page_Type, Pageimage -- added for request id: PNR2.0_1790,PLF2.0_00961
,width,PageClass --Code added for Bug ID:PLF2.0_04721
,HeaderPosition,TabRotation,TabTitleStyle,TabIconPosition,
PageLayout,XYCoordinates,ColumnLayWidth,
LeftToolbar,RightToolbar,TopToolbar,BottomToolbar)--Code added for TECH-70687
select
customer_name,  project_name,  @engg_req_no,
--req_no,
--modified by Shafina on 31-Dec-2003 to populate the published tables with the proper request number
process_name,  component_name,  activity_name,
ui_name,   page_bt_synonym, horder,
vorder,    page_doc,   page_prefix,
newid(),   ui_sysid,   @ctxt_user,
@date,   @ctxt_user,   @date,
1, page_Type, Pageimage -- added for request id: PNR2.0_1790,PLF2.0_00961
,width ,PageClass--Code added for Bug ID:PLF2.0_04721
,HeaderPosition,TabRotation,TabTitleStyle,TabIconPosition,
PageLayout,XYCoordinates,ColumnLayWidth,
LeftToolbar,RightToolbar,TopToolbar,BottomToolbar --Code added for TECH-70687
from ep_ui_page_dtl (nolock)
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_base_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)


--Code Modification for PNR2.0_30869 starts 
--Code Modification for PNR2.0_32209 starts 
-- For Deleting UI Page Events Details
delete ep_published_ui_pageevents_dtl
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)
--Code Modification for PNR2.0_32209 ends 
-- INSERTING INTO EP_PUBLISHED_UI_PAGE_DTL
insert into ep_published_ui_pageevents_dtl	
(
customer_name,project_name,process_name,req_no,component_name,activity_name,
ui_name,page_bt_synonym,horder,vorder,EventRequired,Task_Onclick,SystemGenerated,
timestamp,createdby,createddate,modifiedby,modifieddate
)
select
customer_name,project_name,process_name,@engg_req_no,component_name,activity_name,
ui_name,page_bt_synonym,horder,vorder,EventRequired,Task_Onclick,SystemGenerated,
timestamp,@ctxt_user,@date,   @ctxt_user,   @date
from ep_ui_pageevents_dtl	 (nolock)
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)
--Code Modification for PNR2.0_30869 ends 

-- For deleting existing section details
delete ep_published_ui_section_dtl
where customer_name  =  (@customer_name_temp)
and  project_name  =  (@project_name_temp)
and  req_no    =  (@engg_req_no)
and  process_name  = (@process_name_temp)
and  component_name  = (@component_name_temp)
and  activity_name  = (@activity_name_temp)
and  ui_name    = (@ui_name_temp)

-- INSERTING INTO EP_PUBLISHED_UI_SECTION_DTL
insert  into  ep_published_ui_section_dtl
(
customer_name,  project_name,   req_no,
process_name,  component_name,   activity_name,
ui_name,  page_bt_synonym,  section_bt_synonym,
visisble_flag,  title_required,   border_required,
parent_section,  horder,    vorder,
ui_section_sysid, page_sysid,   timestamp,
createdby,  createddate,   modifiedby,
modifieddate,  section_doc,   width,
height,   section_type,   SectionPrefixClass,
ctrl_caption_align, caption_Format,   Section_width_Scalemode,
Section_height_Scalemode, section_prefix , -- added for request id: PNR2.0_1790
title_alignment, Associated_control, splitter_pos ,section_collapsemode,NRowSpan,NColSpan/*,IsStatic*/,section_collapse,CarouselNavigation  -- Code modified for  PNR2.0_30127,PNR2.0_31403 ,PNR2.0_35984
,cell_spacing,cell_padding,Region,TitlePosition,CollapseDir,SectionLayout,XYCoordinates,ColumnLayWidth,IsPlatform,
IsResponsive, mob_pop_fullview,BorderLeftWidth, BorderRightWidth, BorderTopWidth, BorderBottomWidth, BorderLeftColor, BorderRightColor,BorderTopColor,BorderBottomColor,
BorderTopLeftRadius, BorderTopRightRadius, BorderBottomLeftRadius, BorderBottomRightRadius, BorderStyle, ForResponsive,  --Code added for TECH-69624
LeftToolbar, RightToolbar,TopToolbar, BottomToolbar, MinimizedRows, ViewMode,HasTitleAction,  --Code added for TECH-70687
TitleIcon, Orientation)	--TECH-72114 --TECH-75230
select
customer_name,  project_name,   @engg_req_no,
--req_no,
--modified by Shafina on 31-Dec-2003 to populate the published tables with the proper request number
process_name,  component_name,  activity_name,
ui_name,  page_bt_synonym,  section_bt_synonym,
visisble_flag,  title_required,   border_required,
parent_section,  horder,    vorder,
newid(),  page_sysid,   1,
@ctxt_user,  @date,    @ctxt_user,
@date,   section_doc,   width,
height,   section_type,   SectionPrefixClass,
ctrl_caption_align, caption_Format,   Section_width_Scalemode,
Section_height_Scalemode, section_prefix ,-- added for request id: PNR2.0_1790
title_alignment ,  -- Code modified for  PNR2.0_30127
Associated_control ,  -- Code modified for  PNR2.0_31403
splitter_pos ,section_collapsemode,
NRowSpan , NColSpan, /*IsStatic,*/section_collapse,CarouselNavigation--Code modified for PNR2.0_35984
,cell_spacing,cell_padding,Region,TitlePosition,CollapseDir,SectionLayout,XYCoordinates,ColumnLayWidth, IsPlatform,
IsResponsive, mob_pop_fullview, BorderLeftWidth, BorderRightWidth, BorderTopWidth, BorderBottomWidth, BorderLeftColor, BorderRightColor,BorderTopColor,BorderBottomColor,
BorderTopLeftRadius, BorderTopRightRadius, BorderBottomLeftRadius, BorderBottomRightRadius, BorderStyle, ForResponsive,	--Code added for TECH-69624
LeftToolbar, RightToolbar,TopToolbar, BottomToolbar, MinimizedRows, ViewMode,HasTitleAction,  --Code added for TECH-70687
TitleIcon, Orientation	--TECH-72114	--TECH-75230
from ep_ui_section_dtl (nolock)
where customer_name  =  (@customer_name_temp)
and project_name  =  (@project_name_temp)
and req_no   =  (@engg_base_req_no)
and process_name  = (@process_name_temp)
and component_name  = (@component_name_temp)
and activity_name  = (@activity_name_temp)
and ui_name   = (@ui_name_temp)

-- For Deleting EP_PUBLISHED_UI_CONTROL_DTL
delete EP_PUBLISHED_UI_CONTROL_DTL
where customer_name   =  (@customer_name_temp)
and  project_name   =  (@project_name_temp)
and  req_no     =  (@engg_req_no)
and  process_name   = (@process_name_temp)
and  component_name   = (@component_name_temp)
and  activity_name   = (@activity_name_temp)
and  ui_name     = (@ui_name_temp)

-- INSERTING INTO EP_PUBLISHED_UI_CONTROL_DTL
-- code modified by shafina on 16-jan-2004 to insert control_prefix in the published table
-- New Column AccessKey added for the BugID : PNR2.0_1522
insert into ep_published_ui_control_dtl
(
customer_name,      project_name,   req_no,
process_name,       component_name,      activity_name,
ui_name,        page_bt_synonym,     section_bt_synonym,
control_bt_synonym, control_id,          view_name,
control_type,       visisble_length,     horder,
vorder, proto_tooltip,       sample_data,
control_doc,        ui_control_sysid,    ui_section_sysid,
createdby,         createddate,         modifiedby,
modifieddate,     timestamp,    control_prefix,
order_seq,   data_column_width,  label_column_width,
-- code modified by shafina on 22-Dec-2004 for  PREVIEWENG203ACC_000116 (In control_dtl table, label_column_scalemode and data_column_scalemode are added.)
data_column_scalemode, label_column_scalemode, tab_seq,
help_tabstop,  LabelClass,  ControlClass,
LabelImageClass, ControlImageClass, accesskey, Set_User_Pref, freezecount,-- code Added by Gopinath S for the Call ID PNR2.0_19480) -- code modified for the caseid: PNR2.0_26860
controlimage, colspan, rowspan,TemplateID -- code modified for the caseid:PLF2.0_00961
,TemplateCategory,TemplateSpecific,Control_class_ext6,icon_position,icon_class,sensitivedata,  -- Added for TECH-20897
IsPlatform, DynamicStyle,	ImageAsData,	UpeSetFocusEnabled,	MoreEventEnabled,	ExtensionReqd,ExtensionLaunchMode, AssociateControl,	 -- NGPLF,Code added for TECH-60451, code added for TECH-63527
BorderLeftWidth, BorderRightWidth, BorderTopWidth, BorderBottomWidth, BorderLeftColor, BorderRightColor,BorderTopColor,	
BorderBottomColor, BorderTopLeftRadius, BorderTopRightRadius,BorderBottomLeftRadius,BorderBottomRightRadius,BorderStyle, HasCustomAction,ForResponsive, --Code added for TECH-69624
ControlFormat, ButtonNature, InlineStyle) -- Code Added for TECH-73996 
select
customer_name,      project_name,   @engg_req_no,
--req_no,
--modified by Shafina on 31-Dec-2003 to populate the published tables with the proper request number
process_name,       component_name,      activity_name,
ui_name,            page_bt_synonym,     section_bt_synonym,
control_bt_synonym, control_id,          view_name,
control_type,       visisble_length,     horder,
vorder,          proto_tooltip,       sample_data,
control_doc,        newid(),     ui_section_sysid,
@ctxt_user,     @date,   @ctxt_user,
@date,      1,    control_prefix,
order_seq,     data_column_width,  label_column_width,
data_column_scalemode, label_column_scalemode, tab_seq,
help_tabstop,  LabelClass,  ControlClass,
LabelImageClass, ControlImageClass,accesskey, Set_User_Pref,freezecount,-- code modified for the caseid: PNR2.0_26860
controlimage, colspan, rowspan ,TemplateID-- code modified for the caseid:PLF2.0_00961
,TemplateCategory,TemplateSpecific,Control_class_ext6,icon_position,icon_class,sensitivedata, IsPlatform, 
DynamicStyle,	ImageAsData	,UpeSetFocusEnabled,MoreEventEnabled,	ExtensionReqd,ExtensionLaunchMode, AssociateControl, ----Added for the Defect ID TECH-45828, TECH-60451,code added TECH-63527
BorderLeftWidth, BorderRightWidth, BorderTopWidth, BorderBottomWidth, BorderLeftColor, BorderRightColor,BorderTopColor,	
BorderBottomColor, BorderTopLeftRadius, BorderTopRightRadius,BorderBottomLeftRadius,BorderBottomRightRadius,BorderStyle, HasCustomAction,ForResponsive,	--Code added for TECH-69624
ControlFormat, ButtonNature, InlineStyle --Code Added for TECH-73996	--TECH-75230
from ep_ui_control_dtl (nolock)
where customer_name   =  (@customer_name_temp)
and  project_name  =  (@project_name_temp)
and  req_no   =  (@engg_base_req_no)
and  process_name  = (@process_name_temp)
and  component_name  = (@component_name_temp)
and  activity_name  = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)

-- For deleting ep_published_ui_grid_dtl
delete ep_published_ui_grid_dtl
where customer_name   =  (@customer_name_temp)
and  project_name   =  (@project_name_temp)
and  req_no     =  (@engg_req_no)
and  process_name   = (@process_name_temp)
and  component_name   = (@component_name_temp)
and  activity_name   = (@activity_name_temp)
and  ui_name     = (@ui_name_temp)


-- INSERTING INTO EP_PUBLISHED_UI_GRID_DTL
-- code modified by shafina on 16-jan-2004 to insert column_prefix in the published table
insert into ep_published_ui_grid_dtl
(
customer_name,   project_name,   req_no,
process_name,   component_name,   activity_name,
ui_name,    page_bt_synonym,  section_bt_synonym,
control_bt_synonym,  column_bt_synonym,  control_id,
view_name,    column_type,   column_no,
visible_length,   proto_tooltip,   sample_data,
col_doc,    grid_sysid,    ui_control_sysid,
createdby,    createddate,   modifiedby,
modifieddate,   timestamp,    column_prefix, Set_User_Pref, -- code Added by Gopinath S for the Call ID PNR2.0_19480
default_required,visible,ColumnClass, --Column added  for PNR2.0_30869
/*ColumnHdrClass,*/Forcefit,TemplateID,iskey,Kyseq_no
,TemplateCategory,TemplateSpecific,Column_class_ext6, RowExpander, GridToForm,icon_position,icon_class,TreeColumn,
column_Transformas,sensitivedata, -- added for GridToForm TECH-12776 , TECH-20897
IsPlatform, CompactView,	UpeSetFocusEnabled,	MoreEventEnabled,	ExtensionReqd,ExtensionLaunchMode, --Code added for TECH-60451 	
AssociateControl ) --Code Added for TECH-71262
select
customer_name,   project_name,   @engg_req_no,
--req_no,
--modified by Shafina on 31-Dec-2003 to populate the published tables with the proper request number
process_name,   component_name,   activity_name,
ui_name,    page_bt_synonym,  section_bt_synonym,
control_bt_synonym,  column_bt_synonym,  control_id,
view_name,    column_type,   column_no,
visible_length,   proto_tooltip,   sample_data,
col_doc,    newid(),    ui_control_sysid,
@ctxt_user,          @date,          @ctxt_user,
@date,          1,      column_prefix, Set_User_Pref,default_required ,visible,    --Column added  for PNR2.0_30869
ColumnClass,/*ColumnHdrClass,*/Forcefit,TemplateID,iskey,Kyseq_no
,TemplateCategory,TemplateSpecific,Column_class_ext6, RowExpander, GridToForm,icon_position,icon_class,TreeColumn,
column_Transformas,sensitivedata, IsPlatform, CompactView,	UpeSetFocusEnabled,	MoreEventEnabled,	ExtensionReqd,ExtensionLaunchMode, ----Added for the Defect ID TECH-45828,TECH-60451
AssociateControl  --Code Added for TECH-71262
from ep_ui_grid_dtl (nolock)
where customer_name   =  (@customer_name_temp)
and  project_name   =  (@project_name_temp)
and  req_no     =  (@engg_base_req_no)
and  process_name   = (@process_name_temp)
and  component_name   = (@component_name_temp)
and  activity_name   = (@activity_name_temp)
and  ui_name     = (@ui_name_temp)

									
-- For deleting ep_published_ui_columngroup
delete	ep_published_ui_columngroup
where	customer_name		= (@customer_name_temp)
and  	project_name		= (@project_name_temp)
and  	req_no				= (@engg_req_no)
and  	process_name		= (@process_name_temp)
and  	component_name		= (@component_name_temp)
and  	activity_name		= (@activity_name_temp)
and  	ui_name				= (@ui_name_temp)

-- INSERTING INTO EP_PUBLISHED_UI_COLUMNGROUP
insert into ep_published_ui_columngroup
	(customer_name,project_name,req_no, process_name,component_name,activity_name, ui_name,Page_bt_synonym,section_bt_synonym,
	grid_control_bt_synonym,Group_name,Group_caption,timestamp,createdby,createddate, modifiedby,modifieddate, grouplevel, 
	groupseqno, parentgroup, parentgroupseq)
select customer_name,project_name,@engg_req_no, process_name,component_name,activity_name,ui_name,Page_bt_synonym,section_bt_synonym,
	grid_control_bt_synonym,Group_name,Group_caption,timestamp, @ctxt_user, @date,  @ctxt_user,@date, grouplevel,
	groupseqno, parentgroup, parentgroupseq
	from	ep_ui_columngroup(nolock)
	where	customer_name   = (@customer_name_temp)
	and		project_name	= (@project_name_temp)
	and		req_no			= (@engg_base_req_no)
	and		process_name	= (@process_name_temp)
	and		component_name  = (@component_name_temp)
	and		activity_name   = (@activity_name_temp)
	and		ui_name			= (@ui_name_temp)

-- Inserting for specify calender
insert into ep_published_calendar_configure
	(Customer_name,Project_name,Req_no,Process_name,Component_name,Activity_name,ui_name,page_name,section_name,monthview_cal,
	weekview_cal,editable,detailspane,listview_req,DefaultTemplate,eventstyle,month_nav_req,week_nav_req,tap_req,doubletap_req,
	drag_req,month_nav_event,week_nav_event,tapevent,doubletap_event,dragevent,timestamp,createdby,createddate,modifiedby,modifieddate)

select	Customer_name,Project_name,@engg_req_no,Process_name,Component_name,Activity_name,ui_name,page_name,section_name,monthview_cal,weekview_cal,editable,detailspane,
listview_req,DefaultTemplate,eventstyle,month_nav_req,week_nav_req,tap_req,doubletap_req,drag_req,month_nav_event,week_nav_event,tapevent,doubletap_event,dragevent,
timestamp,@ctxt_user,@date,@ctxt_user,@date

	from	ep_calendar_configure(nolock)
	where	customer_name   = (@customer_name_temp)
	and		project_name	= (@project_name_temp)
	and		req_no			= (@engg_base_req_no)
	and		process_name	= (@process_name_temp)
	and		component_name  = (@component_name_temp)
	and		activity_name   = (@activity_name_temp)
	and		ui_name			= (@ui_name_temp)


-- For deleting ep_published_ui_column_group_mapping
delete	ep_published_ui_column_group_mapping
where	customer_name		= (@customer_name_temp)
and  	project_name		= (@project_name_temp)
and  	req_no				= (@engg_req_no)
and  	process_name		= (@process_name_temp)
and  	component_name		= (@component_name_temp)
and  	activity_name		= (@activity_name_temp)
and  	ui_name				= (@ui_name_temp)

-- INSERTING INTO EP_PUBLISHED_UI_COLUMN_GROUP_MAPPING
insert into ep_published_ui_column_group_mapping
(customer_name,project_name,req_no,
process_name,component_name,activity_name,
ui_name,Page_bt_synonym,section_bt_synonym,
grid_control_bt_synonym,Group_name,column_bt_synonym,
SequenceNo,mapped_entity,timestamp,createdby,
createddate,modifiedby,modifieddate)
select
customer_name,project_name,@engg_req_no,
process_name,component_name,activity_name,
ui_name,Page_bt_synonym,section_bt_synonym,
grid_control_bt_synonym,Group_name,column_bt_synonym,
SequenceNo,mapped_entity,timestamp, @ctxt_user, 
@date,@ctxt_user,@date
from	ep_ui_column_group_mapping(nolock)
where	customer_name   = (@customer_name_temp)
and		project_name	= (@project_name_temp)
and		req_no			= (@engg_base_req_no)
and		process_name	= (@process_name_temp)
and		component_name  = (@component_name_temp)
and		activity_name   = (@activity_name_temp)
and		ui_name			= (@ui_name_temp)

-- For deleting ep_published_phone_columngroup
delete	ep_published_phone_columngroup
where	customer_name		= (@customer_name_temp)
and  	project_name		= (@project_name_temp)
and  	req_no				= (@engg_req_no)
and  	process_name		= (@process_name_temp)
and  	component_name		= (@component_name_temp)
and  	activity_name		= (@activity_name_temp)
and  	ui_name				= (@ui_name_temp)

-- INSERTING INTO EP_PUBLISHED_phone_columngroup
insert into ep_published_phone_columngroup
(customer_name,project_name,req_no,
process_name,component_name,activity_name,
ui_name,Page_bt_synonym,section_bt_synonym,
grid_control_bt_synonym,Group_name,Group_caption,
timestamp,createdby,createddate,
modifiedby,modifieddate,grouplevel, 
	groupseqno, parentgroup, parentgroupseq)
select
customer_name,project_name,@engg_req_no,
process_name,component_name,activity_name,
ui_name,Page_bt_synonym,section_bt_synonym,
grid_control_bt_synonym,Group_name,Group_caption,
timestamp, @ctxt_user, @date,  
@ctxt_user,@date, grouplevel,
	groupseqno, parentgroup, parentgroupseq
from	ep_phone_columngroup(nolock)
where	customer_name   = (@customer_name_temp)
and		project_name	= (@project_name_temp)
and		req_no			= (@engg_base_req_no)
and		process_name	= (@process_name_temp)
and		component_name  = (@component_name_temp)
and		activity_name   = (@activity_name_temp)
and		ui_name			= (@ui_name_temp)


-- For deleting ep_published_phone_columngroup
delete	ep_published_phone_column_group_mapping
where	customer_name		= (@customer_name_temp)
and  	project_name		= (@project_name_temp)
and  	req_no				= (@engg_req_no)
and  	process_name		= (@process_name_temp)
and  	component_name		= (@component_name_temp)
and  	activity_name		= (@activity_name_temp)
and  	ui_name				= (@ui_name_temp)

-- INSERTING INTO EP_PUBLISHED_phone_column_group_MAPPING
insert into ep_published_phone_column_group_mapping
(customer_name,project_name,req_no,
process_name,component_name,activity_name,
ui_name,Page_bt_synonym,section_bt_synonym,
grid_control_bt_synonym,Group_name,column_bt_synonym,
SequenceNo,mapped_entity,timestamp,createdby,
createddate,modifiedby,modifieddate)
select
customer_name,project_name,@engg_req_no,
process_name,component_name,activity_name,
ui_name,Page_bt_synonym,section_bt_synonym,
grid_control_bt_synonym,Group_name,column_bt_synonym,
SequenceNo,mapped_entity,timestamp, @ctxt_user, 
@date,@ctxt_user,@date
from	ep_phone_column_group_mapping(nolock)
where	customer_name   = (@customer_name_temp)
and		project_name	= (@project_name_temp)
and		req_no			= (@engg_base_req_no)
and		process_name	= (@process_name_temp)
and		component_name  = (@component_name_temp)
and		activity_name   = (@activity_name_temp)
and		ui_name			= (@ui_name_temp)


-- For deleting ep_published_tablet_columngroup
delete	ep_published_tablet_columngroup
where	customer_name		= (@customer_name_temp)
and  	project_name		= (@project_name_temp)
and  	req_no				= (@engg_req_no)
and  	process_name		= (@process_name_temp)
and  	component_name		= (@component_name_temp)
and  	activity_name		= (@activity_name_temp)
and  	ui_name				= (@ui_name_temp)

-- INSERTING INTO EP_PUBLISHED_tablet_columngroup
insert into ep_published_tablet_columngroup
(customer_name,project_name,req_no,
process_name,component_name,activity_name,
ui_name,Page_bt_synonym,section_bt_synonym,
grid_control_bt_synonym,Group_name,Group_caption,
timestamp,createdby,createddate,
modifiedby,modifieddate,grouplevel, 
	groupseqno, parentgroup, parentgroupseq)
select
customer_name,project_name,@engg_req_no,
process_name,component_name,activity_name,
ui_name,Page_bt_synonym,section_bt_synonym,
grid_control_bt_synonym,Group_name,Group_caption,
timestamp, @ctxt_user, @date,  
@ctxt_user,@date ,grouplevel,
	groupseqno, parentgroup, parentgroupseq
from	ep_tablet_columngroup(nolock)
where	customer_name   = (@customer_name_temp)
and		project_name	= (@project_name_temp)
and		req_no			= (@engg_base_req_no)
and		process_name	= (@process_name_temp)
and		component_name  = (@component_name_temp)
and		activity_name   = (@activity_name_temp)
and		ui_name			= (@ui_name_temp)


-- For deleting ep_published_tablet_columngroup
delete	ep_published_tablet_column_group_mapping
where	customer_name		= (@customer_name_temp)
and  	project_name		= (@project_name_temp)
and  	req_no				= (@engg_req_no)
and  	process_name		= (@process_name_temp)
and  	component_name		= (@component_name_temp)
and  	activity_name		= (@activity_name_temp)
and  	ui_name				= (@ui_name_temp)

-- INSERTING INTO EP_PUBLISHED_tablet_column_group_MAPPING
insert into ep_published_tablet_column_group_mapping
(customer_name,project_name,req_no,
process_name,component_name,activity_name,
ui_name,Page_bt_synonym,section_bt_synonym,
grid_control_bt_synonym,Group_name,column_bt_synonym,
SequenceNo,mapped_entity,timestamp,createdby,
createddate,modifiedby,modifieddate)
select
customer_name,project_name,@engg_req_no,
process_name,component_name,activity_name,
ui_name,Page_bt_synonym,section_bt_synonym,
grid_control_bt_synonym,Group_name,column_bt_synonym,
SequenceNo,mapped_entity,timestamp, @ctxt_user, 
@date,@ctxt_user,@date
from	ep_tablet_column_group_mapping(nolock)
where	customer_name   = (@customer_name_temp)
and		project_name	= (@project_name_temp)
and		req_no			= (@engg_base_req_no)
and		process_name	= (@process_name_temp)
and		component_name  = (@component_name_temp)
and		activity_name   = (@activity_name_temp)
and		ui_name			= (@ui_name_temp)


delete	ep_published_enum_value_dtl
where customer_name   =  (@customer_name_temp)
and	 project_name   =  (@project_name_temp)
and	 req_no     =  (@engg_req_no)
and  process_name   = (@process_name_temp)
and  component_name   = (@component_name_temp)
and  activity_name   = (@activity_name_temp)
and  ui_name     = (@ui_name_temp)

-- INSERTING INTO EP_PUBLISHED_ENUM_VALUE_DTL
insert into ep_published_enum_value_dtl
(
customer_name,   project_name,   req_no,
process_name,   component_name,   activity_name,
ui_name,    page_bt_synonym,  section_bt_synonym,
control_bt_synonym,  enum_code,    enum_caption,
default_flag,   enum_value_sysid,  ui_section_sysid,
createdby,    createddate,   modifiedby,
modifieddate,   timestamp,    seq_no
)
select
customer_name,   project_name,   @engg_req_no,
--req_no,
--modified by Shafina on 31-Dec-2003 to populate the published tables with the proper request number
process_name,   component_name,   activity_name,
ui_name,    page_bt_synonym,  section_bt_synonym,
control_bt_synonym,  enum_code,    enum_caption,
default_flag,   newid(),    ui_section_sysid,
@ctxt_user,    @date,    @ctxt_user,
@date,    1,      seq_no
from ep_enum_value_dtl (nolock)
where customer_name   =  (@customer_name_temp)
and  project_name   =  (@project_name_temp)
and  req_no     =  (@engg_base_req_no)
and  process_name   = (@process_name_temp)
and  component_name   = (@component_name_temp)
and  activity_name   = (@activity_name_temp)
and  ui_name     = (@ui_name_temp)

/* Code modified by Gankan.G for the CaseId:PNR2.0_32385 to populate lang extn tables starts*/
insert into ep_enum_value_dtl_lng_extn(customer_name,project_name,req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,enum_code,enum_caption,default_flag,enum_value_sysid,ui_section_sysid,
languageid,timestamp,createdby,createddate,modifiedby,modifieddate,seq_no,wrkreqno)
select	distinct a.customer_name,a.project_name,a.req_no,a.process_name,a.component_name,a.activity_name,a.ui_name,a.page_bt_synonym,a.section_bt_synonym,a.control_bt_synonym,a.enum_code,a.enum_caption,a.default_flag,a.enum_value_sysid,a.ui_section_sysid,















c.quick_code,a.timestamp,a.createdby,a.createddate,a.modifiedby,a.modifieddate,a.seq_no,a.wrkreqno
from	ep_enum_value_dtl a(nolock),
		ep_language_met c(nolock)
where	a.customer_name	=	@customer_name_temp 
and		a.project_name	=	@project_name_temp  
and		not exists (	select	'b'
						from	ep_enum_value_dtl_lng_extn b(nolock)
						where	b.customer_name			=	a.customer_name		
						and		b.project_name			=	a.project_name		
						and		b.process_name			=	a.process_name		
						and		b.component_name		=	a.component_name	
						and		b.activity_name			=	a.activity_name 
						and		b.ui_name				=	a.ui_name		
						and		b.page_bt_synonym		=	a.page_bt_synonym	
						and		b.section_bt_synonym	=	a.section_bt_synonym 
						and		b.control_bt_synonym	=	a.control_bt_synonym	
						and		b.enum_code				=	a.enum_code 
						)
/* Code modified by Gankan.G for the CaseId:PNR2.0_32385 to populate lang extn tables ends*/

--code added by Gowrisankar on 3-Oct-2005 for the callid PNR2.0_4079
-- For deleting ep_published_enum_value_dtl_lng_extn
delete from ep_published_enum_value_dtl_lng_extn
where customer_name =  @customer_name_temp
and project_name  =  @project_name_temp
and req_no    =  @engg_req_no
and process_name  = @process_name_temp
and component_name  = @component_name_temp
and activity_name  = @activity_name_temp
and ui_name    = @ui_name_temp

-- INSERTING INTO EP_PUBLISHED_ENUM_VALUE_DTL_LNG_EXTN
insert into ep_published_enum_value_dtl_lng_extn
(
customer_name,   project_name,   req_no,
process_name,   component_name,   activity_name,
ui_name,    page_bt_synonym,  section_bt_synonym,
control_bt_synonym,  enum_code,    enum_caption,
default_flag,   enum_value_sysid,  ui_section_sysid,
createdby,    createddate,   modifiedby,
modifieddate,   timestamp,    seq_no,
languageid
)
select
customer_name,   project_name,   @engg_req_no,
process_name,   component_name,   activity_name,
ui_name,    page_bt_synonym,  section_bt_synonym,
control_bt_synonym,  enum_code,    enum_caption,
default_flag,   newid(),    ui_section_sysid,
@ctxt_user,    @date,     @ctxt_user,
@date,     1,      seq_no,
languageid
from ep_enum_value_dtl_lng_extn (nolock)
where customer_name  =  @customer_name_temp
and  project_name  =  @project_name_temp
and  req_no    =  @engg_base_req_no
and  process_name  = @process_name_temp
and  component_name  = @component_name_temp
and  activity_name  = @activity_name_temp
and  ui_name    = @ui_name_temp

-- For deletign ep_published_radio_button_dtl
delete ep_published_radio_button_dtl
where customer_name   =  (@customer_name_temp)
and  project_name   =  (@project_name_temp)
and  req_no     =  (@engg_req_no)
and  process_name   = (@process_name_temp)
and  component_name   = (@component_name_temp)
and  activity_name   = (@activity_name_temp)
and  ui_name     = (@ui_name_temp)

-- INSERTING INTO EP_PUBLISHED_RADIO_BUTTON_DTL
insert into ep_published_radio_button_dtl
(
customer_name,   project_name,  req_no,
process_name,   component_name,  activity_name,
ui_name,    page_bt_synonym, section_bt_synonym,
control_bt_synonym,  button_code,  seq_no,
button_caption,   default_flag,  radio_button_sysid,
ui_control_sysid,  createdby,   createddate,
modifiedby,    modifieddate,  timestamp,
horder,     vorder
)
select
customer_name,   project_name,  @engg_req_no,
--req_no,
--modified by Shafina on 31-Dec-2003 to populate the published tables with the proper request number
process_name,   component_name,  activity_name,
ui_name,    page_bt_synonym, section_bt_synonym,
control_bt_synonym,  button_code,  seq_no,
button_caption,   default_flag,  newid(),
ui_control_sysid,  @ctxt_user,   @date,
@ctxt_user,    @date,   1,
horder,     vorder
from ep_radio_button_dtl (nolock)
where customer_name   =  (@customer_name_temp)
and  project_name   =  (@project_name_temp)
and  req_no     =  (@engg_base_req_no)
and  process_name   = (@process_name_temp)
and  component_name   = (@component_name_temp)
and  activity_name   = (@activity_name_temp)
and  ui_name     = (@ui_name_temp)

/* Code modified by Gankan.G for the CaseId:PNR2.0_32385 to populate lang extn tables starts*/
insert into ep_radio_button_dtl_lng_extn(customer_name,project_name,req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,button_code,seq_no,button_caption,default_flag,radio_button_sysid,
ui_control_sysid,languageid,timestamp,createdby,createddate,modifiedby,modifieddate,horder,vorder,wrkreqno)
select	distinct a.customer_name,a.project_name,a.req_no,a.process_name,a.component_name,a.activity_name,a.ui_name,a.page_bt_synonym,a.section_bt_synonym,a.control_bt_synonym,a.button_code,a.seq_no,a.button_caption,a.default_flag,a.radio_button_sysid,
a.ui_control_sysid,c.quick_code,a.timestamp,a.createdby,a.createddate,a.modifiedby,a.modifieddate,a.horder,a.vorder,a.wrkreqno
from	ep_radio_button_dtl a(nolock),
		ep_language_met c(nolock)
where	a.customer_name	=	@customer_name_temp 
and		a.project_name	=	@project_name_temp 
and		not exists (	select	'b'
						from	ep_radio_button_dtl_lng_extn b(nolock)
						where	b.customer_name			=	a.customer_name		
						and		b.project_name			=	a.project_name		
						and		b.process_name			=	a.process_name		
						and		b.component_name		=	a.component_name	
						and		b.activity_name			=	a.activity_name 
						and		b.ui_name				=	a.ui_name		
						and		b.page_bt_synonym		=	a.page_bt_synonym	
						and		b.section_bt_synonym	=	a.section_bt_synonym 
						and		b.control_bt_synonym	=	a.control_bt_synonym	
						and		b.button_code			=	a.button_code 
						)
/* Code modified by Gankan.G for the CaseId:PNR2.0_32385 to populate lang extn tables ends*/

-- For deleting ep_published_radio_button_dtl_lng_extn
delete from ep_published_radio_button_dtl_lng_extn
where customer_name =  rtrim(@customer_name_temp)
and project_name  =  rtrim(@project_name_temp)
and req_no    =  rtrim(@engg_req_no)
and process_name  = rtrim(@process_name_temp)
and component_name  = rtrim(@component_name_temp)
and activity_name  = rtrim(@activity_name_temp)
and ui_name    = rtrim(@ui_name_temp)

-- INSERTING INTO ep_published_radio_button_dtl_lng_extn
insert into ep_published_radio_button_dtl_lng_extn
(
customer_name,   project_name,  req_no,
process_name,   component_name,  activity_name,
ui_name,    page_bt_synonym, section_bt_synonym,
control_bt_synonym,  button_code,  seq_no,
button_caption,   default_flag,  radio_button_sysid,
ui_control_sysid,  createdby,   createddate,
modifiedby,    modifieddate,  timestamp,
horder,     vorder,    languageid
)
select
customer_name,   project_name,  @engg_req_no,
process_name,   component_name,  activity_name,
ui_name,    page_bt_synonym, section_bt_synonym,
control_bt_synonym,  button_code,  seq_no,
button_caption,   default_flag,  newid(),
ui_control_sysid,  @ctxt_user,   @date,
@ctxt_user,    @date,    1,
horder,     vorder,    languageid
from ep_radio_button_dtl_lng_extn (nolock)
where customer_name   =  rtrim(@customer_name_temp)
and  project_name   =  rtrim(@project_name_temp)
and  req_no     =  rtrim(@engg_base_req_no)
and  process_name   = rtrim(@process_name_temp)
and  component_name   = rtrim(@component_name_temp)
and  activity_name   = rtrim(@activity_name_temp)
and  ui_name     = rtrim(@ui_name_temp)

-- code modified by shafina on 02-Feb-2005 for PREVIEWENG203SYS_000197(Violation of PRIMARY KEY constraint 'ep_published_ui_traversal_dtl_pkey'. Cannot insert duplicate key in object 'ep_published_ui_traversal_dtl'.The above error is displayed when trying


















-- to publish)
delete
from ep_published_ui_traversal_dtl
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)
-- code modified by shafina on 15-Apr-2004 for PREVIEWENG203ACC_000035
-- INSERTING INTO EP_PUBLISHED_TRAVERSAL_DTL
-- code modified by shafina on 02-Aug-2004 for REENG203SYS_000047


--Code modification for PNR2.0_26335 starts

insert into ep_published_ui_traversal_dtl
(
customer_name,  project_name,  req_no,
process_name,  component_name,  activity_name,
ui_name,  page_bt_synonym, section_bt_synonym,
control_bt_synonym, link_type,  linked_component,
linked_activity, linked_ui,  treaversal_sysid,
ui_page_sysid,  createdby,  createddate,
modifiedby,  modifieddate,  timestamp,
--code modified for the caseid :PNR2.0_26475 starts
--status_flag,  
associated_ctrl_bt_synonym,trvsl_seq,
Width,Height,Toolbar_notreq,LinkLaunchType)
select
customer_name,  project_name,  @engg_req_no,
process_name,  component_name,  activity_name,
ui_name,  page_bt_synonym, section_bt_synonym,
control_bt_synonym, link_type,  linked_component,
linked_activity, linked_ui,  newid(),
ui_page_sysid,  @ctxt_user,  @date,
@ctxt_user,  @date,   1,
--'I',   
associated_ctrl_bt_synonym ,trvsl_seq,
Width,Height,Toolbar_notreq,LinkLaunchType
from ep_ui_traversal_dtl (nolock)
where customer_name   =  (@customer_name_temp)
and  project_name  =  (@project_name_temp)
and  req_no   =  (@engg_base_req_no)
and  process_name  = (@process_name_temp)
and  component_name  = (@component_name_temp)
and  activity_name  = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)

--Code modification for PNR2.0_26335 ends

-- code modified by shafina on 18-Jan-2005 for PREVIEWENG203ACC_000122 (While publishing work request , foreign key violation error in fw_bpt_ui_task_bt table is thrown.)
/*
update ep_published_ui_traversal_dtl
set  status_flag  =  'S',
modifiedby  = @ctxt_user,
modifieddate = @date
from ep_published_ui_traversal_dtl  a,
ep_bpt_ui_link_vw     b
where a.customer_name  =  (@customer_name_temp)
and  a.project_name  =  (@project_name_temp)
and  a.req_no   =  (@engg_req_no)
and  a.process_name  = (@process_name_temp)
and  a.component_name = (@component_name_temp)
and  a.activity_name  = (@activity_name_temp)
and  a.ui_name   = (@ui_name_temp)
and  a.customer_name  = b.customer_name
and  a.process_name  = b.process_name
and  a.component_name = b.component_name
and  a.activity_name  = b.activity_name
and  a.ui_name   = b.ui_name
and  a.page_bt_synonym = b.page_bt_synonym
and  a.control_bt_synonym= b.control_bt_synonym

update a
set  status_flag   =  'I',
modifiedby   = @ctxt_user,
modifieddate  = @date
from ep_published_ui_traversal_dtl a
where customer_name  =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no    =  (@engg_req_no)
and  process_name  = (@process_name_temp)
and  component_name  = (@component_name_temp)
and  activity_name  = (@activity_name_temp)
and  ui_name    = (@ui_name_temp)
and  control_bt_synonym not in (select b.control_bt_synonym
from ep_bpt_ui_link_vw b(nolock)
where b.customer_name  =  (@customer_name_temp)
and  b.project_name  =  (@project_name_temp)
and  b.process_name  = (@process_name_temp)
and  b.component_name = (@component_name_temp)
and  b.activity_name  = (@activity_name_temp)
and  b.ui_name   = (@ui_name_temp)
and  b.page_bt_synonym = a.page_bt_synonym)
*/
--code modified for the caseid :PNR2.0_26475 ends
-- INSERTING INTO ep_published_comp_glossary_mst

--CODE MODIFICATION TO INSERT PUBLISHED GLOSSARY MASTER - GIRIDHARAN V ON 08/01/2004 STARTS

--INSERTING PAGE BT SYNONYM

/*   Insert into ep_published_comp_glossary_mst
(
customer_name,   project_name,  req_no,
process_name,   component_name,  bt_synonym_name,
data_type,    length,    bt_synonym_caption,
glossary_sysid,   timestamp,   createdby,
createddate,   modifiedby,   modifieddate,
ref_bt_synonym_name, bt_synonym_doc,  bt_name,
synonym_status
)
Select distinct
gls.customer_name,  gls.project_name, @engg_req_no,
gls.process_name,  gls.component_name, gls.bt_synonym_name,
gls.data_type,   gls.length,   gls.bt_synonym_caption,
glossary_sysid,   1,     @ctxt_user,
@date,    @ctxt_user,   @date,
gls.ref_bt_synonym_name,gls.bt_synonym_doc, gls.bt_name,
gls.synonym_status
from ep_component_glossary_mst gls (nolock),
ep_ui_page_dtl    pg  (nolock)
where pg.customer_name = @engg_customer_name
and  pg.project_name  = @engg_project_name
and  pg.req_no   = (@engg_base_req_no)
and  pg.process_name  = @process_name_temp
and  pg.component_name = @component_name_temp
and  pg.activity_name = @activity_name_temp
and  pg.ui_name   = @ui_name_temp
and  pg.customer_name = gls.customer_name
and  pg.project_name  = gls.project_name
and  pg.req_no   = gls.req_no
and  pg.process_name  = gls.process_name
and  pg.component_name = gls.component_name
and  pg.page_bt_synonym = gls.bt_synonym_name
and  not exists    (
Select 'A'
from ep_published_comp_glossary_mst pgls (nolock)
where pgls.customer_name = gls.customer_name
and  pgls.project_name = gls.project_name
and  pgls.req_no   = @engg_req_no
and  pgls.process_name = gls.process_name
and  pgls.component_name = gls.component_name
and  pgls.bt_synonym_name= gls.bt_synonym_name
)

--INSERTING SECTION BT SYNONYM
Insert into ep_published_comp_glossary_mst
(
customer_name,   project_name,  req_no,
process_name,   component_name,  bt_synonym_name,
data_type,    length,    bt_synonym_caption,
glossary_sysid,   timestamp,   createdby,
createddate,   modifiedby,   modifieddate,
ref_bt_synonym_name, bt_synonym_doc,  bt_name,
synonym_status
)
Select distinct
gls.customer_name,  gls.project_name, @engg_req_no,
gls.process_name,  gls.component_name, gls.bt_synonym_name,
gls.data_type,   gls.length,   gls.bt_synonym_caption,
glossary_sysid,  1,     @ctxt_user,
@date,    @ctxt_user,   @date,
gls.ref_bt_synonym_name,gls.bt_synonym_doc, gls.bt_name,
gls.synonym_status
from ep_component_glossary_mst  gls (nolock),
ep_ui_section_dtl pg  (nolock)
where pg.customer_name  = @engg_customer_name
and  pg.project_name   = @engg_project_name
and  pg.req_no    = (@engg_base_req_no)
and  pg.process_name   = @process_name_temp
and  pg.component_name  = @component_name_temp
and  pg.activity_name  = @activity_name_temp
and  pg.ui_name    = @ui_name_temp
and  pg.customer_name  = gls.customer_name
and  pg.project_name   = gls.project_name
and  pg.req_no    = gls.req_no
and  pg.process_name   = gls.process_name
and  pg.component_name  = gls.component_name
and  pg.section_bt_synonym = gls.bt_synonym_name
and  not exists     (
Select 'A'
from ep_published_comp_glossary_mst pgls (nolock)
where pgls.customer_name  = gls.customer_name
and  pgls.project_name  = gls.project_name
and  pgls.req_no    = @engg_req_no
and  pgls.process_name  = gls.process_name
and  pgls.component_name  = gls.component_name
and  pgls.bt_synonym_name = gls.bt_synonym_name
-- code modified by shafina on 14-Apr-2004 for PREVIEWENG203ACC_000034 to comment sysid in join
--            and  pgls.glossary_sysid  = gls.glossary_sysid
)*/

--CODE ADDED BY GIRI ON 17/01/2004
-- code commented by shafina on 29-April-2004 for PREVIEWENG203ACC_000050
/*   Update b
Set  b.bt_synonym_caption= a.bt_synonym_caption
from ep_component_glossary_mst  a (nolock),
ep_published_comp_glossary_mst b (nolock)
where a.customer_name  = b.customer_name
and  a.project_name  = b.project_name
and  a.process_name  = b.process_name
and  a.component_name = b.component_name
and  a.glossary_sysid = b.glossary_sysid*/

--INSERTING CONTROL BT SYNONYM
/*   Insert into ep_published_comp_glossary_mst
(
customer_name,  project_name,  req_no,
process_name,   component_name,  bt_synonym_name,
data_type,    length,    bt_synonym_caption,
glossary_sysid,   timestamp,   createdby,
createddate,   modifiedby,   modifieddate,
ref_bt_synonym_name, bt_synonym_doc,  bt_name,
synonym_status
)
Select distinct
gls.customer_name,  gls.project_name, @engg_req_no,
gls.process_name,  gls.component_name, gls.bt_synonym_name,
gls.data_type,   gls.length,   gls.bt_synonym_caption,
glossary_sysid,   1,     @ctxt_user,
@date,    @ctxt_user,   @date,
gls.ref_bt_synonym_name,gls.bt_synonym_doc, gls.bt_name,
gls.synonym_status
from ep_component_glossary_mst  gls (nolock),
ep_ui_control_dtl pg  (nolock)
where pg.customer_name  = @engg_customer_name
and  pg.project_name   = @engg_project_name
and  pg.req_no    = (@engg_base_req_no)
and  pg.process_name   = @process_name_temp
and  pg.component_name  = @component_name_temp
and  pg.activity_name  = @activity_name_temp
and  pg.ui_name    = @ui_name_temp
and  pg.customer_name  = gls.customer_name
and  pg.project_name   = gls.project_name
and  pg.req_no    = gls.req_no
and  pg.process_name   = gls.process_name
and  pg.component_name  = gls.component_name
and  pg.control_bt_synonym = gls.bt_synonym_name
and  not exists     (
Select 'A'
from ep_published_comp_glossary_mst pgls (nolock)
where pgls.customer_name  = gls.customer_name
and  pgls.project_name  = gls.project_name
and  pgls.req_no    = @engg_req_no
and  pgls.process_name  = gls.process_name
and  pgls.component_name  = gls.component_name
and  pgls.bt_synonym_name = gls.bt_synonym_name
--            and  pgls.glossary_sysid  = gls.glossary_sysid
)

--INSERTING GRID BT SYNONYM
Insert into ep_published_comp_glossary_mst
(
customer_name,   project_name,  req_no,
process_name,   component_name,  bt_synonym_name,
data_type,    length,    bt_synonym_caption,
glossary_sysid,   timestamp,   createdby,
createddate,   modifiedby,   modifieddate,
ref_bt_synonym_name, bt_synonym_doc,  bt_name,
synonym_status
)
Select distinct
gls.customer_name,  gls.project_name, @engg_req_no,
gls.process_name,  gls.component_name, gls.bt_synonym_name,
gls.data_type,   gls.length,   gls.bt_synonym_caption,
glossary_sysid,   1,     @ctxt_user,
@date,    @ctxt_user,   @date,
gls.ref_bt_synonym_name,gls.bt_synonym_doc, gls.bt_name,
gls.synonym_status
from ep_component_glossary_mst  gls (nolock),
ep_ui_grid_dtl  pg  (nolock)
where pg.customer_name  = @engg_customer_name
and  pg.project_name   = @engg_project_name
and  pg.req_no    = (@engg_base_req_no)
and  pg.process_name   = @process_name_temp
and  pg.component_name  = @component_name_temp
and  pg.activity_name  = @activity_name_temp
and  pg.ui_name    = @ui_name_temp
and  pg.customer_name  = gls.customer_name
and  pg.project_name   = gls.project_name
and  pg.req_no    = gls.req_no
and  pg.process_name   = gls.process_name
and  pg.component_name  = gls.component_name
and  pg.column_bt_synonym = gls.bt_synonym_name
and  not exists     (
Select 'A'
from ep_published_comp_glossary_mst pgls (nolock)
where pgls.customer_name = gls.customer_name
and  pgls.project_name = gls.project_name
and  pgls.req_no   = @engg_req_no
and  pgls.process_name = gls.process_name
and  pgls.component_name = gls.component_name
and  pgls.bt_synonym_name= gls.bt_synonym_name
)
--CODE MODIFICATION TO INSERT PUBLISHED GLOSSARY MASTER - GIRIDHARAN V ON 08/01/2004 ENDS

-- INSERTING PAGE_BT_SYNONYM
Insert into ep_published_comp_glossary_mst_lng_extn
(
customer_name,  project_name,  req_no,
process_name,  component_name,  bt_synonym_name,
data_type,   length,    bt_synonym_caption,
glossary_sysid,  languageid,   timestamp,
createdby,   createddate,  modifiedby,
modifieddate,  ref_bt_synonym_name,bt_synonym_doc,
bt_name,   synonym_status
)
Select distinct
gls.customer_name,  gls.project_name,  @engg_req_no,
gls.process_name,  gls.component_name,  gls.bt_synonym_name,
gls.data_type,   gls.length,    gls.bt_synonym_caption,
glossary_sysid,   gls.languageid,   1,
@ctxt_user,    @date,    @ctxt_user,
@date,    gls.ref_bt_synonym_name,gls.bt_synonym_doc,
gls.bt_name,   gls.synonym_status
from ep_component_glossary_mst_lng_extn gls (nolock),
ep_ui_page_dtl      pg  (nolock)
where pg.customer_name = @engg_customer_name
and  pg.project_name  = @engg_project_name
and  pg.req_no   = (@engg_base_req_no)
and  pg.process_name  = @process_name_temp
and  pg.component_name = @component_name_temp
and  pg.activity_name = @activity_name_temp
and  pg.ui_name   = @ui_name_temp
and  pg.customer_name = gls.customer_name
and  pg.project_name  = gls.project_name
and  pg.req_no   = gls.req_no
and  pg.process_name  = gls.process_name
and  pg.component_name = gls.component_name
and  pg.page_bt_synonym = gls.bt_synonym_name
and  not exists    (
Select 'A'
from ep_published_comp_glossary_mst_lng_extn pgls (nolock)
where pgls.customer_name = gls.customer_name
and  pgls.project_name = gls.project_name
and  pgls.req_no   = @engg_req_no
and  pgls.process_name = gls.process_name
and  pgls.component_name = gls.component_name
and  pgls.bt_synonym_name= gls.bt_synonym_name
)

--INSERTING SECTION BT SYNONYM
Insert into ep_published_comp_glossary_mst_lng_extn
(
customer_name,  project_name,  req_no,
process_name,  component_name,  bt_synonym_name,
data_type,   length,    bt_synonym_caption,
glossary_sysid,  languageid,   timestamp,
createdby,   createddate,  modifiedby,
modifieddate,  ref_bt_synonym_name,bt_synonym_doc,
bt_name,   synonym_status
)
Select distinct
gls.customer_name,  gls.project_name,  @engg_req_no,
gls.process_name,  gls.component_name,  gls.bt_synonym_name,
gls.data_type,   gls.length,    gls.bt_synonym_caption,
glossary_sysid,   gls.languageid,   1,
@ctxt_user,    @date,    @ctxt_user,
@date,    gls.ref_bt_synonym_name,gls.bt_synonym_doc,
gls.bt_name,   gls.synonym_status
from ep_component_glossary_mst_lng_extn  gls (nolock),
ep_ui_section_dtl pg  (nolock)
where pg.customer_name  = @engg_customer_name
and  pg.project_name   = @engg_project_name
and  pg.req_no    = (@engg_base_req_no)
and  pg.process_name   = @process_name_temp
and  pg.component_name  = @component_name_temp
and  pg.activity_name  = @activity_name_temp
and  pg.ui_name    = @ui_name_temp
and  pg.customer_name  = gls.customer_name
and  pg.project_name   = gls.project_name
and  pg.req_no    = gls.req_no
and  pg.process_name   = gls.process_name
and  pg.component_name  = gls.component_name
and  pg.section_bt_synonym = gls.bt_synonym_name
and  not exists     (
Select 'A'
from ep_published_comp_glossary_mst_lng_extn pgls (nolock)
where pgls.customer_name  = gls.customer_name
and  pgls.project_name  = gls.project_name
and  pgls.req_no    = @engg_req_no
and  pgls.process_name  = gls.process_name
and  pgls.component_name  = gls.component_name
and  pgls.bt_synonym_name = gls.bt_synonym_name
--            and  pgls.glossary_sysid  = gls.glossary_sysid
)*/
-- code commented by shafina on 29-April-2004 for PREVIEWENG203ACC_000050
/*   Update b
Set  b.bt_synonym_caption= a.bt_synonym_caption
from ep_component_glossary_mst_lng_extn  a (nolock),
ep_published_comp_glossary_mst_lng_extn b (nolock)
where a.customer_name  = b.customer_name
and  a.project_name = b.project_name
and  a.process_name  = b.process_name
and  a.component_name = b.component_name
and  a.glossary_sysid = b.glossary_sysid*/

--INSERTING CONTROL BT SYNONYM
/*   Insert into ep_published_comp_glossary_mst_lng_extn
(
customer_name,  project_name,  req_no,
process_name,  component_name,  bt_synonym_name,
data_type,   length,    bt_synonym_caption,
glossary_sysid,  languageid,   timestamp,
createdby,   createddate,  modifiedby,
modifieddate,  ref_bt_synonym_name,bt_synonym_doc,
bt_name,   synonym_status
)
Select distinct
gls.customer_name,  gls.project_name,  @engg_req_no,
gls.process_name,  gls.component_name,  gls.bt_synonym_name,
gls.data_type,   gls.length,  gls.bt_synonym_caption,
glossary_sysid,   gls.languageid,   1,
@ctxt_user,    @date,    @ctxt_user,
@date,    gls.ref_bt_synonym_name,gls.bt_synonym_doc,
gls.bt_name,   gls.synonym_status
from ep_component_glossary_mst_lng_extn  gls (nolock),
ep_ui_control_dtl pg  (nolock)
where pg.customer_name  = @engg_customer_name
and  pg.project_name   = @engg_project_name
and  pg.req_no    = (@engg_base_req_no)
and  pg.process_name   = @process_name_temp
and  pg.component_name  = @component_name_temp
and pg.activity_name  = @activity_name_temp
and  pg.ui_name    = @ui_name_temp
and  pg.customer_name  = gls.customer_name
and  pg.project_name   = gls.project_name
and  pg.req_no    = gls.req_no
and  pg.process_name   = gls.process_name
and  pg.component_name  = gls.component_name
and  pg.control_bt_synonym = gls.bt_synonym_name
and  not exists     (
Select 'A'
from ep_published_comp_glossary_mst_lng_extn pgls (nolock)
where pgls.customer_name  = gls.customer_name
and  pgls.project_name  = gls.project_name
and  pgls.req_no    = @engg_req_no
and  pgls.process_name  = gls.process_name
and  pgls.component_name  = gls.component_name
and  pgls.bt_synonym_name = gls.bt_synonym_name
--            and  pgls.glossary_sysid  = gls.glossary_sysid
)

--INSERTING GRID BT SYNONYM
Insert into ep_published_comp_glossary_mst_lng_extn
(
customer_name,  project_name,  req_no,
process_name,  component_name,  bt_synonym_name,
data_type,   length,    bt_synonym_caption,
glossary_sysid,  languageid,   timestamp,
createdby,   createddate,  modifiedby,
modifieddate,  ref_bt_synonym_name,bt_synonym_doc,
bt_name,   synonym_status
)
Select distinct
gls.customer_name,  gls.project_name,  @engg_req_no,
gls.process_name,  gls.component_name,  gls.bt_synonym_name,
gls.data_type,   gls.length,    gls.bt_synonym_caption,
glossary_sysid,   gls.languageid,   1,
@ctxt_user,    @date,    @ctxt_user,
@date,    gls.ref_bt_synonym_name,gls.bt_synonym_doc,
gls.bt_name,   gls.synonym_status
from ep_component_glossary_mst_lng_extn  gls (nolock),
ep_ui_grid_dtl  pg  (nolock)
where pg.customer_name  = @engg_customer_name
and  pg.project_name   = @engg_project_name
and  pg.req_no    = (@engg_base_req_no)
and  pg.process_name   = @process_name_temp
and  pg.component_name  = @component_name_temp
and  pg.activity_name  = @activity_name_temp
and  pg.ui_name    = @ui_name_temp
and  pg.customer_name  = gls.customer_name
and  pg.project_name   = gls.project_name
and  pg.req_no    = gls.req_no
and  pg.process_name   = gls.process_name
and  pg.component_name  = gls.component_name
and  pg.column_bt_synonym = gls.bt_synonym_name
and  not exists     (
Select 'A'
from ep_published_comp_glossary_mst_lng_extn pgls (nolock)
where pgls.customer_name = gls.customer_name
and  pgls.project_name = gls.project_name
and  pgls.req_no   = @engg_req_no
and  pgls.process_name = gls.process_name
and  pgls.component_name = gls.component_name
and  pgls.bt_synonym_name= gls.bt_synonym_name
)
*/
--    -- For deletiong ep_published_action_mst
delete  from ep_published_action_mst
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)

-- INSERTING INTO EP_PUBLISHED_ACTION_MST
insert into ep_published_action_mst
(
customer_name,  project_name,  req_no,
process_name,  component_name,  activity_name,
ui_name,   page_bt_synonym, task_name,
task_descr,   task_seq,   task_pattern,
primary_control_bts,task_sysid,   ui_sysid,
createdby,   createddate,  modifiedby,
--code modified for the caseid :PNR2.0_26475 starts
modifieddate,  timestamp,   --status_flag,
task_type,  task_confirm_msg,  task_status_msg, -- Column added by Mohideen on Jun 15, 2006
usageid,ddt_page_bt_synonym,ddt_control_bt_synonym,ddt_control_id,ddt_view_name , -- Columns added  for  PNR2.0_1790
task_process_msg, PopUp_page_bt_synonym, PopUp_section, PopUp_close,--Column added  for PNR2.0_30869 ,PLF2.0_00961
Iscallout
,QR_sourceCtrl,QR_targetCtrl,Barcode_sourceCtrl,Barcode_targetCtrl,browse_control-- cpde added for qrcode
,QR_sourceCtrl_Page,QR_targetCtrl_Page,Barcode_sourceCtrl_Page,Barcode_targetCtrl_Page,browse_control_Page,group_name,
Buttonbar_primary_section,Popup_onclick_close,Autoupload,sectionlaunchtype,  		-- added for SectionLaunch Type TECH-12776 
QuickTask, SystemTaskType,  -- Added for the Defect ID TECH-29822
SystemGenerated)	--TECH-73216
select
customer_name,  project_name,  @engg_req_no,
process_name,  component_name,  activity_name,
ui_name,   page_bt_synonym, task_name,
task_descr,   task_seq,   task_pattern,
primary_control_bts,newid(),   ui_sysid,
@ctxt_user,   @date,    @ctxt_user,
@date,    1,     --'',
-- code modified by shafina on 29-July-2004 for DEENG203SYS_000324 as task type inserted wrongly
task_type,  task_confirm_msg,  task_status_msg, -- Column added by Mohideen on Jun 15, 2006
usageid,ddt_page_bt_synonym,ddt_control_bt_synonym,ddt_control_id,ddt_view_name ,  -- Columns added  for  PNR2.0_1790
task_process_msg, PopUp_page_bt_synonym, PopUp_section, PopUp_close--Column added  for PNR2.0_30869 ,PLF2.0_00961
,iscallout
,QR_sourceCtrl,QR_targetCtrl,Barcode_sourceCtrl,Barcode_targetCtrl,browse_control
,QR_sourceCtrl_Page,QR_targetCtrl_Page,Barcode_sourceCtrl_Page,Barcode_targetCtrl_Page,browse_control_Page,group_name,
Buttonbar_primary_section,Popup_onclick_close,Autoupload,sectionlaunchtype,
QuickTask, SystemTaskType,  -- Added for the Defect ID TECH-29822
SystemGenerated	--TECH-73216
from ep_action_mst (nolock)
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_base_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)

-- Added by Jeya for extn js -- PNR2.0_1790

delete  from ep_published_ext_js_section_dtl
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   req_no     = @engg_req_no
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp


insert into ep_published_ext_js_section_dtl
(customer_name,  project_name,   req_no,   process_name,   component_name,  activity_name,   ui_name,
page_bt_synonym,  section_bt_synonym, section_type,  Section_Width,   Section_Height,  Section_Class,   RVW_Task,
Callout_Task,   Direction,    Scroll_Behaviour,Scroll_Delay,   Fade_Delay,   No_Of_Columns,   Report_Item_Class,
Property_Class,  Value_Class,   sample_data,  createdby,    createddate,   modifiedby,   modifieddate)
select
customer_name,  project_name,   @engg_req_no,   process_name,   component_name,  activity_name,   ui_name,
page_bt_synonym,  section_bt_synonym, section_type,  Section_Width,   Section_Height,  Section_Class,   RVW_Task,
Callout_Task,   Direction,    Scroll_Behaviour,Scroll_Delay,   Fade_Delay,   No_Of_Columns,   Report_Item_Class,
Property_Class,  Value_Class,   sample_data,  @ctxt_user,   @date,     @ctxt_user,   @date
from  ep_ext_js_section_dtl (nolock)
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   req_no     = @engg_base_req_no
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp

delete  from ep_published_ext_js_control_dtl
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   req_no     = @engg_req_no
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp

insert into ep_published_ext_js_control_dtl
(customer_name,  project_name, req_no,    process_name,   component_name,   activity_name,   ui_name,
page_bt_synonym,  section_bt_synonym, control_bt_synonym, Extjs_Ctrl_type,  Ctrl_height,  ctrl_width,   Control_Class,
RVW_Task,    Callout_Task,   Type_Delay,   Type_Direction,  Fade_Delay,    Fade_Direction,  Loop_Count,
sample_data,  feature_name,   createdby,    createddate,   modifiedby,    modifieddate)
select
customer_name,   project_name,   @engg_req_no,    process_name,   component_name,   activity_name,   ui_name,
page_bt_synonym,  section_bt_synonym, control_bt_synonym, Extjs_Ctrl_type,  Ctrl_height,    ctrl_width,   Control_Class,
RVW_Task,    Callout_Task,   Type_Delay,   Type_Direction,  Fade_Delay,    Fade_Direction,  Loop_Count,
sample_data,  feature_name,   @ctxt_user,   @date,     @ctxt_user,    @date
from  ep_ext_js_control_dtl (nolock)
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   req_no     = @engg_base_req_no
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp


delete  from ep_published_ext_js_section_column_dtl
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   req_no     = @engg_req_no
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp

insert into ep_published_ext_js_section_column_dtl
(customer_name,  project_name,   req_no,    process_name,   component_name, activity_name,   ui_name,  page_bt_synonym,
section_bt_synonym, section_type,   control_bt_synonym, Column_Sequence,  Column_BT_Synonym,  IS_Key,    Datatype,  Grouping,
Grouping_Function,  Grouping_Synonym,  RVW_Task,    Callout_Task,   Label_Class,   Control_Class,   sample_data, createdby,
createddate,   modifiedby,   modifieddate,  FieldList,   Default_Dragoption, column_type
,visible_length,image_column)
select
customer_name,   project_name,   @engg_req_no,    process_name,   component_name,  activity_name,   ui_name,  page_bt_synonym,
section_bt_synonym, section_type,   control_bt_synonym, Column_Sequence,  Column_BT_Synonym,  IS_Key,    Datatype,  Grouping,
Grouping_Function,  Grouping_Synonym,  RVW_Task,    Callout_Task,   Label_Class,   Control_Class,   sample_data, @ctxt_user,
@date,     @ctxt_user,   @date,    FieldList,   Default_Dragoption, column_type
,visible_length,image_column
from  ep_ext_js_section_column_dtl (nolock)
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   req_no     = @engg_base_req_no
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp

-- Added by Jeya for extnjs -- PNR2.0_1790

-- Start for the Feature Context Menu(PNR2.0_1476) - Added by Jeya
delete  from ep_published_ui_contextmenu_task_dtl
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)


-- INSERTING INTO ep_published_ui_contextmenu_task_dtl

insert into ep_published_ui_contextmenu_task_dtl
(
customer_name,  project_name,  req_no,
process_name,  component_name,  activity_name,
ui_name,   page_bt_synonym, section_name, control_bt_synonym,control_id,
task_name,task_descr,   task_seq,   task_pattern,
task_type, createdby,   createddate,  modifiedby,
modifieddate,  timestamp,wrkreqno
)
select
customer_name,  project_name, @engg_req_no,
process_name,  component_name,  activity_name,
ui_name,   page_bt_synonym, section_name, control_bt_synonym,control_id,
task_name,task_descr,   task_seq,   task_pattern,
task_type,  @ctxt_user,   @date,   @ctxt_user, @date,    1,
wrkreqno
from ep_ui_contextmenu_task_dtl (nolock)
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_base_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)

-- End for the Feature Context Menu(PNR2.0_1476) - Added by Jeya

-- code modified by Ganesh for the callid :: PNR2.0_3386 on 01/08/05
delete  from ep_published_action_mst_lng_extn
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)

/* Code modified by Gankan.G for the CaseId:PNR2.0_32385 to populate lang extn tables starts*/
insert into ep_action_mst_lng_extn(customer_name,project_name,req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,task_name,task_descr,task_seq,
task_pattern,languageid,timestamp,createdby,createddate,modifiedby,modifieddate,primary_control_bts,task_sysid,ui_sysid,task_type,task_confirm_msg,
task_status_msg,wrkreqno,usageid,ddt_page_bt_synonym,ddt_control_bt_synonym,ddt_control_id,ddt_view_name,task_process_msg,PopUp_page_bt_synonym,PopUp_section,
PopUp_close,Iscallout,QR_sourceCtrl,QR_targetCtrl,Barcode_sourceCtrl,Barcode_targetCtrl,browse_control,QR_sourceCtrl_Page,QR_targetCtrl_Page,
Barcode_sourceCtrl_Page,Barcode_targetCtrl_Page,browse_control_Page,group_name,Buttonbar_primary_section,Popup_onclick_close,Autoupload)
select distinct a.customer_name,a.project_name,a.req_no,a.process_name,a.component_name,a.activity_name,a.ui_name,a.page_bt_synonym,a.task_name,a.task_descr,a.task_seq,
a.task_pattern,c.quick_code,a.timestamp,a.createdby,a.createddate,a.modifiedby,a.modifieddate,a.primary_control_bts,a.task_sysid,a.ui_sysid,a.task_type,a.task_confirm_msg,
a.task_status_msg,a.wrkreqno,a.usageid,a.ddt_page_bt_synonym,a.ddt_control_bt_synonym,a.ddt_control_id,a.ddt_view_name,a.task_process_msg,a.PopUp_page_bt_synonym,a.PopUp_section,
a.PopUp_close,a.Iscallout,a.QR_sourceCtrl,a.QR_targetCtrl,a.Barcode_sourceCtrl,a.Barcode_targetCtrl,a.browse_control,a.QR_sourceCtrl_Page,a.QR_targetCtrl_Page,
a.Barcode_sourceCtrl_Page,a.Barcode_targetCtrl_Page,a.browse_control_Page,group_name,Buttonbar_primary_section,a.Popup_onclick_close,a.Autoupload
from ep_action_mst a(nolock),
ep_language_met c(nolock)
where a.ui_name <> 'IntegrationUI'
and  a.customer_name = @customer_name_temp
and  a.project_name = @project_name_temp
and  not exists ( select 'b'
from ep_action_mst_lng_extn b(nolock)
where b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.req_no   = a.req_no
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name
and  b.page_bt_synonym = a.page_bt_synonym
and  b.task_name   = a.task_name 
and	b.languageid	= c.quick_code) --TECH-71454
/* Code modified by Gankan.G for the CaseId:PNR2.0_32385 to populate lang extn tables ends*/

-- code added for Multi lang popup section population starts TECH-45119
Update	b
Set		b.PopUp_page_bt_synonym	= a.PopUp_page_bt_synonym,
		b.PopUp_section			= a.PopUp_section,
		b.PopUp_close			= a.PopUp_close,
		b.Popup_onclick_close	= a.Popup_onclick_close
from	ep_action_mst_lng_extn  a (nolock),
		ep_action_mst_lng_extn b (nolock)
where   a.customer_name		= @customer_name_temp
and		a.project_name		= @project_name_temp
and		a.process_name		= @process_name_temp
and		a.component_name	= @component_name_temp
and		a.activity_name		= @activity_name_temp
and		a.ui_name			= @ui_name_temp
and		a.customer_name		= b.customer_name
and		a.project_name		= b.project_name
and		a.process_name		= b.process_name
and		a.component_name	= b.component_name
and		a.activity_name		= b.activity_name
and		a.ui_name			= b.ui_name
and		a.page_bt_synonym	= b.page_bt_synonym
and		a.task_name			= b.task_name
and		a.languageid		=	'1'
and		b.languageid		<>	'1'

-- code added for Multi lang popup section population Ends TECH-45119


insert into ep_published_action_mst_lng_extn
( customer_name,  project_name,  req_no,     process_name,
component_name,  activity_name,  ui_name,    page_bt_synonym,
task_name,   task_descr,   task_seq,    task_pattern,
languageid,   timestamp,   createdby,    createddate,
modifiedby,   modifieddate,  primary_control_bts, task_sysid,
ui_sysid,   task_type,   task_confirm_msg,  task_status_msg, -- Column added by Mohideen on Jun 15, 2006
usageid,ddt_page_bt_synonym,ddt_control_bt_synonym,ddt_control_id,ddt_view_name,   -- Columns added  for  PNR2.0_1790
task_process_msg, PopUp_page_bt_synonym, PopUp_section, PopUp_close,-- Code Added for PNR2.0_30869,PLF2.0_00961
iscallout
,QR_sourceCtrl,QR_targetCtrl,Barcode_sourceCtrl,Barcode_targetCtrl,browse_control
,QR_sourceCtrl_Page,QR_targetCtrl_Page,Barcode_sourceCtrl_Page,Barcode_targetCtrl_Page,browse_control_Page,group_name,
Buttonbar_primary_section,Popup_onclick_close,Autoupload)
select distinct
customer_name,  project_name,  @engg_req_no,   process_name,
component_name,  activity_name,  ui_name,    page_bt_synonym,
task_name,   task_descr,   task_seq,    task_pattern,
languageid,   1,     @ctxt_user,    @date,
@ctxt_user,   @date,    primary_control_bts, newid(),
ui_sysid,   task_type,   task_confirm_msg,  task_status_msg ,-- Column added by Mohideen on Jun 15, 2006
usageid,ddt_page_bt_synonym,ddt_control_bt_synonym,ddt_control_id,ddt_view_name,    -- Columns added  for  PNR2.0_1790
task_process_msg, PopUp_page_bt_synonym, PopUp_section, PopUp_close,-- Code Added for PNR2.0_30869,PLF2.0_00961 -
iscallout
,QR_sourceCtrl,QR_targetCtrl,Barcode_sourceCtrl,Barcode_targetCtrl,browse_control
,QR_sourceCtrl_Page,QR_targetCtrl_Page,Barcode_sourceCtrl_Page,Barcode_targetCtrl_Page,browse_control_Page,group_name,
Buttonbar_primary_section,Popup_onclick_close,Autoupload
from ep_action_mst_lng_extn (nolock)
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_base_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)

-- code added by Lakshmi M on 28/09/2005

/*Code added for TECH-69624 starts*/
insert into ep_published_ui_control_customaction
(customer_name, project_name, req_no, process_name, component_name,	activity_name, ui_name, page_bt_synonym, section_bt_synonym,
control_bt_synonym, ActionControlBTSynonym, Control_ID, View_Name, ActionType, ActionSequence, IconClass, IconPosition, Width,
ToolTip, ActionName, ActionDescription, ActionControlID, ActionViewName, Createdby,Createddate, Modifiedby, Modifieddate)
select distinct 
customer_name, project_name, @engg_req_no, process_name, component_name,	activity_name, ui_name, page_bt_synonym, section_bt_synonym,
control_bt_synonym, ActionControlBTSynonym, Control_ID, View_Name, ActionType, ActionSequence, IconClass, IconPosition, Width,
ToolTip, ActionName, ActionDescription, ActionControlID, ActionViewName, Createdby,Createddate, Modifiedby, Modifieddate
from ep_ui_control_customaction with(nolock)
where customer_name =  (@customer_name_temp)
and  project_name	=  (@project_name_temp)
and  req_no			=  (@engg_base_req_no)
and  process_name	=  (@process_name_temp)
and  component_name =  (@component_name_temp)
and  activity_name	=  (@activity_name_temp)
and  ui_name		=  (@ui_name_temp)
/*Code added for TECH-69624 Ends*/

/*Code added for the Defect Id Tech-70687 starts*/
insert into ep_published_ui_section_Titleaction
(customer_name,project_name,req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,TitleControlBTSynonym,
ActionType,ActionSequence,IconClass,IconPosition,Width,ToolTip,ActionName,ActionDescription,ActionControlID,ActionViewName,Createdby,Createddate,Modifiedby,
Modifieddate,Titleaction)
select distinct 
customer_name,project_name,@engg_req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,TitleControlBTSynonym,
ActionType,ActionSequence,IconClass,IconPosition,Width,ToolTip,ActionName,ActionDescription,ActionControlID,ActionViewName,Createdby,Createddate,Modifiedby,
Modifieddate,Titleaction
from ep_ui_section_Titleaction with(nolock)
where customer_name =  (@customer_name_temp)
and  project_name	=  (@project_name_temp)
and  req_no			=  (@engg_base_req_no)
and  process_name	=  (@process_name_temp)
and  component_name =  (@component_name_temp)
and  activity_name	=  (@activity_name_temp)
and  ui_name		=  (@ui_name_temp)
/*Code added for the Defect Id Tech-70687 ends*/

delete  from ep_published_tree_sample_data_map
where  customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no  =  (@engg_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name  = (@ui_name_temp)

delete  from ep_published_tree_sample_data
where  customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no  =  (@engg_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name  = (@ui_name_temp)

delete  from ep_published_tree_dtl
where  customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no  =  (@engg_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name  = (@ui_name_temp)


insert into ep_published_tree_dtl(
customer_name,  project_name,  req_no,
process_name,  component_name,  activity_name,
ui_name,  page_bt_synonym,  section_bt_synonym,
node_type,  node_description, event_req,
mapped_task,  open_img_name,  not_exp_img_name,
expendable_img_name, expended_img_name, close_img_name,
chkbox_chk_img,  chkbox_unchk_img, chkbox_parial_chkimg,
createdby,  createddate,  modifiedby,
modifieddate,  CheckboxRequired, linesRequired,
StylesheetClass,ExpandImageEvent)

Select distinct
@customer_name_temp, @project_name_temp, @engg_req_no,-- Modified by Hamsika for the Bug ID : Case ID : Platform_2.0.3.1_65 -- Pri Key Violation Err on Pub Work Req
@process_name_temp, @component_name_temp, @activity_name_temp,
@ui_name_temp,  page_bt_synonym,  section_bt_synonym,
node_type,  node_description, event_req,
mapped_task,  open_img_name,  not_exp_img_name,
expendable_img_name, expended_img_name, close_img_name,
chkbox_chk_img,  chkbox_unchk_img, chkbox_parial_chkimg,
@ctxt_user,  getdate(),  @ctxt_user,
getdate(),  CheckboxRequired, linesRequired,
StylesheetClass,ExpandImageEvent
from ep_tree_dtl(nolock)
where customer_name =  (@customer_name_temp)
and project_name =  (@project_name_temp)
and process_name = (@process_name_temp)
and component_name = (@component_name_temp)
and activity_name = (@activity_name_temp)
and ui_name  = (@ui_name_temp)




insert into ep_published_tree_sample_data(
customer_name,  project_name,  req_no,
process_name,  component_name,  activity_name,
ui_name,  page_bt_synonym,  section_bt_synonym,
node_type,  node_description, createdby,
createddate,  modifiedby,  modifieddate,
Node_id)
Select
@customer_name_temp, @project_name_temp, @engg_req_no,-- Modified by Hamsika for the Bug ID : Case ID : Platform_2.0.3.1_65 -- Pri Key Violation Err on Pub Work Req
@process_name_temp, @component_name_temp, @activity_name_temp,
@ui_name_temp,  page_bt_synonym,  section_bt_synonym,
node_type,  node_description, @ctxt_user,
getdate(),  @ctxt_user,  getdate(),
Node_id
from ep_tree_sample_data(nolock)
where customer_name =  (@customer_name_temp)
and project_name =  (@project_name_temp)
and process_name = (@process_name_temp)
and component_name = (@component_name_temp)
and activity_name = (@activity_name_temp)
and ui_name  = (@ui_name_temp)




insert into ep_published_tree_sample_data_map(
customer_name,  project_name,  req_no,
process_name,  component_name,  activity_name,
ui_name,  page_bt_synonym,  section_bt_synonym,
node_id,  parent_node_id,  node_type,
node_description, parent_node_type, parent_node_descr,
mapped_flag,  createdby,  createddate,
modifiedby,  modifieddate)
Select
@customer_name_temp, @project_name_temp, @engg_req_no,-- Modified by Hamsika for the Bug ID : Case ID : Platform_2.0.3.1_65 -- Pri Key Violation Err on Pub Work Req
@process_name_temp, @component_name_temp, @activity_name_temp,
@ui_name_temp,  page_bt_synonym,  section_bt_synonym,
node_id,  parent_node_id,  node_type,
node_description, parent_node_type, parent_node_descr,
mapped_flag,  @ctxt_user,  getdate(),
@ctxt_user,  getdate()
from ep_tree_sample_data_map(nolock)
where customer_name =  (@customer_name_temp)
and project_name =  (@customer_name_temp)
and process_name = (@process_name_temp)
and component_name = (@component_name_temp)
and activity_name = (@activity_name_temp)
and ui_name  = (@ui_name_temp)


--code added by Feroz for spin control

delete  ep_published_spin_control_dtl
where  customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)


Insert into ep_published_spin_control_dtl
(customer_name,  project_name,  req_no,   process_name,
component_name, activity_name,  ui_name,  page_bt_synonym,
section_bt_synonym, control_bt_synonym, control_type, spin_control_bt_synonym,
spincontrol_section)


select
@customer_name_temp, @project_name_temp,  @engg_req_no, @process_name_temp,
@component_name_temp, @activity_name_temp, @ui_name_temp, page_bt_synonym,
section_bt_synonym,  control_bt_synonym, control_type, spin_control_bt_synonym,
spincontrol_section
from ep_spin_control_dtl(nolock)
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)

delete
from ep_published_comp_ctrl_type_mst 
where customer_name  =  (@customer_name_temp)
and project_name  =  (@project_name_temp)
and req_no    =  (@engg_req_no)
and process_name  = (@process_name_temp)
and component_name  = (@component_name_temp)

delete
from ep_published_comp_task_type_mst 
where customer_name  =  (@customer_name_temp)
and project_name  =  (@project_name_temp)
and req_no    =  (@engg_req_no)
and process_name  = (@process_name_temp)
and component_name  = (@component_name_temp)


--Added By Kanagavel A For control Type and task type property History
/*
--Insert into ep_published_comp_ctrl_type_mst

--(
--customer_name,project_name,req_no,process_name,component_name,ctrl_type_name,ctrl_type_descr,base_ctrl_type,mandatory_flag,visisble_flag,editable_flag,caption_req,select_flag,zoom_req,insert_req,delete_req,help_req,event_handling_req,ellipses_req,comp_




c

trl_type_sysid,timestamp,createdby,createddate,modifiedby,modifieddate,caption_alignment,caption_position,caption_wrap,visisble_rows,ctrl_type_doc,ctrl_position,label_class,ctrl_class,password_char,tskimg_class,hlpimg_class,disponlycmb_req,html_txt_area,r






eport_req,Auto_tab_stop,Spin_required,Spin_up_image,Spin_down_image,InPlace_Calendar,EditMask,NoofLinesPerRow,RowHeight,Vscrollbar_Req,Is_Extjs_Control,Extjs_Ctrl_type,gridlite_req,bulletlink_req,buttoncombo_req,associatedlist_req,onfocustask_req,listrefi






lltask_req,attach_document,image_upload,inplace_image,listedit_noofcolumns,image_row_height,relative_url_path,relative_document_path,relative_image_path,save_doc_content_to_db,save_image_content_to_db,dataascaption,image_icon,Date_highlight,ezee_report,Li






te_Attach_Document,Browse_Button_Enable,Delete_Button_Enable,image_row_width,image_preview_height,image_preview_width,image_preview_req,image_Accept_Type,Lite_Attach_Image,timezone,autoexpand,Disp_Only_Apply_Len,editcombo_req,Label_Link,captiontype,contro






lstyle,IsListBox,Toolbar_Not_Req,ColumnBorder_Not_Req,RowBorder_Not_Req,PagenavigationOnly,RowNO_Not_Req,ButtonHome_Req,ButtonPrevious_Req,Tooltip_Not_Req,Forcefit,columncaption_Not_Req,Border_Not_Req,IsModal,Alternate_Color_Req,Map_In_Req,Map_Out_Req,spi






n_system_task,combo_link,QR_Image,Barcode_Image,Accpet_Type,Isfallback,config_parameter,config_value,upload,FileSize,Is_Varbinary,EMail,Phone,StaticCaption,Datagrid,MoveFirst,Move_PrevSet,Move_Previous,Move_Next,Move_NextSet,Move_Last,Carousel_Req,Orienta






tion,WrapCount,Box_Type,ISDeviceInfo,ListControl,col_caption_align,Gridheaderstyle,Gridtoolbarstyle,preevent,postevent,col_data_align,avn_download,norowstodisplay_notreq,PreventDownload,enabledefault,hideinsert,hidedelete,hidecopy,hidecut,hidefilterdata,h






idepdf,hidereport,hidehtml,hideexportexcel,hideexportcsv,hideexporttext,hideimportdata,hidechart,hideexportopenoffice,hidepersonalize,hidefiltercolumn,searchhide,autolist_not_req,hideselect,ishijri,AutoHeight,SystemGeneratedFileId,slider_type,max_value,mi






n_value,step_value,QlikLink,IsPivot,RangeMinimum,RangeMaximum,RangeStartValue,RangeEndValue,RangeStep,RangeLabel,RangeSelect,ValueShown,Style,IsMarquee,IsAssorted,RatingType,CaptchaData, RenderAs
--)																						            
--select   @customer_name_temp, @project_name_temp, @engg_req_no,							           
--@process_name_temp, @component_name_temp, ctrl_type_name,ctrl_type_descr,base_ctrl_type,mandatory_flag,visisble_flag,editable_flag,caption_req,select_flag,zoom_req,insert_req,delete_req,help_req,event_handling_req,ellipses_req,comp_ctrl_type_sysid,times






tamp,@ctxt_user,getdate(),@ctxt_user,getdate(),caption_alignment,caption_position,caption_wrap,visisble_rows,ctrl_type_doc,ctrl_position,label_class,ctrl_class,password_char,tskimg_class,hlpimg_class,disponlycmb_req,html_txt_area,report_req,Auto_tab_stop,






Spin_required,Spin_up_image,Spin_down_image,InPlace_Calendar,EditMask,NoofLinesPerRow,RowHeight,Vscrollbar_Req,Is_Extjs_Control,Extjs_Ctrl_type,gridlite_req,bulletlink_req,buttoncombo_req,associatedlist_req,onfocustask_req,listrefilltask_req,attach_docume






nt,image_upload,inplace_image,listedit_noofcolumns,image_row_height,relative_url_path,relative_document_path,relative_image_path,save_doc_content_to_db,save_image_content_to_db,dataascaption,image_icon,Date_highlight,ezee_report,Lite_Attach_Document,Brows






e_Button_Enable,Delete_Button_Enable,image_row_width,image_preview_height,image_preview_width,image_preview_req,image_Accept_Type,Lite_Attach_Image,timezone,autoexpand,Disp_Only_Apply_Len,editcombo_req,Label_Link,captiontype,controlstyle,IsListBox,Toolbar






_Not_Req,ColumnBorder_Not_Req,RowBorder_Not_Req,PagenavigationOnly,RowNO_Not_Req,ButtonHome_Req,ButtonPrevious_Req,Tooltip_Not_Req,Forcefit,columncaption_Not_Req,Border_Not_Req,IsModal,Alternate_Color_Req,Map_In_Req,Map_Out_Req,spin_system_task,combo_link






,QR_Image,Barcode_Image,Accpet_Type,Isfallback,config_parameter,config_value,upload,FileSize,Is_Varbinary,EMail,Phone,StaticCaption,Datagrid,MoveFirst,Move_PrevSet,Move_Previous,Move_Next,Move_NextSet,Move_Last,Carousel_Req,Orientation,WrapCount,Box_Type,






ISDeviceInfo,ListControl,col_caption_align,Gridheaderstyle,Gridtoolbarstyle,preevent,postevent,col_data_align,avn_download,norowstodisplay_notreq,PreventDownload,enabledefault,hideinsert,hidedelete,hidecopy,hidecut,hidefilterdata,hidepdf,hidereport,hideht






ml,hideexportexcel,hideexportcsv,hideexporttext,hideimportdata,hidechart,hideexportopenoffice,hidepersonalize,hidefiltercolumn,searchhide,autolist_not_req,hideselect,ishijri,AutoHeight,SystemGeneratedFileId,slider_type,max_value,min_value,step_value,QlikL






ink,IsPivot,RangeMinimum,RangeMaximum,RangeStartValue,RangeEndValue,RangeStep,RangeLabel,RangeSelect,ValueShown,Style,IsMarquee,IsAssorted,RatingType,CaptchaData
--, RenderAs
--from es_comp_ctrl_type_mst (nolock)
--where customer_name  =  (@customer_name_temp)
--and project_name  =  (@project_name_temp)
--and req_no    =  'Base'
--and process_name  = (@process_name_temp)
--and component_name  = (@component_name_temp)

--Insert into ep_published_comp_task_type_mst
--(
--customer_name,project_name,req_no,process_name,component_name,task_type_name,task_type_descr,default_for,refresh_on_save,valid_on_init,err_handle_method,incl_place_holder,cond_ml_fetch,clr_on_page_save,hdr_fetch_req,ml_fet_req,hdr_ref_req,hdr_check_req,






proc_sel_rows,usr_role_map,trn_scope_req,comp_task_type_sysid,timestamp,createdby,createddate,modifiedby,modifieddate,task_type_doc,hdr_save_req,ml_save_req,fprowno_req,cbdef_req,no_placeholder,data_save_req,print_req,task_confirmation,Logic_Extensions,pr






ocess_updrows,alternate_db,sys_proc_sel_rows,sys_process_updrows,Linkasui,Uiastrans,MLSaveSinglesegment,sys_proc_selupd_rows,CurrentContextInformation,ParentContextInformation--)

--select   @customer_name_temp, @project_name_temp, @engg_req_no,--@process_name_temp, @component_name_temp, task_type_name,task_type_descr,default_for,refresh_on_save,valid_on_init,err_handle_method,incl_place_holder,cond_ml_fetch,clr_on_page_save,hdr_fe






tch_req,ml_fet_req,hdr_ref_req,hdr_check_req,proc_sel_rows,usr_role_map,trn_scope_req,comp_task_type_sysid,timestamp,@ctxt_user,getdate(),@ctxt_user,getdate(),task_type_doc,hdr_save_req,ml_save_req,fprowno_req,cbdef_req,no_placeholder,data_save_req,print_






req,task_confirmation,Logic_Extensions,process_updrows,alternate_db,sys_proc_sel_rows,sys_process_updrows,Linkasui,Uiastrans,MLSaveSinglesegment,sys_proc_selupd_rows,CurrentContextInformation,ParentContextInformation--from es_comp_task_type_mst (nolock)
--where customer_name  =  (@customer_name_temp)
--and project_name  =  (@project_name_temp)
--and req_no    =  'Base'
--and process_name  = (@process_name_temp)
--and component_name  = (@component_name_temp)
*/

	--Added by 11536 for the case ID TECH-66583 control Type and task type property History

		INSERT INTO ep_published_comp_ctrl_type_mst
			(	customer_name,				project_name,				req_no,					process_name,
				component_name,				ctrl_type_name,				ctrl_type_descr,		base_ctrl_type,
				mandatory_flag,				visisble_flag,				editable_flag,			caption_req,
				select_flag,				zoom_req,					insert_req,				delete_req,
				help_req,					event_handling_req,			ellipses_req,			comp_ctrl_type_sysid,
				caption_alignment,			caption_position,			caption_wrap,			visisble_rows,
				ctrl_type_doc,				ctrl_position,				label_class,			ctrl_class,
				password_char,				tskimg_class,				hlpimg_class,			disponlycmb_req,
				html_txt_area,				report_req,					Auto_tab_stop,			Spin_required,
				Spin_up_image,				Spin_down_image,			InPlace_Calendar,		EditMask,
				NoofLinesPerRow,			RowHeight,					Vscrollbar_Req,			Is_Extjs_Control,
				Extjs_Ctrl_type,			gridlite_req,				bulletlink_req,			buttoncombo_req,
				associatedlist_req,			onfocustask_req,			listrefilltask_req,		attach_document,
				image_upload,				inplace_image,				listedit_noofcolumns,	image_row_height,
				relative_url_path,			relative_document_path,		relative_image_path,	save_doc_content_to_db,
				save_image_content_to_db,	dataascaption,				image_icon,				Date_highlight,
				ezee_report,				Lite_Attach_Document,		Browse_Button_Enable,	Delete_Button_Enable,
				image_row_width,			image_preview_height,		image_preview_width,	image_preview_req,
				Lite_Attach_Image,			timezone,					autoexpand,				Disp_Only_Apply_Len,
				editcombo_req,				Label_Link,					captiontype,			controlstyle,
				IsListBox,					Toolbar_Not_Req,			ColumnBorder_Not_Req,	RowBorder_Not_Req,
				PagenavigationOnly,			RowNO_Not_Req,				ButtonHome_Req,			ButtonPrevious_Req,
				Accpet_Type,				combo_link,					QR_Image,				Tooltip_Not_Req,
				Forcefit,					columncaption_Not_Req,		Border_Not_Req,			IsModal,
				Alternate_Color_Req,		Map_In_Req,					Map_Out_Req,			Barcode_Image,
				Isfallback,					config_parameter,			config_value,			upload,
				Is_Varbinary,				FileSize,					EMail,					Phone,
				StaticCaption,				Datagrid,					MoveFirst,				Move_PrevSet,
				Move_Previous,				Move_Next,					Move_NextSet,			Move_Last,
				Carousel_Req,				Orientation,				WrapCount,				Box_Type,
				ISDeviceInfo,				ListControl,				col_caption_align,		Gridheaderstyle,
				Gridtoolbarstyle,			preevent,					postevent,				norowstodisplay_notreq,
				col_data_align,				avn_download,				PreventDownload,		ishijri,
				slider_type,				max_value,					min_value,				step_value,
				spin_system_task,			enabledefault,				hideinsert,				hidedelete,
				hidecopy,					hidecut,					hidefilterdata,			hidepdf,
				hidereport,					hidehtml,					hideexportexcel,		hideexportcsv,
				hideexporttext,				hideimportdata,				hidechart,				hideexportopenoffice,
				hidepersonalize,			hidefiltercolumn,			searchhide,				autolist_not_req,
				hideselect,					AutoHeight,					IsPivot,				QlikLink,
				RangeMinimum,				RangeMaximum,				RangeStartValue,		RangeEndValue,
				RangeStep,					RangeLabel,					RangeSelect,			ValueShown,
				Style,						SystemGeneratedFileId,		IsMarquee,				IsAssorted,
				RatingType,					CaptchaData,				rangetype,				RenderAs,
				noofrowsselected_req,		AttachmentWithDesc,			preserve_gridposition,	Image_Accept_Type,
				Accept_Type,				file_Accept_Type,			MlsearchOnly,			hidecolumnchooser,
				timestamp,					
				createdby,					createddate,				modifiedby,				modifieddate	)
		SELECT DISTINCT
				customer_name,				project_name,				@engg_req_no,			process_name,
				component_name,				ctrl_type_name,				ctrl_type_descr,		base_ctrl_type,
				mandatory_flag,				visisble_flag,				editable_flag,			caption_req,
				select_flag,				zoom_req,					insert_req,				delete_req,
				help_req,					event_handling_req,			ellipses_req,			comp_ctrl_type_sysid,
				caption_alignment,			caption_position,			caption_wrap,			visisble_rows,
				ctrl_type_doc,				ctrl_position,				label_class,			ctrl_class,
				password_char,				tskimg_class,				hlpimg_class,			disponlycmb_req,
				html_txt_area,				report_req,					Auto_tab_stop,			Spin_required,
				Spin_up_image,				Spin_down_image,			InPlace_Calendar,		EditMask,
				NoofLinesPerRow,			RowHeight,					Vscrollbar_Req,			Is_Extjs_Control,
				Extjs_Ctrl_type,			gridlite_req,				bulletlink_req,			buttoncombo_req,
				associatedlist_req,			onfocustask_req,			listrefilltask_req,		attach_document,
				image_upload,				inplace_image,				listedit_noofcolumns,	image_row_height,
				relative_url_path,			relative_document_path,		relative_image_path,	save_doc_content_to_db,
				save_image_content_to_db,	dataascaption,				image_icon,				Date_highlight,
				ezee_report,				Lite_Attach_Document,		Browse_Button_Enable,	Delete_Button_Enable,
				image_row_width,			image_preview_height,		image_preview_width,	image_preview_req,
				Lite_Attach_Image,			timezone,					autoexpand,				Disp_Only_Apply_Len,
				editcombo_req,				Label_Link,					captiontype,			controlstyle,
				IsListBox,					Toolbar_Not_Req,			ColumnBorder_Not_Req,	RowBorder_Not_Req,
				PagenavigationOnly,			RowNO_Not_Req,				ButtonHome_Req,			ButtonPrevious_Req,
				Accpet_Type,				combo_link,					QR_Image,				Tooltip_Not_Req,
				Forcefit,					columncaption_Not_Req,		Border_Not_Req,			IsModal,
				Alternate_Color_Req,		Map_In_Req,					Map_Out_Req,			Barcode_Image,
				Isfallback,					config_parameter,			config_value,			upload,
				Is_Varbinary,				FileSize,					EMail,					Phone,
				StaticCaption,				Datagrid,					MoveFirst,				Move_PrevSet,
				Move_Previous,				Move_Next,					Move_NextSet,			Move_Last,
				Carousel_Req,				Orientation,				WrapCount,				Box_Type,
				ISDeviceInfo,				ListControl,				col_caption_align,		Gridheaderstyle,
				Gridtoolbarstyle,			preevent,					postevent,				norowstodisplay_notreq,
				col_data_align,				avn_download,				PreventDownload,		ishijri,
				slider_type,				max_value,					min_value,				step_value,
				spin_system_task,			enabledefault,				hideinsert,				hidedelete,
				hidecopy,					hidecut,					hidefilterdata,			hidepdf,
				hidereport,					hidehtml,					hideexportexcel,		hideexportcsv,
				hideexporttext,				hideimportdata,				hidechart,				hideexportopenoffice,
				hidepersonalize,			hidefiltercolumn,			searchhide,				autolist_not_req,
				hideselect,					AutoHeight,					IsPivot,				QlikLink,
				RangeMinimum,				RangeMaximum,				RangeStartValue,		RangeEndValue,
				RangeStep,					RangeLabel,					RangeSelect,			ValueShown,
				Style,						SystemGeneratedFileId,		IsMarquee,				IsAssorted,
				RatingType,					CaptchaData,				rangetype,				RenderAs,
				noofrowsselected_req,		AttachmentWithDesc,			preserve_gridposition,	Image_Accept_Type,
				Accept_Type,				file_Accept_Type,			MlsearchOnly,			hidecolumnchooser,
				timestamp,					
				@ctxt_user,					GETDATE(),					@ctxt_user,				GETDATE()
		FROM	es_comp_ctrl_type_mst a (NOLOCK)
		WHERE	Customer_Name		=	@customer_name_temp
		AND		Project_Name		=	@project_name_temp
		AND		Process_Name		=	@process_name_temp
		AND		Component_Name		=	@component_name_temp
		AND NOT EXISTS (	SELECT 'X'
								FROM	ep_published_comp_ctrl_type_mst b (NOLOCK)
								WHERE	b.Customer_Name		=	a.Customer_Name
								AND		b.Project_Name		=	a.Project_Name
								AND		b.Process_Name		=	a.Process_Name
								AND		b.Component_Name	=	a.Component_Name
								AND		b.ctrl_type_name	=	a.ctrl_type_name 
								
								AND		b.Customer_Name		=	@customer_name_temp
								AND		b.Project_Name		=	@project_name_temp
								AND		b.Process_Name		=	@process_name_temp
								AND		b.Component_Name	=	@component_name_temp
								AND		b.req_no			=	@engg_req_no )

	INSERT INTO ep_published_comp_ctrl_type_mst_extn
				(	customer_name,				project_name,				req_no,				process_name,
					component_name,				ctrl_type_name,				ctrl_type_descr,	base_ctrl_type,
					Configuration,				SliderType,					SliderBehaviour,	RenderType,
					Orientation,				Startvalue,					Endvalue,			Minvalue,
					Maxvalue,					Stepvalue,					SliderValue,		Showvalue,
					ShowTooltip,				Rangelabel,					Rangevalue,			Rangetooltip,
					RangeSelect,				ValueShown,					ExpandEvent,		ExpandAllEvent,
					CollapseEvent,				CollapseAllEvent,			ClickEvent,			DDToolTip,
					ZoomMin,					ZoomMax,					DefaultZoom,		ZoomStep,
					NodeWidth,					NodeHeight,					DefaultFile,		IsOrgChart,
					checkevent,					bufferedrows,				SparkChartType,		ChartType,
					Delayedpwdmask,				preserve_gridposition,		Dynamicfileupload,	ServerSidePrint,
					MultiFileSelect,			NoofCtrlPerLine,			FormWidth,			ControlWidth,
					LabelWidth,					MetaDataBasedLink,			LabelAlignment,		Scan,
					Autoselect,					IsList,						MultiSelect,		SelectedRowcount,
					DockedItem,					NFCEnabled,					AutoScan,			IsToggle,
					NodeIconReqd,				NodeCustomClass,			IsDocked,			RuleBuilder,
					MultiSelectComboforRB,		CalendarControl,			Setfocusevent,		Leavefocusevent,
					GanttControl,				AutoSync,					SetFocusEventOccurence,LeaveFocusEventOccurence,
					IsChips,					IsSpellcheck,				DirectPrint,		ListItemExpander,
					ReadOnly,					ShowTodayLine,				ShowRollupTasks,	ShowProjectLines,
					SkipWeekendsDuringDragDrop,	LockedGridWidth,			RowHeight,			BottomLabelField,
					TopLabelField,				LeftLabelField,				RightLabelField,	RollupLabelField,
					Baseline,					ScrollToDateCentered,		Zoom,				Fit,
					Export,						Highlight,					Indent,				ContextMenu,
					PopupTaskEditor,			GanttShift,					GanttExpand,		GanttInsert,
					GanttDelete,				Calendar,					IsScheduler,		ListItemType,
					IsSelectionReqdList,		RowAlwaysExpanded,			IsMobile,			PaginationReqd,
					UpdateTaskReqd,				DeleteTaskReqd,				timestamp,
					createdby,					createddate,				modifiedby,			modifieddate,
					ShowLines,					PreTask,					PostTask,			BulkDownload, 	--TECH-68066	--TECH-68067
					HideRuleHeader,				HideANDOperator,			HideOROperator,		HideNOTOperator,
					HideGroupOperator,			HideRuleOperator,			SelectOnlyListValues, 	--Code added for TECH-69624
					BrowsePreTask,				BrowsePostTask,				DeletePreTask,		DeletePostTask,
					ButtonStyle,				BadgeText,					AutoHeight, --Code added for TECH-71262 on 14July22 ends	--TECH-72114
					--Code added for TECH-73996  Starts
					EyeIconForPassword,			Signature,					KeyupSearch,				Stepper,					
					LiveClock,		 			ClearTask,					ShowAnimation,				PreventMultipleRowSelection, 
					PreviousCount)
					--Code added for TECH-73996  ends

	SELECT DISTINCT
					customer_name,				project_name,				@engg_req_no,		process_name,
					component_name,				ctrl_type_name,				ctrl_type_descr,	base_ctrl_type,
					Configuration,				SliderType,					SliderBehaviour,	RenderType,
					Orientation,				Startvalue,					Endvalue,			Minvalue,
					Maxvalue,					Stepvalue,					SliderValue,		Showvalue,
					ShowTooltip,				Rangelabel,					Rangevalue,			Rangetooltip,
					RangeSelect,				ValueShown,					ExpandEvent,		ExpandAllEvent,
					CollapseEvent,				CollapseAllEvent,			ClickEvent,			DDToolTip,
					ZoomMin,					ZoomMax,					DefaultZoom,		ZoomStep,
					NodeWidth,					NodeHeight,					DefaultFile,		IsOrgChart,
					checkevent,					bufferedrows,				SparkChartType,		ChartType,
					Delayedpwdmask,				preserve_gridposition,		Dynamicfileupload,	ServerSidePrint,
					MultiFileSelect,			NoofCtrlPerLine,			FormWidth,			ControlWidth,
					LabelWidth,					MetaDataBasedLink,			LabelAlignment,		Scan,
					Autoselect,					IsList,						MultiSelect,		SelectedRowcount,
					DockedItem,					NFCEnabled,					AutoScan,			IsToggle,
					NodeIconReqd,				NodeCustomClass,			IsDocked,			RuleBuilder,
					MultiSelectComboforRB,		CalendarControl,			Setfocusevent,		Leavefocusevent,
					GanttControl,				AutoSync,					SetFocusEventOccurence,LeaveFocusEventOccurence,
					IsChips,					IsSpellcheck,				DirectPrint,		ListItemExpander,
					ReadOnly,					ShowTodayLine,				ShowRollupTasks,	ShowProjectLines,
					SkipWeekendsDuringDragDrop,	LockedGridWidth,			RowHeight,			BottomLabelField,
					TopLabelField,				LeftLabelField,				RightLabelField,	RollupLabelField,
					Baseline,					ScrollToDateCentered,		Zoom,				Fit,
					Export,						Highlight,					Indent,				ContextMenu,
					PopupTaskEditor,			GanttShift,					GanttExpand,		GanttInsert,
					GanttDelete,				Calendar,					IsScheduler,		ListItemType,
					IsSelectionReqdList,		RowAlwaysExpanded,			IsMobile,			PaginationReqd,
					UpdateTaskReqd,				DeleteTaskReqd,				timestamp,
					@ctxt_user,					GETDATE(),					@ctxt_user,			GETDATE(),
					ShowLines,					PreTask,					PostTask,			BulkDownload,	--TECH-68066
					HideRuleHeader,				HideANDOperator,			HideOROperator,		HideNOTOperator,
					HideGroupOperator,			HideRuleOperator,			SelectOnlyListValues, 	--Code added for TECH-69624
					BrowsePreTask,				BrowsePostTask,				DeletePreTask,		DeletePostTask,
					ButtonStyle,				BadgeText,					AutoHeight,	--Code added for TECH-71262 on 14July22 ends --TECH-72114
					--Code added for TECH-73996  starts
					EyeIconForPassword,			Signature,					KeyupSearch,				Stepper,					
					LiveClock,		 			ClearTask,					ShowAnimation,				PreventMultipleRowSelection, 
					PreviousCount
					--Code added for TECH-73996  ends
			FROM	es_comp_ctrl_type_mst_extn a (NOLOCK)
			WHERE	Customer_Name		=	@customer_name_temp
			AND		Project_Name		=	@project_name_temp
			AND		Process_Name		=	@process_name_temp
			AND		Component_Name		=	@component_name_temp
			AND NOT EXISTS (	SELECT 'X'
								FROM	ep_published_comp_ctrl_type_mst_extn b (NOLOCK)
								WHERE	b.Customer_Name		=	a.Customer_Name
								AND		b.Project_Name		=	a.Project_Name
								AND		b.Process_Name		=	a.Process_Name
								AND		b.Component_Name	=	a.Component_Name
								AND		b.ctrl_type_name	=	a.ctrl_type_name 
								
								AND		b.Customer_Name		=	@customer_name_temp
								AND		b.Project_Name		=	@project_name_temp
								AND		b.Process_Name		=	@process_name_temp
								AND		b.Component_Name	=	@component_name_temp
								AND		b.req_no			=	@engg_req_no )

	INSERT INTO ep_published_comp_task_type_mst
			(	customer_name,				project_name,				req_no,				process_name,
				component_name,				task_type_name,				task_type_descr,	default_for,
				refresh_on_save,			valid_on_init,				err_handle_method,	incl_place_holder,
				cond_ml_fetch,				clr_on_page_save,			hdr_fetch_req,		ml_fet_req,
				hdr_ref_req,				hdr_check_req,				proc_sel_rows,		usr_role_map,
				trn_scope_req,				comp_task_type_sysid,		task_type_doc,		hdr_save_req,
				ml_save_req,				fprowno_req,				cbdef_req,			no_placeholder,
				data_save_req,				print_req,					task_confirmation,	Logic_Extensions,
				process_updrows,			alternate_db,				sys_proc_sel_rows,	sys_process_updrows,
				Linkasui,					Uiastrans,					MLSaveSinglesegment,sys_proc_selupd_rows,
				CurrentContextInformation,	ParentContextInformation,	ModeflagEnabled,	BulkValidation,
				timestamp,					BubbleMessage,		--TECH-75230
				createdby,					createddate,				modifiedby,			modifieddate	)
	SELECT DISTINCT
				customer_name,				project_name,				@engg_req_no,		process_name,
				component_name,				task_type_name,				task_type_descr,	default_for,
				refresh_on_save,			valid_on_init,				err_handle_method,	incl_place_holder,
				cond_ml_fetch,				clr_on_page_save,			hdr_fetch_req,		ml_fet_req,
				hdr_ref_req,				hdr_check_req,				proc_sel_rows,		usr_role_map,
				trn_scope_req,				comp_task_type_sysid,		task_type_doc,		hdr_save_req,
				ml_save_req,				fprowno_req,				cbdef_req,			no_placeholder,
				data_save_req,				print_req,					task_confirmation,	Logic_Extensions,
				process_updrows,			alternate_db,				sys_proc_sel_rows,	sys_process_updrows,
				Linkasui,					Uiastrans,					MLSaveSinglesegment,sys_proc_selupd_rows,
				CurrentContextInformation,	ParentContextInformation,	ModeflagEnabled,	BulkValidation,
				timestamp,					BubbleMessage,		--TECH-75230
				@ctxt_user,					GETDATE(),					@ctxt_user,			GETDATE()
		FROM	es_comp_task_type_mst a (NOLOCK)
		WHERE	Customer_Name		=	@customer_name_temp
		AND		Project_Name		=	@project_name_temp
		AND		Process_Name		=	@process_name_temp
		AND		Component_Name		=	@component_name_temp
		AND NOT EXISTS (	SELECT 'X'
							FROM	ep_published_comp_task_type_mst b (NOLOCK)
							WHERE	b.Customer_Name		=	a.Customer_Name
							AND		b.Project_Name		=	a.Project_Name
							AND		b.Process_Name		=	a.Process_Name
							AND		b.Component_Name	=	a.Component_Name
							AND		b.task_type_name	=	a.task_type_name 
							
							AND		b.Customer_Name		=	@customer_name_temp
							AND		b.Project_Name		=	@project_name_temp
							AND		b.Process_Name		=	@process_name_temp
							AND		b.Component_Name	=	@component_name_temp
							AND		b.req_no			=	@engg_req_no )

	--case ID TECH-66583 Ends

--code added by Feroz for spin control

--code added By feroz for Chart Tables
delete  from ep_published_chart_sample_data
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)

delete  from ep_published_chart_series
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)

delete  from ep_published_chart_header
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name  = (@ui_name_temp)



insert into ep_published_chart_header( customer_name,project_name,process_name,
component_name,activity_name,ui_name,
page_bt_synonym,section_bt_synonym,req_no,
chart_type,chart_desc,chart_title,
tooltip,datagrid,datagrid_type,
legend_title,width,height,
font,font_size,font_color,
series_legend,background_color,graphicsmode,
legend_font,legend_font_size,legend_font_color,
x_axis_title,x_series_elements,x_error_band_type,
x_error_marker_type,x_error_marker_size,x_error_marker_val,
y_axis_title,x_auto_scale,x_divisions_min,
x_divisions_max,x_units,x_cal_err_value,
y_units,x_showvalue,X_showname,
x_font,x_font_size,x_font_color,
x_con_type,x_con_color,x_con_style,
x_con_weight,x_con_wt_val,x_marker_type,
x_marker_size,x_marker_color,x_marker_size_val,
y_series_elements,y_error_band_type,y_error_marker_type,
y_error_marker_size,y_error_marker_value,y_auto_scale,
y_divisions_min,y_divisions_max,y_secondary_axis,
y_cal_err_value,y_font,y_font_size,
y_font_color,y_con_type,y_connector_color,
y_connector_style,y_con_weight,y_con_wt_val,
y_marker_type,y_marker_size,y_marker_color,
y_marker_size_val,background,override_chart_type,
x_show_err_band,y_show_err_band,created_by,
created_date,modified_by,modified_date,
x_numdivlines,y_numdivlines,canvas_color,divline_color --Code Modified for the Bug ID: PNR2.0_34035

)

Select distinct
@customer_name_temp, @project_name_temp, @process_name_temp,
@component_name_temp, @activity_name_temp, @ui_name_temp,
page_bt_synonym,  section_bt_synonym, @engg_req_no,
chart_type,chart_desc,chart_title,
tooltip,datagrid,datagrid_type,
legend_title,width,height,
font,font_size,font_color,
series_legend,background_color,graphicsmode,
legend_font,legend_font_size,legend_font_color,
x_axis_title,x_series_elements,x_error_band_type,
x_error_marker_type,x_error_marker_size,x_error_marker_val,
y_axis_title,x_auto_scale,x_divisions_min,
x_divisions_max,x_units,x_cal_err_value,
y_units,x_showvalue,X_showname,
x_font,x_font_size,x_font_color,
x_con_type,x_con_color,x_con_style,
x_con_weight,x_con_wt_val,x_marker_type,
x_marker_size,x_marker_color,x_marker_size_val,
y_series_elements,y_error_band_type,y_error_marker_type,
y_error_marker_size,y_error_marker_value,y_auto_scale,
y_divisions_min,y_divisions_max,y_secondary_axis,
y_cal_err_value,y_font,y_font_size,
y_font_color,y_con_type,y_connector_color,
y_connector_style,y_con_weight,y_con_wt_val,
y_marker_type,y_marker_size,y_marker_color,
y_marker_size_val,background,override_chart_type,
x_show_err_band,y_show_err_band,@ctxt_user,
getdate(),@ctxt_user,getdate(),x_numdivlines,y_numdivlines,canvas_color,divline_color --Code Modified for the Bug ID: PNR2.0_34035
from  ep_chart_header(nolock)
where customer_name =  (@customer_name_temp)
and project_name =  (@project_name_temp)
and process_name = (@process_name_temp)
and component_name = (@component_name_temp)
and activity_name = (@activity_name_temp)
and ui_name  = (@ui_name_temp)




insert into ep_published_chart_series( customer_name, project_name, process_name,
component_name, activity_name, ui_name,
page_bt_synonym,section_bt_synonym, req_no,
axis_id, series_id, series_name,
con_type, con_color, con_style,
con_weight, con_wt_val, marker_type,
marker_size, marker_size_val,mark_color,
error_band_type,error_marker_type,error_marker_size,
err_mark_size_val,auto_scale, divisions_min,
divisions_max, units,  x_showvalue,
x_showname, sequence, y_secondary_axis,
y_legend_caption,cal_err_value, error_bands,
created_by, created_date, modified_by,
modified_date

)
Select distinct
@customer_name_temp, @project_name_temp, @process_name_temp,
@component_name_temp, @activity_name_temp, @ui_name_temp,
page_bt_synonym,  section_bt_synonym, @engg_req_no,
axis_id,  series_id,  series_name,
con_type,  con_color,  con_style,
con_weight,  con_wt_val,  marker_type,
marker_size,  marker_size_val, mark_color,
error_band_type, error_marker_type, error_marker_size,
err_mark_size_val, auto_scale,  divisions_min,
divisions_max,  units,   x_showvalue,
x_showname,  sequence,  y_secondary_axis,
y_legend_caption,  cal_err_value,  error_bands,
@ctxt_user,  getdate(),  @ctxt_user,
getdate()

from  ep_chart_series(nolock)
where customer_name =  (@customer_name_temp)
and project_name =  (@project_name_temp)
and process_name = (@process_name_temp)
and component_name = (@component_name_temp)
and activity_name = (@activity_name_temp)
and ui_name  = (@ui_name_temp)

--Column Added For Bug_id PNR2.0_18002 Starts Here
insert into ep_published_chart_sample_data( customer_name,project_name,process_name,
component_name,activity_name,ui_name,
page_bt_synonym,section_bt_synonym,req_no,
x_series_data,y_series_id,y_value,
y_error_value,tooltip_text,created_by,
created_date,modified_by,modified_date, seq_no
)
Select distinct
@customer_name_temp, @project_name_temp, @process_name_temp,
@component_name_temp, @activity_name_temp, @ui_name_temp,
page_bt_synonym,  section_bt_synonym, @engg_req_no,
x_series_data,  y_series_id,  y_value,
y_error_value,  tooltip_text,  @ctxt_user,
getdate(),  @ctxt_user,  getdate(),seq_no
from  ep_chart_sample_data(nolock)
where customer_name =  (@customer_name_temp)
and project_name =  (@project_name_temp)
and process_name = (@process_name_temp)
and component_name = (@component_name_temp)
and activity_name = (@activity_name_temp)
and ui_name  = (@ui_name_temp)

--Column Added For Bug_id PNR2.0_18002 Ends Here
--code added for Chart Tables

-- code added for state processing by feroz starts

insert into ep_published_ui_state_dtl
(customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name,
state_id, state_descr, createdby, createddate, modifiedby, modifieddate, system_state)
select customer_name, project_name, @engg_req_no, process_name, component_name, activity_name, ui_name,
state_id, state_descr, @ctxt_user, getdate(), @ctxt_user, getdate(), system_state
from  ep_ui_state_dtl  (nolock)
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)

insert into ep_published_ui_state_section_dtl
(customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym,
state_id, section_bt_synonym, collapse, visible, enable, createdby, createddate, modifiedby, modifieddate )
select customer_name, project_name, @engg_req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym,
state_id, section_bt_synonym, collapse, visible, enable, @ctxt_user, getdate(), @ctxt_user, getdate()
from  ep_ui_state_section_dtl  (nolock)
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)
--PNR2.0_15683

insert into ep_published_ui_state_control_dtl
(customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym,
state_id, section_bt_synonym, control_bt_synonym, visible, enable, createdby, createddate, modifiedby, modifieddate)
select a.customer_name, a.project_name, @engg_req_no, a.process_name, a.component_name, a.activity_name, a.ui_name, a.page_bt_synonym,
a.state_id, a.section_bt_synonym, a.control_bt_synonym, a.visible, a.enable, @ctxt_user, getdate(), @ctxt_user, getdate()
from  ep_ui_state_control_dtl a (nolock),
ep_ui_control_dtl b (nolock),
es_comp_ctrl_type_mst c(nolock)
where a.customer_name  =  (@customer_name_temp)
and  a.project_name  =  (@project_name_temp)
and  a.process_name  = (@process_name_temp)
and  a.component_name = (@component_name_temp)
and  a.activity_name  = (@activity_name_temp)
and  a.ui_name   = (@ui_name_temp)
and     a.customer_name  =   b.customer_name
and  a.project_name  =   b.project_name
and  a.process_name  =  b.process_name
and  a.component_name =  b.component_name
and  a.activity_name  =  b.activity_name
and  a.ui_name   =  b.ui_name
and     a.page_bt_synonym =    b.page_bt_synonym
and     a.section_bt_synonym =   b.section_bt_synonym
and     a.control_bt_synonym =   b.control_bt_synonym
and   b.control_type      not like '%filler%'
and     b.customer_name  =   c.customer_name
and  b.project_name  =   c.project_name
and  b.process_name  =  c.process_name
and  b.component_name =  c.component_name
and     b.control_type     =    c.ctrl_type_name
and   c.base_ctrl_type  not in   ('line','Image')

---13852 added on 20feb2020 Starts
insert into ep_published_ui_section_refinement
(customer_name,	project_name,	req_no,	process_name,	component_name,	activity_name,	ui_name,	Formfactor,	page_bt_synonym,	
section_bt_synonym,	visible_flag,	timestamp,	createdby,	createddate	,modifiedby,	modifieddate)
select a.customer_name,	a.project_name,	@engg_req_no,	a.process_name,	a.component_name,	a.activity_name,	a.ui_name,	a.Formfactor,
a.page_bt_synonym,	a.section_bt_synonym,	a.visible_flag,	a.timestamp,	@ctxt_user,	getdate(),	@ctxt_user,	getdate()
from  ep_ui_section_refinement a (nolock)

where a.customer_name  =  (@customer_name_temp)
and  a.project_name  =  (@project_name_temp)
and  a.process_name  = (@process_name_temp)
and  a.component_name = (@component_name_temp)
and  a.activity_name  = (@activity_name_temp)
and  a.ui_name   = (@ui_name_temp)



insert into ep_published_responsive_sec_weightage
(customer_name,	project_name,	req_no,	process_name,	component_name,	activity_name,	ui_name,	Formfactor,	page_bt_synonym,
parent_section,	section_bt_synonym,	Weightage,	SectionWidth,	timestamp,	createdby,	createddate,	modifiedby,	modifieddate)
select a.customer_name,	a.project_name,	@engg_req_no,	a.process_name,	a.component_name,	a.activity_name,	a.ui_name,	a.Formfactor,
a.page_bt_synonym,	a.parent_section,	a.section_bt_synonym,	a.Weightage,	a.SectionWidth,	a.timestamp,	@ctxt_user,getdate(),	@ctxt_user,getdate()
from  ep_responsive_sec_weightage a (nolock)

where a.customer_name =  (@customer_name_temp)
and  a.project_name   =  (@project_name_temp)
and  a.process_name   = (@process_name_temp)
and  a.component_name = (@component_name_temp)
and  a.activity_name  = (@activity_name_temp)
and  a.ui_name        = (@ui_name_temp)



--13852 added on 20feb2020 End

---Added for the Defect ID TECH-45546 starts
insert into ep_published_els_query_listedit_map(
customername,	projectname,	Reqno,	processname, 	componentname,	activityname,	uiname,	ListControlSynonym,	ListControlID,
ListViewname,	QueryID,	SearchIndex,	Pagesize, createdby,	createddate,	Modifedby,modifieddate)
select m.customername,	m.projectname,		@engg_req_no,m.processname,	m.componentname,	m.activityname,	m.uiname,	m.ListControlSynonym,
m.ListControlID, m.ListViewname,	m.QueryID,	m.SearchIndex,	m.Pagesize,@ctxt_user,	getdate(),	@ctxt_user,	getdate()
from ep_els_query_listedit_map m(nolock)
where m.CustomerName  =  (@customer_name_temp)
and  m.projectname  =  (@project_name_temp)
and  m.processname  = (@process_name_temp)
and  m.componentname = (@component_name_temp)
and  m.activityname  = (@activity_name_temp)
and  m.uiname   = (@ui_name_temp)


insert into ep_published_els_query_listedit_input(
customername,	projectname,	Reqno,	processname, 	componentname,	activityname,	uiname,	ListControlSynonym,	ListControlID,
ListViewname,	QueryID,	ParameterName,	MappedSynonym, MappedControlID,	MappedViewName,	createdby,	createddate,	Modifedby,modifieddate)
select i.customername,	i.projectname,		@engg_req_no,i.processname,	i.componentname,	i.activityname,	i.uiname,	i.ListControlSynonym,
i.ListControlID, i.ListViewname,	i.QueryID,i.ParameterName,	i.MappedSynonym,	i.MappedControlID,i.MappedViewName,	@ctxt_user,	getdate(),	@ctxt_user,	getdate()
from ep_els_query_listedit_input i(nolock)
where i.CustomerName  =  (@customer_name_temp)
and  i.projectname  =  (@project_name_temp)
and  i.processname  = (@process_name_temp)
and  i.componentname = (@component_name_temp)
and  i.activityname  = (@activity_name_temp)
and  i.uiname   = (@ui_name_temp)

insert into ep_published_els_query_listedit_result(
customername,	projectname,	Reqno,	processname, 	componentname,	activityname,	uiname,	ListControlSynonym,	ListControlID,
ListViewname,	QueryID,	ResultColumnName,	MappedSynonym, MappedControlID,	MappedViewName,	ParameterCaption,Width,
IsVisible,	createdby,	createddate,	Modifedby,	modifieddate,Seqno)
select r.customername,	r.projectname,		@engg_req_no,r.processname,	r.componentname,	r.activityname,	r.uiname,	r.ListControlSynonym,
r.ListControlID, r.ListViewname,	r.QueryID,	r.ResultColumnName,	r.MappedSynonym,	r.MappedControlID,r.MappedViewName,r.ParameterCaption,r.Width,
r.IsVisible,	@ctxt_user,	getdate(),	@ctxt_user,	getdate(),r.Seqno
from ep_els_query_listedit_result r(nolock)
where r.CustomerName  =  (@customer_name_temp)
and  r.projectname  =  (@project_name_temp)
and  r.processname  = (@process_name_temp)
and  r.componentname = (@component_name_temp)
and  r.activityname  = (@activity_name_temp)
and  r.uiname   = (@ui_name_temp)

--13852 added on 13apr2020 End

--Code added for TECH-60451 Starts
	INSERT INTO ep_published_ui_grid_Extension
					(	Customer_Name,		Project_Name,		Req_No,					Process_Name,				Component_Name,
						Activity_Name,		UI_Name,			Page_BT_Synonym,		Section_BT_Synonym,			Control_ID,
						View_Name,			ParameterName,		ParameterSequence,		MappedBTSynonym,			MappedField,
						CreatedBy,			CreatedDate,		ModifiedBy,			    ModifiedDate )

	SELECT				extn.Customer_Name,	extn.Project_Name,	@engg_req_no,			extn.Process_Name,			extn.Component_Name,
						extn.Activity_Name,	extn.UI_Name,		extn.Page_BT_Synonym,	extn.Section_BT_Synonym,	extn.Control_ID,
						extn.View_Name,		extn.ParameterName,	extn.ParameterSequence,	extn.MappedBTSynonym,		extn.MappedField,
					    @ctxt_user,			getdate(),			@ctxt_user,			    getdate()
	FROM	ep_ui_grid_Extension extn (NOLOCK)
	WHERE	extn.Customer_Name	=	(@customer_name_temp)
	AND		extn.Project_Name	=	(@project_name_temp)
	AND		extn.Process_Name	=	(@process_name_temp)
	AND		extn.Component_Name	=	(@component_name_temp)
	AND		extn.Activity_Name	=	(@activity_name_temp)
	AND		extn.UI_Name		=	(@ui_name_temp)
--Code added for TECH-60451 Ends


insert into ep_published_ui_state_task_dtl
(customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym,
state_id, task_name, rt_state, focus_control, createdby, createddate, modifiedby, modifieddate )
select customer_name, project_name, @engg_req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym,
state_id, task_name, rt_state, focus_control, @ctxt_user, getdate(), @ctxt_user, getdate()
from  ep_ui_state_task_dtl (nolock)
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)

insert into ep_published_ui_state_task_mst
(customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym,
state_id, task_name, task_descr,  createdby, createddate, modifiedby, modifieddate )
select customer_name, project_name, @engg_req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym,
state_id, task_name, task_descr, @ctxt_user, getdate(), @ctxt_user, getdate()
from  ep_ui_state_task_mst (nolock)
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)

-- Code added for Extn js by Jeya -- PNR2.0_1790
insert into ep_published_ui_state_column_dtl
(customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym,
state_id, section_bt_synonym, control_bt_synonym, column_bt_synonym,  column_no, visible, createdby, createddate, modifiedby, modifieddate,enable )
select customer_name, project_name, @engg_req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym,
state_id, section_bt_synonym, control_bt_synonym, column_bt_synonym,  column_no, visible, @ctxt_user, getdate(), @ctxt_user, getdate(),enable
from  ep_ui_state_column_dtl (nolock)
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)

-- Code modification  for  PNR2.0_22275 starts

insert into ep_published_ui_state_page_dtl
(customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym,
state_id, visible, enable,  createdby, createddate, modifiedby, modifieddate , focus)
select customer_name, project_name, @engg_req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym,
state_id, visible, enable, @ctxt_user, getdate(), @ctxt_user, getdate(),focus
from  ep_ui_state_page_dtl (nolock)
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)

-- Code modification  for  PNR2.0_22275 ends

-- Code added for Extn js by Jeya -- PNR2.0_1790

-- code added for state processing by feroz ends


-- code added for Ezeeview by Jeya -- PNR2.0_1790 -- start here

delete  from ep_published_ezeeview_sp
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   req_no     = @engg_req_no
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and  ui_name   = (@ui_name_temp)

insert into ep_published_ezeeview_sp (customer_name,project_name,req_no,process_name,component_name,activity_name,
ui_name,page_bt_synonym,Link_ControlName,Target_SPName,Link_Caption,Linked_Component,Linked_Activity,Linked_ui,
timestamp,createdby,createddate,modifiedby,modifieddate,Linked_Task )
select customer_name,project_name,@engg_req_no,process_name,component_name,activity_name,
ui_name,page_bt_synonym,Link_ControlName,Target_SPName,Link_Caption,Linked_Component,Linked_Activity,Linked_ui,
timestamp,@ctxt_user,getdate(),@ctxt_user,getdate(),Linked_Task
from ep_layout_ezeeview_sp (nolock)
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)

delete  from ep_published_ezeeview_spparamlist
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   req_no     = @engg_req_no
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and  ui_name   = (@ui_name_temp)
--code modified for the caseid :PNR2.0_24424 starts
-- ep_published_ezeeview_sp
insert into ep_published_ezeeview_spparamlist (customer_name,project_name,req_no,process_name,component_name,activity_name,
ui_name,page_bt_synonym,Link_ControlName,Target_SPName,ParameterName,Mapped_Control,Link_Caption,
timestamp,createdby,createddate,modifiedby,modifieddate,control_page_name )
select customer_name,project_name,@engg_req_no,process_name,component_name,activity_name,
ui_name,page_bt_synonym,Link_ControlName,Target_SPName,ParameterName,Mapped_Control,Link_Caption,
timestamp,@ctxt_user,getdate(),@ctxt_user,getdate(),control_page_name
from ep_layout_ezeeview_spparamlist (nolock)
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)
--code modified for the caseid :PNR2.0_24424 ends

-- code added for Ezeeview by Jeya -- PNR2.0_1790 -- ends here

-- Added by Feroz For ListEdit -- start

delete from ep_published_listedit_column_dtl
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   req_no     = @engg_req_no
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp


insert into ep_published_listedit_column_dtl
(customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name,
listedit_synonym, listedit_column_synonym, listedit_column_seqno, listedit_controlid, listedit_viewname,
column_prefix, createdby, createddate,visible_length)
select
customer_name, project_name, @engg_req_no, process_name, component_name, activity_name, ui_name,
listedit_synonym, listedit_column_synonym, listedit_column_seqno, listedit_controlid, listedit_viewname,
column_prefix, @ctxt_user, @date,visible_length
from ep_listedit_column_dtl (nolock)
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   req_no     = @engg_base_req_no
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp

delete from ep_published_listedit_control_map
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   req_no     = @engg_req_no
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp


insert into ep_published_listedit_control_map
(customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym,
section_bt_synonym, mapped_bt_synonym, listedit_synonym, control_id, view_name, createdby, createddate, listedit_controlid, listedit_viewname) -- Modified By feroz for bug id :PNR2.0_23463
select
customer_name, project_name, @engg_req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym,
section_bt_synonym, mapped_bt_synonym, listedit_synonym, control_id, view_name,  @ctxt_user, @date, listedit_controlid, listedit_viewname -- Modified By feroz for bug id :PNR2.0_23463
from ep_listedit_control_map (nolock)
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   req_no     = @engg_base_req_no
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp

delete from ep_published_resolvelist_data_map
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   req_no     = @engg_req_no
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp

-- Modification for the defect id: TECH-16126
insert into ep_published_resolvelist_data_map
(customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym,
listedit_synonym, mapped_bt_synonym, listedit_column_synonym, data_mapped_synonym, primary_search_column, list_index_search, control_id,
view_name, visible, createdby, createddate,mapped_bt_syn_page,map_listdata)   --Modified for  PNR2.0_26701
select
customer_name, project_name, @engg_req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym,
listedit_synonym, mapped_bt_synonym, listedit_column_synonym, data_mapped_synonym, primary_search_column, list_index_search, control_id,
view_name, visible, @ctxt_user, @date , mapped_bt_syn_page,map_listdata        --Modified for  PNR2.0_26701
from ep_resolvelist_data_map (nolock)
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   req_no     = @engg_base_req_no
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp
--Modification for the defect id: TECH-16126

------ Insert into ep_published_ui_qrcode_dtl

--insert into ep_published_ui_qrcode_dtl
--(customer_name , project_name ,req_no  ,process_name  ,component_name  ,activity_name  ,ui_name  ,task_name  ,
--qr_image  ,control_bt_synonym  ,seqno  ,createdby ,createddate ,modifiedby ,modifieddate) 
--select
--customer_name,project_name ,@engg_req_no,process_name ,component_name ,activity_name ,ui_name ,task_name ,
--qr_image ,control_bt_synonym ,seqno ,@ctxt_user ,GETDATE() ,  @ctxt_user ,GETDATE() 
--from ep_ui_qrcode_dtl(nolock)
--where  customer_name  = @customer_name_temp
--and   project_name  = @project_name_temp
--and   req_no     = @engg_base_req_no
--and   process_name  = @process_name_temp
--and   component_name  = @component_name_temp
--and   activity_name  = @activity_name_temp
--and   ui_name   = @ui_name_temp


---- Insert into ep_published_ui_comobolink_dtl

insert into ep_published_ui_combolink_dtl
(customer_name	,project_name	,req_no	,process_name	,component_name, activity_name	,ui_name,
Combo_control_bt_synonym	,link_control_bt_synonym	,link_control_caption	,Display_seqno,
separatelink_req	,map	,createdby	,createddate	,modifiedby	,modifieddate	)
select
customer_name	,project_name	,@engg_req_no,process_name	,component_name	,
activity_name	,ui_name	,Combo_control_bt_synonym	,link_control_bt_synonym	,link_control_caption	,Display_seqno,
separatelink_req	,map	,@ctxt_user	,GETDATE()	,@ctxt_user	,GETDATE()	
from ep_ui_combolink_dtl(nolock)
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and  activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp

---- Insert into ep_published_user_section_dtl
delete
from ep_published_user_section_dtl
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   reqno     = @engg_req_no
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp

insert into ep_published_user_section_dtl
(customer_name,project_name,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,
type,include_text,include_value,languageid,reqno,createdby,createddate,modifiedby,modifieddate)
Select 
customer_name,project_name,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,
type,include_text,include_value,languageid,@engg_req_no,@ctxt_user,GETDATE(),@ctxt_user,GETDATE()
from ep_user_section_dtl(nolock)
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp

---Insertion for device table starts

insert into ep_published_ui_device_control_dtl
(customer_name,attributename,project_name,req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,
control_bt_synonym,attributevalue,createdby,createddate,modifiedby,modifieddate,controlid,viewname)
Select 
customer_name,attributename,project_name,@engg_req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,
attributevalue,@ctxt_user,GETDATE(),@ctxt_user,GETDATE(),control_id,view_name 
from ep_ui_device_control_dtl(nolock)
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   req_no    =  (@engg_base_req_no)
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp

insert into ep_published_ui_device_page_dtl(customer_name,project_name,req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,
attributename,attributevalue,createdby,createddate,modifiedby,modifieddate)
Select customer_name,project_name,@engg_req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,
attributename,attributevalue,@ctxt_user,GETDATE(),@ctxt_user,GETDATE() 
from ep_ui_device_page_dtl(nolock)
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   req_no    =  (@engg_base_req_no)
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp

insert into ep_published_ui_device_section_dtl(customer_name,project_name,req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,
attributename,attributevalue,createdby,createddate,modifiedby,modifieddate)
Select customer_name,project_name,@engg_req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,
attributename,attributevalue,@ctxt_user,GETDATE(),@ctxt_user,GETDATE() 
from ep_ui_device_section_dtl(nolock)
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and req_no    =  (@engg_base_req_no)
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp

insert into ep_published_ui_device_grid_dtl(customer_name,project_name,req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,column_bt_synonym,
attributename,attributevalue,createdby,createddate,modifiedby,modifieddate,controlid,viewname)
Select customer_name,project_name,@engg_req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,column_bt_synonym,
attributename,attributevalue,@ctxt_user,GETDATE(),@ctxt_user,GETDATE() ,control_id,view_name
from ep_ui_device_grid_dtl(nolock)
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and req_no    =  (@engg_base_req_no)
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp

insert into ep_published_ui_device_dtl
(customer_name,project_name,req_no,process_name,component_name,activity_name,ui_name,attributename,attributevalue,
createdby,createddate,modifiedby,modifieddate
)
Select 
customer_name,project_name,@engg_req_no,process_name,component_name,activity_name,ui_name,attributename,attributevalue,
@ctxt_user,GETDATE(),@ctxt_user,GETDATE() 
from ep_ui_device_dtl(nolock)
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and req_no    =  (@engg_base_req_no)
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp

---Insertion for device table ends
/*
--ep_published_ui_section_control_map_dtl
delete from ep_published_ui_section_control_map_dtl
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   req_no     = @engg_req_no
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp

insert into ep_published_ui_section_control_map_dtl
(customer_name,project_name,req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym
,control_bt_synonym,control_id,view_name,createdby,createddate,modifiedby,modifieddate)
Select 
customer_name,project_name,@engg_req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym
,control_bt_synonym,control_id,view_name,@ctxt_user,GETDATE(),@ctxt_user,GETDATE() 
from ep_ui_section_control_map_dtl(nolock)
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and req_no    =  (@engg_base_req_no)
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp
----
*/
-- insertion into placeholder and tooltip tables
delete from ep_published_ui_tooltip_dtl_lng_extn
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   req_no     = @engg_req_no
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp

insert into ep_published_ui_tooltip_dtl_lng_extn
(customer_name,project_name,req_no,process_name,component_name,activity_name,ui_name,
page_bt_synonym,section_bt_synonym,control_bt_synonym,column_bt_synonym,control_id,
view_name,languageid,tooltip,timestamp,createdby,createddate,modifiedby,modifieddate)
Select 
customer_name,project_name,@engg_req_no,process_name,component_name,activity_name,ui_name,
page_bt_synonym,section_bt_synonym,control_bt_synonym,column_bt_synonym,control_id,
view_name,languageid,tooltip,timestamp,@ctxt_user,GETDATE(),@ctxt_user,GETDATE() 
from ep_ui_tooltip_dtl_lng_extn(nolock)
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and	  req_no    =  (@engg_base_req_no)
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp

delete from ep_published_ui_placeholder_dtl_lng_extn
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   req_no     = @engg_req_no
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp

insert into ep_published_ui_placeholder_dtl_lng_extn
(customer_name,project_name,req_no,process_name,component_name,activity_name,ui_name,control_bt_synonym,
control_id,view_name,languageid,placeholder,timestamp,createdby,createddate,modifiedby,modifieddate)
Select 
customer_name,project_name,@engg_req_no,process_name,component_name,activity_name,ui_name,control_bt_synonym
,control_id,view_name,languageid,placeholder,timestamp,@ctxt_user,GETDATE(),@ctxt_user,GETDATE() 
from ep_ui_placeholder_dtl_lng_extn(nolock)
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and req_no    =  (@engg_base_req_no)
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp
---------QlikLinks  PLF2.0_16291 
delete from ep_published_ui_control_association_map
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   req_no     = @engg_req_no
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp

insert into ep_published_ui_control_association_map
(customer_name	, project_name	, req_no, process_name	, component_name	, activity_name	,
 ui_name,	page_bt_synonym	, section_bt_synonym, Control_id,view_name, propertyname, propertycontrol,property_controlid,property_viewname
 ,createdby,createddate,modifiedby,modifieddate	)
Select 
customer_name	, project_name	, @engg_req_no, process_name	, component_name	, activity_name	,
 ui_name, page_bt_synonym	, section_bt_synonym, Control_id,view_name, propertyname, propertycontrol	,property_controlid,property_viewname,
@ctxt_user,GETDATE(),@ctxt_user,GETDATE() 
from	ep_ui_control_association_map(nolock)
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   req_no     = @engg_base_req_no
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp
---------
-- code added for PLF2.0_16291  starts
delete from ep_published_pivot_configure
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   req_no     = @engg_req_no
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp

insert into ep_published_pivot_configure
(customer_name,project_name,process_name,component_name,activity_name,ui_name,page_name,Control_bt_synonym,configpan_pos,rowgrandtot_pos,rowsubtot_pos
,colgrandtot_pos,colsubtot_pos,rowgrandtot_text,colgrandtot_text,rowsubtot_text,colsubtot_text,timestamp,createdby,createddate,modifiedby,modifieddate
,req_no)
Select 
customer_name,project_name,process_name,component_name,activity_name,ui_name,page_name,Control_bt_synonym,configpan_pos,rowgrandtot_pos,rowsubtot_pos
,colgrandtot_pos,colsubtot_pos,rowgrandtot_text,colgrandtot_text,rowsubtot_text,colsubtot_text,timestamp,@ctxt_user,GETDATE(),@ctxt_user,GETDATE() 
,@engg_req_no
from ep_pivot_configure(nolock)
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   req_no     = @engg_base_req_no
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp

delete from ep_published_pivot_fields
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   req_no     = @engg_req_no
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp

insert into ep_published_pivot_fields
(customer_name,project_name,process_name,component_name,activity_name,ui_name,page_name,Control_bt_synonym,column_bt_synonym,rowlabel,columnlabel,
fieldValue,rowlabelseq,columnlabelseq,valueseq,ValueFunction,rowlabelsorting,columnlabelsorting,timestamp,createdby,createddate,modifiedby,modifieddate,
req_no)
Select 
customer_name,project_name,process_name,component_name,activity_name,ui_name,page_name,Control_bt_synonym,column_bt_synonym,rowlabel,columnlabel,
fieldValue,rowlabelseq,columnlabelseq,valueseq,ValueFunction,rowlabelsorting,columnlabelsorting,timestamp,@ctxt_user,GETDATE(),@ctxt_user,GETDATE() 
,@engg_req_no
from ep_pivot_fields(nolock)
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   req_no     = @engg_base_req_no
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp

delete from ep_published_pivot_lang_extn
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   req_no     = @engg_req_no
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp

insert into ep_published_pivot_lang_extn
(customer_name,project_name,process_name,component_name,activity_name,ui_name,page_name,Control_bt_synonym,DisplayField,Languageid,
DisplayText,timestamp,createdby,createddate,modifiedby,modifieddate,req_no)
Select 
customer_name,project_name,process_name,component_name,activity_name,ui_name,page_name,Control_bt_synonym,DisplayField,Languageid,
DisplayText,timestamp,@ctxt_user,GETDATE(),@ctxt_user,GETDATE(),@engg_req_no
from ep_pivot_lang_extn(nolock)
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   req_no     = @engg_base_req_no
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp

-- code added for PLF2.0_16291  ends
----
-----Phone and Tablet Table Starts
delete from ep_published_phone_mst
where	customer_name	= @customer_name_temp
and		project_name	= @project_name_temp
and		process_name	= @process_name_temp
and		component_name  = @component_name_temp
and		activity_name	= @activity_name_temp
and		ui_name			= @ui_name_temp

insert into ep_published_phone_mst
(customer_name,project_name,req_no,process_name,component_name,activity_name,ui_name,ui_descr,ui_type,ui_format,tab_height,TabStyle,timestamp,
createdby,createddate,modifiedby,modifieddate,Layout,XYCoordinates,ColumnLayWidth,TabHeaderPostion,TabRotation)
Select 
customer_name,project_name,@engg_req_no,process_name,component_name,activity_name,ui_name,ui_descr,ui_type,ui_format,tab_height,TabStyle,timestamp,
@ctxt_user,GETDATE(),@ctxt_user,GETDATE() ,Layout,XYCoordinates,ColumnLayWidth,TabHeaderPostion,TabRotation
from ep_phone_mst(nolock)
where	customer_name	= @customer_name_temp
and		project_name	= @project_name_temp
and		process_name	= @process_name_temp
and		component_name  = @component_name_temp
and		activity_name	= @activity_name_temp
and		ui_name			= @ui_name_temp


delete from ep_published_tablet_mst
where	customer_name	= @customer_name_temp
and		project_name	= @project_name_temp
and		process_name	= @process_name_temp
and		component_name  = @component_name_temp
and		activity_name	= @activity_name_temp
and		ui_name			= @ui_name_temp


insert into ep_published_tablet_mst
(customer_name,project_name,req_no,process_name,component_name,activity_name,ui_name,ui_descr,ui_type,ui_format,tab_height,TabStyle,timestamp,
createdby,createddate,modifiedby,modifieddate,Layout,XYCoordinates,ColumnLayWidth,TabHeaderPostion,TabRotation)
Select 
customer_name,project_name,@engg_req_no,process_name,component_name,activity_name,ui_name,ui_descr,ui_type,ui_format,tab_height,TabStyle,timestamp,
@ctxt_user,GETDATE(),@ctxt_user,GETDATE() ,Layout,XYCoordinates,ColumnLayWidth,TabHeaderPostion,TabRotation
from ep_tablet_mst(nolock)
where	customer_name	= @customer_name_temp
and		project_name	= @project_name_temp
and		process_name	= @process_name_temp
and		component_name  = @component_name_temp
and		activity_name	= @activity_name_temp
and		ui_name			= @ui_name_temp


delete from ep_published_phone_page_dtl
where	customer_name	= @customer_name_temp
and		project_name	= @project_name_temp
and		process_name	= @process_name_temp
and		component_name  = @component_name_temp
and		activity_name	= @activity_name_temp
and		ui_name			= @ui_name_temp

insert into ep_published_phone_page_dtl
(customer_name,project_name,req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,horder,vorder,HeaderPosition,TabRotation
,TabTitleStyle,TabIconPosition,PageLayout,XYCoordinates,ColumnLayWidth,timestamp,createdby,createddate,modifiedby,modifieddate,PageClass)
Select 
customer_name,project_name,@engg_req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,horder,vorder,HeaderPosition,TabRotation
,TabTitleStyle,TabIconPosition,PageLayout,XYCoordinates,ColumnLayWidth,timestamp,@ctxt_user,GETDATE(),@ctxt_user,GETDATE() ,PageClass
from ep_phone_page_dtl(nolock)
where	customer_name	= @customer_name_temp
and		project_name	= @project_name_temp
and		process_name	= @process_name_temp
and		component_name  = @component_name_temp
and		activity_name	= @activity_name_temp
and		ui_name			= @ui_name_temp

delete from ep_published_tablet_page_dtl
where	customer_name	= @customer_name_temp
and		project_name	= @project_name_temp
and		process_name	= @process_name_temp
and		component_name  = @component_name_temp
and		activity_name	= @activity_name_temp
and		ui_name			= @ui_name_temp

insert into ep_published_tablet_page_dtl
(customer_name,project_name,req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,horder,vorder,HeaderPosition,TabRotation
,TabTitleStyle,TabIconPosition,PageLayout,XYCoordinates,ColumnLayWidth,timestamp,createdby,createddate,modifiedby,modifieddate,PageClass)
Select 
customer_name,project_name,@engg_req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,horder,vorder,HeaderPosition,TabRotation
,TabTitleStyle,TabIconPosition,PageLayout,XYCoordinates,ColumnLayWidth,timestamp,@ctxt_user,GETDATE(),@ctxt_user,GETDATE() ,PageClass
from ep_tablet_page_dtl(nolock)
where	customer_name	= @customer_name_temp
and		project_name	= @project_name_temp
and		process_name	= @process_name_temp
and		component_name  = @component_name_temp
and		activity_name	= @activity_name_temp
and		ui_name			= @ui_name_temp

delete from ep_published_phone_section_dtl
where	customer_name	= @customer_name_temp
and		project_name	= @project_name_temp
and		process_name	= @process_name_temp
and		component_name  = @component_name_temp
and		activity_name	= @activity_name_temp
and		ui_name			= @ui_name_temp

insert into ep_published_phone_section_dtl
(customer_name,project_name,req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,section_type,title_required,
border_required,title_alignment,parent_section,horder,vorder,width,height,ctrl_caption_align,caption_Format,Section_width_Scalemode,Section_height_Scalemode,
SectionPrefixClass,Region,TitlePosition,CollapseDir,SectionLayout,XYCoordinates,ColumnLayWidth,timestamp,createdby,createddate,modifiedby,modifieddate)
Select 
customer_name,project_name,@engg_req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,section_type,title_required,
border_required,title_alignment,parent_section,horder,vorder,width,height,ctrl_caption_align,caption_Format,Section_width_Scalemode,Section_height_Scalemode,
SectionPrefixClass,Region,TitlePosition,CollapseDir,SectionLayout,XYCoordinates,ColumnLayWidth,timestamp,@ctxt_user,GETDATE(),@ctxt_user,GETDATE() 
from	ep_phone_section_dtl(nolock)
where	customer_name	= @customer_name_temp
and		project_name	= @project_name_temp
and		process_name	= @process_name_temp
and		component_name  = @component_name_temp
and		activity_name	= @activity_name_temp
and		ui_name			= @ui_name_temp

delete from ep_published_tablet_section_dtl
where	customer_name	= @customer_name_temp
and		project_name	= @project_name_temp
and		process_name	= @process_name_temp
and		component_name  = @component_name_temp
and		activity_name	= @activity_name_temp
and		ui_name			= @ui_name_temp

insert into ep_published_tablet_section_dtl
(customer_name,project_name,req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,section_type,title_required,
border_required,title_alignment,parent_section,horder,vorder,width,height,ctrl_caption_align,caption_Format,Section_width_Scalemode,Section_height_Scalemode,
SectionPrefixClass,Region,TitlePosition,CollapseDir,SectionLayout,XYCoordinates,ColumnLayWidth,timestamp,createdby,createddate,modifiedby,modifieddate)
Select 
customer_name,project_name,@engg_req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,section_type,title_required,
border_required,title_alignment,parent_section,horder,vorder,width,height,ctrl_caption_align,caption_Format,Section_width_Scalemode,Section_height_Scalemode,
SectionPrefixClass,Region,TitlePosition,CollapseDir,SectionLayout,XYCoordinates,ColumnLayWidth,timestamp,@ctxt_user,GETDATE(),@ctxt_user,GETDATE() 
from	ep_tablet_section_dtl(nolock)
where	customer_name	= @customer_name_temp
and		project_name	= @project_name_temp
and		process_name	= @process_name_temp
and		component_name  = @component_name_temp
and		activity_name	= @activity_name_temp
and		ui_name			= @ui_name_temp


delete from ep_published_phone_control_dtl
where	customer_name	= @customer_name_temp
and		project_name	= @project_name_temp
and		process_name	= @process_name_temp
and		component_name  = @component_name_temp
and		activity_name	= @activity_name_temp
and		ui_name			= @ui_name_temp

insert into ep_published_phone_control_dtl
(customer_name,project_name,req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,control_type,
horder,vorder,order_seq,data_column_width,label_column_width,label_column_scalemode,data_column_scalemode,control_id,view_name,visible_length,sample_data,LabelClass,ControlClass,freezecount,
TemplateID,timestamp,createdby,createddate,modifiedby,modifieddate,TemplateCategory,TemplateSpecific,Control_class_ext6)
Select 
customer_name,project_name,@engg_req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,control_type,
horder,vorder,order_seq,data_column_width,label_column_width,label_column_scalemode,data_column_scalemode,control_id,view_name,visible_length,sample_data,LabelClass,ControlClass,freezecount,
TemplateID,timestamp,@ctxt_user,GETDATE(),@ctxt_user,GETDATE()	,TemplateCategory,TemplateSpecific,Control_class_ext6
from ep_phone_control_dtl(nolock)
where	customer_name	= @customer_name_temp
and		project_name	= @project_name_temp
and		process_name	= @process_name_temp
and		component_name  = @component_name_temp
and		activity_name	= @activity_name_temp
and		ui_name			= @ui_name_temp

delete from ep_published_tablet_control_dtl
where	customer_name	= @customer_name_temp
and		project_name	= @project_name_temp
and		process_name	= @process_name_temp
and		component_name  = @component_name_temp
and		activity_name	= @activity_name_temp
and		ui_name			= @ui_name_temp

insert into ep_published_tablet_control_dtl
(customer_name,project_name,req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,control_type,
horder,vorder,order_seq,data_column_width,label_column_width,control_id,view_name,visible_length,sample_data,LabelClass,ControlClass,freezecount,
TemplateID,timestamp,createdby,createddate,modifiedby,modifieddate,label_column_scalemode,data_column_scalemode,TemplateCategory,TemplateSpecific,Control_class_ext6)
Select 
customer_name,project_name,@engg_req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,control_type,
horder,vorder,order_seq,data_column_width,label_column_width,control_id,view_name,visible_length,sample_data,LabelClass,ControlClass,freezecount,
TemplateID,timestamp,@ctxt_user,GETDATE(),@ctxt_user,GETDATE() ,label_column_scalemode,data_column_scalemode,TemplateCategory,TemplateSpecific,Control_class_ext6
from ep_tablet_control_dtl(nolock)
where	customer_name	= @customer_name_temp
and		project_name	= @project_name_temp
and		process_name	= @process_name_temp
and		component_name  = @component_name_temp
and		activity_name	= @activity_name_temp
and		ui_name			= @ui_name_temp

delete from ep_published_phone_grid_dtl
where	customer_name	= @customer_name_temp
and		project_name	= @project_name_temp
and		process_name	= @process_name_temp
and		component_name  = @component_name_temp
and		activity_name	= @activity_name_temp
and		ui_name			= @ui_name_temp

insert into ep_published_phone_grid_dtl
(customer_name,project_name,req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,
column_bt_synonym,column_type,column_no,control_id,view_name,visible_length,sample_data,ColumnClass,TemplateID,timestamp,createdby,createddate
,modifiedby,modifieddate,TemplateCategory,TemplateSpecific,Column_class_ext6)
Select 
customer_name,project_name,@engg_req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,
column_bt_synonym,column_type,column_no,control_id,view_name,visible_length,sample_data,ColumnClass,TemplateID,timestamp,@ctxt_user,GETDATE(),
@ctxt_user,GETDATE() ,TemplateCategory,TemplateSpecific,Column_class_ext6
from	ep_phone_grid_dtl(nolock)
where	customer_name	= @customer_name_temp
and		project_name	= @project_name_temp
and		process_name	= @process_name_temp
and		component_name  = @component_name_temp
and		activity_name	= @activity_name_temp
and		ui_name			= @ui_name_temp

delete from ep_published_tablet_grid_dtl
where	customer_name	= @customer_name_temp
and		project_name	= @project_name_temp
and		process_name	= @process_name_temp
and		component_name  = @component_name_temp
and		activity_name	= @activity_name_temp
and		ui_name			= @ui_name_temp

insert into ep_published_tablet_grid_dtl
(customer_name,project_name,req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,
column_bt_synonym,column_type,column_no,control_id,view_name,visible_length,sample_data,ColumnClass,TemplateID,timestamp,createdby,createddate
,modifiedby,modifieddate,TemplateCategory,TemplateSpecific,Column_class_ext6)
Select 
customer_name,project_name,@engg_req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,
column_bt_synonym,column_type,column_no,control_id,view_name,visible_length,sample_data,ColumnClass,TemplateID,timestamp,@ctxt_user,GETDATE(),
@ctxt_user,GETDATE() ,TemplateCategory,TemplateSpecific,Column_class_ext6
from	ep_tablet_grid_dtl(nolock)
where	customer_name	= @customer_name_temp
and		project_name	= @project_name_temp
and		process_name	= @process_name_temp
and		component_name  = @component_name_temp
and		activity_name	= @activity_name_temp	
and		ui_name			= @ui_name_temp

-----Phone and Tablet Table Ends

delete from ep_published_date_highlight_control_map
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   req_no     = @engg_req_no
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp

insert into ep_published_date_highlight_control_map
(customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym,
control_bt_synonym, listedit_synonym, controlid, viewname, listedit_controlid, listedit_viewname, createdby, createddate)
select
customer_name, project_name, @engg_req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym,
control_bt_synonym, listedit_synonym, controlid, viewname, listedit_controlid, listedit_viewname, @ctxt_user, @date
from ep_date_highlight_control_map (nolock)
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   req_no     = @engg_base_req_no
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp
---  specify template changes
insert into ep_published_ui_Temp_placeholders
(customer_name,project_name,process_name,component_name,activity_name,ui_name,page_bt_synonym,Control_bt_synonym,section_bt_synonym,templateid,control_id,view_name,
createdby,createddate,modifiedby,modifieddate,req_no,placeholder,associatedColumn,associatedevent)
Select 
customer_name,project_name,process_name,component_name,activity_name,ui_name,page_bt_synonym,Control_bt_synonym,section_bt_synonym,templateid,control_id,view_name,
@ctxt_user,getdate(),@ctxt_user,getdate(),@engg_req_no,placeholder,associatedColumn,associatedevent
from ep_ui_Temp_placeholders(nolock)
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   req_no     = @engg_base_req_no
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp

insert into ep_published_ui_template_controlmap
(activity_name,customer_name,project_name,process_name,component_name,ui_name,page_bt_synonym,Control_bt_synonym,section_bt_synonym,templateid,control_id,view_name,createdby,createddate,modifiedby,modifieddate,req_no)
Select 
activity_name,customer_name,project_name,process_name,component_name,ui_name,page_bt_synonym,Control_bt_synonym,section_bt_synonym,templateid,control_id,view_name,@ctxt_user,getdate(),@ctxt_user,getdate(),@engg_req_no
from ep_ui_template_controlmap(nolock)
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   req_no     = @engg_base_req_no
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp

--- specify template changes ends

-- Added by Feroz For ListEdit -- End
-- Added By Feroz For UI ToolBar -- Start
			delete from	ep_published_ui_toolbar_group_dtl
			where 	customer_name 	= @customer_name_temp
			and  	project_name 	= @project_name_temp
			and  	req_no   		= @engg_req_no
			and  	process_name 	= @process_name_temp
			and  	component_name 	= @component_name_temp
			and  	activity_name 	= @activity_name_temp
			and  	ui_name   		= @ui_name_temp	

			delete from	ep_published_ui_toolbar_dtl
			where 	customer_name 	= @customer_name_temp
			and  	project_name 	= @project_name_temp
			and  	req_no   		= @engg_req_no
			and  	process_name 	= @process_name_temp
			and  	component_name 	= @component_name_temp
			and  	activity_name 	= @activity_name_temp
			and  	ui_name   		= @ui_name_temp	

			delete from	ep_published_ui_displaytext_lang_extn
			where 	customer_name 	= @customer_name_temp
			and  	project_name 	= @project_name_temp
			and  	req_no   		= @engg_req_no
			and  	process_name 	= @process_name_temp
			and  	component_name 	= @component_name_temp
			and  	activity_name 	= @activity_name_temp
			and  	ui_name   		= @ui_name_temp	

			delete from	ep_published_ui_toolbar_mapping_dtl
			where 	customer_name 	= @customer_name_temp
			and  	project_name 	= @project_name_temp
			and  	req_no   		= @engg_req_no
			and  	process_name 	= @process_name_temp
			and  	component_name 	= @component_name_temp
			and  	activity_name 	= @activity_name_temp
			and  	ui_name   		= @ui_name_temp	

			insert into ep_published_ui_toolbar_group_dtl
			(customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, group_name, group_descr, createddate, createdby,
			modifieddate, modifiedby, Orientation)
			select 
			customer_name, project_name, @engg_req_no, process_name, component_name, activity_name, ui_name, group_name, group_descr, @date, @ctxt_user,
			@date, @ctxt_user, Orientation
			from	ep_ui_toolbar_group_dtl (nolock)
			where 	customer_name 	= @customer_name_temp
			and  	project_name 	= @project_name_temp
			and  	req_no   		= @engg_base_req_no
			and  	process_name 	= @process_name_temp
			and  	component_name 	= @component_name_temp
			and  	activity_name 	= @activity_name_temp
			and  	ui_name   		= @ui_name_temp	

			insert into ep_published_ui_toolbar_dtl
			(customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, group_name, group_task_name, task_seqno, class_name,
			display_text, createddate, createdby, modifieddate, modifiedby, group_task_desc,group_node_task)
			select 
			customer_name, project_name, @engg_req_no, process_name, component_name, activity_name, ui_name, group_name, group_task_name, task_seqno, class_name,
			display_text, @date, @ctxt_user, @date, @ctxt_user, group_task_desc,group_node_task
			from	ep_ui_toolbar_dtl (nolock)
			where 	customer_name 	= @customer_name_temp
			and  	project_name 	= @project_name_temp
			and  	req_no   		= @engg_base_req_no
			and  	process_name 	= @process_name_temp
			and  	component_name 	= @component_name_temp
			and  	activity_name 	= @activity_name_temp
			and  	ui_name   		= @ui_name_temp	

			insert into ep_published_ui_displaytext_lang_extn
			(customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, group_task_name, display_text, lang_id, createddate, createdby,group_name)
			select 
			customer_name, project_name, @engg_req_no, process_name, component_name, activity_name, ui_name, group_task_name, display_text, lang_id,  @date, @ctxt_user,group_name
			from ep_ui_displaytext_lang_extn (nolock)
			where 	customer_name 	= @customer_name_temp
			and  	project_name 	= @project_name_temp
			and  	req_no   		= @engg_base_req_no
			and  	process_name 	= @process_name_temp
			and  	component_name 	= @component_name_temp
			and  	activity_name 	= @activity_name_temp
			and  	ui_name   		= @ui_name_temp	

			insert into ep_published_ui_toolbar_mapping_dtl
			(customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, toolbar_id, group_task_name, display_seqno, class_name,
			display_text, caption_req, control_req, createddate, createdby, modifieddate, modifiedby)
			select
			customer_name, project_name, @engg_req_no, process_name, component_name, activity_name, ui_name, toolbar_id, group_task_name, display_seqno, class_name,
			display_text, caption_req, control_req, @date, @ctxt_user, @date, @ctxt_user
			from	ep_ui_toolbar_mapping_dtl (nolock)
			where 	customer_name 	= @customer_name_temp
			and  	project_name 	= @project_name_temp
			and  	req_no   		= @engg_base_req_no
			and  	process_name 	= @process_name_temp
			and  	component_name 	= @component_name_temp
			and  	activity_name 	= @activity_name_temp
			and  	ui_name   		= @ui_name_temp	
-- Added By Feroz For UI ToolBar -- End

-- Added by Jeya For Dynamic Section -- start
delete from ep_published_dynamic_sec_control_map
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and   req_no     = @engg_req_no
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp


insert into ep_published_dynamic_sec_control_map
(customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name,
page_bt_synonym, section_bt_synonym, control_bt_synonym, controlid, viewname, createdby, createddate)
select
customer_name, project_name, @engg_req_no, process_name, component_name, activity_name, ui_name,
page_bt_synonym, section_bt_synonym, control_bt_synonym, controlid, viewname, @ctxt_user, @date
from ep_dynamic_sec_control_map  (nolock)
where  customer_name  = @customer_name_temp
and   project_name  = @project_name_temp
and  req_no     = @engg_base_req_no
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp

-- Added by Jeya For Dynamic Section -- End

--- Below code added for Sync View by Ganesh Prabhu

delete from ep_published_sync_view
where  customer_name = @customer_name_temp
and   project_name  = @project_name_temp
and   req_no     = @engg_req_no
and   process_name  = @process_name_temp
and   component_name  = @component_name_temp
and   activity_name  = @activity_name_temp
and   ui_name     = @ui_name_temp




insert into ep_published_sync_view
(Customer_name,Project_name,req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,legrid_control_bt_syonym,legrid_control_id,
legrid_view_name,map_le_synonym,map_le_column_synonym,map_le_controlid,map_le_viewname,map_legrid_view_name,createdby,created_date,modifieddate,modifiedby,
legrid_column_bt_synonym,map_legrid_column_bt_synonym)
select
Customer_name,Project_name,@engg_req_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,legrid_control_bt_syonym,legrid_control_id,
legrid_view_name,map_le_synonym,map_le_column_synonym,map_le_controlid,map_le_viewname,map_legrid_view_name,@ctxt_user,getdate(),getdate(),@ctxt_user,
legrid_column_bt_synonym,map_legrid_column_bt_synonym
from ep_sync_view (nolock)
where  customer_name	= @customer_name_temp
and   project_name		= @project_name_temp
and   req_no			= @engg_base_req_no
and   process_name		= @process_name_temp
and   component_name	= @component_name_temp
and   activity_name		= @activity_name_temp
and   ui_name			= @ui_name_temp

-- COde modified Ends by Ganesh Prabhu 

-- Added for TECH-36371

DELETE FROM ep_published_nativeapp_mapping
WHERE customer_name		= @customer_name_temp
AND   project_name		= @project_name_temp
AND   req_no			= @engg_req_no
AND   process_name		= @process_name_temp
AND   component_name	= @component_name_temp
AND   activity_name		= @activity_name_temp
AND   ui_name			= @ui_name_temp


INSERT INTO ep_published_nativeapp_mapping
(	customer_name,		project_name,		req_no,				process_name,				component_name,				activity_name,
	ui_name,			page_bt_synonym,	section_bt_synonym,	control_Hidden_bt_synonym,	MappedGridColumnSynonym,	control_hiddenview,
	control_id,			view_name,			GridControlID,		GridViewName,				timestamp,					createdby,					
	createddate,		modifiedby,			modifieddate		
)
SELECT
	customer_name,		project_name,		@engg_req_no,		process_name,				component_name,				activity_name,
	ui_name,			page_bt_synonym,	section_bt_synonym,	control_Hidden_bt_synonym,	MappedGridColumnSynonym,	control_hiddenview,	
	control_id,			view_name,			GridControlID,		GridViewName,				@timestamp_tmp,				@ctxt_user,					
	getdate(),			@ctxt_user,			getdate()
FROM	ep_nativeapp_mapping WITH(NOLOCK)
where customer_name		= @customer_name_temp
and   project_name		= @project_name_temp
and   req_no			= @engg_base_req_no
and   process_name		= @process_name_temp
and   component_name	= @component_name_temp
and   activity_name		= @activity_name_temp
and   ui_name			= @ui_name_temp

-- code modified by Ganesh for the callid :: PNR2.0_3386 on 01/08/05
-- code modified by shafina on 28-July-2004 for PREVIEWENG203ACC_000081
/*
update ep_published_action_mst
set  status_flag = 'S',
modifiedby = @ctxt_user,
modifieddate = @date
from ep_published_action_mst a,
fw_bpt_ui_task_preview_vw b
where customer_name =  (@customer_name_temp)
and project_name =  (@project_name_temp)
and req_no  =  (@engg_req_no)
and process_name = (@process_name_temp)
and component_name = (@component_name_temp)
and activity_name = (@activity_name_temp)
and ui_name  = (@ui_name_temp)
and a.customer_name = b.customerid
and a.project_name = b.projectid
and a.process_name = b.bpid
and a.component_name= b.componentname
and a.activity_name = b.activityid
and a.ui_name = b.uiid
and a.task_name = b.taskid

update ep_published_action_mst
set  status_flag    = 'I',
modifiedby    = @ctxt_user,
modifieddate   = @date
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)
and  task_name  not in (select taskid
from fw_bpt_ui_task_preview_vw b(nolock)
where customerid  =  (@customer_name_temp)
and  projectid  =  (@project_name_temp)
and  bpid   = (@process_name_temp)
and  componentname = (@component_name_temp)
and  activityid  = (@activity_name_temp)
and  uiid   = (@ui_name_temp))
*/
--code modified for the caseid :PNR2.0_26475 ends
insert into ep_deleted_task_dtl
(
customer_name,  project_name,  req_no,    process_name, component_name,
activity_name,  ui_name,   task_name,   task_descr,  timestamp,
createdby,   createddate,  modifiedby,   modifieddate
)
select
customerid,   projectid,   @engg_req_no,  bpid,   componentname,
activityid,   uiid,    taskid,    taskdesc,  1,
@ctxt_user,   @date,   @ctxt_user,   @date
from fw_bpt_ui_task_preview_vw b (nolock)
where customerid  =  (@customer_name_temp)
and  projectid  =  (@project_name_temp)
and  bpid   = (@process_name_temp)
and  componentname = (@component_name_temp)
and  activityid  = (@activity_name_temp)
and  uiid   = (@ui_name_temp)
and taskid   not in (select task_name
from ep_published_action_mst (nolock)
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp))
-- code modified by shafina on 29-July-2004 for PREVIEWENG203ACC_000082
and  taskid   not in (select task_name
from ep_deleted_task_dtl (nolock)
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp))

--Added by Balaji.S on 22/07/2005 for Bug Id : PNR2.0_3328
update a
set  task_Descr = b.task_descr
from ep_deleted_task_dtl   a (nolock),
ep_action_mst    b (nolock)
where a.customer_name	= @customer_name_temp	--- Code Added  for the case id PLF2.0_07770 starts
and  a.project_name		= @project_name_temp
and  a.process_name		= @process_name_temp
and  a.component_name	= @component_name_temp
and  a.activity_name	= @activity_name_temp	
and  a.ui_name			= @ui_name_temp			--- Code Added for the case id PLF2.0_07770 ends
and  a.customer_name  = b.customer_name
and  a.project_name  = b.project_name
and  a.process_name = b.process_name
and  a.component_name = b.component_name
and  a.task_name   = b.task_name
and  a.task_descr  <> b.task_descr
--Added by Balaji.S on 22/07/2005 for Bug Id : PNR2.0_10009
update a
set  task_Descr = b.task_descr
from ep_published_action_mst  a (nolock),
ep_action_mst    b (nolock)
where a.customer_name	= @customer_name_temp	--- Code Added for the case id PLF2.0_07770 starts
and  a.project_name		= @project_name_temp
and  a.req_no			= @engg_req_no
and  a.process_name		= @process_name_temp
and  a.component_name	= @component_name_temp
and  a.activity_name	= @activity_name_temp
and  a.ui_name			= @ui_name_temp			--- Code Added for the case id PLF2.0_07770 ends
and  a.customer_name  = b.customer_name
and  a.project_name  = b.project_name
and  a.process_name  = b.process_name
and  a.component_name = b.component_name
and  a.task_name   = b.task_name
and  a.task_descr  <> b.task_descr
--and  a.status_flag  = 'I' --PNR2.0_26475
--Added by Balaji.S on 22/07/2005 for Bug Id : PNR2.0_3328


--    update ep_published_action_mst
--    set  status_flag = ''
--    where customer_name =  (@customer_name_temp)
--    and  project_name =  (@project_name_temp)
--    and  req_no   =  (@engg_req_no)
--    and  process_name = (@process_name_temp)
--    and  component_name = (@component_name_temp)
--    and  activity_name = (@activity_name_temp)
--    and  ui_name   = (@ui_name_temp)

/*  declare task_cur cursor for
select page_bt_synonym, task_name,  task_descr,
task_seq,   task_pattern, primary_control_bts, task_type
from ep_action_mst (nolock)
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_base_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)

open task_cur

while 1 = 1
begin --task_cur
fetch  next from task_cur
into @task_page_tmp,  @task_name,  @task_descr,
@task_seq,   @task_pattern, @primary_control_bts, @base_task_type

if @@fetch_status <> 0
begin
break
end
-- select * from ep_published_action_mst
-- where customer_name = 'customertest'

if exists (
select 'x'
from ep_published_action_mst (nolock)
where customer_name   =  (@customer_name_temp)
and  project_name   =  (@project_name_temp)
and  req_no     =  (@engg_req_no)
and  process_name   = (@process_name_temp)
and  component_name   = (@component_name_temp)
and  activity_name   = (@activity_name_temp)
and  ui_name     = (@ui_name_temp)
and  page_bt_synonym   = @task_page_tmp
and  task_name    = @task_name
and  task_descr    = @task_descr
and  task_seq    = @task_seq
--        and  task_pattern   = @task_pattern
and  task_type    = @base_task_type
and  primary_control_bts  = @primary_control_bts
)
begin
update ep_published_action_mst
set  status_flag = 'S'
where customer_name   = (@customer_name_temp)
and  project_name   = (@project_name_temp)
and  req_no     = (@engg_req_no)
and  process_name   = (@process_name_temp)
and  component_name   = (@component_name_temp)
and  activity_name   = (@activity_name_temp)
and  ui_name     = (@ui_name_temp)
and  page_bt_synonym   = @task_page_tmp
and  task_name    = @task_name
and  page_bt_synonym   = @task_page_tmp
and  task_name    = @task_name
and  task_descr    = @task_descr
and  task_seq    = @task_seq
--      and  task_pattern   = @task_pattern
and  task_type    = @base_task_type
and  primary_control_bts  = @primary_control_bts
end
else if exists (
select 'x'
from ep_published_action_mst (nolock)
where customer_name     = (@customer_name_temp)
and  project_name     = (@project_name_temp)
and  req_no       = (@engg_req_no)
and  process_name     = (@process_name_temp)
and  component_name     = (@component_name_temp)
and  activity_name     = (@activity_name_temp)
and  ui_name       = (@ui_name_temp)
and  page_bt_synonym     = @task_page_tmp
and  task_name      = @task_name
and  (isnull(task_descr,'')   <> isnull(@task_descr,'')
or  isnull(task_seq,'')    <> isnull(@task_seq,'')
or  isnull(task_pattern,'')   <> isnull(@task_pattern,'')
or  isnull(primary_control_bts,'') <> isnull(@primary_control_bts,''))
)
begin
update ep_published_action_mst
set  status_flag   =  'U',
task_descr   = @task_descr,
task_seq   = @task_seq,
task_pattern  = @task_pattern,
primary_control_bts = @primary_control_bts
where customer_name   =  (@customer_name_temp)
and  project_name   =  (@project_name_temp)
and  req_no     =  (@engg_req_no)
and  process_name   = (@process_name_temp)
and  component_name   = (@component_name_temp)
and  activity_name   = (@activity_name_temp)
and  ui_name     = (@ui_name_temp)
and  page_bt_synonym   = @task_page_tmp
and  task_name    = @task_name
end
else if not exists (
select 'x'
from ep_published_action_mst (nolock)
where customer_name   =  (@customer_name_temp)
and  project_name   =  (@project_name_temp)
and  req_no     =  (@engg_req_no)
and  process_name   = (@process_name_temp)
and  component_name   = (@component_name_temp)
and  activity_name   = (@activity_name_temp)
and  ui_name     = (@ui_name_temp)
and  page_bt_synonym   = @task_page_tmp
and  task_name    = @task_name
)
begin
insert into ep_published_action_mst
(
customer_name,  project_name,  req_no,
process_name,  component_name,  activity_name,
ui_name,   page_bt_synonym, task_name,
task_descr,   task_seq,   task_pattern,
primary_control_bts,task_sysid,   ui_sysid,
createdby,   createddate,  modifiedby,
modifieddate,  timestamp,   status_flag, task_type
)
select
customer_name,  project_name,  @engg_req_no,
process_name,  component_name,  activity_name,
ui_name,   page_bt_synonym, task_name,
task_descr,   task_seq,   task_pattern,
primary_control_bts,newid(),   ui_sysid,
@ctxt_user,   @date,   @ctxt_user,
@date,   1,     'I',    @base_task_type
from ep_action_mst (nolock)
where customer_name =  (@customer_name_temp)
and project_name =  (@project_name_temp)
and req_no  =  (@engg_base_req_no)
and process_name = (@process_name_temp)
and component_name = (@component_name_temp)
and activity_name = (@activity_name_temp)
and ui_name  = (@ui_name_temp)
and  page_bt_synonym   = @task_page_tmp
and  task_name    = @task_name
end
end
close task_cur
deallocate task_cur

update ep_published_action_mst
set  status_flag = 'D'
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)
and  task_name  not in (select task_name
from ep_action_mst (nolock)
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_base_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp))
*/
-- INSERTING INTO EP_PUBLISHED_ACTION_SECTION_MAP
if exists (
select 'x'
from ep_published_action_mst (nolock)
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name = (@ui_name_temp)
)
begin
-- code modified by shafina on 16-jan-2004 to insert page_bt_synonym in the published table
-- code COMMENTED by shafina on 16-jan-2004 to ROLLBACK TO PREVIOUS STATE

delete ep_published_action_section_map
where customer_name  =  (@customer_name_temp)
and  project_name  =  (@project_name_temp)
and  req_no    =  (@engg_req_no)
and  process_name  = (@process_name_temp)
and  component_name  = (@component_name_temp)
and  activity_name  = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)

insert into ep_published_action_section_map
(
customer_name,  project_name,  req_no,
process_name,  component_name,  activity_name,
ui_name,   page_bt_synonym, task_name,
section_bt_synonym, task_section_sysid, task_sysid,
createdby,   createddate,  modifiedby,
modifieddate,  timestamp,   section_page_bt_synonym
)
select
customer_name,  project_name,  @engg_req_no,
--req_no,
--modified by Shafina on 31-Dec-2003 to populate the published tables with the proper request number
process_name,  component_name,  activity_name,
ui_name,   page_bt_synonym, task_name,
section_bt_synonym, newid(),   task_sysid,
@ctxt_user,   @date,   @ctxt_user,
@date,   1,     section_page_bt_synonym
from ep_action_section_map (nolock)
where customer_name  =  (@customer_name_temp)
and  project_name  =  (@project_name_temp)
and  req_no    =  (@engg_base_req_no)
and  process_name  = (@process_name_temp)
and  component_name  = (@component_name_temp)
and  activity_name  = (@activity_name_temp)
and  ui_name    = (@ui_name_temp)
end

delete
from ep_published_flowbr_mst
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and ui_name   = (@ui_name_temp)
-- modified by shafina 0n 09-jan-2004 to insert into ep_published_flowbr_mst
-- INSERTING INTO EP_PUBLISHED_FLOWBR_MST
insert into ep_published_flowbr_mst
(
customer_name,  project_name,  req_no,
process_name,  component_name,  activity_name,
ui_name,   page_bt_synonym, task_name,
flowbr_name,  flowbr_descr,  flowbr_sequence,
flowbr_sysid,  task_sysid,   timestamp,
createdby,   createddate,  modifiedby,
modifieddate,  control_id,   view_name,
event_name,   map_flag,   status_flag
)
select
customer_name,  project_name,  @engg_req_no,
process_name,  component_name,  activity_name,
ui_name,   page_bt_synonym, task_name,
flowbr_name,  flowbr_descr,  flowbr_sequence,
newid(),   task_sysid,   1,
@ctxt_user,   @date,   @ctxt_user,
@date,   control_id,   view_name,
event_name,   map_flag,   'I'
from ep_flowbr_mst (nolock)
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_base_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)

update ep_published_flowbr_mst
set  status_flag  =  'S',
modifiedby  = @ctxt_user,
modifieddate = @date
from ep_published_flowbr_mst a,
ep_bpt_ui_flowbr_vw  b
where a.customer_name =  (@customer_name_temp)
and  a.project_name =  (@project_name_temp)
and  a.req_no  =  (@engg_req_no)
and  a.process_name = (@process_name_temp)
and  a.component_name= (@component_name_temp)
and  a.activity_name = (@activity_name_temp)
and  a.ui_name  = (@ui_name_temp)
and  a.customer_name = b.customer_name
and  a.customer_name = b.customer_name
and  a.process_name = b.process_name
and  a.component_name= b.component_name
and  a.activity_name = b.activity_name
and  a.ui_name  = b.ui_name
and  a.task_name  = b.task_name
and  a.flowbr_name = b.flowbr_name

update a
set  status_flag  =  'I',
modifiedby  = @ctxt_user,
modifieddate = @date
from ep_published_flowbr_mst a
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)
and  flowbr_name  not in (select b.flowbr_name
from ep_bpt_ui_flowbr_vw b(nolock)
where b.customer_name  =  (@customer_name_temp)
and  b.project_name  =  (@project_name_temp)
and  b.process_name  = (@process_name_temp)
and  b.component_name = (@component_name_temp)
and  b.activity_name  = (@activity_name_temp)
and  b.ui_name   = (@ui_name_temp)
and  b.task_name   = a.task_name)

-- code modified by shafina on 15-jan-2004 to update the req_status as 'P' for a particular UI..
update ep_ui_req_dtl
set  req_status  = 'P',
modifiedby  = @ctxt_user,
modifieddate = @date,
req_publish_date= @date
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and  ui_name   = (@ui_name_temp)

update ep_ui_mst
set  current_req_no =  '',
modifiedby  = @ctxt_user,
modifieddate = @date
where customer_name =  (@customer_name_temp)
and  project_name =  (@project_name_temp)
and  req_no   =  (@engg_base_req_no)
and  process_name = (@process_name_temp)
and  component_name = (@component_name_temp)
and  activity_name = (@activity_name_temp)
and ui_name   = (@ui_name_temp)


------ NGPLF Changes Starts
	Declare @ctxt_role		engg_name 

	Exec ngplf_wr_publish 
					@ctxt_language,			@ctxt_ouinstance,			@ctxt_user,				@ctxt_role,		
					@engg_customer_name,	@engg_project_name,			@process_name_temp,		@component_name_temp,
					@activity_name_temp,	@ui_name_temp,				@WorkRequest	=	@engg_req_no

------ NGPLF Changes ends

end--main_cur
close main_cur
deallocate main_cur

-- code modified by shafina on 07-May-2004 for PREVIEWENG203ACC_000056
delete gls
from ep_published_comp_glossary_mst  gls (nolock)
--    ep_ui_req_dtl      r  (nolock)/* PNR2.0_12773 */
where gls.customer_name = @engg_customer_name
and  gls.project_name = @engg_project_name
-- code modified by shafina on 12-May-2004 for PREVIEWENG203SYS_000069
--   and  r.req_no   = (@engg_base_req_no)
and  gls.req_no   = (@engg_req_no)
/* PNR2.0_12773 */
--   and  gls.process_name in (select distinct process_name
--           from ep_ui_req_dtl (nolock)
--           where customer_name = @engg_customer_name
--           and  project_name = @engg_project_name
--           and  req_no   = (@engg_req_no))
--   and  gls.component_name in (select distinct component_name
--           from ep_ui_req_dtl (nolock)
--           where customer_name = @engg_customer_name
--           and  project_name = @engg_project_name
--           and  req_no   = (@engg_req_no))
--   and  gls.customer_name = r.customer_name
--   and  gls.project_name = r.project_name
--   and  gls.req_no   = r.req_no
--   and  gls.process_name = r.process_name
--   and  gls.component_name = r.component_name
/* PNR2.0_12773 */
-- code modified by shafina on 17-June-2004 for PREVIEWENG203ACC_000073
Insert into ep_published_comp_glossary_mst
(
customer_name,   project_name,   req_no,
process_name,   component_name,   bt_synonym_name,
data_type,    length,     bt_synonym_caption,
glossary_sysid,   timestamp,    createdby,
createddate,   modifiedby,    modifieddate,
ref_bt_synonym_name, bt_synonym_doc,   bt_name,
synonym_status,   singleinst_sample_data, multiinst_sample_data, IsGlance

)
Select distinct
gls.customer_name,  gls.project_name,   @engg_req_no,
gls.process_name,  gls.component_name,   gls.bt_synonym_name,
gls.data_type,   gls.length,     gls.bt_synonym_caption,
glossary_sysid,   1,       @ctxt_user,
@date,    @ctxt_user,     @date,
gls.ref_bt_synonym_name,gls.bt_synonym_doc,   gls.bt_name,
gls.synonym_status,  gls.singleinst_sample_data, gls.multiinst_sample_data, IsGlance
from ep_component_glossary_mst gls (nolock),
ep_ui_req_dtl    r  (nolock)
where gls.customer_name = @engg_customer_name
and  gls.project_name = @engg_project_name
and  gls.req_no   = (@engg_base_req_no)
/* PNR2.0_12773 */
--   and  gls.process_name in (select distinct process_name
--           from ep_ui_req_dtl (nolock)
--           where customer_name = @engg_customer_name
--           and  project_name = @engg_project_name
--           and  req_no   = (@engg_req_no))
--   and  gls.component_name in (select distinct component_name
--           from ep_ui_req_dtl (nolock)
--      where customer_name = @engg_customer_name
--           and  project_name = @engg_project_name
--           and  req_no   = (@engg_req_no))
/* PNR2.0_12773 */
and  gls.customer_name = r.customer_name
and  gls.project_name = r.project_name
--   and  gls.req_no   = r.req_no
and  r.req_no   = @engg_req_no/* PNR2.0_12773 */
and  gls.process_name = r.process_name
and  gls.component_name = r.component_name

delete gls
from ep_published_comp_glossary_mst_lng_extn gls (nolock)
--    ep_ui_req_dtl       r  (nolock)/* PNR2.0_12773 */
where gls.customer_name = @engg_customer_name
and  gls.project_name = @engg_project_name
-- code modified by shafina on 12-May-2004 for PREVIEWENG203SYS_000069
--   and  r.req_no   = (@engg_base_req_no)
and  gls.req_no   = (@engg_req_no)
/* PNR2.0_12773 */
--   and  gls.process_name in (select distinct process_name
--           from ep_ui_req_dtl (nolock)
--           where customer_name = @engg_customer_name
--           and  project_name = @engg_project_name
--           and  req_no   = (@engg_req_no))
--   and  gls.component_name in (select distinct component_name
--           from ep_ui_req_dtl (nolock)
--           where customer_name = @engg_customer_name
--           and  project_name = @engg_project_name
--           and  req_no   = (@engg_req_no))
--   and  gls.customer_name = r.customer_name
--   and  gls.project_name = r.project_name
--   and  gls.req_no   = r.req_no
--   and  gls.process_name = r.process_name
--   and  gls.component_name = r.component_name
/* PNR2.0_12773 */

/* Code modified by Gankan.G for the CaseId:PNR2.0_32385 to populate lang extn tables starts*/

-- Code commented due to EP/RE lng extn purge Starts by 11537
/*
insert into ep_component_glossary_mst_lng_extn(customer_name,project_name,req_no,process_name,component_name,bt_synonym_name,data_type,length,bt_synonym_caption,glossary_sysid,languageid,timestamp,createdby,createddate,modifiedby,modifieddate,
ref_bt_synonym_name,bt_synonym_doc,bt_name,synonym_status,singleinst_sample_data,multiinst_sample_data,wrkreqno)

select	distinct a.customer_name,a.project_name,a.req_no,a.process_name,a.component_name,a.bt_synonym_name,a.data_type,a.length,a.bt_synonym_caption,a.glossary_sysid,c.quick_code,a.timestamp,a.createdby,a.createddate,a.modifiedby,a.modifieddate,
a.ref_bt_synonym_name,a.bt_synonym_doc,a.bt_name,synonym_status,a.singleinst_sample_data,a.multiinst_sample_data,a.wrkreqno
from	ep_component_glossary_mst a(nolock),
		ep_language_met c(nolock)
where	a.customer_name	=	@customer_name_temp 
and		a.project_name	=	@project_name_temp 
and		not exists (	select	'b'
						from	ep_component_glossary_mst_lng_extn b(nolock)
						where	b.customer_name		=	a.customer_name		
						and		b.project_name		=	a.project_name		
						and		b.process_name		=	a.process_name		
						and		b.component_name	=	a.component_name	
						and		b.bt_synonym_name	=	a.bt_synonym_name )
/* Code modified by Gankan.G for the CaseId:PNR2.0_32385 to populate lang extn tables ends*/

Insert into ep_published_comp_glossary_mst_lng_extn
(
customer_name,  project_name,  req_no,
process_name,  component_name,  bt_synonym_name,
data_type,   length,    bt_synonym_caption,
glossary_sysid,  languageid,   timestamp,
createdby,   createddate,  modifiedby,
modifieddate,  ref_bt_synonym_name,bt_synonym_doc,
bt_name,   synonym_status,  singleinst_sample_data,
multiinst_sample_data
)
Select distinct
gls.customer_name,  gls.project_name,  @engg_req_no,
gls.process_name,  gls.component_name,  gls.bt_synonym_name,
gls.data_type,   gls.length,    gls.bt_synonym_caption,
glossary_sysid,   gls.languageid,   1,
@ctxt_user,    @date,    @ctxt_user,
@date,    gls.ref_bt_synonym_name,gls.bt_synonym_doc,
gls.bt_name,   gls.synonym_status,  gls.singleinst_sample_data,
gls.multiinst_sample_data
from ep_component_glossary_mst_lng_extn gls (nolock),
ep_ui_req_dtl      r  (nolock)
where gls.customer_name = @engg_customer_name
and  gls.project_name = @engg_project_name
and  gls.req_no   = (@engg_base_req_no)
/* PNR2.0_12773 */
--   and  gls.process_name in (select distinct process_name
--           from ep_ui_req_dtl (nolock)
--           where customer_name = @engg_customer_name
--           and  project_name = @engg_project_name
--    and  req_no   = (@engg_req_no))
--   and  gls.component_name in (select distinct component_name
--           from ep_ui_req_dtl (nolock)
--           where customer_name = @engg_customer_name
--           and  project_name = @engg_project_name
--           and  req_no   = (@engg_req_no))
/* PNR2.0_12773 */
and  gls.customer_name = r.customer_name
and  gls.project_name = r.project_name
--   and  gls.req_no   = r.req_no
and  r.req_no   = @engg_req_no /* PNR2.0_12773 */
and  gls.process_name = r.process_name
and  gls.component_name = r.component_name
*/
-- Code commented due to EP/RE lng extn purge Ends by 11537

-- code modified by shafina on 14-jan-2004 to update the Preview Ready Flag as 'PPB'
--code modified by shafina on 15-jan-2004 to partially publish based on the previewready flag

--Insert data for static ctrl types --1497
EXEC ep_publish_stat_ctrl_types @ctxt_user,@customer_name_temp,@project_name_temp, @process_name_temp,@component_name_temp, @engg_req_no, 'P'
--Insert data for static ctrl types --1497

if @engg_req_no = 'BASE'
begin
declare pub_cur cursor
for
select distinct
r.customer_name , r.project_name , r.req_no ,
r.process_name , r.component_name , r.activity_name , b.functionid
from ep_ui_req_dtl r (nolock),
ep_bpt_download_vw b(nolock),
ep_bpt_activity_ppw_vw p(nolock)
where r.customer_name =  (@engg_customer_name)
and  r.project_name =  (@engg_project_name)
and  r.req_no  =  (@engg_req_no)
and  r.customer_name =  b.customer_name
and  r.project_name =  b.project_name
and  r.req_no  =  b.req_no
and  r.process_name = b.process_name
and  r.component_name= b.component_name
and  r.activity_name = b.activity_name
and  r.ui_name  = b.ui_name
--    and  r.activity_name <> 'IntegrationActivity'
--    and  r.ui_name  <> 'IntegrationUI'
and  b.customer_name =  p.customerid
and  b.project_name =  p.projectid
and  b.req_no  =  p.workreqid
and  b.process_name = p.bpid
and  b.functionid = p.functionid
and  b.activity_name = p.activityid
--     and  p.previewready = 'RPP'
and  r.ui_name   <>  ''
/*PNR2.0_14661*/
--   end
--   else
--   begin
--    declare pub_cur cursor
--    for
--    select distinct
--      r.customer_name , r.project_name , r.req_no ,
--      r.process_name , r.component_name , r.activity_name , c.functionid
--    from ep_ui_req_dtl r (nolock),
--      ep_cmt_download_vw c(nolock),
--      ep_cmt_activity_ppw_vw p(nolock)
--    where r.customer_name =  (@engg_customer_name)
--    and  r.project_name =  (@engg_project_name)
--    and  r.req_no  =  (@engg_req_no)
--    and  r.customer_name =  c.customer_name
--    and  r.project_name =  c.project_name
--    and  r.req_no  =  c.req_no
--    and  r.process_name = c.process_name
--    and  r.component_name= c.component_name
--    and  r.activity_name = c.activity_name
--    and  r.ui_name  = c.ui_name
-- --    and  r.activity_name <> 'IntegrationActivity'
-- --    and  r.ui_name  <> 'IntegrationUI'
--    and  c.customer_name =  p.customerid
--    and  c.project_name =  p.projectid
--    and  c.req_no =  p.workreqid
--    and  c.process_name = p.bpid
--    and  c.functionid = p.functionid
--    and  c.activity_name = p.activityid
-- --     and  p.previewready = 'RPP'
--    and  r.ui_name   <>  ''
--   end
/*PNR2.0_14661*/
open pub_cur

while 1 = 1
begin --pub_cur
fetch  next from pub_cur
into @cust_name_temp,@proj_name_temp,@req_tmp,
@proc_name_temp,@comp_name_temp,@act_name_temp,@func_name_temp

if @@fetch_status <> 0
begin
break
end

--    if @req_tmp = 'BASE'
--    begin
exec  bpt_preview_publish
@cust_name_temp,
@proj_name_temp,
@proc_name_temp,
@func_name_temp,
@act_name_temp,
@ctxt_language,
@ctxt_user,
@m_errorid output

if @m_errorid = 624
begin
select @msg = 'Please enter CustomerID'
exec engg_error_sp
ep_publ_sp_publcrml,1,@msg,@ctxt_language,@ctxt_ouinstance,
@ctxt_service,@ctxt_user,'','','','',@m_errorid out
close pub_cur
deallocate pub_cur
return
end

if @m_errorid = 625
begin
select @msg = 'Please enter ProjectID'
exec engg_error_sp
ep_publ_sp_publcrml,1,@msg,@ctxt_language,@ctxt_ouinstance,
@ctxt_service,@ctxt_user,'','','','',@m_errorid out
close pub_cur
deallocate pub_cur
return
end

if @m_errorid = 626
begin
select @msg = 'Please enter BPID'
exec engg_error_sp
ep_publ_sp_publcrml,1,@msg,@ctxt_language,@ctxt_ouinstance,
@ctxt_service,@ctxt_user,'','','','',@m_errorid out
close pub_cur
deallocate pub_cur
return
end

if @m_errorid = 627
begin
select @msg = 'Please enter FunctionID'
exec engg_error_sp
ep_publ_sp_publcrml,1,@msg,@ctxt_language,@ctxt_ouinstance,
@ctxt_service,@ctxt_user,'','','','',@m_errorid out
close pub_cur
deallocate pub_cur
return
end

if @m_errorid = 945
begin
select @msg = 'Activity ID cannot be blank'
exec engg_error_sp
ep_publ_sp_publcrml,1,@msg,@ctxt_language,@ctxt_ouinstance,
@ctxt_service,@ctxt_user,'','','','',@m_errorid out
close pub_cur
deallocate pub_cur
return
end

if @m_errorid = 648
begin
select @msg = 'CustomerID,ProjectID,BPID,FunctionID,ActivityName,UIID,and TaskID combination is Invalid.Please select another combination. '
exec engg_error_sp
ep_publ_sp_publcrml,1,@msg,@ctxt_language,@ctxt_ouinstance,
@ctxt_service,@ctxt_user,'','','','',@m_errorid out
close pub_cur
deallocate pub_cur
return
end
-- code modified by shafina on 20-April-2004 for PREVIEWENG203ACC_000035
if @m_errorid = 649
begin
select @msg = 'Activity : ' + @act_name_temp + ' is not ready for publish'
exec engg_error_sp
ep_publ_sp_publcrml,1,@msg,@ctxt_language,@ctxt_ouinstance,
@ctxt_service,@ctxt_user,'','','','',@m_errorid out
close pub_cur
deallocate pub_cur
return
end
-- code modified by shafina on 04-May-2004 for PREVIEWENG203SYS_000057
if @m_errorid = 650
begin
select @msg = 'Activity : ' + @act_name_temp + ' is already published'
exec engg_error_sp
ep_publ_sp_publcrml,1,@msg,@ctxt_language,@ctxt_ouinstance,
@ctxt_service,@ctxt_user,'','','','',@m_errorid out
close pub_cur
deallocate pub_cur
return
end
-- code modified by shafina on 20-July-2004 for PREVIEWENG203SYS_000057
if @m_errorid = 665
begin
select @msg = 'Activity : ' + @act_name_temp + ' is already baselined'
exec engg_error_sp
ep_publ_sp_publcrml,1,@msg,@ctxt_language,@ctxt_ouinstance,
@ctxt_service,@ctxt_user,'','','','',@m_errorid out
close pub_cur
deallocate pub_cur
return
end
-- code commented by shafina on 29-April-2004 for PREVIEWENG203SYS_000051
/*    if @m_errorid <> 0
begin
close pub_cur
deallocate pub_cur
return
end*/
end
close pub_cur
deallocate pub_cur
end
/*PNR2.0_14661*/
else
begin
declare pub_cur cursor
for
select distinct
r.customer_name , r.project_name , r.req_no ,
r.process_name , r.component_name , c.functionid
from ep_ui_req_dtl r (nolock),
ep_cmt_download_vw c(nolock),
ep_cmt_activity_ppw_vw p(nolock)
where r.customer_name =  (@engg_customer_name)
and  r.project_name =  (@engg_project_name)
and  r.req_no  =  (@engg_req_no)
and  r.customer_name =  c.customer_name
and  r.project_name =  c.project_name
and  r.req_no  =  c.req_no
and  r.process_name = c.process_name
and  r.component_name= c.component_name
and  r.activity_name = c.activity_name
and  r.ui_name  = c.ui_name
and  c.customer_name =  p.customerid
and  c.project_name =  p.projectid
and  c.req_no  =  p.workreqid
and  c.process_name = p.bpid
and  c.functionid = p.functionid
and  c.activity_name = p.activityid
and  r.ui_name   <>  ''
open pub_cur
while (1=1)
begin
fetch next from pub_cur into @cust_name_temp,@proj_name_temp,@req_tmp,@proc_name_temp,@comp_name_temp,@func_name_temp

if @@fetch_status <> 0
begin
break
end

IF exists ( SELECT 'x'
FROM Fw_Cmt_Activity (nolock)
WHERE CustomerID = @cust_name_temp
AND  ProjectID = @proj_name_temp
AND  WorkReqID   = @req_tmp
AND  BPID  = @proc_name_temp
AND  FunctionID = @func_name_temp
AND  LangID  = @ctxt_language
AND  PreviewReady = 'PPB')
begin
SELECT @act_name_temp = ActivityName
FROM Fw_Cmt_Activity (nolock)
WHERE CustomerID = @cust_name_temp
AND  ProjectID = @proj_name_temp
AND  WorkReqID   = @req_tmp
AND  BPID  = @proc_name_temp
AND  FunctionID = @func_name_temp
AND  LangID  = @ctxt_language
AND  PreviewReady = 'PPB'

select @msg = 'Activity : ' + @act_name_temp + ' is already published'
exec engg_error_sp
ep_publ_sp_publcrml,1,@msg,@ctxt_language,@ctxt_ouinstance,
@ctxt_service,@ctxt_user,'','','','',@m_errorid out
close pub_cur
deallocate pub_cur
return
end

--   begin
exec cmt_preview_publish
@cust_name_temp,
@proj_name_temp,
@req_tmp,
@proc_name_temp,
@func_name_temp,
'',
@ctxt_language,
@ctxt_user,
'Component',
@m_errorid output
/*PNR2.0_14661*/
if @m_errorid = 618
begin
select @msg = 'CustomerID cannot be Blank'
exec engg_error_sp
ep_publ_sp_publcrml,1,@msg,@ctxt_language,@ctxt_ouinstance,
@ctxt_service,@ctxt_user,'','','','',@m_errorid out
close pub_cur
deallocate pub_cur
return
end

if @m_errorid = 619
begin
select @msg = 'ProjectID cannot be Blank'
exec engg_error_sp
ep_publ_sp_publcrml,1,@msg,@ctxt_language,@ctxt_ouinstance,
@ctxt_service,@ctxt_user,'','','','',@m_errorid out
close pub_cur
deallocate pub_cur
return
end

if @m_errorid = 620
begin
select @msg = 'WorkReqID cannot be blank'
exec engg_error_sp
ep_publ_sp_publcrml,1,@msg,@ctxt_language,@ctxt_ouinstance,
@ctxt_service,@ctxt_user,'','','','',@m_errorid out
close pub_cur
deallocate pub_cur
return
end

if @m_errorid = 654
begin
select @msg = 'BP ID cannot be blank'
exec engg_error_sp
ep_publ_sp_publcrml,1,@msg,@ctxt_language,@ctxt_ouinstance,
@ctxt_service,@ctxt_user,'','','','',@m_errorid out
close pub_cur
deallocate pub_cur
return
end

if @m_errorid = 655
begin
select @msg = 'Function ID cannot be blank'
exec engg_error_sp
ep_publ_sp_publcrml,1,@msg,@ctxt_language,@ctxt_ouinstance,
@ctxt_service,@ctxt_user,'','','','',@m_errorid out
close pub_cur
deallocate pub_cur
return
end

if @m_errorid = 702
begin
select @msg = 'Activity ID cannot be blank'
exec engg_error_sp
ep_publ_sp_publcrml,1,@msg,@ctxt_language,@ctxt_ouinstance,
@ctxt_service,@ctxt_user,'','','','',@m_errorid out
close pub_cur
deallocate pub_cur
return
end

if @m_errorid = 816
begin
select @msg = 'CustomerID,ProjectID,BPID,FunctionID,ActivityName,UIID,and TaskID combination is Invalid.Please select another combination. '
exec engg_error_sp
ep_publ_sp_publcrml,1,@msg,@ctxt_language,@ctxt_ouinstance,
@ctxt_service,@ctxt_user,'','','','',@m_errorid out
close pub_cur
deallocate pub_cur
return
end
/*PNR2.0_14661*/
--     if @m_errorid = 1469
--     begin
--      select @msg = 'Activity : ' + @act_name_temp + ' is not ready for publish'
--      exec engg_error_sp
--        ep_publ_sp_publcrml,1,@msg,@ctxt_language,@ctxt_ouinstance,
--        @ctxt_service,@ctxt_user,'','','','',@m_errorid out
--      close pub_cur
--      deallocate pub_cur
--      return
--     end
-- code modified by shafina on 04-May-2004 for PREVIEWENG203SYS_000057
--     if @m_errorid = 701
--     begin
--
--      select @msg = 'Activity : ' + @act_name_temp + ' is already published'
--      exec engg_error_sp
--        ep_publ_sp_publcrml,1,@msg,@ctxt_language,@ctxt_ouinstance,
--        @ctxt_service,@ctxt_user,'','','','',@m_errorid out
--      close pub_cur
--      deallocate pub_cur
--      return
--     end
/*PNR2.0_14661*/
--     if @m_errorid = 701
--     begin
--      select @msg = 'Activity : ' + @act_name_temp + ' is already baselined'
--      exec engg_error_sp
--        ep_publ_sp_publcrml,1,@msg,@ctxt_language,@ctxt_ouinstance,
--        @ctxt_service,@ctxt_user,'','','','',@m_errorid out
--      close pub_cur
--      deallocate pub_cur
--      return
--     end
-- code commented by shafina on 29-April-2004 for PREVIEWENG203SYS_000051
/*    if @m_errorid <> 0
begin
close pub_cur
deallocate pub_cur
return
end*/
end
close pub_cur
deallocate pub_cur
end
end--1
end  --@auto_complete = 'WorkRequest'


if isnull(@auto_complete,'') in ('RCN', 'ECR')
Begin --(@auto_complete,'') in ('RCN', 'ECR')
declare @tmp_rcnno  engg_name
declare @tmp_uiname  engg_name
declare @tmp_ecrno  engg_name
declare @engg_ecr_descr engg_desc
declare @engg_ecr_no engg_name
declare @engg_ico_descr engg_desc
declare @engg_ico_no engg_name

if isnull(@engg_req_no,'') = 'Base'
Begin
select @msg = 'Invalid Document Selection for Workrequest: "Base"'
exec engg_error_sp  'ep_publ_sp_publcrml',
1,
@msg,
@ctxt_language,
@ctxt_ouinstance,
@ctxt_service,
@ctxt_user,
'',
'',
'',
'',
@m_errorid out
return
End

if isnull(@auto_complete,'') = 'RCN'
Begin  --(@auto_complete,'') = 'RCN'


select @tmp_rcnno = ecr_no,--
@tmp_uiname = ui_name--
from re_ui_ecr a (nolock)
where a.customer_name =  (@engg_customer_name)
and  a.project_name =  (@engg_project_name)
and  exists  (select 'x'
from ep_ui_req_dtl b(nolock)
where b.customer_name  =  (@engg_customer_name)
and  b.project_name  =  (@engg_project_name)
and  b.req_no   =  (@engg_req_no)
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name )
and  a.ui_status  = 'C'

if isnull(@tmp_rcnno,'') <> ''
Begin
select @msg = 'The UI: '+@tmp_uiname+' is in current status for the RCN: '+@tmp_rcnno+'. Can not proceed'
exec engg_error_sp  'ep_publ_sp_publcrml',
1,
@msg,
@ctxt_language,
@ctxt_ouinstance,
@ctxt_service,
@ctxt_user,
'',
'',
'',
'',
@m_errorid out
return
End

select @engg_ecr_no = rcnnumber
from Fw_Nia_SheetID_RCN_ECR_ICODtl (nolock)/*PNR2.0_12824*/
where customerid =  @engg_customer_name
and  projectid =  @engg_project_name
and  WorkReqID =  @engg_req_no

if isnull(@engg_ecr_no,'') = ''
Begin
select @engg_ecr_no = rcnnumber
from Fw_Nia_GenDoc_RCN_ECR_ICO_temp (nolock)
where customerid =  @engg_customer_name
and  projectid =  @engg_project_name
and  WorkReqID  =  @engg_req_no
End

if isnull(@engg_ecr_no,'') = ''
Begin
select @msg = 'Engineering Documents have not been generated for this Workrequest: '+@engg_req_no
exec engg_error_sp  'ep_publ_sp_publcrml',
1,
@msg,
@ctxt_language,
@ctxt_ouinstance,
@ctxt_service,
@ctxt_user,
'',
'',
'',
'',
@m_errorid out
return /*PNR2.0_12824*/
End

exec  ep_publ_sp_publcrml
@ctxt_language,
@ctxt_ouinstance,
@ctxt_service,
@ctxt_user,
@engg_customer_name,
@engg_project_name,
@engg_req_descr,
@engg_req_no,
'Z',
'Current',
0,
@m_errorid out

if isnull(@m_errorid,0) <> 0
return




exec  re_ecr_sp_dnldecr
@ctxt_language,
@ctxt_ouinstance,
@ctxt_service,
@ctxt_user,
@engg_customer_name,
@engg_ecr_descr,--
@engg_ecr_no,--
'Pending',
@engg_project_name,
'Z',
0,
@m_errorid out

if isnull(@m_errorid,0) <> 0
return

exec  re_publ_sp_publcrml
@ctxt_language,
@ctxt_ouinstance,
@ctxt_service,
@ctxt_user,
@engg_customer_name,
@engg_ecr_descr,--
@engg_ecr_no,--
@engg_project_name,
'Z',
'Current',
0,
@m_errorid out

if isnull(@m_errorid,0) <> 0
return


End  --(@auto_complete,'') = 'RCN'

if isnull(@auto_complete,'') = 'ECR'
Begin  --(@auto_complete,'') = 'ECR'



select @tmp_ecrno = ico_no,--
@tmp_uiname = ui_name--
from de_ui_ico a (nolock)
where a.customer_name =  (@engg_customer_name)
and  a.project_name =  (@engg_project_name)
and  exists  ( select 'x'
from ep_ui_req_dtl b(nolock)
where b.customer_name  =  (@engg_customer_name)
and  b.project_name  =  (@engg_project_name)
and  b.req_no   =  (@engg_req_no)
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name )
and  a.ico_status = 'C'

if isnull(@tmp_ecrno,'') <> ''
Begin
select @msg = 'The UI: '+@tmp_uiname+' is in current status for the ECR: '+@tmp_ecrno+'. Can not proceed'
exec engg_error_sp  'ep_publ_sp_publcrml',
1,
@msg,
@ctxt_language,
@ctxt_ouinstance,
@ctxt_service,
@ctxt_user,
'',
'',
'',
'',
@m_errorid out
return
End


exec  ep_publ_sp_publcrml
@ctxt_language,
@ctxt_ouinstance,
@ctxt_service,
@ctxt_user,
@engg_customer_name,
@engg_project_name,
@engg_req_descr,
@engg_req_no,
'Z',
'RCN',
0,
@m_errorid out

if isnull(@m_errorid,0) <> 0
return


Declare wrqecr_cur insensitive cursor
for
select distinct ECRNumber
from Fw_Nia_SheetID_RCN_ECR_ICODtl(nolock)/*PNR2.0_12824*/
where customerid =  @engg_customer_name
and  projectid =  @engg_project_name
and  WorkReqID  =  @engg_req_no
union
select distinct ECRNumber
from Fw_Nia_GenDoc_RCN_ECR_ICO_temp (nolock)
where customerid =  @engg_customer_name
and  projectid =  @engg_project_name
and  WorkReqID  =  @engg_req_no

Open wrqecr_cur
While 1=1
Begin --cursor

fetch next from wrqecr_cur into @engg_ico_no
if @@fetch_status <> 0
break

exec  de_dnld_sp_dnldico
@ctxt_language,
@ctxt_ouinstance,
@ctxt_service,
@ctxt_user,
@engg_customer_name,
@engg_ico_descr,--
@engg_ico_no,--
'Pending',--
@engg_project_name,
'Z',
0,
@m_errorid out

if isnull(@m_errorid,0) <> 0
return

exec  de_publ_sp_publico
@ctxt_language,
@ctxt_ouinstance,
@ctxt_service,
@ctxt_user,
@engg_customer_name,
@engg_ico_descr,--
@engg_ico_no,--
@engg_project_name,
'Z',
0,
@m_errorid out

if isnull(@m_errorid,0) <> 0
return
End --cursor
Close wrqecr_cur
Deallocate wrqecr_cur

End  --(@auto_complete,'') = 'ECR'

End --(@auto_complete,'') in ('RCN', 'ECR')

		--if exists ( select  'x'  -- code added by 11536 for the case id TECH-20631
		--			from	ep_ui_req_dtl(nolock)  
		--			where	customer_name		=	@engg_customer_name  
		--			and		project_name		=	@engg_project_name  
		--			and		req_no				=	rtrim(@engg_req_no)  
		--			and		req_status			=	'p'
		--			)  
		--			begin 

		--				Update	FW_NIA_GenDoc_Rcn_Ecr_ICO_temp 
		--				set		doc_status			=	'WRPUB'
		--				where	Customerid			=	@engg_customer_name
		--				and		Projectid			=	@engg_project_name
		--				and		WorkReqID			=	rtrim(@engg_req_no) 

		--			End

-- NGPLF Changes Starts
	
	--Update	ngplf_glance_upload_blob set DocumentStatus = 'P'
	--where	CustomerID		= rtrim(@engg_customer_name)
	--and		ProjectID		= rtrim(@engg_project_name)
	--and		DocumentNo		= rtrim(@engg_req_no)
	--and		ComponentName	= rtrim(@comp_name_temp)
	--and		ActivityName    = rtrim(@act_name_temp)
	--and     UIName			= rtrim(@ui_name_temp)
-- NGPLF Changes Ends

IF  @ctxt_service_in = 'EP_Publ_Sr_Publ'    and  @engg_req_descr not in ('pubezeeview')  --Code modified for PNR2.0_28333	
select @fprowno 'fprowno_io' /* DOTNET Migration Tool Changes */

set nocount off
end
GO

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_publ_sp_publcrml' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON ep_publ_sp_publcrml TO PUBLIC
END
GO


