IF EXISTS  (SELECT 'X' FROM SYSOBJECTS WHERE NAME ='ep_maireeSp_scsavengg_c' AND TYPE = 'P')
    BEGIN
        DROP PROC ep_maireeSp_scsavengg_c
    END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		ep_maireeSp_scsavengg_c.sql
********************************************************************************/
/********************************************************************************/
/* Procedure    : ep_maireeSp_scsavengg_c                                       */
/* Description  :                                                               */
/********************************************************************************/
/* Project      :                                                               */
/* ECR          :                                                               */
/* Version      :                                                               */
/********************************************************************************/
/* Referenced   :                                                               */
/* Tables       :                                                               */
/********************************************************************************/
/* Development history                                                          */
/********************************************************************************/
/* Author       : Model Explorer                                                */
/* Date         : 23/Sep/2005                                                   */
/********************************************************************************/
/* Modification history                                                         */
/********************************************************************************/
/* Modified by  :                                                               */
/* Date         :                                                               */
/* Description  :                                                               */
/********************************************************************************/
/* modified by  : Piranava T  			                                        */
/* date         : Oct 10 2014			                                        */
/* BugId        : PLF2.0_09035 			                                        */
/* description  : Model changes for rowspan,colspan,IsStatic,IsCallout iná layout level */
/************************************************************************************/
/* Modified by  : Veena U                                                  */
/* Date         : 25-Feb-2015                                                  */
/* Call ID		: PLF2.0_11499                                                 */
/********************************************************************************/
/* Modified by  : Kalidas S	                                                  */
/* Date         : 03-Aug-2015                                                  */
/* Defect ID	: PLF2.0_14096                                                 */
/********************************************************************************/
/* modified by			Date				Defect ID							*/
/* Veena U				08-Jun-2016			PLF2.0_18487						*/
/********************************************************************************/
/* Modified by    :    Ponmalar A                                               */
/* Modified on    :    02/12/22													*/
/* Defect ID      :    TECH-75230												*/
/* Description    : Platform Release for the Month of Nov'22				    */
/********************************************************************************/
CREATE PROCEDURE ep_maireeSp_scsavengg_c
	@ctxt_ouinstance engg_ctxt_ouinstance, --Input 
	@ctxt_user engg_ctxt_user, --Input 
	@ctxt_language engg_ctxt_language, --Input 
	@ctxt_service engg_ctxt_service, --Input 
	--@enggc_hModeFlag											engg_guid, -- Input
	@engge_hModeFlag engg_guid, -- Input
	@engg_act_descr ENGG_DESCRIPTION, --Input 
	@engg_component engg_description, --Input 
	@engg_cont_btsynname engg_name, --Input 
	@engg_cont_ctrlclass engg_name, --Input 
	@engg_cont_ctrlimgclass engg_name, --Input 
	@engg_cont_datawidth engg_flag, --Input 
	@engg_cont_descr engg_description, --Input 
	@engg_cont_doc engg_documentation, --Input 
	@engg_cont_elem_type engg_name, --Input 
	@engg_cont_helptabstop engg_flag, --Input 
	@engg_cont_horder engg_seqno, --Input 
	@engg_cont_labclass engg_name, --Input 
	@engg_cont_labimgclass engg_name, --Input 
	@engg_cont_labwidth engg_flag, --Input 
	@engg_cont_page_bts engg_name, --Input 
	@engg_cont_samp_data engg_documentation, --Input 
	@engg_cont_sec_bts engg_name, --Input 
	@engg_cont_sequence engg_seqno, --Input 
	@engg_cont_tabseq engg_seqno, --Input 
	@engg_cont_tooltip engg_documentation, --Input 
	@engg_cont_vis_length engg_length, --Input 
	@engg_cont_vorder engg_seqno, --Input 
	@engg_customer_name engg_name, --Input 
	@engg_enum_page_bts engg_name, --Input 
	@engg_enum_sec_bts engg_name, --Input 
	@engg_grid_page_bts engg_name, --Input 
	@engg_grid_sec_bts engg_name, --Input 
	@engg_lay_page_bts engg_name, --Input 
	@engg_process_descr engg_description, --Input 
	@engg_project_name engg_name, --Input 
	@engg_radio_page_bts engg_name, --Input 
	@engg_radio_sec_bts engg_name, --Input 
	@engg_req_no engg_name, --Input 
	@engg_rf_act engg_description, --Input 
	@engg_rf_comp engg_description, --Input 
	@engg_rf_ui engg_description, --Input 
	@engg_sec_page_bts engg_name, --Input 
	@engg_ui_descr engg_name, --Input 
	@engg_ui_xml engg_documentation, --Input 
	@hdncustomer engg_name, --Input 
	@hdnproject engg_name, --Input 
	@modeflag engg_modeflag, --Input 
	@Engg_cont_rowspan engg_seq_no,
	@Engg_cont_colspan engg_seq_no,
	@Engg_cont_Ctrlimg engg_description, --Input --shakthi
	@engg_c_fpRowNo engg_rowno, --Input/Output 
	@engg_cont_tempid engg_name, --Input/Output
	@ctrl_temp_cat engg_name, --Input 
	@ctrl_temp_specific engg_documentation, --Input 
	@icon_position		engg_name,
	@ButtonNature		engg_name,	--Code added for TECH-75230
	@InlineStyle		engg_nvarchar_max,	--Code added for TECH-75230
	@m_errorid INT OUTPUT --To Return Execution Status 
AS
BEGIN
	-- nocount should be switched on to prevent phantom rows
	SET NOCOUNT ON
	-- @m_errorid should be 0 to Indicate Success
	SET @m_errorid = 0
	--declaration of temporary variables
	--temporary and formal parameters mapping
	SET @ctxt_user = ltrim(rtrim(@ctxt_user))
	SET @ctxt_service = ltrim(rtrim(@ctxt_service))
	SET @engg_act_descr = ltrim(rtrim(@engg_act_descr))
	SET @engg_component = ltrim(rtrim(@engg_component))
	SET @engg_cont_btsynname = ltrim(rtrim(@engg_cont_btsynname))
	SET @engg_cont_ctrlclass = ltrim(rtrim(@engg_cont_ctrlclass))
	SET @engg_cont_ctrlimgclass = ltrim(rtrim(@engg_cont_ctrlimgclass))
	SET @engg_cont_datawidth = ltrim(rtrim(@engg_cont_datawidth))
	SET @engg_cont_descr = ltrim(rtrim(@engg_cont_descr))
	SET @engg_cont_doc = ltrim(rtrim(@engg_cont_doc))
	SET @engg_cont_elem_type = ltrim(rtrim(@engg_cont_elem_type))
	SET @engg_cont_helptabstop = ltrim(rtrim(@engg_cont_helptabstop))
	SET @engg_cont_labclass = ltrim(rtrim(@engg_cont_labclass))
	SET @engg_cont_labimgclass = ltrim(rtrim(@engg_cont_labimgclass))
	SET @engg_cont_labwidth = ltrim(rtrim(@engg_cont_labwidth))
	SET @engg_cont_page_bts = ltrim(rtrim(@engg_cont_page_bts))
	SET @engg_cont_samp_data = ltrim(rtrim(@engg_cont_samp_data))
	SET @engg_cont_sec_bts = ltrim(rtrim(@engg_cont_sec_bts))
	SET @engg_cont_tooltip = ltrim(rtrim(@engg_cont_tooltip))
	SET @engg_customer_name = ltrim(rtrim(@engg_customer_name))
	SET @engg_enum_page_bts = ltrim(rtrim(@engg_enum_page_bts))
	SET @engg_enum_sec_bts = ltrim(rtrim(@engg_enum_sec_bts))
	SET @engg_grid_page_bts = ltrim(rtrim(@engg_grid_page_bts))
	SET @engg_grid_sec_bts = ltrim(rtrim(@engg_grid_sec_bts))
	SET @engg_lay_page_bts = ltrim(rtrim(@engg_lay_page_bts))
	SET @engg_process_descr = ltrim(rtrim(@engg_process_descr))
	SET @engg_project_name = ltrim(rtrim(@engg_project_name))
	SET @engg_radio_page_bts = ltrim(rtrim(@engg_radio_page_bts))
	SET @engg_radio_sec_bts = ltrim(rtrim(@engg_radio_sec_bts))
	SET @engg_req_no = ltrim(rtrim(@engg_req_no))
	SET @engg_rf_act = ltrim(rtrim(@engg_rf_act))
	SET @engg_rf_comp = ltrim(rtrim(@engg_rf_comp))
	SET @engg_rf_ui = ltrim(rtrim(@engg_rf_ui))
	SET @engg_sec_page_bts = ltrim(rtrim(@engg_sec_page_bts))
	SET @engg_ui_descr = ltrim(rtrim(@engg_ui_descr))
	SET @engg_ui_xml = ltrim(rtrim(@engg_ui_xml))
	SET @hdncustomer = ltrim(rtrim(@hdncustomer))
	SET @hdnproject = ltrim(rtrim(@hdnproject))
	SET @modeflag = ltrim(rtrim(@modeflag))
	SET @engg_cont_tempid = ltrim(rtrim(@engg_cont_tempid))

	--null checking
	IF @ctxt_ouinstance = - 915
		SET @ctxt_ouinstance = NULL

	IF @ctxt_user = '~#~'
		SET @ctxt_user = NULL

	IF @ctxt_language = - 915
		SET @ctxt_language = NULL

	IF @ctxt_service = '~#~'
		SET @ctxt_service = NULL

	IF @engg_act_descr = '~#~'
		SET @engg_act_descr = NULL

	IF @engg_component = '~#~'
		SET @engg_component = NULL

	IF @engg_cont_btsynname = '~#~'
		SET @engg_cont_btsynname = NULL

	IF @engg_cont_ctrlclass = '~#~'
		SET @engg_cont_ctrlclass = NULL

	IF @engg_cont_ctrlimgclass = '~#~'
		SET @engg_cont_ctrlimgclass = NULL

	IF @engg_cont_datawidth = '~#~'
		SET @engg_cont_datawidth = NULL

	IF @engg_cont_descr = '~#~'
		SET @engg_cont_descr = NULL

	IF @engg_cont_doc = '~#~'
		SET @engg_cont_doc = NULL

	IF @engg_cont_elem_type = '~#~'
		SET @engg_cont_elem_type = NULL

	IF @engg_cont_helptabstop = '~#~'
		SET @engg_cont_helptabstop = NULL

	IF @engg_cont_horder = - 915
		SET @engg_cont_horder = NULL

	IF @engg_cont_labclass = '~#~'
		SET @engg_cont_labclass = NULL

	IF @engg_cont_labimgclass = '~#~'
		SET @engg_cont_labimgclass = NULL

	IF @engg_cont_labwidth = '~#~'
		SET @engg_cont_labwidth = NULL

	IF @engg_cont_page_bts = '~#~'
		SET @engg_cont_page_bts = NULL

	IF @engg_cont_samp_data = '~#~'
		SET @engg_cont_samp_data = NULL

	IF @engg_cont_sec_bts = '~#~'
		SET @engg_cont_sec_bts = NULL

	IF @engg_cont_sequence = - 915
		SET @engg_cont_sequence = NULL

	IF @engg_cont_tabseq = - 915
		SET @engg_cont_tabseq = NULL

	IF @engg_cont_tooltip = '~#~'
		SET @engg_cont_tooltip = NULL

	IF @engg_cont_vis_length = - 915
		SET @engg_cont_vis_length = NULL

	IF @engg_cont_vorder = - 915
		SET @engg_cont_vorder = NULL

	IF @engg_customer_name = '~#~'
		SET @engg_customer_name = NULL

	IF @engg_enum_page_bts = '~#~'
		SET @engg_enum_page_bts = NULL

	IF @engg_enum_sec_bts = '~#~'
		SET @engg_enum_sec_bts = NULL

	IF @engg_grid_page_bts = '~#~'
		SET @engg_grid_page_bts = NULL

	IF @engg_grid_sec_bts = '~#~'
		SET @engg_grid_sec_bts = NULL

	IF @engg_lay_page_bts = '~#~'
		SET @engg_lay_page_bts = NULL

	IF @engg_process_descr = '~#~'
		SET @engg_process_descr = NULL

	IF @engg_project_name = '~#~'
		SET @engg_project_name = NULL

	IF @engg_radio_page_bts = '~#~'
		SET @engg_radio_page_bts = NULL

	IF @engg_radio_sec_bts = '~#~'
		SET @engg_radio_sec_bts = NULL

	IF @engg_req_no = '~#~'
		SET @engg_req_no = NULL

	IF @engg_rf_act = '~#~'
		SET @engg_rf_act = NULL

	IF @engg_rf_comp = '~#~'
		SET @engg_rf_comp = NULL

	IF @engg_rf_ui = '~#~'
		SET @engg_rf_ui = NULL

	IF @engg_sec_page_bts = '~#~'
		SET @engg_sec_page_bts = NULL

	IF @engg_ui_descr = '~#~'
		SET @engg_ui_descr = NULL

	IF @engg_ui_xml = '~#~'
		SET @engg_ui_xml = NULL

	IF @hdncustomer = '~#~'
		SET @hdncustomer = NULL

	IF @hdnproject = '~#~'
		SET @hdnproject = NULL

	IF @modeflag = '~#~'
		SET @modeflag = NULL

	IF @engg_c_fpRowNo = - 915
		SET @engg_c_fpRowNo = NULL

	IF @engg_cont_tempid = '~#~'
		SET @engg_cont_tempid = NULL

	/* 
	--OuputList
	Select null 'engg_c_fpRowNo' from
	null 'engg_cont_tempid',  *** 
*/
	SELECT 0 'engg_c_fpRowNo'

	SET NOCOUNT OFF
END

GO

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_maireeSp_scsavengg_c' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON ep_maireeSp_scsavengg_c TO PUBLIC
END
GO
