IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_layout_sp_savfrm_hsv' AND TYPE = 'P')
BEGIN
	DROP PROC ep_layout_sp_savfrm_hsv
END
GO
/*      V E R S I O N      :  2.0.4    */  
/*      Released By        :  PTech    */  
/*      Release Comments   :  Released on 05-Nov-2004 (Patch Release-7)    */  
/*      V E R S I O N      :  2.0.2    */  
/*      Released By        :  PTech    */  
/*      Release Comments   :  Released on  22-Jan-2004    */  
/****** Object:  Stored Procedure dbo.ep_layout_sp_savfrm_hsv    Script Date: 11/6/03 5:20:43 PM ******/  
/********************************************************************************/  
/* procedure      ep_layout_sp_savfrm_hsv                                       */  
/* description    sp to save ui format attribute values in main page			*/  
/********************************************************************************/  
/* project        Preview                                                       */  
/* version                                                                      */  
/********************************************************************************/  
/* referenced                                                                   */  
/* tables                                                                       */  
/********************************************************************************/  
/* development history                                                          */  
/********************************************************************************/  
/* author         B.Shafina Begum                                               */  
/* date           23/ 10/ 2003                                                  */  
/********************************************************************************/  
/* modification history                                                         */  
/********************************************************************************/  
/* modified by  : B.Shafina Begum                                               */  
/* date         : 04-feb-2004                                                   */  
/* description  : To check for ui's req_status									*/  
/* modified by  : Shiram V														*/  
/* date         : 09-Aug-2005													*/  
/* description  : Cannot insert the value NULL into column 'tab_height', table  */  
/*'modeldb20.dbo.ep_ui_mst'; column does not allow nulls.						*/  
/*********************************************************************************/  
/* Modification history                                                         */  
/********************************************************************************/  
/* Modified by  : Ramanujam S                                                   */  
/* Date         : 30-11-2005                                                    */  
/* Description  : New Parameter @engg_att_ui_grid_type was added                */  
/********************************************************************************/  
/* Modified by : Feroz														    */  
/* Modified on : 08/11/06														*/  
/* Description : State Processing												*/  
/********************************************************************************/  
/* modified by   : Jeya															*/  
/* date     : 25-nov-2008														*/  
/* BugId    : PNR2.0_1790														*/  
/********************************************************************************/  
/* modified by  : Jeyalatha K													*/  
/* date    : 11-Feb-2011														*/  
/* Bug Id   : PNR2.0_30127														*/  
/* Modified for  : Feature  Release												*/  
/********************************************************************************/  
/* modified by  : Ganesh Prabhu S                                      			*/  
/* date         : Oct 10 2014                               					*/  
/* BugId        : PLF2.0_09035                                          		*/  
/* description  : Model changes for rowspan,colspan,IsStatic,IsCallout in  layout level  */  
/********************************************************************************/   
/* Modified by  : Veena U														*/
/* Date         : 25-Feb-2015													*/
/* Call ID		: PLF2.0_11499													*/
/********************************************************************************/
/* Modified by  : Kalidas S	                                                  */
/* Date         : 03-Aug-2015                                                  */
/* Defect ID	: PLF2.0_14096                                                 */
/********************************************************************************/
 /* Modified by  : Veena U	                                                  */
/* Date         : 24-Dec-2015*/
/* Defect ID	: PLF2.0_16153                                                 */
/********************************************************************************/
/* Modified by  : Veena U                                                  */
/* Date         : 24-Feb-2016                                                 */
/* Defect ID	: PLF2.0_16291                                                */
/********************************************************************************/  
/* Modified by  : Veena U                                                  */
/* Date         : 28-Mar-2016                                                 */
/* Call ID		: PLF2.0_17570                                               */
/********************************************************************************/ 
/* modified by			Date				Defect ID							*/
/* Veena U				08-Jun-2016			PLF2.0_18487						*/
/********************************************************************************/
/* Modified by : Jeya Latha K/Ganesh Prabhu S	for callid TECH-7349				*/
/* Modified on : 14-03-2017				 											*/
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and New Feature Organization chart */
/***********************************************************************************/
/* Modified by : Ganesh Prabhu S/Ranjitha R      for callid  TECH-10118            */
/* Modified on : 30-May-2017                                                       */
/* Description : Platform Feature Release                                          */
/***********************************************************************************************/
/*Modified by	: Jeya Latha K   Defect ID: TECH-20897      On: 30-Apr-2018					   */
/* Modified by :  Jeya Latha K	 Date: 25-Jul-2019          Defect ID: TECH-36371			   */
/***********************************************************************************************/
/* Modified by :  Venkatesan K	 Date: 13-Nov-2019          Defect ID: TECH-40034			   */
/* Description :  Allows the state control and callout option for glance screen and creates    */
/*					the state control and its depedency if user selected the option in 
					specify layout for glance screen.                                          */
/* Modified by : Priyadharshini U/Rajeswari M       Date: 29-Jan-2020  Defect ID : TECH-42483  */
/* Modified by : Priyadharshini U/Jeya Latha K		Date: 27-Feb-2020  Defect ID : TECH-43307  */
/***********************************************************************************************/
/* Modified by	:	Ponmalar A		 														   */
/* Modified on	:	08/07/2022				 												   */
/* Defect ID	:	Tech-70687																   */
/* Description	:	Tool and Toolbars														   */
/***********************************************************************************************/
/* Modified by : Ponmalar A						Date: 29-Aug-2022       Defect ID : Tech-72114 */
/***********************************************************************************************/
/* Modified by			: Ponmalar A														   */
/* Date					: 29-Sep-2022														   */
/* Defect ID			: TECH-73216														   */
/***********************************************************************************************/
/* Modified by : Ponmalar A						Date: 02-Dec-2022       Defect ID : Tech-75230 */
/***********************************************************************************************/
CREATE PROCEDURE ep_layout_sp_savfrm_hsv  
@ctxt_language_in             engg_ctxt_language,  
@ctxt_ouinstance_in           engg_ctxt_ouinstance,  
@ctxt_service_in              engg_ctxt_service,  
@ctxt_user_in                 engg_ctxt_user,  
@engg_act_descr_in            engg_description,  
@engg_att_ui_cap_align_in     engg_name,  
@engg_att_ui_format_in        engg_description,  
@engg_att_ui_trail_bar_in     engg_name,  
@engg_att_ui_type_in          engg_name,  
@engg_component_in            engg_description,  
@engg_customer_name_in        engg_name,  
@engg_process_descr_in        engg_description,  
@engg_project_name_in         engg_name,  
@engg_req_no_in               engg_name,  
@engg_tab_height_in           engg_length,  
@engg_ui_descr_in             engg_description,  
@guid_in             engg_guid,  
@engg_att_ui_grid_type		engg_Type,  
@State_Processing			engg_name,  
@engg_callout_type			engg_Type, -- added for request id: PNR2.0_1790  
@ezee_taskpane				engg_name, -- Added for the Bug ID:PNR2.0_30127  
@engg_tab_type				engg_name, --Input  
@engg_isdevice            	engg_flag, --Input 
@engg_smarthide           	engg_flag, --Input 
@engg_ilbotitle           	engg_flag, --Input 
@engg_hdrpersonalisation	engg_flag,
@engg_syst_excl_tab_ind		engg_flag,
@engg_phone               	engg_flag, --Input 
@engg_tablet 	engg_flag, --Input 
@engg_desk_brw            	engg_flag, --Input 
@engg_tab_style           	engg_name, --Input 
@engg_ui_layout           	engg_name, --Input 
@engg_ui_laycon           	engg_description, --Input 
@engg_tab_hdr_pos         	engg_name, --Input 
@engg_hide_print          	engg_flag, --Input 
@engg_tab_rotate			engg_name, --Input 
@engg_hide_default			engg_flag, 
@engg_uisubtype				engg_name,
@engg_nativeapp				engg_flag,
@engg_popup_close			engg_flag,
-- Added for Request TECH-43307 Starts
@engg_titlebar_search       engg_flag,			
-- Added for Request TECH-43307 Ends
--Tech-70687
@engg_att_sidebar			engg_seqno,
@engg_att_docked			engg_name,
@engg_lefttb				engg_seqno,
@engg_righttb				engg_seqno,
@engg_toptb					engg_seqno,
@engg_bottomtb				engg_seqno,
--Tech-70687
@PullToRefresh				engg_seqno,	--TECH-75230
@m_errorid                	int output --To Return Execution Status
as  
begin  
  
set nocount on  
  
--declaration of temporary variables  
declare @ctxt_language                engg_ctxt_language  
declare @ctxt_ouinstance              engg_ctxt_ouinstance  
declare @ctxt_service                 engg_ctxt_service  
declare @ctxt_user                    engg_ctxt_user  
declare @engg_act_descr               engg_description  
declare @engg_att_ui_cap_align        engg_name  
declare @engg_att_ui_format           engg_description  
declare @engg_att_ui_trail_bar        engg_name  
declare @engg_att_ui_type             engg_name  
declare @engg_component               engg_description  
declare @engg_customer_name           engg_name  
declare @engg_process_descr           engg_description  
declare @engg_project_name            engg_name  
declare @engg_req_no                  engg_name  
declare @engg_tab_height              engg_length  
declare @engg_ui_descr                engg_description  
declare @guid                         engg_guid 

  
--temporary and formal parameters mapping  
select @ctxt_language                 = @ctxt_language_in  
select @ctxt_ouinstance				  = @ctxt_ouinstance_in  
select @ctxt_service                  = ltrim(rtrim(@ctxt_service_in))  
select @ctxt_user                     = ltrim(rtrim(@ctxt_user_in))  
select @engg_act_descr                = ltrim(rtrim(@engg_act_descr_in))  
select @engg_att_ui_cap_align         = ltrim(rtrim(@engg_att_ui_cap_align_in))  
select @engg_att_ui_format            = ltrim(rtrim(@engg_att_ui_format_in))  
select @engg_att_ui_trail_bar         = ltrim(rtrim(@engg_att_ui_trail_bar_in))  
select @engg_att_ui_type              = ltrim(rtrim(@engg_att_ui_type_in))  
select @engg_component                = ltrim(rtrim(@engg_component_in))  
select @engg_customer_name            = ltrim(rtrim(@engg_customer_name_in))  
select @engg_process_descr            = ltrim(rtrim(@engg_process_descr_in))  
select @engg_project_name             = ltrim(rtrim(@engg_project_name_in))  
select @engg_req_no                   = ltrim(rtrim(@engg_req_no_in))  
select @engg_tab_height               = @engg_tab_height_in  
select @engg_ui_descr                 = ltrim(rtrim(@engg_ui_descr_in))  
select @guid                          = ltrim(rtrim(@guid_in))  
select @engg_att_ui_grid_type         = ltrim(rtrim(@engg_att_ui_grid_type))  
select @State_Processing			  = ltrim(rtrim(@State_Processing))  
select @engg_callout_type			= ltrim(rtrim(@engg_callout_type)) -- added for request id: PNR2.0_1790  
select @ezee_taskpane				= ltrim(rtrim(@ezee_taskpane)) -- Added for the Bug ID:PNR2.0_30127  
select @engg_tab_type				= LTRIM(RTRIM(@engg_tab_type))
Select @engg_isdevice				= ltrim(rtrim(@engg_isdevice))
Select @engg_smarthide				= ltrim(rtrim(@engg_smarthide))
Select @engg_ilbotitle				= ltrim(rtrim(@engg_ilbotitle))
Select @engg_hdrpersonalisation     = ltrim(rtrim(@engg_hdrpersonalisation))
Select @engg_syst_excl_tab_ind		= ltrim(rtrim(@engg_syst_excl_tab_ind))
Select @engg_phone					= ltrim(rtrim(@engg_phone))
Select @engg_tablet					= ltrim(rtrim(@engg_tablet))
Select @engg_desk_brw				= ltrim(rtrim(@engg_desk_brw))
Select @engg_tab_style				= ltrim(rtrim(@engg_tab_style))
Select @engg_tab_rotate				= LTRIM(RTRIM(@engg_tab_rotate))
Select @engg_hide_default			= LTRIM(rtrim(@engg_hide_default))	
Select @engg_uisubtype				= LTRIM(rtrim(@engg_uisubtype))	
Select @engg_nativeapp				= LTRIM(rtrim(@engg_nativeapp))	
Select @engg_popup_close			= LTRIM(rtrim(@engg_popup_close))
-- Added for Request TECH-43307 Ends
Select @engg_titlebar_search		= LTRIM(rtrim(@engg_titlebar_search))	
-- Added for Request TECH-43307 Ends

--null checking  
if @ctxt_language = -915  
select @ctxt_language = null  
  
if @ctxt_ouinstance = -915  
select @ctxt_ouinstance = null  
  
if @ctxt_service = '~#~'  
select @ctxt_service = null  
  
if @ctxt_user = '~#~'  
select @ctxt_user = null  
  
if @engg_act_descr = '~#~'  
select @engg_act_descr = null  
  
if @engg_att_ui_cap_align = '~#~'  
select @engg_att_ui_cap_align = null  
  
if @engg_att_ui_format = '~#~'  
select @engg_att_ui_format = null  
  
if @engg_att_ui_trail_bar = '~#~'  
select @engg_att_ui_trail_bar = null  
  
if @engg_att_ui_type = '~#~'  
select @engg_att_ui_type = null  
  
if @engg_component = '~#~'  
select @engg_component = null  
  
if @engg_customer_name = '~#~'  
select @engg_customer_name = null  
  
if @engg_process_descr = '~#~'  
select @engg_process_descr = null  
  
if @engg_project_name = '~#~'  
select @engg_project_name = null  
  
if @engg_req_no = '~#~'  
select @engg_req_no = null  
  
if @engg_tab_height = -915  
select @engg_tab_height = null  
  
if @engg_ui_descr = '~#~'  
select @engg_ui_descr = null  
  
if @guid = '~#~'  
select @guid = null  
  
if @engg_att_ui_grid_type = '~#~'  
select @engg_att_ui_grid_type = null  
  
if @State_Processing = '~#~'  
select @State_Processing = null  
  
-- added for request id: PNR2.0_1790  
if @engg_callout_type = '~#~'  
select @engg_callout_type = null  
  
IF @engg_hdrpersonalisation = '~#~' 
	Select @engg_hdrpersonalisation = null 
	

IF @engg_syst_excl_tab_ind = '~#~' 
	Select @engg_syst_excl_tab_ind = null 
	
  
-- Added for the Bug ID:PNR2.0_30127  
if @ezee_taskpane = '~#~'  
select @ezee_taskpane = null  
  
IF @engg_tab_type = '~#~'  
Select @engg_tab_type = null  

IF @engg_isdevice = '~#~' 
		Select @engg_isdevice = null  

IF @engg_smarthide = '~#~' 
		Select @engg_smarthide = null  

IF @engg_ilbotitle = '~#~' 
		Select @engg_ilbotitle = null 

IF @engg_ui_layout = '~#~' 
	Select @engg_ui_layout = null  

IF @engg_ui_laycon = '~#~' 
	Select @engg_ui_laycon = null  

IF @engg_tab_hdr_pos = '~#~' 
	Select @engg_tab_hdr_pos = null  

IF @engg_hide_print = '~#~' 
	Select @engg_hide_print = null  
	
If @engg_tab_rotate	= '~#~'
	Select @engg_tab_rotate	= null	

If @engg_hide_default			= -915
	Select	@engg_hide_default		= NULL

If @engg_uisubtype	= '~#~'
	Select @engg_uisubtype	= null
			
If @engg_phone	= '~#~'
	Select @engg_phone	= null	

If @engg_tablet	= '~#~'
	Select @engg_tablet	= null	

		-- Added for PLF2.0_14096 Starts

if @engg_isdevice = '1'
	select @engg_isdevice = 'Y'
else 
	select @engg_isdevice = 'N'
		
if @engg_smarthide = '1'
	select @engg_smarthide = 'Y'
else
	select @engg_smarthide = 'N'
		
if @engg_ilbotitle = '1'
	select @engg_ilbotitle = 'Y'
else
	select @engg_ilbotitle = 'N'
		
if @engg_hdrpersonalisation = '1'
	select @engg_hdrpersonalisation = 'Y'
else
	select @engg_hdrpersonalisation = 'N'

-- Added for PLF2.0_14096 ends
if @engg_syst_excl_tab_ind = '1'
	select @engg_syst_excl_tab_ind = 'Y'
else
	select @engg_syst_excl_tab_ind = 'N'
  
if @engg_hide_print = '1'
	select @engg_hide_print = 'Y'
else 
	select @engg_hide_print = 'N'

if @engg_hide_default = '1'
	select @engg_hide_default = 'Y'
else 
	select @engg_hide_default = 'N'

IF @engg_desk_brw = '-915' 
	Select @engg_desk_brw = null  

IF @engg_tab_style = '~#~' 
	Select @engg_tab_style = null  
		
if @engg_nativeapp = '1'
	select @engg_nativeapp = 'Y'
else 
	select @engg_nativeapp = 'N'

if @engg_popup_close = '1'
	select @engg_popup_close = 'Y'
else 
	select @engg_popup_close = 'N'

-- Added for Request TECH-43307 Starts
if @engg_titlebar_search = '1'
	select @engg_titlebar_search = 'Y'
else 
	select @engg_titlebar_search = 'N'		
-- Added for Request TECH-43307 Ends

--Tech-70687
if @engg_att_sidebar = -915
	select @engg_att_sidebar = NULL

If @engg_att_docked			= '~#~'
	Select	@engg_att_docked		= NULL

if @engg_lefttb = -915
	select @engg_lefttb = NULL

if @engg_righttb = -915
	select @engg_righttb = NULL

if @engg_toptb = -915
	select @engg_toptb = NULL

if @engg_bottomtb = -915
	select @engg_bottomtb = NULL
--Tech-70687

if @PullToRefresh = -915
	select @PullToRefresh = NULL

 --errors mapped  
declare @msg				engg_description ,  
		@tmp_comp_name		engg_name ,  
		@tmp_proc			engg_name ,  
		@tmp_acty_name		engg_name ,  
		@tmp_ui_name		engg_name ,  
		@tmp_ref_comp_name  engg_name ,  
		@tmp_ref_acty_name  engg_name ,  
		@tmp_ref_ui_name	engg_name ,  
		@tmp_ref_comp_desc  engg_name ,  
		@tmp_ref_acty_desc  engg_name ,  
		@tmp_ref_ui_desc	engg_name ,  
		@tmp_ui_type		engg_name ,  
		@engg_base_req_no	engg_name  ,
		@devicetype			engg_name,
		@DeviceType_old		engg_name,
		@phone_in			engg_name,
		@tablet_in			engg_name,
		@len2				engg_seqno,
		@len1 				engg_seqno,
		@XYCoordinates		engg_description,
		@ColumnLayWidth		engg_description,
		@Ctxt_role			engg_name
  
select	@engg_base_req_no	= 'BASE',  
		@ctxt_role			=	NULL
  
--select process name for description  
select	@tmp_proc		= rtrim(process_name)  
from	ep_ui_req_dtl (nolock)  
where	customer_name	= rtrim(@engg_customer_name)  
and		project_name	= rtrim(@engg_project_name)  
and		req_no			= rtrim(@engg_req_no)  
and		process_descr	= rtrim(@engg_process_descr)  
  
--select component name for description  
select	@tmp_comp_name  = rtrim(component_name)  
from	ep_ui_req_dtl (nolock)  
where	customer_name	= rtrim(@engg_customer_name)  
and		project_name	= rtrim(@engg_project_name)  
and		req_no			= rtrim(@engg_req_no)  
and		process_name	= rtrim(@tmp_proc)  
and		component_descr = rtrim(@engg_component)  
  
--select activity name for description  
select	@tmp_acty_name  = rtrim(activity_name)  
from	ep_ui_req_dtl (nolock)  
where	customer_name	= rtrim(@engg_customer_name)  
and		project_name	= rtrim(@engg_project_name)  
and		req_no			= rtrim(@engg_req_no)  
and		process_name	= rtrim(@tmp_proc)  
and		component_name  = rtrim(@tmp_comp_name)  
and		activity_descr	= rtrim(@engg_act_descr)  
  
--select UI name for description  
select	@tmp_ui_name	= rtrim(ui_name)  
from	ep_ui_req_dtl (nolock)  
where	customer_name	= rtrim(@engg_customer_name)  
and		project_name	= rtrim(@engg_project_name)  
and		req_no			= rtrim(@engg_req_no)  
and		process_name	= rtrim(@tmp_proc)  
and		component_name  = rtrim(@tmp_comp_name)  
and		activity_name	= rtrim(@tmp_acty_name)  
and		ui_descr		= rtrim(@engg_ui_descr)  


IF ISNULL(@engg_desk_brw, 0) = 0 AND ISNULL(@engg_phone,0) = 0 AND ISNULL(@Engg_tablet,0) = 0
BEGIN
	Raiserror('Please Select any one of the option in ''Applicable Device Type''.' ,16,1)
	RETURN
END
/*
IF ISNULL(@engg_desk_brw, 0) = 1 
BEGIN
	Raiserror('Please use Glance for New UI creation.' ,16,1)
	RETURN
END
*/

--code commented by 11536 for the defect id TECH-40034
---- NGPLF Changes Starts
--IF EXISTS (	SELECT 'X'
--			FROM	ep_ui_mst (NOLOCK)
--			WHERE	customer_name	= @engg_customer_name
--			AND		project_name	= @engg_project_name
--			AND		process_name	= @tmp_proc
--			AND		component_name	= @tmp_comp_name
--			AND		activity_name	= @tmp_acty_name
--			AND		ui_name			= @tmp_ui_name
--			AND		ISNULL(ISGlance, 'N') = 'Y')
--BEGIN
--	EXEC ngplf_validate_specifylayout
--		@ctxt_language,			@ctxt_ouinstance,		@ctxt_user,				@Ctxt_role,			@engg_customer_name,
--		@engg_project_name,		@tmp_proc,				@tmp_comp_name,			@tmp_acty_name,		@tmp_ui_name,
--		'',						'',						'F'				
--END		
---- NGPLF Changes ends

if exists  
(  
select 'x'  
from ep_ui_req_dtl(nolock)  
where  customer_name = @engg_customer_name  
and  project_name    = @engg_project_name  
and  req_no          = @engg_req_no  
and  process_name    = @tmp_proc  
and  component_name  = @tmp_comp_name  
and  activity_name = @tmp_acty_name  
and  ui_name   = @tmp_ui_name  
and  req_status  = 'P'  
)  
begin  
select @msg = 'Cannot be saved as Selected UI is in published status'  
exec engg_error_sp  
'ep_layout_sp_savfrm_hsv',  
1,  
@msg,  
@ctxt_language,  
@ctxt_ouinstance,  
@ctxt_service,  
@ctxt_user,  
'',  
'',  
'',  
'',  
@m_errorid output  
if @m_errorid <> 0  
return  
end  
  
/*check whether activity is selected. if not display error message*/  
if rtrim(@engg_act_descr) is null  
begin  
select  @msg = 'select activity'  
exec engg_error_sp 'ep_layout_sp_savfrm_hsv',  
1,  
@msg,  
@ctxt_language,  
@ctxt_ouinstance,  
@ctxt_service,  
@ctxt_user,  
'',  
'',  
'',  
'',  
@m_errorid  output  
return  
end  
  
/*check whether ui is selected. if not display error message*/  
if rtrim(@engg_ui_descr) is null  
begin  
select  @msg = 'select user interface'  
exec engg_error_sp 'ep_layout_sp_savfrm_hsv',  
2,  
@msg,  
@ctxt_language,  
@ctxt_ouinstance,  
@ctxt_service,  
@ctxt_user,  
'',  
'',  
'',  
'',  
@m_errorid  output  
return  
end  
  
-- code modified by shafina for PREVIEWPF204SYS_000017 (Unable to preview. Throws error: Main UI does not exist for this activity The activity has only one UI and the UI is shown as type Main in the UI format tab of specify layout.)  
if isnull(@engg_att_ui_type,'') = ''  
begin  
select  @msg = 'UI type cannot be blank'  
exec engg_error_sp 'ep_layout_sp_savfrm_hsv',  
8,  
@msg,  
@ctxt_language,  
@ctxt_ouinstance,  
@ctxt_service,  
@ctxt_user,  
'',  
'',  
'',  
'',  
@m_errorid  output  
return  
end  

IF EXISTS (	SELECT 'X'
			FROM	ep_ui_mst (NOLOCK)
			WHERE	customer_name	= @engg_customer_name
			AND		project_name	= @engg_project_name
			AND		process_name	= @tmp_proc
			AND		component_name	= @tmp_comp_name
			AND		activity_name	= @tmp_acty_name
			AND		ui_name			= @tmp_ui_name
			AND		ISNULL(ISGlance, 'N') = 'N')
BEGIN -- Glance Check Begin
  
-- Ramachandran.T 25 Dec 2003  
-- Request No in the where clause commented for the es_comp_param_mst_vw  
  
/*In an activity , only one UI must be of type 'Search' or 'Main'*/ -- Pending  
/*Check project level parameter uniformuiformat type uiformat.  
if the parameter is set as "do not allow modifications", display error message*/  
if exists (  select  'x'  
from	es_comp_param_mst_vw(nolock)  
--    from ep_proj_param_mst(nolock)  
where	customer_name   = rtrim(@engg_customer_name)  
and		project_name   = rtrim(@engg_project_name)  
--    and  req_no     = rtrim(@engg_req_no)  
and  process_name   = rtrim(@tmp_proc)  
and  component_name   = rtrim(@tmp_comp_name)  
and  upper(param_category) = 'UNIFORMUIFORMAT'  
and  upper(param_type)  = 'UIFORMAT'  
and  upper(current_value) = 'DO NOT ALLOW MODIFICATIONS'  
)  
begin  
select  @msg = 'ui format cannot be modified at ui level.'  
exec engg_error_sp 'ep_layout_sp_savfrm_hsv',  
3,  
@msg,  
@ctxt_language,  
@ctxt_ouinstance,  
@ctxt_service,  
@ctxt_user,  
'',  
'',  
'',  
'',  
@m_errorid  output  
return  
end  
  
select	@tmp_ui_type = rtrim(ui_type)  
from	ep_ui_mst (nolock)  
where	customer_name	= rtrim(@engg_customer_name)  
and		project_name	= rtrim(@engg_project_name)  
and		req_no			= rtrim(@engg_base_req_no)  
and		process_name	= rtrim(@tmp_proc)  
and		component_name	= rtrim(@tmp_comp_name)  
and		activity_name	= rtrim(@tmp_acty_name)  
and		ui_name			= rtrim(@tmp_ui_name)  
  
/* To check whether ui of type 'main' or 'search' already exists for the activity*/  
--code modified by Kanagavel A to avoid creation of ui types main and mainmodify under one activity
if exists
(
select 'x'
from	fw_bpt_activity_vw     A (nolock),
		fw_bpt_function_component_vw B (nolock)
where	a.CustomerID	= b.CustomerID
and		a.ProjectID		= b.ProjectID
and		a.BPID			= b.BPID
and		a.FunctionID	= b.FunctionID

and		b.CustomerID	= @engg_customer_name
and		b.ProjectID		= @engg_project_name
and		b.BPID			= @tmp_proc
and		b.componentname = @tmp_comp_name

and		a.CustomerID	= @engg_customer_name
and		a.ProjectID		= @engg_project_name
and		a.BPID			= @tmp_proc
and		a.activityid	= @tmp_acty_name
and		a.ActivityType	= 'USR' ) 
and		@tmp_acty_name <> 'IntegrationActivity'
--code modified for bug id:PNR2.0_9730
begin  
	if @tmp_ui_type <> @engg_att_ui_type
	begin 

		if rtrim(@engg_att_ui_type) in ('Main','Search','Mainmodify')  
		begin  
			if (  
			select  count('x')  
			from	ep_ui_mst(nolock)  
			where	customer_name	= rtrim(@engg_customer_name)  
			and		project_name	= rtrim(@engg_project_name)  
			and		req_no			= rtrim(@engg_base_req_no)  
			and		process_name	= rtrim(@tmp_proc)  
			and		component_name  = rtrim(@tmp_comp_name)  
			and		activity_name	= rtrim(@tmp_acty_name)  
			and		ui_type			in ('Main','Search','Mainmodify')  
			) > 1 
			begin  
				raiserror('Only one User Interface can be of type "Main" or "Search" or "MainModify" for a selected activity',16,1)    
				return  
			end  
		end  
	end  
end  
  
--Added by Shriram V on 09/08/05 for Bug Id : Platform_2.0.3.X_81  
 -- Below code commented for the defect id TECH-46577
--if isnull(@engg_tab_height,0) = 0  
  
--begin  
--select  @msg = 'Tab Height cannot be Null'  
--exec engg_error_sp 'ep_layout_sp_savfrm_hsv',  
--9,  
--@msg,  
--@ctxt_language,  
--@ctxt_ouinstance,  
--@ctxt_service,  
--@ctxt_user,  
--'',  
--'',  
--'',  
--'',  
--@m_errorid  output  
--return  
--end  
--End of Addition by Shriram V on 09/08/05 for Bug Id : Platform_2.0.3.X_81  
  
  
  
/*check component level parameter captionformat type uiformat.  
if the parameter is not set as "decide at ui level" display error message*/  
/*check component level parameter captionalign type uiformat.  
if the parameter is not set as "decide at ui level" display error message*/  
/*check component level parameter trailbar type uiformat.  
if the parameter is not set as "decide at ui level" display error message*/  
/*if any of the attribute is default*/  
  
--Anyway if the parameter is going to be "decide at ui level" - default only will be loaded  
--so no check is required for the above  
  
/* if (upper(@engg_att_ui_format) = 'DEFAULT' or upper(@engg_att_ui_trail_bar) = 'DEFAULT'  
or upper(@engg_att_ui_cap_align) = 'DEFAULT')  
begin  
  
  
-- get ref comp name , ref acty name , ref ui name for the selected ui  
select @tmp_ref_comp_name = isnull(rtrim(base_component_name),''),  
@tmp_ref_acty_name = isnull(rtrim(base_activity_name),''),  
@tmp_ref_ui_name = isnull(rtrim(base_ui_name),'')  
from ep_ui_mst (nolock)  
where customer_name  = rtrim(@engg_customer_name)  
and  project_name  = rtrim(@engg_project_name)  
and  req_no    = rtrim(@engg_base_req_no)  
and  process_name  = rtrim(@tmp_proc)  
and  component_name  = rtrim(@tmp_comp_name)  
and  activity_name  = rtrim(@tmp_acty_name)  
and  ui_name    = rtrim(@tmp_ui_name)  
  
if upper(@engg_att_ui_format) = 'DEFAULT'  
begin  
select  @engg_att_ui_format = rtrim(ui_format)  
from  ep_ui_mst(nolock)  
where customer_name  = rtrim(@engg_customer_name)  
and  project_name  = rtrim(@engg_project_name)  
and  req_no    = rtrim(@engg_base_req_no)  
and  process_name  = rtrim(@tmp_proc)  
and  component_name  = rtrim(@tmp_ref_comp_name)  
and  activity_name  = rtrim(@tmp_ref_acty_name)  
and  ui_name    = rtrim(@tmp_ref_ui_name)  
end  
  
if upper(@engg_att_ui_cap_align) = 'DEFAULT'  
begin  
select  @engg_att_ui_cap_align = rtrim(caption_alignment)  
from  ep_ui_mst(nolock)  
where customer_name   = rtrim(@engg_customer_name)  
and  project_name   = rtrim(@engg_project_name)  
and  req_no     = rtrim(@engg_base_req_no)  
and  process_name   = rtrim(@tmp_proc)  
and  component_name   = rtrim(@tmp_ref_comp_name)  
and  activity_name   = rtrim(@tmp_ref_acty_name)  
and  ui_name     = rtrim(@tmp_ref_ui_name)  
end  
  
if upper(@engg_att_ui_trail_bar) = 'DEFAULT'  
begin  
select  @engg_att_ui_trail_bar = rtrim(trail_bar)  
from  ep_ui_mst(nolock)  
where customer_name   = rtrim(@engg_customer_name)  
and  project_name   = rtrim(@engg_project_name)  
and  req_no     = rtrim(@engg_base_req_no)  
and  process_name   = rtrim(@tmp_proc)  
and  component_name   = rtrim(@tmp_ref_comp_name)  
and  activity_name   = rtrim(@tmp_ref_acty_name)  
and  ui_name     = rtrim(@tmp_ref_ui_name)  
end  
end*/  
  
/*If Default is choosen in any of the Combos then get it from Project Param Master table  
and then save it.*/  
  
  
-- Ramachandran.T 25 Dec 2003  
-- Request No in the where clause commented for the es_comp_param_mst_vw  
  
/*For UI FORMAT COMBO*/  
if upper(rtrim(@engg_att_ui_format)) = 'DEFAULT'  
begin  
if (  
select count('x')  
from es_comp_param_mst_vw(nolock)  
--  from ep_proj_param_mst (nolock)  
where customer_name  = rtrim(@engg_customer_name)  
and  project_name = rtrim(@engg_project_name)  
--   and  req_no   = rtrim(@engg_base_req_no)  
and  process_name = rtrim(@tmp_proc)  
and  component_name = rtrim(@tmp_comp_name)  
and  param_category = 'CAPTIONFORMAT'  
and  param_type  = 'UIFORMAT'  
) = 0  
begin  
select  @msg = 'There is no entry in the component parameters'  
exec engg_error_sp 'ep_layout_sp_savfrm_hsv',  
9,  
@msg,  
@ctxt_language,  
@ctxt_ouinstance,  
@ctxt_service,  
@ctxt_user,  
'',  
'',  
'',  
'',  
@m_errorid  output  
return  
end  
else  
begin  
-- Ramachandran.T 25 Dec 2003  
-- Request No in the where clause commented for the es_comp_param_mst_vw  
  
select	@engg_att_ui_format = rtrim(current_value)  
from	es_comp_param_mst_vw(nolock)  
--  from ep_proj_param_mst (nolock)  
where	customer_name	= rtrim(@engg_customer_name)  
and		project_name	= rtrim(@engg_project_name)  
--   and  req_no   = rtrim(@engg_base_req_no)  
and		process_name	= rtrim(@tmp_proc)  
and		component_name	= rtrim(@tmp_comp_name)  
and		param_category	= 'CAPTIONFORMAT'  
and		param_type		= 'UIFORMAT'  
end  
end  
/*For CAPTION ALIGNMENT COMBO*/  
if upper(rtrim(@engg_att_ui_cap_align)) = 'DEFAULT'  
begin  
  
-- Ramachandran.T 25 Dec 2003  
-- Request No in the where clause commented for the es_comp_param_mst_vw  
  
if (  
select count('x')  
from es_comp_param_mst_vw(nolock)  
--  from ep_proj_param_mst (nolock)  
where customer_name  = rtrim(@engg_customer_name)  
and  project_name = rtrim(@engg_project_name)  
--   and  req_no   = rtrim(@engg_base_req_no)  
and  process_name = rtrim(@tmp_proc)  
and  component_name = rtrim(@tmp_comp_name)  
and  param_category = 'CAPTIONALIGN'  
and  param_type  = 'UIFORMAT'  
) = 0  
begin  
select  @msg = 'There is no entry in the component parameters'  
exec engg_error_sp 'ep_layout_sp_savfrm_hsv',  
10,  
@msg,  
@ctxt_language,  
@ctxt_ouinstance,  
@ctxt_service,  
@ctxt_user,  
'',  
'',  
'',  
'',  
@m_errorid  output  
return  
end  
else  
begin  
  
-- Ramachandran.T 25 Dec 2003  
-- Request No in the where clause commented for the es_comp_param_mst_vw  
  
select	@engg_att_ui_cap_align = rtrim(current_value)  
from	es_comp_param_mst_vw(nolock)  
--  from ep_proj_param_mst (nolock)  
where	customer_name	= rtrim(@engg_customer_name)  
and		project_name	= rtrim(@engg_project_name)  
--   and  req_no   = rtrim(@engg_base_req_no)  
and		process_name	= rtrim(@tmp_proc)  
and		component_name	= rtrim(@tmp_comp_name)  
and		param_category	= 'CAPTIONALIGN'  
and		param_type		= 'UIFORMAT'  
end  
end  
  
/*FOR TRAILBAR COMBO*/  
if upper(rtrim(@engg_att_ui_trail_bar)) = 'DEFAULT'  
begin  
-- Ramachandran.T 25 Dec 2003  
-- Request No in the where clause commented for the es_comp_param_mst_vw  
  
if (  
select count('x')  
from es_comp_param_mst_vw(nolock)  
--  from ep_proj_param_mst (nolock)  
where customer_name  = rtrim(@engg_customer_name)  
and  project_name = rtrim(@engg_project_name)  
--   and  req_no   = rtrim(@engg_base_req_no)  
and  process_name = rtrim(@tmp_proc)  
and  component_name = rtrim(@tmp_comp_name)  
and  param_category = 'TRAILBAR'  
and  param_type  = 'UIFORMAT'  
) = 0  
begin  
select  @msg = 'There is no entry in the component parameters'  
exec engg_error_sp 'ep_layout_sp_savfrm_hsv',  
10,  
@msg,  
@ctxt_language,  
@ctxt_ouinstance,  
@ctxt_service,  
@ctxt_user,  
'',  
'',  
'',  
'',  
@m_errorid  output  
return  
end  
else  
begin  
  
-- Ramachandran.T 25 Dec 2003  
-- Request No in the where clause commented for the es_comp_param_mst_vw  
  
select	@engg_att_ui_trail_bar = rtrim(current_value)  
from	es_comp_param_mst_vw(nolock)  
--  from ep_proj_param_mst (nolock)  
where	customer_name	= rtrim(@engg_customer_name)  
and		project_name	= rtrim(@engg_project_name)  
--   and  req_no   = rtrim(@engg_base_req_no)  
and		process_name	= rtrim(@tmp_proc)  
and		component_name	= rtrim(@tmp_comp_name)  
and		param_category	= 'TRAILBAR'  
and		param_type		= 'UIFORMAT'  
end  
end  
  
/*get the quick codes for the attributes*/  
if lower(ltrim(rtrim(@engg_att_ui_format))) = ltrim(rtrim('controls beside captions'))  
select @engg_att_ui_format = 'bes'  
else  
if lower(ltrim(rtrim(@engg_att_ui_format))) = ltrim(rtrim('controls under captions'))  
select @engg_att_ui_format = 'und'  
--TECH-72114
else		
if lower(ltrim(rtrim(@engg_att_ui_format))) = ltrim(rtrim('Top Inner'))  
select @engg_att_ui_format = 'top'  
--TECH-72114
  
  
if lower(ltrim(rtrim(@engg_att_ui_cap_align))) = ltrim(rtrim('center'))  
select @engg_att_ui_cap_align = 'cent'  
  
if lower(ltrim(rtrim(@engg_att_ui_trail_bar))) = ltrim(rtrim('bottom'))  
select @engg_att_ui_trail_bar = 'bott'  
  
/* added by Ramanujam on nov-30-2005 */  
  
if lower(ltrim(rtrim(@engg_att_ui_grid_type))) = ltrim(rtrim('far point'))  
select @engg_att_ui_grid_type = 'fp'  
else  
if lower(ltrim(rtrim(@engg_att_ui_grid_type))) = ltrim(rtrim('htm'))  
select @engg_att_ui_grid_type = 'htm'  
  
Select  distinct	@engg_tab_style = parameter_code
from	ep_device_quick_code_met (nolock)
Where	parameter_type	= 'TabStyle'
and		parameter_text	 = @engg_tab_style
  
-- Validation added for TECH-20897 Starts
If	isnull(@engg_tab_style,'') = 'Carousel' and isnull(@Engg_tablet,0) <> 1 and isnull(@engg_phone, 0) <> 1
Begin
	Raiserror ('Tab Style ''Carousel'' is applicable only for Tablet and Phone.',16,4)
	Return
End
-- Validation added for TECH-20897 Ends

-- Validation added for Jan2020 Starts
If	isnull(@engg_titlebar_search,'N') = 'Y' and (isnull(@Engg_tablet,0) < 1 and isnull(@engg_phone, 0) < 1)
Begin
	Raiserror ('''Tile Bar Search'' is applicable only for Tablet and Phone.',16,4)
	Return
End
-- Validation added for TECH-20897 Ends
If @engg_ui_layout not in ( 'absolute','Column') and isnull(@engg_ui_laycon,'') <> ''
begin 
	Raiserror ('Layout Configuration Can have values only when Page Layout is "Absolute" or "Column".',16,4)
	Return
End
	
If @engg_ui_layout in ( 'absolute','Column')  and isnull(@engg_ui_laycon,'') = ''
begin 
	Raiserror ('Layout Configuration needs to have value when Page Layout is "Column" or "Absolute".',16,4)
	Return
End

if @engg_ui_layout = 'absolute'
Begin
       
if @engg_ui_layout = 'absolute' and isnull(@engg_ui_laycon,'') not like '%~%' 
Begin
	Raiserror('For layout configuration, X and Y Coordinates needs to be given with Delimiters.(Ex: 50~80).',16,4)
	Return
End

if isnumeric(isnull(LEFT(@engg_ui_laycon, CHARINDEX('~', @engg_ui_laycon) - 1), -915)) = 0  or 
isnumeric(isnull(RIGHT(@engg_ui_laycon, LEN(@engg_ui_laycon) - CHARINDEX('~', @engg_ui_laycon)),-915) )= 0 
Begin
	Raiserror('For layout configuration, X and Y Coordinates needs to be integer value greater than 0 given with Delimiters.(Ex: 50~80).',16,4)
	Return
End

SELECT @len1 = convert(int,LEFT(@engg_ui_laycon, CHARINDEX('~', @engg_ui_laycon) - 1)) ,
       @len2 = convert(int, RIGHT(@engg_ui_laycon, LEN(@engg_ui_laycon) - CHARINDEX('~', @engg_ui_laycon)))



if @engg_ui_layout = 'absolute' and (@len1 < 1 or @len2	< 1)
Begin 
	Raiserror('For layout configuration, X and Y Coordinates needs to be given with Delimiters.(Ex: 50~80).',16,4)
    Return
End 
End

If @engg_ui_layout = 'absolute'
Select @XYCoordinates = isnull(@engg_ui_laycon,'') 
	

If @engg_ui_layout = 'Column'
Select @ColumnLayWidth = isnull(@engg_ui_laycon,'') 

Select	@engg_tab_hdr_pos = parameter_code
from	ep_device_quick_code_met (nolock)
Where	parameter_type	= 'HeaderPosition'
and		parameter_text	=  @engg_tab_hdr_pos

Select	@engg_ui_layout	= parameter_code
from	ep_device_quick_code_met (nolock)
Where	parameter_type	= 'UILayout'
and		parameter_text	=  @engg_ui_layout


Select	@engg_tab_rotate= parameter_code
from	ep_device_quick_code_met (nolock)
Where	parameter_type	= 'TabRotation'
and		parameter_text	=  @engg_tab_rotate

---------

  declare @engg_desk_brwser engg_name
  
  
/*SmartHide,Ilbotitle,Isdevice*/
if @engg_desk_brw = 1 Select @engg_desk_brwser = 'Y'
if @engg_desk_brw = 0 Select @engg_desk_brwser= 'N'

Select  @devicetype = ''
--if isnull(@engg_phone,0) <> 0    and isnull(@engg_tablet,0) <> 0
--select @devicetype = 'B'
--if isnull(@engg_phone,0) <> 0    and isnull(@engg_tablet,0) = 0
--select @devicetype = 'P'
--if isnull(@engg_tablet,0) <> 0  and  isnull(@engg_phone,0) = 0 
--select @devicetype = 'T'

if isnull(@engg_phone,'') = '1'    and isnull(@engg_tablet,'') = '1'
select @devicetype = 'B'
if isnull(@engg_phone,'') = '1'    and isnull(@engg_tablet,'') = '0'
select @devicetype = 'P'
if isnull(@engg_tablet,'') = '1'  and  isnull(@engg_phone,'') = '0' 
select @devicetype = 'T'


Select  @devicetype_old		= isnull(devicetype,'')
from ep_ui_mst(nolock)
where	customer_name		= rtrim(@engg_customer_name)
and		project_name		= rtrim(@engg_project_name)
and		req_no				= rtrim(@engg_base_req_no)
and		process_name		= rtrim(@tmp_proc)
and		component_name		= rtrim(@tmp_comp_name)
and		activity_name		= rtrim(@tmp_acty_name)
and		ui_name				= rtrim(@tmp_ui_name)

if isnull(@devicetype_old,'') = ''
Begin
Select @phone_in	= @engg_phone,
@tablet_in	= @engg_tablet
End

If @devicetype_old = @devicetype 
begin
Select @phone_in = null,
@tablet_in	= null
End

if (@devicetype_old = 'P' and 	@devicetype = 'B') or (@devicetype_old = 'P' and 	@devicetype = 'T')
Begin
Select @phone_in = null,
@tablet_in	= @engg_tablet
End

if (@devicetype_old = 'T' and 	@devicetype = 'B')or (@devicetype_old = 'T' and 	@devicetype = 'P')
Begin
Select @phone_in = @engg_phone,
@tablet_in	= null
End


if (@devicetype_old = 'B' and 	@devicetype in( 'T','')) or (@devicetype_old = 'P' and 	@devicetype in('T', ''))
Begin
Select @phone_in = null,
@tablet_in	= null
where  (@devicetype_old = 'B' and 	@devicetype in( 'T','')) or (@devicetype_old = 'P' and 	@devicetype = '')
---Delete the entries in Phone tables--

Delete	from ep_phone_column_group_mapping
where	customer_name	= rtrim(@engg_customer_name)
and		project_name	= rtrim(@engg_project_name)
and		req_no			= rtrim(@engg_base_req_no)
and		process_name	= rtrim(@tmp_proc)
and		component_name	= rtrim(@tmp_comp_name)
and		activity_name	= rtrim(@tmp_acty_name)
and		ui_name			= rtrim(@tmp_ui_name)

Delete	from ep_phone_columngroup
where	customer_name	= rtrim(@engg_customer_name)
and		project_name	= rtrim(@engg_project_name)
and		req_no			= rtrim(@engg_base_req_no)
and		process_name	= rtrim(@tmp_proc)
and		component_name	= rtrim(@tmp_comp_name)
and		activity_name	= rtrim(@tmp_acty_name)
and		ui_name			= rtrim(@tmp_ui_name)

Delete	from ep_phone_grid_dtl
where	customer_name	= rtrim(@engg_customer_name)
and		project_name	= rtrim(@engg_project_name)
and		req_no			= rtrim(@engg_base_req_no)
and		process_name	= rtrim(@tmp_proc)
and		component_name	= rtrim(@tmp_comp_name)
and		activity_name	= rtrim(@tmp_acty_name)
and		ui_name			= rtrim(@tmp_ui_name)

Delete	from ep_phone_control_dtl
where	customer_name	= rtrim(@engg_customer_name)
and		project_name	= rtrim(@engg_project_name)
and		req_no			= rtrim(@engg_base_req_no)
and		process_name	= rtrim(@tmp_proc)
and		component_name	= rtrim(@tmp_comp_name)
and		activity_name	= rtrim(@tmp_acty_name)
and		ui_name			= rtrim(@tmp_ui_name)

Delete	from ep_phone_section_dtl
where	customer_name	= rtrim(@engg_customer_name)
and		project_name	= rtrim(@engg_project_name)
and		req_no			= rtrim(@engg_base_req_no)
and		process_name	= rtrim(@tmp_proc)
and		component_name	= rtrim(@tmp_comp_name)
and		activity_name	= rtrim(@tmp_acty_name)
and		ui_name			= rtrim(@tmp_ui_name)

Delete	from ep_phone_page_dtl
where	customer_name	= rtrim(@engg_customer_name)
and		project_name	= rtrim(@engg_project_name)
and		req_no			= rtrim(@engg_base_req_no)
and		process_name	= rtrim(@tmp_proc)
and		component_name	= rtrim(@tmp_comp_name)
and		activity_name	= rtrim(@tmp_acty_name)
and		ui_name			= rtrim(@tmp_ui_name)

Delete	from ep_phone_mst
where	customer_name	= rtrim(@engg_customer_name)
and		project_name	= rtrim(@engg_project_name)
and		req_no			= rtrim(@engg_base_req_no)
and		process_name	= rtrim(@tmp_proc)
and		component_name	= rtrim(@tmp_comp_name)
and		activity_name	= rtrim(@tmp_acty_name)
and		ui_name			= rtrim(@tmp_ui_name)


End

if (@devicetype_old = 'B' and 	@devicetype in( 'P','')) or (@devicetype_old = 'T' and 	@devicetype in('P', ''))
Begin
Select @phone_in = null,
@tablet_in	= null
where  (@devicetype_old = 'B' and 	@devicetype in( 'P','')) or (@devicetype_old = 'T' and 	@devicetype =  '')
---Delete the entries in Tablet tables--

Delete	from ep_tablet_column_group_mapping
where	customer_name	= rtrim(@engg_customer_name)
and		project_name	= rtrim(@engg_project_name)
and		req_no			= rtrim(@engg_base_req_no)
and		process_name	= rtrim(@tmp_proc)
and		component_name	= rtrim(@tmp_comp_name)
and		activity_name	= rtrim(@tmp_acty_name)
and		ui_name			= rtrim(@tmp_ui_name)

Delete	from ep_tablet_columngroup
where	customer_name	= rtrim(@engg_customer_name)
and		project_name	= rtrim(@engg_project_name)
and		req_no			= rtrim(@engg_base_req_no)
and		process_name	= rtrim(@tmp_proc)
and		component_name	= rtrim(@tmp_comp_name)
and		activity_name	= rtrim(@tmp_acty_name)
and		ui_name			= rtrim(@tmp_ui_name)

Delete	from ep_tablet_grid_dtl
where	customer_name	= rtrim(@engg_customer_name)
and		project_name	= rtrim(@engg_project_name)
and		req_no			= rtrim(@engg_base_req_no)
and		process_name	= rtrim(@tmp_proc)
and		component_name	= rtrim(@tmp_comp_name)
and		activity_name	= rtrim(@tmp_acty_name)
and		ui_name			= rtrim(@tmp_ui_name)


Delete	from ep_tablet_control_dtl
where	customer_name	= rtrim(@engg_customer_name)
and		project_name	= rtrim(@engg_project_name)
and		req_no			= rtrim(@engg_base_req_no)
and		process_name	= rtrim(@tmp_proc)
and		component_name	= rtrim(@tmp_comp_name)
and		activity_name	= rtrim(@tmp_acty_name)
and		ui_name			= rtrim(@tmp_ui_name)

Delete	from ep_tablet_section_dtl
where	customer_name	= rtrim(@engg_customer_name)
and		project_name	= rtrim(@engg_project_name)
and		req_no			= rtrim(@engg_base_req_no)
and		process_name	= rtrim(@tmp_proc)
and		component_name	= rtrim(@tmp_comp_name)
and		activity_name	= rtrim(@tmp_acty_name)
and		ui_name			= rtrim(@tmp_ui_name)

Delete	from ep_tablet_page_dtl
where	customer_name	= rtrim(@engg_customer_name)
and		project_name	= rtrim(@engg_project_name)
and		req_no			= rtrim(@engg_base_req_no)
and		process_name	= rtrim(@tmp_proc)
and		component_name	= rtrim(@tmp_comp_name)
and		activity_name	= rtrim(@tmp_acty_name)
and		ui_name			= rtrim(@tmp_ui_name)

Delete	from ep_tablet_mst
where	customer_name	= rtrim(@engg_customer_name)
and		project_name	= rtrim(@engg_project_name)
and		req_no			= rtrim(@engg_base_req_no)
and		process_name	= rtrim(@tmp_proc)
and		component_name	= rtrim(@tmp_comp_name)
and		activity_name	= rtrim(@tmp_acty_name)
and		ui_name			= rtrim(@tmp_ui_name)


End

Declare	@tmp_devicetype		engg_flag

select	@tmp_devicetype	= devicetype
FROM	ep_ui_mst (nolock)
where	customer_name	= rtrim(@engg_customer_name)
and		project_name	= rtrim(@engg_project_name)
and		req_no			= rtrim(@engg_base_req_no)
and		process_name	= rtrim(@tmp_proc)
and		component_name	= rtrim(@tmp_comp_name)
and		activity_name	= rtrim(@tmp_acty_name)
and		ui_name			= rtrim(@tmp_ui_name)

IF (isnull(@engg_phone, 0) = 0 AND isnull(@engg_tablet,0) = 0 and isnull(@tmp_devicetype,'') = '' ) and @engg_nativeapp  = 'Y' 
BEGIN
	Raiserror ('Native Application attribute is applicable for Mobile UIs.', 16, 1)
	RETURN
END

/*update ui format attributes for the selected ui.*/  
update a 
set		ui_type					= rtrim(@engg_att_ui_type),
		ui_format				= rtrim(@engg_att_ui_format) ,
		caption_alignment		= rtrim(@engg_att_ui_cap_align) ,
		trail_bar				= rtrim(@engg_att_ui_trail_bar) ,
		tab_height				= rtrim(@engg_tab_height),
		-- Added for PLF2.0_14096 Starts
		Is_device				= @engg_isdevice ,
		SmartHide				= @engg_smarthide,
		HideIlbotitlemenu_req	= @engg_ilbotitle,
		-- Added for PLF2.0_14096 ends
		-- code added by shafina on 07-Sep-2004 for PREVIEWENG203ACC_000098 (Modified Date must be updated.)
		modifiedby				= @ctxt_user,
		modifieddate			= getdate(),
		grid_type				= rtrim(@engg_att_ui_grid_type),
		State_Processing		= @State_Processing,
		callout_type			= @engg_callout_type, -- added for request id: PNR2.0_1790
		taskpane_req			= @ezee_taskpane, -- Added for the Bug ID:PNR2.0_30127
		tab_type				= b.quick_code	,
		personalization			= @engg_hdrpersonalisation,
		Exclude_Systemtabindex	= @engg_syst_excl_tab_ind--PLF2.0_16291 
		,DeviceTYpe				= @devicetype,-- PLF2.0_17570   
		TabStyle				= @engg_tab_style,
		IsDesktop				= @engg_desk_brwser,
		Layout					= @engg_ui_layout,
		XYCoordinates			= @XYCoordinates,
		ColumnLayWidth			= @ColumnLayWidth,
		Hide_Print 				= @engg_hide_print,
		hide_imp_defaults		= @engg_hide_default,
		--Code changed by 12545
		TabPosition				= @engg_tab_hdr_pos,
		--TabHeaderPostion = @engg_tab_hdr_pos,
		TabRotation				=  @engg_tab_rotate,
		ui_subtype				= @engg_uisubtype,
		NativeApplication		= @engg_nativeapp,
		Conditional_popupclose	= @engg_popup_close,
		Titlebar_Search			= @engg_titlebar_search,
		--Tech-70687
		Sidebar					= CASE WHEN @engg_att_sidebar = 1 THEN 'Y' ELSE 'N' END,
		Docked					= CASE WHEN @engg_att_sidebar = 1 THEN @engg_att_docked ELSE '' END,
		LeftToolbar				= CASE WHEN @engg_lefttb	= 1 THEN 'Y' ELSE 'N' END,
		RightToolbar			= CASE WHEN @engg_righttb = 1 THEN 'Y' ELSE 'N' END,
		TopToolbar				= CASE WHEN @engg_toptb	= 1 THEN 'Y' ELSE 'N' END,
		BottomToolbar			= CASE WHEN @engg_bottomtb= 1 THEN 'Y' ELSE 'N' END,
		--Tech-70687
		PullToRefresh			= CASE WHEN @PullToRefresh= 1 THEN 'Y' ELSE 'N' END  --TECH-75230
from	ep_ui_mst a (nolock),
		ep_quick_code_mst b (nolock)
where	customer_name	= rtrim(@engg_customer_name)
and		project_name	= rtrim(@engg_project_name)
and		req_no			= rtrim(@engg_base_req_no)
and		process_name	= rtrim(@tmp_proc)
and		component_name  = rtrim(@tmp_comp_name)
and		activity_name	= rtrim(@tmp_acty_name)
and		ui_name			= rtrim(@tmp_ui_name)
and		quick_code_value= rtrim(@engg_tab_type)
--Code changed by 12545
and		quick_code_type	= 'Tab_Type'
--------for phone and Mobile

--Tech-70687
EXEC ep_toolbar_sec_creation_sp
 @ctxt_language             = @ctxt_language_in,
 @ctxt_ouinstance           = @ctxt_ouinstance_in,  
 @ctxt_service              = @ctxt_service_in,
 @ctxt_user                 = @ctxt_user_in,
 @customer_name				= @engg_customer_name_in,
 @project_name				= @engg_project_name_in,
 @req_no					= @engg_req_no_in,
 @process_name				= @tmp_proc,
 @component_name			= @tmp_comp_name,
 @activity_name				= @tmp_acty_name,
 @ui_name					= @tmp_ui_name,
 @page_name					= '',
 @section_name				= '',
 @toptoolbar				= @engg_toptb,
 @bottomtoolbar				= @engg_bottomtb,
 @lefttoolbar				= @engg_lefttb,
 @righttoolbar				= @engg_righttb,
 @sidebarrequired			= @engg_att_sidebar,
 @m_errorid					= 0
--Tech-70687

If	isnull(@devicetype,'') in ('P','B')
Begin
--Exec ep_layout_phone_tablet_ins_sp 
Exec ep_layout_phone_ins_sp 
		@ctxt_language,				@ctxt_ouinstance,				@ctxt_service,				@ctxt_user,					@tmp_acty_name,
		@tmp_comp_name,				@engg_customer_name,			null,						null,						null,
		null,						@tmp_proc,						@engg_project_name,			@engg_req_no,				@tmp_ui_name,
		@engg_phone,				@engg_tablet,						'Format',					null,						@m_errorid
		--@phone_in,					@tablet_in,						'Format',					null,						@m_errorid
End
	
If	isnull(@devicetype,'') in ('T','B')
Begin
Exec ep_layout_tablet_ins_sp 
		@ctxt_language,				@ctxt_ouinstance,				@ctxt_service,				@ctxt_user,					@tmp_acty_name,
		@tmp_comp_name,				@engg_customer_name,			null,						null,						null,
		null,						@tmp_proc,						@engg_project_name,			@engg_req_no,				@tmp_ui_name,
		@engg_phone,					@engg_tablet,						'Format',					null,						@m_errorid
		--@phone_in,					@tablet_in,						'Format',					null,						@m_errorid
End
if isnull(@engg_uisubtype,'') = 'Dashboard'
begin 
select @engg_req_no='base'
	Exec ep_systemdefined_controls_ins_sp
			@ctxt_OUInstance,		@ctxt_User,				@ctxt_Language,			@ctxt_Service,			@engg_customer_name ,
			@engg_project_name,		@tmp_proc,				@tmp_comp_name,			@tmp_acty_name,			@tmp_ui_name,
			@engg_req_no,			'[mainscreen]',			'DashhdnSection' ,		'RVFContext' ,			'HDNRVFContext',
			'Dashboard',			'',						'',						'HiddenEdit',			'',
			'',						@engg_req_no ,			'',						'',						'',  --TECH-73216
			@m_errorid   OUT

end
if isnull(@engg_uisubtype,'') = 'ARI Report' 
begin 

select @engg_req_no='base'
	Exec ep_controlcreation_sp
				@ctxt_OUInstance,				@ctxt_User,					@ctxt_Language,						@ctxt_Service,
				@engg_customer_name,			@engg_project_name,			@tmp_proc,							@tmp_comp_name,
				@tmp_acty_name,					@tmp_ui_name,				'[mainscreen]',						'PrjhdnSection',
				@tmp_ui_name,					@engg_req_no,				'I',								'ARIReport',
				@m_errorid   OUT

end

if ISNULL(@engg_titlebar_search,'N') = 'Y'
begin 

select @engg_req_no='base'
	Exec ep_controlcreation_sp
				@ctxt_OUInstance,				@ctxt_User,					@ctxt_Language,						@ctxt_Service,
				@engg_customer_name,			@engg_project_name,			@tmp_proc,							@tmp_comp_name,
				@tmp_acty_name,					@tmp_ui_name,				'[mainscreen]',						'PrjhdnSection',
				'TitlebarSearch_unify',			@engg_req_no,				'I',								'TitlebarSearch',
				@m_errorid   OUT

end

if ISNULL(@engg_titlebar_search,'N') = 'N'
begin 
	IF EXISTS (SELECT 'X'
	FROM	ep_ui_control_dtl (nolock)
	WHERE	customer_name		= rtrim(@engg_customer_name)
	and		project_name		= rtrim(@engg_project_name)
	and		req_no				= rtrim(@engg_base_req_no)
	and		process_name		= rtrim(@tmp_proc)
	and		component_name		= rtrim(@tmp_comp_name)
	and		activity_name		= rtrim(@tmp_acty_name)
	and		ui_name				= rtrim(@tmp_ui_name)
	and		control_bt_synonym	= rtrim('TitlebarSearch_unify')
	)
	BEGIN
		DELETE FROM ep_ui_control_dtl 
		WHERE	customer_name		= rtrim(@engg_customer_name)
		and		project_name		= rtrim(@engg_project_name)
		and		req_no				= rtrim(@engg_base_req_no)
		and		process_name		= rtrim(@tmp_proc)
		and		component_name		= rtrim(@tmp_comp_name)
		and		activity_name		= rtrim(@tmp_acty_name)
		and		ui_name				= rtrim(@tmp_ui_name)
		and		control_bt_synonym	= rtrim('TitlebarSearch_unify')

		DELETE FROM ep_action_mst 
		WHERE	customer_name		= rtrim(@engg_customer_name)
		and		project_name		= rtrim(@engg_project_name)
		and		req_no				= rtrim(@engg_base_req_no)
		and		process_name		= rtrim(@tmp_proc)
		and		component_name		= rtrim(@tmp_comp_name)
		and		activity_name		= rtrim(@tmp_acty_name)
		and		ui_name				= rtrim(@tmp_ui_name)
		and		primary_control_bts	= rtrim('TitlebarSearch_unify')
	END
END

if isnull(@engg_popup_close,'') = 'Y' 
and	NOT EXISTs (SELECT	'X'
				FROM	ep_ui_control_dtl (nolock)
				WHERE	customer_name		= rtrim(@engg_customer_name)
				and		project_name		= rtrim(@engg_project_name)
				and		req_no				= rtrim(@engg_base_req_no)
				and		process_name		= rtrim(@tmp_proc)
				and		component_name		= rtrim(@tmp_comp_name)
				and		activity_name		= rtrim(@tmp_acty_name)
				and		ui_name				= rtrim(@tmp_ui_name)
				and		control_bt_synonym	= rtrim('hdnrt_popup_close'))
begin 

			exec ep_controlcreation_sp
										@ctxt_OUInstance			= @ctxt_OUInstance,
										@ctxt_User					= @ctxt_User,
										@ctxt_Language				= @ctxt_Language,
										@ctxt_Service				= @ctxt_Service,
										@engg_customer_name			= @engg_customer_name,
										@engg_project_name			= @engg_project_name,
										@engg_process_name			= @tmp_proc,
										@engg_component_name		= @tmp_comp_name,
										@engg_activity_name			= @tmp_acty_name,
										@engg_ui_name				= @tmp_ui_name,
										@engg_page_name				= '[mainscreen]',
										@engg_section_name			= 'prjhdnsection',
										@engg_control_name			= 'hdnrt_popup_close',
										@engg_req_no				= @engg_req_no,
										@ModeFlag					= '',
										@CreatingFor				= 'ConditionalPopupclose',
										@m_errorid					= @m_errorid OUT
END
ELSE IF isnull(@engg_popup_close,'') = 'N' 
and	EXISTs (SELECT	'X'
				FROM	ep_ui_control_dtl (nolock)
				WHERE	customer_name		= rtrim(@engg_customer_name)
				and		project_name		= rtrim(@engg_project_name)
				and		req_no				= rtrim(@engg_base_req_no)
				and		process_name		= rtrim(@tmp_proc)
				and		component_name		= rtrim(@tmp_comp_name)
				and		activity_name		= rtrim(@tmp_acty_name)
				and		ui_name				= rtrim(@tmp_ui_name)
				and		control_bt_synonym	= rtrim('hdnrt_popup_close'))
BEGIN
	DELETE
	FROM	ep_ui_control_dtl 
	WHERE	customer_name		= rtrim(@engg_customer_name)
	and		project_name		= rtrim(@engg_project_name)
	and		req_no				= rtrim(@engg_base_req_no)
	and		process_name		= rtrim(@tmp_proc)
	and		component_name		= rtrim(@tmp_comp_name)
	and		activity_name		= rtrim(@tmp_acty_name)
	and		ui_name				= rtrim(@tmp_ui_name)
	and		control_bt_synonym	= rtrim('hdnrt_popup_close')

END	

END--Glance Check Begin
ELSE 
BEGIN	

	UPDATE	a 
	SET		State_Processing		= @State_Processing,
			callout_type			= @engg_callout_type
	FROM	ep_ui_mst a (nolock)
	where	customer_name	= rtrim(@engg_customer_name)
	and		project_name	= rtrim(@engg_project_name)
	and		req_no			= rtrim(@engg_base_req_no)
	and		process_name	= rtrim(@tmp_proc)
	and		component_name  = rtrim(@tmp_comp_name)
	and		activity_name	= rtrim(@tmp_acty_name)
	and		ui_name			= rtrim(@tmp_ui_name)

	UPDATE	a 
	SET		StateReqd			=	LOWER(@State_Processing),
			CalloutType			=	LOWER(@engg_callout_type) 
	FROM	ngplf_wr_userinterface_info a (nolock)
	WHERE	CustomerID		= RTRIM(@engg_customer_name)
	AND		ProjectID		= RTRIM(@engg_project_name)
	AND		ProcessName		= RTRIM(@tmp_proc)
	AND		ComponentName	= RTRIM(@tmp_comp_name)
	AND		ActivityName	= RTRIM(@tmp_acty_name)
	AND		UIName			= RTRIM(@tmp_ui_name)

	EXEC ngplf_postprocess_sp	@ctxt_language,			@ctxt_ouinstance,		@ctxt_user,		@ctxt_role,
								@engg_customer_name,	@engg_project_name,		@tmp_proc,		@tmp_comp_name,
								@engg_req_no_in,		@tmp_acty_name,			@tmp_ui_name	

END
--output parameters
select  0     'fprowno'

set nocount off
end
GO

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_layout_sp_savfrm_hsv' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON ep_layout_sp_savfrm_hsv TO PUBLIC
END
GO

