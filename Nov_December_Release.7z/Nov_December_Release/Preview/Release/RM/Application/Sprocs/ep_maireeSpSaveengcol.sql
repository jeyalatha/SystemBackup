IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_maireeSpSaveengcol' AND TYPE = 'P')
BEGIN
	DROP PROC ep_maireeSpSaveengcol                            
                                                                   
END
GO
/******************************************************************************/  
/* Procedure     : ep_maireeSpSaveengcol         */  
/* Description     :          */  
/******************************************************************************/  
/* Project      :          */  
/* EcrNo      :          */  
/* Version      :          */  
/******************************************************************************/  
/* Referenced     :          */  
/* Tables      :          */  
/******************************************************************************/  
/* Development history   :          */  
/******************************************************************************/  
/* Author      : ModelExplorer         */  
/* Date       : May 13 2016  5:11PM         */  
/******************************************************************************/  
/* Modification History   :          */  
/******************************************************************************/  
/* modified by   Date    Defect ID       */  
/* Veena U    08-Jun-2016   PLF2.0_18487      */  
/********************************************************************************/  
/* Modified by : Jeya Latha K/Ganesh Prabhu S for callid TECH-7349    */  
/* Modified on : 14-03-2017                */  
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and New Feature Organization chart */  
/***********************************************************************************/  
/* Modified by : Ganesh Prabhu S/Ranjitha R      for callid  TECH-10118            */  
/* Modified on : 30-May-2017                                                       */  
/* Description : Platform Feature Release                                          */  
/***********************************************************************************/
/*Modified by  :Manoj S		Date: 13 Sep 2021		Defect ID: TECH-61946		   */
/***********************************************************************************************/
/* Modified by    :    VimalKumar R                                                            */
/* Modified on    :    03/11/22                                                                */
/* Defect ID	  :    TECH-73052                                                              */
/* Description    :    Need new column- Column caption from Respective grid controls-In column
					   grouping tab in addition with existing Column name/synonym.             */
/***********************************************************************************************/

CREATE Procedure ep_maireeSpSaveengcol  
 @ctxt_ouinstance     ctxt_ouinstance, --Input   
 @ctxt_user           ctxt_user, --Input   
 @ctxt_language       ctxt_language, --Input   
 @ctxt_service        ctxt_service, --Input   
 @engg_act_descr      engg_description, --Input   
 @engg_col_or_group   engg_name, --Input   
 @engg_component      engg_description, --Input   
 @engg_component_name  engg_name, --Input   
 @engg_control_name   engg_name, --Input   
 @engg_customer_name  engg_name, --Input   
 @engg_group_caption  engg_description, --Input   
 @engg_group_name     engg_name, --Input   
 @engg_group_seq       engg_seqno, --Input   
 @engg_group_seqno     engg_seqno, --Input   
 @engg_mapped_entity  engg_name, --Input   
 @engg_map_seq        engg_seqno, --Input   
 @engg_new_group_cap   engg_description, --Input   
 @engg_new_group_name  engg_name, --Input   
 @engg_page_name      engg_name, --Input   
 @engg_process_descr  engg_description, --Input   
 @engg_project_name   engg_name, --Input   
 @engg_req_no         engg_name, --Input   
 @engg_sect_name      engg_name, --Input   
 @engg_ui_descr       engg_description, --Input   
 @engg_ui_name         engg_name, --Input   
 @engg_ui_map         engg_flag, --Input   
 @engg_col_caption	  engg_description,	--Code Added for TECH-73052
 @modeflag            modeflag, --Input   
 @fprowno             rowno, --Input/Output  
 @m_errorid           int output --To Return Execution Status  
as  
Begin  
 -- nocount should be switched on to prevent phantom rows  
 Set nocount on  
 -- @m_errorid should be 0 to Indicate Success  
 Set @m_errorid = 0  
  
 --declaration of temporary variables  
  
  
 --temporary and formal parameters mapping  
  
 Set @ctxt_user           = ltrim(rtrim(@ctxt_user))  
 Set @ctxt_service        = ltrim(rtrim(@ctxt_service))  
 Set @engg_act_descr      = ltrim(rtrim(@engg_act_descr))  
 Set @engg_col_or_group   = ltrim(rtrim(@engg_col_or_group))  
 Set @engg_component      = ltrim(rtrim(@engg_component))  
 Set @engg_component_name  = ltrim(rtrim(@engg_component_name))  
 Set @engg_control_name   = ltrim(rtrim(@engg_control_name))  
 Set @engg_customer_name  = ltrim(rtrim(@engg_customer_name))  
 Set @engg_group_caption  = ltrim(rtrim(@engg_group_caption))  
 Set @engg_group_name     = ltrim(rtrim(@engg_group_name))  
 Set @engg_mapped_entity  = ltrim(rtrim(@engg_mapped_entity))  
 Set @engg_new_group_cap   = ltrim(rtrim(@engg_new_group_cap))  
 Set @engg_new_group_name  = ltrim(rtrim(@engg_new_group_name))  
 Set @engg_page_name      = ltrim(rtrim(@engg_page_name))  
 Set @engg_process_descr  = ltrim(rtrim(@engg_process_descr))  
 Set @engg_project_name   = ltrim(rtrim(@engg_project_name))  
 Set @engg_req_no         = ltrim(rtrim(@engg_req_no))  
 Set @engg_sect_name      = ltrim(rtrim(@engg_sect_name))  
 Set @engg_ui_descr       = ltrim(rtrim(@engg_ui_descr))  
 Set @engg_ui_map         = ltrim(rtrim(@engg_ui_map))  
 Set @engg_ui_name         = ltrim(rtrim(@engg_ui_name))  
 Set @modeflag            = ltrim(rtrim(@modeflag))  
  
 --null checking  
  
 IF @ctxt_ouinstance = -915  
  Select @ctxt_ouinstance = null    
  
 IF @ctxt_user = '~#~'   
  Select @ctxt_user = null    
  
 IF @ctxt_language = -915  
  Select @ctxt_language = null    
  
 IF @ctxt_service = '~#~'   
  Select @ctxt_service = null    
  
 IF @engg_act_descr = '~#~'   
  Select @engg_act_descr = null    
  
 IF @engg_col_or_group = '~#~'   
  Select @engg_col_or_group = null    
  
 IF @engg_component = '~#~'   
  Select @engg_component = null    
   
 IF @engg_component_name = '~#~'   
  Select @engg_component_name = null    
  
 IF @engg_control_name = '~#~'   
  Select @engg_control_name = null    
  
 IF @engg_customer_name = '~#~'   
  Select @engg_customer_name = null    
  
 IF @engg_group_caption = '~#~'   
  Select @engg_group_caption = null    
  
 IF @engg_group_name = '~#~'   
  Select @engg_group_name = null    
   
 IF @engg_group_seq = -915  
  Select @engg_group_seq = null    
  
 IF @engg_group_seqno = -915  
  Select @engg_group_seqno = null    
  
 IF @engg_mapped_entity = '~#~'   
  Select @engg_mapped_entity = null    
  
 IF @engg_map_seq = -915  
  Select @engg_map_seq = null    
    
 IF @engg_new_group_cap = '~#~'   
  Select @engg_new_group_cap = null    
  
 IF @engg_new_group_name = '~#~'   
  Select @engg_new_group_name = null    
  
 IF @engg_page_name = '~#~'   
  Select @engg_page_name = null    
  
 IF @engg_process_descr = '~#~'   
  Select @engg_process_descr = null    
  
 IF @engg_project_name = '~#~'   
  Select @engg_project_name = null    
  
 IF @engg_req_no = '~#~'   
  Select @engg_req_no = null    
  
 IF @engg_sect_name = '~#~'   
  Select @engg_sect_name = null    
  
 IF @engg_ui_descr = '~#~'   
  Select @engg_ui_descr = null    
  
 IF @engg_ui_map = '~#~'   
  Select @engg_ui_map = null    
  
 IF @engg_ui_name = '~#~'   
  Select @engg_ui_name = null    
  
 IF @modeflag = '~#~'   
  Select @modeflag = null    
  
 IF @fprowno = -915  
  Select @fprowno = null    
  
 Declare  @tmp_proc engg_name,  
    @tmp_comp engg_name,  
    @tmp_act engg_name,  
    @tmp_ui  engg_name,  
    @grp_name engg_name,  
    @seqno  engg_seqno,  
    @sequence engg_seqno,  
    @phone_in engg_flag,  
    @tablet_in engg_flag,  
    @Devicetype engg_flag,  
    @count_ph  ENGG_SEQNO,  
    @count_tab  ENGG_SEQNO  
       
  
 select @tmp_proc  = rtrim(process_name)  
 from ep_ui_req_dtl (nolock)  
 where customer_name = rtrim(@engg_customer_name)  
 and  project_name = rtrim(@engg_project_name)  
 and  req_no   = rtrim(@engg_req_no)  
 and  process_descr = rtrim(@engg_process_descr)  
  
 select @tmp_comp  = rtrim(component_name)  
 from ep_ui_req_dtl (nolock)  
 where customer_name = rtrim(@engg_customer_name)  
 and  project_name = rtrim(@engg_project_name)  
 and  req_no   = rtrim(@engg_req_no)  
 and  process_name = rtrim(@tmp_proc)  
 and  component_descr = rtrim(@engg_component)  
  
 select top 1  @tmp_act = rtrim(activity_name)  
 from ep_ui_req_dtl (nolock)  
 where customer_name = rtrim(@engg_customer_name)  
 and  project_name = rtrim(@engg_project_name)  
 and  req_no   = rtrim(@engg_req_no)  
 and  process_name = rtrim(@tmp_proc)  
 and  component_name  = rtrim(@tmp_comp)  
 and  activity_descr = RTRIM(@engg_act_descr)  
  
 select top 1 @tmp_ui = rtrim(ui_name)  
 from ep_ui_req_dtl (nolock)  
 where customer_name = rtrim(@engg_customer_name)  
 and  project_name = rtrim(@engg_project_name)  
 and  process_name = rtrim(@tmp_proc)  
 and  req_no   = rtrim(@engg_req_no)  
 and  component_name  = rtrim(@tmp_comp)  
 and  activity_name = rtrim(@tmp_act)  
 and  ui_descr  = RTRIM(@engg_ui_descr)   
   
 Select @cOUNT_ph   = COUNT(column_bt_synonym)  
 from ep_phone_column_group_mapping (nolock)  
 where customer_name  = RTRIM(@engg_customer_name)  
 and  project_name  = RTRIM(@engg_project_name)  
 and  process_name  = RTRIM(@tmp_proc)  
 and  component_name  = RTRIM(@tmp_comp)  
 and  activity_name  = RTRIM(@tmp_act)  
 and  ui_name    = RTRIM(@tmp_ui)  
 and  Page_bt_synonym  = RTRIM(@engg_page_name)  
 and  section_bt_synonym = RTRIM(@engg_sect_name)  
 and  grid_control_bt_synonym = RTRIM(@engg_control_name)  
 and  group_name   = RTRIM(@engg_group_name)  
   
 Select @cOUNT_tab   = COUNT(column_bt_synonym)  
 from ep_phone_column_group_mapping (nolock)  
 where customer_name  = RTRIM(@engg_customer_name)  
 and  project_name  = RTRIM(@engg_project_name)  
 and  process_name  = RTRIM(@tmp_proc)  
 and  component_name  = RTRIM(@tmp_comp)  
 and  activity_name  = RTRIM(@tmp_act)  
 and  ui_name    = RTRIM(@tmp_ui)  
 and  Page_bt_synonym  = RTRIM(@engg_page_name)  
 and  section_bt_synonym = RTRIM(@engg_sect_name)  
 and  grid_control_bt_synonym = RTRIM(@engg_control_name)  
 and  group_name   = RTRIM(@engg_group_name)  
   
  
 if isnull(@engg_ui_map,0) = 0  
 Begin  
  If exists (Select 'x' from   
     ep_ui_column_group_mapping (nolock)  
     where customer_name  = RTRIM(@engg_customer_name)  
     and  project_name  = RTRIM(@engg_project_name)  
     and  process_name  = RTRIM(@tmp_proc)  
     and  component_name  = RTRIM(@tmp_comp)  
     and  activity_name  = RTRIM(@tmp_act)  
     and  ui_name    = RTRIM(@tmp_ui)  
     and  page_bt_synonym  = rtrim(@engg_page_name)  
     and  group_name   = RTRIM(@engg_group_name)  
     and  column_bt_synonym = RTRIM(@engg_col_or_group))  
  Begin  
   Delete from ep_ui_column_group_mapping   
   where customer_name  = RTRIM(@engg_customer_name)  
   and  project_name  = RTRIM(@engg_project_name)  
   and  process_name  = RTRIM(@tmp_proc)  
   and  component_name  = RTRIM(@tmp_comp)  
   and  activity_name  = RTRIM(@tmp_act)  
   and  ui_name    = RTRIM(@tmp_ui)  
   and  page_bt_synonym  = rtrim(@engg_page_name)  
   and  group_name   = RTRIM(@engg_group_name)  
   and  column_bt_synonym = RTRIM(@engg_col_or_group)  
  
   Delete from ep_phone_column_group_mapping   
   where customer_name  = RTRIM(@engg_customer_name)  
   and  project_name  = RTRIM(@engg_project_name)  
   and  process_name  = RTRIM(@tmp_proc)  
   and  component_name  = RTRIM(@tmp_comp)  
   and  activity_name  = RTRIM(@tmp_act)  
   and  ui_name    = RTRIM(@tmp_ui)  
   and  page_bt_synonym  = rtrim(@engg_page_name)  
   and  group_name   = RTRIM(@engg_group_name)  
   and  column_bt_synonym = RTRIM(@engg_col_or_group)  
     
   Delete from ep_tablet_column_group_mapping   
   where customer_name  = RTRIM(@engg_customer_name)  
   and  project_name  = RTRIM(@engg_project_name)  
   and  process_name  = RTRIM(@tmp_proc)  
   and  component_name  = RTRIM(@tmp_comp)  
   and  activity_name  = RTRIM(@tmp_act)  
   and  ui_name    = RTRIM(@tmp_ui)  
   and  page_bt_synonym  = rtrim(@engg_page_name)  
   and  group_name   = RTRIM(@engg_group_name)  
   and  column_bt_synonym = RTRIM(@engg_col_or_group)     
  End  
 End  
 Else  
 Begin  
  if @engg_mapped_entity = 'Group' and   
  not exists (Select 'x' from   
   ep_ui_column_group_mapping (nolock)  
   where customer_name  = RTRIM(@engg_customer_name)  
   and  project_name  = RTRIM(@engg_project_name)  
   and  process_name  = RTRIM(@tmp_proc)  
   and  component_name  = RTRIM(@tmp_comp)  
   and  activity_name  = RTRIM(@tmp_act)  
   and  ui_name    = RTRIM(@tmp_ui)  
   and  group_name   = RTRIM(@engg_col_or_group))  
  Begin  
   Raiserror ('The Group "%s" do not have any column mapped to it. Kindly map and procede.',16,4,@engg_col_or_group)  
   Return  
  End  
    
  If  isnull(@engg_group_name,'') = ''  
    Set @engg_group_name ='GridControl'  
  
   
  
  If not exists (Select 'x' from   
     ep_ui_column_group_mapping (nolock)  
     where customer_name  = RTRIM(@engg_customer_name)  
     and  project_name  = RTRIM(@engg_project_name)  
     and  process_name  = RTRIM(@tmp_proc)  
     and  component_name  = RTRIM(@tmp_comp)  
     and  activity_name  = RTRIM(@tmp_act)  
     and  ui_name    = RTRIM(@tmp_ui)  
     and  page_bt_synonym  = rtrim(@engg_page_name)  
     and  group_name   = RTRIM(@engg_group_name)  
     and  column_bt_synonym = RTRIM(@engg_col_or_group))    
  Begin   
     
   Insert into ep_ui_column_group_mapping  
   (customer_name,   project_name,   req_no,    process_name,    component_name,  activity_name,  
   ui_name,    Page_bt_synonym,  section_bt_synonym, grid_control_bt_synonym, Group_name,   column_bt_synonym,  
   SequenceNo,    mapped_entity,   wrkreqno,   timestamp,     createdby,   createddate,  
   modifiedby,    modifieddate) 
   Values  
   (@engg_customer_name, @engg_project_name,  'Base',    @tmp_proc,     @tmp_comp,   @tmp_act,  
   @tmp_ui,    @engg_page_name,  @engg_sect_name, @engg_control_name,   @engg_group_name, @engg_col_or_group,  
   @engg_map_seq,   @engg_mapped_entity, @engg_req_no,  1,       @ctxt_user,   GETDATE(),  
   @ctxt_user,    GETDATE()) 
  End  
  
 -- Code fixed against the defect id TECH-47956 starts  
  
  if @engg_mapped_entity = 'Column'  
   Begin  
    update ep_ui_column_group_mapping   
    set  SequenceNo    = @engg_map_seq
    where customer_name   = rtrim(@engg_customer_name)  
    and  project_name   = rtrim(@engg_project_name)  
    and  process_name   = rtrim(@tmp_proc)  
    and  component_name    = rtrim(@tmp_comp)  
    and  activity_name   = rtrim(@tmp_act)  
    and  ui_name     = rtrim(@tmp_ui)  
    and  Page_bt_synonym   = rtrim(@engg_page_name)  
    and  section_bt_synonym  = rtrim(@engg_sect_name)  
    and  column_bt_synonym  = rtrim(@engg_col_or_group)  
    and  group_name    = rtrim(@engg_group_name)   
  
  end  
  
  -- Code fixed against the defect id TECH-47956 Ends  
    
  if @engg_mapped_entity = 'Group'  
  Begin  
    
   Declare  @level engg_seqno  
  
   select @level = isnull(grouplevel,0)  
   from ep_ui_columngroup (nolock)  
   where customer_name   = rtrim(@engg_customer_name)  
   and  project_name   = rtrim(@engg_project_name)  
   and  process_name   = rtrim(@tmp_proc)  
   and  component_name    = rtrim(@tmp_comp)  
   and  activity_name   = rtrim(@tmp_act)  
   and  ui_name     = rtrim(@tmp_ui)  
   and  Page_bt_synonym   = rtrim(@engg_page_name)  
   and  section_bt_synonym  = rtrim(@engg_sect_name)  
   and  grid_control_bt_synonym = rtrim(@engg_control_name)  
   and  Group_name    = rtrim(@engg_group_name)  
  
  
   update ep_ui_columngroup   
    set grouplevel = isnull(@level,0)+1,  
     parentgroup  = @engg_group_name,  
     parentgroupseq = @engg_group_seq  
   where customer_name   = rtrim(@engg_customer_name)  
   and  project_name   = rtrim(@engg_project_name)  
   and  process_name   = rtrim(@tmp_proc)  
   and  component_name    = rtrim(@tmp_comp)  
   and  activity_name   = rtrim(@tmp_act)  
   and  ui_name     = rtrim(@tmp_ui)  
   and  Page_bt_synonym   = rtrim(@engg_page_name)  
   and  section_bt_synonym  = rtrim(@engg_sect_name)  
   and  grid_control_bt_synonym = rtrim(@engg_control_name)  
   and  group_name    = rtrim(@engg_col_or_group)  
  
  --Added for TECH-61946 starts
     update ep_ui_column_group_mapping
   set sequenceno = @engg_map_seq,
   modifiedby = @ctxt_user,
   modifieddate = getdate()
   where customer_name   = rtrim(@engg_customer_name)  
   and  project_name   = rtrim(@engg_project_name)  
   and  process_name   = rtrim(@tmp_proc)  
   and  component_name    = rtrim(@tmp_comp)  
   and  activity_name   = rtrim(@tmp_act)  
   and  ui_name     = rtrim(@tmp_ui)  
   and  Page_bt_synonym   = rtrim(@engg_page_name)  
   and  section_bt_synonym  = rtrim(@engg_sect_name)  
   and  grid_control_bt_synonym = rtrim(@engg_control_name) 
   and  column_bt_synonym = rtrim(@engg_col_or_group) 
   and  group_name    = rtrim(@engg_group_name)   
   --Added for TECH-61946 ends 
  End  
  
     
  
  --if isnull(@count_ph,0) = 0 or isnull(@count_tab,0) = 0  
  --Begin   
  -- Select @devicetype  = ''  
  -- Select @Devicetype  = isnull(devicetype,'')  
  -- from ep_ui_mst(nolock)  
  -- where customer_name  = rtrim(@engg_customer_name)  
  -- and  project_name  = rtrim(@engg_project_name)  
  -- and  process_name  = rtrim(@tmp_proc)  
  -- and  component_name  = rtrim(@tmp_comp)  
  -- and  activity_name  = rtrim(@tmp_act)  
  -- and  ui_name    = rtrim(@tmp_ui)  
  
  -- If isnull(@devicetype,'') = ''   
  --   Select @phone_in  = null, @tablet_in = null  
  -- If isnull(@devicetype,'') = 'P'   
  --   Select @phone_in  = 1, @tablet_in = null  
  -- If isnull(@devicetype,'') = 'T'   
  --   Select @phone_in  = null, @tablet_in = 1  
  -- If isnull(@devicetype,'') = 'B'   
  --   Select @phone_in  = 1 , @tablet_in = 1   
     
  -- Exec ep_layout_phone_tablet_ins_sp   
  --  @ctxt_language,    @ctxt_ouinstance,    @ctxt_service,     @ctxt_user,     @tmp_act,  
  --  @tmp_comp,     @engg_customer_name,   @engg_page_name,    @engg_sect_name,   @engg_control_name,  
  --  null,      @tmp_proc,      @engg_project_name,    @engg_req_no,    @tmp_ui,  
  --  @phone_in,     @tablet_in,      'ColumnGroup',     @engg_group_name,   @m_errorid   
  --End  
   
 End  
   
 /*   
 --OutputList  
  Select  
  null 'fprowno',   
 */  
   
Set nocount off  
  
End  
GO

IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'ep_maireeSpSaveengcol' AND TYPE = 'P')
BEGIN
    GRANT EXEC ON ep_maireeSpSaveengcol TO PUBLIC
END
GO