IF EXISTS ( SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'EP_UI_CONTROL_DTL_SP_INS' AND TYPE = 'P' )
    BEGIN
        DROP PROC EP_UI_CONTROL_DTL_SP_INS
    END
GO
Set quoted_identifier off
go
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		EP_UI_CONTROL_DTL_SP_INS.sql
********************************************************************************/
--Set quoted_identifier off
/* modified by   : Chanheetha N A        */
/* date     : 17-nov-2007         */
/* BugId    : PNR2.0_16023          */
/********************************************************************************/
/* Modified By      : Sangeetha G                    */
/* Date            : 05-May-2010                  */
/* BugID       : PNR2.0_23541                   */
/* Modified For      : To set UserPreference through frontend in spec Layout */
/********************************************************************************/
/* Modified By      : Chanheetha N A               */
/* Date            : 14-May-2010             */
/* BugID       : PNR2.0_26860              */
/* Modified For      : Extra column to specify freezecount                   */
/********************************************************************************/
/* Modified By      :   Jeya Latha K                            */
/* date           :   17 Aug 2010                               */
/* BugID           :   PNR2.0_28003                               */
/********************************************************************************/
/* Modified By      : Balaji D                     */
/* Date            : Nov 30 2010                  */
/* BugID       : PNR2.0_29237                     */
/* Description      : Tab sequence column is not getting refresh   */
/********************************************************************************/
/* modified by  : Veena U   			                                        */
/* date         : Oct 10 2014			                                        */
/* BugId        : PLF2.0_09035													*/
/* description  : Model changes for rowspan,colspan,IsStatic,IsCallout 
				  in  layout level.												*/
/********************************************************************************/
/* Modified by  : Veena U                                                  */
/* Date         : 25-Feb-2015                                                  */
/* Call ID		: PLF2.0_11499                                                 */
/********************************************************************************/
/* Modified by  : Kalidas S	                                                  */
/* Date         : 03-Aug-2015                                                  */
/* Defect ID	: PLF2.0_14096                                                 */
/*************************************************************************************/
/* modified by                    Date                       Defect ID               */
/* Veena U                        08-Jun-2016                PLF2.0_18487            */
/* Modified by  : Jeya Latha K/Venkatesan K	Date: 31-Oct-2018  Defect ID: TECH-28010 */
/* Modified by  : Jeya Latha K				Date: 25-Jul-2019  Defect ID: TECH-36371 */
/* Modified by  : Rajeswari M/Priyadharshini U Date: 28-Jul-2021  Defect ID : TECH-60451*/
/* TECH-60451   : Launching Help&Link UIs, Popup sections and Grid Extensions in Side Drawer*/
/* TECH-63527   : Associate Control added in ep_ui_control_dtl for Multiselectcombo  */ 
/*************************************************************************************/
/* Modified by	:	Priyadharshini U/VimalKumar R								*/
/* Modified on	:	08/06/22				 									*/
/* Defect ID	:	TECH-69624													*/
/* Description	:	Custom border, Custom actions and Responsive layout			*/
/********************************************************************************/
/* Modified by	:	Priyadharshini U											*/
/* Modified on	:	22/08/22				 									*/
/* Defect ID	:	TECH-72114													*/
/********************************************************************************/
/* Modified by    :    Ponmalar A                                               */
/* Modified on    :    02/12/22													*/
/* Defect ID      :    TECH-75230												*/
/* Description    : Platform Release for the Month of Nov'22				    */
/********************************************************************************/
CREATE PROCEDURE EP_UI_CONTROL_DTL_SP_INS
	@CTXT_LANGUAGE_IN ENGG_CTXT_LANGUAGE,
	@CTXT_OUINSTANCE_IN ENGG_CTXT_OUINSTANCE,
	@CTXT_SERVICE_IN ENGG_CTXT_SERVICE,
	@CTXT_USER_IN ENGG_CTXT_USER,
	@CUSTOMER_NAME_IN ENGG_NAME,
	@PROJECT_NAME_IN ENGG_NAME,
	@REQ_NO_IN ENGG_NAME,
	@PROCESS_NAME_IN ENGG_NAME,
	@COMPONENT_NAME_IN ENGG_NAME,
	@ACTIVITY_NAME_IN ENGG_NAME,
	@UI_NAME_IN ENGG_NAME,
	@PAGE_BT_SYNONYM_IN ENGG_NAME,
	@SECTION_BT_SYNONYM_IN ENGG_NAME,
	@CONTROL_BT_SYNONYM_IN ENGG_NAME,
	@CONTROL_ID_IN ENGG_NAME,
	--    @VIEW_NAME_IN                                       ENGG_NAME,
	@CONTROL_TYPE_IN ENGG_NAME,
	@VISISBLE_LENGTH_IN ENGG_LENGTH,
	@HORDER_IN ENGG_SEQNO,
	@VORDER_IN ENGG_SEQNO,
	@ORDER_SEQ_IN ENGG_SEQNO,
	@DATA_COLUMN_WIDTH_IN ENGG_SEQNO,
	@LABEL_COLUMN_WIDTH_IN ENGG_SEQNO,
	@PROTO_TOOLTIP_IN ENGG_DESCRIPTION,
	@SAMPLE_DATA_IN ENGG_DOCUMENTATION,
	@CONTROL_DOC_IN ENGG_DOCUMENTATION,
	@CONTROL_PREFIX_IN ENGG_PREFIX,
	@LABEL_CONTROL_ID_IN ENGG_NAME,
	@label_column_scalemode_in engg_prefix,
	@data_column_scalemode_in engg_prefix,
	@engg_label_class_in engg_name,
	@engg_control_class_in engg_name,
	@engg_label_image_class_in engg_name,
	@engg_control_image_class_in engg_name,
	@engg_tab_sequence_in engg_seqno,
	@engg_tab_stopforhelp_in engg_flag,
	@TIMESTAMP_IN INT,
	@engg_req_no engg_name, --chan
	@user_pref engg_flag, -- Code modified for PNR2.0_23541
	@freezecount engg_seqno, --added for PNR2.0_26860,
	@Engg_cont_Ctrlimg engg_name,
	@Engg_cont_rowspan engg_seqno,
	@Engg_cont_colspan engg_seqno,
	@engg_cont_tempid engg_name,
	@ctrl_temp_cat engg_name,
	@ctrl_temp_specific engg_documentation,
	--Ranjith
	@AccessKey engg_code,
	@Icon_class engg_name,
	@Icon_position engg_name,
	@Cont_class_ext6 engg_name,
	@engg_dynamicstyle engg_flag,
	@engg_imageasdata engg_flag,
	@engg_extnreqd   engg_seqno, 
	@engg_MSC_Ass_control engg_name,--code added for TECH-63527
	@Engg_cont_forresponsive	engg_seqno,	--Code added for TECH-69624
	@engg_cont_control_format	engg_name,	--Code Added for the Defect Id TECH-72114
	@ButtonNature	engg_name,	---Code added for TECH-75230
	@Inlinestyle	engg_nvarchar_max,	---Code added for TECH-75230
	@M_ERRORID INT OUTPUT
AS
BEGIN
	SET NOCOUNT ON
	
	/********************************************************************************/
	/*                          TEMPORARY INPUT PARAMETERS                          */
	/********************************************************************************/
	DECLARE @ERRORMESSAGE_TMP VARCHAR(1000),
		@ERRORNO_TMP INT,
		@SPERROR INT,
		@DUPCOUNT_TMP INT,
		@TIMESTAMP_TMP INT,
		@CTXT_LANGUAGE_TMP ENGG_CTXT_LANGUAGE,
		@CUSTOMER_NAME_TMP ENGG_NAME,
		@CTXT_OUINSTANCE_TMP ENGG_CTXT_OUINSTANCE,
		@PROJECT_NAME_TMP ENGG_NAME,
		@CTXT_SERVICE_TMP ENGG_CTXT_SERVICE,
		@REQ_NO_TMP ENGG_NAME,
		@CTXT_USER_TMP ENGG_CTXT_USER,
		@PROCESS_NAME_TMP ENGG_NAME,
		@COMPONENT_NAME_TMP ENGG_NAME,
		@ACTIVITY_NAME_TMP ENGG_NAME,
		@UI_NAME_TMP ENGG_NAME,
		@PAGE_BT_SYNONYM_TMP ENGG_NAME,
		@SECTION_BT_SYNONYM_TMP ENGG_NAME,
		@CONTROL_BT_SYNONYM_TMP ENGG_NAME,
		@CONTROL_ID_TMP ENGG_NAME,
		@VIEW_NAME_TMP ENGG_NAME,
		@CONTROL_TYPE_TMP ENGG_NAME,
		@VISISBLE_LENGTH_TMP ENGG_LENGTH,
		@HORDER_TMP ENGG_SEQNO,
		@VORDER_TMP ENGG_SEQNO,
		@ORDER_SEQ_TMP ENGG_SEQNO,
		@DATA_COLUMN_WIDTH_TMP ENGG_SEQNO,
		@LABEL_COLUMN_WIDTH_TMP ENGG_SEQNO,
		@PROTO_TOOLTIP_TMP ENGG_DESCRIPTION,
		@SAMPLE_DATA_TMP ENGG_DOCUMENTATION,
		@CONTROL_DOC_TMP ENGG_DOCUMENTATION,
		@CONTROL_PREFIX_TMP ENGG_PREFIX,
		@UI_CONTROL_SYSID_TMP ENGG_SYSID,
		@UI_SECTION_SYSID_TMP ENGG_SYSID,
		@LABEL_CONTROL_ID_TMP ENGG_NAME,
		@label_column_scalemode_tmp engg_prefix,
		@data_column_scalemode_tmp engg_prefix,
		@engg_label_class_tmp engg_name,
		@engg_control_class_tmp engg_name,
		@engg_label_image_class_tmp engg_name,
		@engg_control_image_class_tmp engg_name,
		@engg_tab_sequence_tmp engg_seqno,
		@engg_tab_stopforhelp_tmp engg_flag

	/********************************************************************************/
	/*                                  ASSIGNING TO TEMP VARIABLE                  */
	/********************************************************************************/
	SELECT @CTXT_LANGUAGE_TMP = @CTXT_LANGUAGE_IN,
		@CUSTOMER_NAME_TMP = LTRIM(RTRIM(@CUSTOMER_NAME_IN)),
		@CTXT_OUINSTANCE_TMP = @CTXT_OUINSTANCE_IN,
		@PROJECT_NAME_TMP = LTRIM(RTRIM(@PROJECT_NAME_IN)),
		@CTXT_SERVICE_TMP = LTRIM(RTRIM(@CTXT_SERVICE_IN)),
		@REQ_NO_TMP = LTRIM(RTRIM(@REQ_NO_IN)),
		@CTXT_USER_TMP = LTRIM(RTRIM(@CTXT_USER_IN)),
		@PROCESS_NAME_TMP = LTRIM(RTRIM(@PROCESS_NAME_IN)),
		@COMPONENT_NAME_TMP = LTRIM(RTRIM(@COMPONENT_NAME_IN)),
		@ACTIVITY_NAME_TMP = LTRIM(RTRIM(@ACTIVITY_NAME_IN)),
		@UI_NAME_TMP = LTRIM(RTRIM(@UI_NAME_IN)),
		@PAGE_BT_SYNONYM_TMP = LTRIM(RTRIM(@PAGE_BT_SYNONYM_IN)),
		@SECTION_BT_SYNONYM_TMP = LTRIM(RTRIM(@SECTION_BT_SYNONYM_IN)),
		@CONTROL_BT_SYNONYM_TMP = LTRIM(RTRIM(@CONTROL_BT_SYNONYM_IN)),
		@CONTROL_ID_TMP = LTRIM(RTRIM(@CONTROL_ID_IN)),
		-- @VIEW_NAME_TMP                                      =   LTRIM(RTRIM(@VIEW_NAME_IN)),
		@CONTROL_TYPE_TMP = LTRIM(RTRIM(@CONTROL_TYPE_IN)),
		@VISISBLE_LENGTH_TMP = @VISISBLE_LENGTH_IN,
		@HORDER_TMP = @HORDER_IN,
		@VORDER_TMP = @VORDER_IN,
		@ORDER_SEQ_TMP = @ORDER_SEQ_IN,
		@DATA_COLUMN_WIDTH_TMP = @DATA_COLUMN_WIDTH_IN,
		@LABEL_COLUMN_WIDTH_TMP = @LABEL_COLUMN_WIDTH_IN,
		@PROTO_TOOLTIP_TMP = LTRIM(RTRIM(@PROTO_TOOLTIP_IN)),
		@SAMPLE_DATA_TMP = LTRIM(RTRIM(@SAMPLE_DATA_IN)),
		@CONTROL_DOC_TMP = LTRIM(RTRIM(@CONTROL_DOC_IN)),
		@CONTROL_PREFIX_TMP = LTRIM(RTRIM(@CONTROL_PREFIX_IN)),
		@LABEL_CONTROL_ID_TMP = LTRIM(RTRIM(@LABEL_CONTROL_ID_IN)),
		@label_column_scalemode_tmp = LTRIM(RTRIM(@label_column_scalemode_in)),
		@data_column_scalemode_tmp = LTRIM(RTRIM(@data_column_scalemode_in)),
		@engg_label_class_tmp = LTRIM(RTRIM(@engg_label_class_in)),
		@engg_control_class_tmp = LTRIM(RTRIM(@engg_control_class_in)),
		@engg_label_image_class_tmp = LTRIM(RTRIM(@engg_label_image_class_in)),
		@engg_control_image_class_tmp = LTRIM(RTRIM(@engg_control_image_class_in)),
		@engg_tab_sequence_tmp = LTRIM(RTRIM(@engg_tab_sequence_in)),
		@engg_tab_stopforhelp_tmp = LTRIM(RTRIM(@engg_tab_stopforhelp_in)),
		@engg_cont_tempid = Ltrim(Rtrim(@engg_cont_tempid)),
		--Ranjitha
		--@Cont_class_ext6											=	Ltrim(Rtrim(@Cont_class_ext6)),
		--@AccessKey 									=	Ltrim(Rtrim(@AccessKey)),
		--@Icon_class											=	Ltrim(Rtrim(@Icon_class)),
		--@Icon_position									=	Ltrim(Rtrim(@Icon_position)),
		@TIMESTAMP_TMP = @TIMESTAMP_IN

	/********************************************************************************/
	/*     TEMPORARY AND FORMAL PARAMETERS MAPPING                    */
	/********************************************************************************/
	IF @CTXT_LANGUAGE_TMP = - 915
		SELECT @CTXT_LANGUAGE_TMP = NULL

	IF @CUSTOMER_NAME_TMP = '~#~'
		SELECT @CUSTOMER_NAME_TMP = NULL

	IF @CTXT_OUINSTANCE_TMP = - 915
		SELECT @CTXT_OUINSTANCE_TMP = NULL

	IF @PROJECT_NAME_TMP = '~#~'
		SELECT @PROJECT_NAME_TMP = NULL

	IF @CTXT_SERVICE_TMP = '~#~'
		SELECT @CTXT_SERVICE_TMP = NULL

	IF @REQ_NO_TMP = '~#~'
		SELECT @REQ_NO_TMP = NULL

	IF @CTXT_USER_TMP = '~#~'
		SELECT @CTXT_USER_TMP = NULL

	IF @PROCESS_NAME_TMP = '~#~'
		SELECT @PROCESS_NAME_TMP = NULL

	IF @COMPONENT_NAME_TMP = '~#~'
		SELECT @COMPONENT_NAME_TMP = NULL

	IF @ACTIVITY_NAME_TMP = '~#~'
		SELECT @ACTIVITY_NAME_TMP = NULL

	IF @UI_NAME_TMP = '~#~'
		SELECT @UI_NAME_TMP = NULL

	IF @PAGE_BT_SYNONYM_TMP = '~#~'
		SELECT @PAGE_BT_SYNONYM_TMP = NULL

	IF @SECTION_BT_SYNONYM_TMP = '~#~'
		SELECT @SECTION_BT_SYNONYM_TMP = NULL

	IF @CONTROL_BT_SYNONYM_TMP = '~#~'
		SELECT @CONTROL_BT_SYNONYM_TMP = NULL

	IF @CONTROL_ID_TMP = '~#~'
		SELECT @CONTROL_ID_TMP = NULL

	IF @VIEW_NAME_TMP = '~#~'
		SELECT @VIEW_NAME_TMP = NULL

	IF @CONTROL_TYPE_TMP = '~#~'
		SELECT @CONTROL_TYPE_TMP = NULL

	IF @VISISBLE_LENGTH_TMP = - 915
		SELECT @VISISBLE_LENGTH_TMP = NULL

	IF @HORDER_TMP = - 915
		SELECT @HORDER_TMP = NULL

	IF @VORDER_TMP = - 915
		SELECT @VORDER_TMP = NULL

	IF @ORDER_SEQ_TMP = - 915
		SELECT @ORDER_SEQ_TMP = NULL

	IF @DATA_COLUMN_WIDTH_TMP = - 915
		SELECT @DATA_COLUMN_WIDTH_TMP = NULL

	IF @LABEL_COLUMN_WIDTH_TMP = - 915
		SELECT @LABEL_COLUMN_WIDTH_TMP = NULL

	IF @PROTO_TOOLTIP_TMP = '~#~'
		SELECT @PROTO_TOOLTIP_TMP = NULL

	IF @SAMPLE_DATA_TMP = '~#~'
		SELECT @SAMPLE_DATA_TMP = NULL

	IF @CONTROL_DOC_TMP = '~#~'
		SELECT @CONTROL_DOC_TMP = NULL

	IF @CONTROL_PREFIX_TMP = '~#~'
		SELECT @CONTROL_PREFIX_TMP = NULL

	IF @UI_CONTROL_SYSID_TMP = '~#~'
		SELECT @UI_CONTROL_SYSID_TMP = NULL

	IF @UI_SECTION_SYSID_TMP = '~#~'
		SELECT @UI_SECTION_SYSID_TMP = NULL

	IF @LABEL_CONTROL_ID_TMP = '~#~'
		SELECT @LABEL_CONTROL_ID_TMP = NULL

	IF @label_column_scalemode_tmp = '~#~'
		SELECT @label_column_scalemode_tmp = NULL

	IF @data_column_scalemode_tmp = '~#~'
		SELECT @data_column_scalemode_tmp = NULL

	IF @engg_label_class_tmp = '~#~'
		SELECT @engg_label_class_tmp = NULL

	IF @engg_control_class_tmp = '~#~'
		SELECT @engg_control_class_tmp = NULL

	IF @engg_label_image_class_tmp = '~#~'
		SELECT @engg_label_image_class_tmp = NULL

	IF @engg_control_image_class_tmp = '~#~'
		SELECT @engg_control_image_class_tmp = NULL

	IF @engg_tab_sequence_tmp = - 915
		SELECT @engg_tab_sequence_tmp = NULL

	IF @engg_tab_stopforhelp_tmp = 0
		SELECT @engg_tab_stopforhelp_tmp = NULL

	IF @engg_cont_tempid = '~#~'
		SELECT @engg_cont_tempid = NULL

	--Ranjitha
	--If  @Cont_class_ext6	= '~#~'								Select	@Cont_class_ext6 = Null
	--If  @AccessKey	= '~#~'								Select	@AccessKey = Null
	--If  @Icon_position	= '~#~'								Select	@Icon_position = Null
	--If  @Icon_class	= '~#~'								Select	@Icon_class = Null
	/********************************************************************************/
	/*                   ASSIGNMENT OF DEFAULT DATA                                 */
	/********************************************************************************/
	--code modified for the Bug ID :PNR2.0_29237 starts
	-- code added by Lakshmi M on 04/10/2005
	IF @engg_tab_stopforhelp_in = 1
		SET @engg_tab_stopforhelp_tmp = 'Y'
	ELSE
		SET @engg_tab_stopforhelp_tmp = 'N'

	-- code added by Lakshmi M on 04/10/2005
	--code modified for the Bug ID :PNR2.0_29237 ends
	SELECT @DUPCOUNT_TMP = 0,
		@ERRORNO_TMP = 0,
		@SPERROR = 0,
		@M_ERRORID = 0

	SELECT @ORDER_SEQ_TMP = ISNULL(@ORDER_SEQ_TMP, 1),
		@DATA_COLUMN_WIDTH_TMP = ISNULL(@DATA_COLUMN_WIDTH_TMP, 0),
		@LABEL_COLUMN_WIDTH_TMP = ISNULL(@LABEL_COLUMN_WIDTH_TMP, 0)

	/********************************************************************************/
	/*                   NULL CHECK VALIDATION                                      */
	/********************************************************************************/
	/*                   NULL CHECK FOR COLUMN CUSTOMER_NAME                       */
	BEGIN
		IF ISNULL(@CUSTOMER_NAME_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = "ENTER VALUE FOR COLUMN : CUSTOMER NAME"

			EXEC ENGG_ERROR_SP 'EP_UI_CONTROL_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN
		END
	END

	/*                   NULL CHECK FOR COLUMN PROJECT_NAME                       */
	BEGIN
		IF ISNULL(@PROJECT_NAME_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = "ENTER VALUE FOR COLUMN : PROJECT NAME"

			EXEC ENGG_ERROR_SP 'EP_UI_CONTROL_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN
		END
	END

	/*  NULL CHECK FOR COLUMN REQ_NO                       */
	BEGIN
		IF ISNULL(@REQ_NO_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = "ENTER VALUE FOR COLUMN : REQUEST NUMBER"

			EXEC ENGG_ERROR_SP 'EP_UI_CONTROL_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN
		END
	END

	/*                   NULL CHECK FOR COLUMN PROCESS_NAME                       */
	BEGIN
		IF ISNULL(@PROCESS_NAME_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = "ENTER VALUE FOR COLUMN : PROCESS NAME"

			EXEC ENGG_ERROR_SP 'EP_UI_CONTROL_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN
		END
	END

	/*                   NULL CHECK FOR COLUMN COMPONENT_NAME                       */
	BEGIN
		IF ISNULL(@COMPONENT_NAME_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = "ENTER VALUE FOR COLUMN : COMPONENT NAME"

			EXEC ENGG_ERROR_SP 'EP_UI_CONTROL_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN
		END
	END

	/*                   NULL CHECK FOR COLUMN ACTIVITY_NAME                       */
	BEGIN
		IF ISNULL(@ACTIVITY_NAME_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = "ENTER VALUE FOR COLUMN : ACTIVITY NAME"

			EXEC ENGG_ERROR_SP 'EP_UI_CONTROL_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN
		END
	END

	/*                   NULL CHECK FOR COLUMN UI_NAME                       */
	BEGIN
		IF ISNULL(@UI_NAME_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = "ENTER VALUE FOR COLUMN : USER INTERFACE NAME"

			EXEC ENGG_ERROR_SP 'EP_UI_CONTROL_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN
		END
	END

	/*                   NULL CHECK FOR COLUMN PAGE_BT_SYNONYM                       */
	BEGIN
		IF ISNULL(@PAGE_BT_SYNONYM_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = "ENTER VALUE FOR COLUMN : PAGE BT SYNONYM"

			EXEC ENGG_ERROR_SP 'EP_UI_CONTROL_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN
		END
	END

	/*                   NULL CHECK FOR COLUMN SECTION_BT_SYNONYM                       */
	BEGIN
		IF ISNULL(@SECTION_BT_SYNONYM_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = "ENTER VALUE FOR COLUMN : SECTION BT SYNONYM"

			EXEC ENGG_ERROR_SP 'EP_UI_CONTROL_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN
		END
	END

	-- Code Added for the BugId: PNR2.0_28003 Starts
	/* IF EXISTS   (SELECT 1 FROM EP_UI_SECTION_DTL (NOLOCK)
WHERE CUSTOMER_NAME                           =     @CUSTOMER_NAME_TMP
AND   PROJECT_NAME                            =     @PROJECT_NAME_TMP
AND   REQ_NO                                  =     @REQ_NO_TMP
AND   PROCESS_NAME                            =     @PROCESS_NAME_TMP
AND   COMPONENT_NAME                          =     @COMPONENT_NAME_TMP
AND   ACTIVITY_NAME                           =     @ACTIVITY_NAME_TMP
AND   UI_NAME                                 =     @UI_NAME_TMP
AND   PAGE_BT_SYNONYM                         =     @PAGE_BT_SYNONYM_TMP
AND   SECTION_BT_SYNONYM                      =     @SECTION_BT_SYNONYM_TMP
AND   VISISBLE_FLAG         =  'N')
BEGIN
IF EXISTS   (SELECT 1 FROM ES_COMP_CTRL_TYPE_MST (NOLOCK)
WHERE CUSTOMER_NAME                           =     @CUSTOMER_NAME_TMP
AND   PROJECT_NAME                            =     @PROJECT_NAME_TMP
AND   REQ_NO                                  =     @REQ_NO_TMP
AND   PROCESS_NAME                            =     @PROCESS_NAME_TMP
AND   COMPONENT_NAME                          =     @COMPONENT_NAME_TMP
AND   CTRL_TYPE_NAME        =  @CONTROL_TYPE_IN
AND   BASE_CTRL_TYPE        =  'GRID')
BEGIN

SELECT  @ERRORMESSAGE_TMP       =   "Hidden Section can not have Grid Controls."

EXEC    ENGG_ERROR_SP
'EP_UI_CONTROL_DTL_SP_INS',
@ERRORNO_TMP,
@ERRORMESSAGE_TMP,
@CTXT_LANGUAGE_TMP,
@CTXT_OUINSTANCE_TMP,
@CTXT_SERVICE_TMP,
@CTXT_USER_TMP,
'','','','',
@SPERROR OUTPUT

SELECT @M_ERRORID = @SPERROR
RETURN
END
END
-- Code Added for the BugId: PNR2.0_28003 End */
	/*                   NULL CHECK FOR COLUMN CONTROL_BT_SYNONYM                       */
	BEGIN
		IF ISNULL(@CONTROL_BT_SYNONYM_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = "ENTER VALUE FOR COLUMN : CONTROL BT SYNONYM"

			EXEC ENGG_ERROR_SP 'EP_UI_CONTROL_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN
		END
	END

	/*                   NULL CHECK FOR COLUMN CONTROL_TYPE                       */
	BEGIN
		IF ISNULL(@CONTROL_TYPE_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = "ENTER VALUE FOR COLUMN : CONTROL TYPE"

			EXEC ENGG_ERROR_SP 'EP_UI_CONTROL_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN
		END
	END

	/*                   NULL CHECK FOR COLUMN HORDER                       */
	BEGIN
		IF ISNULL(@HORDER_TMP, - 915) = - 915
		BEGIN
			SELECT @ERRORMESSAGE_TMP = "ENTER VALUE FOR COLUMN : HORIZONTAL ORDER"

			EXEC ENGG_ERROR_SP 'EP_UI_CONTROL_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN
		END
	END

	/*                   NULL CHECK FOR COLUMN VORDER                       */
	BEGIN
		IF ISNULL(@VORDER_TMP, - 915) = - 915
		BEGIN
			SELECT @ERRORMESSAGE_TMP = "ENTER VALUE FOR COLUMN : VERTICAL ORDER"

			EXEC ENGG_ERROR_SP 'EP_UI_CONTROL_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN
		END
	END

	/*                   NULL CHECK FOR COLUMN ORDER_SEQ                       */
	BEGIN
		IF ISNULL(@ORDER_SEQ_TMP, - 915) = - 915
		BEGIN
			SELECT @ERRORMESSAGE_TMP = "ENTER VALUE FOR COLUMN : ORDER SEQUENCE"

			EXEC ENGG_ERROR_SP 'EP_UI_CONTROL_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN
		END
	END

	/*                   NULL CHECK FOR COLUMN DATA_COLUMN_WIDTH                       */
	BEGIN
		IF ISNULL(@DATA_COLUMN_WIDTH_TMP, - 915) = - 915
		BEGIN
			SELECT @ERRORMESSAGE_TMP = "ENTER VALUE FOR COLUMN : DATA COLUMN WIDTH"

			EXEC ENGG_ERROR_SP 'EP_UI_CONTROL_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN
		END
	END

	/*                   NULL CHECK FOR COLUMN LABEL_COLUMN_WIDTH                       */
	BEGIN
		IF ISNULL(@LABEL_COLUMN_WIDTH_TMP, - 915) = - 915
		BEGIN
			SELECT @ERRORMESSAGE_TMP = "ENTER VALUE FOR COLUMN : LABEL COLUMN WIDTH"

			EXEC ENGG_ERROR_SP 'EP_UI_CONTROL_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN
		END
	END

	/********************************************************************************/
	/*                   PRIMARY KEY VIOLATION CHECK                     */
	/********************************************************************************/
	/* VALUES FOR COLUMNS CUSTOMER NAME,PROJECT NAME,REQUEST NUMBER,PROCESS NAME,COMPONENT NAME,ACTIVITY NAME,USER INTERFACE NAME,PAGE BT SYNONYM,SECTION BT SYNONYM,CONTROL BT SYNONYM IN  CONTROLS CANNOT  BE REPEATED */
	BEGIN
		IF EXISTS (
				SELECT 1
				FROM EP_UI_CONTROL_DTL
				WHERE CUSTOMER_NAME = @CUSTOMER_NAME_TMP
					AND PROJECT_NAME = @PROJECT_NAME_TMP
					AND REQ_NO = @REQ_NO_TMP
					AND PROCESS_NAME = @PROCESS_NAME_TMP
					AND COMPONENT_NAME = @COMPONENT_NAME_TMP
					AND ACTIVITY_NAME = @ACTIVITY_NAME_TMP
					AND UI_NAME = @UI_NAME_TMP
					AND PAGE_BT_SYNONYM = @PAGE_BT_SYNONYM_TMP
					AND SECTION_BT_SYNONYM = @SECTION_BT_SYNONYM_TMP
					AND CONTROL_BT_SYNONYM = @CONTROL_BT_SYNONYM_TMP
				)
		BEGIN
			
			SELECT @ERRORMESSAGE_TMP = "VALUES FOR COLUMNS CUSTOMER NAME,PROJECT NAME,REQUEST NUMBER,PROCESS NAME,COMPONENT NAME,ACTIVITY NAME,USER INTERFACE NAME,
PAGE BT SYNONYM,SECTION BT SYNONYM,CONTROL BT SYNONYM IN  CONTROLS CANNOT  BE REPEATED "

			EXEC ENGG_ERROR_SP 'EP_UI_CONTROL_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN
		END
	END

	/********************************************************************************/
	/*                   CHECK FOR FORIEGN KEY VIOLATION                            */
	/********************************************************************************/
	/* VALUES CANNOT ADDED IN  EP_UI_CONTROL_DTL AS DATA DOES NOT EXISTS FOR THE MASTER  EP_UI_SECTION_DTL*/
	BEGIN
		IF NOT EXISTS (
				SELECT 1
				FROM EP_UI_SECTION_DTL
				WHERE CUSTOMER_NAME = @CUSTOMER_NAME_TMP
					AND PROJECT_NAME = @PROJECT_NAME_TMP
					AND REQ_NO = @REQ_NO_TMP
					AND PROCESS_NAME = @PROCESS_NAME_TMP
					AND COMPONENT_NAME = @COMPONENT_NAME_TMP
					AND ACTIVITY_NAME = @ACTIVITY_NAME_TMP
					AND UI_NAME = @UI_NAME_TMP
					AND PAGE_BT_SYNONYM = @PAGE_BT_SYNONYM_TMP
					AND SECTION_BT_SYNONYM = @SECTION_BT_SYNONYM_TMP
				)
		BEGIN
		
			SELECT @ERRORMESSAGE_TMP = "COLUMNS CUSTOMER NAME,PROJECT NAME,REQUEST NUMBER,PROCESS NAME,COMPONENT NAME,ACTIVITY NAME,USER INTERFACE NAME,PAGE BT SYNONYM,SECTION BT SYNONYM,CONTROL BT SYNONYMCUSTOMER_NAME,PROJECT_NAME,REQ_NO,PROCESS_NAME,COMPON


ENT_NAME,ACTIVITY_NAME,UI_NAME,PAGE_BT_SYNONYM,SECTION_BT_SYNONYM OF TABLE UI SECTIONS HAS REFERENCE TO TABLE CONTROLS"



			EXEC ENGG_ERROR_SP 'EP_UI_CONTROL_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN
		END
	END

	/********************************************************************************/
	/*                   INSERT DATA INTO THE TABLE    EP_UI_CONTROL_DTL            */
	/********************************************************************************/
	BEGIN
		EXEC ENGG_GET_NEWSYSID 'EP_UI_CONTROL_DTL',
			@UI_CONTROL_SYSID_TMP OUTPUT

		SELECT @UI_SECTION_SYSID_TMP = DBO.EP_GET_UI_SECTION_SYSID(@CTXT_LANGUAGE_TMP, @CTXT_OUINSTANCE_TMP, @CTXT_SERVICE_TMP, @CTXT_USER_TMP, @CUSTOMER_NAME_TMP, @PROJECT_NAME_TMP, @REQ_NO_TMP, @PROCESS_NAME_TMP, @COMPONENT_NAME_TMP, @ACTIVITY_NAME_TMP, @UI_NAME_TMP, @PAGE_BT_SYNONYM_TMP, @SECTION_BT_SYNONYM_TMP)

		-- Ngplf Starts
		DECLARE @IsPlatform engg_flag

		SET @IsPlatform = 'N'

		IF EXISTS (
				SELECT 'X'
				FROM ep_ui_mst(NOLOCK)
				WHERE customer_name = @CUSTOMER_NAME_TMP
					AND project_name = @PROJECT_NAME_TMP
					AND process_name = @PROCESS_NAME_TMP
					AND component_name = @COMPONENT_NAME_TMP
					AND activity_name = @ACTIVITY_NAME_TMP
					AND ui_name = @UI_NAME_TMP
					AND isnull(IsGlance, 'N') = 'Y'
				)
		BEGIN
			SET @IsPlatform = 'Y'
				--Set @HORDER_TMP		= 0
				--Set @VORDER_TMP		= 0
				--SELECT	@HORDER_TMP			= isnull(max(horder),1000) + 1,
				--		@VORDER_TMP			= isnull(max(vorder),1000) + 1
				--FROM	ep_ui_control_dtl (nolock)
				--WHERE	customer_name		= @CUSTOMER_NAME_TMP
				--AND		project_name		= @PROJECT_NAME_TMP
				--AND		process_name		= @PROCESS_NAME_TMP
				--AND		component_name		= @COMPONENT_NAME_TMP
				--AND		activity_name		= @ACTIVITY_NAME_TMP
				--AND		ui_name				= @UI_NAME_TMP			
				--AND		isnull(IsPlatform, 'N') = 'Y'
				--If	isnull(@HORDER_TMP,0) = 0 
				--Begin
				--	Set		@HORDER_TMP = 1000
				--	Set		@VORDER_TMP = 1000
				--END
		END

		-- Ngplf Ends
		INSERT INTO EP_UI_CONTROL_DTL (
			CUSTOMER_NAME,
			PROJECT_NAME,
			REQ_NO,
			PROCESS_NAME,
			COMPONENT_NAME,
			ACTIVITY_NAME,
			UI_NAME,
			PAGE_BT_SYNONYM,
			SECTION_BT_SYNONYM,
			CONTROL_BT_SYNONYM,
			--                    CONTROL_ID,
			--                    VIEW_NAME,
			CONTROL_TYPE,
			--                    VISISBLE_LENGTH,
			HORDER,
			VORDER,
			ORDER_SEQ,
			DATA_COLUMN_WIDTH,
			LABEL_COLUMN_WIDTH,
			UI_CONTROL_SYSID,
			UI_SECTION_SYSID,
			TIMESTAMP,
			CREATEDBY,
			CREATEDDATE,
			MODIFIEDBY,
			MODIFIEDDATE,
			CONTROL_ID,
			VIEW_NAME,
			VISISBLE_LENGTH,
			PROTO_TOOLTIP,
			SAMPLE_DATA,
			CONTROL_DOC,
			CONTROL_PREFIX,
			LABEL_CONTROL_ID,
			LABEL_COLUMN_SCALEMODE,
			DATA_COLUMN_SCALEMODE,
			TAB_SEQ,
			HELP_TABSTOP,
			LABELCLASS,
			CONTROLCLASS,
			LABELIMAGECLASS,
			CONTROLIMAGECLASS,
			Set_User_Pref, -- Code modified  for PNR2.0_23541
			wrkreqno, --chan
			freezecount, --added for PNR2.0_26860
			controlimage,
			TemplateID, -- Added for PLF2.0_14096
			rowspan,
			colspan,
			TemplateCategory,
			TemplateSpecific,
			--Ranjitha
			AccessKey,
			Icon_class,
			Icon_position,
			Control_class_ext6,
			IsPlatform,
			dynamicstyle,
			imageasdata,
			ExtensionReqd,
			AssociateControl,---code added for TECH-63527
			ForResponsive,	--Code added for TECH-69624
			ControlFormat,	--Code Added for the Defect Id TECH-72114
			ButtonNature,	--Code added for TECH-75230
			InlineStyle		--Code added for TECH-75230
			)
		VALUES (
			@CUSTOMER_NAME_TMP,
			@PROJECT_NAME_TMP,
			@REQ_NO_TMP,
			@PROCESS_NAME_TMP,
			@COMPONENT_NAME_TMP,
			@ACTIVITY_NAME_TMP,
			@UI_NAME_TMP,
			@PAGE_BT_SYNONYM_TMP,
			@SECTION_BT_SYNONYM_TMP,
			@CONTROL_BT_SYNONYM_TMP,
			--                    @CONTROL_ID_TMP,
			--                    @VIEW_NAME_TMP,
			@CONTROL_TYPE_TMP,
			--                    @VISISBLE_LENGTH_TMP,
			@HORDER_TMP,
			@VORDER_TMP,
			@ORDER_SEQ_TMP,
			@DATA_COLUMN_WIDTH_TMP,
			@LABEL_COLUMN_WIDTH_TMP,
			@UI_CONTROL_SYSID_TMP,
			@UI_SECTION_SYSID_TMP,
			@TIMESTAMP_TMP,
			@CTXT_USER_TMP,
			GETDATE(),
			@CTXT_USER_TMP,
			GETDATE(),
			@CONTROL_ID_TMP,
			@CONTROL_ID_TMP, -- @VIEW_NAME_TMP,
			@VISISBLE_LENGTH_TMP,
			@PROTO_TOOLTIP_TMP,
			@SAMPLE_DATA_TMP,
			@CONTROL_DOC_TMP,
			@CONTROL_PREFIX_TMP,
			@LABEL_CONTROL_ID_TMP,
			@LABEL_COLUMN_SCALEMODE_TMP,
			@DATA_COLUMN_SCALEMODE_TMP,
			@engg_tab_sequence_tmp,
			@engg_tab_stopforhelp_TMP,
			@engg_label_class_TMP,
			@engg_control_class_TMP,
			@engg_label_image_class_TMP,
			@engg_control_image_class_TMP,
			@user_pref, -- Code modified  for PNR2.0_23541
			@engg_req_no,
			@freezecount,
			@Engg_cont_Ctrlimg,
			@engg_cont_tempid, -- Added for PLF2.0_14096
			@Engg_cont_rowspan,
			@Engg_cont_colspan,
			@ctrl_temp_cat,
			@ctrl_temp_specific,
			----Ranjitha
			@AccessKey,
			@Icon_class,
			@Icon_position,
			@Cont_class_ext6,
			@IsPlatform,
			@engg_dynamicstyle,
			@engg_imageasdata,
			CASE WHEN @engg_extnreqd = '1' THEN 'Yes' ELSE 'No' END , ---Code added for TECH-60451
			@engg_MSC_Ass_control, --code added for TECH-63527
			@Engg_cont_forresponsive,	--Code added for TECH-69624
			CASE WHEN @engg_cont_control_format = 'Controls Beside Captions' THEN 'Bes'
				 WHEN @engg_cont_control_format = 'Top Inner'				 THEN 'Top' ELSE '' end,	--Code Added for the Defect Id TECH-72114
			@ButtonNature,	--Code added for TECH-75230
			@Inlinestyle	--Code added for TECH-75230
			) --added for PNR2.0_26860
	END
END

	SET QUOTED_IDENTIFIER OFF;
			GO
GO

IF EXISTS ( SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'EP_UI_CONTROL_DTL_SP_INS' AND TYPE = 'P' )
BEGIN
	GRANT EXEC ON  EP_UI_CONTROL_DTL_SP_INS TO PUBLIC
END
GO


