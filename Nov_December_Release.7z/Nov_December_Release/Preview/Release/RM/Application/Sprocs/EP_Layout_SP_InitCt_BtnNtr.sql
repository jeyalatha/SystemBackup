if exists ( Select 'y' from sysobjects where name = 'EP_Layout_SP_InitCt_BtnNtr' and type = 'P')
    begin
        drop proc EP_Layout_SP_InitCt_BtnNtr
    end
go


/*********************************************************************************/
/* Procedure					: EP_Layout_SP_InitCt_BtnNtr					 */
/* Description					: 												 */
/*********************************************************************************/
/* Project						: 												 */
/* EcrNo						: Prw_ECR_00									 */
/* Version						: 												 */
/*********************************************************************************/
/* Referenced					: 												 */
/* Tables						: 												 */
/*********************************************************************************/
/* Development history			: 												 */
/*********************************************************************************/
/* Author						: ModelExplorer									*/
/* Date							: Nov  2 2022  8:00PM							 */
/*********************************************************************************/
/* Modification History			: 												 */
/*********************************************************************************/
/* Modified By					: Ponmalar A									 */
/* Date							: 02-Dec-2022									 */
/* DefectID						: TECH-75230									 */
/*********************************************************************************/

Create Procedure EP_Layout_SP_InitCt_BtnNtr
	@ctxt_language_in      	ctxt_language, --Input 
	@ctxt_ouinstance_in    	ctxt_ouinstance, --Input 
	@ctxt_service_in       	ctxt_service, --Input 
	@ctxt_user_in          	ctxt_user, --Input 
	@engg_component_in     	engg_description, --Input 
	@engg_customer_name_in 	engg_name, --Input 
	@engg_process_descr_in 	engg_description, --Input 
	@engg_project_name_in  	engg_name, --Input 
	@engg_req_no_in        	engg_name, --Input 
	@m_errorid             	int output --To Return Execution Status
as
Begin
	-- nocount should be switched on to prevent phantom rows
	Set nocount on

	-- @m_errorid should be 0 to Indicate Success
	Set @m_errorid = 0

	-- declaration of temporary variables


	-- temporary and formal parameters mapping

	Set @ctxt_service_in        = ltrim(rtrim(@ctxt_service_in))
	Set @ctxt_user_in           = ltrim(rtrim(@ctxt_user_in))
	Set @engg_component_in      = ltrim(rtrim(@engg_component_in))
	Set @engg_customer_name_in  = ltrim(rtrim(@engg_customer_name_in))
	Set @engg_process_descr_in  = ltrim(rtrim(@engg_process_descr_in))
	Set @engg_project_name_in   = ltrim(rtrim(@engg_project_name_in))
	Set @engg_req_no_in         = ltrim(rtrim(@engg_req_no_in))

	-- null checking

	IF @ctxt_language_in = -915
		Select @ctxt_language_in = null  

	IF @ctxt_ouinstance_in = -915
		Select @ctxt_ouinstance_in = null  

	IF @ctxt_service_in = '~#~' 
		Select @ctxt_service_in = null  

	IF @ctxt_user_in = '~#~' 
		Select @ctxt_user_in = null  

	IF @engg_component_in = '~#~' 
		Select @engg_component_in = null  

	IF @engg_customer_name_in = '~#~' 
		Select @engg_customer_name_in = null  

	IF @engg_process_descr_in = '~#~' 
		Select @engg_process_descr_in = null  

	IF @engg_project_name_in = '~#~' 
		Select @engg_project_name_in = null  

	IF @engg_req_no_in = '~#~' 
		Select @engg_req_no_in = null  

	SELECT	''					'buttonnature'
	UNION
	SELECT	quick_code_value	'buttonnature' 
	FROM ep_quick_code_mst (NOLOCK)
	WHERE	quick_code_type	=	'ButtonNature'

	/* 
	-- OutputList
	Select
		null 'buttonnature', 
	*/

	Set nocount off
End


