IF EXISTS(SELECT 'X' From SYSOBJECTS WHERE NAME ='ep_layout_sp_savgrd_hck' AND TYPE='P')
   BEGIN
        DROP PROC ep_layout_sp_savgrd_hck
   END
GO
 /*      V E R S I O N      :  2.0.4    */
/*      Released By        :  PTech    */
/*      Release Comments   :  Released on 05-Nov-2004 (Patch Release-7)    */
/****** Object:  Stored Procedure dbo.ep_layout_sp_savgrd_hck    Script Date: 11/6/03 5:21:00 PM ******/
/******************************************************************************************************
procedure name and id :ep_layout_sp_savgrd_hck
description             :Currently Nothing is written, later depending on the
functionality, it is written
name of the author      :Madugula Srinivas
date created            :15-Oct-2003
query file name         :ep_layout_sp_savgrd_hck.sql
method name    :ep_layout_mt_savgrd_hck
modifications history   :
modified by       :B.Shafina Begum
modified date           :17-jan-2004
modified purpose        :to generate seq no for the tasks
to check for horder,vorder only if atleast one column is present in the grid
******************************************************************************************************/
/*Modified BY   : Anuradha M
Modified Date  : 16-Dec-2005
Modification Descr : Bug Id : PNR2.0_5031
Bug Descr : 1. When publishing the ECR, the below error occurs. "INSERT statement conflicted with TABLE FOREIGN KEY 
constraint 'de_fw_req_task_local_info_fkey_de_fw_req_task'. The conflict occurred in database 'TrainingDB203x', table 'de_fw_req_task'.
******************************************************************************************************/
/*Modified BY          : Sangeetha L															 */
/*Modified Date         : 11-Feb-2006															 */
/*Bug Id                   : PNR2.0_6199														*/
/************************************************************************************************/
/*Modified BY          : Chanheetha N A															*/
/*Modified Date         : 24-Aug-2006															*/
/*Bug Id                   : PNR2.0_10007														 */
/************************************************************************************************/
/*Modified BY          : Chanheetha N A													*/
/*Modified Date         : 05-Mar-2007													*/
/*Bug Id                   : PNR2.0_12484												*/
/****************************************************************************************/
/*Modified BY          : Jeyalatha K													*/
/*Modified Date         : 21-Sep-2011													*/
/*Bug Id                   : PNR2.0_33469												*/
/***************************************************************************************/
/* Modified by  : Veena U															*/
/* Date         : 28-Mar-2016                                                 */
/* Call ID		: PLF2.0_17570                                               */
/********************************************************************************/ 
/* modified by			Date				Defect ID							*/
/* Veena U				08-Jun-2016			PLF2.0_18487						*/
/********************************************************************************/
/* modified by                    Date                       Defect ID            */
/* Veena U                        22-Jun-2016                PLF2.0_19034∩┐╜        */
/**********************************************************************************/
/* Modified by : Jeya Latha K/Ganesh Prabhu S	for callid TECH-7349				*/
/* Modified on : 14-03-2017				 											*/
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and New Feature Organization chart */
/***********************************************************************************/
--grant all on ep_layout_sp_savgrd_hck to public
/* Modified by : Ganesh Prabhu S/Ranjitha R      for callid  TECH-10118                   */
/* Modified on : 30-May-2017                                                            */
/* Description : Platform Feature Release                                         */
/****************************************************************************************/
/* Modified by  : JeyaLatha K/Ranjitha R	Date: 31-Jan-2018  Defect ID : TECH-18349 */  
/***************************************************************************************/
/* Modified by  : Ranjitha R	Date: 28-Feb-2018  Defect ID : TECH-19347 */  
/***************************************************************************************/
/* Modified by : Ranjitha R		Date: 29-Mar-2018  Defect ID : TECH-20326 */  
/* Modified by : Jeya Latha K	Date: 07-Feb-2020  Defect ID : TECH-42760 */  
/* Modified by : Jeya Latha K   Date: 27-May-2020  Defect ID : TECH-46646 */
/***************************************************************************************/
/* Modified by : Ponmalar A		Date: 29-Sep-2022  Defect ID : TECH-73216			   */
/***************************************************************************************/
/* Modified by : Janani S		Date: 15-Nov-2022  Defect ID : TECH-74323			   */
/***************************************************************************************/
create PROCEDURE ep_layout_sp_savgrd_hck
@ctxt_language             engg_ctxt_language,
@ctxt_ouinstance           engg_ctxt_ouinstance,
@ctxt_service              engg_ctxt_service,
@ctxt_user                 engg_ctxt_user,
@engg_act_descr            engg_description,
@engg_component            engg_description,
@engg_customer_name        engg_name,
@engg_enum_page_bts        engg_name  ,
@engg_enum_sec_bts         engg_name  ,
@engg_grid_grid_code       engg_name,
@engg_grid_page_bts        engg_name,
@engg_grid_sec_bts         engg_name,
@engg_process_descr        engg_description,
@engg_project_name         engg_name,
@engg_req_no               engg_name,
@engg_ui_descr             engg_description,
@guid                      engg_guid,
@fprowno                   engg_rowno,
@engg_del_columns          engg_documentation, -- added for Bug Id :PNR2.0_33469
@m_errorid                 engg_seqno output
as
begin

set nocount on

select @m_errorid = 0

--temporary and formal parameters mapping
select @ctxt_language                 = @ctxt_language
select @ctxt_ouinstance               = @ctxt_ouinstance
select @ctxt_service                  = ltrim(rtrim(@ctxt_service))
select @ctxt_user                     = ltrim(rtrim(@ctxt_user))
select @engg_act_descr                = ltrim(rtrim(@engg_act_descr))
select @engg_component                = ltrim(rtrim(@engg_component))
select @engg_customer_name            = ltrim(rtrim(@engg_customer_name))
select @engg_grid_grid_code           = ltrim(rtrim(@engg_grid_grid_code))
select @engg_grid_page_bts            = ltrim(rtrim(@engg_grid_page_bts))
select @engg_grid_sec_bts             = ltrim(rtrim(@engg_grid_sec_bts))
select @engg_process_descr            = ltrim(rtrim(@engg_process_descr))
select @engg_project_name             = ltrim(rtrim(@engg_project_name))
select @engg_req_no                   = ltrim(rtrim(@engg_req_no))
select @engg_ui_descr                 = ltrim(rtrim(@engg_ui_descr))
select @guid                          = ltrim(rtrim(@guid))
select @fprowno                       = @fprowno
select @engg_del_columns              = ltrim(rtrim(@engg_del_columns)) -- added for Bug Id :PNR2.0_33469

--null checking
if @ctxt_language = -915 
	select @ctxt_language = null
if @ctxt_ouinstance = -915 
	select @ctxt_ouinstance = null
if @ctxt_service = '~#~' 
	select @ctxt_service = null
if @ctxt_user = '~#~'  
	select @ctxt_user = null
if @engg_act_descr = '~#~' 
	select @engg_act_descr = null
if @engg_component = '~#~' 
	select @engg_component = null
if @engg_customer_name = '~#~' 
	select @engg_customer_name = null
if @engg_grid_grid_code = '~#~' 
	select @engg_grid_grid_code = null
if @engg_grid_page_bts = '~#~' 
	select @engg_grid_page_bts = null
if @engg_grid_sec_bts = '~#~' 
	select @engg_grid_sec_bts = null
if @engg_process_descr = '~#~' 
	select @engg_process_descr = null
if @engg_project_name = '~#~' 
	select @engg_project_name = null
if @engg_req_no = '~#~'  
	select @engg_req_no = null
if @engg_ui_descr = '~#~' 
	select @engg_ui_descr = null
if @guid = '~#~'  
	select @guid = null
if @fprowno = -915  
	select @fprowno = null
if @engg_del_columns = '~#~' 
	select @engg_del_columns = null  -- Code added for Bug Id :PNR2.0_33469

declare	@component_name_tmp			engg_name,
		@prc_name_tmp				engg_name,
		@act_name_tmp				engg_name,
		@ui_name_tmp				engg_name,
		@row_count					engg_seqno,
		@max_val					engg_seqno,
		@ActionType_init			engg_name,
		@ActionType_fet				engg_name,
		@tmp_ActionName				engg_name,
		@tmp_Action_desc			engg_description,
		@task_name_tmp				engg_name,
		@max_seq_no					engg_length
declare @comp_pfx_tmp				engg_name
declare @ui_pfx_tmp					engg_name,
		@flow_action_name			engg_name,
-- code modified by shafina on 16-feb-2005 for PREVIEWPFSUPPORT_000009 ( When i generate the UI the layout is not as defined. it doesn't show the grid in the bottom)
		@count						engg_seqno,
		@col_no						engg_seqno,
-- Code added by chanheetha N A for the call id :  on 23-Aug-2006
		@msg						engg_documentation,
		@column_bt_synonym			engg_name ,
		@col_type					engg_name,
		@engg_grid_btsynname		engg_name
-- Code added by chanheetha N A for the call id :  on 23-Aug-2006
-- code modified by shafina on 16-feb-2005 for PREVIEWPFSUPPORT_000009 ( When i generate the UI the layout is not as defined. it doesn't show the grid in the bottom)
		,@templ_count				engg_seqno
declare @engg_base_req_no			engg_name, 
		@renderas					engg_name, 
		@base_ctrltype				engg_name, 
		@count1						engg_seqno,
		@IsGlance					engg_name

	If isnull(@engg_del_columns,'') <> ''
	Begin
		select @m_errorid = 10001
		return
	End

select @engg_base_req_no = 'BASE'
-- code added by shafina on 16-feb-2004
if @fprowno < 1
begin
	exec engg_error_sp
	'ep_layout_sp_savgrd_hck',  1,     'Enter Atleast One Row',
		@ctxt_language,     @ctxt_ouinstance,	@ctxt_service,		@ctxt_user,      '',     '',
		'',					'',					@m_errorid out
	if @m_errorid <> 0
	return
end

/*Getting Process Name for incoming Process Desc.*/
select	@prc_name_tmp = rtrim(process_name)
from	ep_ui_req_dtl (nolock)
where	customer_name	= rtrim(@engg_customer_name)
and		project_name	= rtrim(@engg_project_name)
and		process_descr	= rtrim(@engg_process_descr)
and		req_no			= rtrim(@engg_req_no)

/*Getting Component Name for Given Component Description*/
select	@component_name_tmp = rtrim(component_name)
from	ep_ui_req_dtl (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @prc_name_tmp
and		component_descr = @engg_component
and		req_no			= rtrim(@engg_req_no)

/*Getting Activity Name for Activity Desc*/
select	@act_name_tmp = rtrim(activity_name)
from	ep_ui_req_dtl (nolock)
where	customer_name	= rtrim(@engg_customer_name)
and		project_name	= rtrim(@engg_project_name)
and		req_no			= rtrim(@engg_req_no)
and		process_name	= rtrim(@prc_name_tmp)
and		component_name  = rtrim(@component_name_tmp)
and		activity_descr	= rtrim(@engg_act_descr)

/*Getting UI Name for UI Desc*/
select	@ui_name_tmp = rtrim(ui_name)
from	ep_ui_req_dtl (nolock)
where	customer_name	= rtrim(@engg_customer_name)
and		project_name	= rtrim(@engg_project_name)
and		req_no			= rtrim(@engg_req_no)
and		process_name	= rtrim(@prc_name_tmp)
and		component_name	= rtrim(@component_name_tmp)
and		activity_name	= rtrim(@act_name_tmp)
and		ui_descr		= rtrim(@engg_ui_descr)

select	@IsGlance		= isnull(IsGlance,'N')
from	ep_ui_mst (nolock)
where	customer_name	= rtrim(@engg_customer_name)
and		project_name	= rtrim(@engg_project_name)
and		req_no			= rtrim(@engg_req_no)
and		process_name	= rtrim(@prc_name_tmp)
and		component_name	= rtrim(@component_name_tmp)
and		activity_name	= rtrim(@act_name_tmp)
and		ui_name			= rtrim(@ui_name_tmp)




select	@renderas		= renderas,
		@base_ctrltype	= base_ctrl_type
from	ep_ui_control_dtl ctrl(nolock),
		es_comp_ctrl_type_mst	ctype(nolock)
where	ctrl.customer_name		= ctype.customer_name
and		ctrl.project_name		= ctype.project_name
and		ctrl.process_name		= ctype.process_name
and		ctrl.component_name		= ctype.component_name
and		ctrl.control_type		= ctype.ctrl_type_name
and		ctrl.customer_name		= rtrim(@engg_customer_name)
and  	ctrl.project_name		= rtrim(@engg_project_name)
and  	ctrl.process_name		= rtrim(@prc_name_tmp)
and  	ctrl.component_name  	= rtrim(@component_name_tmp)
and  	ctrl.activity_name		= rtrim(@act_name_tmp)
and  	ctrl.ui_name			= rtrim(@ui_name_tmp)
and  	ctrl.page_bt_synonym	= rtrim(@engg_grid_page_bts)
and  	ctrl.section_bt_synonym	= rtrim(@engg_grid_sec_bts)
and  	ctrl.control_bt_synonym	= rtrim(@engg_grid_grid_code)


If @base_ctrltype = 'TreeGrid'
Begin
	If not exists (select 'x'
	from	ep_ui_grid_dtl	grd(nolock),
			ep_ui_control_dtl	ctrl(nolock),
			es_comp_ctrl_type_mst	ctype(nolock)
	where	ctrl.customer_name		= ctype.customer_name
	and		ctrl.project_name		= ctype.project_name
	and		ctrl.process_name		= ctype.process_name
	and		ctrl.component_name		= ctype.component_name
	and		ctrl.control_type		= ctype.ctrl_type_name
	and		ctrl.customer_name		= grd.customer_name
	and		ctrl.project_name		= grd.project_name
	and		ctrl.process_name		= grd.process_name
	and		ctrl.component_name		= grd.component_name
	and		ctrl.activity_name		= grd.activity_name
	and		ctrl.ui_name			= grd.ui_name
	and		ctrl.page_bt_synonym	= grd.page_bt_synonym
	and		ctrl.section_bt_synonym	= grd.section_bt_synonym
	and		ctrl.control_bt_synonym	= grd.control_bt_synonym
	and		grd.customer_name		= rtrim(@engg_customer_name)
	and  	grd.project_name		= rtrim(@engg_project_name)
	and  	grd.process_name		= rtrim(@prc_name_tmp)
	and  	grd.component_name  	= rtrim(@component_name_tmp)
	and  	grd.activity_name		= rtrim(@act_name_tmp)
	and  	grd.ui_name				= rtrim(@ui_name_tmp)
	and  	grd.page_bt_synonym		= rtrim(@engg_grid_page_bts)
	and  	grd.section_bt_synonym	= rtrim(@engg_grid_sec_bts)
	and  	grd.control_bt_synonym	= rtrim(@engg_grid_grid_code)
	and		isnull(grd.TreeColumn,'N')		= 'Y'
	and		ISNULL(ctype.base_ctrl_type,'') = 'TreeGrid')
	and exists ( select 'x'
	from ep_ui_grid_dtl (nolock)
	where	customer_name		= rtrim(@engg_customer_name)
	and  	project_name		= rtrim(@engg_project_name)
	and  	process_name		= rtrim(@prc_name_tmp)
	and  	component_name  	= rtrim(@component_name_tmp)
	and  	activity_name		= rtrim(@act_name_tmp)
	and  	ui_name				= rtrim(@ui_name_tmp)
	and  	page_bt_synonym		= rtrim(@engg_grid_page_bts)
	and  	section_bt_synonym	= rtrim(@engg_grid_sec_bts)
	and  	control_bt_synonym	= rtrim(@engg_grid_grid_code))
	Begin
		Raiserror ('Please provide ''Tree Column'' for any one of the columns, Since this control is a Tree Grid.',16,4,@engg_grid_grid_code)
		Return
	End

	select @count1 = 0
	select @count1 = count(*)
	from	ep_ui_grid_dtl	grd(nolock),
			ep_ui_control_dtl	ctrl(nolock),
			es_comp_ctrl_type_mst	ctype(nolock)
	where	ctrl.customer_name		= ctype.customer_name
	and		ctrl.project_name		= ctype.project_name
	and		ctrl.process_name		= ctype.process_name
	and		ctrl.component_name		= ctype.component_name
	and		ctrl.control_type		= ctype.ctrl_type_name
	and		ctrl.customer_name		= grd.customer_name
	and		ctrl.project_name		= grd.project_name
	and		ctrl.process_name		= grd.process_name
	and		ctrl.component_name		= grd.component_name
	and		ctrl.activity_name		= grd.activity_name
	and		ctrl.ui_name			= grd.ui_name
	and		ctrl.page_bt_synonym	= grd.page_bt_synonym
	and		ctrl.section_bt_synonym	= grd.section_bt_synonym
	and		ctrl.control_bt_synonym	= grd.control_bt_synonym
	and		grd.customer_name		= rtrim(@engg_customer_name)
	and  	grd.project_name		= rtrim(@engg_project_name)
	and  	grd.process_name		= rtrim(@prc_name_tmp)
	and  	grd.component_name  	= rtrim(@component_name_tmp)
	and  	grd.activity_name		= rtrim(@act_name_tmp)
	and  	grd.ui_name				= rtrim(@ui_name_tmp)
	and  	grd.page_bt_synonym		= rtrim(@engg_grid_page_bts)
	and  	grd.section_bt_synonym	= rtrim(@engg_grid_sec_bts)
	and  	grd.control_bt_synonym	= rtrim(@engg_grid_grid_code)
	and		isnull(grd.TreeColumn,'N')		= 'Y'
	and		ISNULL(ctype.base_ctrl_type,'') = 'TreeGrid'	
	
	if isnull(@count1,0) > 1
	Begin
		Raiserror ('''Tree Column'' should be enabled for only one column in the Tree Grid.',16,4,@engg_grid_grid_code)
		Return
	End

End

if @renderas	= 'Gridtoform'
Begin
	If not exists (select 'x'
	from	ep_ui_grid_dtl	grd(nolock),
			ep_ui_control_dtl	ctrl(nolock),
			es_comp_ctrl_type_mst	ctype(nolock)
	where	ctrl.customer_name		= ctype.customer_name
	and		ctrl.project_name		= ctype.project_name
	and		ctrl.process_name		= ctype.process_name
	and		ctrl.component_name		= ctype.component_name
	and		ctrl.control_type		= ctype.ctrl_type_name
	and		ctrl.customer_name		= grd.customer_name
	and		ctrl.project_name		= grd.project_name
	and		ctrl.process_name		= grd.process_name
	and		ctrl.component_name		= grd.component_name
	and		ctrl.activity_name		= grd.activity_name
	and		ctrl.ui_name			= grd.ui_name
	and		ctrl.page_bt_synonym	= grd.page_bt_synonym
	and		ctrl.section_bt_synonym	= grd.section_bt_synonym
	and		ctrl.control_bt_synonym	= grd.control_bt_synonym
	and		grd.customer_name		= rtrim(@engg_customer_name)
	and  	grd.project_name		= rtrim(@engg_project_name)
	and  	grd.process_name		= rtrim(@prc_name_tmp)
	and  	grd.component_name  	= rtrim(@component_name_tmp)
	and  	grd.activity_name		= rtrim(@act_name_tmp)
	and  	grd.ui_name				= rtrim(@ui_name_tmp)
	and  	grd.page_bt_synonym		= rtrim(@engg_grid_page_bts)
	and  	grd.section_bt_synonym	= rtrim(@engg_grid_sec_bts)
	and  	grd.control_bt_synonym	= rtrim(@engg_grid_grid_code)
	and		isnull(grd.gridtoform,'N')	= 'Y'
	and		ISNULL(ctype.renderas,'')	= 'GridtoForm')
	Begin
		Raiserror ('Please provide ''Grid to Form'' for any one of the columns, Since this control is enabled for ''Grid to Form''.',16,4,@engg_grid_grid_code)
		Return
	End
End

If @renderas = 'RowExpander'
Begin
	Declare @totcol		engg_seqno
	select	@totcol = 0

	select	@totcol		= count(distinct column_bt_synonym)
	from	ep_ui_grid_dtl grd (nolock)
	where	grd.customer_name		= rtrim(@engg_customer_name)
	and  	grd.project_name		= rtrim(@engg_project_name)
	and  	grd.process_name		= rtrim(@prc_name_tmp)
	and  	grd.component_name  	= rtrim(@component_name_tmp)
	and  	grd.activity_name		= rtrim(@act_name_tmp)
	and  	grd.ui_name				= rtrim(@ui_name_tmp)
	and  	grd.page_bt_synonym		= rtrim(@engg_grid_page_bts)
	and  	grd.section_bt_synonym	= rtrim(@engg_grid_sec_bts)
	and  	grd.control_bt_synonym	= rtrim(@engg_grid_grid_code)

	If not exists (select 'x'
	from	ep_ui_grid_dtl	grd(nolock),
			ep_ui_control_dtl	ctrl(nolock),
			es_comp_ctrl_type_mst	ctype(nolock)
	where	ctrl.customer_name		= ctype.customer_name
	and		ctrl.project_name		= ctype.project_name
	and		ctrl.process_name		= ctype.process_name
	and		ctrl.component_name		= ctype.component_name
	and		ctrl.control_type		= ctype.ctrl_type_name
	and		ctrl.customer_name		= grd.customer_name
	and		ctrl.project_name		= grd.project_name
	and		ctrl.process_name		= grd.process_name
	and		ctrl.component_name		= grd.component_name
	and		ctrl.activity_name		= grd.activity_name
	and		ctrl.ui_name			= grd.ui_name
	and		ctrl.page_bt_synonym	= grd.page_bt_synonym
	and		ctrl.section_bt_synonym	= grd.section_bt_synonym
	and		ctrl.control_bt_synonym	= grd.control_bt_synonym
	and		grd.customer_name		= rtrim(@engg_customer_name)
	and  	grd.project_name		= rtrim(@engg_project_name)
	and  	grd.process_name		= rtrim(@prc_name_tmp)
	and  	grd.component_name  	= rtrim(@component_name_tmp)
	and  	grd.activity_name		= rtrim(@act_name_tmp)
	and  	grd.ui_name				= rtrim(@ui_name_tmp)
	and  	grd.page_bt_synonym		= rtrim(@engg_grid_page_bts)
	and  	grd.section_bt_synonym	= rtrim(@engg_grid_sec_bts)
	and  	grd.control_bt_synonym	= rtrim(@engg_grid_grid_code)
	and		isnull(grd.RowExpander,'N')	= 'Y' 
	and		ISNULL(ctype.renderas,'')	= 'RowExpander')
	and		isnull(@totcol,0)			> 1
	Begin
		Raiserror ('Please provide ''Row Expander'' for any one of the column, Since this control is enabled for ''Row Expander''.',16,4,@engg_grid_grid_code)
		Return
	End
End
--  code modified by shafina on 17-jan-2004 to check for horder,vorder only
-- if atleast one column is present in the grid

Select	@templ_count		= COUNT(column_bt_synonym)
from	ep_ui_grid_dtl	grd(nolock),
		ep_ui_control_dtl	ctrl(nolock),
		es_comp_ctrl_type_mst	ctype(nolock)
where	ctrl.customer_name		= ctype.customer_name
and		ctrl.project_name		= ctype.project_name
and		ctrl.process_name		= ctype.process_name
and		ctrl.component_name		= ctype.component_name
and		ctrl.control_type		= ctype.ctrl_type_name
and		ctrl.customer_name		= grd.customer_name
and		ctrl.project_name		= grd.project_name
and		ctrl.process_name		= grd.process_name
and		ctrl.component_name		= grd.component_name
and		ctrl.activity_name		= grd.activity_name
and		ctrl.ui_name			= grd.ui_name
and		ctrl.page_bt_synonym	= grd.page_bt_synonym
and		ctrl.section_bt_synonym	= grd.section_bt_synonym
and		ctrl.control_bt_synonym	= grd.control_bt_synonym
and		grd.customer_name		= rtrim(@engg_customer_name)
and  	grd.project_name		= rtrim(@engg_project_name)
and  	grd.process_name		= rtrim(@prc_name_tmp)
and  	grd.component_name  	= rtrim(@component_name_tmp)
and  	grd.activity_name		= rtrim(@act_name_tmp)
and  	grd.ui_name				= rtrim(@ui_name_tmp)
and  	grd.page_bt_synonym		= rtrim(@engg_grid_page_bts)
and  	grd.section_bt_synonym	= rtrim(@engg_grid_sec_bts)
and  	grd.control_bt_synonym	= rtrim(@engg_grid_grid_code)
and		isnull(grd.TemplateID,'')<> ''			
and		ISNULL(ctype.base_ctrl_type,'') = 'Assorted'
--and		ISNULL(IsAssorted,'N') = 'Y'

if isnull(@templ_count,0) > 1
Begin
	Raiserror ('Template ID cannot be assigned to more than one column of Assorted Control.',16,4)
	Return
End

/**	Providing Sequential column no. for hidden columns created, while creating column with Edit Mask feature. 
	Code added for Defect id: TECH-20326 starts.
	*/
	Declare @colno				engg_seqno,
			@colname			engg_name

	if exists (select 'x'
	from	ep_ui_grid_dtl a (nolock),
			es_comp_ctrl_type_mst b (nolock) 
	where	a.customer_name = @engg_customer_name
	and		a.project_name  = @engg_project_name
	and		a.process_name  = @prc_name_tmp
	and		a.component_name= @component_name_tmp
	and		a.activity_name = @act_name_tmp
	and		a.ui_name		= @ui_name_tmp
	and		a.customer_name = b.customer_name
	and		a.project_name	= b.project_name
	and		a.process_name	= b.process_name
	and		a.component_name= b.component_name
	and		a.column_type	= b.ctrl_type_name
	and		isnull(EditMask,'N') = 'Y')
	begin
		select	@colno = max(column_no)
		from	ep_ui_grid_dtl (nolock)
		where	customer_name		= rtrim(@engg_customer_name)
		and		project_name		= rtrim(@engg_project_name)
		and		process_name		= rtrim(@prc_name_tmp)
		and		component_name		= rtrim(@component_name_tmp)
		and		activity_name		= rtrim(@act_name_tmp)
		and		ui_name				= rtrim(@ui_name_tmp)
		and		page_bt_synonym		= rtrim(@engg_grid_page_bts)
		and		section_bt_synonym	= rtrim(@engg_grid_sec_bts)
		and		control_bt_synonym	= rtrim(@engg_grid_grid_code)
		and		column_no			< 997

		Declare	col_seq cursor for 

		select	column_bt_synonym
		from	ep_ui_grid_dtl (nolock)
		where	customer_name		= rtrim(@engg_customer_name)
		and		project_name		= rtrim(@engg_project_name)
		and		process_name		= rtrim(@prc_name_tmp)
		and		component_name		= rtrim(@component_name_tmp)
		and		activity_name		= rtrim(@act_name_tmp)
		and		ui_name				= rtrim(@ui_name_tmp)
		and		page_bt_synonym		= rtrim(@engg_grid_page_bts)
		and		section_bt_synonym	= rtrim(@engg_grid_sec_bts)
		and		control_bt_synonym	= rtrim(@engg_grid_grid_code)
		and		column_no			>= 997
		order by column_bt_synonym
		
		Open col_seq
		Fetch next from col_seq into @colname
		while @@fetch_status = 0
		begin
			select	@colno = @colno + 1

			Update ep_ui_grid_dtl set column_no = @colno
			where	customer_name		= rtrim(@engg_customer_name)
			and		project_name		= rtrim(@engg_project_name)
			and		process_name		= rtrim(@prc_name_tmp)
			and		component_name		= rtrim(@component_name_tmp)
			and		activity_name		= rtrim(@act_name_tmp)
			and		ui_name				= rtrim(@ui_name_tmp)
			and		page_bt_synonym		= rtrim(@engg_grid_page_bts)
			and		section_bt_synonym	= rtrim(@engg_grid_sec_bts)
			and		control_bt_synonym	= rtrim(@engg_grid_grid_code)
			and		column_bt_synonym	= @colname		
			and		column_no		    >= 997

			fetch next from col_seq into @colname
		end	
		Close col_seq
		Deallocate col_seq
	end

/** Column sequence update when a column deletes from the Grid */
	Declare @cnt1				engg_seqno,
			@seqcount			engg_seqno,
			@cnt				engg_seqno,
			@sequp				engg_seqno,
			@col_bt				engg_name,
			@totcnt				engg_seqno

	select	@cnt1		= count(*),
			@seqcount	= isnull(max(column_no),0)
	from	ep_ui_grid_dtl (nolock)
	where	customer_name		= rtrim(@engg_customer_name)
	and		project_name		= rtrim(@engg_project_name)
	and		process_name		= rtrim(@prc_name_tmp)
	and		component_name		= rtrim(@component_name_tmp)
	and		activity_name		= rtrim(@act_name_tmp)
	and		ui_name				= rtrim(@ui_name_tmp)
	and		page_bt_synonym		= rtrim(@engg_grid_page_bts)
	and		section_bt_synonym	= rtrim(@engg_grid_sec_bts)
	and		control_bt_synonym	= rtrim(@engg_grid_grid_code)
	and		isnull(@IsGlance,'N') = 'N'

	Select @cnt = @cnt1

	If isnull(@cnt1, 0) <> isnull (@seqcount, 0)
	begin
		Select @sequp = 1

		Declare ColSeqUp cursor for
		select	column_bt_synonym
		from	ep_ui_grid_dtl (nolock)
		where	customer_name		= rtrim(@engg_customer_name)
		and		project_name		= rtrim(@engg_project_name)
		and		process_name		= rtrim(@prc_name_tmp)
		and		component_name		= rtrim(@component_name_tmp)
		and		activity_name		= rtrim(@act_name_tmp)
		and		ui_name				= rtrim(@ui_name_tmp)
		and		page_bt_synonym		= rtrim(@engg_grid_page_bts)
		and		section_bt_synonym	= rtrim(@engg_grid_sec_bts)
		and		control_bt_synonym	= rtrim(@engg_grid_grid_code)
		order by column_no								
			
		Open ColSeqUp
		Fetch next from ColSeqUp into @col_bt
		while @@FETCH_STATUS = 0
		begin
			Update  ep_ui_grid_dtl set
					column_no	= @sequp
			where	customer_name		= rtrim(@engg_customer_name)
			and		project_name		= rtrim(@engg_project_name)
			and		process_name		= rtrim(@prc_name_tmp)
			and		component_name		= rtrim(@component_name_tmp)
			and		activity_name		= rtrim(@act_name_tmp)
			and		ui_name				= rtrim(@ui_name_tmp)
			and		page_bt_synonym		= rtrim(@engg_grid_page_bts)
			and		section_bt_synonym	= rtrim(@engg_grid_sec_bts)
			and		control_bt_synonym	= rtrim(@engg_grid_grid_code)
			and     column_bt_synonym	= @col_bt

			select  @sequp = @sequp + 1

			fetch next from ColSeqUp into @col_bt
	end		
	close ColSeqUp
	deallocate ColSeqUp		
end	
-- Code added for Defect id: TECH-20326 ends.

if exists (
select 'x'
from	ep_ui_grid_dtl (nolock)
where	customer_name	= rtrim(@engg_customer_name)
and		project_name	= rtrim(@engg_project_name)
and		req_no			= rtrim(@engg_base_req_no)
and		process_name	= rtrim(@prc_name_tmp)
and		component_name  = rtrim(@component_name_tmp)
and		activity_name	= rtrim(@act_name_tmp)
and		ui_name			= rtrim(@ui_name_tmp)
and		page_bt_synonym = rtrim(@engg_grid_page_bts)
and		section_bt_synonym = rtrim(@engg_grid_sec_bts)
and		control_bt_synonym = rtrim(@engg_grid_grid_code)
)
begin
-- code modified by shafina on 16-feb-2005 for PREVIEWPFSUPPORT_000009 ( When i generate the UI the layout is not as defined. it doesn't show the grid in the bottom)

	select @count = 1
	declare check_cur insensitive cursor for
	select  a.column_no
	from	ep_ui_grid_dtl a(nolock)
	where	a.customer_name		= rtrim(@engg_customer_name)
	and		a.project_name		= rtrim(@engg_project_name)
	and		a.req_no			= rtrim(@engg_base_req_no)
	and		a.process_name		= rtrim(@prc_name_tmp)
	and		a.component_name	= rtrim(@component_name_tmp)
	and		a.activity_name		= rtrim(@act_name_tmp)
	and		a.ui_name			= rtrim(@ui_name_tmp)	
	and		a.page_bt_synonym	= rtrim(@engg_grid_page_bts)
	and		a.section_bt_synonym= rtrim(@engg_grid_sec_bts)
	and		a.control_bt_synonym= rtrim(@engg_grid_grid_code)
	and		isnull(@IsGlance, 'N') = 'N'
	order by a.column_no
	open check_cur
	while (1=1)
	begin
		fetch next from check_cur into @col_no
		if @@fetch_status <> 0
			break
		if @col_no <> @count
		begin
			close check_cur
			deallocate check_cur
			exec engg_error_sp 'ep_layout_sp_savgrd_hck',2,'There are gaps in column numbers',
				@ctxt_language,		@ctxt_ouinstance,		@ctxt_service,		@ctxt_user,
				'',					'',						'',					'',
				@m_errorid output
			if @m_errorid > 0
			return
		end
		select @count = @count + 1
	end
	close check_cur
	deallocate check_cur
-- code modified by shafina on 16-feb-2005 for PREVIEWPFSUPPORT_000009 ( When i generate the UI the layout is not as defined. it doesn't show the grid in the bottom)

/*getting the maximum value for the display sequence*/
	select	@max_val   = max(column_no)
	from	ep_ui_grid_dtl (nolock)
	where	customer_name	= rtrim(@engg_customer_name)
	and		project_name	= rtrim(@engg_project_name)
	and		req_no			= rtrim(@engg_base_req_no)
	and		process_name	= rtrim(@prc_name_tmp)
	and		component_name  = rtrim(@component_name_tmp)
	and		activity_name	= rtrim(@act_name_tmp)
	and		ui_name			= rtrim(@ui_name_tmp)
	and		page_bt_synonym = rtrim(@engg_grid_page_bts)
	and		section_bt_synonym = rtrim(@engg_grid_sec_bts)
	and		control_bt_synonym = rtrim(@engg_grid_grid_code)


--getting the row count for the display sequence
	select	@row_count   = count(column_no)
	from	ep_ui_grid_dtl (nolock)
	where	customer_name	= rtrim(@engg_customer_name)
	and		project_name	= rtrim(@engg_project_name)
	and		req_no			= rtrim(@engg_base_req_no)
	and		process_name	= rtrim(@prc_name_tmp)
	and		component_name  = rtrim(@component_name_tmp)
	and		activity_name	= rtrim(@act_name_tmp)
	and		ui_name			= rtrim(@ui_name_tmp)
	and		page_bt_synonym = rtrim(@engg_grid_page_bts)
	and		section_bt_synonym = rtrim(@engg_grid_sec_bts)
	and		control_bt_synonym = rtrim(@engg_grid_grid_code)
	and		isnull(@IsGlance, 'N') = 'N'

	If isnull(@row_count,0) > 0
	BEGIN
	/*checking whether there is any gap in the display sequence*/
		if @max_val <> @row_count and @engg_req_no in ('BASE' , 'ADHOC')
		begin
		
			exec  engg_error_sp 'ep_layout_sp_savgrd_hck',1,'There are gaps in Column Numbers.',
				@ctxt_language,		@ctxt_ouinstance,		@ctxt_service,		@ctxt_user,
				'',					'',						'',					'',		
				@m_errorid output

			if  @m_errorid > 0
			return
		end
	END
end
-- Code added by chanheetha N A for the call id :PNR2.0_10007  on 23-Aug-2006

if  exists  ( select 'x'
from	de_hidden_view(nolock)
where	customer_name   = @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @prc_name_tmp
and		component_name  = @component_name_tmp
and		activity_name   = @act_name_tmp
and		ui_name			= @ui_name_tmp
and     control_bt_synonym= @engg_grid_grid_code
and     HIDDEN_VIEW_SOURCE   is null)
begin
	if not exists (select 'x'
	from	ep_ui_grid_dtl a (nolock),
			es_comp_ctrl_type_mst b (nolock)
	where   a.customer_name      = @engg_customer_name
	and     a.project_name       = @engg_project_name
	and     a.process_name       = @prc_name_tmp
	and     a.component_name	 = @component_name_tmp
	and     a.activity_name      = @act_name_tmp
	and     a.ui_name			 = @ui_name_tmp
	and     a.page_bt_synonym	 = @engg_grid_page_bts
	and     a.section_bt_synonym = @engg_grid_sec_bts
	and		a.control_bt_synonym = @engg_grid_grid_code
	and     a.customer_name      = b.customer_name
	and     a.project_name		 = b.project_name
	and     a.process_name		 = b.process_name
	and     a.component_name     = b.component_name
	and     a.column_type        = b.ctrl_type_name
	and     b.base_ctrl_type     = 'edit')
	--AND     b.editable_flag    = 'y' )/* PNR2.0_12484 */
	begin
/* PNR2.0_12484 */
		declare @column_Name		engg_name
		select  @column_Name  = b.control_bt_synonym
		from	de_hidden_view a (nolock),
				de_hidden_view b (nolock)
		where	a.customer_name		= @engg_customer_name
		and		a.project_name		= @engg_project_name
		and		a.process_name		= @prc_name_tmp
		and		a.component_name	= @component_name_tmp
		and		a.activity_name		= @act_name_tmp
		and		a.ui_name			= @ui_name_tmp
		and     a.control_bt_synonym= @engg_grid_grid_code
		and     a.HIDDEN_VIEW_SOURCE  is null
		and     a.customer_name		= b.customer_name
		and     a.project_name		= b.project_name
		and     a.process_name		= b.process_name
		and     a.component_name	= b.component_name
		and     a.activity_name		= b.activity_name
		and     a.ui_name			= b.ui_name
		and     a.hidden_view_bt_synonym= b.HIDDEN_VIEW_SOURCE
/* PNR2.0_12484 */

		select @msg = 'Hidden view has been defined for this grid so u can not change the column type for this editable column : '+ 
					  @column_Name--@engg_grid_grid_code/* PNR2.0_12484 */
		exec engg_error_sp 'ep_layout_sp_savgrdgdml',14,@msg,
			 @ctxt_language,		@ctxt_ouinstance,		@ctxt_service,		@ctxt_user,
			'',						@fprowno,				'',					'',
			@m_errorid output
		if @m_errorid <> 0 /* PNR2.0_12484 */
			return
	end
end

-- Code added for Defect ID : TECH-18349 starts
Declare	@countmfs		engg_seqno

if exists (select  'x'
from	es_comp_ctrl_type_mst mst (nolock),
		es_comp_ctrl_type_mst_extn extn (nolock),
		ep_ui_grid_dtl grid (nolock)
where   mst.customer_name	= @engg_customer_name
and     mst.project_name    = @engg_project_name
and     mst.process_name    = @prc_name_tmp
and		mst.Component_name  = @component_name_tmp
and     activity_name       = @act_name_tmp
and     ui_name				= @ui_name_tmp
and     control_bt_synonym  = @engg_grid_grid_code
and     page_bt_synonym		= @engg_grid_page_bts
and     section_bt_synonym  = @engg_grid_sec_bts
and     mst.base_ctrl_type	= 'Edit'
and		multifileselect     = 'Y'
and		mst.customer_name	= extn.customer_name  
and		mst.project_name	= extn.project_name  
and		mst.process_name	= extn.process_name
and		mst.component_name	= extn.component_name
and		mst.ctrl_type_name	= extn.ctrl_type_name
and		mst.base_ctrl_type	= extn.base_ctrl_type
and		mst.customer_name	= grid.customer_name  
and		mst.project_name	= grid.project_name  
and		mst.process_name	= grid.process_name
and		mst.component_name	= grid.component_name
and		mst.ctrl_type_name	= grid.column_type)
begin
	Select  @countmfs = count(distinct column_bt_synonym)
	from	ep_ui_grid_dtl grid (nolock)
	JOIN	es_comp_ctrl_type_mst mst (nolock)  ----TECH-73216
	ON		mst.customer_name	= grid.customer_name  
	AND		mst.project_name	= grid.project_name  
	AND		mst.process_name	= grid.process_name
	AND		mst.component_name	= grid.component_name
	AND		mst.ctrl_type_name	= grid.column_type
	WHERE   grid.customer_name		 = @engg_customer_name
	AND     grid.project_name		 = @engg_project_name
	AND     grid.process_name		 = @prc_name_tmp
	AND		grid.Component_name		 = @component_name_tmp
	AND     grid.activity_name       = @act_name_tmp
	AND     grid.ui_name			 = @ui_name_tmp
	AND     grid.control_bt_synonym  = @engg_grid_grid_code
	AND     grid.page_bt_synonym	 = @engg_grid_page_bts
	AND     grid.section_bt_synonym  = @engg_grid_sec_bts
	AND		mst.ctrl_type_name  NOT IN ('Filesize','Filetype') ----TECH-73216

	if isnull(@countmfs,0) > 1
	begin
		Raiserror('MultiFileSelect enabled grid allows Only one column. Please remove other column(s).',16,1)
		return
	end
end
-- Code added for Defect ID : TECH-18349 ends

-- Code added for Defect ID : TECH-19347 starts
	Declare @col_bt_syn		engg_name

	Select	@countmfs = 0

	Select  @col_bt_syn	= column_bt_synonym
	from	ep_ui_grid_dtl (nolock)
	where   customer_name		= @engg_customer_name
	and     project_name		= @engg_project_name
	and     process_name		= @prc_name_tmp
	and		Component_name		= @component_name_tmp
	and     activity_name       = @act_name_tmp
	and     ui_name				= @ui_name_tmp
	and     control_bt_synonym  = @engg_grid_grid_code
	and     page_bt_synonym		= @engg_grid_page_bts
	and     section_bt_synonym  = @engg_grid_sec_bts
	and     isnull(rowexpander,'n') = 'y'

	Select  @countmfs	= count(distinct column_bt_synonym)
	from	ep_ui_grid_dtl (nolock)
	where   customer_name		= @engg_customer_name
	and     project_name		= @engg_project_name
	and     process_name		= @prc_name_tmp
	and		Component_name		= @component_name_tmp
	and     activity_name       = @act_name_tmp
	and     ui_name				= @ui_name_tmp
	and     control_bt_synonym  = @engg_grid_grid_code
	and     page_bt_synonym		= @engg_grid_page_bts
	and     section_bt_synonym  = @engg_grid_sec_bts
	and     isnull(rowexpander,'n') = 'y'

	if isnull(@countmfs,0) > 1
	begin
		Raiserror('Only one Display only Column has to be selected for Row Expander. Please remove other column(s).',16,1)
		return
	end

	--Declare @col_type		engg_name

	--select  @col_type = column_type
	--from	ep_ui_grid_dtl a (nolock)
	--where   a.customer_name		= @engg_customer_name
	--and     a.project_name		= @engg_project_name
	--and     a.process_name		= @prc_name_tmp
	--and		a.Component_name	= @component_name_tmp
	--and     activity_name       = @act_name_tmp
	--and     ui_name				= @ui_name_tmp
	--and     control_bt_synonym  = @engg_grid_grid_code
	--and     page_bt_synonym		= @engg_grid_page_bts
	--and     section_bt_synonym  = @engg_grid_sec_bts
	--and     column_bt_synonym   = @col_bt_syn

	if exists (select  'x'
	from	ep_ui_grid_dtl a (nolock),
			es_comp_ctrl_type_mst c (nolock)
	where   a.customer_name		= @engg_customer_name
	and     a.project_name		= @engg_project_name
	and     a.process_name		= @prc_name_tmp
	and		a.Component_name	= @component_name_tmp
	and     activity_name       = @act_name_tmp
	and     ui_name				= @ui_name_tmp
	and     control_bt_synonym  = @engg_grid_grid_code
	and     page_bt_synonym		= @engg_grid_page_bts
	and     section_bt_synonym  = @engg_grid_sec_bts
	and     column_bt_synonym   = @col_bt_syn
	and     isnull(rowexpander,'n') = 'y'
	and     TemplateCategory    is  null 
	and		base_ctrl_type		<> 'Edit'
	and		isnull(visisble_flag,'n')<> 'N'

	and     a.customer_name     = c.customer_name
	and     a.project_name		= c.project_name
	and     a.process_name		= c.process_name
	and     a.component_name	= c.component_name
	and		a.column_type		= c.ctrl_type_name)
	begin
		raiserror('Row expander enabled column must be Display only and Template enabled.',16,1)
	end
-- Code added for Defect ID : TECH-19347 ends

if  exists  ( select 'x'
from	de_hidden_view(nolock)
where	customer_name   = @engg_customer_name
and		project_name    = @engg_project_name
and		process_name    = @prc_name_tmp
and		component_name  = @component_name_tmp
and		activity_name   = @act_name_tmp
and		ui_name			= @ui_name_tmp
and     control_bt_synonym= @engg_grid_grid_code
and     HIDDEN_VIEW_SOURCE   is null)
begin
	select  @col_type			= column_type,
			@engg_grid_btsynname= column_bt_synonym
	from	ep_ui_grid_dtl     a (nolock),
			de_hidden_view     b (nolock)
	where	a.customer_name		= @engg_customer_name
	and		a.project_name		= @engg_project_name
	and		a.process_name		= @prc_name_tmp
	and		a.component_name	= @component_name_tmp
	and		a.activity_name		= @act_name_tmp
	and		a.ui_name			= @ui_name_tmp
	and     a.control_bt_synonym= @engg_grid_grid_code/* PNR2.0_12484 */
	and     a.customer_name		= b.customer_name
	and     a.project_name		= b.project_name
	and     a.process_name		= b.process_name
	and     a.component_name	= b.component_name
	and     a.activity_name		= b.activity_name
	and     a.ui_name			= b.ui_name
	and     a.column_bt_synonym = b.control_bt_synonym
	and     isnull(HIDDEN_VIEW_SOURCE, '') <> ''

	if not exists(select 'x'
	from  es_comp_ctrl_type_mst(nolock)
	where customer_name      = @engg_customer_name
	and   project_name       = @engg_project_name
	and   process_name       = @prc_name_tmp
	and   component_name	 = @component_name_tmp
	and   ctrl_type_name     = isnull(@col_type,'')
	and   base_ctrl_type     = 'edit')
	--    and   editable_flag   = 'Y')/* PNR2.0_12484 */
	begin
		select  top 1 @column_bt_synonym = column_bt_synonym
		from	ep_ui_grid_dtl a (nolock),
				es_comp_ctrl_type_mst b (nolock)
		where   a.customer_name      = @engg_customer_name
		and     a.project_name       = @engg_project_name
		and     a.process_name       = @prc_name_tmp
		and     a.component_name	 = @component_name_tmp
		and     a.activity_name      = @act_name_tmp
		and     a.ui_name			 = @ui_name_tmp
		and     a.page_bt_synonym    = @engg_grid_page_bts
		and     a.section_bt_synonym = @engg_grid_sec_bts
		and		a.control_bt_synonym = @engg_grid_grid_code
		and     a.column_bt_synonym  <> isnull(@engg_grid_btsynname,'')
		and     a.customer_name      = b.customer_name
		and     a.project_name		 = b.project_name
		and     a.process_name		 = b.process_name
		and     a.component_name     = b.component_name
		and     a.column_type        = b.ctrl_type_name
		and     b.base_ctrl_type     = 'edit'
		--    AND     b.editable_flag   = 'y'
		ORDER   BY a.column_no

		if isnull(@column_bt_synonym,'')<> ''
		begin
			update  a
			set		a.control_bt_sysnonym = @column_bt_synonym
			from	de_hidden_view_usage a (nolock)
			where   a.customer_name      = @engg_customer_name
			and     a.project_name       = @engg_project_name
			and     a.process_name       = @prc_name_tmp
			and     a.component_name	 = @component_name_tmp
			and     a.activity_name      = @act_name_tmp
			and     a.ui_name			 = @ui_name_tmp
			and     a.page_name			 = @engg_grid_page_bts
			and		a.hidden_view_bt_sysnonym in  ( select  a.hidden_view_bt_synonym
			from	de_hidden_view a(nolock),
					de_hidden_view b(nolock)
			where   a.customer_name      = @engg_customer_name
			and     a.project_name       = @engg_project_name
			and     a.process_name       = @prc_name_tmp
			and     a.component_name	 = @component_name_tmp
			and     a.activity_name      = @act_name_tmp
			and     a.ui_name			 = @ui_name_tmp
			and     a.page_name			 = @engg_grid_page_bts
			and     a.section_name       = @engg_grid_sec_bts
			and     a.customer_name      = b.customer_name
			and     a.project_name       = b.project_name
			and     a.process_name       = b.process_name
			and     a.component_name	 = b.component_name
			and     a.activity_name      = b.activity_name
			and     a.ui_name			 = b.ui_name
			and     a.page_name			 = b.page_name
			and     a.section_name		 = b.section_name
			and     b.control_bt_synonym = @engg_grid_grid_code
			and     a.HIDDEN_VIEW_SOURCE = b.hidden_view_bt_synonym)

			Update  a
			set     a.control_bt_synonym = @column_bt_synonym
			from	de_hidden_view a(nolock),
					de_hidden_view b(nolock)
			where   a.customer_name      = @engg_customer_name
			and     a.project_name       = @engg_project_name
			and     a.process_name       = @prc_name_tmp
			and     a.component_name	 = @component_name_tmp
			and     a.activity_name      = @act_name_tmp
			and     a.ui_name			 = @ui_name_tmp
			and     a.page_name			 = @engg_grid_page_bts
			and     a.section_name       = @engg_grid_sec_bts
			and     a.customer_name      = b.customer_name
			and     a.project_name       = b.project_name
			and     a.process_name       = b.process_name
			and     a.component_name	 = b.component_name
			and     a.activity_name      = b.activity_name
			and     a.ui_name			 = b.ui_name
			and     a.page_name			 = b.page_name
			and     a.section_name		 = b.section_name
			and     b.control_bt_synonym = @engg_grid_grid_code
			and     a.HIDDEN_VIEW_SOURCE = b.hidden_view_bt_synonym
		end --else
	end -- @tmp_control_type <> @engg_grid_elem_type
end -- isnull(HIDDEN_VIEW_SOURCE,'') <> ''
-- Code added by chanheetha N A for the call id :PNR2.0_10007  on 23-Aug-2006

-- code modified by shafina on 17-jan-2004 to add init task and generate task seq no
update	ep_action_mst set  
		task_seq   =  0
where	customer_name		= @engg_customer_name
and		project_name		= @engg_project_name
and		req_no				= @engg_base_req_no
and		process_name		= @prc_name_tmp
and		component_name		= @component_name_tmp
and		activity_name		= @act_name_tmp
and		ui_name				= @ui_name_tmp

select	@ActionType_fet		= task_type_name
from	es_comp_task_type_mst_vw(nolock)
where	customer_name		= @engg_customer_name
and		project_name		= @engg_project_name
and		process_name		= @prc_name_tmp
and		component_name		= @component_name_tmp
--  and  req_no				= @engg_base_req_no
and  default_for			= 'Fetch'

select	@ActionType_init= task_type_name
from	es_comp_task_type_mst_vw(nolock)
where	customer_name		= @engg_customer_name
and		project_name		= @engg_project_name
and		process_name		= @prc_name_tmp
and		component_name		= @component_name_tmp
--  and  req_no				= @engg_base_req_no
and		default_for			= 'Init'

-- modified by shafina on 29-jan-2004 to alter the generation of tasks

select	@comp_pfx_tmp = current_value
from	es_comp_param_mst (nolock)
where	customer_name	= rtrim(@engg_customer_name)
and		project_name	= rtrim(@engg_project_name)
and		process_name	= rtrim(@prc_name_tmp)
and		component_name	= rtrim(@component_name_tmp)
and		param_category	= 'compprefix'

select	@ui_pfx_tmp  = page_prefix
from	ep_ui_page_dtl (nolock)
where	customer_name	= rtrim(@engg_customer_name)
and		project_name	= rtrim(@engg_project_name)
and		process_name	= rtrim(@prc_name_tmp)
and		component_name	= rtrim(@component_name_tmp)
and		req_no			= rtrim(@engg_base_req_no)
and		activity_name   = rtrim(@act_name_tmp)
and		ui_name			= rtrim(@ui_name_tmp)
and		page_bt_synonym = '[mainscreen]'

-- check any combo controls are there in header for the selected ui
-- code modified by shafina on 20-May-2004 for PREVIEWENG203SYS_000081 (While mapping an ECR to and Impact RCN, init task is getting vanished...)
if (
select  count('x')
from	ep_ui_control_dtl c(nolock) ,
		es_comp_ctrl_type_mst_vw m(nolock)
where	c.customer_name		= rtrim(@engg_customer_name)
and		c.project_name		= rtrim(@engg_project_name)
and		c.req_no			= rtrim(@engg_base_req_no)
and		c.process_name		= rtrim(@prc_name_tmp)
and		c.component_name	= rtrim(@component_name_tmp)
and		c.activity_name		= rtrim(@act_name_tmp)
and		c.ui_name			= rtrim(@ui_name_tmp)
--   and  c.page_bt_synonym = rtrim(@engg_grid_page_bts)
and		c.customer_name		= m.customer_name
and		c.project_name		= m.project_name
and		c.req_no			= m.req_no
and		c.process_name		= m.process_name
and		c.component_name	= m.component_name
and		c.control_type		= m.ctrl_type_name
and		m.base_ctrl_type	= 'Combo'
-- code modified by shafina on 05-Nov-2004 for PREVIEWENG203ACC_000106(Init task must not be generated when only enumerated combos exist in the UI.)
and		c.control_bt_synonym not in (select e.control_bt_synonym
from	ep_enum_value_dtl e (nolock)
where	e.customer_name		= rtrim(@engg_customer_name)
and		e.project_name		= rtrim(@engg_project_name)
and		e.req_no			= rtrim(@engg_base_req_no)
and		e.process_name		= rtrim(@prc_name_tmp)
and		e.component_name	= rtrim(@component_name_tmp)
and		e.activity_name		= rtrim(@act_name_tmp)
and		e.ui_name			= rtrim(@ui_name_tmp)
and		e.page_bt_synonym	= c.page_bt_synonym)) > 0
or		(select  count('x')
from	ep_ui_grid_dtl c(nolock) ,
		es_comp_ctrl_type_mst_vw m(nolock)
where	c.customer_name		= rtrim(@engg_customer_name)
and		c.project_name		= rtrim(@engg_project_name)
and		c.req_no			= rtrim(@engg_base_req_no)
and		c.process_name		= rtrim(@prc_name_tmp)
and		c.component_name	= rtrim(@component_name_tmp)
and		c.activity_name		= rtrim(@act_name_tmp)
and		c.ui_name			= rtrim(@ui_name_tmp)
--   and  c.page_bt_synonym = rtrim(@engg_grid_page_bts)
and		c.customer_name		= m.customer_name
and		c.project_name		= m.project_name
and		c.req_no			= m.req_no
and		c.process_name		= m.process_name
and		c.component_name	= m.component_name
and		c.column_type		= m.ctrl_type_name
and		m.base_ctrl_type	= 'Combo'
and		c.column_bt_synonym not in (select e.control_bt_synonym
from	ep_enum_value_dtl e (nolock)
where	e.customer_name		= rtrim(@engg_customer_name)
and		e.project_name		= rtrim(@engg_project_name)
and		e.req_no			= rtrim(@engg_base_req_no)
and		e.process_name		= rtrim(@prc_name_tmp)
and		e.component_name	= rtrim(@component_name_tmp)
and		e.activity_name		= rtrim(@act_name_tmp)
and		e.ui_name			= rtrim(@ui_name_tmp)
and		e.page_bt_synonym	= c.page_bt_synonym)) > 0
begin
	select  --@tmp_ActionName  = @tmp_ui + '_Init',
			@tmp_ActionName   = isnull(@comp_pfx_tmp,'') + isnull(@ui_pfx_tmp,'') + 'Init',
			@tmp_Action_Desc  = 'Initialize'
			-- @tmp_ActionType  = 'Init'

-- For Init Task
	if not exists (select 'x' 
	from	ep_action_mst(nolock)
	where	customer_name	= @engg_customer_name
	and		project_name	= @engg_project_name
	and		process_name    = @prc_name_tmp
	and		component_name  = @component_name_tmp
	and		activity_name   = @act_name_tmp
	--       and task_name  = @tmp_ActionName
	and		ui_name			= @ui_name_tmp
	and		req_no			= @engg_base_req_no
-- code modified by shafina on 27-April-2004 for PREVIEWENG203ACC_000048
--       and task_pattern  = @ActionType_init)
-- code modified by shafina on 25-Sep-2004 for PREVIEWENG203SYS_000155(In section layout tab , when records r saved , the followin error is thrown : "VALUES FOR COLUMNS CUSTOMER NAME,PROJECT ...........")
	and		task_type	    = 'init')
	begin--8
		exec ep_action_mst_sp_ins
			@ctxt_language,		@ctxt_ouinstance,		@ctxt_service,		@ctxt_user,			@engg_customer_name,
			@engg_project_name,	@engg_base_req_no,		@prc_name_tmp,		@component_name_tmp,@act_name_tmp,
			@ui_name_tmp,
		-- code modified by shafina on 17-June-2004 for PREVIEWENG203ACC_000065
			'[mainscreen]',		@tmp_ActionName ,		@tmp_Action_Desc ,	0,					@ActionType_init ,
			'[None]',			'Init',					1 ,
			@m_errorid output							

		if @m_errorid <> 0
			return

--Code added by Sangeetha L on 11-Feb-2006 for the Bug id:PNR2.0_6199
		insert ep_action_mst_lng_extn( 
			customer_name,			project_name,			req_no,				process_name,			component_name,			activity_name,   
			ui_name,				page_bt_synonym,		task_name,			task_descr,				task_seq,				task_pattern,
			languageid,				timestamp,				createdby,			createddate,			modifiedby,				modifieddate,   
			primary_control_bts,    task_sysid,				ui_sysid,			task_type)
		select  
			a.customer_name,		a.project_name,			a.req_no,			a.process_name,			a.component_name,		a.activity_name,  
			a.ui_name,				a.page_bt_synonym,		a.task_name,		a.task_descr,			a.task_seq,				a.task_pattern,
			quick_code,				a.timestamp,			@ctxt_user,			a.createddate,			@ctxt_user,				a.modifieddate,  
			a.primary_control_bts,  newid(),				a.ui_sysid,			a.task_type
		from	ep_action_mst  a (nolock),
				ep_language_met b (nolock)
		where	quick_code_type		='language_code'
		and		a.customer_name		= @engg_customer_name
		and		a.project_name		= @engg_project_name
		and		req_no				= @engg_base_req_no
		and		process_name		= @prc_name_tmp
		and		component_name		= @component_name_tmp
		and		activity_name		= @act_name_tmp
		and		ui_name				= @ui_name_tmp
		and		page_bt_synonym		='[mainscreen]'
		and		task_name			= @tmp_ActionName
		and		not exists (select 's'
		from	ep_action_mst_lng_extn c (nolock)
		where	c.customer_name		= a.customer_name
		and		c.project_name		= a.project_name
		and		c.req_no			= a.req_no
		and		c.process_name		= a.process_name
		and		c.component_name	= a.component_name
		and		c.activity_name		= a.activity_name
		and		c.ui_name			= a.ui_name
		and		c.page_bt_synonym	= a.page_bt_synonym
		and		c.task_name			= a.task_name
		and		c.languageid		= quick_code)
--Code added by Sangeetha L on 11-Feb-2006 for the Bug id:PNR2.0_6199
	end

-- To generate the seqnos for the tasks
	update	ep_action_mst set
			task_seq   =  1
	where	customer_name   = @engg_customer_name
	and		project_name	= @engg_project_name
	and		process_name    = @prc_name_tmp
	and		component_name  = @component_name_tmp
	and		activity_name   = @act_name_tmp
	-- and  task_name		= @tmp_ActionName
	and		ui_name			= @ui_name_tmp
	and		req_no			= @engg_base_req_no
	--   and  task_pattern  = @ActionType_init
	and		task_type		= 'init'

	update	ep_action_mst set
			  task_seq   =  2
	where	customer_name   = @engg_customer_name
	and		project_name	= @engg_project_name
	and		process_name    = @prc_name_tmp
	and		component_name  = @component_name_tmp
	and		activity_name   = @act_name_tmp
	-- and  task_name		= @tmp_ActionName
	and		ui_name			= @ui_name_tmp
	and		req_no			= @engg_base_req_no
	--   and  task_pattern  = @ActionType_fet
	and		task_type		= 'fetch'
end
else
begin
-- To delete the init task
	select  --@tmp_ActionName  = @tmp_ui + '_Init'
			@tmp_ActionName  = isnull(@comp_pfx_tmp,'') + isnull(@ui_pfx_tmp,'') + 'Init'

	if exists (select 'x' 
	from	ep_action_mst(nolock)
	where	customer_name	= @engg_customer_name
	and		project_name	= @engg_project_name
	and		process_name    = @prc_name_tmp
	and		component_name  = @component_name_tmp
	and		activity_name   = @act_name_tmp
--      and task_name		= @tmp_ActionName
	and		ui_name			= @ui_name_tmp
	and		req_no			= @engg_base_req_no
-- code modified by shafina on 27-April-2004 for PREVIEWENG203ACC_000048
--      and task_pattern  = @ActionType_init)
	and		task_type		= 'init')
begin
	select	@flow_action_name = task_name
	from	ep_action_mst (nolock)
	where	customer_name   = @engg_customer_name
	and		project_name	= @engg_project_name
	and		process_name    = @prc_name_tmp
	and		component_name  = @component_name_tmp
	and		activity_name   = @act_name_tmp
	and		ui_name			= @ui_name_tmp
	and		req_no			= @engg_base_req_no
	--    and  task_pattern = @ActionType_init
	and		task_type		= 'init'

--code modified by shafina on 27-jan-2004 to delete flow_br_mst table
	if exists   (select 'x' 
	from	ep_flowbr_mst (nolock)
	where	customer_name	= @engg_customer_name
	and		project_name	= @engg_project_name
	and		req_no			= @engg_base_req_no
	and		process_name	= @prc_name_tmp
	and		component_name  = @component_name_tmp
	and		activity_name   = @act_name_tmp
	and		ui_name			= @ui_name_tmp
	and		page_bt_synonym = '[mainscreen]'
	and		task_name       = @flow_action_name)
	begin
		delete	ep_flowbr_mst
		where	customer_name	= @engg_customer_name
		and		project_name    = @engg_project_name
		and		req_no          = @engg_base_req_no
		and		process_name    = @prc_name_tmp
		and		component_name  = @component_name_tmp
		and		activity_name   = @act_name_tmp
		and		ui_name			= @ui_name_tmp
		and		page_bt_synonym = '[mainscreen]'
		and		task_name       = @flow_action_name
	end

	delete	from	ep_action_mst
	where	customer_name   = @engg_customer_name
	and		project_name	= @engg_project_name
	and		process_name    = @prc_name_tmp
	and		component_name  = @component_name_tmp
	and		activity_name   = @act_name_tmp
	-- and  task_name       = @tmp_ActionName
	and		ui_name			= @ui_name_tmp
	and		req_no			= @engg_base_req_no
	-- code modified by shafina on 27-April-2004 for PREVIEWENG203ACC_000048
	-- and  task_pattern  = @ActionType_init
	and		task_type		='init'

-- code added by Anuradha M on 16-12-2005 for the Bug Id :: PNR2.0_5031
	delete	from ep_action_mst_lng_extn
	where	customer_name		= @engg_customer_name
	and		project_name		= @engg_project_name
	and		process_name		= @prc_name_tmp
	and		component_name		= @component_name_tmp
	and		activity_name		= @act_name_tmp
	and		ui_name				= @ui_name_tmp
	and		req_no				= @engg_base_req_no
	and		task_type			= 'init'
	-- code added by Anuradha M on 16-12-2005 for the Bug Id :: PNR2.0_5031
end

-- To generate the seqnos for the tasks
update	ep_action_mst set
		task_seq   =  1
where	customer_name   = @engg_customer_name
and		project_name	= @engg_project_name
and		process_name    = @prc_name_tmp
and		component_name  = @component_name_tmp
and		activity_name   = @act_name_tmp
-- and  task_name		= @tmp_ActionName
and		ui_name			= @ui_name_tmp
and		req_no			= @engg_base_req_no
--   and  task_pattern  = @ActionType_fet
and		task_type		= 'fetch'
end

update	ep_action_mst set
		task_seq   =  0
where	customer_name   = @engg_customer_name
and		project_name	= @engg_project_name
and		req_no			= @engg_base_req_no
and		process_name    = @prc_name_tmp
and		component_name  = @component_name_tmp
and		activity_name   = @act_name_tmp
and		ui_name			= @ui_name_tmp
and		task_type		<> 'init'
and		task_type		<> 'fetch'

declare	gen_cur cursor for
	select task_name
	from	ep_action_mst (nolock)
	where	customer_name   = @engg_customer_name
	and		project_name	= @engg_project_name
	and		process_name    = @prc_name_tmp
	and		component_name  = @component_name_tmp
	and		activity_name   = @act_name_tmp
	and		ui_name			= @ui_name_tmp
	and		req_no			= @engg_base_req_no
--  and  task_pattern  <> @ActionType_fet
--  and  task_pattern  <> @ActionType_init
	and		task_type		<> 'init'
	and		task_type		<> 'fetch'

	open gen_cur

	while (1=1)
	begin
		fetch next from gen_cur	into @task_name_tmp

		if @@fetch_status <> 0
			break

		select	@max_seq_no   = max(task_seq) + 1
		from	ep_action_mst (nolock)
		where	customer_name   = @engg_customer_name
		and		project_name	= @engg_project_name
		and		process_name    = @prc_name_tmp
		and		component_name  = @component_name_tmp
		and		activity_name   = @act_name_tmp
		-- and  task_name		=  @tmp_ActionName
		and		ui_name			= @ui_name_tmp
		and		req_no			= @engg_base_req_no

		update	ep_action_mst set
				task_seq	=  @max_seq_no
		where	customer_name   = @engg_customer_name
		and		project_name	= @engg_project_name
		and		req_no			= @engg_base_req_no
		and		process_name    = @prc_name_tmp
		and		component_name  = @component_name_tmp
		and		activity_name   = @act_name_tmp
		and		ui_name			= @ui_name_tmp
		and		task_name		= @task_name_tmp
		--   and  task_pattern  <> @ActionType_fet
		--   and  task_pattern  <> @ActionType_init
		and		task_type		<> 'init'
		and		task_type		<> 'fetch'
	end
	close gen_cur
	deallocate gen_cur


	update	a set
			a.task_seq = b.task_seq
	from	ep_action_mst_lng_extn  a (nolock),
			ep_action_mst   b (nolock)
	where	b.customer_name		= @engg_customer_name
	and		b.project_name		= @engg_project_name
	and		b.req_no			= @engg_base_req_no
	and		b.process_name		= @prc_name_tmp
	and		b.component_name	= @component_name_tmp
	and		b.activity_name		= @act_name_tmp
	and		b.ui_name			= @ui_name_tmp
	and		a.customer_name		= b.customer_name
	and		a.project_name		= b.project_name
	and		a.process_name		= b.process_name
	and		a.component_name	= b.component_name
	and		a.activity_name		= b.activity_name
	and		a.ui_name			= b.ui_name
	and		a.page_bt_synonym	= b.page_bt_synonym
	and		a.task_name			= b.task_name
----For Layout Manager starts

/*If isnull(@engg_del_columns,'') <> ''
	Begin
		select @m_errorid = 20001
	End

-- Code added for Bug Id :PNR2.0_33469 Starts
If isnull(@engg_del_columns,'') <> ''
			Begin
				select @m_errorid = 10001
			End*/
-- Code added for Bug Id :PNR2.0_33469 Ends

-- NGPLF Changes Starts
		--Declare @Ctxt_role		NGPLF_NAME	

		--IF EXISTS ( SELECT	'X'
		--			FROM	ep_ui_mst (NOLOCK)
		--			WHERE	customer_name			= @engg_customer_name
		--			AND		project_name			= @engg_project_name
		--			AND		process_name			= @prc_name_tmp
		--			AND		component_name			= @component_name_tmp
		--			AND		activity_name			= @act_name_tmp
		--			AND		ui_name					= @ui_name_tmp
		--			AND		ISNULL(ISGlance,'N')	= 'Y' )
		--BEGIN
			
		----	--EXEC ngplf_transferdata_fromplf
		----	@ctxt_language,			@ctxt_ouinstance,		@ctxt_user,				@Ctxt_role,			@engg_customer_name,
		----	@engg_project_name,		@prc_name_tmp,			@component_name_tmp,	@engg_req_no,		@act_name_tmp,		
		----	@ui_name_tmp,			@engg_grid_sec_bts,		'HCol'	
		--END
-- NGPLF Changes Ends
--code added for compactview TECH-74323
declare @cunt1 engg_seqno, @cunt2 engg_seqno
	select @cunt1 =  count(*)
from ep_ui_grid_dtl (nolock)
WHERE customer_name = @engg_customer_name
	AND project_name = @engg_project_name
	AND process_name = @prc_name_tmp
	AND component_name = @component_name_tmp
	AND activity_name = @act_name_tmp
	AND ui_name = @ui_name_tmp
	AND page_bt_synonym = @engg_grid_page_bts
	AND control_bt_synonym = @engg_grid_grid_code
select @cunt2=  count(*)
from ep_ui_grid_dtl (nolock)
WHERE customer_name = @engg_customer_name
	AND project_name = @engg_project_name
	AND process_name = @prc_name_tmp
	AND component_name = @component_name_tmp
	AND activity_name = @act_name_tmp
	AND ui_name = @ui_name_tmp
	AND page_bt_synonym = @engg_grid_page_bts
	AND control_bt_synonym = @engg_grid_grid_code
and CompactView = 'y'
if @cunt1 = @cunt2
 begin  
        Raiserror ('Compactview should not be defaulted for all columns in a ML',16,1)  ;

		end

		----code ends for TECH-74323

-- Added for TECH-42760 Starts
	IF NOT EXISTS ( SELECT 'X'
	FROM	ep_ui_grid_dtl (nolock)
	WHERE customer_name = @engg_customer_name
	AND project_name = @engg_project_name
	AND process_name = @prc_name_tmp
	AND component_name = @component_name_tmp
	AND activity_name = @act_name_tmp
	AND ui_name = @ui_name_tmp
	AND page_bt_synonym = @engg_grid_page_bts
	AND control_bt_synonym = @engg_grid_grid_code
	AND	ISNULL(Compactview, 'No') = 'Y'
	)
	BEGIN
		UPDATE ep_ui_grid_dtl SET Compactview = 'NA'	
		WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND process_name = @prc_name_tmp
		AND component_name = @component_name_tmp
		AND activity_name = @act_name_tmp
		AND ui_name = @ui_name_tmp
		AND page_bt_synonym = @engg_grid_page_bts
		AND control_bt_synonym = @engg_grid_grid_code		
	END

	IF EXISTS ( SELECT 'X'
	FROM	ep_ui_grid_dtl (nolock)
	WHERE customer_name = @engg_customer_name
	AND project_name = @engg_project_name
	AND process_name = @prc_name_tmp
	AND component_name = @component_name_tmp
	AND activity_name = @act_name_tmp
	AND ui_name = @ui_name_tmp
	AND page_bt_synonym = @engg_grid_page_bts
	AND control_bt_synonym = @engg_grid_grid_code
	AND	ISNULL(Compactview, 'No') = 'Y'
	)
	BEGIN
		UPDATE ep_ui_grid_dtl SET Compactview = 'N'	
		WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND process_name = @prc_name_tmp
		AND component_name = @component_name_tmp
		AND activity_name = @act_name_tmp
		AND ui_name = @ui_name_tmp
		AND page_bt_synonym = @engg_grid_page_bts
		AND control_bt_synonym = @engg_grid_grid_code	
		AND	ISNULL(CompactView, 'no') = 'NA'
	END
-- Added for TECH-42760 Ends
--output parameters

select  @fprowno			'fprowno',
		@engg_del_columns	'engg_del_columns' -- Code added for Bug Id :PNR2.0_33469
set nocount off
End




GO
IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME= 'ep_layout_sp_savgrd_hck' AND TYPE='P')
BEGIN
	GRANT EXEC ON  ep_layout_sp_savgrd_hck TO PUBLIC
END
GO 
