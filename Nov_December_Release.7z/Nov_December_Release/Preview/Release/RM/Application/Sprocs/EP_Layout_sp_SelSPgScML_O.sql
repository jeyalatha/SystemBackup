IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'EP_Layout_sp_SelSPgScML_O' AND TYPE = 'P')
BEGIN
	DROP PROC EP_Layout_sp_SelSPgScML_O
END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		EP_Layout_sp_SelSPgScML_O.sql
********************************************************************************/
/********************************************************************************/
/* Procedure    : EP_Layout_sp_SelSPgScML_O                                     */
/* Description  :                                                               */
/********************************************************************************/
/* Project      :                                                               */
/* ECR          :                                                               */
/* Version      :                                                               */
/********************************************************************************/
/* Referenced   :                                                               */
/* Tables       :                                                               */
/********************************************************************************/
/* Development history                                                          */
/********************************************************************************/
/* Author       : Swaminathan R.                                                */
/* Date         : 22/Sep/2005                                                   */
/********************************************************************************/
/* Modification history                                                         */
/********************************************************************************/
/* modified by      Sangeetha L                                                 */
/* date             20/01/2006                                                  */
/* description      PNR2.0_5635                                                 */
/********************************************************************************/
/* Modified by  : kiruthika R                                                   */
/* Date         : 20-06-2006                                                    */
/* Description  : PNR2.0_9025                                                   */
/********************************************************************************/
/* Modified by  : Shakthi P                                                            */
/* Date         : 22-Mar-2011                                                          */
/* Description  : The state section should not appear in sections and Page Layout tabs.*/
/* CaseID       : PNR2.0_30667                                                         */
/***************************************************************************************/
/* modified by  : Piranava T  			                                                   */
/* date         : Oct 10 2014															   */
/* BugId        : PLF2.0_09035 															   */
/* description  : Model changes for rowspan,colspan,IsStatic,IsCallout iná layout level	   */
/*******************************************************************************************/
/* Modified by  : Veena U																   */
/* Date         : 25-Feb-2015															   */
/* Call ID		: PLF2.0_11499															   */
/*******************************************************************************************/
/* Modified by  : Veena U                                                                  */
/* Date         : 28-Mar-2016                                                              */
/* Call ID		: PLF2.0_17570															   */
/*******************************************************************************************/
/* modified by			Date				Defect ID									   */
/* Veena U				08-Jun-2016			PLF2.0_18487								   */
/* Modified by : Priyadharshini U/Jeya Latha K   Date: 27-Feb-2020  Defect ID : TECH-43307 */
/*******************************************************************************************/
/* Modified by	:	VimalKumar R 														   */
/* Modified on	:	08/06/22				 											   */
/* Defect ID	:	TECH-69624															   */
/* Description	:	Custom border, Custom actions and Responsive layout					   */
/*******************************************************************************************/
/* Modified by	:	Ponmalar A \ Vimal Kumar R		 									   */
/* Modified on	:	08/07/2022				 											   */
/* Defect ID	:	Tech-70687															   */
/* Description	:	Tool and Toolbars													   */
/*******************************************************************************************/
/* Modified by	:	Ponmalar A															   */
/* Modified on	:	24-Aug-2022				 											   */
/* Defect ID	:	TECH-72114															   */
/* Description	:	Platform Modeling for Section Title Icon							   */
/*******************************************************************************************/
/* Modified by  : VimalKumar R															   */
/* Modified on	:	03/11/22				 											   */
/* Defect ID	: TECH-75230															   */
/* Description	:	Platform Release for the Month of Nov'22							   */
/*******************************************************************************************/
CREATE PROCEDURE EP_Layout_sp_SelSPgScML_O
	@ctxt_language engg_ctxt_language, --Input
	@ctxt_ouinstance engg_ctxt_ouinstance, --Input
	@ctxt_service engg_ctxt_service, --Input
	@ctxt_user engg_ctxt_user, --Input
	@engg_act_descr engg_description, --Input
	@engg_component engg_description, --Input
	@engg_customer_name engg_name, --Input
	@engg_process_descr engg_description, --Input
	@engg_project_name engg_name, --Input
	@engg_req_no engg_name, --Input
	@engg_sec_page_bts engg_name, --Input
	@engg_ui_descr engg_description, --Input
	@guid engg_guid, --Input
	@m_errorid engg_seqno OUTPUT --To Return Execution Status
AS
BEGIN
	-- nocount should be switched on to prevent phantom rows
	SET NOCOUNT ON

	-- @m_errorid should be 0 to Indicate Success
	SELECT @m_errorid = 0

	--declaration of temporary variables
	--temporary and formal parameters mapping
	SELECT @ctxt_service = ltrim(rtrim(@ctxt_service))

	SELECT @ctxt_user = ltrim(rtrim(@ctxt_user))

	SELECT @engg_act_descr = ltrim(rtrim(@engg_act_descr))

	SELECT @engg_component = ltrim(rtrim(@engg_component))

	SELECT @engg_customer_name = ltrim(rtrim(@engg_customer_name))

	SELECT @engg_process_descr = ltrim(rtrim(@engg_process_descr))

	SELECT @engg_project_name = ltrim(rtrim(@engg_project_name))

	SELECT @engg_req_no = ltrim(rtrim(@engg_req_no))

	SELECT @engg_sec_page_bts = ltrim(rtrim(@engg_sec_page_bts))

	SELECT @engg_ui_descr = ltrim(rtrim(@engg_ui_descr))

	SELECT @guid = ltrim(rtrim(@guid))

	--null checking
	IF @ctxt_language = - 915
		SELECT @ctxt_language = NULL

	IF @ctxt_ouinstance = - 915
		SELECT @ctxt_ouinstance = NULL

	IF @ctxt_service = '~#~'
		SELECT @ctxt_service = NULL

	IF @ctxt_user = '~#~'
		SELECT @ctxt_user = NULL

	IF @engg_act_descr = '~#~'
		SELECT @engg_act_descr = NULL

	IF @engg_component = '~#~'
		SELECT @engg_component = NULL

	IF @engg_customer_name = '~#~'
		SELECT @engg_customer_name = NULL

	IF @engg_process_descr = '~#~'
		SELECT @engg_process_descr = NULL

	IF @engg_project_name = '~#~'
		SELECT @engg_project_name = NULL

	IF @engg_req_no = '~#~'
		SELECT @engg_req_no = NULL

	IF @engg_sec_page_bts = '~#~'
		SELECT @engg_sec_page_bts = NULL

	IF @engg_ui_descr = '~#~'
		SELECT @engg_ui_descr = NULL

	IF @guid = '~#~'
		SELECT @guid = NULL


	--errors mapped
	DECLARE
		--   @IUDModeFlag       varchar(2),
		@tmp_processname engg_name,
		@tmp_componentname engg_name,
		@tmp_activity engg_name,
		@tmp_ui engg_name,
		@msg engg_documentation,
		@engg_base_req_no engg_name

	SELECT @engg_base_req_no = 'BASE'

	-- modified by shafina on 18-feb-2004
	--output parameters
	--GETTING THE PROCESS NAME FOR DESCRIPTION
	SELECT @tmp_processname = process_name
	--from  ep_process_mst  (nolock) /* 2003_Dec_25 Changes - by saro */
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND process_descr = @engg_process_descr
		AND req_no = @engg_req_no

	--GETTING THE COMPONENT NAME FOR THE DESCRIPTION
	SELECT @tmp_componentname = Component_name
	--from  ep_component_mst  (nolock)/* 2003_Dec_25 Changes - by saro */
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND process_name = @tmp_processname
		AND component_descr = @engg_component
		AND req_no = @engg_req_no

	--GETTING THE ACTIVITY NAME FOR THE DESCRIPTION
	SELECT @tmp_activity = activity_name
	--from  ep_activity_mst (nolock) /* 2003_Dec_25 Changes - by saro */
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND process_name = @tmp_processname
		AND component_name = @tmp_componentname
		AND activity_descr = @engg_act_descr
		AND req_no = @engg_req_no

	--GETTING THE UI NAME FOR THE DESCRIPTION
	SELECT @tmp_ui = ui_name
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND process_name = @tmp_processname
		AND component_name = @tmp_componentname
		AND activity_name = @tmp_activity
		AND ui_descr = @engg_ui_descr
		AND req_no = @engg_req_no

	--Code modified by Sangeetha L  for Bug id:PNR2.0_5635
	SELECT CASE 
			WHEN border_required = 'Y'
				THEN 1
			WHEN border_required = 'n'
				THEN 0
			END 'engg_sec_bord_req',
		section_bt_synonym 'engg_sec_btsynname',
		bt_synonym_caption 'engg_sec_descr',
		a.title_alignment 'engg_sec_title_align',
		CASE 
			WHEN title_required = 'Y'
				THEN 1
			WHEN title_required = 'n'
				THEN 0
			END 'engg_sec_title_req',
		CASE 
			WHEN visisble_flag = 'Y'
				THEN 1
			WHEN visisble_flag = 'n'
				THEN 0
					--Code modified by Sangeetha L  for Bug id:PNR2.0_5635
			END 'engg_sec_visible',
-- Added for Request TECH-43307 Starts
				CASE 
				    WHEN IsResponsive = 'y'
		              THEN 1
				    WHEN IsResponsive = 'n'
					  THEN 0
	            END 'engg_mob_responsive',
                                           
				CASE 
                   WHEN mob_pop_fullview = 'y'
                     THEN 1
                   WHEN mob_pop_fullview = 'n'
                     THEN 0
                END 'engg_mob_fullview',
-- Added for Request TECH-43307 Ends
		a.section_type 'engg_sec_type',
		--code modified by kiruthika For bugid:PNR2.0_9025
		cast(a.height AS VARCHAR(60)) + a.Section_height_Scalemode 'engg_sec_height',
		cast(a.Width AS VARCHAR(60)) + a.Section_width_Scalemode 'engg_sec_width',
		a.caption_Format 'engg_sec_cap_format',
		a.ctrl_caption_align 'engg_sec_cap_align',
		a.SectionPrefixClass 'engg_sec_class_prefix',
		a.section_doc 'engg_sect_doc',
		a.section_collapse 'Sec_Collapse',
		a.section_collapsemode 'sec_collapsemode',
		a.NRowSpan 'section_rowspan',
		a.NColSpan 'section_colspan',
		isnull(reg.parameter_text, '') 'engg_region', -- PLF2.0_17570   
		isnull(titlpo.parameter_text, '') 'engg_title_pos',
		isnull(col.parameter_text, '') 'engg_col_dir',
		isnull(sectl.parameter_text, '') 'engg_sect_lay',
		CASE 
			WHEN SectionLayout = 'abs'
				THEN isnull(XYCoordinates, '')
			WHEN SectionLayout = 'col'
				THEN isnull(ColumnLayWidth, '')
			ELSE NULL
			END 'engg_sec_lay_con',
		ISNULL(Associated_Control,	'') 'engg_associatedcontrol',
		ISNULL(a.ForResponsive,		'') 'engg_sect_forresponsive',		--Code Added for TECH-69624
		'...'							'engg_sec_customborder',		--Code Added for TECH-69624
		ISNULL(a.Orientation,		'') 'Orientation',					--Code Added for TECH-75230 
		--Code Added for the Defect Id Tech-70687 starts
		'...'													'engg_sec_titleaction',
        CASE WHEN a.LeftToolbar		= 'Y' THEN 1 ELSE 0 END		'engg_sec_lefttb',
        CASE WHEN a.RightToolbar	= 'Y' THEN 1 ELSE 0 END		'engg_sec_righttb',
        CASE WHEN a.TopToolbar		= 'Y' THEN 1 ELSE 0 END		'engg_sec_toptb',
        CASE WHEN a.BottomToolbar	= 'Y' THEN 1 ELSE 0 END		'engg_sec_bottomtb',
		a.MinimizedRows											'engg_sec_MinRows',
		a.ViewMode												'engg_sec_VwMode',
        --Code Added for the Defect Id Tech-70687 ends
		a.TitleIcon						'engg_sec_titleicon'  --TECH-72114
	--,case upper(IsStatic)
	--when 'Y'  then 1
	--else 0
	--end    'isstatic'
	FROM ep_ui_section_dtl a(NOLOCK)
	LEFT JOIN ep_component_glossary_mst b(NOLOCK) ON a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.section_bt_synonym = b.bt_synonym_name
		AND a.req_no = b.req_no
	LEFT JOIN ep_device_quick_code_met reg(NOLOCK) ON a.Region = reg.parameter_code
		AND reg.parameter_type = 'Region'
	LEFT JOIN ep_device_quick_code_met titlpo(NOLOCK) ON a.TitlePosition = titlpo.parameter_code
		AND titlpo.parameter_type = 'TitlePosition'
	LEFT JOIN ep_device_quick_code_met col(NOLOCK) ON a.CollapseDir = col.parameter_code
		AND col.parameter_type = 'CollapseDir'
	LEFT JOIN ep_device_quick_code_met sectl(NOLOCK) ON a.SectionLayout = sectl.parameter_code
		AND sectl.parameter_type = 'SectionLayout'
	WHERE a.customer_name = @engg_customer_name
		AND a.project_name = @engg_project_name
		AND a.req_no = @engg_base_req_no
		AND a.process_name = @tmp_processname
		AND a.component_name = @tmp_componentname
		AND a.activity_name = @tmp_activity
		AND a.ui_name = @tmp_ui
		AND a.page_bt_synonym = @engg_sec_page_bts
		AND a.section_bt_synonym NOT IN (
			'PrjHdnSection',
			'[tabcontrol]',
			'hdnrt_stsection'
			)
		AND section_type NOT IN ('Sidebar','Toolbar') --Tech-70687
	/* Code Modified for the Case ID:PNR2.0_30667 By Shakthi P */
	ORDER BY 2

	--  and   a.customer_name      *=  b.customer_name
	--  and   a.project_name       *=  b.project_name
	--  and   a.process_name       *=  b.process_name
	--  and   a.component_name      *=  b.component_name
	--  and   a.section_bt_synonym  *=  b.bt_synonym_name
	--  and   a.req_no      *=  b.req_no
	--  and  a.section_bt_synonym not in ('PrjHdnSection','[tabcontrol]')
	--  order by 2
	/*
--OuputList
Select null 'engg_sec_bord_req',
null 'engg_sec_btsynname',
null 'engg_sec_descr',
null 'engg_sec_title_align',
null 'engg_sec_title_req',
null 'engg_sec_visible',
null 'engg_sec_type',
null 'engg_sec_height',
null 'engg_sec_width',
null 'engg_sec_cap_format',
null 'engg_sec_cap_align',
null 'engg_sec_class_prefix',
null 'engg_sect_doc' from ***
*/
	SET NOCOUNT OFF
END
GO

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'EP_Layout_sp_SelSPgScML_O' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON EP_Layout_sp_SelSPgScML_O TO PUBLIC
END
GO
