IF EXISTS(SELECT 'X' From SYSOBJECTS WHERE NAME ='ep_layout_sp_savpg_hck' AND TYPE='P')
   BEGIN
        DROP PROC ep_layout_sp_savpg_hck
   END
GO 
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		ep_layout_sp_savpg_hck.sql
********************************************************************************/
/*      V E R S I O N      :  PNR2.0_1403    */
/*      Released By        :  Development Team    */
/*      Release Comments   :  For DotNet Migration, Naming convention has been changed  for some of the out parameters by using Stub Generator.Comments will not be there for this Request ID.    */
/*      V E R S I O N      :  2.0.4    */
/*      Released By        :  Ptech    */
/*      Release Comments   :  Released On 30-September-2004    */
/*      V E R S I O N      :  2.0.2    */
/*      Released By        :  PTech    */
/*      Release Comments   :  Released on  22-Jan-2004    */
/****** Object:  Stored Procedure dbo.ep_layout_sp_savpg_hck    Script Date: 11/6/03 5:20:47 PM ******/
/********************************************************************************/
/* procedure      ep_layout_sp_savpg_hck                                        */
/* description    header check sp                                               */
/********************************************************************************/
/* project        Engineering                                                   */
/* version        2.0                                                           */
/********************************************************************************/
/* referenced                                                                   */
/* tables                                                                       */
/********************************************************************************/
/* development history                                                          */
/********************************************************************************/
/* author         Giridharan V                                                  */
/* date           23/ 10/ 2003                                                  */
/********************************************************************************/
/* modification history                                                         */
/********************************************************************************/
/* modified by    Shafina Begum.B                                               */
/* date           16/ 01/ 2004                                                  */
/* description    To check for horder and vorder only if atleast one tab is present*/
/********************************************************************************/
/* modified by    Balaji.S                                                  */
/* date           14/04/2007                                                   */
/* description    PNR2.0_13120             */
/********************************************************************************/
/* modified by   : Chanheetha N A        */
/* date     : 17-nov-2007         */
/* BugId    : PNR2.0_16023          */
/************************************************************************/
/* modified by   : Feroz        */
/* date     : 22-jan-2009         */
/* BugId    : :PNR2.0_20782          */
/************************************************************************/
/* Modified by  : Veena U                                                  */
/* Date         : 25-Feb-2015                                                  */
/* Call ID		: PLF2.0_11499                                                 */
/********************************************************************************/
/* Modified by  : Veena U                                                  */
/* Date         : 28-Mar-2016                                                 */
/* Call ID		: PLF2.0_17570                                               */
/********************************************************************************/
/* modified by                    Date                       Defect ID            */
/* Veena U                        22-Jun-2016                PLF2.0_19034┬á        */
/**********************************************************************************/
/* Modified by	:	Venkatesan K                                                  */
/* Date         :   05-APR-2018                ┬á        						  */
/* Defect ID	:	TECH-20428													  */
/* Descriprtion	:	Section collapse and collapse mode option disabled tab control*/
/**********************************************************************************/
/* Modified by  : Jeya Latha K	Date: 30-Apr-2018  Defect ID : TECH-20897	   */
/*******************************************************************************/
/* Modified by	:	Priyadharshini U/VimalKumar R								*/
/* Modified on	:	08/06/22				 									*/
/* Defect ID	:	TECH-69624													*/
/* Description	:	Custom border, Custom actions and Responsive layout			*/
/********************************************************************************/
/* Modified by	:	Ponmalar A		 											*/
/* Modified on	:	08/07/2022				 									*/
/* Defect ID	:	Tech-70687													*/
/* Description	:	Tool and Toolbars											*/
/********************************************************************************/
/* Modified by  : Ponmalar A	Date: 24-Aug-2022  Defect ID : TECH-72114		*/
/********************************************************************************/
/* Modified by  : Ponmalar A	Date: 02-Dec-2022  Defect ID : TECH-75230		*/
/********************************************************************************/
CREATE PROCEDURE ep_layout_sp_savpg_hck
	@ctxt_language_in engg_ctxt_language,
	@ctxt_ouinstance_in engg_ctxt_ouinstance,
	@ctxt_service_in engg_ctxt_service,
	@ctxt_user_in engg_ctxt_user,
	@engg_act_descr_in engg_description,
	@engg_component_in engg_description,
	@engg_customer_name_in engg_name,
	@engg_process_descr_in engg_description,
	@engg_project_name_in engg_name,
	@engg_req_no_in engg_name,
	@engg_ui_descr_in engg_description,
	@guid_in engg_guid,
	@fprowno_io engg_rowno,
	@m_errorid INT OUTPUT
AS
BEGIN
	SET NOCOUNT ON

	--declaration of temporary variables
	DECLARE @iudmodeflag VARCHAR(2),
		@msg VARCHAR(200),
		@maxval INT,
		@rowcount INT,
		@horderval INT,
		@tmp_proc VARCHAR(40),
		@tmp_comp VARCHAR(40),
		@tmp_act VARCHAR(40),
		@tmp_ui VARCHAR(60), --udd length should be 60 
		@engg_base_req_no engg_name
	DECLARE @ctxt_language engg_ctxt_language
	DECLARE @ctxt_ouinstance engg_ctxt_ouinstance
	DECLARE @ctxt_service engg_ctxt_service
	DECLARE @ctxt_user engg_ctxt_user
	DECLARE @engg_act_descr engg_description
	DECLARE @engg_component engg_description
	DECLARE @engg_customer_name engg_name
	DECLARE @engg_process_descr engg_description
	DECLARE @engg_project_name engg_name
	DECLARE @engg_req_no engg_name
	DECLARE @engg_ui_descr engg_description
	DECLARE @guid engg_guid
	DECLARE @fprowno engg_rowno

	--temporary and formal parameters mapping
	SELECT @ctxt_language = @ctxt_language_in

	SELECT @ctxt_ouinstance = @ctxt_ouinstance_in

	SELECT @ctxt_service = ltrim(rtrim(@ctxt_service_in))

	SELECT @ctxt_user = ltrim(rtrim(@ctxt_user_in))

	SELECT @engg_act_descr = ltrim(rtrim(@engg_act_descr_in))

	SELECT @engg_component = ltrim(rtrim(@engg_component_in))

	SELECT @engg_customer_name = ltrim(rtrim(@engg_customer_name_in))

	SELECT @engg_process_descr = ltrim(rtrim(@engg_process_descr_in))

	SELECT @engg_project_name = ltrim(rtrim(@engg_project_name_in))

	SELECT @engg_req_no = ltrim(rtrim(@engg_req_no_in))

	SELECT @engg_ui_descr = ltrim(rtrim(@engg_ui_descr_in))

	SELECT @guid = ltrim(rtrim(@guid_in))

	SELECT @fprowno = @fprowno_io

	--null checking
	IF @ctxt_language = - 915
		SELECT @ctxt_language = NULL

	IF @ctxt_ouinstance = - 915
		SELECT @ctxt_ouinstance = NULL

	IF @ctxt_service = '~#~'
		SELECT @ctxt_service = NULL

	IF @ctxt_user = '~#~'
		SELECT @ctxt_user = NULL

	IF @engg_act_descr = '~#~'
		SELECT @engg_act_descr = NULL

	IF @engg_component = '~#~'
		SELECT @engg_component = NULL

	IF @engg_customer_name = '~#~'
		SELECT @engg_customer_name = NULL

	IF @engg_process_descr = '~#~'
		SELECT @engg_process_descr = NULL

	IF @engg_project_name = '~#~'
		SELECT @engg_project_name = NULL

	IF @engg_req_no = '~#~'
		SELECT @engg_req_no = NULL

	IF @engg_ui_descr = '~#~'
		SELECT @engg_ui_descr = NULL

	IF @guid = '~#~'
		SELECT @guid = NULL

	IF @fprowno = - 915
		SELECT @fprowno = NULL

	--GETTING THE PROCESS NAME FOR DESCRIPTION
	SELECT @tmp_proc = process_name
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND req_no = @engg_req_no
		AND process_descr = @engg_process_descr

	--GETTING THE COMPONENT NAME FOR THE DESCRIPTION
	SELECT @tmp_comp = component_name
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND req_no = @engg_req_no
		AND process_name = @tmp_proc
		AND component_descr = @engg_component

	--GETTING THE ACTIVITY NAME FOR THE DESCRIPTION
	SELECT @tmp_act = activity_name
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND req_no = @engg_req_no
		AND process_name = @tmp_proc
		AND component_name = @tmp_comp
		AND activity_descr = @engg_act_descr

	--GETTING THE UI NAME FOR THE DESCRIPTION
	SELECT @tmp_ui = ui_name
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND req_no = @engg_req_no
		AND process_name = @tmp_proc
		AND component_name = @tmp_comp
		AND activity_name = @tmp_act
		AND ui_descr = @engg_ui_descr

	SELECT @engg_base_req_no = 'BASE'

	IF @fpRowno = 0
	BEGIN
		SELECT @msg = 'No new pages created.'

		EXEC engg_error_sp 'en_layout_sp_savpg_hck',
			1,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		RETURN
	END

	--VALIDATIONS
	--HORDER AND VORDER ZERO CHECKING
	-- code added by shafina on 16-jan-2004 to check for horder and vorder only if atleast one tab is present
	IF EXISTS (
			SELECT 'X'
			FROM ep_ui_page_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_base_req_no
				AND process_name = @tmp_proc
				AND component_name = @tmp_comp
				AND activity_name = @tmp_act
				AND ui_name = @tmp_ui
				AND page_bt_synonym <> '[mainscreen]'
			)
	BEGIN
		IF EXISTS (
				SELECT 'X'
				FROM ep_ui_page_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND activity_name = @tmp_act
					AND ui_name = @tmp_ui
					AND page_bt_synonym <> '[mainscreen]'
					AND (
						horder = 0
						OR vorder = 0
						)
				)
		BEGIN
			IF @fprowNo > 0
			BEGIN
				SELECT @msg = 'Horizontal/Vertical should not be zero'

				EXEC engg_error_sp 'en_layout_sp_savpg_hck',
					1,
					@msg,
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					'',
					'',
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid <> 0
					RETURN
			END
		END

		--"Check for the following:
		IF EXISTS (
				SELECT 'X'
				FROM ep_ui_page_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND activity_name = @tmp_act
					AND ui_name = @tmp_ui
					AND horder = 1
					AND vorder = 1
				)
		BEGIN
			SELECT @tmp_ui = rtrim(@tmp_ui)
		END
		ELSE
		BEGIN
			IF @fprowNo > 0
			BEGIN
				SELECT @msg = 'Horizontal/Vertical Order Combination should Start with 1 : 1'

				EXEC engg_error_sp 'en_layout_sp_savpg_hck',
					1,
					@msg,
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					'',
					'',
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid <> 0
					RETURN
			END
		END

		DECLARE @horder_temp engg_seqno
		DECLARE @count engg_seqno

		SELECT @count = 1

		DECLARE hordercheck_cur CURSOR
		FOR
		SELECT DISTINCT horder
		FROM ep_ui_page_dtl(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND req_no = @engg_base_req_no
			AND process_name = @tmp_proc
			AND component_name = @tmp_comp
			AND activity_name = @tmp_act
			AND ui_name = @tmp_ui
			AND page_bt_synonym <> '[mainscreen]'
		ORDER BY horder

		OPEN hordercheck_cur

		WHILE (1 = 1)
		BEGIN
			FETCH NEXT
			FROM hordercheck_cur
			INTO @horder_temp

			IF (@@fetch_status) <> 0
				BREAK

			IF @horder_temp <> @count
			BEGIN
				CLOSE hordercheck_cur

				DEALLOCATE hordercheck_cur

				EXEC engg_error_sp 'ep_layout_sp_savpg_hck',
					9,
					'There are gaps in Horder sequence',
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					'',
					'',
					'',
					'',
					@m_errorid OUTPUT

				RETURN
			END

			SELECT @count = @count + 1
		END

		CLOSE hordercheck_cur

		DEALLOCATE hordercheck_cur

		--1. The combination of Horizontal and Vertical Order must not repeat.
		IF EXISTS (
				SELECT horder,
					vorder
				FROM ep_ui_page_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND activity_name = @tmp_act
					AND ui_name = @tmp_ui
				GROUP BY horder,
					vorder
				HAVING count(*) > 1
				)
		BEGIN
			SELECT @msg = 'There is inconsistency in the Horizontal/Vertical Orders of the Pages.'

			EXEC engg_error_sp 'en_layout_sp_savpg_hck',
				1,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			RETURN
		END

		--2. There should not be any gaps in the Horizontal or Vertical Order sequences."
		DECLARE hordercur CURSOR
		FOR
		SELECT DISTINCT horder
		FROM ep_ui_page_dtl(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND req_no = @engg_base_req_no
			AND process_name = @tmp_proc
			AND component_name = @tmp_comp
			AND activity_name = @tmp_act
			AND ui_name = @tmp_ui
			AND horder <> 0

		OPEN hordercur

		FETCH NEXT
		FROM hordercur
		INTO @horderval

		WHILE 1 = 1
		BEGIN
			IF @@fetch_status <> 0
			BEGIN
				BREAK
			END

			SELECT @rowcount = count(*)
			FROM ep_ui_page_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_base_req_no
				AND process_name = @tmp_proc
				AND component_name = @tmp_comp
				AND activity_name = @tmp_act
				AND ui_name = @tmp_ui
				AND horder = @horderval
				AND horder <> 0

			SELECT @maxval = max(vorder)
			FROM ep_ui_page_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_base_req_no
				AND process_name = @tmp_proc
				AND component_name = @tmp_comp
				AND activity_name = @tmp_act
				AND ui_name = @tmp_ui
				AND horder = @horderval
				AND horder <> 0

			IF @rowcount <> @maxval
			BEGIN
				CLOSE hordercur

				DEALLOCATE hordercur

				SELECT @msg = 'There is inconsistency in the Horizontal/Vertical Orders of the Pages.'

				EXEC engg_error_sp 'en_layout_sp_savpg_hck',
					2,
					@msg,
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					'',
					'',
					'',
					'',
					@m_errorid OUTPUT

				RETURN
			END

			FETCH NEXT
			FROM hordercur
			INTO @horderval
		END

		CLOSE hordercur

		DEALLOCATE hordercur
	END

	-- Added BY Feroz For bug id :PNR2.0_20782 
	IF EXISTS (
			SELECT count(page_type)
			FROM ep_ui_page_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_base_req_no
				AND process_name = @tmp_proc
				AND component_name = @tmp_comp
				AND activity_name = @tmp_act
				AND ui_name = @tmp_ui
				AND page_type = 'Grouping'
			GROUP BY page_type
			HAVING count(page_type) > 1
			)
	BEGIN
		SELECT @msg = 'Page Type, Groupping can be done for only one Page in an UI.'

		EXEC engg_error_sp 'en_layout_sp_savpg_hck',
			2,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		RETURN
	END

	-- Added BY Feroz For bug id :PNR2.0_20782 
	-- modified by shafina on 30-jan-2004 to insert a '[tabcontrol]' section for '[mainscreen]'
	IF EXISTS (
			SELECT 'x'
			FROM ep_ui_page_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_base_req_no
				AND process_name = @tmp_proc
				AND component_name = @tmp_comp
				AND activity_name = @tmp_act
				AND ui_name = @tmp_ui
				AND page_bt_synonym <> '[mainscreen]'
			)
	BEGIN
		IF NOT EXISTS (
				SELECT 'x'
				FROM ep_ui_section_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND activity_name = @tmp_act
					AND ui_name = @tmp_ui
					AND page_bt_synonym = '[mainscreen]'
					AND section_bt_synonym = '[tabcontrol]'
				)
		BEGIN
			--Code Modified for BugId : PNR2.0_13120
			EXEC ep_ui_section_dtl_sp_ins @ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@engg_customer_name,
				@engg_project_name,
				@engg_base_req_no,
				@tmp_proc,
				@tmp_comp,
				@tmp_act,
				@tmp_ui,
				'[mainscreen]',
				'[tabcontrol]',
				'Y',
				'N',
				'N',
				'Left',
				'',
				0,
				0,
				'[tabcontrol]',
				1,
				'',
				'',
				'bes',
				'',
				'',
				'',
				'',
				'NON',
				'N',
				@engg_req_no,
				'',
				'', --code modified by 11536 for the case id TECH-20428
				'',
				'',
				'',
				'',
				'',
				'',
				'', --veena PLF2.0_17570   
				'',
				'',
				0,  --TECH-69624
				'',	--TECH-75230
				'','','','','','', --Tech-70687
				'', --TECH-72114
				@m_errorid OUTPUT --chan

			IF @m_errorid <> 0
				RETURN
		END
	END
	ELSE
	BEGIN
		IF EXISTS (
				SELECT 'x'
				FROM ep_ui_section_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND activity_name = @tmp_act
					AND ui_name = @tmp_ui
					AND page_bt_synonym = '[mainscreen]'
					AND section_bt_synonym = '[tabcontrol]'
				)
		BEGIN
			EXEC ep_ui_section_dtl_sp_del @ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@engg_customer_name,
				@engg_project_name,
				@engg_base_req_no,
				@tmp_proc,
				@tmp_comp,
				@tmp_act,
				@tmp_ui,
				'[mainscreen]',
				'[tabcontrol]',
				@m_errorid OUTPUT

			IF @m_errorid <> 0
				RETURN
		END
	END

	SET NOCOUNT OFF
END

GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME= 'ep_layout_sp_savpg_hck' AND TYPE='P')
BEGIN
	GRANT EXEC ON  ep_layout_sp_savpg_hck TO PUBLIC
END
GO
