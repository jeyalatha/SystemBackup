IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'EP_UI_SECTION_DTL_SP_INS' AND TYPE = 'P')
BEGIN
	DROP PROC EP_UI_SECTION_DTL_SP_INS
END
GO
Set quoted_identifier off
go
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		EP_UI_SECTION_DTL_SP_INS.sql
********************************************************************************/
/* modified by			: Chanheetha N A								*/
/* date					: 17-nov-2007									*/
/* BugId				: PNR2.0_16023 									*/
/************************************************************************/
/* modified by  : Veena U   			                                        */
/* date         : Oct 10 2014			                                        */
/* BugId        : PLF2.0_09035													*/
/* description  : Model changes for rowspan,colspan,IsStatic,IsCallout 
				  in  layout level.												*/
/********************************************************************************/
/* Modified by  : Veena U                                                  */
/* Date         : 28-Mar-2016                                                 */
/* Call ID		: PLF2.0_17570                                               */
/********************************************************************************/
/* modified by                    Date                       Defect ID            */
/* Veena U                        08-Jun-2016                PLF2.0_18487         */
/**********************************************************************************/
/* Modified by : Jeya Latha K/Ganesh Prabhu S	for callid TECH-7349				*/
/* Modified on : 14-03-2017				 											*/
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and New Feature Organization chart */
/* Modified by  : Jeya Latha K/Venkatesan K	Date: 31-Oct-2018  Defect ID : TECH-28010 */
/**************************************************************************************/
/* Modified by	:	Priyadharshini U/VimalKumar R								*/
/* Modified on	:	08/06/22				 									*/
/* Defect ID	:	TECH-69624													*/
/* Description	:	Custom border, Custom actions and Responsive layout			*/
/********************************************************************************/
/* Modified by	:	Ponmalar A													*/
/* Modified on	:	11-July-22				 									*/
/* Defect ID	:	TECH-70687													*/
/* Description	:	Tool and Toolbars											*/
/********************************************************************************/
/* Modified by	:	Ponmalar A													*/
/* Modified on	:	24-Aug-2022				 									*/
/* Defect ID	:	TECH-72114													*/
/* Description	:	Platform Modeling for Section Title Icon					*/
/********************************************************************************/
/* Modified by	:	Vimal Kumar R												*/
/* Modified on	:	03-Nov-2022				 									*/
/* Defect ID	:	TECH-75230													*/
/* Description	:	Platform Release for the Month of Nov'22					*/
/********************************************************************************/
CREATE PROCEDURE EP_UI_SECTION_DTL_SP_INS
	@CTXT_LANGUAGE_IN ENGG_CTXT_LANGUAGE,
	@CTXT_OUINSTANCE_IN ENGG_CTXT_OUINSTANCE,
	@CTXT_SERVICE_IN ENGG_CTXT_SERVICE,
	@CTXT_USER_IN ENGG_CTXT_USER,
	@CUSTOMER_NAME_IN ENGG_NAME,
	@PROJECT_NAME_IN ENGG_NAME,
	@REQ_NO_IN ENGG_NAME,
	@PROCESS_NAME_IN ENGG_NAME,
	@COMPONENT_NAME_IN ENGG_NAME,
	@ACTIVITY_NAME_IN ENGG_NAME,
	@UI_NAME_IN ENGG_NAME,
	@PAGE_BT_SYNONYM_IN ENGG_NAME,
	@SECTION_BT_SYNONYM_IN ENGG_NAME,
	@VISISBLE_FLAG_IN ENGG_FLAG,
	@TITLE_REQUIRED_IN ENGG_FLAG,
	@BORDER_REQUIRED_IN ENGG_FLAG,
	-- datatype changed by shafina on 21-April-2004 for PREVIEWENG203ACC_000028
	@TITLE_ALIGNMENT_IN ENGG_NAME,
	@PARENT_SECTION_IN ENGG_NAME,
	@HORDER_IN ENGG_SEQNO,
	@VORDER_IN ENGG_SEQNO,
	@SECTION_DOC_IN ENGG_DOCUMENTATION,
	@TIMESTAMP_IN INT,
	@ENGG_SECTION_TYPE_IN ENGG_NAME,
	@engg_sec_cap_align engg_name, --Input 
	@engg_sec_cap_format engg_name, --Input 
	@sectionheight engg_seqno, --Input 
	@sectionwidth engg_seqno, --Input 
	@Section_width_Scalemode Engg_name,
	@Section_height_Scalemode Engg_name,
	@Sec_CollapseMode Engg_name,
	@Sec_Collapse Engg_name,
	@engg_req_no ENGG_NAME, --chan
	@section_rowspan engg_seqno,
	@section_colspan engg_seqno,
	--@IsStatic											engg_flag,
	@Region engg_flag, --- PLF2.0_17570  
	@TitlePosition engg_flag,
	@CollapseDir engg_flag,
	@SectionLayout engg_name,			--TECH-69624(engg_flag to engg_name)
	@XYCoordinates engg_description,
	@ColumnLayWidth engg_description,
	@engg_associatedcontrol engg_name,
	----code added by 13639 starts----
	@engg_mob_fullview  engg_flag,
	@engg_mob_responsive  engg_flag,
	-----code added by 13639 ends----
	@engg_sect_forresponsive engg_seqno,	--Code added for TECH-69624
	@Orientation			 engg_name ,	--Code Added for TECH-75230
	--TECH-70687
	@engg_sec_bottomtb	engg_seqno,
	@engg_sec_toptb		engg_seqno,
	@engg_sec_righttb	engg_seqno,
	@engg_sec_lefttb	engg_seqno,
	@engg_sec_minrows	engg_seqno,
	@engg_sec_vwmode	engg_name,
	--TECH-70687
	@engg_sec_titleicon	engg_name,  --TECH-72114
	@M_ERRORID INT OUTPUT
AS
BEGIN
	SET NOCOUNT ON

	/********************************************************************************/
	/*                          TEMPORARY INPUT PARAMETERS                          */
	/********************************************************************************/
	DECLARE @ERRORMESSAGE_TMP VARCHAR(1000),
		@ERRORNO_TMP INT,
		@SPERROR INT,
		@DUPCOUNT_TMP INT,
		@TIMESTAMP_TMP INT,
		@CTXT_LANGUAGE_TMP ENGG_CTXT_LANGUAGE,
		@CUSTOMER_NAME_TMP ENGG_NAME,
		@CTXT_OUINSTANCE_TMP ENGG_CTXT_OUINSTANCE,
		@PROJECT_NAME_TMP ENGG_NAME,
		@CTXT_SERVICE_TMP ENGG_CTXT_SERVICE,
		@REQ_NO_TMP ENGG_NAME,
		@CTXT_USER_TMP ENGG_CTXT_USER,
		@PROCESS_NAME_TMP ENGG_NAME,
		@COMPONENT_NAME_TMP ENGG_NAME,
		@ACTIVITY_NAME_TMP ENGG_NAME,
		@UI_NAME_TMP ENGG_NAME,
		@PAGE_BT_SYNONYM_TMP ENGG_NAME,
		@SECTION_BT_SYNONYM_TMP ENGG_NAME,
		@VISISBLE_FLAG_TMP ENGG_FLAG,
		@TITLE_REQUIRED_TMP ENGG_FLAG,
		@BORDER_REQUIRED_TMP ENGG_FLAG,
		@TITLE_ALIGNMENT_TMP ENGG_NAME,
		@PARENT_SECTION_TMP ENGG_NAME,
		@HORDER_TMP ENGG_SEQNO,
		@VORDER_TMP ENGG_SEQNO,
		@SECTION_DOC_TMP ENGG_DOCUMENTATION,
		@UI_SECTION_SYSID_TMP ENGG_SYSID,
		@PAGE_SYSID_TMP ENGG_SYSID,
		@SECTION_TYPE_TMP ENGG_NAME,
		@colspan_tmp engg_seqno,
		@rowspan_tmp engg_seqno

	--@isstatic_tmp										engg_flag
	/********************************************************************************/
	/*                                  ASSIGNING TO TEMP VARIABLE                  */
	/********************************************************************************/
	SELECT @CTXT_LANGUAGE_TMP = @CTXT_LANGUAGE_IN,
		@CUSTOMER_NAME_TMP = LTRIM(RTRIM(@CUSTOMER_NAME_IN)),
		@CTXT_OUINSTANCE_TMP = @CTXT_OUINSTANCE_IN,
		@PROJECT_NAME_TMP = LTRIM(RTRIM(@PROJECT_NAME_IN)),
		@CTXT_SERVICE_TMP = LTRIM(RTRIM(@CTXT_SERVICE_IN)),
		@REQ_NO_TMP = LTRIM(RTRIM(@REQ_NO_IN)),
		@CTXT_USER_TMP = LTRIM(RTRIM(@CTXT_USER_IN)),
		@PROCESS_NAME_TMP = LTRIM(RTRIM(@PROCESS_NAME_IN)),
		@COMPONENT_NAME_TMP = LTRIM(RTRIM(@COMPONENT_NAME_IN)),
		@ACTIVITY_NAME_TMP = LTRIM(RTRIM(@ACTIVITY_NAME_IN)),
		@UI_NAME_TMP = LTRIM(RTRIM(@UI_NAME_IN)),
		@PAGE_BT_SYNONYM_TMP = LTRIM(RTRIM(@PAGE_BT_SYNONYM_IN)),
		@SECTION_BT_SYNONYM_TMP = LTRIM(RTRIM(@SECTION_BT_SYNONYM_IN)),
		@VISISBLE_FLAG_TMP = LTRIM(RTRIM(@VISISBLE_FLAG_IN)),
		@TITLE_REQUIRED_TMP = LTRIM(RTRIM(@TITLE_REQUIRED_IN)),
		@BORDER_REQUIRED_TMP = LTRIM(RTRIM(@BORDER_REQUIRED_IN)),
		@TITLE_ALIGNMENT_TMP = LTRIM(RTRIM(@TITLE_ALIGNMENT_IN)),
		@PARENT_SECTION_TMP = LTRIM(RTRIM(@PARENT_SECTION_IN)),
		@HORDER_TMP = @HORDER_IN,
		@VORDER_TMP = @VORDER_IN,
		@SECTION_DOC_TMP = LTRIM(RTRIM(@SECTION_DOC_IN)),
		@TIMESTAMP_TMP = @TIMESTAMP_IN,
		@SECTION_TYPE_TMP = LTRIM(RTRIM(@ENGG_SECTION_TYPE_IN)),
		--@isstatic_tmp									    = ltrim(rtrim(@IsStatic_tmp)),	
		@colspan_tmp = ltrim(rtrim(@section_colspan)),
		@rowspan_tmp = ltrim(rtrim(@section_rowspan))

	/********************************************************************************/
	/*                   TEMPORARY AND FORMAL PARAMETERS MAPPING                    */
	/********************************************************************************/
	IF @CTXT_LANGUAGE_TMP = - 915
		SELECT @CTXT_LANGUAGE_TMP = NULL

	IF @CUSTOMER_NAME_TMP = '~#~'
		SELECT @CUSTOMER_NAME_TMP = NULL

	IF @CTXT_OUINSTANCE_TMP = - 915
		SELECT @CTXT_OUINSTANCE_TMP = NULL

	IF @PROJECT_NAME_TMP = '~#~'
		SELECT @PROJECT_NAME_TMP = NULL

	IF @CTXT_SERVICE_TMP = '~#~'
		SELECT @CTXT_SERVICE_TMP = NULL

	IF @REQ_NO_TMP = '~#~'
		SELECT @REQ_NO_TMP = NULL

	IF @CTXT_USER_TMP = '~#~'
		SELECT @CTXT_USER_TMP = NULL

	IF @PROCESS_NAME_TMP = '~#~'
		SELECT @PROCESS_NAME_TMP = NULL

	IF @COMPONENT_NAME_TMP = '~#~'
		SELECT @COMPONENT_NAME_TMP = NULL

	IF @ACTIVITY_NAME_TMP = '~#~'
		SELECT @ACTIVITY_NAME_TMP = NULL

	IF @UI_NAME_TMP = '~#~'
		SELECT @UI_NAME_TMP = NULL

	IF @PAGE_BT_SYNONYM_TMP = '~#~'
		SELECT @PAGE_BT_SYNONYM_TMP = NULL

	IF @SECTION_BT_SYNONYM_TMP = '~#~'
		SELECT @SECTION_BT_SYNONYM_TMP = NULL

	IF @VISISBLE_FLAG_TMP = '~#~'
		SELECT @VISISBLE_FLAG_TMP = NULL

	IF @TITLE_REQUIRED_TMP = '~#~'
		SELECT @TITLE_REQUIRED_TMP = NULL

	IF @BORDER_REQUIRED_TMP = '~#~'
		SELECT @BORDER_REQUIRED_TMP = NULL

	IF @TITLE_ALIGNMENT_TMP = '~#~'
		SELECT @TITLE_ALIGNMENT_TMP = NULL

	IF @PARENT_SECTION_TMP = '~#~'
		SELECT @PARENT_SECTION_TMP = NULL

	IF @HORDER_TMP = - 915
		SELECT @HORDER_TMP = NULL

	IF @VORDER_TMP = - 915
		SELECT @VORDER_TMP = NULL

	IF @SECTION_DOC_TMP = '~#~'
		SELECT @SECTION_DOC_TMP = NULL

	IF @UI_SECTION_SYSID_TMP = '~#~'
		SELECT @UI_SECTION_SYSID_TMP = NULL

	IF @PAGE_SYSID_TMP = '~#~'
		SELECT @PAGE_SYSID_TMP = NULL

	IF @TIMESTAMP_TMP = - 915
		SELECT @TIMESTAMP_TMP = NULL

	IF @SECTION_TYPE_TMP = '~#~'
		SELECT @SECTION_TYPE_TMP = NULL

	IF @rowspan_tmp = - 915
		SELECT @section_rowspan = NULL

	IF @colspan_tmp = - 915
		SELECT @section_colspan = NULL

	IF @engg_sec_bottomtb = - 915
		SELECT @engg_sec_bottomtb = NULL

	IF @engg_sec_toptb = - 915
		SELECT @engg_sec_toptb = NULL

	IF @engg_sec_righttb = - 915
		SELECT @engg_sec_righttb = NULL

	IF @engg_sec_lefttb = - 915
		SELECT @engg_sec_lefttb = NULL

	IF @engg_sec_minrows = - 915
		SELECT @engg_sec_minrows = NULL

	IF @engg_sec_vwmode = '~#~'
		SELECT @engg_sec_vwmode = NULL

	IF @engg_sec_titleicon = '~#~'
		SELECT @engg_sec_titleicon = NULL

	--IF @isstatic_tmp = '~#~' 
	--	Select @isstatic = null  
	/********************************************************************************/
	/*                   ASSIGNMENT OF DEFAULT DATA                                 */
	/********************************************************************************/
	SELECT @DUPCOUNT_TMP = 0,
		@ERRORNO_TMP = 0,
		@SPERROR = 0,
		@M_ERRORID = 0

	SELECT @VISISBLE_FLAG_TMP = ISNULL(@VISISBLE_FLAG_TMP, 'Y'),
		@TITLE_REQUIRED_TMP = ISNULL(@TITLE_REQUIRED_TMP, 'N'),
		@BORDER_REQUIRED_TMP = ISNULL(@BORDER_REQUIRED_TMP, 'Y'),
		@TITLE_ALIGNMENT_TMP = ISNULL(@TITLE_ALIGNMENT_TMP, 'LEFT')

	--@isstatic_tmp										   =	 ISNULL(@isstatic_tmp,'N')
	/*
	if @isstatic_tmp = 1
		set @isstatic_tmp = 'y'
	else
		set @isstatic_tmp = 'n' */
	/********************************************************************************/
	/*                   NULL CHECK VALIDATION                                      */
	/********************************************************************************/
	/*                   NULL CHECK FOR COLUMN CUSTOMER_NAME                       */
	BEGIN
		IF ISNULL(@CUSTOMER_NAME_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = 'ENTER VALUE FOR COLUMN : CUSTOMER NAME'

			EXEC ENGG_ERROR_SP 'EP_UI_SECTION_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN @M_ERRORID
		END
	END

	/*                   NULL CHECK FOR COLUMN PROJECT_NAME                       */
	BEGIN
		IF ISNULL(@PROJECT_NAME_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = 'ENTER VALUE FOR COLUMN : PROJECT NAME'

			EXEC ENGG_ERROR_SP 'EP_UI_SECTION_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN @M_ERRORID
		END
	END

	/*                   NULL CHECK FOR COLUMN REQ_NO                       */
	BEGIN
		IF ISNULL(@REQ_NO_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = 'ENTER VALUE FOR COLUMN : REQUEST NUMBER'

			EXEC ENGG_ERROR_SP 'EP_UI_SECTION_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN @M_ERRORID
		END
	END

	/*                   NULL CHECK FOR COLUMN PROCESS_NAME                       */
	BEGIN
		IF ISNULL(@PROCESS_NAME_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = 'ENTER VALUE FOR COLUMN : PROCESS NAME'

			EXEC ENGG_ERROR_SP 'EP_UI_SECTION_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN @M_ERRORID
		END
	END

	/*       NULL CHECK FOR COLUMN COMPONENT_NAME                       */
	BEGIN
		IF ISNULL(@COMPONENT_NAME_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = 'ENTER VALUE FOR COLUMN : COMPONENT NAME'

			EXEC ENGG_ERROR_SP 'EP_UI_SECTION_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN @M_ERRORID
		END
	END

	/*                   NULL CHECK FOR COLUMN ACTIVITY_NAME                       */
	BEGIN
		IF ISNULL(@ACTIVITY_NAME_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = 'ENTER VALUE FOR COLUMN : ACTIVITY NAME'

			EXEC ENGG_ERROR_SP 'EP_UI_SECTION_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN @M_ERRORID
		END
	END

	/*                   NULL CHECK FOR COLUMN UI_NAME                       */
	BEGIN
		IF ISNULL(@UI_NAME_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = 'ENTER VALUE FOR COLUMN : USER INTERFACE NAME'

			EXEC ENGG_ERROR_SP 'EP_UI_SECTION_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN @M_ERRORID
		END
	END

	/*                   NULL CHECK FOR COLUMN PAGE_BT_SYNONYM                       */
	BEGIN
		IF ISNULL(@PAGE_BT_SYNONYM_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = 'ENTER VALUE FOR COLUMN : PAGE BT SYNONYM'

			EXEC ENGG_ERROR_SP 'EP_UI_SECTION_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN @M_ERRORID
		END
	END

	/*                   NULL CHECK FOR COLUMN SECTION_BT_SYNONYM                       */
	BEGIN
		IF ISNULL(@SECTION_BT_SYNONYM_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = 'ENTER VALUE FOR COLUMN : SECTION BT SYNONYM'

			EXEC ENGG_ERROR_SP 'EP_UI_SECTION_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN @M_ERRORID
		END
	END

	/*                   NULL CHECK FOR COLUMN VISISBLE_FLAG                       */
	BEGIN
		IF ISNULL(@VISISBLE_FLAG_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = 'ENTER VALUE FOR COLUMN : VISIBLE'

			EXEC ENGG_ERROR_SP 'EP_UI_SECTION_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN @M_ERRORID
		END
	END

	/*                   NULL CHECK FOR COLUMN TITLE_REQUIRED                       */
	BEGIN
		IF ISNULL(@TITLE_REQUIRED_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = 'ENTER VALUE FOR COLUMN : TITLE REQUIRED'

			EXEC ENGG_ERROR_SP 'EP_UI_SECTION_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN @M_ERRORID
		END
	END

	/*                   NULL CHECK FOR COLUMN BORDER_REQUIRED                       */
	BEGIN
		IF ISNULL(@BORDER_REQUIRED_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = 'ENTER VALUE FOR COLUMN : BORDER REQUIRED'

			EXEC ENGG_ERROR_SP 'EP_UI_SECTION_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN @M_ERRORID
		END
	END

	/*                   NULL CHECK FOR COLUMN TITLE_ALIGNMENT                       */
	BEGIN
		IF ISNULL(@TITLE_ALIGNMENT_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = 'ENTER VALUE FOR COLUMN : TITLE ALIGNMENT'

			EXEC ENGG_ERROR_SP 'EP_UI_SECTION_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN @M_ERRORID
		END
	END

	/*                   NULL CHECK FOR COLUMN PARENT_SECTION  */
	BEGIN
		IF ISNULL(@PARENT_SECTION_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = 'ENTER VALUE FOR COLUMN : PARENT SECTION'

			EXEC ENGG_ERROR_SP 'EP_UI_SECTION_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN @M_ERRORID
		END
	END

	/*                   NULL CHECK FOR COLUMN HORDER                       */
	BEGIN
		IF ISNULL(@HORDER_TMP, - 915) = - 915
		BEGIN
			SELECT @ERRORMESSAGE_TMP = 'ENTER VALUE FOR COLUMN : HORIZONTAL ORDER'

			EXEC ENGG_ERROR_SP 'EP_UI_SECTION_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN @M_ERRORID
		END
	END

	/*                   NULL CHECK FOR COLUMN VORDER                       */
	BEGIN
		IF ISNULL(@VORDER_TMP, - 915) = - 915
		BEGIN
			SELECT @ERRORMESSAGE_TMP = 'ENTER VALUE FOR COLUMN : VERTICAL ORDER'

			EXEC ENGG_ERROR_SP 'EP_UI_SECTION_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN @M_ERRORID
		END
	END

	/********************************************************************************/
	/*                   PRIMARY KEY VIOLATION CHECK                                */
	/********************************************************************************/
	/* VALUES FOR COLUMNS CUSTOMER NAME,PROJECT NAME,REQUEST NUMBER,PROCESS NAME,COMPONENT NAME,ACTIVITY NAME,USER INTERFACE NAME,PAGE BT SYNONYM,SECTION BT SYNONYM IN  UI SECTIONS CANNOT  BE REPEATED */
	BEGIN
		IF EXISTS (
				SELECT 1
				FROM EP_UI_SECTION_DTL
				WHERE CUSTOMER_NAME = @CUSTOMER_NAME_TMP
					AND PROJECT_NAME = @PROJECT_NAME_TMP
					AND REQ_NO = @REQ_NO_TMP
					AND PROCESS_NAME = @PROCESS_NAME_TMP
					AND COMPONENT_NAME = @COMPONENT_NAME_TMP
					AND ACTIVITY_NAME = @ACTIVITY_NAME_TMP
					AND UI_NAME = @UI_NAME_TMP
					AND PAGE_BT_SYNONYM = @PAGE_BT_SYNONYM_TMP
					AND SECTION_BT_SYNONYM = @SECTION_BT_SYNONYM_TMP
					AND ISNULL(horder,0) <> 601  --TECH-70687
				)
		BEGIN
			SELECT @ERRORMESSAGE_TMP = 'VALUES FOR COLUMNS CUSTOMER NAME,PROJECT NAME,REQUEST NUMBER,PROCESS NAME,COMPONENT NAME,ACTIVITY NAME,USER INTERFACE NAME,PAGE BT SYNONYM,SECTION BT SYNONYM IN  UI SECTIONS CANNOT  BE REPEATED'

			EXEC ENGG_ERROR_SP 'EP_UI_SECTION_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN
		END
	END

	/********************************************************************************/
	/*                   CHECK FOR FORIEGN KEY VIOLATION                            */
	/********************************************************************************/
	/* VALUES CANNOT ADDED IN  EP_UI_SECTION_DTL AS DATA DOES NOT EXISTS FOR THE MASTER  EP_UI_PAGE_DTL*/
	BEGIN
		IF NOT EXISTS (
				SELECT 1
				FROM EP_UI_PAGE_DTL
				WHERE CUSTOMER_NAME = @CUSTOMER_NAME_TMP
					AND PROJECT_NAME = @PROJECT_NAME_TMP
					AND REQ_NO = @REQ_NO_TMP
					AND PROCESS_NAME = @PROCESS_NAME_TMP
					AND COMPONENT_NAME = @COMPONENT_NAME_TMP
					AND ACTIVITY_NAME = @ACTIVITY_NAME_TMP
					AND UI_NAME = @UI_NAME_TMP
					AND PAGE_BT_SYNONYM = @PAGE_BT_SYNONYM_TMP
				)
		BEGIN
			SELECT @ERRORMESSAGE_TMP = 'COLUMNS CUSTOMER NAME,PROJECT NAME,REQUEST NUMBER,PROCESS NAME,COMPONENT NAME,ACTIVITY NAME,USER INTERFACE NAME,PAGE BT SYNONYM,SECTION BT SYNONYMCUSTOMER_NAME,PROJECT_NAME,REQ_NO,
												PROCESS_NAME,COMPONENT_NAME,ACTIVITY_NAME,UI_NAME,PAGE_BT_SYNONYM OF TABLE UI PAGES HAS REFERENCE TO TABLE UI SECTIONS'

			EXEC ENGG_ERROR_SP 'EP_UI_SECTION_DTL_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN
		END
	END

	/********************************************************************************/
	/*                   INSERT DATA INTO THE TABLE    EP_UI_SECTION_DTL            */
	/********************************************************************************/
	BEGIN
		EXEC ENGG_GET_NEWSYSID 'EP_UI_SECTION_DTL',
			@UI_SECTION_SYSID_TMP OUTPUT

		SELECT @PAGE_SYSID_TMP = DBO.EP_GET_PAGE_SYSID(@CTXT_LANGUAGE_TMP, @CTXT_OUINSTANCE_TMP, @CTXT_SERVICE_TMP, @CTXT_USER_TMP, @CUSTOMER_NAME_TMP, @PROJECT_NAME_TMP, @REQ_NO_TMP, @PROCESS_NAME_TMP, @COMPONENT_NAME_TMP, @ACTIVITY_NAME_TMP, @UI_NAME_TMP, @PAGE_BT_SYNONYM_TMP)

		-- Ngplf Starts
		DECLARE @IsPlatform engg_flag

		SET @IsPlatform = 'N'

		IF EXISTS (
				SELECT 'X'
				FROM ep_ui_mst(NOLOCK)
				WHERE customer_name = @CUSTOMER_NAME_TMP
					AND project_name = @PROJECT_NAME_TMP
					AND process_name = @PROCESS_NAME_TMP
					AND component_name = @COMPONENT_NAME_TMP
					AND activity_name = @ACTIVITY_NAME_TMP
					AND ui_name = @UI_NAME_TMP
					AND isnull(IsGlance, 'N') = 'Y'
				)
						BEGIN
			SET @IsPlatform = 'Y'

			SELECT @HORDER_TMP = isnull(max(horder), 0) + 1,
				@VORDER_TMP = isnull(max(vorder), 0) + 1
			FROM ep_ui_section_dtl(NOLOCK)
			WHERE customer_name = @CUSTOMER_NAME_TMP
				AND project_name = @PROJECT_NAME_TMP
				AND process_name = @PROCESS_NAME_TMP
				AND component_name = @COMPONENT_NAME_TMP
				AND activity_name = @ACTIVITY_NAME_TMP
				AND ui_name = @UI_NAME_TMP
				AND isnull(IsPlatform, 'N') = 'Y'

			IF isnull(@HORDER_TMP, 0) = 1
			BEGIN
				SET @HORDER_TMP = 1000
				SET @VORDER_TMP = 1000
			END
		END

		-- Ngplf Ends

		--TECH-70687	
		IF NOT EXISTS
		(SELECT 'X'
		FROM EP_UI_SECTION_DTL WITH (NOLOCK)
		WHERE CUSTOMER_NAME		 =  @CUSTOMER_NAME_TMP
		AND	  PROJECT_NAME		 =  @PROJECT_NAME_TMP
		AND	  req_no			 = @REQ_NO_TMP
		AND	  PROCESS_NAME		 = @PROCESS_NAME_TMP
		AND   COMPONENT_NAME	 = @COMPONENT_NAME_TMP
		AND	  ACTIVITY_NAME		 = @ACTIVITY_NAME_TMP
		AND   UI_NAME			 = @UI_NAME_TMP
		AND   page_bt_synonym	 =	@PAGE_BT_SYNONYM_TMP
		AND   section_bt_synonym =  @SECTION_BT_SYNONYM_TMP
		)
		--TECH-70687
		BEGIN
		INSERT INTO EP_UI_SECTION_DTL (
			CUSTOMER_NAME,
			PROJECT_NAME,
			REQ_NO,
			PROCESS_NAME,
			COMPONENT_NAME,
			ACTIVITY_NAME,
			UI_NAME,
			PAGE_BT_SYNONYM,
			SECTION_BT_SYNONYM,
			VISISBLE_FLAG,
			TITLE_REQUIRED,
			BORDER_REQUIRED,
			TITLE_ALIGNMENT,
			PARENT_SECTION,
			HORDER,
			VORDER,
			SECTION_DOC,
			UI_SECTION_SYSID,
			PAGE_SYSID,
			CREATEDBY,
			CREATEDDATE,
			MODIFIEDBY,
			MODIFIEDDATE,
			TIMESTAMP,
			SECTION_TYPE,
			ctrl_caption_align,
			caption_Format,
			height,
			width,
			Section_width_Scalemode,
			Section_height_Scalemode,
			wrkreqno,
			section_collapsemode,
			section_collapse,
			NColSpan,
			NRowSpan /*,
			IsStatic*/ --chan shakthi
			,
			Region, --- PLF2.0_17570  
			TitlePosition,
			CollapseDir,
			SectionLayout,
			XYCoordinates,
			ColumnLayWidth,
			Associated_Control,
			IsResponsive, --13639
			mob_pop_fullview,--13639
			IsPlatform,
			ForResponsive,	--Code added for TECH-69624
			Orientation,	--Code Added for TECH-75230
			--TECH-70687
			LeftToolbar,
			RightToolbar,
			TopToolbar,
			BottomToolbar,
			MinimizedRows,
			ViewMode,
			--TECH-70687
			TitleIcon	--TECH-72114
			)
		VALUES (
			@CUSTOMER_NAME_TMP,
			@PROJECT_NAME_TMP,
			@REQ_NO_TMP,
			@PROCESS_NAME_TMP,
			@COMPONENT_NAME_TMP,
			@ACTIVITY_NAME_TMP,
			@UI_NAME_TMP,
			@PAGE_BT_SYNONYM_TMP,
			@SECTION_BT_SYNONYM_TMP,
			@VISISBLE_FLAG_TMP,
			@TITLE_REQUIRED_TMP,
			@BORDER_REQUIRED_TMP,
			@TITLE_ALIGNMENT_TMP,
			@PARENT_SECTION_TMP,
			@HORDER_TMP,
			@VORDER_TMP,
			@SECTION_DOC_TMP,
			@UI_SECTION_SYSID_TMP,
			@PAGE_SYSID_TMP,
			@CTXT_USER_TMP,
			GETDATE(),
			@CTXT_USER_TMP,
			GETDATE(),
			@TIMESTAMP_TMP,
			@SECTION_TYPE_TMP,
			@engg_sec_cap_align,
			@engg_sec_cap_format,
			@sectionheight,
			@sectionwidth,
			@Section_width_Scalemode,
			@Section_height_Scalemode,
			@engg_req_no,
			@Sec_CollapseMode,
			@Sec_Collapse,
			@colspan_tmp,
			@rowspan_tmp /*,
			@isstatic_tmp*/ --chan
			,
			@Region, --- PLF2.0_17570  
			@TitlePosition,
			@CollapseDir,
			@SectionLayout,
			@XYCoordinates,
			@ColumnLayWidth,
			@engg_associatedcontrol,
			---code added by 13639 starts
		  CASE WHEN @engg_mob_responsive = '1' THEN 'Y'
												WHEN @engg_mob_responsive = '0' THEN 'N'
											END,
						   CASE WHEN @engg_mob_fullview = '1' THEN 'Y'
												WHEN @engg_mob_fullview = '0' THEN 'N'
												end,
			--code added by 13639 ends
			@IsPlatform,
			@engg_sect_forresponsive,	--Code added for TECH-69624
			@Orientation,				--Code Added for TECH-75230
			--TECH-70687
			 CASE WHEN @engg_sec_lefttb  = 1 THEN 'Y' ELSE NULL END,
			 CASE WHEN @engg_sec_righttb = 1 THEN 'Y' ELSE NULL END,
			 CASE WHEN @engg_sec_toptb	 = 1 THEN 'Y' ELSE NULL END,
			 CASE WHEN @engg_sec_bottomtb = 1 THEN 'Y' ELSE NULL END,
			 @engg_sec_minrows,
			 @engg_sec_vwmode,
			--TECH-70687
			@engg_sec_titleicon  --TECH-72114
			)
		END
	END
END
GO

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'EP_UI_SECTION_DTL_SP_INS' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON EP_UI_SECTION_DTL_SP_INS TO PUBLIC
END
GO