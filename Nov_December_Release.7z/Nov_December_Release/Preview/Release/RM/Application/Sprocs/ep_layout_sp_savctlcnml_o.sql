IF EXISTS  (SELECT 'X' FROM SYSOBJECTS WHERE NAME ='ep_layout_sp_savctlcnml_o' AND TYPE = 'P')
    BEGIN
        DROP PROC ep_layout_sp_savctlcnml_o
    END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		ep_layout_sp_savctlcnml_o.sql
********************************************************************************/
/********************************************************************************/
/* Procedure    : ep_layout_sp_savctlcnml_o                                     */
/* Description  :                                                               */
/********************************************************************************/
/* Project      :                                                               */
/* ECR          :                                                               */
/* Version      :                                                               */
/********************************************************************************/
/* Referenced   :                                                               */
/* Tables       :                                                               */
/********************************************************************************/
/* Development history                                                          */
/********************************************************************************/
/* Author       : ModelExplorer                                                 */
/* Date         : 22/Sep/2005                                                   */
/********************************************************************************/
/* Modification history                                                         */
/********************************************************************************/
/* modified by  : Sivakumar S For BugId : PNR2.0_14785         */
/* date         : 03-AUG-2007                */
/* description  :   In Section Layout tab,Controls Order sequence needs to be changed.*/
/***************************************************************************************************/
/* modified by  : Ganesh Prabhu S                                      						       */
/* date         : Oct 10 2014                                      							       */
/* BugId        : PLF2.0_09035                                          						   */
/* description  : Model changes for rowspan,colspan,IsStatic,IsCallout in  layout level            */
/***************************************************************************************************/
/* Modified by  : Veena U                                                  */
/* Date         : 25-Feb-2015                                                  */
/* Call ID		: PLF2.0_11499                                                 */
/********************************************************************************/
/* Modified by  : Kalidas S	                                                  */
/* Date         : 03-Aug-2015                                                  */
/* Defect ID	: PLF2.0_14096                                                 */
/********************************************************************************/
/* modified by					Date				Defect ID					*/
/* Veena U						08-Jun-2016			PLF2.0_18487				*/
/* Modified by : Jeya Latha K   Date: 25-Jul-2019   Defect ID: TECH-36371	    */
/* Modified by : Rajeswari M/Priyadharshini U Date: 28-Jul-2021  Defect ID : TECH-60451    */
/* TECH-60451  : Launching Help&Link UIs, Popup sections and Grid Extensions in Side Drawer*/
/* TECH-63527  : Associate Control added in ep_ui_control_dtl for Multiselectcombo*/ 
/********************************************************************************/
/* Modified by	:	VimalKumar R 												*/
/* Modified on	:	08/06/22				 									*/
/* Defect ID	:	TECH-69624													*/
/* Description	:	Custom border, Custom actions and Responsive layout			*/
/********************************************************************************/
/* Modified by	:	Ponmalar A		 											*/
/* Modified on	:	08/07/2022				 									*/
/* Defect ID	:	Tech-70687													*/
/* Description	:	Tool and Toolbars											*/
/********************************************************************************/
/* Modified by	:	Priyadharshini U		 									*/
/* Modified on	:	22/08/2022				 									*/
/* Defect ID	:	TECH-72114													*/
/********************************************************************************/
/* Modified by    :    Ponmalar A                                               */
/* Modified on    :    02/12/22													*/
/* Defect ID      :    TECH-75230												*/
/* Description    : Platform Release for the Month of Nov'22				    */
/********************************************************************************/
CREATE PROCEDURE ep_layout_sp_savctlcnml_o
	@ctxt_language engg_ctxt_language, --Input   
	@ctxt_ouinstance engg_ctxt_ouinstance, --Input   
	@ctxt_service engg_ctxt_service, --Input   
	@ctxt_user engg_ctxt_user, --Input   
	@engg_act_descr engg_description, --Input   
	@engg_component engg_description, --Input   
	@engg_cont_page_bts engg_name, --Input   
	@engg_cont_sec_bts engg_name, --Input   
	@engg_customer_name engg_name, --Input   
	@engg_enum_page_bts engg_name, --Input   
	@engg_enum_sec_bts engg_name, --Input   
	@engg_grid_page_bts engg_name, --Input   
	@engg_grid_sec_bts engg_name, --Input   
	@engg_lnk_page_descr engg_description, --Input   
	@engg_process_descr engg_description, --Input   
	@engg_project_name engg_name, --Input   
	@engg_radio_page_bts engg_name, --Input   
	@engg_radio_sec_bts engg_name, --Input   
	@engg_req_no engg_name, --Input   
	@engg_ui_descr engg_description, --Input   
	@guid engg_guid, --Input   
	@m_errorid Engg_Seqno OUTPUT --To Return Execution Status   
AS
BEGIN
	-- nocount should be switched on to prevent phantom rows  
	SET NOCOUNT ON
	-- @m_errorid should be 0 to Indicate Success  
	SET @m_errorid = 0
	--declaration of temporary variables  
	--temporary and formal parameters mapping  
	SET @ctxt_service = ltrim(rtrim(@ctxt_service))
	SET @ctxt_user = ltrim(rtrim(@ctxt_user))
	SET @engg_act_descr = ltrim(rtrim(@engg_act_descr))
	SET @engg_component = ltrim(rtrim(@engg_component))
	SET @engg_cont_page_bts = ltrim(rtrim(@engg_cont_page_bts))
	SET @engg_cont_sec_bts = ltrim(rtrim(@engg_cont_sec_bts))
	SET @engg_customer_name = ltrim(rtrim(@engg_customer_name))
	SET @engg_enum_page_bts = ltrim(rtrim(@engg_enum_page_bts))
	SET @engg_enum_sec_bts = ltrim(rtrim(@engg_enum_sec_bts))
	SET @engg_grid_page_bts = ltrim(rtrim(@engg_grid_page_bts))
	SET @engg_grid_sec_bts = ltrim(rtrim(@engg_grid_sec_bts))
	SET @engg_lnk_page_descr = ltrim(rtrim(@engg_lnk_page_descr))
	SET @engg_process_descr = ltrim(rtrim(@engg_process_descr))
	SET @engg_project_name = ltrim(rtrim(@engg_project_name))
	SET @engg_radio_page_bts = ltrim(rtrim(@engg_radio_page_bts))
	SET @engg_radio_sec_bts = ltrim(rtrim(@engg_radio_sec_bts))
	SET @engg_req_no = ltrim(rtrim(@engg_req_no))
	SET @engg_ui_descr = ltrim(rtrim(@engg_ui_descr))
	SET @guid = ltrim(rtrim(@guid))

	--null checking  
	IF @ctxt_language = - 915
		SET @ctxt_language = NULL

	IF @ctxt_ouinstance = - 915
		SET @ctxt_ouinstance = NULL

	IF @ctxt_service = '~#~'
		SET @ctxt_service = NULL

	IF @ctxt_user = '~#~'
		SET @ctxt_user = NULL

	IF @engg_act_descr = '~#~'
		SET @engg_act_descr = NULL

	IF @engg_component = '~#~'
		SET @engg_component = NULL

	IF @engg_cont_page_bts = '~#~'
		SET @engg_cont_page_bts = NULL

	IF @engg_cont_sec_bts = '~#~'
		SET @engg_cont_sec_bts = NULL

	IF @engg_customer_name = '~#~'
		SET @engg_customer_name = NULL

	IF @engg_enum_page_bts = '~#~'
		SET @engg_enum_page_bts = NULL

	IF @engg_enum_sec_bts = '~#~'
		SET @engg_enum_sec_bts = NULL

	IF @engg_grid_page_bts = '~#~'
		SET @engg_grid_page_bts = NULL

	IF @engg_grid_sec_bts = '~#~'
		SET @engg_grid_sec_bts = NULL

	IF @engg_lnk_page_descr = '~#~'
		SET @engg_lnk_page_descr = NULL

	IF @engg_process_descr = '~#~'
		SET @engg_process_descr = NULL

	IF @engg_project_name = '~#~'
		SET @engg_project_name = NULL

	IF @engg_radio_page_bts = '~#~'
		SET @engg_radio_page_bts = NULL

	IF @engg_radio_sec_bts = '~#~'
		SET @engg_radio_sec_bts = NULL

	IF @engg_req_no = '~#~'
		SET @engg_req_no = NULL

	IF @engg_ui_descr = '~#~'
		SET @engg_ui_descr = NULL

	IF @guid = '~#~'
		SET @guid = NULL

	/*   
 --OuputList  
 Select null 'engg_cont_btsynname',   
 null 'engg_cont_datawidth',   
 null 'engg_cont_descr',   
 null 'engg_cont_doc',   
 null 'engg_cont_elem_type',   
 null 'engg_cont_horder',   
 null 'engg_cont_labwidth',   
 null 'engg_cont_samp_data',   
 null 'engg_cont_sequence',   
 null 'engg_cont_tooltip',   
 null 'engg_cont_vis_length',   
 null 'engg_cont_vorder',   
 null 'engg_label_class',   
 null 'engg_control_class',   
 null 'engg_label_image_class',   
 null 'engg_control_image_class',   
 null 'engg_tab_sequence',   
 null 'engg_tab_stopforhelp' from ***   
*/
	DECLARE @msg engg_description,
		@tmp_comp_name engg_name,
		@tmp_proc engg_name,
		@tmp_acty_name engg_name,
		@tmp_ui_name engg_name,
		@engg_base_req_no engg_name

	SELECT @engg_base_req_no = 'BASE'

	--select process name for description      
	SELECT @tmp_proc = rtrim(process_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_req_no)
		AND process_descr = rtrim(@engg_process_descr)

	--select component name for description      
	SELECT @tmp_comp_name = rtrim(component_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_descr = rtrim(@engg_component)

	--select activity name for description      
	SELECT @tmp_acty_name = rtrim(activity_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp_name)
		AND activity_descr = rtrim(@engg_act_descr)

	--select ui name for description      
	SELECT @tmp_ui_name = rtrim(ui_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp_name)
		AND activity_name = rtrim(@tmp_acty_name)
		AND ui_descr = rtrim(@engg_ui_descr)

	--errors mapped        
	/*  
fetch the control details for the selected activity/ui and display in the multiline  
*/
	SELECT rtrim(control_bt_synonym) 'engg_cont_btsynname',
		--  rtrim(data_column_width) + rtrim(data_column_scalemode) 'engg_cont_datawidth',  
		rtrim(data_column_width) 'engg_cont_datawidth',
		rtrim(b.bt_synonym_caption) 'engg_cont_descr',
		rtrim(control_doc) 'engg_cont_doc',
		rtrim(control_type) 'engg_cont_elem_type',
		rtrim(horder) 'engg_cont_horder',
		rtrim(label_column_width) 'engg_cont_labwidth',
		rtrim(sample_data) 'engg_cont_samp_data',
		rtrim(order_seq) 'engg_cont_sequence',
		rtrim(proto_tooltip) 'engg_cont_tooltip',
		rtrim(visisble_length) 'engg_cont_vis_length',
		rtrim(vorder) 'engg_cont_vorder',
		LabelClass 'engg_label_class',
		ControlClass 'engg_control_class',
		LabelImageClass 'engg_label_image_class',
		ControlImageClass 'engg_control_image_class',
		a.TemplateID 'engg_cont_tempid', -- Added for PLF2.0_14096
		tab_seq 'engg_tab_sequence',
		CASE help_tabstop
			WHEN 'Y'
				THEN '1'
			WHEN 'N'
				THEN '0'
			END 'engg_tab_stopforhelp',
		--Code modification  for  PNR2.0_23541 starts  
		CASE isnull(a.Set_User_Pref, '')
			WHEN 'N'
				THEN '1'
			ELSE '0'
			END 'set_user_pref',
		isnull(freezecount, 0) 'freezecount', --added for PNR2.0_26860  
		a.controlimage 'Engg_cont_Ctrlimg',
		a.rowspan 'Engg_cont_rowspan',
		a.colspan 'Engg_cont_colspan',
		parameter_text 'ctrl_temp_cat',
		TemplateSpecific 'ctrl_temp_specific',
		AssociateControl 'engg_MSC_Ass_control',--code added for TECH-63527
		--Code modification  for  PNR2.0_23541 ends
		--Code added by Ranjitha
		AccessKey 'AccessKey',
		Icon_class 'Icon_class',
		Icon_position 'Icon_position',
		Control_class_ext6 'Cont_class_ext6',
		CASE 
			WHEN dynamicStyle = 'y'
				THEN '1'
			ELSE '0'
			END 'engg_dynamicStyle',
		CASE 
			WHEN imageasdata = 'y'
				THEN '1'
			ELSE '0'
			END 'engg_ImageAsData',	--Code ends  
		CASE 
			WHEN  ExtensionReqd	= 'Yes'
			  THEN '1'
			ELSE '0'
			END			'engg_extnreqd',   ---Code added for TECH-60451
		'...'			'engg_extension',    ---Code added for TECH-60451
		--Code Added for TECH-69624 Starts
		ISNULL(a.ForResponsive,'')	'Engg_cont_forresponsive',
		'...'						'engg_cont_customborder',
		'...'						'engg_cont_customaction',
		--Code Added for TECH-69624 ends
		CASE WHEN ControlFormat	= 'Bes' THEN 'Controls Beside Captions'
			 WHEN ControlFormat = 'Top'	THEN 'Top Inner' ELSE '' END 'engg_cont_control_format',	--Code Added for the Defect Id TECH-72114
		ISNULL(a.ButtonNature,'')	'ButtonNature',		--Code added for TECH-75230
		ISNULL(a.InlineStyle,'')	'InlineStyle'		--Code added for TECH-75230
	FROM ep_component_glossary_mst b(NOLOCK)
	RIGHT JOIN ep_ui_control_dtl a(NOLOCK) ON b.customer_name = a.customer_name
		AND b.project_name = a.project_name
		AND b.req_no = a.req_no
		AND b.process_name = a.process_name
		AND b.component_name = a.component_name
		AND b.bt_synonym_name = a.control_bt_synonym
	LEFT JOIN ep_device_quick_code_met c(NOLOCK) ON a.TemplateCategory = c.parameter_code
		AND parameter_type = 'TemplateCategory'
	WHERE a.customer_name = rtrim(@engg_customer_name)
		AND a.project_name = rtrim(@engg_project_name)
		AND a.req_no = rtrim(@engg_base_req_no)
		AND a.process_name = rtrim(@tmp_proc)
		AND a.component_name = rtrim(@tmp_comp_name)
		AND a.activity_name = rtrim(@tmp_acty_name)
		AND a.ui_name = rtrim(@tmp_ui_name)
		AND a.page_bt_synonym = rtrim(@engg_cont_page_bts)
		AND a.section_bt_synonym = rtrim(@engg_cont_sec_bts)
		AND a.horder NOT IN (501,601) --Tech-70687
	--  and   b.customer_name   =*  a.customer_name  
	--  and   b.project_name   =*  a.project_name  
	--  and   b.req_no     =*  a.req_no  
	--  and   b.process_name   =*  a.process_name  
	--  and   b.component_name  =*  a.component_name  
	--  and   b.bt_synonym_name  =*  a.control_bt_synonym  
	ORDER BY horder,
		vorder,
		order_seq

	/* 
	--OutputList
		Select
		null 'engg_cont_btsynname', 
		null 'engg_cont_datawidth', 
		null 'engg_cont_descr', 
		null 'engg_cont_doc', 
		null 'engg_cont_elem_type', 
		null 'engg_cont_horder', 
		null 'engg_cont_labwidth', 
		null 'engg_cont_samp_data', 
		null 'engg_cont_sequence', 
		null 'engg_cont_tooltip', 
		null 'engg_cont_vis_length', 
		null 'engg_cont_vorder', 
		null 'engg_label_class', 
		null 'engg_control_class', 
		null 'engg_label_image_class', 
		null 'engg_control_image_class', 
		null 'engg_tab_sequence', 
		null 'engg_tab_stopforhelp', 
		null 'engg_cont_rowspan', 
		null 'engg_cont_colspan', 
		null 'engg_cont_ctrlimg', 
		null 'set_user_pref', 
		null 'freezecount'
		null 'engg_cont_tempid', 
		null 'engg_extnreqd',
		null 'engg_extension,
		null 'engg_MSC_Ass_control',

	*/
	SET NOCOUNT OFF
END
GO

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_layout_sp_savctlcnml_o' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON ep_layout_sp_savctlcnml_o TO PUBLIC
END
GO
