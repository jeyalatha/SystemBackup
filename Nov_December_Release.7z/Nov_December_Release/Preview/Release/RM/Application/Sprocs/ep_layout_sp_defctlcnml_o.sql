IF EXISTS  (SELECT 'X' FROM SYSOBJECTS WHERE NAME ='ep_layout_sp_defctlcnml_o' AND TYPE = 'P')
    BEGIN
        DROP PROC ep_layout_sp_defctlcnml_o
    END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		ep_layout_sp_defctlcnml_o.sql
********************************************************************************/
/*      V E R S I O N      :  2 . 0 . 4    */
/*      Released By        :  PTech    */
/*      Release Comments   :  Released on 07 - Jan -05 (Patch Release 1)    */
/*      V E R S I O N      :  2.0.2    */
/*      Released By        :  PTech    */
/*      Release Comments   :  Released on  22-Jan-2004    */
/********************************************************************************/
/* procedure      ep_layout_sp_defctlcnml_o                                     */
/* description                                                                  */
/********************************************************************************/
/* project        Preview                                                       */
/* version                                                                      */
/********************************************************************************/
/* referenced                                                                   */
/* tables                                                                       */
/********************************************************************************/
/* development history                                                          */
/********************************************************************************/
/* author         Shafina Begum.B                                               */
/* date           1/ 12/ 2003                                                   */
/********************************************************************************/
/* modification history                                                         */
/********************************************************************************/
/* modified by                                                                  */
/* date                                                                         */
/* description                                                                  */
/********************************************************************************/
/* Modified by  : Kalidas S	                                                  */
/* Date         : 03-Aug-2015                                                  */
/* Defect ID	: PLF2.0_14096                                                 */
/********************************************************************************/
/* modified by					Date				Defect ID				    */
/* Veena U						08-Jun-2016			PLF2.0_18487				*/
/* Modified by : Jeya Latha K   Date: 25-Jul-2019   Defect ID: TECH-36371		*/
/* Modified by : Rajeswari M/Priyadharshini U Date: 28-Jul-2021  Defect ID : TECH-60451    */
/* TECH-60451  : Launching Help&Link UIs, Popup sections and Grid Extensions in Side Drawer*/
/* TECH-63527  : Associate Control added in ep_ui_control_dtl for Multiselectcombo*/ 
/********************************************************************************/
/* Modified by	:	VimalKumar R 												*/
/* Modified on	:	08/06/22				 									*/
/* Defect ID	:	TECH-69624													*/
/* Description	:	Custom border, Custom actions and Responsive layout			*/
/********************************************************************************/
/* Modified by	:	Ponmalar A		 											*/
/* Modified on	:	08/07/2022				 									*/
/* Defect ID	:	Tech-70687													*/
/* Description	:	Tool and Toolbars											*/
/********************************************************************************/
/* Modified by	:	Priyadharshini U 											*/
/* Modified on	:	22/08/2022				 									*/
/* Defect ID	:	TECH-72114													*/
/********************************************************************************/
/* Modified by    :    Ponmalar A                                               */
/* Modified on    :    02/12/22													*/
/* Defect ID      :    TECH-75230												*/
/* Description    : Platform Release for the Month of Nov'22				    */
/********************************************************************************/
CREATE PROCEDURE ep_layout_sp_defctlcnml_o
	@ctxt_language_in engg_ctxt_language,
	@ctxt_ouinstance_in engg_ctxt_ouinstance,
	@ctxt_service_in engg_ctxt_service,
	@ctxt_user_in engg_ctxt_user,
	@engg_act_descr_in engg_description,
	@engg_component_in engg_description,
	@engg_cont_page_bts_in engg_name,
	@engg_cont_sec_bts_in engg_name,
	@engg_customer_name_in engg_name,
	@engg_enum_page_bts_in engg_name,
	@engg_enum_sec_bts_in engg_name,
	@engg_grid_page_bts_in engg_name,
	@engg_grid_sec_bts_in engg_name,
	@engg_process_descr_in engg_description,
	@engg_project_name_in engg_name,
	@engg_radpage_bts_in engg_name,
	@engg_radsec_bts_in engg_name,
	@engg_req_no_in engg_name,
	@engg_rf_act_in engg_description,
	@engg_rf_comp_in engg_description,
	@engg_rf_ui_in engg_description,
	@engg_ui_descr_in engg_description,
	@guid_in engg_guid,
	@m_errorid INT OUTPUT
AS
BEGIN
	SET NOCOUNT ON

	--declaration of temporary variables
	DECLARE @ctxt_language engg_ctxt_language
	DECLARE @ctxt_ouinstance engg_ctxt_ouinstance
	DECLARE @ctxt_service engg_ctxt_service
	DECLARE @ctxt_user engg_ctxt_user
	DECLARE @engg_act_descr engg_description
	DECLARE @engg_component engg_description
	DECLARE @engg_cont_page_bts engg_name
	DECLARE @engg_cont_sec_bts engg_name
	DECLARE @engg_customer_name engg_name
	DECLARE @engg_enum_page_bts engg_name
	DECLARE @engg_enum_sec_bts engg_name
	DECLARE @engg_grid_page_bts engg_name
	DECLARE @engg_grid_sec_bts engg_name
	DECLARE @engg_process_descr engg_description
	DECLARE @engg_project_name engg_name
	DECLARE @engg_radpage_bts engg_name
	DECLARE @engg_radsec_bts engg_name
	DECLARE @engg_req_no engg_name
	DECLARE @engg_rf_act engg_description
	DECLARE @engg_rf_comp engg_description
	DECLARE @engg_rf_ui engg_description
	DECLARE @engg_ui_descr engg_description
	DECLARE @guid engg_guid

	--temporary and formal parameters mapping
	SELECT @ctxt_language = @ctxt_language_in

	SELECT @ctxt_ouinstance = @ctxt_ouinstance_in

	SELECT @ctxt_service = ltrim(rtrim(@ctxt_service_in))

	SELECT @ctxt_user = ltrim(rtrim(@ctxt_user_in))

	SELECT @engg_act_descr = ltrim(rtrim(@engg_act_descr_in))

	SELECT @engg_component = ltrim(rtrim(@engg_component_in))

	SELECT @engg_cont_page_bts = ltrim(rtrim(@engg_cont_page_bts_in))

	SELECT @engg_cont_sec_bts = ltrim(rtrim(@engg_cont_sec_bts_in))

	SELECT @engg_customer_name = ltrim(rtrim(@engg_customer_name_in))

	SELECT @engg_enum_page_bts = ltrim(rtrim(@engg_enum_page_bts_in))

	SELECT @engg_enum_sec_bts = ltrim(rtrim(@engg_enum_sec_bts_in))

	SELECT @engg_grid_page_bts = ltrim(rtrim(@engg_grid_page_bts_in))

	SELECT @engg_grid_sec_bts = ltrim(rtrim(@engg_grid_sec_bts_in))

	SELECT @engg_process_descr = ltrim(rtrim(@engg_process_descr_in))

	SELECT @engg_project_name = ltrim(rtrim(@engg_project_name_in))

	SELECT @engg_radpage_bts = ltrim(rtrim(@engg_radpage_bts_in))

	SELECT @engg_radsec_bts = ltrim(rtrim(@engg_radsec_bts_in))

	SELECT @engg_req_no = ltrim(rtrim(@engg_req_no_in))

	SELECT @engg_rf_act = ltrim(rtrim(@engg_rf_act_in))

	SELECT @engg_rf_comp = ltrim(rtrim(@engg_rf_comp_in))

	SELECT @engg_rf_ui = ltrim(rtrim(@engg_rf_ui_in))

	SELECT @engg_ui_descr = ltrim(rtrim(@engg_ui_descr_in))

	SELECT @guid = ltrim(rtrim(@guid_in))

	--null checking
	IF @ctxt_language = - 915
		SELECT @ctxt_language = NULL

	IF @ctxt_ouinstance = - 915
		SELECT @ctxt_ouinstance = NULL

	IF @ctxt_service = '~#~'
		SELECT @ctxt_service = NULL

	IF @ctxt_user = '~#~'
		SELECT @ctxt_user = NULL

	IF @engg_act_descr = '~#~'
		SELECT @engg_act_descr = NULL

	IF @engg_component = '~#~'
		SELECT @engg_component = NULL

	IF @engg_cont_page_bts = '~#~'
		SELECT @engg_cont_page_bts = NULL

	IF @engg_cont_sec_bts = '~#~'
		SELECT @engg_cont_sec_bts = NULL

	IF @engg_customer_name = '~#~'
		SELECT @engg_customer_name = NULL

	IF @engg_enum_page_bts = '~#~'
		SELECT @engg_enum_page_bts = NULL

	IF @engg_enum_sec_bts = '~#~'
		SELECT @engg_enum_sec_bts = NULL

	IF @engg_grid_page_bts = '~#~'
		SELECT @engg_grid_page_bts = NULL

	IF @engg_grid_sec_bts = '~#~'
		SELECT @engg_grid_sec_bts = NULL

	IF @engg_process_descr = '~#~'
		SELECT @engg_process_descr = NULL

	IF @engg_project_name = '~#~'
		SELECT @engg_project_name = NULL

	IF @engg_radpage_bts = '~#~'
		SELECT @engg_radpage_bts = NULL

	IF @engg_radsec_bts = '~#~'
		SELECT @engg_radsec_bts = NULL

	IF @engg_req_no = '~#~'
		SELECT @engg_req_no = NULL

	IF @engg_rf_act = '~#~'
		SELECT @engg_rf_act = NULL

	IF @engg_rf_comp = '~#~'
		SELECT @engg_rf_comp = NULL

	IF @engg_rf_ui = '~#~'
		SELECT @engg_rf_ui = NULL

	IF @engg_ui_descr = '~#~'
		SELECT @engg_ui_descr = NULL

	IF @guid = '~#~'
		SELECT @guid = NULL


	--errors mapped
	DECLARE @iudmodeflag VARCHAR(2),
		@tmp_processname engg_name,
		@tmp_componentname engg_name,
		@tmp_activity engg_name,
		@tmp_ui engg_name,
		@engg_base_req_no engg_name

	SELECT @engg_base_req_no = 'BASE'

	--getting the process name for description  
	SELECT @tmp_processname = process_name
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND process_descr = @engg_process_descr
		AND req_no = @engg_req_no

	--getting the component name for the description  
	SELECT @tmp_componentname = component_name
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND process_name = @tmp_processname
		AND component_descr = @engg_component
		AND req_no = @engg_req_no

	--getting the activity name for the description  
	SELECT @tmp_activity = activity_name
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND process_name = @tmp_processname
		AND component_name = @tmp_componentname
		AND activity_descr = @engg_act_descr
		AND req_no = @engg_req_no

	--getting the ui name for the description  
	SELECT @tmp_ui = ui_name
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND process_name = @tmp_processname
		AND component_name = @tmp_componentname
		AND activity_name = @tmp_activity
		AND ui_descr = @engg_ui_descr
		AND req_no = @engg_req_no

	SELECT control_bt_synonym 'engg_cont_btsynname',
		bt_synonym_caption 'engg_cont_descr',
		control_doc 'engg_cont_doc',
		control_type 'engg_cont_elem_type',
		horder 'engg_cont_horder',
		sample_data 'engg_cont_samp_data',
		proto_tooltip 'engg_cont_tooltip',
		visisble_length 'engg_cont_vis_length',
		vorder 'engg_cont_vorder',
		-- code modified by shafina on 22-Dec-2004 for  PREVIEWENG203ACC_000116 (In control_dtl table, label_column_scalemode and data_column_scalemode are added.)
		rtrim(data_column_width) + rtrim(data_column_scalemode) 'engg_cont_datawidth',
		rtrim(label_column_width) + rtrim(label_column_scalemode) 'engg_cont_labwidth',
		rtrim(order_seq) 'engg_cont_sequence',
		rowspan 'engg_cont_rowspan',
		colspan 'engg_cont_colspan',
		controlimage 'engg_cont_ctrlimg',
		a.TemplateID 'engg_cont_tempid' -- Added for PLF2.0_14096		
		,
		parameter_text 'ctrl_temp_cat',
		TemplateSpecific 'ctrl_temp_specific',
		-- code modified by Ranjitha R
		AccessKey 'AccessKey',
		Icon_class 'Icon_Class',
		Icon_position 'Icon_position',
		Control_class_ext6 'Cont_class_ext6',
		CASE 
			WHEN dynamicStyle = 'y'
				THEN '1'
			ELSE '0'
			END 'engg_dynamicStyle',
		CASE 
			WHEN imageasdata = 'y'
				THEN '1'
			ELSE '0'
			END 'engg_ImageAsData',--code ends

			CASE WHEN ExtensionReqd	=	'Yes'
		        THEN '1'
			ELSE '0'
			END 'engg_extnreqd',  --Code added for TECH-60451
		'...'	'engg_extension',  ---Code added for TECH-60451
		AssociateControl 'engg_MSC_Ass_control', --code added for TECH-63527
		--Code Added for TECH-69624 on 02June22 Starts
		ISNULL(a.ForResponsive,'')	'Engg_cont_forresponsive',
		'...'						'engg_cont_customborder',
		'...'						'engg_cont_customaction',
		--Code Added for TECH-69624 on 02June22 ends
		ControlFormat				'engg_cont_control_format',	--Code Added for the Defect Id TECH-72114
		ISNULL(a.ButtonNature,'')	'ButtonNature',		--Code added for TECH-75230
		ISNULL(a.InlineStyle,'')	'InlineStyle'		--Code added for TECH-75230
	FROM ep_ui_control_dtl a(NOLOCK)
	LEFT JOIN ep_component_glossary_mst b(NOLOCK) ON a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.req_no = b.req_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.control_bt_synonym = b.bt_synonym_name
	LEFT JOIN ep_device_quick_code_met c(NOLOCK) ON a.TemplateCategory = c.parameter_code
		AND parameter_type = 'TemplateCategory'
	WHERE a.customer_name = @engg_customer_name
		AND a.project_name = @engg_project_name
		AND a.req_no = @engg_base_req_no
		AND a.process_name = @tmp_processname
		AND a.component_name = @tmp_componentname
		AND a.activity_name = @tmp_activity
		AND a.ui_name = @tmp_ui
		AND a.page_bt_synonym = @engg_cont_page_bts
		AND a.section_bt_synonym = @engg_cont_sec_bts
		AND a.horder	NOT IN (501,601) --Tech-70687

	--and  	a.customer_name   	*= 	b.customer_name  
	--and  	a.project_name    	*= 	b.project_name  
	--and     a.req_no       		*=  	b.req_no  
	--and  	a.process_name    	*= 	b.process_name  
	--and  	a.component_name  	*= 	b.component_name
	--and  	a.control_bt_synonym 	*= 	b.bt_synonym_name
	/* 
	--OutputList
		Select
		null 'engg_cont_btsynname', 
		null 'engg_cont_datawidth', 
		null 'engg_cont_descr', 
		null 'engg_cont_doc', 
		null 'engg_cont_elem_type', 
		null 'engg_cont_horder', 
		null 'engg_cont_labwidth', 
		null 'engg_cont_samp_data', 
		null 'engg_cont_sequence', 
		null 'engg_cont_tooltip', 
		null 'engg_cont_vis_length', 
		null 'engg_cont_vorder', 
		null 'engg_cont_rowspan', 
		null 'engg_cont_colspan', 
		null 'engg_cont_ctrlimg', 
		null 'engg_cont_tempid', 
		null 'engg_extnreqd',
		null 'engg_extension,
		null 'engg_MSC_Ass_control',
	*/
	SET NOCOUNT OFF
END
GO

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_layout_sp_defctlcnml_o' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON ep_layout_sp_defctlcnml_o TO PUBLIC
END
GO

