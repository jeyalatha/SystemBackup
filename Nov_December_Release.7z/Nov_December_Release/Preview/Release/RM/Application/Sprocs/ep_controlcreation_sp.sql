IF EXISTS(SELECT 'X' From SYSOBJECTS WHERE NAME ='ep_controlcreation_sp' AND TYPE='P')
   BEGIN
        DROP PROC ep_controlcreation_sp
   END
GO 
/****************************************************************************************************/
/* Procedure Name		: ep_controlcreation_sp														*/
/* Description			: To create the controls from metadata Table								*/
/* Created by			: JeyaLatha K			   Date: 21-Mar-2018  Defect ID: TECH-20326			*/
/* Modified by			: Jeya Latha K			   Date: 28-Jun-2019  Defect ID: TECH-35368			*/
/* Modified by			: Jeya Latha K			   Date: 25-Jul-2019  Defect ID: TECH-36371			*/
/* Modified by			: Jeya Latha K\Hareesh K   Date: 30-Aug-2019  Defect ID: TECH-37471			*/
/* Modified by			: Priyadharshini U/Rajeswari M	 Date: 29-Jan-2020  Defect ID : TECH-42483	*/
/* Modified by 			: Jeya Latha K                   Date: 27-May-2020	Defect ID : TECH-46646 	*/
/* Modified by 			: Rajeswari M/Priyadharshini U   Date: 28-July-2021	Defect ID : TECH-60451 	*/
/* TECH-60451			: Launching Help&Link UIs, Popup sections and Grid Extensions in Side Drawer*/
/* Modified by 			: Jeya Latha K   Date: 31-Mar-2022	Defect ID : TECH-60451 					*/
/* TECH-67705			: Create a edit control (System generated) for Calendar, 
						  Scheduler & Gantt to implement the filter capabilities.					*/
/* Modified by 			: Priyadharshini U			Date: 27-July-2022	Defect ID : TECH-71262	 	*/		
/* Modified by 			: Ponmalar A				Date: 30-Sep-2022	Defect ID : TECH-73216	 	*/				
/* Modified by 			: Ponmalar A				Date: 02-Dec-2022	Defect ID : TECH-75230	 	*/				
/****************************************************************************************************/
/* Modified by 			: Venkatesan K   Date: 27-Oct-2022	Defect ID : TECH-74049 					*/
/* Modified by 			: Ponmalar A	 Date: 22-Nov-2022	Defect ID : TECH-75230 					*/
/****************************************************************************************************/
create PROCEDURE ep_controlcreation_sp
@ctxt_OUInstance                engg_ctxt_OUInstance,
@ctxt_User                      engg_ctxt_User,
@ctxt_Language                  engg_ctxt_Language,
@ctxt_Service                   engg_ctxt_Service,
@engg_customer_name             engg_name,
@engg_project_name              engg_name,
@engg_process_name				engg_name,
@engg_component_name            engg_name,
@engg_activity_name				engg_name,
@engg_ui_name					engg_name,
@engg_page_name					engg_name,
@engg_section_name				engg_name,
@engg_control_name				engg_name,
@engg_req_no                    engg_name,
@ModeFlag                       engg_ModeFlag,
@CreatingFor					engg_name,
@m_errorid                      engg_seqno output
As
Begin

	SET NOCOUNT ON

	Declare	@tmp_viewname			engg_name,
			@tmp_viewcaption		engg_name,
			@tmp_ctrltype			engg_name,
			@tmp_derivedtype		engg_name,
			@tmp_remarks			engg_Description,
			@tmp_prefix				engg_name,
			@tmp_suffix				engg_name,
			@tmp_seqno				engg_seqno,
			@tmp_controlidprefix	engg_name,
			@tmp_controlid			engg_name,
			@tmp_controlbtsynonym	engg_name,
			@tmp_btLength			engg_seqno,
			@MultiSelectforRB		engg_name,
			@taskreqd				engg_flag,
			@RuleBuilderTask		engg_name,
			@page_prefix_tmp		engg_name,
			@tmp_btname				engg_name,
			@tmp_renderas			engg_name,
			@control_doc			engg_documentation,
			@tmp_taskdesc			engg_description,
			@tmp_tasktype			engg_name,
		--Code Added for Defect ID : TECH-39534 Starts
			@GanttTask				engg_flag,
			@tmp_controlprefix		engg_name,
			@engg_dynamicstyle		engg_name,
			@tmp_sectionprefix		engg_name

-- Added for Rule Builder Starts Defect ID: TECH-35368
	SET @tmp_btLength		= 4000
	SET @MultiSelectforRB	= 'N'
	SET @GanttTask			= 'N'
	--Code Added for Defect ID : TECH-39534 Ends
	SET @control_doc		= 'System Generated'
	
		--TECH-73216	
		IF ISNULL(@ModeFlag,'') IN ('I','X') AND LEN(@engg_control_name) > 18
		BEGIN
			RAISERROR ('Length of Control Bt Synonym must not be greater than 18.',16,1)
			RETURN
		END
		--TECH-73216
	
	IF @CreatingFor = 'RulebuilderMS'
	BEGIN
	 
		Select @CreatingFor = 'RuleBuilder'
		SELECT @MultiSelectforRB = 'Y'
	END
-- Added for Rule Builder Ends Defect ID: TECH-35368
	
	IF  @CreatingFor = 'SectionDynamicStyle'
	BEGIN
		SELECT @engg_dynamicstyle	= 'Dynamic'
	END
	ELSE
		SELECT @engg_dynamicstyle	= ''

	IF @MultiSelectforRB = 'Y'
	BEGIN
		Declare controlcur insensitive cursor  for   
		SELECT	ViewName,		ViewCaption,	control_type,	Remarks,	prefix,		suffix,		seq_no,	
				TaskReqd,		BTName,			RenderAs
		FROM	ep_systemdefined_views (nolock)
		WHERE	CreatedFor		= @CreatingFor
		AND		ViewCode		= 'Control'		
		order by seq_no
	END
	-- Added for Rule Builder Starts Defect ID: TECH-35368
	ELSE IF @MultiSelectforRB = 'N' and @CreatingFor = 'RuleBuilder'
	BEGIN
		Declare controlcur insensitive cursor  for   
		SELECT	ViewName,		ViewCaption,	control_type,	Remarks,	prefix,		suffix,		seq_no,
				TaskReqd,		BTName,			RenderAs
		FROM	ep_systemdefined_views (nolock)
		WHERE	CreatedFor		= @CreatingFor
		AND		ViewCode		= 'Control'	
		AND		seq_no			< 3	
		order by seq_no
	END
	
	ELSE  IF @CreatingFor IN ('Calendar', 'Gantt')
	BEGIN	
	
		Declare controlcur insensitive cursor  for   
		SELECT	ViewName,		ViewCaption,	control_type,	Remarks,	prefix,		suffix,		seq_no,
				TaskReqd,		BTName,			RenderAs
		FROM	ep_systemdefined_views (nolock)
		WHERE	CreatedFor		= @CreatingFor
		AND		ViewCode		= 'Control'			
		order by seq_no
	END
	ELSE  IF @CreatingFor = 'ConditionalPopupclose'
	BEGIN	
	
		Declare controlcur insensitive cursor  for   
		SELECT	ViewName,		ViewCaption,	control_type,	Remarks,	prefix,		suffix,		seq_no,
				TaskReqd,		BTName,			RenderAs
		FROM	ep_systemdefined_views (nolock)
		WHERE	CreatedFor		= @CreatingFor
		AND		ViewCode		= 'HiddenControl'			
		order by seq_no
	END
	ELSE  IF @CreatingFor = 'ARIReport' OR @CreatingFor = 'TitlebarSearch' OR @CreatingFor = 'SectionDynamicStyle'
	BEGIN	
	
		Declare controlcur insensitive cursor  for   
		SELECT	ViewName,		ViewCaption,	control_type,	Remarks,	prefix,		suffix,		seq_no,
				TaskReqd,		BTName,			RenderAs
		FROM	ep_systemdefined_views (nolock)
		WHERE	CreatedFor		= @CreatingFor
		AND		ViewCode		= 'Control'			
		order by seq_no
	END
		ELSE  IF @CreatingFor = 'StepperLinear' OR @CreatingFor = 'StepperNonLinear' --TECH-74049
	BEGIN	
		Declare controlcur insensitive cursor  for   
		SELECT	ViewName,		ViewCaption,	control_type,	Remarks,	prefix,		suffix,		seq_no,
				TaskReqd,		BTName,			RenderAs
		FROM	ep_systemdefined_views (nolock)
		WHERE	CreatedFor		= @CreatingFor
		AND		ViewCode		= 'Control'			
		order by seq_no
	END

	-- Added for Rule Builder Ends Defect ID: TECH-35368
	open controlcur
	Fetch Next from controlcur into @tmp_viewname , @tmp_viewcaption, @tmp_ctrltype, @tmp_remarks, @tmp_prefix,	@tmp_suffix, @tmp_seqno,
								@taskreqd,	@tmp_btname,	@tmp_renderas
	
	
	WHILE @@FETCH_STATUS = 0
		BEGIN						

--Code Added for Defect ID : TECH-39534 Starts
		 IF @CreatingFor = 'Gantt'
		 BEGIN
			
			if exists ( select 'x'  
			from    es_comp_ctrl_type_mst_extn ext (nolock)  ,
					ep_ui_control_dtl ctl (nolock)
			where   ctl.customer_name   = @engg_customer_name  
			and		ctl.project_name    = @engg_project_name  
			and		ctl.process_name    = @engg_process_name  
			and		ctl.component_name  = @engg_component_name  
			and		ctl.activity_name	= @engg_activity_name
			and		ctl.ui_name			= @engg_ui_name
			and		ctl.page_bt_synonym	= @engg_page_name
			and		ctl.section_bt_synonym=@engg_section_name
			and		ctl.control_bt_synonym =@engg_control_name

			and		ctl.customer_name	= ext.customer_name
			and		ctl.project_name	= ext.project_name
			and		ctl.process_name	= ext.process_name
			and		ctl.component_name	= ext.component_name
			and		ctl.control_Type	= ext.ctrl_Type_name
				
			and		base_Ctrl_Type		= 'TreeGrid'
			and		ISNULL(AutoSync,'N')= 'Y')	
			
				SELECT	@GanttTask		= 'Y' 
		END
--Code Added for Defect ID : TECH-39534 Ends
		 select @tmp_btname	= replace(@tmp_btname,'-','')
		 
		select @tmp_controlidprefix  = case 
											when @tmp_ctrltype = 'Edit'	then 'TXT'
											when @tmp_ctrltype = 'HiddenEdit'	then 'HDN'
											when @tmp_ctrltype = 'Combo'	then 'CMB'
											when @tmp_ctrltype = 'DisplayOnly'	then 'DSP'
											when @tmp_ctrltype = 'Grid'	then 'ML'
											when @tmp_ctrltype = 'Button' then 'BTN'
											when @tmp_ctrltype = 'Link'	then 'LNK'
											when @tmp_ctrltype = 'TextArea'	then 'TXT'
											when @tmp_ctrltype = 'ListView'	then 'LVW'
											when @tmp_ctrltype = 'HiddenControl' then 'hdn'
										end

						
			If not exists ( select	'X' from de_business_term (nolock)
			where	customer_name   = @engg_customer_name
			And		project_name	= @engg_project_name
			And		process_name	= @engg_process_name
			And		component_name  = @engg_component_name
			And		bt_name			= 'nvarcharmax')
			Begin
				Insert into de_business_term
					(customer_name,			project_name,			process_name,		component_name,			bt_name,		bt_descr,
					data_type,				bt_sysid,				timestamp,			createdby,				createddate,	modifiedby,
					modifieddate,			length,					precision_type,		ecrno)
				values
					(@engg_customer_name,   @engg_project_name,		@engg_process_name,	@engg_component_name,	'nvarcharmax',	'nvarcharmax',
					'Char',					newid(),				1,					@ctxt_user,				getdate(),		@ctxt_user,
					getdate(),				8000,					null,				@engg_req_no)
			End
--Code Added for Defect ID : TECH-39534 Starts
		
		SELECT	@tmp_controlprefix		= control_prefix
		FROM	ep_ui_control_dtl (nolock)
		WHERE	customer_name			= @engg_customer_name
		AND		project_name			= @engg_project_name		
		AND		process_name			= @engg_process_name
		AND		component_name			= @engg_component_name
		AND		activity_name			= @engg_activity_name
		AND		ui_name					= @engg_ui_name
		AND		page_bt_synonym			= @engg_page_name
		AND		section_bt_synonym		= @engg_section_name
		AND		control_bt_synonym		= @engg_control_name
			
		SELECT	@tmp_sectionprefix		= section_prefix
		FROM	ep_ui_section_dtl (nolock)
		WHERE	customer_name			= @engg_customer_name
		AND		project_name			= @engg_project_name		
		AND		process_name			= @engg_process_name
		AND		component_name			= @engg_component_name
		AND		activity_name			= @engg_activity_name
		AND		ui_name					= @engg_ui_name
		AND		page_bt_synonym			= @engg_page_name
		AND		section_bt_synonym		= @engg_section_name
		

		 IF charindex('[control_bt_synonym]', @tmp_viewname) > 0 
			select @tmp_viewname	= @engg_control_name
		 ELSE IF charindex('[controlprefix]', @tmp_viewname) > 0 
			select @tmp_viewname	= @tmp_controlprefix
		ELSE IF charindex('[sectionprefix]', @tmp_viewname) > 0 
			select @tmp_viewname	= @tmp_sectionprefix
		ELSE
			Select @tmp_viewname	= @tmp_viewname


		select	@tmp_controlbtsynonym	= ISNULL(@tmp_prefix,'') + ISNULL(@tmp_viewname,'') + ISNULL(@tmp_suffix,'')
		select	@tmp_controlid			= ISNULL(@tmp_controlidprefix,'') +  ISNULL(@tmp_controlbtsynonym,'')
--Code Added for Defect ID : TECH-39534 Ends
			

		IF @CreatingFor = 'RuleBuilder' and @tmp_viewcaption = 'SQL Query'
			SELECT @tmp_derivedtype = '__RuleBuilderSQLTA'
		ELSE IF @CreatingFor = 'RuleBuilder' and @tmp_viewcaption like 'Rule%'
			SELECT @tmp_derivedtype = '__RuleBuilderRuleTA'
		ELSE IF @CreatingFor = 'RuleBuilder' and @tmp_ctrltype = 'Edit'
			SELECT @tmp_derivedtype = '__RuleBuilderedt'
		ELSE IF @CreatingFor = 'RuleBuilder' and @tmp_ctrltype = 'ListView'
			SELECT @tmp_derivedtype = '__RuleBuilderLST'
		ELSE IF @CreatingFor = 'Calendar' and @tmp_viewcaption = 'Assignment'
			SELECT @tmp_derivedtype = '__Calendarasg'
		ELSE IF @CreatingFor = 'Calendar' and @tmp_viewcaption = 'Resource'
			SELECT @tmp_derivedtype = '__Calendarres'
		ELSE IF @CreatingFor = 'Calendar' and @tmp_viewcaption = 'MetaLink'
			SELECT @tmp_derivedtype = '__Calendarmet'
		ELSE IF @CreatingFor = 'Gantt' and @tmp_viewcaption = 'Assignment'
			SELECT @tmp_derivedtype = '__GanttAssignment'
		ELSE IF @CreatingFor = 'Gantt' and @tmp_viewcaption = 'Dependency'
			SELECT @tmp_derivedtype = '__GanttDependency'
		ELSE IF @CreatingFor = 'Gantt' and @tmp_viewcaption = 'Resource'
			SELECT @tmp_derivedtype = '__GanttResource'
		ELSE IF @CreatingFor = 'Gantt' and @tmp_viewcaption = 'Calendar'
			SELECT @tmp_derivedtype = '__GanttCalendar'
		ELSE IF @CreatingFor = 'Gantt' and @tmp_viewcaption = 'GanttTask'
			SELECT @tmp_derivedtype = '__GanttButton'
	--Code Added for the Defect-id TECH-67705 starts
		ELSE IF @CreatingFor = 'Gantt' and @tmp_viewcaption = 'Filter'
			SELECT @tmp_derivedtype = 'Edit'
	--Code Added for the Defect-id TECH-67705 Ends
--Code Added for Defect ID : TECH-39534 Starts
		ELSE IF @CreatingFor = 'Calendar' and @tmp_ctrltype = 'HiddenEdit'
			SELECT @tmp_derivedtype = 'HiddenEdit'
--Code Added for Defect ID : TECH-39534 Ends
		ELSE IF @CreatingFor =  'ConditionalPopupclose' 
			SELECT @tmp_derivedtype = 'StringEdit'
		ELSE IF @CreatingFor = 'SectionDynamicStyle' 
			SELECT @tmp_derivedtype = 'HiddenEdit'
		ELSE IF @CreatingFor = 'StepperLinear' AND @tmp_ctrltype = 'Button' --TECH-74049
			SELECT @tmp_derivedtype = 'HiddenButton'
		ELSE IF @CreatingFor = 'StepperNonLinear' AND @tmp_ctrltype = 'Button' --TECH-74049
			SELECT @tmp_derivedtype = 'HiddenButton'
		ELSE IF @CreatingFor = 'StepperLinear' AND @tmp_ctrltype = 'HiddenEdit' --TECH-74049
			SELECT @tmp_derivedtype = 'HiddenEdit'
		ELSE IF @CreatingFor = 'StepperNonLinear' AND @tmp_ctrltype = 'HiddenEdit' --TECH-74049
			SELECT @tmp_derivedtype = 'HiddenEdit'

		ELSE
			SELECT	@tmp_derivedtype	= 'Edit'	--TECH-67705
			
		SET @tmp_seqno	= @tmp_seqno + 1
		
		--SET @tmp_seqno	= @tmp_seqno + 1
		exec engg_gen_prefix_id 
						@engg_customer_name,			@engg_project_name,		@engg_component_name,		@engg_activity_name,		
						@engg_ui_name,					@tmp_controlbtsynonym,	'C',						6,						
						@page_prefix_tmp output  

		
		

		IF NOT EXISTS ( SELECT 'X'
						FROM	ep_ui_control_dtl (nolock)
						where	customer_name   = @engg_customer_name
						And		project_name	= @engg_project_name
						And		process_name	= @engg_process_name
						And		component_name  = @engg_component_name
						AND		activity_name	= @engg_activity_name
						AND		ui_name			= @engg_ui_name
						and		control_bt_synonym= @tmp_controlbtsynonym
						)

		BEGIN

	

		EXEC	EP_UI_CONTROL_DTL_SP_INS
									@CTXT_LANGUAGE_IN			= @ctxt_Language,
									@CTXT_OUINSTANCE_IN			= @ctxt_OUInstance,
									@CTXT_SERVICE_IN			= @ctxt_Service,
									@CTXT_USER_IN				= @ctxt_User,
									@CUSTOMER_NAME_IN			= @engg_customer_name,
									@PROJECT_NAME_IN			= @engg_project_name,
									@REQ_NO_IN					= 'BASE',
									@PROCESS_NAME_IN			= @engg_process_name,
									@COMPONENT_NAME_IN			= @engg_component_name,
									@ACTIVITY_NAME_IN			= @engg_activity_name,
									@UI_NAME_IN					= @engg_ui_name,
									@PAGE_BT_SYNONYM_IN			= @engg_page_name,
									@SECTION_BT_SYNONYM_IN		= @engg_section_name,
									@CONTROL_BT_SYNONYM_IN		= @tmp_controlbtsynonym,
									@CONTROL_ID_IN				= @tmp_controlid,
									@CONTROL_TYPE_IN			= @tmp_derivedtype,
									@VISISBLE_LENGTH_IN			= 20,
									@HORDER_IN					= @tmp_seqno,
									@VORDER_IN					= 1,
									@ORDER_SEQ_IN				= 1,
									@DATA_COLUMN_WIDTH_IN		= 0,
									@LABEL_COLUMN_WIDTH_IN		= 0,
									@PROTO_TOOLTIP_IN			= NULL,
									@SAMPLE_DATA_IN				= NULL,
									@CONTROL_DOC_IN				= @control_doc,
									@CONTROL_PREFIX_IN			= @page_prefix_tmp,
									@LABEL_CONTROL_ID_IN		= '',
									@label_column_scalemode_in	= NULL,
									@data_column_scalemode_in	= NULL,
									@engg_label_class_in		= NULL,
									@engg_control_class_in		= NULL,
									@engg_label_image_class_in	= NULL,
									@engg_control_image_class_in= NULL,
									@engg_tab_sequence_in		= 0,
									@engg_tab_stopforhelp_in	= 0,
									@TIMESTAMP_IN				= 1,
									@engg_req_no				= 'BASE',
									@user_pref					= 'Y',
									@freezecount				= NULL,
									@Engg_cont_Ctrlimg			= NULL,
									@Engg_cont_rowspan			= 0,
									@Engg_cont_colspan			= 0,
									@engg_cont_tempid			= NULL,
									@ctrl_temp_cat				= NULL,
									@ctrl_temp_specific			= NULL,
									@AccessKey					= NULL,
									@Icon_class					= NULL,
									@Icon_position				= NULL,
									@Cont_class_ext6			= NULL,
									@engg_dynamicstyle			= NULL,
									@engg_imageasdata			= NULL,
									@engg_extnreqd				= '',  --Code added for TECH-60451
									@engg_MSC_Ass_control		= '',	--Code Added for TECH-71262
									@Engg_cont_forresponsive	= NULL,	--Code Added for TECH-71262
									@engg_cont_control_format	= '', --TECH-73216
									@ButtonNature				= NULL,	--TECH-75230
									@InlineStyle				= NULL,	--TECH-75230
									@M_ERRORID					= @m_errorid OUT
	END
	--Code Added for Defect ID : TECH-39534 Starts
	IF @creatingfor = 'Gantt' and @GanttTask = 'N'
	BEGIN
	
		IF EXISTS ( SELECT 'X'
		FROM	ep_ui_control_dtl (nolock)
		where	customer_name   = @engg_customer_name
		And		project_name	= @engg_project_name
		And		process_name	= @engg_process_name
		And		component_name  = @engg_component_name
		AND		activity_name	= @engg_activity_name
		AND		ui_name			= @engg_ui_name
		and		page_bt_synonym	= @engg_page_name
		and		section_bt_synonym=@engg_section_name
		and		control_type	= '__GanttButton'
		)
			DELETE FROM	ep_ui_control_dtl 
			where	customer_name   = @engg_customer_name
			And		project_name	= @engg_project_name
			And		process_name	= @engg_process_name
			And		component_name  = @engg_component_name
			AND		activity_name	= @engg_activity_name
			AND		ui_name			= @engg_ui_name
			and		page_bt_synonym	= @engg_page_name
			and		section_bt_synonym=@engg_section_name
			and		control_type	= '__GanttButton'
	END
--Code Added for Defect ID : TECH-39534 Ends	
		--INSERT INTO ep_ui_control_dtl 
		--	(customer_name,			project_name,		req_no,					process_name,				component_name,	
		--	activity_name,			ui_name,			page_bt_synonym,		section_bt_synonym,			control_bt_synonym,			
		--	control_type,			horder,				vorder,					order_seq,					data_column_width,	
		--	label_column_width,		ui_control_sysid,	ui_section_sysid,		timestamp,					createdby,			
		--	createddate,			modifiedby,			modifieddate,			control_id,					view_name,
		--	visisble_length,		sample_data,		control_doc,			control_prefix	)
		--Select
		--	@engg_customer_name,	@engg_project_name,	'BASE',					@engg_process_name,			@engg_component_name,
		--	@engg_activity_name,	@engg_ui_name,		@engg_page_name,		@engg_section_name,			@tmp_controlbtsynonym,
		--	@tmp_derivedtype,		@tmp_seqno+1,		1,						1,							0,	
		--	0,						newid(),			newid(),				1,							@ctxt_user,			
		--	getdate(),				@ctxt_user,			getdate(),				@tmp_controlid,				@tmp_controlid,
		--	null,					'',					'System Generated',		@page_prefix_tmp

		--IF ISNULL(@taskreqd ,'N')	= 'Y' AND @CreatingFor = 'Rulebuilder'
		--BEGIN
		
		--	INSERT INTO es_ctrl_type_events_mst
		--				(customer_name,			project_name,			req_no,				process_name,
		--				component_name,			ctrl_type_name,			base_ctrl_type,		events_desc,
		--				events_required,		tasktype)
		--	VALUES	
		--				(@engg_customer_name,	@engg_project_name,		'BASE',				@engg_process_name,
		--				@engg_component_name,	@tmp_derivedtype,		@tmp_ctrltype,		'UI Task to Load MultiSelect Combo for Rule Builder',
		--				'Y',					'UI')
		--	--IF @CreatingFor = 'Rulebuilder'
		--		SET @engg_control_name = @engg_control_name + '_Entity'

		--	Exec ep_layout_save_events_gen 
		--		@ctxt_language,			@ctxt_ouinstance,		@ctxt_service,			@ctxt_user,			@engg_customer_name,
		--		@engg_project_name,		@engg_process_name,		@engg_component_name,	@engg_activity_name,@engg_ui_name,		
		--		@engg_page_name,		@engg_section_name,		@engg_control_name,		'BASE',				@tmp_derivedtype,
		--		@tmp_ctrltype,			@m_errorid out			

		--END
		
		IF @CreatingFor = 'Rulebuilder'
		BEGIN
			SELECT @tmp_taskdesc	=	'UI Task to Load MultiSelect Combo for Rule Builder'
			SELECT @tmp_tasktype	=	'UI'
			SELECT @engg_control_name = @engg_control_name + '_Entity'
		END
		ELSE IF @CreatingFor = 'Gantt' AND @GanttTask = 'Y' 
		BEGIN
		
			SELECT @tmp_taskdesc	=	'Task for Gantt'
			SELECT @tmp_tasktype	=	'Trans'
			--SELECT @engg_control_name = @engg_control_name 
--Code Added for Defect ID : TECH-39534 Starts
			SELECT @engg_control_name = control_bt_synonym 
			FROM	ep_ui_control_dtl (nolock)
			where	customer_name   = @engg_customer_name
			And		project_name	= @engg_project_name
			And		process_name	= @engg_process_name
			And		component_name  = @engg_component_name
			AND		activity_name	= @engg_activity_name
			AND		ui_name			= @engg_ui_name
			AND		page_bt_synonym	= @engg_page_name
			AND		section_bt_synonym = @engg_section_name
			AND		control_type	= '__GanttButton'

			SET @taskreqd = 'Y'

		END
		ELSE IF @CreatingFor = 'TitlebarSearch'
		BEGIN
			SELECT @tmp_taskdesc	=	'UI Task for Title bar Search'
			SELECT @tmp_tasktype	=	'UI'
			SELECT @engg_control_name = @engg_control_name
		END
		ELSE IF @CreatingFor = 'StepperLinear' AND @tmp_suffix = '_prev' --TECH-74049
		BEGIN 
			SELECT @tmp_taskdesc	=	'Task for Previous button -Linear Stepper'

			SELECT @tmp_tasktype	=	'Trans'

			SELECT @engg_control_name = control_bt_synonym 
			FROM	ep_ui_control_dtl (nolock)
			where	customer_name   = @engg_customer_name
			And		project_name	= @engg_project_name
			And		process_name	= @engg_process_name
			And		component_name  = @engg_component_name
			AND		activity_name	= @engg_activity_name
			AND		ui_name			= @engg_ui_name
			AND		page_bt_synonym	= @engg_page_name
			AND		section_bt_synonym = @engg_section_name
			AND		control_bt_synonym	like '%_prev%'
			
		END
		ELSE IF @CreatingFor = 'StepperLinear' AND @tmp_suffix = '_next' --TECH-74049
		BEGIN 
			SELECT @tmp_taskdesc	=	'Task for Next button -Linear Stepper'

			SELECT @tmp_tasktype	=	'Trans'

			SELECT @engg_control_name = control_bt_synonym 
			FROM	ep_ui_control_dtl (nolock)
			where	customer_name   = @engg_customer_name
			And		project_name	= @engg_project_name
			And		process_name	= @engg_process_name
			And		component_name  = @engg_component_name
			AND		activity_name	= @engg_activity_name
			AND		ui_name			= @engg_ui_name
			AND		page_bt_synonym	= @engg_page_name
			AND		section_bt_synonym = @engg_section_name
			AND		control_bt_synonym	like '%_next%'
			
		END
		ELSE IF @CreatingFor = 'StepperNonLinear' AND @tmp_suffix = '_prev' --TECH-74049
		BEGIN
			SELECT @tmp_taskdesc	=	'Task for Previous button -Non Linear Stepper'

			SELECT @tmp_tasktype	=	'Trans'

			SELECT @engg_control_name = control_bt_synonym 
			FROM	ep_ui_control_dtl (nolock)
			where	customer_name   = @engg_customer_name
			And		project_name	= @engg_project_name
			And		process_name	= @engg_process_name
			And		component_name  = @engg_component_name
			AND		activity_name	= @engg_activity_name
			AND		ui_name			= @engg_ui_name
			AND		page_bt_synonym	= @engg_page_name
			AND		section_bt_synonym = @engg_section_name
			AND		control_bt_synonym	like '%_prev%'
			
		END
		ELSE IF @CreatingFor = 'StepperNonLinear' AND @tmp_suffix = '_next' --TECH-74049
		BEGIN
			SELECT @tmp_taskdesc	=	'Task for Next button -Non Linear Stepper'

			SELECT @tmp_tasktype	=	'Trans'

			SELECT @engg_control_name = control_bt_synonym 
			FROM	ep_ui_control_dtl (nolock)
			where	customer_name   = @engg_customer_name
			And		project_name	= @engg_project_name
			And		process_name	= @engg_process_name
			And		component_name  = @engg_component_name
			AND		activity_name	= @engg_activity_name
			AND		ui_name			= @engg_ui_name
			AND		page_bt_synonym	= @engg_page_name
			AND		section_bt_synonym = @engg_section_name
			AND		control_bt_synonym	like '%_next%'
			
		END
		ELSE IF @CreatingFor = 'StepperNonLinear' AND @tmp_suffix = '_comp' --TECH-74049
		BEGIN
			SELECT @tmp_taskdesc	=	'Task for Complete button -Non Linear Stepper'

			SELECT @tmp_tasktype	=	'Trans'

			SELECT @engg_control_name = control_bt_synonym 
			FROM	ep_ui_control_dtl (nolock)
			where	customer_name   = @engg_customer_name
			And		project_name	= @engg_project_name
			And		process_name	= @engg_process_name
			And		component_name  = @engg_component_name
			AND		activity_name	= @engg_activity_name
			AND		ui_name			= @engg_ui_name
			AND		page_bt_synonym	= @engg_page_name
			AND		section_bt_synonym = @engg_section_name
			AND		control_bt_synonym	like '%_comp%'
			
		END
		--TEch-74049
		IF @CreatingFor = 'Gantt' AND @GanttTask = 'Y'  and @tmp_suffix <> '_Tsk'
			SET @taskreqd = 'N'


		--Code Added for Defect ID : TECH-39534 Ends
		IF ISNULL(@taskreqd ,'N')	= 'Y' 
		BEGIN
		
			INSERT INTO es_ctrl_type_events_mst
						(customer_name,			project_name,			req_no,				process_name,
						component_name,			ctrl_type_name,			base_ctrl_type,		events_desc,
						events_required,		tasktype)
			VALUES	
						(@engg_customer_name,	@engg_project_name,		'BASE',				@engg_process_name,
						@engg_component_name,	@tmp_derivedtype,		@tmp_ctrltype,		@tmp_taskdesc,
						'Y',					@tmp_tasktype)
		
			Exec ep_layout_save_events_gen 
				@ctxt_language,			@ctxt_ouinstance,		@ctxt_service,			@ctxt_user,			@engg_customer_name,
				@engg_project_name,		@engg_process_name,		@engg_component_name,	@engg_activity_name,@engg_ui_name,		
				@engg_page_name,		@engg_section_name,		@engg_control_name,		'BASE',				@tmp_derivedtype,
				@tmp_ctrltype,			@tmp_tasktype,			@tmp_taskdesc,	--TECH-75230
				@m_errorid out			

		END

		If not exists ( select	'X' from ep_component_glossary_mst (nolock)
			where	customer_name   = @engg_customer_name
			And		project_name	= @engg_project_name
			And		process_name	= @engg_process_name
			And		component_name  = @engg_component_name
			And		bt_synonym_name	= @tmp_controlbtsynonym)
			Begin

		exec ep_component_glossary_mst_sp_ins
											@ctxt_language,
											@ctxt_ouinstance,
											@ctxt_service,
											@ctxt_user,
											@engg_customer_name,
											@engg_project_name,									
											'BASE',
											@engg_process_name,
											@engg_component_name,
											@tmp_controlbtsynonym,
											'',
											'Char',
											@tmp_btLength ,
											@tmp_controlbtsynonym ,
											@tmp_controlbtsynonym ,
											@tmp_btname ,
											'U',
											'',
											'',
											1,
											@engg_req_no,
											@m_errorid out
			end
	Fetch Next from controlcur into @tmp_viewname , @tmp_viewcaption, @tmp_ctrltype, @tmp_remarks, @tmp_prefix,	@tmp_suffix, @tmp_seqno,
				@taskreqd,	@tmp_btname,	@tmp_renderas
		
	end
	close controlcur
	deallocate controlcur

	SET NOCOUNT OFF
END

GO
IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME= 'ep_controlcreation_sp' AND TYPE='P')
BEGIN
	GRANT EXEC ON  ep_controlcreation_sp TO PUBLIC
END
GO 
