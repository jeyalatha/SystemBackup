IF EXISTS(SELECT 'X' From SYSOBJECTS WHERE NAME ='ep_maireeSpCGDefHdrSav' AND TYPE='P')
   BEGIN
        DROP PROC ep_maireeSpCGDefHdrSav
   END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		ep_maireeSpCGDefHdrSav.sql
********************************************************************************/
/******************************************************************************/
/* Procedure					: ep_maireeSpCGDefHdrSav								 */
/* Description					: 								 */
/******************************************************************************/
/* Project						: 								 */
/* EcrNo						: 								 */
/* Version						: 								 */
/******************************************************************************/
/* Referenced					: 								 */
/* Tables						: 								 */
/******************************************************************************/
/* Development history			: 								 */
/******************************************************************************/
/* Author						: ModelExplorer								 */
/* Date							: May 31 2016  3:36PM								 */
/******************************************************************************/
/* Modification History			: 								 */
/******************************************************************************/
/* modified by			Date				Defect ID							*/
/* Veena U				08-Jun-2016			PLF2.0_18487						*/
/********************************************************************************/
/* Modified by : Jeya Latha K/Ganesh Prabhu S	for callid TECH-7349				*/
/* Modified on : 14-03-2017				 											*/
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and New Feature Organization chart */
/**************************************************************************************************************/
/* Modified by			: Priyadharshini U																	  */
/* Date					: 22-Nov-2022																		  */
/* Defect ID			: TECH-75230																		  */
/**************************************************************************************************************/
alter PROCEDURE ep_maireeSpCGDefHdrSav
	@ctxt_ouinstance ctxt_ouinstance, --Input 
	@ctxt_user ctxt_user, --Input 
	@ctxt_language ctxt_language, --Input 
	@ctxt_service ctxt_service, --Input 
	@engg_act_descr engg_description, --Input 
	@engg_component engg_description, --Input 
	@engg_control_name engg_name, --Input 
	@engg_customer_name engg_name, --Input 
	@engg_group_caption engg_description, --Input 
	@engg_group_name engg_name, --Input 
	@engg_group_seq engg_seqno, --Input 
	@engg_page_name engg_name, --Input 
	@engg_process_descr engg_description, --Input 
	@engg_project_name engg_name, --Input 
	@engg_req_no engg_name, --Input 
	@engg_rf_act engg_description, --Input 
	@engg_rf_comp engg_description, --Input 
	@engg_rf_ui engg_description, --Input 
	@engg_sect_name engg_name, --Input 
	@engg_ui_descr engg_description, --Input 
	@m_errorid INT OUTPUT --To Return Execution Status
AS
BEGIN
	-- nocount should be switched on to prevent phantom rows
	SET NOCOUNT ON
	-- @m_errorid should be 0 to Indicate Success
	SET @m_errorid = 0
	--declaration of temporary variables
	--temporary and formal parameters mapping
	SET @ctxt_user = ltrim(rtrim(@ctxt_user))
	SET @ctxt_service = ltrim(rtrim(@ctxt_service))
	SET @engg_act_descr = ltrim(rtrim(@engg_act_descr))
	SET @engg_component = ltrim(rtrim(@engg_component))
	SET @engg_control_name = ltrim(rtrim(@engg_control_name))
	SET @engg_customer_name = ltrim(rtrim(@engg_customer_name))
	SET @engg_group_caption = ltrim(rtrim(@engg_group_caption))
	SET @engg_group_name = ltrim(rtrim(@engg_group_name))
	SET @engg_page_name = ltrim(rtrim(@engg_page_name))
	SET @engg_process_descr = ltrim(rtrim(@engg_process_descr))
	SET @engg_project_name = ltrim(rtrim(@engg_project_name))
	SET @engg_req_no = ltrim(rtrim(@engg_req_no))
	SET @engg_rf_act = ltrim(rtrim(@engg_rf_act))
	SET @engg_rf_comp = ltrim(rtrim(@engg_rf_comp))
	SET @engg_rf_ui = ltrim(rtrim(@engg_rf_ui))
	SET @engg_sect_name = ltrim(rtrim(@engg_sect_name))
	SET @engg_ui_descr = ltrim(rtrim(@engg_ui_descr))

	--null checking
	IF @ctxt_ouinstance = - 915
		SELECT @ctxt_ouinstance = NULL

	IF @ctxt_user = '~#~'
		SELECT @ctxt_user = NULL

	IF @ctxt_language = - 915
		SELECT @ctxt_language = NULL

	IF @ctxt_service = '~#~'
		SELECT @ctxt_service = NULL

	IF @engg_act_descr = '~#~'
		SELECT @engg_act_descr = NULL

	IF @engg_component = '~#~'
		SELECT @engg_component = NULL

	IF @engg_control_name = '~#~'
		SELECT @engg_control_name = NULL

	IF @engg_customer_name = '~#~'
		SELECT @engg_customer_name = NULL

	IF @engg_group_caption = '~#~'
		SELECT @engg_group_caption = NULL

	IF @engg_group_name = '~#~'
		SELECT @engg_group_name = NULL

	IF @engg_group_seq = - 915
		SELECT @engg_group_seq = NULL

	IF @engg_page_name = '~#~'
		SELECT @engg_page_name = NULL

	IF @engg_process_descr = '~#~'
		SELECT @engg_process_descr = NULL

	IF @engg_project_name = '~#~'
		SELECT @engg_project_name = NULL

	IF @engg_req_no = '~#~'
		SELECT @engg_req_no = NULL

	IF @engg_rf_act = '~#~'
		SELECT @engg_rf_act = NULL

	IF @engg_rf_comp = '~#~'
		SELECT @engg_rf_comp = NULL

	IF @engg_rf_ui = '~#~'
		SELECT @engg_rf_ui = NULL

	IF @engg_sect_name = '~#~'
		SELECT @engg_sect_name = NULL

	IF @engg_ui_descr = '~#~'
		SELECT @engg_ui_descr = NULL

	DECLARE @tmp_proc engg_name,
		@tmp_comp engg_name,
		@tmp_act engg_name,
		@tmp_ui engg_name,
		@engg_base_req_no engg_name,
		@ref_comp_name_tmp engg_name,
		@ref_act_name_tmp engg_name,
		@ref_ui_name_tmp engg_name,
		@group_name engg_name,
		@group_caption engg_description,
		@column_bt_synonym engg_name,
		@seqno engg_seqno,
		@mapped_ent engg_name

	SELECT @engg_base_req_no = 'BASE'

	SELECT @tmp_proc = process_name
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND req_no = @engg_req_no
		AND process_descr = @engg_process_descr

	SELECT @tmp_comp = Component_name
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND req_no = @engg_req_no
		AND process_name = @tmp_proc
		AND component_descr = @engg_component

	SELECT @tmp_act = activity_name
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND req_no = @engg_req_no
		AND process_name = @tmp_proc
		AND component_name = @tmp_comp
		AND activity_descr = @engg_act_descr

	SELECT @tmp_ui = ui_name
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND process_name = @tmp_proc
		AND req_no = @engg_req_no
		AND component_name = @tmp_comp
		AND activity_name = @tmp_act
		AND ui_descr = @engg_ui_descr

	IF EXISTS (
			SELECT 'x'
			FROM ep_ui_req_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_req_no
				AND process_name = @tmp_proc
				AND component_name = @tmp_comp
				AND activity_name = @tmp_act
				AND ui_name = @tmp_ui
				AND req_status = 'P'
			)
	BEGIN
		RAISERROR (
				'Cannot default as Selected UI is in published status',
				16,
				4
				)

		RETURN
	END

	SELECT @ref_comp_name_tmp = rtrim(component_name)
	FROM Fw_BPT_RE_NameDesc_Vw(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND component_descr = rtrim(@engg_rf_comp)

	SELECT @ref_act_name_tmp = rtrim(activity_name)
	FROM Fw_BPT_RE_NameDesc_Vw(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND component_name = rtrim(@ref_comp_name_tmp)
		AND activity_descr = rtrim(@engg_rf_act)

	SELECT @ref_ui_name_tmp = rtrim(ui_name)
	FROM Fw_BPT_RE_NameDesc_Vw(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND component_name = rtrim(@ref_comp_name_tmp)
		AND activity_name = rtrim(@ref_act_name_tmp)
		AND ui_descr = rtrim(@engg_rf_ui)

	IF rtrim(@engg_act_descr) IS NULL
	BEGIN
		RAISERROR (
				'Select Activity',
				16,
				4
				)

		RETURN
	END

	IF rtrim(@engg_ui_descr) IS NULL
	BEGIN
		RAISERROR (
				'Select User Interface',
				16,
				4
				)

		RETURN
	END

	IF rtrim(@engg_page_name) IS NULL
	BEGIN
		RAISERROR (
				'Select Page (BT Synonym)',
				16,
				4
				)

		RETURN
	END

	IF rtrim(@engg_sect_name) IS NULL
	BEGIN
		RAISERROR (
				'Select Section (BT Synonym)',
				16,
				4
				)

		RETURN
	END

	IF rtrim(@engg_control_name) IS NULL
	BEGIN
		RAISERROR (
				'Select Control (BT Synonym)',
				16,
				4
				)

		RETURN
	END

	IF rtrim(@engg_rf_ui) IS NULL
	BEGIN
		RAISERROR (
				'Reference UI does not exist for the selected UI %s',
				16,
				4,
				@engg_ui_descr
				)

		RETURN
	END

	IF EXISTS (
			SELECT 'X'
			FROM ep_ui_columngroup --_dtl (nolock)
			WHERE customer_name = rtrim(@engg_customer_name)
				AND project_name = rtrim(@engg_project_name)
				AND component_name = rtrim(@ref_comp_name_tmp)
				AND activity_name = rtrim(@ref_act_name_tmp)
				AND ui_name = rtrim(@ref_ui_name_tmp)
				AND page_bt_synonym = rtrim(@engg_page_name)
				AND section_bt_synonym = rtrim(@engg_sect_name)
				AND grid_control_bt_synonym = rtrim(@engg_control_name)
			)
	BEGIN
		SELECT @engg_control_name = rtrim(@engg_control_name)
	END
	ELSE
	BEGIN
		RAISERROR (
				'Page %s -Section %s -Control %s combination does not match in Reference UI',
				16,
				4,
				@engg_page_name,
				@engg_sect_name,
				@engg_control_name
				)

		RETURN
	END

	IF (
			SELECT count('x')
			FROM ep_ui_columngroup(NOLOCK)
			WHERE customer_name = rtrim(@engg_customer_name)
				AND project_name = rtrim(@engg_project_name)
				AND component_name = rtrim(@tmp_comp)
				AND activity_name = rtrim(@tmp_act)
				AND ui_name = rtrim(@tmp_ui)
				AND page_bt_synonym = rtrim(@engg_page_name)
				AND section_bt_synonym = rtrim(@engg_sect_name)
				AND grid_control_bt_synonym = rtrim(@engg_control_name)
			) <> 0
	BEGIN
		RAISERROR (
				'Default from Reference UI cannot be done as there are Groups defined for this Grid Control already',
				16,
				4
				)

		RETURN
	END

	DECLARE insert_Grp_cur INSENSITIVE CURSOR
	FOR
	SELECT DISTINCT Group_name,
		Group_caption
	FROM ep_ui_columngroup grp(NOLOCK)
	WHERE grp.customer_name = @engg_customer_name
		AND grp.project_name = @engg_project_name
		AND grp.component_name = @ref_comp_name_tmp
		AND grp.activity_name = @ref_act_name_tmp
		AND grp.ui_name = @ref_ui_name_tmp
		AND grp.page_bt_synonym = @engg_page_name
		AND grp.section_bt_synonym = @engg_sect_name
		AND grp.grid_control_bt_synonym = @engg_control_name

	OPEN insert_Grp_cur

	WHILE (1 = 1)
	BEGIN
		FETCH NEXT
		FROM insert_Grp_cur
		INTO @group_name,
			@group_caption

		IF @@fetch_status <> 0
			BREAK

		IF EXISTS (
				SELECT 'X'
				FROM ep_ui_section_dtl(NOLOCK)
				WHERE customer_name = rtrim(@engg_customer_name)
					AND project_name = rtrim(@engg_project_name)
					AND process_name = rtrim(@tmp_proc)
					AND component_name = rtrim(@tmp_comp)
					AND activity_name = rtrim(@tmp_act)
					AND ui_name = rtrim(@tmp_ui)
					AND section_bt_synonym = rtrim(@group_name)
				)
		BEGIN
			RAISERROR (
					'Default from Refrence UI Cannot be performed as Group Name "%s" already exists as a Section(BT Synonym) in the UI',
					16,
					4,
					@group_name
					)

			RETURN
		END

		IF EXISTS (
				SELECT 'X'
				FROM ep_ui_control_dtl(NOLOCK)
				WHERE customer_name = rtrim(@engg_customer_name)
					AND project_name = rtrim(@engg_project_name)
					AND process_name = rtrim(@tmp_proc)
					AND component_name = rtrim(@tmp_comp)
					AND activity_name = rtrim(@tmp_act)
					AND ui_name = rtrim(@tmp_ui)
					AND control_bt_synonym = rtrim(@group_name)
				)
		BEGIN
			RAISERROR (
					'Default from Refrence UI Cannot be performed as Group Name "%s" already exists as a Control(BT Synonym) in the UI',
					16,
					4,
					@group_name
					)

			RETURN
		END

		IF EXISTS (
				SELECT 'X'
				FROM ep_ui_grid_dtl(NOLOCK)
				WHERE customer_name = rtrim(@engg_customer_name)
					AND project_name = rtrim(@engg_project_name)
					AND process_name = rtrim(@tmp_proc)
					AND component_name = rtrim(@tmp_comp)
					AND activity_name = rtrim(@tmp_act)
					AND ui_name = rtrim(@tmp_ui)
					AND column_bt_synonym = rtrim(@group_name)
				)
		BEGIN
			RAISERROR (
					'Default from Refrence UI Cannot be performed as Group Name "%s" already exists as a Grid(BT Synonym) in the UI',
					16,
					4,
					@group_name
					)

			RETURN
		END

		IF EXISTS (
				SELECT 'X'
				FROM de_hidden_view(NOLOCK)
				WHERE customer_name = rtrim(@engg_customer_name)
					AND project_name = rtrim(@engg_project_name)
					AND process_name = rtrim(@tmp_proc)
					AND component_name = rtrim(@tmp_comp)
					AND activity_name = rtrim(@tmp_act)
					AND ui_name = rtrim(@tmp_ui)
					AND hidden_view_bt_synonym = rtrim(@group_name)
				)
		BEGIN
			RAISERROR (
					'Default from Refrence UI Cannot be performed as Group Name "%s" already exists as a Hidden View(BT Synonym) in the UI',
					16,
					4,
					@group_name
					)

			RETURN
		END

		IF EXISTS (
				SELECT 'X'
				FROM de_scratch_variable(NOLOCK)
				WHERE customer_name = rtrim(@engg_customer_name)
					AND project_name = rtrim(@engg_project_name)
					AND process_name = rtrim(@tmp_proc)
					AND component_name = rtrim(@tmp_comp)
					AND activity_name = rtrim(@tmp_act)
					AND ui_name = rtrim(@tmp_ui)
					AND scratch_name = rtrim(@group_name)
				)
		BEGIN
			RAISERROR (
					'Default from Refrence UI Cannot be performed as Group Name "%s" already exists as a User Defined Scratch Variable in the UI',
					16,
					4,
					@group_name
					)

			RETURN
		END

		IF EXISTS (
				SELECT 'x'
				FROM de_scratch_variables_sys(NOLOCK)
				WHERE btsynonym = @group_name
				)
			OR @group_name = 'Modeflag'
		BEGIN
			RAISERROR (
					'Default from Refrence UI Cannot be performed as Group Name "%s" already exists as a Default Scratch Variable',
					16,
					4,
					@group_name
					)

			RETURN
		END

		IF EXISTS (
				SELECT 'X'
				FROM ep_listedit_column_dtl(NOLOCK)
				WHERE customer_name = rtrim(@engg_customer_name)
					AND project_name = rtrim(@engg_project_name)
					AND process_name = rtrim(@tmp_proc)
					AND component_name = rtrim(@tmp_comp)
					AND activity_name = rtrim(@tmp_act)
					AND ui_name = rtrim(@tmp_ui)
					AND listedit_column_synonym = rtrim(@group_name)
				)
		BEGIN
			RAISERROR (
					'Default from Refrence UI Cannot be performed as Group Name "%s" already exists as a List Edit Column Name in the UI',
					16,
					4,
					@group_name
					)

			RETURN
		END

		IF EXISTS (
				SELECT 'x'
				FROM ep_ui_columngroup(NOLOCK)
				WHERE customer_name = rtrim(@engg_customer_name)
					AND project_name = rtrim(@engg_project_name)
					AND process_name = rtrim(@tmp_proc)
					AND component_name = rtrim(@tmp_comp)
					AND activity_name = rtrim(@tmp_act)
					AND ui_name = rtrim(@tmp_ui)
					AND group_name = RTRIM(@group_name)
				)
		BEGIN
			RAISERROR (
					'Default from Refrence UI Cannot be performed as The Group Name "%s" already exists in the UI.',
					16,
					4,
					@group_name
					)

			RETURN
		END

		INSERT INTO ep_ui_columngroup (
			customer_name,
			project_name,
			req_no,
			process_name,
			component_name,
			activity_name,
			ui_name,
			Page_bt_synonym,
			section_bt_synonym,
			grid_control_bt_synonym,
			Group_name,
			Group_caption,
			wrkreqno,
			TIMESTAMP,
			createdby,
			createddate,
			modifiedby,
			modifieddate
			)
		SELECT @engg_customer_name,
			@engg_project_name,
			@engg_base_req_no,
			@tmp_proc,
			@tmp_comp,
			@tmp_act,
			@tmp_ui,
			@engg_page_name,
			@Engg_sect_name,
			@engg_control_name,
			@group_name,
			@group_caption,
			@engg_req_no,
			1,
			@ctxt_user,
			GETDATE(),
			@ctxt_user,
			GETDATE()
			--TECH-75230
		--IF NOT EXISTS (
		--		SELECT 'x'
		--		FROM ep_component_glossary_mst(NOLOCK)
		--		WHERE customer_name = @engg_customer_name
		--			AND project_name = @engg_project_name
		--			AND req_no = @engg_base_req_no
		--			AND process_name = @tmp_proc
		--			AND component_name = @tmp_comp
		--			AND bt_synonym_name = @column_bt_synonym
		--		)
		--BEGIN
		--	EXEC ep_component_glossary_mst_sp_ins @ctxt_language,
		--		@ctxt_ouinstance,
		--		@ctxt_service,
		--		@ctxt_user,
		--		@engg_customer_name,
		--		@engg_project_name,
		--		@engg_base_req_no,
		--		@tmp_proc,
		--		@tmp_comp,
		--		@Group_name,
		--		NULL,
		--		'Char',
		--		NULL,
		--		@group_caption,
		--		@Group_name,
		--		'',
		--		'U',
		--		'',
		--		'',
		--		1,
		--		@engg_req_no,
		--		@m_errorid OUTPUT
		--TECH-75230
			IF @m_errorid <> 0
			BEGIN
				CLOSE insert_Grp_cur

				DEALLOCATE insert_Grp_cur

				RETURN
			END
		END
	END

	CLOSE insert_Grp_cur

	DEALLOCATE insert_Grp_cur

	DECLARE insert_ColGrp_cur INSENSITIVE CURSOR
	FOR
	SELECT DISTINCT Group_name,
		column_bt_synonym,
		SequenceNo,
		mapped_entity
	FROM ep_ui_column_group_mapping grp(NOLOCK)
	WHERE grp.customer_name = @engg_customer_name
		AND grp.project_name = @engg_project_name
		AND grp.component_name = @ref_comp_name_tmp
		AND grp.activity_name = @ref_act_name_tmp
		AND grp.ui_name = @ref_ui_name_tmp
		AND grp.page_bt_synonym = @engg_page_name
		AND grp.section_bt_synonym = @engg_sect_name
		AND grp.grid_control_bt_synonym = @engg_control_name

	OPEN insert_ColGrp_cur

	WHILE (1 = 1)
	BEGIN
		FETCH NEXT
		FROM insert_ColGrp_cur
		INTO @group_name,
			@column_bt_synonym,
			@seqno,
			@mapped_ent

		IF @@fetch_status <> 0
			BREAK

		INSERT INTO ep_ui_column_group_mapping (
			customer_name,
			project_name,
			req_no,
			process_name,
			component_name,
			activity_name,
			ui_name,
			Page_bt_synonym,
			section_bt_synonym,
			grid_control_bt_synonym,
			Group_name,
			column_bt_synonym,
			SequenceNo,
			mapped_entity,
			wrkreqno,
			TIMESTAMP,
			createdby,
			createddate,
			modifiedby,
			modifieddate
			)
		SELECT @engg_customer_name,
			@engg_project_name,
			@engg_base_req_no,
			@tmp_proc,
			@tmp_comp,
			@tmp_act,
			@tmp_ui,
			@engg_page_name,
			@engg_sect_name,
			@engg_control_name,
			@group_name,
			@column_bt_synonym,
			@Seqno,
			@mapped_ent,
			@engg_req_no,
			1,
			@ctxt_user,
			GETDATE(),
			@ctxt_user,
			GETDATE()
	END
	--TECH-75230
		IF NOT EXISTS (
				SELECT 'x'
				FROM ep_component_glossary_mst(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND bt_synonym_name = @column_bt_synonym
				)
		BEGIN
			EXEC ep_component_glossary_mst_sp_ins @ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@engg_customer_name,
				@engg_project_name,
				@engg_base_req_no,
				@tmp_proc,
				@tmp_comp,
				@Group_name,
				NULL,
				'Char',
				--NULL,
				255,	--TECH-75230
				@group_caption,
				@Group_name,
				'',
				'U',
				'',
				'',
				1,
				@engg_req_no,
				@m_errorid OUTPUT
				--TECH-75230
	CLOSE insert_ColGrp_cur

	DEALLOCATE insert_ColGrp_cur

	/* 
	--OutputList
		Select
		null 'fprowno', 
	*/
	SET NOCOUNT OFF
END

GO
IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME= 'ep_maireeSpCGDefHdrSav' AND TYPE='P')
BEGIN
	GRANT EXEC ON  ep_maireeSpCGDefHdrSav TO PUBLIC
END
GO  