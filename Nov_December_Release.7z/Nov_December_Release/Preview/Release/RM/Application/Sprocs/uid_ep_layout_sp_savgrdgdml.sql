IF EXISTS(SELECT 'X' From SYSOBJECTS WHERE NAME ='uid_ep_layout_sp_savgrdgdml' AND TYPE='P')
   BEGIN
        DROP PROC uid_ep_layout_sp_savgrdgdml
   END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	25 Sep 2019
Purpose 		uid_ep_layout_sp_savgrdgdml.sql
********************************************************************************/
/*      V E R S I O N      :  2.0.4    */
/*      Released By        :  PTech    */
/*      Release Comments   :  Released on 22-12-2004 (Patch Release 1)    */
/*      V E R S I O N      :  2.0.2    */
/*      Released By        :  PTech    */
/*      Release Comments   :  Released on  22-Jan-2004    */
/****** Object:  Stored Procedure dbo.uid_ep_layout_sp_savgrdgdml    Script Date: 11/6/03 5:21:04 PM ******/
/************************************************************************************
procedure name and id :uid_ep_layout_sp_savgrdgdml
description             :Service the Save Task in GridContents Save, Validating and
Saving the ML Values
name of the author      :Madugula Srinivas
date created            :22-Oct-2003
query file name         :uid_ep_layout_sp_savgrdgdml.sql
method name  :ep_layout_mt_savgrdgdml
modifications history   :
modified by             Shafina Begum.B
modified date           13-jan-2004
modified purpose        to change the length of bt synonym
modified by             Shafina Begum.B
modified date           13-jan-2004
modified purpose        to change the length of bt synonym
modified by             Shafina Begum.B
modified date           17-jan-2004
modified purpose        to fetch the task name based on the default_for column
to insert the primary control_bts
modified by             Shafina Begum.B
modified date           21-jan-2004
modified purpose        to insert the control_id correctly
modified by             Balaji S
modified date           06-Aug-2005
modified purpose        Validation to be added For not to add Label in Grid(Platform_2.0.3.X_55)
************************************************************************************/
/*modified by             Sangeetha L         */
/*modified date           24-Aug-2005         */
/*modified purpose       Validation added for KEYWORD NOT ALLOWED AS A PARAMETER   */
/***********************************************************************************/
/*modified by             Chanheetha N A                                           */
/*modified date           29-Nov-2005                                              */
/*modified purpose        Validation To Display the Column Name which is a keyword*/
/*BugId             PNR2.0_4824                                                */
/*modified by             Gowrisankar M  for PNR2.0_4942
modified date           13-Dec-2005
modified purpose        Validation to be added for default dataitems not to be defined as BT Synonym */
/***********************************************************************************/
/* modified by  : Balaji S                                                    */
/* date         : 29-JUN-2006                                                    */
/* Bug Id  : PNR2.0_9131       */
/* Description  : New Base Control Type Label */
/********************************************************************************/
/* Modified by  : kiruthika R             */
/* Date         : 25-Aug-2006                                                   */
/* Bug ID       : PNR2.0_10027             */
/********************************************************************************/
/* modified by  : Anuradha M                                                    */
/* date         : 06-Nov-2006                                                   */
/* description  : PNR2.0_10832                                                  */
/********************************************************************************/
/* modified by  : Chanheetha N A                                                */
/* date         : 15-Nov-2006                                                   */
/* description  : PNR2.0_11000                                                  */
/********************************************************************************/
/* modified by   : Chanheetha N A        */
/* date     : 17-nov-2007         */
/* BugId    : PNR2.0_16023          */
/************************************************************************/
/* modified by  : Feroz                   */
/* date      : 25-07-2008                  */
/* BugId     : PNR2.0_18706                  */
/************************************************************************/
/* modified by   : Feroz           */
/* date     : 25-nov-2008         */
/* BugId    : PNR2.0_1790          */
/************************************************************************/
/* modified by  : Sangeetha G                                                       */
/* date         : 15-Apr-2009                                                                    */
/* Bug Id       : PNR2.0_21576                                         */
/* Modification : To include the gridlite property for grid type controls       */
/**************************************************************************************************/
/* modified by  : Feroz                                                */
/* date         : 04-Aug-2009                                                   */
/* Bug Id   : PNR2.0_2179             */
/* Description  : Phase 3 Features - ListEdit, AttachDocument, Image & DateHighlight */
/********************************************************************************/
/* modified by  : Gopinath S                            */
/* date         : 05-Nov-2009                                                   */
/* Bug Id  : PNR2.0_24645       */
/* Description  : state column no's are repeating and it is not in order */
/********************************************************************************/
/* modified by  : Chanheetha N A                           */
/* date         : 14-Dec-2009                                                   */
/* Bug Id  : PNR2.0_25211       */
/* Description  : Conversion failed when converting the varchar value 'hhLineNo_Hidn' to data type int.  */
/*********************************************************************************************************/
/* Modified By     	: Sangeetha G           				*/
/* Date       	   	: 05-May-2010        					*/
/* BugID     		: PNR2.0_23541         					*/
/* Modified For     	: To set UserPreference through frontend in spec Layout */
/*      		  Inplace of SP - uid_ep_layout_sp_savgrdgdml		*/
/********************************************************************************/
/* Modified by  : Shakthi P                                                            */
/* Date         : 07-April-2011                                                        */
/* Description  : Validation for Listedit controls,while add,delete and update         */
/* CaseID       : PNR2.0_30886                                                         */
/***************************************************************************************/
/* modified by   : Sangeetha G											*/
/* date			 : 11-Apr-2011											*/
/* BugId		 : PNR2.0_30869											*/
/* modified for	 : Feature Release										*/
/****************************************************************************************/
/* modified by  :	Muthupandi S														*/
/* date         :	08-june-2011														*/
/* Bug ID		:	PNR2.0_31754         												*/
/* Description	:	Validation added to avoid ,   										*/
/*					deleting controls when the task by the control						*/
/*					is mapped as a page event" 											*/
/****************************************************************************************/
/* modified by  :	Muthupandi S														*/
/* date         :	25-July-2011														*/
/* Bug ID		:	PNR2.0_32543         												*/
/* Description	:	To add the validation to avoid deleting link controls,without		*/
/*					removing the Link - ezee view Sp 									*/
/*					mapping in specify ezee view link .		   							*/
/****************************************************************************************/
/* Modified by  : Shakthi P                                                             */
/* Date         : 03-August-2011                                                        */
/* Description  : Default can be set only to Edit/Combo columns                         */
/* CaseID       : PNR2.0_32759                                                          */
/****************************************************************************************/
/* Modified By	: Vignesh																*/
/* Date			: 29-Aug-2011															*/
/* BugId		: PNR2.0_32228 															*/
/****************************************************************************************/
/* Modified By	: Jeya Latha K															*/
/* Date			: 21-Sep-2011															*/
/* BugId		: PNR2.0_33469 															*/
/****************************************************************************************/
/* Modified By	: Balaji D  															*/
/* Date			: 18-Oct-2011															*/
/* BugId		: PNR2.0_33877															*/
/* Description	: Control having base control type as Datahayperlink is not				*/
/*				  listing in ezeeview screen											*/
/****************************************************************************************/
/* modified by	: Balaji D  			                                                */
/* date			: 10-jan-2012			                                                */
/* BugId		: PNR2.0_35200 			                                                */
/* Description	: Default cannot be set to DisplayOnly columns.					        */
/****************************************************************************************/
/* modified by  :	Gankan G															*/
/* date         :	03-Nov-2012											        		*/
/* Bug ID		:	PLF2.0_03057 														*/
/* Description	:	Code Modified to inlucde new ISList Box property					*/
/****************************************************************************************/
/* modified by  :	Gankan G															*/
/* date         :	03-Nov-2012											        		*/
/* Bug ID		:	PLF2.0_03114 														*/
/* Description	:	Code Modified to handle ISList Box property							*/
/****************************************************************************************/
/* modified by  :	Gankan G															*/
/* date         :	03-Dec-2013											        		*/
/* Bug ID		:	PLF2.0_06660 														*/
/* Description	:	Code changes to disable hiddencontrol insertion for Grid Defaulting	*/
/****************************************************************************************/
/* modified by  	: Kanagavel A             											*/
/* date         	: 03/06/2014            										*/
/* Description 	: if  BTSynonym Name already exists for another Page or Section or control or Grid Control, display error message  			  */
/***************************************************************************************************/
/* modified by  : Ganesh Prabhu S                                      						   */
/* date         : Oct 10 2014                                      							       */
/* BugId        : PLF2.0_09035                                          						   */
/* description  : Model changes for rowspan,colspan,IsStatic,IsCallout in  layout level            */
/***************************************************************************************************/
/* Modified by  : Veena U													    */
/* Date         : 25-Feb-2015                                                   */
/* Call ID		: PLF2.0_11499                                                  */
/********************************************************************************/
/* Modified by	:	Ponmalar A		 											*/
/* Modified on	:	08/07/2022				 									*/
/* Defect ID	:	Tech-70687													*/
/* Description	:	Tool and Toolbars											*/
/********************************************************************************/
/* Modified by  : Ponmalar A	Date: 24-Aug-2022  Defect ID : TECH-72114		*/
/********************************************************************************/
/* Modified by : Ponmalar A		Date: 02-Dec-2022  Defect ID : TECH-75230		*/
/********************************************************************************/
CREATE PROCEDURE uid_ep_layout_sp_savgrdgdml
	@ctxt_language ctxt_language, --Input 
	@ctxt_ouinstance ctxt_ouinstance, --Input 
	@ctxt_service ctxt_service, --Input 
	@ctxt_user ctxt_user, --Input 
	@engg_act_descr engg_description, --Input 
	@engg_col_descr engg_description, --Input 
	@engg_component engg_description, --Input 
	@engg_customer_name engg_name, --Input 
	@engg_enum_page_bts engg_name, --Input 
	@engg_enum_sec_bts engg_name, --Input 
	@engg_grid_btsynname engg_name, --Input 
	@engg_grid_colno engg_seqno, --Input 
	@engg_grid_doc engg_documentation, --Input 
	@engg_grid_elem_type engg_name, --Input 
	@engg_grid_grid_code engg_name, --Input 
	@engg_grid_page_bts engg_name, --Input 
	@engg_grid_samp_data engg_documentation, --Input 
	@engg_grid_sec_bts engg_name, --Input 
	@engg_grid_tooltip engg_documentation, --Input 
	@engg_grid_vis_length engg_length, --Input 
	@engg_process_descr engg_description, --Input 
	@engg_project_name engg_name, --Input 
	@engg_req_no engg_name, --Input 
	@engg_ui_descr engg_name, --Input 
	@guid guid, --Input 
	@modeflag modeflag, --Input 
	@engg_grid_default engg_flag, --Input 
	@fprowno rowno, --Input/Output
	@engg_del_columns engg_documentation, --Input/Output
	@engg_grd_visible engg_flag, --Input 
	@columnclass engg_name, --Input 
	--@columnheaderclass    	engg_name, --Input 
	@forcefit engg_flag, --Input 
	@set_user_pref_ml checkflag_int, --Input 
	@m_errorid INT OUTPUT --To Return Execution Status
AS
BEGIN
	-- nocount should be switched on to prevent phantom rows
	SET NOCOUNT ON
	-- @m_errorid should be 0 to Indicate Success
	SET @m_errorid = 0
	--declaration of temporary variables
	--temporary and formal parameters mapping
	SET @ctxt_service = ltrim(rtrim(@ctxt_service))
	SET @ctxt_user = ltrim(rtrim(@ctxt_user))
	SET @engg_act_descr = ltrim(rtrim(@engg_act_descr))
	SET @engg_col_descr = ltrim(rtrim(@engg_col_descr))
	SET @engg_component = ltrim(rtrim(@engg_component))
	SET @engg_customer_name = ltrim(rtrim(@engg_customer_name))
	SET @engg_enum_page_bts = ltrim(rtrim(@engg_enum_page_bts))
	SET @engg_enum_sec_bts = ltrim(rtrim(@engg_enum_sec_bts))
	SET @engg_grid_btsynname = ltrim(rtrim(@engg_grid_btsynname))
	SET @engg_grid_doc = ltrim(rtrim(@engg_grid_doc))
	SET @engg_grid_elem_type = ltrim(rtrim(@engg_grid_elem_type))
	SET @engg_grid_grid_code = ltrim(rtrim(@engg_grid_grid_code))
	SET @engg_grid_page_bts = ltrim(rtrim(@engg_grid_page_bts))
	SET @engg_grid_samp_data = ltrim(rtrim(@engg_grid_samp_data))
	SET @engg_grid_sec_bts = ltrim(rtrim(@engg_grid_sec_bts))
	SET @engg_grid_tooltip = ltrim(rtrim(@engg_grid_tooltip))
	SET @engg_process_descr = ltrim(rtrim(@engg_process_descr))
	SET @engg_project_name = ltrim(rtrim(@engg_project_name))
	SET @engg_req_no = ltrim(rtrim(@engg_req_no))
	SET @engg_ui_descr = ltrim(rtrim(@engg_ui_descr))
	SET @guid = ltrim(rtrim(@guid))
	SET @modeflag = ltrim(rtrim(@modeflag))
	SET @engg_grid_default = ltrim(rtrim(@engg_grid_default))
	SET @engg_del_columns = ltrim(rtrim(@engg_del_columns))
	SET @engg_grd_visible = ltrim(rtrim(@engg_grd_visible))
	SET @columnclass = ltrim(rtrim(@columnclass))
	--Set @columnheaderclass     = ltrim(rtrim(@columnheaderclass))
	SET @forcefit = ltrim(rtrim(@forcefit))

	--null checking
	IF @ctxt_language = - 915
		SELECT @ctxt_language = NULL

	IF @ctxt_ouinstance = - 915
		SELECT @ctxt_ouinstance = NULL

	IF @ctxt_service = '~#~'
		SELECT @ctxt_service = NULL

	IF @ctxt_user = '~#~'
		SELECT @ctxt_user = NULL

	IF @engg_act_descr = '~#~'
		SELECT @engg_act_descr = NULL

	IF @engg_col_descr = '~#~'
		SELECT @engg_col_descr = NULL

	IF @engg_component = '~#~'
		SELECT @engg_component = NULL

	IF @engg_customer_name = '~#~'
		SELECT @engg_customer_name = NULL

	IF @engg_enum_page_bts = '~#~'
		SELECT @engg_enum_page_bts = NULL

	IF @engg_enum_sec_bts = '~#~'
		SELECT @engg_enum_sec_bts = NULL

	IF @engg_grid_btsynname = '~#~'
		SELECT @engg_grid_btsynname = NULL

	IF @engg_grid_colno = - 915
		SELECT @engg_grid_colno = NULL

	IF @engg_grid_doc = '~#~'
		SELECT @engg_grid_doc = NULL

	IF @engg_grid_elem_type = '~#~'
		SELECT @engg_grid_elem_type = NULL

	IF @engg_grid_grid_code = '~#~'
		SELECT @engg_grid_grid_code = NULL

	IF @engg_grid_page_bts = '~#~'
		SELECT @engg_grid_page_bts = NULL

	IF @engg_grid_samp_data = '~#~'
		SELECT @engg_grid_samp_data = NULL

	IF @engg_grid_sec_bts = '~#~'
		SELECT @engg_grid_sec_bts = NULL

	IF @engg_grid_tooltip = '~#~'
		SELECT @engg_grid_tooltip = NULL

	IF @engg_grid_vis_length = - 915
		SELECT @engg_grid_vis_length = NULL

	IF @engg_process_descr = '~#~'
		SELECT @engg_process_descr = NULL

	IF @engg_project_name = '~#~'
		SELECT @engg_project_name = NULL

	IF @engg_req_no = '~#~'
		SELECT @engg_req_no = NULL

	IF @engg_ui_descr = '~#~'
		SELECT @engg_ui_descr = NULL

	IF @guid = '~#~'
		SELECT @guid = NULL

	IF @modeflag = '~#~'
		SELECT @modeflag = NULL

	IF @engg_grid_default = '~#~'
		SELECT @engg_grid_default = NULL

	IF @fprowno = - 915
		SELECT @fprowno = NULL

	IF @engg_del_columns = '~#~'
		SELECT @engg_del_columns = NULL

	IF @engg_grd_visible = '~#~'
		SELECT @engg_grd_visible = NULL

	IF @columnclass = '~#~'
		SELECT @columnclass = NULL

	--IF @columnheaderclass = '~#~' 
	--Select @columnheaderclass = null  
	IF @forcefit = '~#~'
		SELECT @forcefit = NULL

	IF @set_user_pref_ml = - 915
		SELECT @set_user_pref_ml = NULL

	DECLARE @component_name_tmp engg_name,
		@prc_name_tmp engg_name,
		@act_name_tmp engg_name,
		@ui_name_tmp engg_name,
		@vis_flag engg_flag,
		@allow_hdn_ctrl engg_description,
		@col_bt_syn_chk engg_name,
		@control_id_tmp engg_name,
		@count engg_name,
		@ctrl_bt_syn_id engg_name,
		@view_name engg_name,
		@event_req engg_flag,
		@help_req engg_flag,
		@old_help_req engg_flag,
		@zoom_req engg_flag,
		@editable engg_flag,
		@tmp_ctl engg_name,
		@page_prefix_tmp engg_name,
		@tmp_control_type engg_name,
		@viewname_tmp engg_name,
		@hview_name_tmp engg_name, /* PNR2.0_11000*/
		@rstr engg_name,
		@task_name engg_name,
		@vlen INT,
		@ccnt INT,
		@cstr engg_name,
		@grid_bt_caption engg_name,
		@base_ctrl_type_tmp engg_name,
		@enumcap engg_description,
		@spin_required engg_flag,
		@report_req engg_flag -- code modified by Anuradha on 06-Nov-2006 for the Bug ID :: PNR2.0_10832  
	DECLARE @error_tmp engg_rowno
	DECLARE @msg engg_documentation
	DECLARE @engg_base_req_no engg_name

	SELECT @engg_base_req_no = 'BASE'

	--  select @seq_no = 0  
	--Modification for PNR2.0_23541 starts  
	DECLARE @user_pref engg_flag

	IF isnull(@set_user_pref_ml, '') IN (
			'',
			0
			)
		SELECT @user_pref = 'Y'

	IF isnull(@set_user_pref_ml, '') = 1
		SELECT @user_pref = 'N'

	--Modification for PNR2.0_23541 ends  
	--Code Modification for PNR2.0_30869 starts  
	DECLARE @control_id engg_name
	DECLARE @grid_def engg_flag

	IF isnull(@engg_grid_default, '') = 1
		SELECT @grid_def = 'Y'
	ELSE
		SELECT @grid_def = 'N'

	--Code Modification for PNR2.0_30869 ends  
	/*Getting Process Name for incoming Process Desc.*/
	SELECT @prc_name_tmp = rtrim(process_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_req_no)
		AND process_descr = rtrim(@engg_process_descr)

	/*Getting Component Name for Given Component Description*/
	SELECT @component_name_tmp = rtrim(component_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_req_no)
		AND process_name = rtrim(@prc_name_tmp)
		AND component_descr = rtrim(@engg_component)

	/*Getting Activity Name for Activity Desc*/
	SELECT @act_name_tmp = rtrim(activity_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_req_no)
		AND process_name = rtrim(@prc_name_tmp)
		AND component_name = rtrim(@component_name_tmp)
		AND activity_descr = rtrim(@engg_act_descr)

	/*Getting UI Name for UI Desc*/
	SELECT @ui_name_tmp = rtrim(ui_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_req_no)
		AND process_name = rtrim(@prc_name_tmp)
		AND component_name = rtrim(@component_name_tmp)
		AND activity_name = rtrim(@act_name_tmp)
		AND ui_descr = rtrim(@engg_ui_descr)

	--GETTING THE CTRL NAME FOR THE DESCRIPTION  
	SELECT @tmp_ctl = base_ctrl_type,
		@help_req = help_req,
		@event_req = event_handling_req,
		@zoom_req = zoom_req,
		@editable = editable_flag,
		@spin_required = spin_required,
		@report_req = report_req -- code modified by Anuradha on 06-Nov-2006 for the Bug ID :: PNR2.0_10832  
	FROM es_comp_ctrl_type_mst_vw(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND process_name = rtrim(@prc_name_tmp)
		AND component_name = rtrim(@component_name_tmp)
		AND ctrl_type_name = rtrim(@engg_grid_elem_type)
		AND req_no = rtrim(@engg_base_req_no)

	-- Code Added for PNR2.0_32228 Starts  
	DECLARE @del_flag engg_flag

	--PLF2.0_03057 starts  
	IF EXISTS (
			SELECT 'x'
			FROM ep_ui_control_dtl a(NOLOCK),
				es_comp_ctrl_type_mst b(NOLOCK)
			WHERE a.customer_name = @engg_customer_name
				AND a.project_name = @engg_project_name
				AND a.process_name = @prc_name_tmp
				AND a.component_name = @component_name_tmp
				AND a.page_bt_synonym = @engg_grid_page_bts
				AND a.control_bt_synonym = @engg_grid_grid_code
				AND a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.control_type = b.ctrl_type_name
				AND b.base_ctrl_type = 'GRID'
				AND b.IsListBox = 'Y'
			)
	BEGIN
		IF NOT EXISTS (
				SELECT 'x' -- Code changes for PLF2.0_03114  
				FROM es_comp_ctrl_type_mst(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND ctrl_type_name = @engg_grid_elem_type
					AND base_ctrl_type IN (
						'link',
						'edit'
						)
					AND editable_flag = 'n'
				)
		BEGIN
			RAISERROR (
					'For the Grid with list box property selected, Only column types with displayonly and link can be added !.',
					16,
					1
					)

			RETURN
		END
	END

	--PLF2.0_03057 ends  
	SELECT @del_flag = 'F'

	IF @modeflag = 'D'
	BEGIN
		IF EXISTS (
				SELECT 'x'
				FROM de_fw_des_ilbo_Service_view_datamap(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ilbocode = @ui_name_tmp
					AND page_bt_synonym = @engg_grid_page_bts
					AND control_bt_synonym = @engg_grid_btsynname
					AND controlid = 'ML' + isnull(@engg_grid_grid_code, '')
				)
		BEGIN
			INSERT INTO ep_ui_control_del_dtl (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				control_type,
				req_no,
				guid,
				Deletion_type,
				controlid
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@prc_name_tmp,
				@component_name_tmp,
				@act_name_tmp,
				@ui_name_tmp,
				@engg_grid_page_bts,
				@engg_grid_sec_bts,
				@engg_grid_btsynname,
				@tmp_ctl,
				@engg_base_req_no,
				@guid,
				'Column',
				'ML' + isnull(@engg_grid_grid_code, '')
				)

			SELECT @del_flag = 'F'

			-- Code modified for Bug Id :PNR2.0_33469 Starts  
			IF isnull(@engg_del_columns, '') = ''
			BEGIN
				SELECT @engg_del_columns = @engg_grid_btsynname
			END
			ELSE
			BEGIN
				SELECT @engg_del_columns = isnull(@engg_del_columns, '') + ', ' + @engg_grid_btsynname
			END
					--select @m_errorid = 10001  
					--Raiserror ('This Column is used in one or more Service(s). Do you want to Delete', 16,1)  
					--Return  
					-- Code modified for Bug Id :PNR2.0_33469 Ends  
		END
		ELSE
		BEGIN
			SELECT @del_flag = 'T'
		END
	END

	-- Code Added for PNR2.0_32228 End  
	-- Code modification for PNR2.0_21576 starts  
	DECLARE @gridlite_req engg_name

	SELECT @gridlite_req = b.gridlite_req
	FROM ep_ui_control_dtl a(NOLOCK),
		es_comp_ctrl_type_mst_vw b(NOLOCK)
	WHERE a.customer_name = rtrim(@engg_customer_name)
		AND a.project_name = rtrim(@engg_project_name)
		AND a.req_no = rtrim(@engg_base_req_no)
		AND a.process_name = rtrim(@prc_name_tmp)
		AND a.component_name = rtrim(@component_name_tmp)
		AND a.activity_name = rtrim(@act_name_tmp)
		AND a.ui_name = rtrim(@ui_name_tmp)
		AND a.page_bt_synonym = rtrim(@engg_grid_page_bts)
		AND a.section_bt_synonym = rtrim(@engg_grid_sec_bts)
		AND a.control_bt_synonym = rtrim(@engg_grid_grid_code)
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.control_type = b.ctrl_type_name

	IF isnull(@gridlite_req, 'N') = 'Y'
	BEGIN
		IF isnull(@editable, 'N') = 'Y'
		BEGIN
			EXEC engg_error_sp 'uid_ep_layout_sp_savgrdgdml',
				1,
				'Grid with gridlite property enabled cannot have editable column. Check the Column',
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@engg_grid_btsynname,
				'',
				'',
				'',
				@m_errorid OUTPUT

			IF @m_errorid > 0
				RETURN
		END

		IF isnull(@help_req, 'N') = 'Y'
		BEGIN
			EXEC engg_error_sp 'uid_ep_layout_sp_savgrdgdml',
				1,
				'Grid with gridlite property enabled cannot have column associated with help task. Check the Column <%1>',
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@engg_grid_btsynname,
				'',
				'',
				'',
				@m_errorid OUTPUT

			IF @m_errorid > 0
				RETURN
		END
	END

	-- Code modification for PNR2.0_21576 ends  
	-- Added by JL  
	IF EXISTS (
			SELECT 'X'
			FROM es_comp_ctrl_type_mst_vw(NOLOCK)
			WHERE customer_name = rtrim(@engg_customer_name)
				AND project_name = rtrim(@engg_project_name)
				AND process_name = rtrim(@prc_name_tmp)
				AND component_name = rtrim(@component_name_tmp)
				-- code modfied by feroz for bug id: PNR2.0_18706  
				--   and    @tmp_ctl     =  'Edit'  
				AND ctrl_type_name = rtrim(@engg_grid_elem_type)
				AND InPlace_Calendar = 'Y'
			)
	BEGIN
		RAISERROR (
				'Inplace Calendar property is applicable only for Header controls.',
				16,
				1
				)

		RETURN
	END

	/* Code added for the Case ID:PNR2.0_32759 By Shakthi P begins*/
	IF @engg_grid_default = '1'
	BEGIN
		IF EXISTS (
				SELECT 'X'
				FROM es_comp_ctrl_type_mst_vw(NOLOCK)
				WHERE customer_name = rtrim(@engg_customer_name)
					AND project_name = rtrim(@engg_project_name)
					AND process_name = rtrim(@prc_name_tmp)
					AND component_name = rtrim(@component_name_tmp)
					AND ctrl_type_name = rtrim(@engg_grid_elem_type)
					AND base_ctrl_type IN (
						'Edit',
						'Combo'
						)
					--and   (editable_flag  = 'N' or help_req        ='Y'))--Bug ID:PNR2.0_35200  
					AND editable_flag = 'N'
				)
		BEGIN
			--Raiserror ('Default cannot be set to DisplayOnly/Help event associated columns.',16,1)  
			RAISERROR (
					'Default cannot be set to DisplayOnly columns.',
					16,
					1
					) --Bug ID:PNR2.0_35200  

			RETURN
		END
	END

	IF @engg_grid_default = '1'
	BEGIN
		IF EXISTS (
				SELECT 'X'
				FROM es_comp_ctrl_type_mst_vw(NOLOCK)
				WHERE customer_name = rtrim(@engg_customer_name)
					AND project_name = rtrim(@engg_project_name)
					AND process_name = rtrim(@prc_name_tmp)
					AND component_name = rtrim(@component_name_tmp)
					AND ctrl_type_name = rtrim(@engg_grid_elem_type)
					AND base_ctrl_type NOT IN (
						'Edit',
						'Combo'
						)
				)
		BEGIN
			RAISERROR (
					'Default can be set only to Edit/Combo columns.',
					16,
					1
					)

			RETURN
		END
	END

	/* Code added for the Case ID:PNR2.0_32759 By Shakthi P End*/
	-- Added BY Feroz For List Edit  
	IF EXISTS (
			SELECT 'X'
			FROM es_comp_ctrl_type_mst_vw(NOLOCK)
			WHERE customer_name = rtrim(@engg_customer_name)
				AND project_name = rtrim(@engg_project_name)
				AND process_name = rtrim(@prc_name_tmp)
				AND component_name = rtrim(@component_name_tmp)
				AND ctrl_type_name = rtrim(@engg_grid_elem_type)
				AND (
					listrefilltask_req = 'Y'
					OR onfocustask_req = 'Y'
					)
			)
	BEGIN
		EXEC engg_error_sp 'uid_ep_layout_sp_savgrdgdml',
			5,
			'List Refill Task/Onfocus Task property is applicable only for Header controls',
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			@fprowno,
			'',
			'',
			'',
			@m_errorid OUTPUT

		IF @m_errorid > 0
			RETURN
	END

	-- Added BY Feroz For List Edit  
	-- Added by feroz for static  
	IF EXISTS (
			SELECT 'x'
			FROM es_comp_stat_ctrl_type_mst(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @prc_name_tmp
				AND component_name = @component_name_tmp
				AND ctrl_type_name = @engg_grid_elem_type
			)
	BEGIN
		IF isnull(@engg_grid_samp_data, '') <> ''
		BEGIN
			RAISERROR (
					'sample data is not applicable for static control types',
					16,
					1
					)

			RETURN
		END

		SELECT @event_req = handle_events,
			@tmp_ctl = base_ctrl_type
		FROM es_comp_stat_ctrl_type_mst(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND process_name = @prc_name_tmp
			AND component_name = @component_name_tmp
			AND ctrl_type_name = @engg_grid_elem_type
	END

	-- code added by Feroz for Ext js -- PNR2.0_1790  
	IF @modeflag IN (
			'U',
			'Y',
			'I',
			'X',
			'D'
			)
	BEGIN
		IF EXISTS (
				SELECT 'x'
				FROM ep_ui_section_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = @engg_grid_page_bts
					AND section_bt_synonym = @engg_grid_sec_bts
					AND section_type IN (
						'Text Scroller',
						'Formatted Text',
						'Report List',
						'Property Window',
						'Pivot',
						'Tree Grid',
						'IFrame',
						'RSS Feed',
						'TextType Writer',
						'Marquee Ticker',
						'EMail',
						'Bar Code'
						)
					AND req_no = @engg_base_req_no
				)
		BEGIN
			RAISERROR (
					'Insertion/Modification/Deletion not allowed  for ExtensionJs Section',
					16,
					1
					)

			RETURN
		END
	END

	-- code added by Feroz for Ext js -- PNR2.0_1790  
	/*Modification made by Muthupandi S for Bug id : PNR2.0_31754 Starts*/
	IF @modeflag = 'D'
	BEGIN
		IF EXISTS (
				SELECT 'X'
				FROM ep_ui_pageevents_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND task_onclick IN (
						SELECT task_name
						FROM ep_action_mst(NOLOCK) /*Modification made by Muthupandi S for Bug id : PNR2.0_32543*/
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @prc_name_tmp
							AND component_name = @component_name_tmp
							AND activity_name = @act_name_tmp
							AND ui_name = @ui_name_tmp
							AND page_bt_synonym = @engg_grid_page_bts
							AND primary_control_bts = @engg_grid_btsynname
						)
				)
		BEGIN
			SELECT @msg = 'The task of the grid column ' + '"' + @engg_grid_btsynname + '"' + 'is used as a PageEvent.Hence Column cannot be deleted .Check Specify Page Events Link'

			RAISERROR (
					@msg,
					16,
					1
					)

			RETURN
		END
	END

	/*Modification made by Muthupandi S for Bug id : PNR2.0_31754 Ends*/
	/*Modification made by Muthupandi S for Bug id : PNR2.0_32543 Starts*/
	IF @modeflag = 'D'
	BEGIN
		IF EXISTS (
				SELECT 'X'
				FROM ep_layout_ezeeview_sp(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = @engg_grid_page_bts
					AND Link_ControlName = @engg_grid_btsynname
				)
		BEGIN
			SELECT @msg = 'The "Link" type column ' + '"' + @engg_grid_btsynname + '"' + ' is Mapped with an ezee view sp.Hence Column cannot be deleted .Check Specify ezee view Link'

			RAISERROR (
					@msg,
					16,
					1
					)

			RETURN
		END
	END

	/*Modification made by Muthupandi S for Bug id : PNR2.0_32543 Ends*/
	IF @tmp_ctl = 'Edit'
		AND @spin_required = 'y'
	BEGIN
		RAISERROR (
				'Column Type cannot be ''%s'' since Spin Required is checked',
				16,
				1,
				@engg_grid_elem_type
				)

		RETURN
	END

	/*Check null for column number*/
	IF rtrim(@engg_grid_colno) IS NULL
	BEGIN
		EXEC engg_error_sp 'uid_ep_layout_sp_savgrdgdml',
			9,
			'Column Number Cannot be Null for Column<%1>',
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			@engg_grid_btsynname,
			'',
			'',
			'',
			@m_errorid OUTPUT

		IF @m_errorid > 0
			RETURN
	END

	/*Check null for Control BT synonym*/
	IF rtrim(@engg_grid_btsynname) IS NULL
	BEGIN
		EXEC engg_error_sp 'uid_ep_layout_sp_savgrdgdml',
			1,
			'Column(BT Synonym) Cannot be Null at Row no<%1>',
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			@fprowno,
			'',
			'',
			'',
			@m_errorid OUTPUT

		IF @m_errorid > 0
			RETURN
	END

	/*Code Added For BugId : Platform_2.0.3.X_55*/
	--Code Modified For BugId : PNR2.0_9131  
	IF rtrim(@engg_grid_elem_type) = 'Label'
		OR @tmp_ctl = 'label'
	BEGIN
		EXEC engg_error_sp 'uid_ep_layout_sp_savgrdgdml',
			1,
			'Label Control at rowno <%1> is not allowed in Multiline',
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			@fprowno,
			'',
			'',
			'',
			@m_errorid OUTPUT

		IF @m_errorid > 0
			RETURN
	END

	--For each row, if Grid Column BTSynonym Name contains blank spaces , display error message.  
	SELECT @error_tmp = dbo.ep_check_spl_char(@engg_grid_btsynname)

	-- code modified by shafina on 12-May-2004 for PREVIEWENG203ACC_000058  
	IF @modeflag <> 'D'
	BEGIN
		IF @error_tmp = 1
		BEGIN
			SELECT @msg = 'BT Synonym for Column ' + @engg_grid_btsynname + ' contains special characters.'

			EXEC ENGG_ERROR_SP 'uid_ep_layout_sp_savgrdgdml',
				4,
				@msg,
				@CTXT_LANGUAGE,
				@CTXT_OUINSTANCE,
				@CTXT_SERVICE,
				@CTXT_USER,
				'',
				'',
				'',
				'',
				@M_ERRORID OUTPUT

			RETURN
		END

		--code modified by kiruthika for bugid:  PNR2.0_10027  
		IF rtrim(@engg_grid_btsynname) = 'HdnWFDocKey'
		BEGIN
			EXEC engg_error_sp 'uid_ep_layout_sp_savgrdgdml',
				1,
				'Column cannot have "HdnWFDocKey" as its BT Synonym.',
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@fprowno,
				'',
				'',
				'',
				@m_errorid OUTPUT

			IF @m_errorid > 0
				RETURN
		END

		IF rtrim(@engg_grid_btsynname) = 'HdnWFOrgUnit'
		BEGIN
			EXEC engg_error_sp 'uid_ep_layout_sp_savgrdgdml',
				1,
				'Column cannot have "HdnWFOrgUnit" as its BT Synonym.',
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@fprowno,
				'',
				'',
				'',
				@m_errorid OUTPUT

			IF @m_errorid > 0
				RETURN
		END

		--code modified by kiruthika for bugid:  PNR2.0_10027  
		-- code modified by shafina on 07-July-2004 for PREVIEWENG203ACC_000076  
		-- Length of the BT Synonym must not exceed 30 characters.  
		-- code modified by shafina on 19-Nov-2004 for PREVIEWENG203ACC_000076(Length of the BT Synonym must not exceed 28 characters)  
		IF len(rtrim(@engg_grid_btsynname)) > 28
		BEGIN
			EXEC engg_error_sp 'uid_ep_layout_sp_savgrdgdml',
				1,
				'Length of Column(BT Synonym) cannot be greater than 28 for Column<%1>',
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@engg_grid_btsynname,
				'',
				'',
				'',
				@m_errorid OUTPUT

			IF @m_errorid > 0
				RETURN
		END

		-- code modified by shafina on 11-Aug-2004 for checking whether FILLER is given as BTSynonym.- PREVIEWENG203ACC_000086  
		IF rtrim(@engg_grid_btsynname) = 'FILLER'
		BEGIN
			EXEC engg_error_sp 'uid_ep_layout_sp_savgrdgdml',
				1,
				'Column cannot have FILLER as its BT Synonym.',
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@fprowno,
				'',
				'',
				'',
				@m_errorid OUTPUT

			IF @m_errorid > 0
				RETURN
		END

		-- code added by Gowrisankar for PNR2.0_4942 on 13-Dec-2005  
		IF EXISTS (
				SELECT 'x'
				FROM re_quick_code_mst(NOLOCK)
				WHERE quick_code_type = 'RE_CONTEXT'
					AND quick_code_value = @engg_grid_btsynname
				)
		BEGIN
			SELECT @msg = 'Default dataitems can not be defined as Column BT Synonym for Column' + @engg_grid_btsynname

			EXEC engg_error_sp uid_ep_layout_sp_savgrdgdml,
				'1',
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			IF @m_errorid <> 0
				RETURN
		END -- code added by Gowrisankar for PNR2.0_4942 on 13-Dec-2005  
	END

	IF @modeflag IN (
			'X',
			'I'
			)
	BEGIN
		-- code modified by shafina on 25-Aug-2004 for PREVIEWENG203ACC_000093 ( When a control bt synonym / column bt synonym is repeated within a UI , it's length must not exceed 24 characters.)  
		IF EXISTS (
				SELECT 'X'
				FROM ep_ui_control_dtl(NOLOCK)
				WHERE customer_name = rtrim(@engg_customer_name)
					AND project_name = rtrim(@engg_project_name)
					AND req_no = rtrim(@engg_base_req_no)
					AND process_name = rtrim(@prc_name_tmp)
					AND component_name = rtrim(@component_name_tmp)
					AND activity_name = rtrim(@act_name_tmp)
					AND ui_name = rtrim(@ui_name_tmp)
					AND control_bt_synonym = rtrim(@engg_grid_btsynname)
				
				UNION
				
				SELECT 'X'
				FROM ep_ui_grid_dtl(NOLOCK)
				WHERE customer_name = rtrim(@engg_customer_name)
					AND project_name = rtrim(@engg_project_name)
					AND req_no = rtrim(@engg_base_req_no)
					AND process_name = rtrim(@prc_name_tmp)
					AND component_name = rtrim(@component_name_tmp)
					AND activity_name = rtrim(@act_name_tmp)
					AND ui_name = rtrim(@ui_name_tmp)
					AND column_bt_synonym = rtrim(@engg_grid_btsynname)
				)
			AND len(@engg_grid_btsynname) > 24
		BEGIN
			EXEC engg_error_sp 'uid_ep_layout_sp_savgrdgdml',
				2,
				'Column (BT Synonym):<%2> length must not exceed 24.',
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@fprowno,
				@engg_grid_btsynname,
				'',
				'',
				@m_errorid OUTPUT

			IF @m_errorid > 0
				RETURN
		END

		/*Check duplication of Column BT synonym within the Activity/UI/Page*/
		-- code commented by shafina on 16-Nov-2004 for PREVIEWENG203SYS_000178 (Unable to delete the controls in specifylayout. Platform has accepted same control name for both Page Name and controls. It didnt validate while creating, but on deletion it is validating)  
		/*  if exists (  
select 'X'  
from ep_ui_page_dtl (nolock)  
where customer_name = rtrim(@engg_customer_name)  
and  project_name = rtrim(@engg_project_name)  
and  req_no   = rtrim(@engg_base_req_no)  
and  process_name = rtrim(@prc_name_tmp)  
and  component_name = rtrim(@component_name_tmp)  
and  activity_name = rtrim(@act_name_tmp)  
and  ui_name   = rtrim(@ui_name_tmp)  
--    and  page_bt_synonym = rtrim(@engg_grid_page_bts)  
and  page_bt_synonym = rtrim(@engg_grid_btsynname)  
)  
begin  
exec engg_error_sp 'uid_ep_layout_sp_savgrdgdml',2,'Column (BT Synonym):<%2> already exists as a Page(BT Synonym) at row:<%1>',  
@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
@fprowno,@engg_grid_btsynname,'','',@m_errorid output  
if @m_errorid > 0  
return  
end*/
		/*Check duplication of Column BT synonym within the Activity/UI/Page/Section*/
		--code added by Sangeetha L for the bug id : Platform_2.0.3.X_265  
		--bug Descr :I have generated a service with a parameter "Name".  
		--The service got generated without any errors.But,when I tried to change the flow direction ,It is throwing an error  
		IF len(ltrim(rtrim(@engg_grid_btsynname))) > 0
		BEGIN
			IF EXISTS (
					SELECT 'x'
					FROM de_meta_vbkeywords(NOLOCK)
					WHERE keyword = @engg_grid_btsynname
					)
			BEGIN
				-- Code modified by Chanheetha N A on 29-Nov-2005 for the BUG ID:PNR2.0_4824  
				SET @msg = 'The Keyword "' + @engg_grid_btsynname + '" not allowed as a Column Name'

				EXEC engg_error_sp 'uid_ep_layout_sp_savgrdgdml',
					102,
					@msg,
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					NULL,
					NULL,
					NULL,
					NULL,
					@m_errorid OUTPUT

				IF @m_errorid <> 0
					RETURN
			END
		END

		IF EXISTS (
				SELECT 'X'
				FROM ep_ui_section_dtl(NOLOCK)
				WHERE customer_name = rtrim(@engg_customer_name)
					AND project_name = rtrim(@engg_project_name)
					AND req_no = rtrim(@engg_base_req_no)
					AND process_name = rtrim(@prc_name_tmp)
					AND component_name = rtrim(@component_name_tmp)
					AND activity_name = rtrim(@act_name_tmp)
					AND ui_name = rtrim(@ui_name_tmp)
					AND page_bt_synonym = rtrim(@engg_grid_page_bts)
					AND section_bt_synonym = rtrim(@engg_grid_btsynname)
				)
		BEGIN
			EXEC engg_error_sp 'uid_ep_layout_sp_savgrdgdml',
				3,
				'Column (BT Synonym):<%2> already exists as a Section(BT Synonym).',
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@fprowno,
				@engg_grid_btsynname,
				'',
				'',
				@m_errorid OUTPUT

			IF @m_errorid > 0
				RETURN
		END

		/*Check duplication of Column BT synonym within the Activity/UI/Page/Section/Control*/
		IF EXISTS (
				SELECT 'X'
				FROM ep_ui_control_dtl(NOLOCK)
				WHERE customer_name = rtrim(@engg_customer_name)
					AND project_name = rtrim(@engg_project_name)
					AND req_no = rtrim(@engg_base_req_no)
					AND process_name = rtrim(@prc_name_tmp)
					AND component_name = rtrim(@component_name_tmp)
					AND activity_name = rtrim(@act_name_tmp)
					AND ui_name = rtrim(@ui_name_tmp)
					AND page_bt_synonym = rtrim(@engg_grid_page_bts)
					AND control_bt_synonym = rtrim(@engg_grid_btsynname)
				)
		BEGIN
			EXEC engg_error_sp 'uid_ep_layout_sp_savgrdgdml',
				4,
				'Column (BT Synonym):<%2> already exists as a Control(BT Synonym).',
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@fprowno,
				@engg_grid_btsynname,
				'',
				'',
				@m_errorid OUTPUT

			IF @m_errorid > 0
				RETURN
		END

		/*Check duplication of Column BT synonym within the Activity/UI/Page/Section/Grid*/
		IF EXISTS (
				SELECT 'X'
				FROM ep_ui_grid_dtl(NOLOCK)
				WHERE customer_name = rtrim(@engg_customer_name)
					AND project_name = rtrim(@engg_project_name)
					AND req_no = rtrim(@engg_base_req_no)
					AND process_name = rtrim(@prc_name_tmp)
					AND component_name = rtrim(@component_name_tmp)
					AND activity_name = rtrim(@act_name_tmp)
					AND ui_name = rtrim(@ui_name_tmp)
					AND page_bt_synonym = rtrim(@engg_grid_page_bts)
					--    and  section_bt_synonym <>rtrim(@engg_grid_sec_bts)  
					AND column_bt_synonym = rtrim(@engg_grid_btsynname)
				)
		BEGIN
			EXEC engg_error_sp 'uid_ep_layout_sp_savgrdgdml',
				5,
				'Column (BT Synonym):<%2> already exists as a Grid(BT Synonym) at row:<%1>',
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@fprowno,
				@engg_grid_btsynname,
				'',
				'',
				@m_errorid OUTPUT

			IF @m_errorid > 0
				RETURN
		END

		-- code modified by shafina on 01-Sep-2004 for PREVIEWENG203ACC_000095 (When a new BT synonym is entered , it must be checked whether it exists as a hidden view already.)  
		IF EXISTS (
				SELECT 'X'
				FROM de_hidden_view(NOLOCK)
				WHERE customer_name = rtrim(@engg_customer_name)
					AND project_name = rtrim(@engg_project_name)
					AND process_name = rtrim(@prc_name_tmp)
					AND component_name = rtrim(@component_name_tmp)
					AND activity_name = rtrim(@act_name_tmp)
					AND ui_name = rtrim(@ui_name_tmp)
					AND page_name = rtrim(@engg_grid_page_bts)
					AND hidden_view_bt_synonym = rtrim(@engg_grid_btsynname)
				)
		BEGIN
			EXEC engg_error_sp 'uid_ep_layout_sp_savgrdgdml',
				3,
				'Column (BT Synonym):<%2> already exists as a Hidden View(BT Synonym).',
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@fprowno,
				@engg_grid_btsynname,
				'',
				'',
				@m_errorid OUTPUT

			IF @m_errorid > 0
				RETURN
		END

		-- code modified by shafina on 10-Dec-2004 for PREVIEWENG203ACC_000095 (When a new BT synonym is entered , it must be checked whether it exists as a scratch variable already.)  
		IF EXISTS (
				SELECT 'X'
				FROM de_scratch_variable(NOLOCK)
				WHERE customer_name = rtrim(@engg_customer_name)
					AND project_name = rtrim(@engg_project_name)
					AND process_name = rtrim(@prc_name_tmp)
					AND component_name = rtrim(@component_name_tmp)
					AND activity_name = rtrim(@act_name_tmp)
					AND ui_name = rtrim(@ui_name_tmp)
					AND page_name = rtrim(@engg_grid_page_bts)
					AND scratch_name = rtrim(@engg_grid_btsynname)
				)
		BEGIN
			EXEC engg_error_sp 'uid_ep_layout_sp_savgrdgdml',
				3,
				'Column (BT Synonym):<%2> already exists as a User Defined Scratch Variable.',
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@fprowno,
				@engg_grid_btsynname,
				'',
				'',
				@m_errorid OUTPUT

			IF @m_errorid > 0
				RETURN
		END

		-- code modified by shafina on 06-Dec-2004 for PREVIEWPF204ACC_000001 (Default Scratch variables must not be used as user defined bt synonyms.)  
		IF EXISTS (
				SELECT 'x'
				FROM de_scratch_variables_sys(NOLOCK)
				WHERE btsynonym = @engg_grid_btsynname
				)
			-- code modified by shafina on 22-Dec-2004 for PREVIEWENG203ACC_000115 (Modeflag must not be allowed to be entered as bt synonym.)  
			OR @engg_grid_btsynname = 'Modeflag'
		BEGIN
			SELECT @msg = 'Column Bt Synonym ' + @engg_grid_btsynname + ' already exists as a Default Scratch Variable'

			EXEC engg_error_sp 'en_comp_sp_savcon_hsv',
				7,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			RETURN
		END
	END /*End of Modeflag X and I*/

	/*Checking for Dependencies on Deletion in Traversal*/
	IF @modeflag IN ('D')
	BEGIN
		/*Code modified by vijay on 26/12/03 for combo change on grid details*/
		/*Checking for Dependencies on Deletion in Enum*/
		IF EXISTS (
				SELECT 'X'
				FROM ep_enum_value_dtl(NOLOCK)
				WHERE customer_name = rtrim(@engg_customer_name)
					AND project_name = rtrim(@engg_project_name)
					AND req_no = rtrim(@engg_base_req_no)
					AND process_name = rtrim(@prc_name_tmp)
					AND component_name = rtrim(@component_name_tmp)
					AND activity_name = rtrim(@act_name_tmp)
					AND ui_name = rtrim(@ui_name_tmp)
					AND page_bt_synonym = rtrim(@engg_grid_page_bts)
					AND section_bt_synonym = rtrim(@engg_grid_sec_bts)
					AND control_bt_synonym = rtrim(@engg_grid_btsynname)
				)
		BEGIN
			EXEC engg_error_sp 'uid_ep_layout_sp_savgrdgdml',
				6,
				'Column (BT Synonym):<%2> is in use in Enumeration',
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@fprowno,
				@engg_grid_btsynname,
				'',
				'',
				@m_errorid OUTPUT

			IF @m_errorid > 0
				RETURN
		END

		/*Code modified by vijay on 26/12/03 for combo change on grid details*/
		IF EXISTS (
				SELECT 'X'
				FROM ep_ui_traversal_dtl(NOLOCK)
				WHERE customer_name = rtrim(@engg_customer_name)
					AND project_name = rtrim(@engg_project_name)
					AND req_no = rtrim(@engg_base_req_no)
					AND process_name = rtrim(@prc_name_tmp)
					AND component_name = rtrim(@component_name_tmp)
					AND activity_name = rtrim(@act_name_tmp)
					AND ui_name = rtrim(@ui_name_tmp)
					AND page_bt_synonym = rtrim(@engg_grid_page_bts)
					AND section_bt_synonym = rtrim(@engg_grid_sec_bts)
					AND control_bt_synonym = rtrim(@engg_grid_btsynname)
					-- modified by shafina on 19-Apr-2004 for PREVIEWENG203ACC_000038  
					AND isnull(linked_component, '') <> ''
					AND isnull(linked_activity, '') <> ''
					AND isnull(linked_ui, '') <> ''
				)
		BEGIN
			EXEC engg_error_sp 'uid_ep_layout_sp_savgrdgdml',
				7,
				'Column (BT Synonym):<%2> is in use in Traversal',
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@fprowno,
				@engg_grid_btsynname,
				'',
				'',
				@m_errorid OUTPUT

			IF @m_errorid > 0
				RETURN
		END

		/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P begin*/
		IF EXISTS (
				SELECT 'X'
				FROM es_comp_ctrl_type_mst(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND ctrl_type_name = @engg_grid_elem_type
					AND base_ctrl_type = 'Listedit'
				)
		BEGIN
			IF EXISTS (
					SELECT 'X'
					FROM ep_listedit_control_map(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND listedit_synonym = @engg_grid_btsynname
					)
			BEGIN
				EXEC engg_error_sp 'uid_ep_layout_sp_savgrdgdml',
					6,
					'Column (BT Synonym):<%2> is in use in Listedit',
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@fprowno,
					@engg_grid_btsynname,
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid > 0
					RETURN
			END

			IF EXISTS (
					SELECT 'X'
					FROM ep_listedit_column_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND listedit_synonym = @engg_grid_btsynname
					)
			BEGIN
				EXEC engg_error_sp 'uid_ep_layout_sp_savgrdgdml',
					6,
					'Column (BT Synonym):<%2> is in use in Enumeration',
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@fprowno,
					@engg_grid_btsynname,
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid > 0
					RETURN
			END

			IF EXISTS (
					SELECT 'X'
					FROM ep_resolvelist_data_map(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND listedit_synonym = @engg_grid_btsynname
					)
			BEGIN
				EXEC engg_error_sp 'uid_ep_layout_sp_savgrdgdml',
					6,
					'Column (BT Synonym):<%2> is in use in Enumeration',
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@fprowno,
					@engg_grid_btsynname,
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid > 0
					RETURN
			END
		END

		IF EXISTS (
				SELECT 'X'
				FROM es_comp_ctrl_type_mst(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND ctrl_type_name = @engg_grid_elem_type
					--and  base_ctrl_type   ='edit'  
					AND associatedlist_req = 'y'
				)
		BEGIN
			IF EXISTS (
					SELECT 'X'
					FROM ep_listedit_control_map(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = @engg_grid_page_bts
						AND mapped_bt_synonym = @engg_grid_btsynname
					)
			BEGIN
				EXEC engg_error_sp 'uid_ep_layout_sp_savgrdgdml',
					6,
					'Column (BT Synonym):<%2> is in use in Enumeration',
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@fprowno,
					@engg_grid_btsynname,
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid > 0
					RETURN
			END

			IF EXISTS (
					SELECT 'X'
					FROM ep_resolvelist_data_map(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = @engg_grid_page_bts
						AND mapped_bt_synonym = @engg_grid_btsynname
					)
			BEGIN
				EXEC engg_error_sp 'uid_ep_layout_sp_savgrdgdml',
					6,
					'Column (BT Synonym):<%2> is in use in Enumeration',
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@fprowno,
					@engg_grid_btsynname,
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid > 0
					RETURN
			END
		END

		IF EXISTS (
				SELECT 'X'
				FROM ep_resolvelist_data_map(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND mapped_bt_syn_page = @engg_grid_page_bts
					AND data_mapped_synonym = @engg_grid_btsynname
				)
		BEGIN
			EXEC engg_error_sp 'uid_ep_layout_sp_savgrdgdml',
				6,
				'Column (BT Synonym):<%2> is in use in Enumeration',
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@fprowno,
				@engg_grid_btsynname,
				'',
				'',
				@m_errorid OUTPUT

			IF @m_errorid > 0
				RETURN
		END
				/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P End*/
	END /*End for mode flag 'D'*/

	/*Checking for Dependencies on Deletion in Links*/
	/*if exists ( select 'X'  
from engg_subscription_dtl (nolock)  
where customer_name  = rtrim(@engg_customer_name)  
and project_name  = rtrim(@engg_project_name)  
and req_no   = rtrim(@engg_req_no)  
and process_name  = rtrim(@prc_name_tmp)  
and component_name  = rtrim(@component_name_tmp)  
and activity_name  = rtrim(@act_name_tmp)  
and ui_name   = rtrim(@ui_name_tmp)  
--    and page_bt_synonym  = rtrim(@engg_grid_page_bts) --will not be in Sub. dtl  
--    and section_bt_synonym = rtrim(@engg_grid_sec_bts) --will not be in Sub. dtl  
and control_bt_synonym = rtrim(@engg_grid_btsynname)  
)  
begin  
exec engg_error_sp 'uid_ep_layout_sp_savgrdgdml',8,'Column (BT Synonym):<%2> at row:<%1> is in use in Links',  
@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
@fprowno,@engg_grid_btsynname,'','',@m_errorid output  
if @m_errorid > 0  
return  
end  
*/
	/*Checking for Dependencies on Deletion in Task*/
	/* if exists ( select 'X'  
from engg_action_mst (nolock)  
where customer_name  = rtrim(@engg_customer_name)  
and project_name  = rtrim(@engg_project_name)  
and req_no   = rtrim(@engg_req_no)  
and process_name  = rtrim(@prc_name_tmp)  
and component_name  = rtrim(@component_name_tmp)  
and activity_name  = rtrim(@act_name_tmp)  
and ui_name   = rtrim(@ui_name_tmp)  
--    and page_bt_synonym  = rtrim(@engg_grid_page_bts)  
--    and section_bt_synonym = rtrim(@engg_grid_sec_bts)  
and triggering_ctrl_bt_synonym = rtrim(@engg_grid_btsynname)  
)  
begin  
exec engg_error_sp 'uid_ep_layout_sp_savgrdgdml',9,'Column (BT Synonym):<%2> at row:<%1> is in use in Task',  
@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,  
@fprowno,@engg_grid_btsynname,'','',@m_errorid output  
if @m_errorid > 0  
return  
end  
*/
	/*Check Control Type for hidden controls existence*/
	/*Getting the Component Parameter*/
	SELECT @allow_hdn_ctrl = rtrim(current_value)
	FROM es_comp_param_mst_vw(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_base_req_no)
		AND process_name = rtrim(@prc_name_tmp)
		AND component_name = rtrim(@component_name_tmp)
		AND param_category = 'ADDHDNCTRL'
		AND param_type = 'CONFIG'

	/*Getting the Visible Flag*/
	SELECT @vis_flag = rtrim(visisble_flag)
	FROM es_comp_ctrl_type_mst_vw(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_base_req_no)
		AND process_name = rtrim(@prc_name_tmp)
		AND component_name = rtrim(@component_name_tmp)
		AND ctrl_type_name = rtrim(@engg_grid_elem_type)

	--Kanagavel
	--For each row, if column BTSynonym Name already exists for another Page or Section or control or Grid Control, display error message.
	IF @modeflag IN (
			'I',
			'X'
			)
	BEGIN
		IF EXISTS (
				SELECT 'A'
				FROM ep_ui_page_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = @engg_grid_btsynname
				)
		BEGIN
			SELECT @msg = 'Synonym ' + @engg_grid_btsynname + ' already exists in the UI as a Page Bt Synonym'

			RAISERROR (
					@msg,
					16,
					1
					)

			RETURN
		END
	END

	IF @modeflag IN (
			'I',
			'X'
			)
	BEGIN
		IF EXISTS (
				SELECT 'A'
				FROM ep_ui_section_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND section_bt_synonym = @engg_grid_btsynname
				)
		BEGIN
			SELECT @msg = 'Synonym ' + @engg_grid_btsynname + ' already exists in the UI as a Section Bt Synonym'

			RAISERROR (
					@msg,
					16,
					1
					)

			RETURN
		END
	END

	IF @modeflag IN (
			'I',
			'X'
			)
	BEGIN
		IF EXISTS (
				SELECT 'A'
				FROM ep_ui_control_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND control_bt_synonym = @engg_grid_btsynname
				)
		BEGIN
			SELECT @msg = 'Synonym ' + @engg_grid_btsynname + ' already exists in the UI as a control Bt Synonym'

			RAISERROR (
					@msg,
					16,
					1
					)

			RETURN
		END
	END

	IF @modeflag IN (
			'I',
			'X'
			)
	BEGIN
		IF EXISTS (
				SELECT 'A'
				FROM ep_ui_grid_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND column_bt_synonym = @engg_grid_btsynname
				)
		BEGIN
			SELECT @msg = 'Synonym ' + @engg_grid_btsynname + ' already exists in the UI as a control Bt Synonym'

			RAISERROR (
					@msg,
					16,
					1
					)

			RETURN
		END
	END

	/* Hidden Control = 'Do not allow modifications' and Visible Flag = 'N'*/
	IF upper(@allow_hdn_ctrl) = 'DO NOT ALLOW MODIFICATIONS'
		AND upper(@vis_flag) = 'N'
	BEGIN
		EXEC engg_error_sp 'uid_ep_layout_sp_savgrdgdml',
			13,
			'Column <%1> has a hidden control. Hidden controls are not allowed to be created',
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			@engg_grid_btsynname,
			'',
			'',
			'',
			@m_errorid OUTPUT

		IF @m_errorid > 0
			RETURN
	END

	/*Check correctness of Visible Length*/
	IF @engg_grid_vis_length < 0
	BEGIN
		EXEC engg_error_sp 'uid_ep_layout_sp_savgrdgdml',
			10,
			'Visible Length:<%2> is not valid for Column:<%1>',
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			@engg_grid_btsynname,
			@engg_grid_vis_length,
			'',
			'',
			@m_errorid OUTPUT

		IF @m_errorid > 0
			RETURN
	END

	/*Check repetitions in Columns Only on Insertion*/
	IF @modeflag IN (
			'X',
			'I'
			)
	BEGIN
		IF EXISTS (
				SELECT 'X'
				FROM ep_ui_grid_dtl(NOLOCK)
				WHERE customer_name = rtrim(@engg_customer_name)
					AND project_name = rtrim(@engg_project_name)
					AND req_no = rtrim(@engg_base_req_no)
					AND process_name = rtrim(@prc_name_tmp)
					AND component_name = rtrim(@component_name_tmp)
					AND activity_name = rtrim(@act_name_tmp)
					AND ui_name = rtrim(@ui_name_tmp)
					AND page_bt_synonym = rtrim(@engg_grid_page_bts)
					AND section_bt_synonym = rtrim(@engg_grid_sec_bts)
					AND control_bt_synonym = rtrim(@engg_grid_grid_code)
					AND column_no = @engg_grid_colno
				)
		BEGIN
			EXEC engg_error_sp 'uid_ep_layout_sp_savgrdgdml',
				12,
				'There are duplicates in column numbers',
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			IF @m_errorid > 0
				RETURN
		END
	END /*End for Mode Flag X,I*/

	/*Check whether column number is negative.ELse display error message*/
	IF @engg_grid_colno < 1
	BEGIN
		EXEC engg_error_sp 'uid_ep_layout_sp_savgrdgdml',
			14,
			'Column Number <%1> cannot be Negative or Zero for Column <%2>',
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			@engg_grid_colno,
			@engg_grid_btsynname,
			'',
			'',
			@m_errorid OUTPUT

		IF @m_errorid > 0
			RETURN
	END

	IF @modeflag IN (
			'U',
			'Y'
			)
	BEGIN
		-- modified b shafina on 22-jan-2004 to check for updation in controltypes  
		SELECT @tmp_control_type = column_type
		FROM ep_ui_grid_dtl(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND process_name = @prc_name_tmp
			AND component_name = @component_name_tmp
			AND activity_name = @act_name_tmp
			AND ui_name = @ui_name_tmp
			AND page_bt_synonym = rtrim(@engg_grid_page_bts)
			AND section_bt_synonym = rtrim(@engg_grid_sec_bts)
			AND control_bt_synonym = rtrim(@engg_grid_grid_code)
			AND column_bt_synonym = rtrim(@engg_grid_btsynname)
			AND req_no = @engg_base_req_no

		-- code modified by shafina on 02-mar-2004  
		SELECT @base_ctrl_type_tmp = base_ctrl_type
		FROM es_comp_ctrl_type_mst_vw(NOLOCK)
		WHERE customer_name = rtrim(@engg_customer_name)
			AND project_name = rtrim(@engg_project_name)
			AND process_name = rtrim(@prc_name_tmp)
			AND component_name = rtrim(@component_name_tmp)
			AND ctrl_type_name = rtrim(@tmp_control_type)
			AND req_no = rtrim(@engg_base_req_no)

		IF EXISTS (
				SELECT 'x'
				FROM ep_ui_traversal_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = rtrim(@engg_grid_page_bts)
					AND section_bt_synonym = rtrim(@engg_grid_sec_bts)
					AND control_bt_synonym = rtrim(@engg_grid_btsynname)
					AND req_no = @engg_base_req_no
					AND linked_component <> ''
					AND linked_activity <> ''
					AND linked_ui <> ''
				)
		BEGIN
			IF @tmp_control_type <> @engg_grid_elem_type
			BEGIN
				-- code modified by shafina on 16-Aug-2004 for PREVIEWENG203ACC_000089 ( Eventhough Help Details exists in Traversal table , it is allowing to change the datatype og help control if the base control type is same )  
				SELECT @old_help_req = help_req
				FROM es_comp_ctrl_type_mst(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND ctrl_type_name = @tmp_control_type

				IF @base_ctrl_type_tmp <> @tmp_ctl
				BEGIN
					SELECT @msg = 'Control Type cannot be updated as this control exists as a link or help'

					EXEC engg_error_sp 'engg_layout_sp_savctlcnml',
						9,
						@msg,
						@ctxt_language,
						@ctxt_ouinstance,
						@ctxt_service,
						@ctxt_user,
						'',
						'',
						'',
						'',
						@m_errorid OUTPUT

					IF @m_errorid <> 0
						RETURN
				END

				IF @old_help_req <> @help_req
				BEGIN
					SELECT @msg = 'Control Type cannot be updated as this control exists as a help'

					EXEC engg_error_sp 'engg_layout_sp_savgrdgdml',
						9,
						@msg,
						@ctxt_language,
						@ctxt_ouinstance,
						@ctxt_service,
						@ctxt_user,
						'',
						'',
						'',
						'',
						@m_errorid OUTPUT

					IF @m_errorid <> 0
						RETURN
				END
			END

			/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P begin*/
			IF @tmp_control_type <> @engg_grid_elem_type
			BEGIN
				IF EXISTS (
						SELECT 'X'
						FROM es_comp_ctrl_type_mst(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @prc_name_tmp
							AND component_name = @component_name_tmp
							AND ctrl_type_name = @tmp_control_type
							AND base_ctrl_type = 'Listedit'
						)
				BEGIN
					IF EXISTS (
							SELECT 'X'
							FROM ep_listedit_control_map(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @prc_name_tmp
								AND component_name = @component_name_tmp
								AND activity_name = @act_name_tmp
								AND ui_name = @ui_name_tmp
								AND listedit_synonym = @engg_grid_btsynname
							)
					BEGIN
						RAISERROR (
								'Control Type cannot be updated as this control exists as a Listedit',
								16,
								1
								)

						RETURN
					END

					IF EXISTS (
							SELECT 'X'
							FROM ep_listedit_column_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @prc_name_tmp
								AND component_name = @component_name_tmp
								AND activity_name = @act_name_tmp
								AND ui_name = @ui_name_tmp
								AND listedit_synonym = @engg_grid_btsynname
							)
					BEGIN
						RAISERROR (
								'Control Type cannot be updated as this control exists as a Listedit',
								16,
								1
								)

						RETURN
					END

					IF EXISTS (
							SELECT 'X'
							FROM ep_resolvelist_data_map(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @prc_name_tmp
								AND component_name = @component_name_tmp
								AND activity_name = @act_name_tmp
								AND ui_name = @ui_name_tmp
								AND listedit_synonym = @engg_grid_btsynname
							)
					BEGIN
						RAISERROR (
								'Control Type cannot be updated as this control exists as a Listedit',
								16,
								1
								)

						RETURN
					END
				END

				IF EXISTS (
						SELECT 'X'
						FROM es_comp_ctrl_type_mst(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @prc_name_tmp
							AND component_name = @component_name_tmp
							AND ctrl_type_name = @tmp_control_type
							--and  base_ctrl_type   ='edit'  
							AND associatedlist_req = 'y'
						)
				BEGIN
					IF EXISTS (
							SELECT 'X'
							FROM ep_listedit_control_map(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @prc_name_tmp
								AND component_name = @component_name_tmp
								AND activity_name = @act_name_tmp
								AND ui_name = @ui_name_tmp
								AND page_bt_synonym = @engg_grid_page_bts
								AND mapped_bt_synonym = @engg_grid_btsynname
							)
					BEGIN
						RAISERROR (
								'Control Type cannot be updated as this control exists as a Listedit',
								16,
								1
								)

						RETURN
					END

					IF EXISTS (
							SELECT 'X'
							FROM ep_resolvelist_data_map(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @prc_name_tmp
								AND component_name = @component_name_tmp
								AND activity_name = @act_name_tmp
								AND ui_name = @ui_name_tmp
								AND page_bt_synonym = @engg_grid_page_bts
								AND mapped_bt_synonym = @engg_grid_btsynname
							)
					BEGIN
						RAISERROR (
								'Control Type cannot be updated as this control exists as a Listedit',
								16,
								1
								)

						RETURN
					END
				END

				IF EXISTS (
						SELECT 'X'
						FROM ep_resolvelist_data_map(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @prc_name_tmp
							AND component_name = @component_name_tmp
							AND activity_name = @act_name_tmp
							AND ui_name = @ui_name_tmp
							AND mapped_bt_syn_page = @engg_grid_page_bts
							AND data_mapped_synonym = @engg_grid_btsynname
						)
				BEGIN
					RAISERROR (
							'Control Type cannot be updated as this control exists as a Listedit',
							16,
							1
							)

					RETURN
				END
			END
					/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P End*/
		END

		/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P begin*/
		IF @modeflag IN (
				'U',
				'Y',
				'I',
				'X'
				)
		BEGIN
			IF EXISTS (
					SELECT 'X'
					FROM ep_ui_control_dtl a(NOLOCK),
						es_comp_ctrl_type_mst b(NOLOCK)
					WHERE a.customer_name = @engg_customer_name
						AND a.project_name = @engg_project_name
						AND a.process_name = @prc_name_tmp
						AND a.component_name = @component_name_tmp
						AND a.activity_name = @act_name_tmp
						AND a.ui_name = @ui_name_tmp
						AND a.control_bt_synonym = @engg_grid_btsynname
						AND a.customer_name = b.customer_name
						AND a.project_name = b.project_name
						AND a.process_name = b.process_name
						AND a.component_name = b.component_name
						AND a.control_type = b.ctrl_type_name
						AND b.base_ctrl_type = 'Listedit'
					)
			BEGIN
				RAISERROR (
						'Control Type cannot be updated as this control exists as a Listedit control.Unmap and proceed',
						16,
						1
						)

				RETURN
			END

			IF EXISTS (
					SELECT 'X'
					FROM ep_ui_grid_dtl a(NOLOCK),
						es_comp_ctrl_type_mst b(NOLOCK)
					WHERE a.customer_name = @engg_customer_name
						AND a.project_name = @engg_project_name
						AND a.process_name = @prc_name_tmp
						AND a.component_name = @component_name_tmp
						AND a.activity_name = @act_name_tmp
						AND a.ui_name = @ui_name_tmp
						AND a.column_bt_synonym = @engg_grid_btsynname
						AND a.customer_name = b.customer_name
						AND a.project_name = b.project_name
						AND a.process_name = b.process_name
						AND a.component_name = b.component_name
						AND a.column_type = b.ctrl_type_name
						AND b.base_ctrl_type = 'Listedit'
					)
			BEGIN
				RAISERROR (
						'Control Type cannot be updated as this control exists as a Listedit control.Unmap and proceed',
						16,
						1
						)

				RETURN
			END
		END

		/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P End*/
		IF EXISTS (
				SELECT 'x'
				FROM ep_enum_value_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = rtrim(@engg_grid_page_bts)
					AND section_bt_synonym = rtrim(@engg_grid_sec_bts)
					AND control_bt_synonym = rtrim(@engg_grid_btsynname)
					AND req_no = @engg_base_req_no
				)
		BEGIN
			IF @tmp_control_type <> @engg_grid_elem_type
			BEGIN
				IF @base_ctrl_type_tmp <> @tmp_ctl
				BEGIN
					SELECT @msg = 'Control Type cannot be updated as this control exists as a combo control'

					EXEC engg_error_sp 'engg_layout_sp_savctlcnml',
						9,
						@msg,
						@ctxt_language,
						@ctxt_ouinstance,
						@ctxt_service,
						@ctxt_user,
						'',
						'',
						'',
						'',
						@m_errorid OUTPUT

					IF @m_errorid <> 0
						RETURN
				END
			END
		END

		/*Not allowing to Modify the Column BT Synonym Name*/
		IF EXISTS (
				SELECT 'X'
				FROM ep_ui_grid_dtl(NOLOCK)
				WHERE customer_name = rtrim(@engg_customer_name)
					AND project_name = rtrim(@engg_project_name)
					AND req_no = rtrim(@engg_base_req_no)
					AND process_name = rtrim(@prc_name_tmp)
					AND component_name = rtrim(@component_name_tmp)
					AND activity_name = rtrim(@act_name_tmp)
					AND ui_name = rtrim(@ui_name_tmp)
					AND page_bt_synonym = rtrim(@engg_grid_page_bts)
					AND section_bt_synonym = rtrim(@engg_grid_sec_bts)
					AND control_bt_synonym = rtrim(@engg_grid_grid_code)
					AND column_bt_synonym = rtrim(@engg_grid_btsynname)
				)
		BEGIN
			--modified by shafina on 22-jan-2004  
			-- to delete the rows in traversal table when control_type is updated..  
			IF EXISTS (
					SELECT 'x'
					FROM ep_ui_traversal_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = rtrim(@engg_grid_page_bts)
						AND section_bt_synonym = rtrim(@engg_grid_sec_bts)
						AND control_bt_synonym = rtrim(@engg_grid_btsynname)
						AND req_no = @engg_base_req_no
						AND isnull(linked_component, '') = ''
						AND isnull(linked_activity, '') = ''
						AND isnull(linked_ui, '') = ''
					)
			BEGIN
				SELECT @tmp_control_type = column_type
				FROM ep_ui_grid_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = rtrim(@engg_grid_page_bts)
					AND section_bt_synonym = rtrim(@engg_grid_sec_bts)
					AND control_bt_synonym = rtrim(@engg_grid_grid_code)
					AND column_bt_synonym = rtrim(@engg_grid_btsynname)
					AND req_no = @engg_base_req_no

				IF @tmp_control_type <> @engg_grid_elem_type
				BEGIN
					-- code modified by shafina on 20-Nov-2004 for Primary key modification in traversal tables.  
					DELETE
					FROM ep_ui_traversal_dtl
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_base_req_no
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = @engg_grid_page_bts
						AND section_bt_synonym = @engg_grid_sec_bts
						AND control_bt_synonym = @engg_grid_btsynname
						AND isnull(linked_component, '') = ''
						AND isnull(linked_activity, '') = ''
						AND isnull(linked_ui, '') = ''
				END
			END

			UPDATE ep_ui_grid_dtl
			SET column_type = rtrim(@engg_grid_elem_type),
				column_no = @engg_grid_colno,
				visible_length = rtrim(@engg_grid_vis_length),
				proto_tooltip = rtrim(@engg_grid_tooltip),
				sample_data = rtrim(@engg_grid_samp_data),
				col_doc = rtrim(@engg_grid_doc),
				Set_User_Pref = @user_pref, -- modified  for  PNR2.0_23541  
				Default_required = @grid_def, --Code Modified for PNR2.0_30869  
				-- code added by shafina on 07-Sep-2004 for PREVIEWENG203ACC_000098 (Modified Date must be updated.)  
				modifiedby = @ctxt_user,
				modifieddate = getdate(),
				columnclass = @columnclass,
				--ColumnHdrClass = @columnheaderclass,  
				forcefit = CASE @forcefit
					WHEN 1
						THEN 'Y'
					ELSE 'N'
					END
			WHERE customer_name = rtrim(@engg_customer_name)
				AND project_name = rtrim(@engg_project_name)
				AND req_no = rtrim(@engg_base_req_no)
				AND process_name = rtrim(@prc_name_tmp)
				AND component_name = rtrim(@component_name_tmp)
				AND activity_name = rtrim(@act_name_tmp)
				AND ui_name = rtrim(@ui_name_tmp)
				AND page_bt_synonym = rtrim(@engg_grid_page_bts)
				AND section_bt_synonym = rtrim(@engg_grid_sec_bts)
				AND control_bt_synonym = rtrim(@engg_grid_grid_code)
				AND column_bt_synonym = rtrim(@engg_grid_btsynname)

			--Code Modification for PNR2.0_30869 starts  
			IF @engg_grid_default = 1
			BEGIN
				DECLARE @vorder engg_name
				DECLARE @horder engg_name
				DECLARE @newcontrol engg_name
				DECLARE @ControlDoc ENGG_DOCUMENTATION
				DECLARE @newctrlprefix engg_name

				SELECT @newcontrol = @engg_grid_grid_code + 'SetDef'

				IF len(@newcontrol) > 57
					SELECT @newcontrol = left(@engg_grid_grid_code, 51) + 'SetDef'

				EXEC engg_gen_prefix_id @engg_customer_name,
					@engg_project_name,
					@component_name_tmp,
					@act_name_tmp,
					@ui_name_tmp,
					@engg_grid_grid_code,
					'C',
					6,
					@newctrlprefix OUTPUT

				SELECT @newctrlprefix = left(@newctrlprefix, 5) + 'd'

				EXEC ep_controlid_generation @engg_customer_name,
					@engg_project_name,
					@engg_base_req_no,
					@prc_name_tmp,
					@component_name_tmp,
					@act_name_tmp,
					@ui_name_tmp,
					@newcontrol,
					'Edit',
					'N',
					'N',
					@control_id OUTPUT

				SELECT @ControlDoc = 'Grid Defaulting Control for the Grid' + @engg_grid_grid_code

				--Commented for PLF2.0_06660  
				--If not exists ( select 'x'  
				--from ep_component_glossary_mst (nolock)  
				--where customer_name = @engg_customer_name  
				--and  project_name = @engg_project_name  
				--and  process_name    = @prc_name_tmp  
				--and  component_name  = @component_name_tmp  
				--and  bt_synonym_name = @newcontrol  
				--)  
				--begin  
				-- exec ep_component_glossary_mst_sp_ins @ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user, @engg_customer_name,  
				--   @engg_project_name, @engg_base_req_no, @prc_name_tmp, @component_name_tmp, @newcontrol, null, 'Char', 60,  
				--   'Grid Defaulting Control', @ControlDoc, '', 'U', '', '', 1, @engg_req_no, @m_errorid out  
				-- if @m_errorid <> 0  
				--  return  
				--end  
				-- Code Added for the Bug ID:PNR2.0_35200 starts  
				IF NOT EXISTS (
						SELECT 'x'
						FROM ep_ui_section_dtl(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @prc_name_tmp
							AND component_name = @component_name_tmp
							AND activity_name = @act_name_tmp
							AND ui_name = @ui_name_tmp
							AND page_bt_synonym = '[mainscreen]'
							AND section_bt_synonym = 'PrjhdnSection'
						)
				BEGIN
					EXEC ep_ui_section_dtl_sp_ins 
						@ctxt_language,
						@ctxt_ouinstance,
						@ctxt_service,
						@ctxt_user,
						@engg_customer_name,
						@engg_project_name,
						@engg_base_req_no,
						@prc_name_tmp,
						@component_name_tmp,
						@act_name_tmp,
						@ui_name_tmp,
						'[mainscreen]',
						'PrjhdnSection',
						'N',
						'N',
						'N',
						'Left',
						'',
						100,
						1,
						'PrjhdnSection',
						1,
						'Main',
						'',
						'',
						'',
						'',
						'',
						'',
						'', --
						'', --
						@engg_req_no,
						'', --
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',  --TECH-70687
						'','','','','','',  --TECH-70687
						'', --TECH-72114
						'', --TECH-75230
						@m_errorid OUTPUT

					IF @m_errorid <> 0
						RETURN
				END

				-- Code Added for the Bug ID:PNR2.0_35200 ends  
				IF EXISTS (
						SELECT 'x'
						FROM ep_ui_control_dtl(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @prc_name_tmp
							AND component_name = @component_name_tmp
							AND activity_name = @act_name_tmp
							AND ui_name = @ui_name_tmp
							AND page_bt_synonym = '[mainscreen]'
							AND section_bt_synonym = 'PrjhdnSection'
						)
				BEGIN
					SELECT @horder = isnull(max(horder), 0)
					FROM ep_ui_control_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = '[mainscreen]'
						AND section_bt_synonym = 'PrjhdnSection'
				END
				ELSE
					SELECT @horder = 1

				IF EXISTS (
						SELECT 'x'
						FROM ep_ui_control_dtl(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @prc_name_tmp
							AND component_name = @component_name_tmp
							AND activity_name = @act_name_tmp
							AND ui_name = @ui_name_tmp
							AND page_bt_synonym = '[mainscreen]'
							AND section_bt_synonym = 'PrjhdnSection'
						)
				BEGIN
					SELECT @vorder = isnull(max(vorder), 0) + 1
					FROM ep_ui_control_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = '[mainscreen]'
						AND section_bt_synonym = 'PrjhdnSection'
				END
				ELSE
					SELECT @vorder = 1
						--Commented for PLF2.0_06660  
						--If not exists ( select 'x'  
						--from  ep_ui_control_dtl (nolock)  
						--where customer_name  = @engg_customer_name  
						--and  project_name  = @engg_project_name  
						--and  process_name  = @prc_name_tmp  
						--and  component_name  = @component_name_tmp  
						--and  activity_name  = @act_name_tmp  
						--and  ui_name    = @ui_name_tmp  
						--and  page_bt_synonym  = '[mainscreen]'  
						--and  section_bt_synonym = 'PrjhdnSection'  
						--and  control_bt_synonym = @newcontrol  
						-- )  
						--Begin  
						-- Exec ep_ui_control_dtl_sp_ins @ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user, @engg_customer_name, @engg_project_name,  
						--@engg_base_req_no, @prc_name_tmp, @component_name_tmp, @act_name_tmp, @ui_name_tmp, '[mainscreen]',  
						--'PrjhdnSection', @newcontrol, @control_id, 'HiddenEdit', 20, @horder, @vorder, 1, 0, 0, '', 'Grid Defaulting',  
						--'Grid Defaulting', @newctrlprefix, '', '%', '%',   null, null,  null, null, 0, null,  
						--1, @engg_req_no, null, 0, @m_errorid out  
						--End  
			END

			--Code Modification for PNR2.0_30869 ends  
			IF EXISTS (
					SELECT 'x' -- code addition by Gopinath for the Call Id PNR2.0_24645 S begins  
					FROM ep_ui_state_column_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_base_req_no
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = @engg_grid_page_bts
						AND section_bt_synonym = @engg_grid_sec_bts
						AND control_bt_synonym = @engg_grid_grid_code
						AND column_bt_synonym = @engg_grid_btsynname
					)
			BEGIN
				UPDATE ep_ui_state_column_dtl
				SET column_no = @engg_grid_colno
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = @engg_grid_page_bts
					AND section_bt_synonym = @engg_grid_sec_bts
					AND control_bt_synonym = @engg_grid_grid_code
					AND column_bt_synonym = @engg_grid_btsynname
			END -- code addition by Gopinath for the Call Id PNR2.0_24645 S ends  
		END
		ELSE
		BEGIN
			EXEC engg_error_sp 'uid_ep_layout_sp_savgrdgdml',
				13,
				'Column (BT Synonym):<%2> cannot be modified.',
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@fprowno,
				@engg_grid_btsynname,
				'',
				'',
				@m_errorid OUTPUT

			IF @m_errorid > 0
				RETURN
		END
	END /*End of Mode Flag Y and U*/

	-- code modified by shafina on 09-Sep-2004 for PREVIEWENG203SYS_000144 (Enumerated value is not comin in combo)  
	IF @modeflag IN (
			'u',
			'y',
			's',
			'z'
			)
	BEGIN
		IF EXISTS (
				SELECT 'x'
				FROM ep_enum_value_dtl(NOLOCK)
				WHERE customer_name = rtrim(@engg_customer_name)
					AND project_name = rtrim(@engg_project_name)
					AND req_no = rtrim(@engg_base_req_no)
					AND process_name = rtrim(@prc_name_tmp)
					AND component_name = rtrim(@component_name_tmp)
					AND activity_name = rtrim(@act_name_tmp)
					AND ui_name = rtrim(@ui_name_tmp)
					AND page_bt_synonym = rtrim(@engg_grid_page_bts)
					AND section_bt_synonym = rtrim(@engg_grid_sec_bts)
					AND control_bt_synonym = rtrim(@engg_grid_btsynname)
				)
			AND @tmp_ctl = 'combo'
		BEGIN
			SELECT @engg_grid_samp_data = ''

			SELECT @enumcap = ''

			DECLARE enum_curr CURSOR
			FOR
			SELECT enum_caption
			FROM ep_enum_value_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_base_req_no
				AND process_name = @prc_name_tmp
				AND component_name = @component_name_tmp
				AND activity_name = @act_name_tmp
				AND ui_name = @ui_name_tmp
				AND page_bt_synonym = @engg_grid_page_bts
				AND section_bt_synonym = @engg_grid_sec_bts
				AND control_bt_synonym = @engg_grid_btsynname
			ORDER BY default_flag DESC

			OPEN enum_curr

			WHILE 1 = 1
			BEGIN
				FETCH NEXT
				FROM enum_curr
				INTO @enumcap

				IF @@fetch_status <> 0
					BREAK

				SELECT @engg_grid_samp_data = @engg_grid_samp_data + ltrim(rtrim(@enumcap)) + '~'
			END

			CLOSE enum_curr

			DEALLOCATE enum_curr

			IF len(@engg_grid_samp_data) > 0
				SELECT @engg_grid_samp_data = substring(@engg_grid_samp_data, 1, len(@engg_grid_samp_data) - 1)
		END

		UPDATE ep_ui_grid_dtl
		SET sample_data = rtrim(@engg_grid_samp_data),
			Set_User_Pref = @user_pref, -- modified  for  PNR2.0_23541  
			Default_required = @grid_def --Code Modified for PNR2.0_30869  
		WHERE customer_name = rtrim(@engg_customer_name)
			AND project_name = rtrim(@engg_project_name)
			AND req_no = rtrim(@engg_base_req_no)
			AND process_name = rtrim(@prc_name_tmp)
			AND component_name = rtrim(@component_name_tmp)
			AND activity_name = rtrim(@act_name_tmp)
			AND ui_name = rtrim(@ui_name_tmp)
			AND page_bt_synonym = rtrim(@engg_grid_page_bts)
			AND section_bt_synonym = rtrim(@engg_grid_sec_bts)
			AND control_bt_synonym = rtrim(@engg_grid_grid_code)
			AND column_bt_synonym = rtrim(@engg_grid_btsynname)
	END

	/*If a Column BT exists, Update else Insert*/
	IF @modeflag IN (
			'X',
			'I'
			)
	BEGIN
		IF EXISTS (
				SELECT 'X'
				FROM ep_ui_grid_dtl(NOLOCK)
				WHERE customer_name = rtrim(@engg_customer_name)
					AND project_name = rtrim(@engg_project_name)
					AND req_no = rtrim(@engg_base_req_no)
					AND process_name = rtrim(@prc_name_tmp)
					AND component_name = rtrim(@component_name_tmp)
					AND activity_name = rtrim(@act_name_tmp)
					AND ui_name = rtrim(@ui_name_tmp)
					AND page_bt_synonym = rtrim(@engg_grid_page_bts)
					AND section_bt_synonym = rtrim(@engg_grid_sec_bts)
					AND control_bt_synonym = rtrim(@engg_grid_grid_code)
					AND column_bt_synonym = rtrim(@engg_grid_btsynname)
				)
		BEGIN
			UPDATE ep_ui_grid_dtl
			SET column_type = rtrim(@engg_grid_elem_type),
				column_no = @engg_grid_colno,
				visible_length = rtrim(@engg_grid_vis_length),
				proto_tooltip = rtrim(@engg_grid_tooltip),
				sample_data = rtrim(@engg_grid_samp_data),
				col_doc = rtrim(@engg_grid_doc),
				Set_User_Pref = @user_pref, -- modified  for  PNR2.0_23541  
				Default_required = @grid_def, --Code Modified for PNR2.0_30869  
				modifiedby = @ctxt_user,
				modifieddate = getdate()
			WHERE customer_name = rtrim(@engg_customer_name)
				AND project_name = rtrim(@engg_project_name)
				AND req_no = rtrim(@engg_base_req_no)
				AND process_name = rtrim(@prc_name_tmp)
				AND component_name = rtrim(@component_name_tmp)
				AND activity_name = rtrim(@act_name_tmp)
				AND ui_name = rtrim(@ui_name_tmp)
				AND page_bt_synonym = rtrim(@engg_grid_page_bts)
				AND section_bt_synonym = rtrim(@engg_grid_sec_bts)
				AND control_bt_synonym = rtrim(@engg_grid_grid_code)
				AND column_bt_synonym = rtrim(@engg_grid_btsynname)
		END
		ELSE
			/*Insertion of New Row*/
		BEGIN
			-- To Generate Control ID/View Names for the newly inserted controls  
			-- To select the control_id of the grid control from control_dtl..  
			SELECT @ctrl_bt_syn_id = control_id
			FROM ep_ui_control_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_base_req_no
				AND process_name = @prc_name_tmp
				AND component_name = @component_name_tmp
				AND activity_name = @act_name_tmp
				AND ui_name = @ui_name_tmp
				AND page_bt_synonym = @engg_grid_page_bts
				AND section_bt_synonym = @engg_grid_sec_bts
				AND control_bt_synonym = @engg_grid_grid_code

			SELECT @ctrl_bt_syn_id = isnull(@ctrl_bt_syn_id, '')

			-- code modified by chanheetha N A  for the call id : PNR2.0_11000 on15-Nov-2006  
			-- -- code modified by shafina on 08-June-2004 for PREVIEWENG203ACC_000071 ( duplication of view name )  
			--  
			--    select @viewname_tmp  = max(convert(int,view_name))  
			--    from ep_ui_grid_dtl (nolock)  
			--    where  customer_name    = @engg_customer_name  
			--    and   project_name    = @engg_project_name  
			--    and     req_no       = @engg_base_req_no  
			--    and   process_name    = @prc_name_tmp  
			--    and   component_name   = @component_name_tmp  
			--    and   activity_name    = @act_name_tmp  
			--    and   ui_name       = @ui_name_tmp  
			--    and   page_bt_synonym   = @engg_grid_page_bts  
			--    and  section_bt_synonym = @engg_grid_sec_bts  
			--    and  control_bt_synonym = @engg_grid_grid_code  
			-- -- code modified by shafina on 03-mar-2004 to alter generation of view name  
			--    if isnull(@viewname_tmp,'') = ''  
			--    begin  
			--     select @view_name = '1'  
			--    end  
			--    else  
			--    begin  
			--     select @view_name = @viewname_tmp + 1  
			--    end  
			SELECT @viewname_tmp = max(cast(view_name AS INT)) + 1
			FROM ep_ui_grid_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_base_req_no
				AND process_name = @prc_name_tmp
				AND component_name = @component_name_tmp
				AND activity_name = @act_name_tmp
				AND ui_name = @ui_name_tmp
				AND page_bt_synonym = @engg_grid_page_bts
				AND section_bt_synonym = @engg_grid_sec_bts
				AND control_bt_synonym = @engg_grid_grid_code

			SELECT @hview_name_tmp = max(cast(a.view_name AS INT)) + 1
			FROM de_hidden_view a(NOLOCK)
			WHERE a.customer_name = @engg_customer_name
				AND a.project_name = @engg_project_name
				AND a.process_name = @prc_name_tmp
				AND a.component_name = @component_name_tmp
				AND a.activity_name = @act_name_tmp
				AND a.ui_name = @ui_name_tmp
				AND a.page_name = @engg_grid_page_bts
				AND a.section_name = @engg_grid_sec_bts
				AND ltrim(rtrim(a.control_bt_synonym)) NOT IN (
					SELECT ltrim(rtrim(b.control_bt_synonym)) --PNR2.0_25211  
					FROM de_ui_control B(NOLOCK)
					WHERE b.customer_name = @engg_customer_name
						AND b.project_name = @engg_project_name
						AND b.process_name = @prc_name_tmp
						AND b.component_name = @component_name_tmp
						AND b.activity_name = @act_name_tmp
						AND b.ui_name = @ui_name_tmp
						AND b.page_bt_synonym = @engg_grid_page_bts
						AND b.section_bt_synonym = @engg_grid_sec_bts
					)

			IF isnull(@viewname_tmp, '') = ''
			BEGIN
				SELECT @view_name = '1'
			END
			ELSE
			BEGIN
				IF cast(isnull(@hview_name_tmp, '0') AS INT) > cast(@viewname_tmp AS INT)
				BEGIN
					SELECT @view_name = @hview_name_tmp
				END
				ELSE
				BEGIN
					SELECT @view_name = @viewname_tmp
				END
			END

			-- code modified by chanheetha N A  for the call id : PNR2.0_11000 on15-Nov-2006  
			-- modified by shafina on 30-jan-2004 to alter generation of view_name  
			-- modified by shafina on 28-jan-2004 to insert view_name  
			/*   if isnull(@viewname_tmp,'') = ''  
begin  
select @view_name = @ctrl_bt_syn_id+'_1'  
end  
else  
begin  
select @vlen = len(@viewname_tmp)  
select @ccnt = 0,  
@rstr = ''  
  
while @ccnt = 0  
begin  
select @cstr = substring(@viewname_tmp,@vlen,1)  
  
if @cstr = '_'  
begin  
select @ccnt = @vlen  
end  
else  
begin  
select @vlen = @vlen - 1,  
@rstr = @cstr + @rstr  
end  
end  
select @rstr = cast(@rstr as int) + 1  
  
select @view_name = @ctrl_bt_syn_id+'_'+@rstr  
end*/
			-- modified by shafina on 21-jan-2004 to generate the controlid  
			--     if len(@count) = 1  
			--     begin  
			--      select @control_id = @ctrl_bt_syn_id + '-' + '00' + @count  
			--     end  
			--     if len(@count) = 2  
			--     begin  
			--      select @control_id = @ctrl_bt_syn_id + '-' + '0' + @count  
			--     end  
			--     if len(@count) = 3  
			--     begin  
			--      select @control_id = @ctrl_bt_syn_id + '-' + @count  
			--     end  
			--    end  
			--    select  @control_id = isnull(@control_id,'')  
			-- Space is passed for Column Prefix for inserting thru common sp - Ramachandran.T 25 Dec 2003  
			/*Insert SP*/
			--code added by DNR for getting unique prefix ID on 30/12/2003  
			EXEC engg_gen_prefix_id @engg_customer_name,
				@engg_project_name,
				@component_name_tmp,
				@act_name_tmp,
				@ui_name_tmp,
				@engg_grid_btsynname,
				'C',
				6,
				@page_prefix_tmp OUTPUT

			EXEC ep_ui_grid_dtl_sp_ins @ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@engg_customer_name,
				@engg_project_name,
				@engg_base_req_no,
				@prc_name_tmp,
				@component_name_tmp,
				@act_name_tmp,
				@ui_name_tmp,
				@engg_grid_page_bts,
				@engg_grid_sec_bts,
				@engg_grid_grid_code,
				@engg_grid_btsynname,
				@ctrl_bt_syn_id,
				@view_name,
				@engg_grid_elem_type,
				@engg_grid_colno,
				@engg_grid_vis_length,
				@engg_grid_tooltip,
				@engg_grid_samp_data,
				@engg_grid_doc,
				@page_prefix_tmp,
				1,
				@engg_req_no,
				@user_pref,
				@grid_def,
				@engg_grd_visible,
				@columnclass, /* @columnheaderclass,*/
				@forcefit,
				@m_errorid OUTPUT --chan    --UserPref added for PNR2.0_23541   --Code Modified for PNR2.0_30869  

			IF @m_errorid > 0
				RETURN
		END

		--Code Modification for PNR2.0_30869 starts  
		IF @engg_grid_default = 1
		BEGIN
			SELECT @newcontrol = @engg_grid_grid_code + 'SetDef'

			IF len(@newcontrol) > 57
				SELECT @newcontrol = left(@engg_grid_grid_code, 51) + 'SetDef'

			EXEC engg_gen_prefix_id @engg_customer_name,
				@engg_project_name,
				@component_name_tmp,
				@act_name_tmp,
				@ui_name_tmp,
				@engg_grid_grid_code,
				'C',
				6,
				@newctrlprefix OUTPUT

			SELECT @newctrlprefix = left(@newctrlprefix, 5) + 'd'

			EXEC ep_controlid_generation @engg_customer_name,
				@engg_project_name,
				@engg_base_req_no,
				@prc_name_tmp,
				@component_name_tmp,
				@act_name_tmp,
				@ui_name_tmp,
				@newcontrol,
				'Edit',
				'N',
				'N',
				@control_id OUTPUT

			IF NOT EXISTS (
					SELECT 'x'
					FROM ep_component_glossary_mst(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND bt_synonym_name = @newcontrol
					)
			BEGIN
				EXEC ep_component_glossary_mst_sp_ins @ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@engg_customer_name,
					@engg_project_name,
					@engg_base_req_no,
					@prc_name_tmp,
					@component_name_tmp,
					'PrjhdnSection',
					NULL,
					'Char',
					60,
					'Section for Grid Defaulting',
					'PrjhdnSection',
					'',
					'U',
					'',
					'',
					1,
					@engg_req_no,
					@m_errorid OUTPUT

				IF @m_errorid <> 0
					RETURN
			END

			IF EXISTS (
					SELECT 'x'
					FROM ep_ui_control_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = '[mainscreen]'
						AND section_bt_synonym = 'PrjhdnSection'
					)
			BEGIN
				SELECT @horder = isnull(max(horder), 0)
				FROM ep_ui_control_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = '[mainscreen]'
					AND section_bt_synonym = 'PrjhdnSection'
			END
			ELSE
				SELECT @horder = 1

			IF EXISTS (
					SELECT 'x'
					FROM ep_ui_control_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = '[mainscreen]'
						AND section_bt_synonym = 'PrjhdnSection'
					)
			BEGIN
				SELECT @vorder = isnull(max(vorder), 0) + 1
				FROM ep_ui_control_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = '[mainscreen]'
					AND section_bt_synonym = 'PrjhdnSection'
			END
			ELSE
				SELECT @vorder = 1

			IF NOT EXISTS (
					SELECT 'x'
					FROM ep_ui_control_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = '[mainscreen]'
						AND section_bt_synonym = 'PrjhdnSection'
						AND control_bt_synonym = @newcontrol
					)
			BEGIN
				EXEC ep_ui_control_dtl_sp_ins @ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@engg_customer_name,
					@engg_project_name,
					@engg_base_req_no,
					@prc_name_tmp,
					@component_name_tmp,
					@act_name_tmp,
					@ui_name_tmp,
					'[mainscreen]',
					'PrjhdnSection',
					@newcontrol,
					@control_id,
					'HiddenEdit',
					0,
					@horder,
					@vorder,
					1,
					0,
					0,
					'',
					'Grid Defaulting',
					'Grid Defaulting',
					@newctrlprefix,
					'',
					'',
					'',
					NULL,
					NULL,
					NULL,
					NULL,
					0,
					NULL,
					1,
					@engg_req_no,
					NULL,
					0,
					'',
					0,
					0,
					'',
					'',
					'',
					'',
					'',
					'',
					'',
					'',
					'',
					0,
					'',
					0,
					'',
					'', ----TECH-75230
					'', ----TECH-75230
					@m_errorid OUTPUT
			END
		END
				--Code Modification for PNR2.0_30869 ends  
	END /*End For Mode Flag 'X' and 'I'*/

	--  modified by shafina on 17-jan-2004 to fetch the task name based on the default_for column  
	-- and to insert the primary control_bts  
	IF @modeflag <> 'D'
	BEGIN
		-- code modified by shafina on 04-June-2004 for PREVIEWENG203ACC_000070  
		--modified by vasu date:29-12-2003  
		-- if control bt synonym which is residing in grid control from glossary  
		-- modified by shafina on 13-jan-2004 to insert length of bt synonym  
		DECLARE @btLength engg_rowno

		SELECT @btLength = isnull(@engg_grid_vis_length, 20)

		-- code modified by shafina on 09-June-2004 for PREVIEWENG203ACC_000072  
		IF @engg_grid_vis_length = 0
			SELECT @btLength = 20

		IF NOT EXISTS (
				SELECT 'x'
				FROM ep_component_glossary_mst(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND bt_synonym_name = @engg_grid_btsynname
				)
		BEGIN
			-- code modified by shafina on 24-feb-2004  
			EXEC ep_generate_caption @engg_grid_btsynname,
				@grid_bt_caption OUTPUT

			-- code modified by shafina on 17-June-2004 for PREVIEWENG203ACC_000073  
			EXEC ep_component_glossary_mst_sp_ins @ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@engg_customer_name,
				@engg_project_name,
				@engg_base_req_no,
				@prc_name_tmp,
				@component_name_tmp,
				@engg_grid_btsynname,
				NULL,
				'Char',
				@btLength,
				@grid_bt_caption,
				@engg_grid_btsynname,
				'',
				'U',
				'',
				'',
				1,
				@engg_req_no, --chan  
				@m_errorid OUTPUT
		END

		-- code added by shafina on 17-feb-2004 to insert into traversal table  
		IF NOT EXISTS (
				SELECT 'x'
				FROM ep_ui_traversal_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = @engg_grid_page_bts
					AND section_bt_synonym = @engg_grid_sec_bts
					AND control_bt_synonym = @engg_grid_btsynname
				)
		BEGIN
			IF @tmp_ctl IN (
					'Link',
					'DataHyperlink'
					) -- code modified for the Bug ID: PNR2.0_33877  
			BEGIN
				EXEC ep_ui_traversal_dtl_sp_ins @ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@engg_customer_name,
					@engg_project_name,
					@engg_base_req_no,
					@prc_name_tmp,
					@component_name_tmp,
					@act_name_tmp,
					@ui_name_tmp,
					@engg_grid_page_bts,
					@engg_grid_sec_bts,
					@engg_grid_btsynname,
					'Lnk',
					'',
					'',
					'',
					'',
					1,
					@engg_req_no,
					'',
					'',
					'',
					@m_errorid OUTPUT --chan  

				IF @m_errorid <> 0
					RETURN
			END

			IF @help_req = 'y'
			BEGIN
				EXEC ep_ui_traversal_dtl_sp_ins @ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@engg_customer_name,
					@engg_project_name,
					@engg_base_req_no,
					@prc_name_tmp,
					@component_name_tmp,
					@act_name_tmp,
					@ui_name_tmp,
					@engg_grid_page_bts,
					@engg_grid_sec_bts,
					@engg_grid_btsynname,
					'Hlp',
					'',
					'',
					'',
					'',
					1,
					@engg_req_no,
					'',
					'',
					'',
					@m_errorid OUTPUT --chan  

				IF @m_errorid <> 0
					RETURN
			END
		END

		--code modified by shafina on 27-jan-2004 to insert into flow_br_mst table  
		--code modified by shafina on 12-Apr-2004 for PREVIEWENG203ACC_000027  
		EXEC ep_task_generation @ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			@engg_customer_name,
			@engg_project_name,
			@engg_base_req_no,
			@prc_name_tmp,
			@component_name_tmp,
			@act_name_tmp,
			@ui_name_tmp,
			@engg_grid_page_bts,
			@engg_grid_sec_bts,
			@engg_grid_grid_code,
			@engg_grid_btsynname,
			@tmp_ctl,
			@event_req,
			@help_req,
			@zoom_req,
			@editable,
			'COLUMN',
			@report_req,
			@engg_req_no, -- code modified by Anuradha on 06-Nov-2006 for the Bug ID :: PNR2.0_10832  
			@m_errorid OUTPUT
	END -- end of if modeflag <> 'D'  

	-- Code added By Feroz for Image Control / Ataach Document Control hidden view creation  
	IF @modeflag <> 'S'
	BEGIN
		/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P begin*/
		DECLARE @hidden_vew_bt_synonym engg_name,
			@engg_grid_btsynname_tmp engg_name
		DECLARE @hidden_vew_bt_synonym_tmp engg_name,
			@ctxt_attach_doc engg_name,
			@hdicount INT

		/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P End*/
		IF @tmp_control_type <> @engg_grid_elem_type
		BEGIN
			/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P begin*/
			IF NOT EXISTS (
					SELECT 'X'
					FROM es_comp_ctrl_type_mst(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND ctrl_type_name = @engg_grid_elem_type
						AND (
							image_upload = 'Y'
							OR attach_document = 'Y'
							)
						AND (
							save_image_content_to_db = 'y'
							OR save_doc_content_to_db = 'y'
							)
					)
			BEGIN
				DELETE
				FROM de_hidden_view_usage
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND control_page_name = @engg_grid_page_bts
					AND control_bt_sysnonym = @engg_grid_btsynname
					AND hidden_view_bt_sysnonym LIKE ('hdi' + @hidden_vew_bt_synonym + '%')

				/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P End*/
				DELETE
				FROM de_hidden_view
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND page_name = @engg_grid_page_bts
					AND section_name = @engg_grid_sec_bts
					AND control_bt_synonym = @engg_grid_btsynname
					/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P */
					AND hidden_view_bt_synonym LIKE ('hdi' + @hidden_vew_bt_synonym + '%')
			END
		END

		IF EXISTS (
				SELECT 'x'
				FROM es_comp_ctrl_type_mst_vw(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND ctrl_type_name = @engg_grid_elem_type
					/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P begin*/
					--and   req_no     = @engg_base_req_no  
					AND (
						image_upload = 'Y'
						OR attach_document = 'Y'
						)
					AND (
						save_image_content_to_db = 'y'
						OR save_doc_content_to_db = 'y'
						)
				)
			/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P End*/
		BEGIN
			IF NOT EXISTS (
					SELECT 'X'
					FROM de_hidden_view(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND ui_name = @ui_name_tmp
						AND page_name = @engg_grid_page_bts
						AND section_name = @engg_grid_sec_bts
						AND control_bt_synonym = @engg_grid_btsynname
					)
			BEGIN
				/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P begin*/
				SET @hdicount = 0

				IF len(@engg_grid_btsynname) > 25
				BEGIN
					SELECT @engg_grid_btsynname_tmp = left(@engg_grid_btsynname, 23)
				END
				ELSE
				BEGIN
					SELECT @engg_grid_btsynname_tmp = @engg_grid_btsynname
				END

				WHILE (1 = 1)
				BEGIN
					SELECT @hidden_vew_bt_synonym = 'hdi' + @engg_grid_btsynname_tmp

					IF @count = 0
					BEGIN
						SELECT @hidden_vew_bt_synonym_tmp = @hidden_vew_bt_synonym
					END
					ELSE
					BEGIN
						SELECT @hidden_vew_bt_synonym_tmp = @hidden_vew_bt_synonym + cast(@hdicount AS VARCHAR)
					END

					IF EXISTS (
							SELECT 'x'
							FROM ep_ui_page_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @prc_name_tmp
								AND component_name = @component_name_tmp
								AND activity_name = @act_name_tmp
								AND ui_name = @ui_name_tmp
								AND page_bt_synonym = @hidden_vew_bt_synonym_tmp
							
							UNION
							
							SELECT 'x'
							FROM ep_ui_section_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @prc_name_tmp
								AND component_name = @component_name_tmp
								AND activity_name = @act_name_tmp
								AND ui_name = @ui_name_tmp
								AND page_bt_synonym = @engg_grid_page_bts
								AND section_bt_synonym = @hidden_vew_bt_synonym_tmp
								AND req_no = @engg_base_req_no
							
							UNION
							
							SELECT 'x'
							FROM ep_ui_control_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @prc_name_tmp
								AND component_name = @component_name_tmp
								AND activity_name = @act_name_tmp
								AND ui_name = @ui_name_tmp
								AND page_bt_synonym = @engg_grid_page_bts
								AND control_bt_synonym = @hidden_vew_bt_synonym_tmp
								AND req_no = @engg_base_req_no
							
							UNION
							
							SELECT 'x'
							FROM ep_ui_grid_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @prc_name_tmp
								AND component_name = @component_name_tmp
								AND activity_name = @act_name_tmp
								AND ui_name = @ui_name_tmp
								AND page_bt_synonym = @engg_grid_page_bts
								AND column_bt_synonym = @hidden_vew_bt_synonym_tmp
								AND req_no = @engg_base_req_no
							
							UNION
							
							SELECT 'x'
							FROM de_hidden_view(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @prc_name_tmp
								AND component_name = @component_name_tmp
								AND activity_name = @act_name_tmp
								AND ui_name = @ui_name_tmp
								AND page_name = @engg_grid_page_bts
								AND hidden_view_bt_synonym = @hidden_vew_bt_synonym_tmp
							
							UNION
							
							SELECT 'x'
							FROM de_scratch_variable(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @prc_name_tmp
								AND component_name = @component_name_tmp
								AND activity_name = @act_name_tmp
								AND ui_name = @ui_name_tmp
								AND page_name = @engg_grid_page_bts
								AND scratch_name = @hidden_vew_bt_synonym_tmp
							
							UNION
							
							SELECT 'x'
							FROM de_scratch_variables_sys(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @prc_name_tmp
								AND component_name = @component_name_tmp
								AND btsynonym = @hidden_vew_bt_synonym_tmp
							)
					BEGIN
						SELECT @hdicount = @hdicount + 1
					END
					ELSE
					BEGIN
						BREAK
					END
				END

				SELECT @hidden_vew_bt_synonym = @hidden_vew_bt_synonym_tmp

				/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P End*/
				IF NOT EXISTS (
						SELECT 'x'
						FROM ep_component_glossary_mst(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND req_no = @engg_base_req_no
							AND process_name = @prc_name_tmp
							AND component_name = @component_name_tmp
							AND bt_synonym_name = @hidden_vew_bt_synonym
						)
				BEGIN
					/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P begin*/
					SELECT @ctxt_attach_doc = 'ctxt_attach_doc'

					IF EXISTS (
							SELECT 'x'
							FROM de_business_term(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @prc_name_tmp
								AND component_name = @component_name_tmp
								AND length = 4000
								AND data_type = 'char'
							)
					BEGIN
						SELECT @ctxt_attach_doc = bt_name
						FROM de_business_term(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @prc_name_tmp
							AND component_name = @component_name_tmp
							AND length = 4000
							AND data_type = 'char'
					END
					ELSE
					BEGIN
						INSERT INTO de_business_term (
							customer_name,
							project_name,
							process_name,
							component_name,
							bt_name,
							bt_descr,
							data_type,
							bt_sysid,
							TIMESTAMP,
							createdby,
							createddate,
							modifiedby,
							modifieddate,
							length,
							precision_type,
							Generatedby,
							ecrno
							)
						VALUES (
							@engg_customer_name,
							@engg_project_name,
							@prc_name_tmp,
							@component_name_tmp,
							@ctxt_attach_doc,
							@ctxt_attach_doc,
							'CHAR',
							NEWID(),
							1,
							@ctxt_user,
							getdate(),
							@ctxt_user,
							getdate(),
							4000,
							'',
							'',
							@engg_base_req_no
							)
					END

					/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P End*/
					EXEC ep_component_glossary_mst_sp_ins @ctxt_language,
						@ctxt_ouinstance,
						@ctxt_service,
						@ctxt_user,
						@engg_customer_name,
						@engg_project_name,
						@engg_base_req_no,
						@prc_name_tmp,
						@component_name_tmp,
						@hidden_vew_bt_synonym,
						NULL,
						'Char',
						4000,
						@hidden_vew_bt_synonym,
						@hidden_vew_bt_synonym,
						/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P */
						@ctxt_attach_doc,
						'U',
						'',
						'',
						1,
						@engg_req_no,
						@m_errorid OUTPUT

					IF @m_errorid <> 0
						RETURN

					/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P begin*/
					INSERT INTO RE_GLOSSARY (
						customer_name,
						project_name,
						bt_synonym_name,
						process_name,
						component_name,
						data_type,
						length,
						bt_synonym_caption,
						glossary_sysid,
						TIMESTAMP,
						createdby,
						createddate,
						modifiedby,
						modifieddate,
						ref_bt_synonym_name,
						bt_synonym_doc,
						bt_name,
						synonym_status,
						singleinst_sample_data,
						multiinst_sample_data,
						rcnno
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@hidden_vew_bt_synonym,
						@prc_name_tmp,
						@component_name_tmp,
						'char',
						4000,
						@hidden_vew_bt_synonym,
						newid(),
						1,
						@ctxt_user,
						getdate(),
						@ctxt_user,
						getdate(),
						'',
						@hidden_vew_bt_synonym,
						@ctxt_attach_doc,
						'R',
						'',
						'',
						''
						)

					INSERT INTO RE_GLOSSARY_LNG_EXTN (
						customer_name,
						project_name,
						process_name,
						component_name,
						bt_synonym_name,
						data_type,
						length,
						bt_synonym_caption,
						glossary_sysid,
						languageid,
						TIMESTAMP,
						createdby,
						createddate,
						modifiedby,
						modifieddate,
						ref_bt_synonym_name,
						bt_synonym_doc,
						bt_name,
						synonym_status,
						singleinst_sample_data,
						multiinst_sample_data,
						rcnno
						)
					SELECT @engg_customer_name,
						@engg_project_name,
						@prc_name_tmp,
						@component_name_tmp,
						@hidden_vew_bt_synonym,
						'char',
						4000,
						@hidden_vew_bt_synonym,
						newid(),
						quick_code,
						1,
						@ctxt_user,
						getdate(),
						@ctxt_user,
						getdate(),
						'',
						@hidden_vew_bt_synonym,
						@ctxt_attach_doc,
						'R',
						'',
						'',
						''
					FROM EP_LANGUAGE_MET(NOLOCK)

					INSERT INTO DE_GLOSSARY (
						customer_name,
						project_name,
						component_name,
						process_name,
						bt_synonym_name,
						data_type,
						length,
						bt_synonym_caption,
						glossary_sysid,
						TIMESTAMP,
						createdby,
						createddate,
						modifiedby,
						modifieddate,
						ref_bt_synonym_name,
						bt_synonym_doc,
						bt_name,
						synonym_status,
						singleinst_sample_data,
						multiinst_sample_data,
						ecrno
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@component_name_tmp,
						@prc_name_tmp,
						@hidden_vew_bt_synonym,
						'char',
						4000,
						@hidden_vew_bt_synonym,
						newid(),
						1,
						@ctxt_user,
						getdate(),
						@ctxt_user,
						getdate(),
						'',
						@hidden_vew_bt_synonym,
						@ctxt_attach_doc,
						'R',
						'',
						'',
						''
						)

					INSERT INTO DE_GLOSSARY_LNG_EXTN (
						customer_name,
						project_name,
						process_name,
						component_name,
						bt_synonym_name,
						data_type,
						length,
						bt_synonym_caption,
						glossary_sysid,
						languageid,
						TIMESTAMP,
						createdby,
						createddate,
						modifiedby,
						modifieddate,
						ref_bt_synonym_name,
						bt_synonym_doc,
						bt_name,
						synonym_status,
						singleinst_sample_data,
						multiinst_sample_data,
						ecrno
						)
					SELECT @engg_customer_name,
						@engg_project_name,
						@prc_name_tmp,
						@component_name_tmp,
						@hidden_vew_bt_synonym,
						'char',
						4000,
						@hidden_vew_bt_synonym,
						newid(),
						quick_code,
						1,
						@ctxt_user,
						getdate(),
						@ctxt_user,
						getdate(),
						'',
						@hidden_vew_bt_synonym,
						@ctxt_attach_doc,
						'R',
						'',
						'',
						''
					FROM EP_LANGUAGE_MET(NOLOCK)
						/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P End*/
				END

				IF NOT EXISTS (
						SELECT 'x'
						FROM de_hidden_view(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @prc_name_tmp
							AND component_name = @component_name_tmp
							AND activity_name = @act_name_tmp
							AND ui_name = @ui_name_tmp
							AND page_name = @engg_grid_page_bts
							AND section_name = @engg_grid_sec_bts
							AND control_bt_synonym = @engg_grid_btsynname
							AND hidden_view_bt_synonym = @hidden_vew_bt_synonym
						)
				BEGIN
					SELECT @ctrl_bt_syn_id = control_id
					FROM ep_ui_grid_dtl(NOLOCK)
					WHERE customer_name = rtrim(@engg_customer_name)
						AND project_name = rtrim(@engg_project_name)
						AND req_no = rtrim(@engg_base_req_no)
						AND process_name = rtrim(@prc_name_tmp)
						AND component_name = rtrim(@component_name_tmp)
						AND activity_name = rtrim(@act_name_tmp)
						AND ui_name = rtrim(@ui_name_tmp)
						AND page_bt_synonym = rtrim(@engg_grid_page_bts)
						AND section_bt_synonym = rtrim(@engg_grid_sec_bts)
						AND control_bt_synonym = rtrim(@engg_grid_grid_code)
						AND column_bt_synonym = rtrim(@engg_grid_btsynname)

					SELECT @viewname_tmp = max(cast(view_name AS INT)) + 1
					FROM ep_ui_grid_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_base_req_no
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = @engg_grid_page_bts
						AND section_bt_synonym = @engg_grid_sec_bts
						AND control_bt_synonym = @engg_grid_grid_code

					SELECT @hview_name_tmp = max(cast(a.view_name AS INT)) + 1
					FROM de_hidden_view a(NOLOCK)
					WHERE a.customer_name = @engg_customer_name
						AND a.project_name = @engg_project_name
						AND a.process_name = @prc_name_tmp
						AND a.component_name = @component_name_tmp
						AND a.activity_name = @act_name_tmp
						AND a.ui_name = @ui_name_tmp
						AND a.page_name = @engg_grid_page_bts
						AND a.section_name = @engg_grid_sec_bts
						AND a.control_bt_synonym NOT IN (
							SELECT b.control_bt_synonym
							FROM de_ui_control B(NOLOCK)
							WHERE b.customer_name = @engg_customer_name
								AND b.project_name = @engg_project_name
								AND b.process_name = @prc_name_tmp
								AND b.component_name = @component_name_tmp
								AND b.activity_name = @act_name_tmp
								AND b.ui_name = @ui_name_tmp
								AND b.page_bt_synonym = @engg_grid_page_bts
								AND b.section_bt_synonym = @engg_grid_sec_bts
							)

					IF isnull(@viewname_tmp, '') = ''
					BEGIN
						SELECT @view_name = '1'
					END
					ELSE
					BEGIN
						IF cast(isnull(@hview_name_tmp, '0') AS INT) > cast(@viewname_tmp AS INT)
						BEGIN
							SELECT @view_name = @hview_name_tmp
						END
						ELSE
						BEGIN
							SELECT @view_name = @viewname_tmp
						END
					END

					INSERT INTO de_hidden_view (
						customer_name,
						project_name,
						process_name,
						component_name,
						activity_name,
						ui_name,
						page_name,
						section_name,
						control_bt_synonym,
						hidden_view_bt_synonym,
						transfer_flag,
						hidden_view_sysid,
						control_sysid,
						TIMESTAMP,
						createdby,
						createddate,
						modifiedby,
						modifieddate,
						control_id,
						view_name,
						new_control_bt_synonym,
						HIDDEN_VIEW_SOURCE,
						ecrno
						)
					SELECT @engg_customer_name,
						@engg_project_name,
						@prc_name_tmp,
						@component_name_tmp,
						@act_name_tmp,
						@ui_name_tmp,
						@engg_grid_page_bts,
						@engg_grid_sec_bts,
						@engg_grid_btsynname,
						@hidden_vew_bt_synonym,
						'N',
						newid(),
						newid(),
						1,
						@ctxt_user,
						getdate(),
						@ctxt_user,
						getdate(),
						@ctrl_bt_syn_id,
						@view_name + 1,
						@hidden_vew_bt_synonym,
						NULL,
						NULL
				END
			END

			IF @modeflag = 'D'
				AND isnull(@del_flag, 'T') = 'T' -- Code Modified for PNR2.0_32228  
			BEGIN
				/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P begin*/
				DELETE
				FROM de_hidden_view_usage
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND control_page_name = @engg_grid_page_bts
					AND control_bt_sysnonym = @engg_grid_btsynname

				/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P End*/
				DELETE
				FROM de_hidden_view
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND page_name = @engg_grid_page_bts
					AND section_name = @engg_grid_sec_bts
					AND control_bt_synonym = @engg_grid_btsynname
					AND hidden_view_bt_synonym = @hidden_vew_bt_synonym
			END
		END
	END

	-- Code added By Feroz for Image Control / Ataach Document Control hidden view creation  
	/*code added by vijay on 29/12/03 for inserting into ep_action_mst*/
	IF @modeflag = 'D'
		AND isnull(@del_flag, 'T') = 'T' -- Code Modified for PNR2.0_32228  
	BEGIN
		IF EXISTS (
				SELECT 'X'
				FROM ep_ui_grid_dtl(NOLOCK)
				WHERE customer_name = rtrim(@engg_customer_name)
					AND project_name = rtrim(@engg_project_name)
					AND req_no = rtrim(@engg_base_req_no)
					AND process_name = rtrim(@prc_name_tmp)
					AND component_name = rtrim(@component_name_tmp)
					AND activity_name = rtrim(@act_name_tmp)
					AND ui_name = rtrim(@ui_name_tmp)
					AND page_bt_synonym = rtrim(@engg_grid_page_bts)
					AND section_bt_synonym = rtrim(@engg_grid_sec_bts)
					AND control_bt_synonym = rtrim(@engg_grid_grid_code)
					AND column_bt_synonym = rtrim(@engg_grid_btsynname)
				)
		BEGIN
			-- code modified by shafina on 27-April-2004 for PREVIEWENG203ACC_000045  
			DECLARE task_del_cur INSENSITIVE CURSOR
			FOR
			SELECT task_name
			FROM ep_action_mst a(NOLOCK),
				ep_ui_grid_dtl b(NOLOCK)
			WHERE a.customer_name = @engg_customer_name
				AND a.project_name = @engg_project_name
				AND a.req_no = @engg_base_req_no
				AND a.process_name = @prc_name_tmp
				AND a.component_name = @component_name_tmp
				AND a.activity_name = @act_name_tmp
				AND a.ui_name = @ui_name_tmp
				AND a.page_bt_synonym = @engg_grid_page_bts
				AND a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.req_no = b.req_no
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.activity_name = b.activity_name
				AND a.ui_name = b.ui_name
				AND a.page_bt_synonym = b.page_bt_synonym
				AND b.section_bt_synonym = @engg_grid_sec_bts
				AND b.control_bt_synonym = @engg_grid_grid_code
				AND b.column_bt_synonym = @engg_grid_btsynname
				AND a.primary_control_bts = @engg_grid_btsynname

			OPEN task_del_cur

			WHILE (1 = 1)
			BEGIN
				FETCH NEXT
				FROM task_del_cur
				INTO @task_name

				IF @@fetch_status <> 0
					BREAK

				IF isnull(@task_name, '') <> ''
				BEGIN
					IF EXISTS (
							SELECT 'x'
							FROM ep_flowbr_mst(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND req_no = @engg_base_req_no
								AND process_name = @prc_name_tmp
								AND component_name = @component_name_tmp
								AND activity_name = @act_name_tmp
								AND ui_name = @ui_name_tmp
								AND page_bt_synonym = @engg_grid_page_bts
								AND task_name = @task_name
							)
					BEGIN
						DELETE ep_flowbr_mst
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND req_no = @engg_base_req_no
							AND process_name = @prc_name_tmp
							AND component_name = @component_name_tmp
							AND activity_name = @act_name_tmp
							AND ui_name = @ui_name_tmp
							AND page_bt_synonym = @engg_grid_page_bts
							AND task_name = @task_name
					END

					IF EXISTS (
							SELECT 'x'
							FROM ep_action_section_map(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND req_no = @engg_base_req_no
								AND process_name = @prc_name_tmp
								AND component_name = @component_name_tmp
								AND activity_name = @act_name_tmp
								AND ui_name = @ui_name_tmp
								AND page_bt_synonym = @engg_grid_page_bts
								AND task_name = @task_name
							)
					BEGIN
						DELETE ep_action_section_map
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND req_no = @engg_base_req_no
							AND process_name = @prc_name_tmp
							AND component_name = @component_name_tmp
							AND activity_name = @act_name_tmp
							AND ui_name = @ui_name_tmp
							AND page_bt_synonym = @engg_grid_page_bts
							AND task_name = @task_name
					END

					EXEC ep_action_mst_sp_del @ctxt_language,
						@ctxt_ouinstance,
						@ctxt_service,
						@ctxt_user,
						@engg_customer_name,
						@engg_project_name,
						@engg_base_req_no,
						@prc_name_tmp,
						@component_name_tmp,
						@act_name_tmp,
						@ui_name_tmp,
						@engg_grid_page_bts,
						@task_name,
						@m_errorid OUTPUT

					IF @m_errorid <> 0
					BEGIN
						CLOSE task_del_cur

						DEALLOCATE task_del_cur

						RETURN
					END
				END
			END

			CLOSE task_del_cur

			DEALLOCATE task_del_cur

			DELETE
			FROM ep_ui_traversal_dtl
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_base_req_no
				AND process_name = @prc_name_tmp
				AND component_name = @component_name_tmp
				AND activity_name = @act_name_tmp
				AND ui_name = @ui_name_tmp
				AND page_bt_synonym = @engg_grid_page_bts
				AND section_bt_synonym = @engg_grid_sec_bts
				AND control_bt_synonym = @engg_grid_btsynname
				AND isnull(linked_component, '') = ''
				AND isnull(linked_activity, '') = ''
				AND isnull(linked_ui, '') = ''

			EXEC ep_ui_grid_dtl_sp_del @ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@engg_customer_name,
				@engg_project_name,
				@engg_base_req_no,
				@prc_name_tmp,
				@component_name_tmp,
				@act_name_tmp,
				@ui_name_tmp,
				@engg_grid_page_bts,
				@engg_grid_sec_bts,
				@engg_grid_grid_code,
				@engg_grid_btsynname,
				@m_errorid OUTPUT

			IF @m_errorid > 0
				RETURN
					-- modified by vasu date:28-12-2003  
					-- to delete the control bt synonym from glossary which is in grid control  
					-- modified by shafina on 07-feb-2004 to check for existence of btsynonym  
					-- modified by shafina on 09-Apr-2004 for PREVIEWENG203ACC_000013  
					/*  declare @cnt int  
select @cnt = 0  
select @cnt = count('x')  
from ep_ui_page_dtl (nolock)  
where customer_name = @engg_customer_name  
and  project_name = @engg_project_name  
and  page_bt_synonym = @engg_grid_btsynname  
  
select @cnt = @cnt +  
(  
select count('x')  
from ep_ui_section_dtl (nolock)  
where customer_name = @engg_customer_name  
and  project_name = @engg_project_name  
and  section_bt_synonym = @engg_grid_btsynname  
)  
  
select @cnt = @cnt +  
(  
select count('x')  
from ep_ui_control_dtl (nolock)  
where customer_name = @engg_customer_name  
and  project_name = @engg_project_name  
and  control_bt_synonym = @engg_grid_btsynname  
)  
  
select @cnt = @cnt +  
(  
select count('x')  
from ep_ui_grid_dtl (nolock)  
where customer_name = @engg_customer_name  
and  project_name = @engg_project_name  
and  column_bt_synonym = @engg_grid_btsynname  
)  
if @cnt  = 0  
begin  
if exists  (select 'x'  
from ep_component_glossary_mst (nolock)  
where  customer_name =   @engg_customer_name  
and    project_name    =   @engg_project_name  
and    req_no          =   @engg_base_req_no  
and  process_name =  @prc_name_tmp  
and  component_name =  @component_name_tmp  
and    bt_synonym_name = @engg_grid_btsynname)  
begin  
exec ep_component_glossary_mst_sp_del  
@ctxt_language,  
@ctxt_ouinstance,  
@ctxt_service,  
@ctxt_user,  
@engg_customer_name,  
@engg_project_name,  
@engg_base_req_no,  
@prc_name_tmp,  
@component_name_tmp,  
@engg_grid_btsynname,  
@m_errorid out--PARAMETER ADDED BY GIRIDHARAN V ON 10/01/2004  
  
If @m_errorID >0  
return  
end  
end*/
		END
	END

	IF EXISTS (
			SELECT 'x'
			FROM sysobjects(NOLOCK)
			WHERE name = 'de_customer_space'
				AND type = 'u'
			)
	BEGIN
		UPDATE de_customer_space
		SET validate_req = 'Y'
		WHERE customername = @engg_customer_name
			AND projectname = @engg_project_name
			AND processname = @prc_name_tmp
			AND componentname = @component_name_tmp
	END

	--output parameters  
	SELECT @fprowno = @fprowno + 1

	SELECT @fprowno 'fprowno',
		@engg_del_columns 'engg_del_columns'

	/* 
	--OutputList
		Select
		null 'fprowno', 
		null 'engg_del_columns', 
	*/
	SET NOCOUNT OFF
END

GO
IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME= 'uid_ep_layout_sp_savgrdgdml' AND TYPE='P')
BEGIN
	GRANT EXEC ON  uid_ep_layout_sp_savgrdgdml TO PUBLIC
END
GO