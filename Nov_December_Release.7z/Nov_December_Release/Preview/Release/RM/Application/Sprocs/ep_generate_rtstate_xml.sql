IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME ='ep_generate_rtstate_xml' AND TYPE='P')
   BEGIN
        DROP PROC ep_generate_rtstate_xml
   END
GO 
/************************************************************************************/
/* Created by	: Venkatesan K	for callid TECH-7349								*/
/* Created ON	: 08-Nov-2022				 										*/
/* DescriptiON	:  Procedure for preview level state xml generatiON					*/
/***********************************************************************************/
CREATE PROCEDURE ep_generate_rtstate_xml
	@customer	VARCHAR(60),  
	@project	VARCHAR(60),  
	@process	VARCHAR(60),  
	@Component	VARCHAR(60),  
	@act		VARCHAR(60),
	@ui			VARCHAR(60)  
AS  
BEGIN  
	SET NOCOUNT ON 
  
	----list of files to be created for Control xml  
	--SELECT  DISTINCT sc.activity_name,  sc.ui_name  
	--FROM	ep_ui_state_Control_dtl sc (NOLOCK)  	INNER JOIN  
	--		ep_ui_Control_dtl c (NOLOCK)  
	--ON		c.customer_name			=	sc.customer_name  
	--AND		c.project_name			=	sc.project_name 
	--AND		c.process_name			=	sc.process_name  
	--AND		c.Component_name		=	sc.Component_name  
	--AND		c.activity_name			=	sc.activity_name  
	--AND		c.ui_name				=	sc.ui_name 
	--AND		c.page_bt_synonym		=	sc.page_bt_synonym
	--AND		c.Control_bt_synonym	=	sc.Control_bt_synonym
	--AND		c.Control_bt_synonym	=	sc.Control_bt_synonym  

	--WHERE  	sc.customer_name		=	@customer  
	--AND		sc.project_name			=	@project  
	--AND		sc.process_name			=	@process  
	--AND		sc.Component_name		=	@Component  
	--AND		sc.activity_name		=	@act
	--AND		sc.ui_name				=	@ui
	----group by sc.activity_name, sc.ui_name
	--UNION      
	----grid column  
	--SELECT DISTINCT	sc.activity_name,  sc.ui_name  
	--FROM	ep_ui_state_column_dtl sc (NOLOCK)  INNER JOIN  
	--		ep_ui_grid_dtl gc (NOLOCK)  
	--ON		sc.customer_name		=	gc.customer_name  
	--AND		sc.project_name			=	gc.project_name	  
	--AND		sc.process_name			=	gc.process_name  
	--AND		sc.Component_name		=	gc.Component_name  
	--AND		sc.activity_name		=	gc.activity_name  
	--AND		sc.ui_name				=	gc.ui_name
	--AND		sc.page_bt_synonym		=	gc.page_bt_synonym
	--AND		sc.sectiON_bt_synonym	=	gc.sectiON_bt_synonym  
	--AND		sc.Control_bt_synonym	=	gc.Control_bt_synonym  
	--AND		sc.column_bt_synonym	=	gc.column_bt_synonym
	
	--WHERE	sc.customer_name		=	@customer  
	--AND		sc.project_name			=	@project  
	--AND		sc.process_name			=	@process  
	--AND		sc.Component_name		=	@Component  
	--AND		sc.activity_name		=	@act
	--AND		sc.ui_name				=	@ui
	----group by sc.activity_name, sc.ui_name      
	--UNION      
	----sectiON  
	--SELECT DISTINCT activity_name, ui_name  
	--FROM   ep_ui_state_sectiON_dtl (NOLOCK)  
	--WHERE	customer_name	= @customer  
	--AND		project_name	= @project  
	--AND		process_name	= @process  
	--AND		Component_name	= @Component  
	--AND		activity_name	= @act
	--AND		ui_name			= @ui 
	--UNION      
	----page  
	--SELECT DISTINCT  activity_name,  ui_name  
	--FROM	ep_ui_state_page_dtl (NOLOCK)  
	--WHERE	customer_name	= @customer  
	--AND		project_name	= @project  
	--AND		process_name	= @process  
	--AND		Component_name	= @Component  
	--AND		activity_name	= @act
	--AND		ui_name			= @ui

	--state details for Controls  
	--PLF2.0_15017 code change for including Control type **starts**
	SELECT DISTINCT  
			sc.activity_name,  
			sc.ui_name,  
			state_id,  
			'control'  as [type], 
			ct.base_ctrl_type as control_type,   
			control_id,  
			lower(visible) as visible,  
			lower([enable]) as [enable] ,
			isnull(focus,'') 'focus' -- tech-53416
	FROM	ep_ui_state_Control_dtl sc (NOLOCK)  
	INNER JOIN  	ep_ui_Control_dtl c (NOLOCK)    -- PLF2.0_16546
	ON		c.customer_name			=	sc.customer_name  
	AND		c.project_name			=	sc.project_name
	AND		c.process_name			=	sc.process_name  
	AND		c.Component_name		=	sc.Component_name  
	AND		c.activity_name			=	sc.activity_name  
	AND		c.ui_name				=	sc.ui_name
	AND		c.page_bt_synonym		=	sc.page_bt_synonym
	AND		c.sectiON_bt_synonym	=	sc.sectiON_bt_synonym
	AND		c.Control_bt_synonym	=	sc.Control_bt_synonym  
	INNER JOIN	es_comp_ctrl_type_mst ct(NOLOCK)
	ON		ct.customer_name		=	c.customer_name
	AND		ct.project_name			=	c.project_name
	AND		ct.process_name			=	c.process_name
	AND		ct.Component_name		=	c.Component_name
	AND		ct.ctrl_type_name		=	c.Control_type

	WHERE	sc.customer_name		=	@customer  
	AND		sc.project_name			=	@project  
	AND		sc.process_name			=	@process  
	AND		sc.Component_name		=	@Component  
	AND		sc.activity_name		=	@act
	AND		sc.ui_name				=	@ui
	--group 	by		sc.state_id, c.Control_id,ct.base_ctrl_type, sc.visible, sc.[enable], sc.activity_name, sc.ui_name  
	--PLF2.0_15017 code change for including Control type **ends**

	--PLF2.0_15017 code change to fetch enable property starts
	--state details for grid columns  
	SELECT	sc.activity_name,  
			sc.ui_name, 
			sc.state_id,  
			'column'  as [type], 
			gc.control_id,  
			gc.view_name,  
			sc.visible , 
			sc.enable 
	FROM	ep_ui_state_column_dtl sc (NOLOCK) INNER JOIN  
			ep_ui_grid_dtl gc (NOLOCK)  
	ON		sc.customer_name		=	gc.customer_name  
	AND		sc.project_name			=	gc.project_name
	AND		sc.process_name			=	gc.process_name  
	AND		sc.Component_name		=	gc.Component_name  
	AND		sc.activity_name		=	gc.activity_name  
	AND		sc.ui_name				=	gc.ui_name
	AND		sc.page_bt_synonym		=	gc.page_bt_synonym
	AND		sc.sectiON_bt_synonym	=	gc.sectiON_bt_synonym  
	AND		sc.Control_bt_synonym	=	gc.Control_bt_synonym  
	AND		sc.column_bt_synonym	=	gc.column_bt_synonym  
	
	WHERE	sc.customer_name		=	@customer  
	AND		sc.project_name			=	@project  
	AND		sc.process_name			=	@process  
	AND		sc.Component_name		=	@Component  
	AND		sc.activity_name		=	@act
	AND		sc.ui_name				=	@ui
	ORDER BY  sc.activity_name, sc.ui_name,  sc.state_id, gc.Control_id,  gc.view_name  
	--PLF2.0_15017 code change to fetch enable property ends

	--Code added for tabControl additiON in xml 

	SELECT	activity_name,  
			ui_name,  
			count(page_bt_synonym) as 'basecount' 	
			into #ep_ui_state_base_page_count
	FROM   ep_ui_page_dtl (NOLOCK)  
	WHERE	customer_name	= @customer  
	AND		project_name	= @project   
	AND		process_name	= @process  
	AND		Component_name	= @Component  
	AND		activity_name	= @act
	AND		ui_name			= @ui
	AND		page_bt_synonym <> '[mainscreen]'
	GROUP BY activity_name,  ui_name	

	SELECT	activity_name,  
			ui_name,  
			state_id, 
			count(page_bt_synonym) as 'statecount'
    INTO #ep_ui_state_page_count
	FROM   ep_ui_state_page_dtl (NOLOCK)  
	WHERE	customer_name	=	@customer  
	AND		project_name	=	@project  
	AND		process_name	=	@process  
	AND		Component_name	=	@Component  
	AND		activity_name	=	@act
	AND		ui_name			=	@ui
	AND 	visible  		=	'N'
	GROUP BY activity_name,  ui_name,  state_id 
	
	SELECT	activity_name,  
			ui_name,  
			state_id, 
			count(page_bt_synonym) as 'statecount'
    into #ep_ui_state_page_count_yes
	FROM   ep_ui_state_page_dtl (NOLOCK)  
	WHERE	customer_name	=	@customer  
	AND		project_name	=	@project  
	AND		process_name	=	@process  
	AND		Component_name	=	@Component  
	AND		activity_name	=	@act
	AND		ui_name			=	@ui
	AND 	visible  		=	'Y'
	GROUP BY activity_name,  ui_name,  state_id 	

	--state details for sectiONs  
	SELECT	activity_name, 
			ui_name,  
			state_id,  
			'control' as [type],  
			section_bt_synonym,  
			visible,  
			[enable],  
			collapse  
	FROM	ep_ui_state_sectiON_dtl (NOLOCK)  
	WHERE	customer_name	=	@customer  
	AND		project_name	=	@project  
	AND		process_name	=	@process  
	AND		Component_name	=	@Component  
	AND		activity_name	=	@act
	AND		ui_name			=	@ui
	UNION
	SELECT DISTINCT  
			activity_name,  
			ui_name,  
			state_id,  
			'control' as [type],  
			'tabcontrol',  
			'n',  
			'n',  
			'n'    
	FROM   ep_ui_state_page_dtl a(NOLOCK)  
	WHERE	customer_name	=	@customer  
	AND		project_name	=	@project  
	AND		process_name	=	@process  
	AND		Component_name	=	@Component  
	AND		activity_name	=	@act
	AND		ui_name			=	@ui 
	AND EXISTS (SELECT 'K' FROM #ep_ui_state_page_count b (NOLOCK) , 
								#ep_ui_state_base_page_count c (NOLOCK)
								WHERE 	a.activity_name		=	b.activity_name  
								AND		a.ui_name			=	b.ui_name  
								AND		a.state_id			=	b.state_id
								AND		b.activity_name		=	c.activity_name  
								AND		b.ui_name			=	c.ui_name  
								AND		b.statecount		=	c.basecount )
	UNION
	SELECT DISTINCT  activity_name,  
					ui_name,  
					state_id,  
					'control' as [type],  
					'tabcontrol',  
					'y',  
					'y',  
					'n'    
	FROM   ep_ui_state_page_dtl a(NOLOCK)  
	WHERE	customer_name	=	@customer  
	AND		project_name	=	@project  
	AND		process_name	=	@process  
	AND		Component_name	=	@Component  
	AND		activity_name	=	@act
	AND		ui_name			=	@ui 
	AND EXISTS (SELECT 'K' FROM #ep_ui_state_page_count_yes b (NOLOCK) , 
								#ep_ui_state_base_page_count c (NOLOCK)
							WHERE 	a.activity_name		=	b.activity_name  
							AND		a.ui_name			=	b.ui_name  
							AND		a.state_id			=	b.state_id
							AND		b.activity_name		=	c.activity_name  
							AND		b.ui_name			=	c.ui_name  
							AND		((b.statecount		=	c.basecount) 
									or (b.statecount				<>	c.basecount)) )				

    
  --state details for page

	SELECT  activity_name,  
			ui_name,  
			state_id,  
			'control' as [type],  
			page_bt_synonym,  
			visible,  
			[enable],  
			focus    
	FROM   ep_ui_state_page_dtl a (NOLOCK)  
	WHERE	customer_name	=	@customer  
	AND		project_name	=	@project  
	AND		process_name	=	@process  
	AND		Component_name	=	@Component  
	AND		activity_name	=	@act
	AND		ui_name			=	@ui 
	AND NOT EXISTS (SELECT 'K' FROM #ep_ui_state_page_count b (NOLOCK) , 
									#ep_ui_state_base_page_count c (NOLOCK)
								WHERE 	a.activity_name		=	b.activity_name  
								AND		a.ui_name			=	b.ui_name  
								AND		a.state_id			=	b.state_id
								AND		b.activity_name		=	c.activity_name  
								AND		b.ui_name			=	c.ui_name  
								AND		b.statecount		=	c.basecount )
	ORDER BY 	CASE WHEN visible = 	'Y'  THEN 1 ELSE 2 END 


DROP TABLE #ep_ui_state_page_count
DROP TABLE 	#ep_ui_state_base_page_count
	
END 
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME= 'ep_generate_rtstate_xml' AND TYPE='P')
BEGIN
	GRANT EXEC ON  ep_generate_rtstate_xml TO PUBLIC
END
GO
