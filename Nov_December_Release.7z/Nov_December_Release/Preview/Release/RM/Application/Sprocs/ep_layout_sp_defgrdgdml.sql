IF EXISTS  (SELECT 'X' FROM SYSOBJECTS WHERE NAME ='ep_layout_sp_defgrdgdml' AND TYPE = 'P')
    BEGIN
        DROP PROC ep_layout_sp_defgrdgdml
    END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		ep_layout_sp_defgrdgdml.sql
********************************************************************************/
/*      V E R S I O N      :  PNR2.0_1403    */
/*      Released By        :  Development Team    */
/*      Release Comments   :  For DotNet Migration, Naming convention has been changed  for some of the out parameters by using Stub Generator.Comments will not be there for this Request ID.    */
/*      V E R S I O N      :  2.0.4    */
/*      Released By        :  Ptech    */
/*      Release Comments   :  Released On 30-September-2004    */
/*      V E R S I O N      :  2.0.2    */
/*      Released By        :  PTech    */
/*      Release Comments   :  Released on  22-Jan-2004    */
/********************************************************************************/
/* procedure      ep_layout_sp_defgrdgdml                                       */
/* description                                                                  */
/********************************************************************************/
/* project        Preview                                                       */
/* version                                                                      */
/********************************************************************************/
/* referenced                                                                   */
/* tables                                                                       */
/********************************************************************************/
/* development history                                                          */
/********************************************************************************/
/* author         Shafina Begum.B                                               */
/* date           1/ 12/ 2003                                                   */
/********************************************************************************/
/* modification history                                                         */
/********************************************************************************/
/* modified by			Date				Defect ID							*/
/* Veena U				08-Jun-2016			PLF2.0_18487						*/
/* Modified by : Rajeswari M/Priyadharshini U Date: 28-Jul-2021  Defect ID : TECH-60451    */
/* TECH-60451  : Launching Help&Link UIs, Popup sections and Grid Extensions in Side Drawer*/
/********************************************************************************/
/* Modified by : Ponmalar A		Date: 02-Dec-2022  Defect ID : TECH-75230		*/
/********************************************************************************/
CREATE PROCEDURE ep_layout_sp_defgrdgdml
	@ctxt_language_in engg_ctxt_language,
	@ctxt_ouinstance_in engg_ctxt_ouinstance,
	@ctxt_service_in engg_ctxt_service,
	@ctxt_user_in engg_ctxt_user,
	@engg_act_descr_in engg_description,
	@engg_col_descr_in engg_description,
	@engg_component_in engg_description,
	@engg_customer_name_in engg_name,
	@engg_enum_page_bts_in engg_name,
	@engg_enum_sec_bts_in engg_name,
	@engg_grid_btsynname_in engg_name,
	@engg_grid_colno_in engg_seqno,
	@engg_grid_doc_in engg_documentation,
	@engg_grid_elem_type_in engg_description,
	@engg_grid_grid_code_in engg_name,
	@engg_grid_page_bts_in engg_name,
	@engg_grid_samp_data_in engg_documentation,
	@engg_grid_sec_bts_in engg_name,
	@engg_grid_tooltip_in engg_documentation,
	@engg_grid_vis_length_in engg_length,
	@engg_process_descr_in engg_description,
	@engg_project_name_in engg_name,
	@engg_req_no_in engg_name,
	@engg_rf_act_in engg_description,
	@engg_rf_comp_in engg_description,
	@engg_rf_ui_in engg_description,
	@engg_ui_descr_in engg_description,
	@guid_in engg_guid,
	@modeflag_in engg_modeflag,
	@engg_grid_default engg_flag, --Input 
	@fprowno_io engg_rowno,
	@engg_grd_visible engg_flag, --Input 
	@columnclass engg_flag, --Input 
	@forcefit engg_flag, --Input
	@engg_col_tempid engg_name, --Input 
	@col_temp_cat engg_name, --Input 
	@col_temp_specific engg_documentation, --Input 
	@m_errorid INT OUTPUT,
--code added on 19th July 2021
	@engg_extensionreqd engg_seqno, --Input
	@engg_extensionorder engg_seqno, --Input
	@col_Icon_position	engg_name	--TECH-75230
AS
BEGIN
	SET NOCOUNT ON

	--declaration of temporary variables
	DECLARE @ctxt_language engg_ctxt_language
	DECLARE @ctxt_ouinstance engg_ctxt_ouinstance
	DECLARE @ctxt_service engg_ctxt_service
	DECLARE @ctxt_user engg_ctxt_user
	DECLARE @engg_act_descr engg_description
	DECLARE @engg_col_descr engg_description
	DECLARE @engg_component engg_description
	DECLARE @engg_customer_name engg_name
	DECLARE @engg_enum_page_bts engg_name
	DECLARE @engg_enum_sec_bts engg_name
	DECLARE @engg_grid_btsynname engg_name
	DECLARE @engg_grid_colno engg_seqno
	DECLARE @engg_grid_doc engg_documentation
	DECLARE @engg_grid_elem_type engg_description
	DECLARE @engg_grid_grid_code engg_name
	DECLARE @engg_grid_page_bts engg_name
	DECLARE @engg_grid_samp_data engg_documentation
	DECLARE @engg_grid_sec_bts engg_name
	DECLARE @engg_grid_tooltip engg_documentation
	DECLARE @engg_grid_vis_length engg_length
	DECLARE @engg_process_descr engg_description
	DECLARE @engg_project_name engg_name
	DECLARE @engg_req_no engg_name
	DECLARE @engg_rf_act engg_description
	DECLARE @engg_rf_comp engg_description
	DECLARE @engg_rf_ui engg_description
	DECLARE @engg_ui_descr engg_description
	DECLARE @guid engg_guid
	DECLARE @modeflag engg_modeflag
	DECLARE @fprowno engg_rowno

	--temporary and formal parameters mapping
	SELECT @ctxt_language = @ctxt_language_in

	SELECT @ctxt_ouinstance = @ctxt_ouinstance_in

	SELECT @ctxt_service = ltrim(rtrim(@ctxt_service_in))

	SELECT @ctxt_user = ltrim(rtrim(@ctxt_user_in))

	SELECT @engg_act_descr = ltrim(rtrim(@engg_act_descr_in))

	SELECT @engg_col_descr = ltrim(rtrim(@engg_col_descr_in))

	SELECT @engg_component = ltrim(rtrim(@engg_component_in))

	SELECT @engg_customer_name = ltrim(rtrim(@engg_customer_name_in))

	SELECT @engg_enum_page_bts = ltrim(rtrim(@engg_enum_page_bts_in))

	SELECT @engg_enum_sec_bts = ltrim(rtrim(@engg_enum_sec_bts_in))

	SELECT @engg_grid_btsynname = ltrim(rtrim(@engg_grid_btsynname_in))

	SELECT @engg_grid_colno = @engg_grid_colno_in

	SELECT @engg_grid_doc = ltrim(rtrim(@engg_grid_doc_in))

	SELECT @engg_grid_elem_type = ltrim(rtrim(@engg_grid_elem_type_in))

	SELECT @engg_grid_grid_code = ltrim(rtrim(@engg_grid_grid_code_in))

	SELECT @engg_grid_page_bts = ltrim(rtrim(@engg_grid_page_bts_in))

	SELECT @engg_grid_samp_data = ltrim(rtrim(@engg_grid_samp_data_in))

	SELECT @engg_grid_sec_bts = ltrim(rtrim(@engg_grid_sec_bts_in))

	SELECT @engg_grid_tooltip = ltrim(rtrim(@engg_grid_tooltip_in))

	SELECT @engg_grid_vis_length = @engg_grid_vis_length_in

	SELECT @engg_process_descr = ltrim(rtrim(@engg_process_descr_in))

	SELECT @engg_project_name = ltrim(rtrim(@engg_project_name_in))

	SELECT @engg_req_no = ltrim(rtrim(@engg_req_no_in))

	SELECT @engg_rf_act = ltrim(rtrim(@engg_rf_act_in))

	SELECT @engg_rf_comp = ltrim(rtrim(@engg_rf_comp_in))

	SELECT @engg_rf_ui = ltrim(rtrim(@engg_rf_ui_in))

	SELECT @engg_ui_descr = ltrim(rtrim(@engg_ui_descr_in))

	SELECT @guid = ltrim(rtrim(@guid_in))

	SELECT @modeflag = ltrim(rtrim(@modeflag_in))

	SELECT @fprowno = @fprowno_io

	--null checking
	IF @ctxt_language = - 915
		SELECT @ctxt_language = NULL

	IF @ctxt_ouinstance = - 915
		SELECT @ctxt_ouinstance = NULL

	IF @ctxt_service = '~#~'
		SELECT @ctxt_service = NULL

	IF @ctxt_user = '~#~'
		SELECT @ctxt_user = NULL

	IF @engg_act_descr = '~#~'
		SELECT @engg_act_descr = NULL

	IF @engg_col_descr = '~#~'
		SELECT @engg_col_descr = NULL

	IF @engg_component = '~#~'
		SELECT @engg_component = NULL

	IF @engg_customer_name = '~#~'
		SELECT @engg_customer_name = NULL

	IF @engg_enum_page_bts = '~#~'
		SELECT @engg_enum_page_bts = NULL

	IF @engg_enum_sec_bts = '~#~'
		SELECT @engg_enum_sec_bts = NULL

	IF @engg_grid_btsynname = '~#~'
		SELECT @engg_grid_btsynname = NULL

	IF @engg_grid_colno = - 915
		SELECT @engg_grid_colno = NULL

	IF @engg_grid_doc = '~#~'
		SELECT @engg_grid_doc = NULL

	IF @engg_grid_elem_type = '~#~'
		SELECT @engg_grid_elem_type = NULL

	IF @engg_grid_grid_code = '~#~'
		SELECT @engg_grid_grid_code = NULL

	IF @engg_grid_page_bts = '~#~'
		SELECT @engg_grid_page_bts = NULL

	IF @engg_grid_samp_data = '~#~'
		SELECT @engg_grid_samp_data = NULL

	IF @engg_grid_sec_bts = '~#~'
		SELECT @engg_grid_sec_bts = NULL

	IF @engg_grid_tooltip = '~#~'
		SELECT @engg_grid_tooltip = NULL

	IF @engg_grid_vis_length = - 915
		SELECT @engg_grid_vis_length = NULL

	IF @engg_process_descr = '~#~'
		SELECT @engg_process_descr = NULL

	IF @engg_project_name = '~#~'
		SELECT @engg_project_name = NULL

	IF @engg_req_no = '~#~'
		SELECT @engg_req_no = NULL

	IF @engg_rf_act = '~#~'
		SELECT @engg_rf_act = NULL

	IF @engg_rf_comp = '~#~'
		SELECT @engg_rf_comp = NULL

	IF @engg_rf_ui = '~#~'
		SELECT @engg_rf_ui = NULL

	IF @engg_ui_descr = '~#~'
		SELECT @engg_ui_descr = NULL

	IF @guid = '~#~'
		SELECT @guid = NULL

	IF @modeflag = '~#~'
		SELECT @modeflag = NULL

	IF @fprowno = - 915
		SELECT @fprowno = NULL


	IF @engg_extensionreqd = -915
		SELECT @engg_extensionreqd = NULL

	IF @engg_extensionorder = -915
		SELECT engg_extensionorder = NULL  --Code added for TECH-60451

	--errors mapped
	--output parameters
	--	select  null     'fprowno_io' /* DOTNET Migration Tool Changes */ 
	SET NOCOUNT OFF
END
GO

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_layout_sp_defgrdgdml' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON ep_layout_sp_defgrdgdml TO PUBLIC
END
GO
