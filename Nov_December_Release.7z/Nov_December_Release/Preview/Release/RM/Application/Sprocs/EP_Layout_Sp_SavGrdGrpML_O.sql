IF EXISTS  (SELECT 'X' FROM SYSOBJECTS WHERE NAME ='EP_Layout_Sp_SavGrdGrpML_O' AND TYPE = 'P')
    Begin
        Drop PROC EP_Layout_Sp_SavGrdGrpML_O
    End
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		EP_Layout_Sp_SavGrdGrpML_O.sql
********************************************************************************/
/******************************************************************************/
/* Procedure					: EP_Layout_Sp_SavGrdGrpML_O								 */
/* Description					: 								 */
/******************************************************************************/
/* Project						: 								 */
/* EcrNo						: 								 */
/* Version						: 								 */
/******************************************************************************/
/* Referenced					: 								 */
/* Tables						: 								 */
/******************************************************************************/
/* Development history			: 								 */
/******************************************************************************/
/* Author						: ModelExplorer								 */
/* Date							: May 13 2016 11:08AM								 */
/******************************************************************************/
/* Modification History			: 								 */
/******************************************************************************/
/* Modified by  : Veena U                                                   */
/* Date         : 03-Jun-2016                                                  */
/* Defect ID	: PLF2.0_18487                                                 */
/********************************************************************************/
/* modified by			Date				Defect ID							*/
/* Veena U				08-Jun-2016			PLF2.0_18487						*/
/********************************************************************************/
/* Modified by : Ganesh Prabhu S/Ranjitha R      for callid  TECH-10118                   */
/* Modified on : 30-May-2017                                                                                        */
/* Description : Platform Feature Release                                                              */
/***********************************************************************************************/
/* Modified by    :    VimalKumar R                                                            */
/* Modified on    :    03/11/22                                                                */
/* Defect ID      :    TECH-73052															   */
/* Description    :    Need new column- Column caption from Respective grid controls-In column
                       grouping tab in addition with existing Column name/synonym.             */
/***********************************************************************************************/


CREATE PROCEDURE EP_Layout_Sp_SavGrdGrpML_O
	@ctxt_ouinstance ctxt_ouinstance, --Input 
	@ctxt_user ctxt_user, --Input 
	@ctxt_language ctxt_language, --Input 
	@ctxt_service ctxt_service, --Input 
	@engg_act_descr engg_description, --Input 
	@engg_component engg_description, --Input 
	@engg_customer_name engg_name, --Input 
	@engg_process_descr engg_description, --Input 
	@engg_project_name engg_name, --Input 
	@engg_req_no engg_name, --Input 
	@engg_ui_descr engg_description, --Input 
	@m_errorid INT OUTPUT --To Return Execution Status
AS
BEGIN
	-- nocount should be switched on to prevent phantom rows
	SET NOCOUNT ON
	-- @m_errorid should be 0 to Indicate Success
	SET @m_errorid = 0
	--declaration of temporary variables
	--temporary and formal parameters mapping
	SET @ctxt_user = ltrim(rtrim(@ctxt_user))
	SET @ctxt_service = ltrim(rtrim(@ctxt_service))
	SET @engg_act_descr = ltrim(rtrim(@engg_act_descr))
	SET @engg_component = ltrim(rtrim(@engg_component))
	SET @engg_customer_name = ltrim(rtrim(@engg_customer_name))
	SET @engg_process_descr = ltrim(rtrim(@engg_process_descr))
	SET @engg_project_name = ltrim(rtrim(@engg_project_name))
	SET @engg_req_no = ltrim(rtrim(@engg_req_no))
	SET @engg_ui_descr = ltrim(rtrim(@engg_ui_descr))

	--null checking
	IF @ctxt_ouinstance = - 915
		SELECT @ctxt_ouinstance = NULL

	IF @ctxt_user = '~#~'
		SELECT @ctxt_user = NULL

	IF @ctxt_language = - 915
		SELECT @ctxt_language = NULL

	IF @ctxt_service = '~#~'
		SELECT @ctxt_service = NULL

	IF @engg_act_descr = '~#~'
		SELECT @engg_act_descr = NULL

	IF @engg_component = '~#~'
		SELECT @engg_component = NULL

	IF @engg_customer_name = '~#~'
		SELECT @engg_customer_name = NULL

	IF @engg_process_descr = '~#~'
		SELECT @engg_process_descr = NULL

	IF @engg_project_name = '~#~'
		SELECT @engg_project_name = NULL

	IF @engg_req_no = '~#~'
		SELECT @engg_req_no = NULL

	IF @engg_ui_descr = '~#~'
		SELECT @engg_ui_descr = NULL

	DECLARE @tmp_proc engg_name,
		@tmp_comp engg_name,
		@tmp_act engg_name,
		@tmp_ui engg_name,
		@grd_page engg_name,
		@grd_sec engg_name,
		@grd_ctrl engg_name,
		@grp_name engg_name,
		@seqno engg_seqno,
		@sequence engg_seqno

	SELECT @tmp_proc = rtrim(process_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_req_no)
		AND process_descr = rtrim(@engg_process_descr)

	SELECT @tmp_comp = rtrim(component_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_descr = rtrim(@engg_component)

	SELECT TOP 1 @tmp_act = rtrim(activity_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp)
		AND activity_descr = RTRIM(@engg_act_descr)

	SELECT TOP 1 @tmp_ui = rtrim(ui_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND process_name = rtrim(@tmp_proc)
		AND req_no = rtrim(@engg_req_no)
		AND component_name = rtrim(@tmp_comp)
		AND activity_name = rtrim(@tmp_act)
		AND ui_descr = RTRIM(@engg_ui_descr)

	SELECT TOP 1 @grd_page = rtrim(p.page_bt_synonym)
	FROM ep_ui_page_dtl p(NOLOCK)
	WHERE p.customer_name = rtrim(@engg_customer_name)
		AND p.project_name = rtrim(@engg_project_name)
		AND p.process_name = rtrim(@tmp_proc)
		AND p.component_name = rtrim(@tmp_comp)
		AND p.activity_name = rtrim(@tmp_act)
		AND p.ui_name = rtrim(@tmp_ui)
		AND p.page_bt_synonym IN (
			SELECT c.page_bt_synonym
			FROM ep_ui_control_dtl c(NOLOCK),
				es_comp_ctrl_type_mst_vw v(NOLOCK)
			WHERE p.customer_name = c.customer_name
				AND p.project_name = c.project_name
				AND p.process_name = c.process_name
				AND p.component_name = c.component_name
				AND p.activity_name = c.activity_name
				AND p.ui_name = c.ui_name
				AND p.page_bt_synonym = c.page_bt_synonym
				AND c.customer_name = v.customer_name
				AND c.project_name = v.project_name
				AND c.process_name = v.process_name
				AND c.component_name = v.component_name
				AND c.control_type = v.ctrl_type_name
				AND v.base_ctrl_type IN (
					'Grid',
					'TreeGrid'
					)
				AND ISNULL(IsAssorted, 'N') = 'N'
			)
	ORDER BY p.horder,
		p.vorder

	SELECT TOP 1 @grd_sec = rtrim(s.section_bt_synonym)
	FROM ep_ui_section_dtl s(NOLOCK),
		ep_ui_control_dtl c(NOLOCK),
		es_comp_ctrl_type_mst_vw v(NOLOCK)
	WHERE s.customer_name = rtrim(@engg_customer_name)
		AND s.project_name = rtrim(@engg_project_name)
		AND s.process_name = rtrim(@tmp_proc)
		AND s.component_name = rtrim(@tmp_comp)
		AND s.activity_name = rtrim(@tmp_act)
		AND s.ui_name = rtrim(@tmp_ui)
		AND s.page_bt_synonym = rtrim(@grd_page)
		AND s.customer_name = c.customer_name
		AND s.project_name = c.project_name
		AND s.process_name = c.process_name
		AND s.component_name = c.component_name
		AND s.activity_name = c.activity_name
		AND s.ui_name = c.ui_name
		AND s.page_bt_synonym = c.page_bt_synonym
		AND s.section_bt_synonym = c.section_bt_synonym
		AND c.customer_name = v.customer_name
		AND c.project_name = v.project_name
		AND c.process_name = v.process_name
		AND c.component_name = v.component_name
		AND c.control_type = v.ctrl_type_name
		AND v.base_ctrl_type IN (
			'Grid',
			'TreeGrid'
			)
		AND s.section_bt_synonym NOT IN (
			'PrjHdnSection',
			'[tabcontrol]',
			'hdnrt_stsection'
			)
		AND s.section_type NOT IN (
			'Tree',
			'chart',
			'Tree Grid'
			)
		AND ISNULL(IsAssorted, 'N') = 'N'
	ORDER BY 1

	SELECT TOP 1 @grd_ctrl = rtrim(a.control_bt_synonym)
	FROM ep_ui_control_dtl a(NOLOCK),
		es_comp_ctrl_type_mst_vw b(NOLOCK)
	WHERE a.customer_name = rtrim(@engg_customer_name)
		AND a.project_name = rtrim(@engg_project_name)
		AND a.process_name = rtrim(@tmp_proc)
		AND a.component_name = rtrim(@tmp_comp)
		AND a.activity_name = rtrim(@tmp_act)
		AND a.ui_name = rtrim(@tmp_ui)
		AND a.page_bt_synonym = rtrim(@grd_page)
		AND a.section_bt_synonym = rtrim(@grd_sec)
		AND b.customer_name = a.customer_name
		AND b.project_name = a.project_name
		AND b.process_name = a.process_name
		AND b.component_name = a.component_name
		AND a.control_type = b.ctrl_type_name
		AND b.base_ctrl_type IN (
			'Grid',
			'TreeGrid'
			)
		AND ISNULL(IsAssorted, 'N') = 'N'
	ORDER BY 1

	SELECT TOP 1 @grp_name = rtrim(Group_name)
	FROM ep_ui_columngroup(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp)
		AND activity_name = rtrim(@tmp_act)
		AND ui_name = rtrim(@tmp_ui)
		AND page_bt_synonym = rtrim(@grd_page)
		AND section_bt_synonym = rtrim(@grd_sec)
		AND grid_control_bt_synonym = RTRIM(@grd_ctrl)
	ORDER BY 1

	SELECT @seqno = MAX(sequenceno)
	FROM ep_ui_column_group_mapping(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp)
		AND activity_name = rtrim(@tmp_act)
		AND ui_name = rtrim(@tmp_ui)
		AND page_bt_synonym = rtrim(@grd_page)
		AND section_bt_synonym = rtrim(@grd_sec)
		AND grid_control_bt_synonym = RTRIM(@grd_ctrl)
		AND group_name = RTRIM(@grp_name)

	SELECT @sequence = count(DISTINCT column_bt_synonym)
	FROM ep_ui_grid_dtl grd(NOLOCK)
	WHERE grd.customer_name = rtrim(@engg_customer_name)
		AND grd.project_name = rtrim(@engg_project_name)
		AND grd.process_name = rtrim(@tmp_proc)
		AND grd.component_name = rtrim(@tmp_comp)
		AND grd.activity_name = rtrim(@tmp_act)
		AND grd.ui_name = rtrim(@tmp_ui)
		AND grd.page_bt_synonym = rtrim(@grd_page)
		AND grd.section_bt_synonym = rtrim(@grd_sec)
		AND grd.control_bt_synonym = RTRIM(@grd_ctrl)
		AND isnull(grd.visible, 'No') = 'YES'
		AND grd.column_bt_synonym NOT IN (
			SELECT DISTINCT column_bt_synonym
			FROM ep_ui_column_group_mapping(NOLOCK)
			WHERE customer_name = rtrim(@engg_customer_name)
				AND project_name = rtrim(@engg_project_name)
				AND process_name = rtrim(@tmp_proc)
				AND component_name = rtrim(@tmp_comp)
				AND activity_name = rtrim(@tmp_act)
				AND ui_name = rtrim(@tmp_ui)
				AND page_bt_synonym = rtrim(@grd_page)
				AND section_bt_synonym = rtrim(@grd_sec)
				AND grid_control_bt_synonym = RTRIM(@grd_ctrl)
			)

	SELECT DISTINCT colgrp.column_bt_synonym 'engg_col_or_group',
		mapped_entity 'engg_mapped_entity',
		1 'engg_ui_map',
		SequenceNo 'engg_map_seq',
		--Code Added for TECH-73052 starrts
		mst.bt_synonym_caption 'engg_col_caption'  
	FROM ep_ui_column_group_mapping colgrp(NOLOCK)
		join ep_component_glossary_mst	mst(nolock)
		on  colgrp.customer_name = mst.customer_name
		and	colgrp.project_name = mst.project_name
		and	colgrp.process_name = mst.process_name
		and	colgrp.component_name = mst.component_name
		and colgrp.column_bt_synonym = mst.bt_synonym_name
		--Code Added for TECH-73052 ends
	WHERE colgrp.customer_name = rtrim(@engg_customer_name)
		AND colgrp.project_name = rtrim(@engg_project_name)
		AND colgrp.process_name = rtrim(@tmp_proc)
		AND colgrp.component_name = rtrim(@tmp_comp)
		AND colgrp.activity_name = rtrim(@tmp_act)
		AND colgrp.ui_name = rtrim(@tmp_ui)
		AND colgrp.page_bt_synonym = rtrim(@grd_page)
		AND colgrp.section_bt_synonym = rtrim(@grd_sec)
		AND colgrp.grid_control_bt_synonym = RTRIM(@grd_ctrl)
		AND colgrp.group_name = RTRIM(@grp_name)
	
	UNION
	
	SELECT DISTINCT column_bt_synonym 'engg_col_or_group',
		'Column' 'engg_mapped_entity',
		0 'engg_ui_map',
		isnull(@seqno, 0) + ROW_NUMBER() OVER (
			ORDER BY Column_bt_synonym
			) 'engg_map_seq',
		--Code Added for TECH-73052 starts
		bt_synonym_caption   'engg_col_caption' 
	FROM ep_ui_grid_dtl grd(NOLOCK) join
		ep_component_glossary_mst	mst(nolock)
		on grd.customer_name = mst.customer_name
		and	grd.project_name = mst.project_name
		and	grd.process_name = mst.process_name
		and	grd.component_name = mst.component_name
		and grd.column_bt_synonym = mst.bt_synonym_name
		--Code Added for TECH-73052 ends
	WHERE grd.customer_name = rtrim(@engg_customer_name)
		AND grd.project_name = rtrim(@engg_project_name)
		AND grd.process_name = rtrim(@tmp_proc)
		AND grd.component_name = rtrim(@tmp_comp)
		AND grd.activity_name = rtrim(@tmp_act)
		AND grd.ui_name = rtrim(@tmp_ui)
		AND grd.page_bt_synonym = rtrim(@grd_page)
		AND grd.section_bt_synonym = rtrim(@grd_sec)
		AND grd.control_bt_synonym = RTRIM(@grd_ctrl)
		AND isnull(grd.visible, 'No') = 'YES'
		AND grd.column_bt_synonym NOT IN (
			SELECT DISTINCT column_bt_synonym
			FROM ep_ui_column_group_mapping(NOLOCK)
			WHERE customer_name = rtrim(@engg_customer_name)
				AND project_name = rtrim(@engg_project_name)
				AND process_name = rtrim(@tmp_proc)
				AND component_name = rtrim(@tmp_comp)
				AND activity_name = rtrim(@tmp_act)
				AND ui_name = rtrim(@tmp_ui)
				AND page_bt_synonym = rtrim(@grd_page)
				AND section_bt_synonym = rtrim(@grd_sec)
				AND grid_control_bt_synonym = RTRIM(@grd_ctrl)
			)
	
	UNION
	
	SELECT DISTINCT Group_name 'engg_col_or_group',
		'Group' 'engg_mapped_entity',
		0 'engg_ui_map',
		isnull(@seqno, 0) + isnull(@sequence, 0) + ROW_NUMBER() OVER (
			ORDER BY group_name
			) 'engg_map_seq',
		Group_caption 'engg_col_caption' --Code Added for TECH-73052
	FROM ep_ui_columngroup(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp)
		AND activity_name = rtrim(@tmp_act)
		AND ui_name = rtrim(@tmp_ui)
		AND page_bt_synonym = rtrim(@grd_page)
		AND section_bt_synonym = rtrim(@grd_sec)
		AND grid_control_bt_synonym = RTRIM(@grd_ctrl)
		AND group_name <> RTRIM(@grp_name)
		AND group_name <> 'GridControl'
		AND group_name NOT IN (
			SELECT DISTINCT column_bt_synonym
			FROM ep_ui_column_group_mapping(NOLOCK)
			WHERE customer_name = rtrim(@engg_customer_name)
				AND project_name = rtrim(@engg_project_name)
				AND process_name = rtrim(@tmp_proc)
				AND component_name = rtrim(@tmp_comp)
				AND activity_name = rtrim(@tmp_act)
				AND ui_name = rtrim(@tmp_ui)
				AND page_bt_synonym = rtrim(@grd_page)
				AND section_bt_synonym = rtrim(@grd_sec)
				AND grid_control_bt_synonym = RTRIM(@grd_ctrl)
			)
		AND group_name NOT IN (
			SELECT DISTINCT Group_name
			FROM ep_ui_column_group_mapping(NOLOCK)
			WHERE customer_name = rtrim(@engg_customer_name)
				AND project_name = rtrim(@engg_project_name)
				AND process_name = rtrim(@tmp_proc)
				AND component_name = rtrim(@tmp_comp)
				AND activity_name = rtrim(@tmp_act)
				AND ui_name = rtrim(@tmp_ui)
				AND page_bt_synonym = rtrim(@grd_page)
				AND section_bt_synonym = rtrim(@grd_sec)
				AND grid_control_bt_synonym = RTRIM(@grd_ctrl)
				AND column_bt_synonym = RTRIM(@grp_name)
			)
	ORDER BY 3 DESC,
		4,
		2,
		1


	/* 
	--OutputList
		Select
		null 'engg_col_or_group', 
		null 'engg_mapped_entity', 
		null 'engg_ui_map', 
		null 'engg_map_seq', 
	*/
	SET NOCOUNT OFF
END

GO
IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'EP_Layout_Sp_SavGrdGrpML_O' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON  EP_Layout_Sp_SavGrdGrpML_O TO PUBLIC
END
GO
