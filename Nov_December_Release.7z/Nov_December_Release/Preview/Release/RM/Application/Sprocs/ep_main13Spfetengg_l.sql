IF EXISTS(SELECT 'X' From SYSOBJECTS WHERE NAME ='ep_main13Spfetengg_l' AND TYPE='P')
   BEGIN
        DROP PROC ep_main13Spfetengg_l
   END
GO 
/********************************************************************************************/
/*      V E R S I O N      :  PNR2.0_25308													*/  
/*      Released By        :  Development Team												*/  
/*      Release Comments   :  Phase 4 Release												*/  
/********************************************************************************************/  
/* Procedure    : ep_main13Spfetengg_l														*/  
/* Description  :																			*/  
/********************************************************************************************/  
/* Project      :																			*/  
/* ECR          :																			*/  
/* Version      :																			*/  
/********************************************************************************************/  
/* Referenced   :																			*/  
/* Tables       :																			*/  
/********************************************************************************************/  
/* Development history																		*/  
/********************************************************************************************/  
/* Author       : A Yuvaraj																	*/  
/* Date         : 22/Mar/2005																*/  
/********************************************************************************************/  
/* Modification history																		*/  
/********************************************************************************************/  
/* modified by   : Feroz																	*/  
/* date     : 25-nov-2008																	*/  
/* BugId    : PNR2.0_1790																	*/  
/********************************************************************************************/  
/* modified by  : Sangeetha G																*/  
/* date         : 11-Feb-2009                                                               */  
/* Bug Id       : PNR2.0_20849																*/  
/* Bug Desc     : To include NoofLinesPerRow,RowHeight,Vscrollbar_Req,language				*/ 
/*					settings property														*/  
/********************************************************************************************/  
/* modified by  : Sangeetha G																*/  
/* date         : 15-Apr-2009                                                               */  
/* Bug Id       : PNR2.0_21576																*/  
/* Modification : To include the gridlite property for grid type controls					*/  
/********************************************************************************************/  
/* modified by  : Feroz																		*/  
/* date         : 04-Aug-2009																*/  
/* Bug Id   : PNR2.0_2179																	*/  
/* Description  : Phase 3 Features - ListEdit, AttachDocument, Image & DateHighlight		*/  
/********************************************************************************************/  
/* modified by  : Feroz																		*/  
/* date         : 19-Jan-2010																*/  
/* Bug Id   : PNR2.0_25308																	*/  
/* Description  : Phase 4 Features															*/  
/********************************************************************************************/  
/* modified by  : Jeya Latha K																*/  
/* date         : 23-Jul-2010																*/  
/* Bug Id  : PNR2.0_27796																	*/  
/* Description : Attach document for htm environment										*/  
/********************************************************************************************/  
/* Modified By      : Chanheetha N A														*/  
/* Date         : 15-Sep-2010																*/  
/* BugID       : PNR2.0_28319																*/  
/* Description  : image upload for htm environment											*/  
/********************************************************************************************/  
/* modified by   : Sangeetha G																*/  
/* date			 : 11-Apr-2011																*/  
/* BugId		 : PNR2.0_30869																*/  
/* modified for		 : Feature Release  - timezone											*/  
/********************************************************************************************/  
/* modified by   : Jeya Latha K																*/  
/* date			 : 27-Jun-2011																*/  
/* BugId		 : PNR2.0_32053																*/  
/********************************************************************************************/ 
/* modified by   : Balaji D																	*/  
/* date			 : 01-Aug-2011																*/  
/* BugId		 : PNR2.0_32770																*/  
/* modified for	 : Provision to Specify Visible Length for Displayonly						*/ 
/*				   Control																	*/ 
/********************************************************************************************/ 
/* modified by  :	Muthupandi S															*/
/* date         :	22-September-2011														*/
/* Bug ID		:	PNR2.0_33487															*/
/* Description	:	To add the property "Edit Combo Required" for the controltype combo		*/
/********************************************************************************************/
/* modified by   : Balaji D																	*/  
/* date			 : 01-Aug-2011																*/  
/* BugId		 : PNR2.0_36309																*/  
/* modified for	 : Label Link features														*/ 
/********************************************************************************************/ 
/* Modified by  : Veena U																	*/
/* Date         : 25-Feb-2015																*/
/* Call ID		: PLF2.0_11499																*/
/********************************************************************************************/ 
/* modified by			Date				Defect ID										*/
/* Veena U				08-Jun-2016			PLF2.0_18487									*/
/********************************************************************************************/
/* modified by                    Date                       Defect ID						*/
/* Veena U                        22-Jun-2016                PLF2.0_19034-�					*/
/********************************************************************************************/
/* Modified by : Jeya Latha K/Ganesh Prabhu S	for callid TECH-7349						*/
/* Modified on : 14-03-2017				 													*/
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and			*/
/*					New Feature Organization chart       									*/
/********************************************************************************************/
/* Modified by : Ganesh Prabhu S/Ranjitha R      for callid  TECH-10118						*/
/* Modified on : 30-May-2017                                                                */
/* Description : Platform Feature Release                                                   */
/********************************************************************************************/
/* Modified by  : Jeya Latha K		Date: 16-Aug-2017  Defect ID	:TECH-12776				*/  
/********************************************************************************************/
/* Modified by  : JeyaLatha K/Ranjitha R	Date: 31-Jan-2018  Defect ID : TECH-18349		*/  
/********************************************************************************************/
/* Modified by  : Ranjitha R	Date: 28-Feb-2018  Defect ID : TECH-19347					*/  
/********************************************************************************************/
/*Modified by  : Ranjitha R						 Date: 29-Mar-2018	Defect ID : TECH-20326	*/  
/*Modified by  : Jeya Latha K					 Date: 11-Oct-2018  Defect ID: TECH-27036   */
/* Modified by : Jeya Latha K/Venkatesan K       Date: 17-Jun-2019  Defect ID : TECH-34971  */
/* Modified by : Jeya Latha K					 Date: 28-Jun-2019	Defect ID: TECH-35368   */
/* Modified by : Jeya Latha K                    Date: 30-Aug-2019  Defect ID: TECH-37471	*/
/* Modified by  : Hareesh K						 Date: 07-Nov-2019  Defect ID: TECH-39785	*/
/********************************************************************************************/
/* Modified by : Jeya Latha K                    Date: 04-Dec-2019  Defect ID : TECH-40809  */
/* Modified by : Jeya Latha K				     Date: 14-Jan-2020	Defect ID : TECH-41979  */
/* Modified by : Priyadharshini U/Rajeswari M	 Date: 29-Jan-2020  Defect ID : TECH-42483	*/
/* Modified by : Priyadharshini U/Rajeswari M	 Date: 26-May-2020  Defect ID : TECH-46646	*/
/* Modified by : Priyadharshini U/Rajeswari M	 Date: 26-NOV-2020  Defect ID : TECH-52688	*/
/* Modified by : Priyadharshini U/Jeya Latha K	 Date: 31-Mar-2022	Defect ID : TECH-66989	*/
/* Modified by : Priyadharshini U/Jeya Latha K	 Date: 13-Apr-2022 Defect ID : TECH-68066	*/
/* Modified by : Venkatesan K					 Date: 13-Apr-2022  Defect ID : TECH-68067  */
/********************************************************************************************/
/* Modified by	:	Priyadharshini U 														*/
/* Modified on	:	08/06/22				 												*/
/* Defect ID	:	TECH-69624																*/
/* Description	:	Custom border, Custom actions and Responsive layout						*/
/********************************************************************************************/
/* Modified by : Vimal Kumar R	 															*/
/* Modified on : 27-July-2022																*/
/* Defect ID   : TECH-71262																	*/
/* Description : Platform Features for the Month of July'22									*/
/********************************************************************************************/
/* Modified by : Priyadharshini U / Athul M													*/
/* Modified on : 23-Aug-2022																*/
/* Defect ID   : Tech-72114																	*/
/* Description : BadgeText Property for DataHyperLink Controls/Columns						*/
/********************************************************************************************/
/* Modified by : Athul M / Vimal Kumar R															*/
/* Modified on : 27-Oct-2022																		*/
/* Defect ID   : TECH-73996																			*/
/* Description : Addition of attributes for control types in setup ui preferences screen			*/
/****************************************************************************************************/
CREATE PROCEDURE ep_main13Spfetengg_l  
@ctxt_ouinstance                        engg_ctxt_OUInstance,  --Input  
@ctxt_user                              engg_ctxt_User,  --Input  
@ctxt_language                          engg_ctxt_Language,  --Input  
@ctxt_service                           engg_ctxt_Service,  --Input  
@engg_basecmb_type                      engg_name,  --Input  
@engg_cap_align                         engg_description,  --Input  
@engg_cmbtaskt_met                      engg_name,  --Input  
@engg_cmbtask_patt                      engg_name,  --Input 
@engg_component                         engg_description,  --Input  
@engg_config_phy_dir                    engg_description,  --Input  
@engg_config_uiformat                   engg_description,  --Input  
@engg_config_vir_dir                    engg_description,  --Input  
@engg_controlcmb_type                   engg_name,  --Input  
@engg_ctrlcmb_type                      engg_name,  --Input  
@engg_customer_name                     engg_name,  --Input  
@engg_modctr_desc                       engg_description,  --Input  
@engg_modctr_docu						engg_description,  --Input  
@engg_process_descr                     engg_description,  --Input  
@engg_project_name                      engg_name,  --Input  
@engg_req_no                            engg_name,  --Input  
@engg_smartspan                         engg_flag,  --Input  
@engg_tab_height                        engg_length,  --Input  
@engg_taskcmb_type                      engg_name,  --Input  
@engg_tasktxt_desc                      engg_description,  --Input  
@engg_tasttxt_docu                      engg_description,  --Input  
@engg_trail_bar                         engg_description,  --Input  
@guid									engg_guid,  
@hidden_control1						engg_description,  
@m_errorid								int output --To Return Execution Status  
  
as  
Begin  
-- nocount should be switched on to prevent phantom rows  
Set nocount on  
  
-- @m_errorid should be 0 to Indicate Success  
Set @m_errorid = 0  
  
--declaration of temporary variables  
  
--temporary and formal parameters mapping  
SET @ctxt_user                               = ltrim(rtrim(@ctxt_user))  
SET @ctxt_service                            = ltrim(rtrim(@ctxt_service))  
  
--null checking  
	IF @ctxt_ouinstance = - 915
		SET @ctxt_ouinstance = NULL

	IF @ctxt_user = '~#~'
		SET @ctxt_user = NULL

	IF @ctxt_language = - 915
		SET @ctxt_language = NULL

	IF @ctxt_service = '~#~'
		SET @ctxt_service = NULL

	IF @engg_basecmb_type = '~#~'
		SET @engg_basecmb_type = NULL

	IF @engg_cap_align = '~#~'
		SET @engg_cap_align = NULL

	IF @engg_cmbtaskt_met = '~#~'
		SET @engg_cmbtaskt_met = NULL

	IF @engg_cmbtask_patt = '~#~'
		SET @engg_cmbtask_patt = NULL

	IF @engg_component = '~#~'
		SET @engg_component = NULL

	IF @engg_config_phy_dir = '~#~'
		SET @engg_config_phy_dir = NULL

	IF @engg_config_uiformat = '~#~'
		SET @engg_config_uiformat = NULL

	IF @engg_config_vir_dir = '~#~'
		SET @engg_config_vir_dir = NULL

	IF @engg_controlcmb_type = '~#~'
		SET @engg_controlcmb_type = NULL

	IF @engg_ctrlcmb_type = '~#~'
		SET @engg_ctrlcmb_type = NULL

	IF @engg_customer_name = '~#~'
		SET @engg_customer_name = NULL

	IF @engg_modctr_desc = '~#~'
		SET @engg_modctr_desc = NULL

	IF @engg_modctr_docu = '~#~'
		SET @engg_modctr_docu = NULL

	IF @engg_process_descr = '~#~'
		SET @engg_process_descr = NULL

	IF @engg_project_name = '~#~'
		SET @engg_project_name = NULL

	IF @engg_req_no = '~#~'
		SET @engg_req_no = NULL

	IF @engg_smartspan = '~#~'
		SET @engg_smartspan = NULL

	IF @engg_tab_height = - 915
		SET @engg_tab_height = NULL

	IF @engg_taskcmb_type = '~#~'
		SET @engg_taskcmb_type = NULL

	IF @engg_tasktxt_desc = '~#~'
		SET @engg_tasktxt_desc = NULL

	IF @engg_tasttxt_docu = '~#~'
		SET @engg_tasttxt_docu = NULL

	IF @engg_trail_bar = '~#~'
		SET @engg_trail_bar = NULL
  
/*  
--OuputList  
Select null 'engg_prop_desc',  
null 'engg_prop_req' from ***  
*/  
  
declare @engg_process_name  engg_name,  
		@engg_comp_name		engg_name  
  
Select	top 1 @engg_process_name = process_name,  
		@engg_comp_name			 = component_name  
from	ep_ui_req_dtl (nolock)  
where	customer_name	= @engg_customer_name  
and		project_name	= @engg_project_name  
and		process_descr	= @engg_process_descr  
and		component_descr = @engg_component  
order by 1, 2  
  
if not exists  ( Select 'x'  
from	es_ctrl_dtl_tmp (nolock)  
where	customer_name	= @engg_customer_name  
and		project_name	= @engg_project_name  
and		process_name	= @engg_process_name  
and		component_name	= @engg_comp_name  
and		base_ctrl_type	= @engg_basecmb_type  
and		control_type	= @engg_ctrlcmb_type  
and		user_id			= @ctxt_user  
and		guid			= @guid  )  
begin  
	insert into es_ctrl_dtl_tmp (  
		customer_name,			project_name,		process_name,		component_name,			control_type,			base_ctrl_type, 
		user_id,				guid,				ctrl_req,			property,				
		enumerated_values,		
		ctrl_enum_value  )  
	Select  distinct 
		@engg_customer_name,	@engg_project_name, @engg_process_name, @engg_comp_name,		@engg_ctrlcmb_type,		@engg_basecmb_type, 
		@ctxt_user,				@guid,				0,					quick_code_value,  
		case	when quick_code_value in ( 'Caption Alignment' ) then 'Right, Left, Center, bottom, top'  
				when quick_code_value in ( 'Caption Position', 'Control Position' ) then 'Right, Left, Center'
				 
				--Code Added for TECH-73996 starts
				when quick_code_value in ('Step Value')		then '0'
				--Code Added for TECH-73996 ends
				when quick_code_value in (/*'Control Class',*/ 'Help Image Class', 'Label Class', 'Task Image Class' ) then ''  
				when quick_code_value in ('Control Style') then  'Image,Default'
				when quick_code_value in ('Visible Rows' ) then '0'
				when quick_code_value in ('Previous Count' ) then '0'--Code Added for TECH-73996
				when quick_code_value in ('ListItem Type' ) then 'SingleCheck, MultiCheck' --13852 added on 14may2020
		--- 11537 start--
				when quick_code_value in ('Zoom Maximum' ) then '0'
				when quick_code_value in ('Zoom Step' ) then '0'
				when quick_code_value in ('Zoom Minimum' ) then '0'
				when quick_code_value in ('Default Zoom' ) then '0'
				when quick_code_value in ('Default File' ) then ''
				when quick_code_value in ('Spark Chart Type')	then 'Line, Bar, Discrete, Bullet, Pie, Box, Tri-state'
				when quick_code_value in ('Node Height' ) then '0'
				when quick_code_value in ('Node Width' ) then '0'
		--- 11537 Ends--
--Code modification for PNR2.0_20849 starts  
				when quick_code_value in ('Spin-Up Image','Spin-Down Image',--'Edit Mask', -- Commented for the Defect Id: TECH-20326 
										   'No of Lines Per Row','Row Height') then ''   --added by Ramanujam on 01-mar-2006  
--Code modification for PNR2.0_20849 ends  
				when quick_code_value in ('Rich Control Type') then 'TextType Writer, Marquee Ticker, Email, Bar Code, Attach Document'  --added by Feroz for Extnjs Features  -- PNR2.0_1790  
-- Added By Feroz  
--code added for the caseid : PNR2.0_28319 starts  
				when quick_code_value in ('Image Accept Type')  then '*.gif,*.png,*.jpeg,*.jpg'  
				when quick_code_value in ('No of Columns') then ''  
				when quick_code_value in ('Image Height') then ''  
				when quick_code_value in ('Relative URL Path') then ''  
				when quick_code_value in ('Relative Document Path') then ''  
				when quick_code_value in ('Relative Image Path') then ''
				when quick_code_value in ('Accept Type')  then '' 
				when quick_code_value in ('File Size')  then ''  
				when quick_code_value in ('Wrap Count')  then 'No.of Rows \ No.Of Columns'
				when quick_code_value in ('Box Type')  then '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,14,15,16,17,18,19,20,21'
				when quick_code_value in ('Orientation')  then 'Horizontal,Vertical'
				when quick_code_value in ('Set Focus Event Occurence')  then 'First time, Every time'
				when quick_code_value in ('Leave Focus Event Occurence')  then 'First time, Every time'
				when quick_code_value in ('Column Caption Alignment')  then 'Right, Left, Center'
				when quick_code_value in ('Spark Chart Type' )	then 'Line, Bar, Discrete, Bullet, Pie, Box, Tri-state'
				when quick_code_value in ('Grid Header Style')  then 'style1'
				when quick_code_value in ('Grid Toolbar Style')  then 'style1'
				when quick_code_value in ('Column Data Alignment')  then 'Right, Left, Center'
				when quick_code_value in ('Range Minimum')  then ''
				when quick_code_value in ('Range Maximum')  then ''
				when quick_code_value in ('Range Start Value')  then ''
				when quick_code_value in ('Range End Value')  then ''
				when quick_code_value in ('Range Step')  then ''
--when quick_code_value in ('Alignment')  then 'Horizontal,Vertical'
				when quick_code_value in ('Range Label')  then 'True,False'
				when quick_code_value in ('Range Select')  then 'Last Only,First & Last'
				when quick_code_value in ('Value Shown')  then 'In Textbox, Value as Label (Above slider bar), None'
				when quick_code_value in ('Style')  then 'Line, Star Rating, Rainbow Rating, Progress Bar'--Code Added for TECH-73996
				when quick_code_value in ('Configuration')  then 'type: marquee/slide/static,	carousel: y/n,	orientation: hor/ver,	direction: left/right/up/down,		scrollamount: 10,	scrollspeed: 900,	timeout: 1000,navigator: true/false,	pauseonover: true/false'
				when quick_code_value in ('Rating Type')  then 'Star , Rainbow'
				when quick_code_value in ('Captcha Data')  then 'Alphabet , Numeric , Alphanumeric'
		-- code added for Defect Id: TECH-19347 starts
				when quick_code_value = 'No of Controls per Line'  then 'If Grid to Form Selected' 
				when quick_code_value = 'Form Width'  then 'px,% (If Grid to Form Selected)' 
				when quick_code_value = 'Control Width' then 'px,% (If Grid to Form Selected)' 
				when quick_code_value = 'Label Width' then 'px,% (If Grid to Form Selected)' 
				when quick_code_value = 'Label Alignment' then 'Left, Right ,Top (If Grid to Form Selected)'
		-- code added for Defect Id: TECH-19347 ends
		else null end,  
		 case   when quick_code_value = 'Caption Alignment' then b.caption_alignment  
				when quick_code_value = 'Caption Position'   then b.caption_position  
				when quick_code_value = 'Control Position'   then b.ctrl_position  
				when quick_code_value = 'Control Style' then b.controlstyle 
				--Code Added for TECH-73996	 starts
				when quick_code_value = 'Step Value'		then c.StepValue		
				--Code Added for TECH-73996 ends
--when quick_code_value = 'Control Class'  then b.ctrl_class  
				when quick_code_value = 'Help Image Class' then b.hlpimg_class  
				when quick_code_value = 'Label Class' then b.label_class  
				when quick_code_value = 'Task Image Class'  then b.tskimg_class  
				when quick_code_value = 'Report Required'  then b.report_req  
				when quick_code_value = 'Visible Rows'  then convert(varchar(10), b.visisble_rows)
				when quick_code_value = 'Previous Count'  then convert(varchar(10), c.PreviousCount)--Code Added for TECH-73996
			    when quick_code_value = 'ListItem Type'  then c.ListItemType --13852 added on 14may2020
				when quick_code_value = 'Spin-Up Image' then b.spin_up_image  --added by Ramanujam on 01-mar-2006  
				when quick_code_value = 'Spin-Down Image' then b.spin_down_image  --added by Ramanujam on 01-mar-2006  
--Code modification for PNR2.0_20849 starts  
				when quick_code_value = 'No of Lines Per Row'  then isnull(convert(varchar(10), b.NoofLinesPerRow),'')  
				when quick_code_value = 'Row Height'  then isnull (convert(varchar(10), b.RowHeight),'')  
--Code modification for PNR2.0_20849 ends  
				when quick_code_value = 'Inplace Calendar' then b.InPlace_Calendar  
				--when quick_code_value = 'Edit Mask' then isnull(b.Editmask,'')  -- Commented for Defect Id: TECH-20326 
				when quick_code_value = 'Rich Control Type'  then isnull(b.Extjs_Ctrl_type,'') --added by Feroz for Extnjs Features -- PNR2.0_1790  
-- Code modification for PNR2.0_21576 starts  
				when quick_code_value = 'GridLite Required'  then b.gridlite_req  
-- Code modification for PNR2.0_21576 ends  
-- Added By Feroz  
				when quick_code_value = 'No of Columns'  then isnull(convert(varchar(10),b.listedit_noofcolumns),'')  
				when quick_code_value = 'Image Height'  then isnull(convert(varchar(10),b.image_row_height),'')  
				when quick_code_value = 'Relative URL Path'  then isnull(b.relative_url_path, '')  
				when quick_code_value = 'Relative Document Path'  then isnull(b.relative_document_path, '')  
				when quick_code_value = 'Relative Image Path'  then isnull(b.relative_image_path, '')  
-- Added By Feroz  
/*Modification made by Manikandan P K for Bug id : PNR2.0_29917 Starts*/  
				when quick_code_value = 'Image Width'  then isnull(convert(varchar(10),b.Image_Row_Width), '')  
				when quick_code_value = 'Image Preview Height'  then isnull(convert(varchar(10),b.Image_Preview_Height),'' )  
				when quick_code_value = 'Image Preview Width'  then isnull(convert(varchar(10),b.Image_Preview_Width), '')  
/*Modification made by Manikandan P K for Bug id : PNR2.0_29917 Ends*/  
--when quick_code_value = 'Image Accept Type'  then isnull(b.Image_Accept_Type, '') 
				when quick_code_value = 'Accept Type'  then isnull(b.Accpet_Type, '')  
				when quick_code_value = 'File Size'  then isnull(b.FileSize, '')  
				when quick_code_value  = 'Wrap Count'  then isnull(convert(varchar(10),b.wrapcount), '')  
				when quick_code_value = 'Box Type'  then isnull(b.Box_Type, '')
				when quick_code_value = 'Orientation'  then isnull(b.Orientation, '')
				when quick_code_value = 'Set Focus Event Occurence'  then isnull(c.SetFocusEventOccurence, '') 
				when quick_code_value = 'Leave Focus Event Occurence'  then isnull(c.LeaveFocusEventOccurence, '') 
				when quick_code_value = 'Column Caption Alignment'  then isnull(b.col_caption_align, '')
				when quick_code_value = 'Grid Header Style'  then isnull(b.Gridheaderstyle, '')
				when quick_code_value = 'Grid Toolbar Style'  then isnull(b.Gridtoolbarstyle, '')
				when quick_code_value = 'Column Data Alignment'  then isnull(b.col_data_align, '')
--code added for the caseid : PNR2.0_28319 ends  
				when quick_code_value = 'Range Minimum'   then isnull(convert(varchar(10), b.RangeMinimum), '')
				when quick_code_value = 'Range Maximum'  then isnull(convert(varchar(10), b.RangeMaximum), '')
				when quick_code_value = 'Range Start Value'  then isnull(convert(varchar(10), b.RangeStartValue), '')
				when quick_code_value = 'Range End Value'   then isnull(convert(varchar(10), b.RangeEndValue), '')
				when quick_code_value = 'Range Step'   then isnull(convert(varchar(10), b.RangeStep), '')
--when quick_code_value = 'Alignment' then isnull(b.Alignment,'')
				when quick_code_value = 'Range Label'   then isnull(b.RangeLabel,'')
				when quick_code_value = 'Range Select'   then isnull(b.RangeSelect,'')
				when quick_code_value = 'Value Shown'  then isnull(b.ValueShown,'')
				when quick_code_value = 'Style'  then isnull(b.Style,'')
				when quick_code_value = 'Configuration'  then isnull(c.Configuration, '')
				when quick_code_value = 'Rating Type'  then isnull(b.RatingType, '')
				when quick_code_value = 'Captcha Data'  then isnull(b.CaptchaData, '')
				when quick_code_value = 'Is Chips'  then isnull(b.RenderAs, '')-- Added for TECH-41979
				when quick_code_value = 'Is Tag'  then isnull(b.RenderAs, '')
				when quick_code_value = 'Is Mobile'  then isnull(b.RenderAs, '') --code added by 13639

				when quick_code_value = 'Is Scheduler'  then isnull(b.RenderAs, '') --code added by 13639

				when quick_code_value = 'Pre Task'  then isnull(b.RenderAs, '') --Code Added for the Defect Id TECH-68066
				when quick_code_value = 'Post Task'  then isnull(b.RenderAs, '') --Code Added for the Defect Id TECH-68066
				--Code Added for TECH-71262 starts
				WHEN quick_code_value = 'Browse Pre Task'   THEN isnull(b.RenderAs, '')
				WHEN quick_code_value = 'Browse Post Task'  THEN isnull(b.RenderAs, '')
				WHEN quick_code_value = 'Delete Pre Task'   THEN isnull(b.RenderAs, '')
				WHEN quick_code_value = 'Delete Post Task'  THEN isnull(b.RenderAs, '')
				WHEN quick_code_value = 'ButtonStyle'		THEN isnull(b.RenderAs, '')
				--Code Added for TECH-71262 ends
				--when quick_code_value = 'Selection Required for List'  then isnull(b.RenderAs, '')--code added by 13639
				--when quick_code_value = 'Row Always Expanded'  then isnull(b.RenderAs, '') --code added by 13639
				--when quick_code_value = 'Pagination Required'  then isnull(b.RenderAs, '') --code added by 13639
				--when quick_code_value = 'Update Task Required'  then isnull(b.RenderAs, '') --code added by 13639
				--when quick_code_value = 'Delete Task Required'  then isnull(b.RenderAs, '') --code added by 13639

				--Code added for TECH-69624 starts
				when quick_code_value = 'Hide Rule Header'		then isnull(b.RenderAs, '')
				when quick_code_value = 'Hide AND Operator'		then isnull(b.RenderAs, '')
				when quick_code_value = 'Hide OR Operator'		then isnull(b.RenderAs, '')
				when quick_code_value = 'Hide NOT Operator'		then isnull(b.RenderAs, '')
				when quick_code_value = 'Hide Group Operator'	then isnull(b.RenderAs, '')
				when quick_code_value = 'Hide Rule Operator'	then isnull(b.RenderAs, '')
				when quick_code_value = 'Is Toggle'				then isnull(b.RenderAs, '')
				--Code added for TECH-69624 Ends

				when quick_code_value = 'Multi-Selector Grid'  then isnull(b.RenderAs, '')
				when quick_code_value = 'Row Expander'  then isnull(b.RenderAs, '')
				when quick_code_value = 'Grid to Form'  then isnull(b.RenderAs, '')
				when quick_code_value = 'Rule Builder'  then isnull(b.RenderAs, '')			--Added for TECH-35368
				when quick_code_value = 'Calander Control'  then isnull(b.RenderAs, '')		--Added for TECH-35368
				when quick_code_value = 'Gantt Control'  then isnull(b.RenderAs, '')	-- Added for TECH-37471	
				when quick_code_value = 'Is Mobile'		 then isnull(b.RenderAs, '')  -- Added for TECH-37471
				when quick_code_value = 'Is TreeGrid'  then isnull(b.RenderAs, '')
				when quick_code_value = 'Expand Event'  then isnull(c.ExpandEvent,'')     
				when quick_code_value = 'Expand All Event'  then isnull(c.ExpandAllEvent,'')     
				when quick_code_value = 'Collapse Event'  then isnull(c.CollapseEvent,'')     
				when quick_code_value = 'Collapse All Event'  then isnull(c.CollapseAllEvent,'')     
				when quick_code_value = 'Click Event'  then isnull(c.ClickEvent,'')     
				when quick_code_value = 'Drag Drop ToolTip'  then isnull(c.DDToolTip,'')
				when quick_code_value = 'Node Icon Required'  then isnull(c.NodeIconReqd,'')   
				when quick_code_value = 'Node Custom Class'  then isnull(c.NodeCustomClass,'')      
				when quick_code_value = 'Is Organization Chart'  then isnull(c.IsOrgChart,'') 
				when quick_code_value in ('Zoom Maximum' )		then convert(varchar(10), c.zoommax) 
				when quick_code_value in ('Zoom Step' )			then convert(varchar(10), c.ZoomStep)
				when quick_code_value in ('Zoom Minimum' )		then convert(varchar(10), c.ZoomMin) 
				when quick_code_value in ('Default Zoom' )		then convert(varchar(10), c.DefaultZoom) 
				when quick_code_value in ('Node Height' )		then convert(varchar(10), c.NodeHeight) 
				when quick_code_value in ('Node Width' )		then convert(varchar(10), c.NodeWidth) 
				when quick_code_value in ('Default File' )		then isnull(c.DefaultFile,'') 
				when quick_code_value in ('Spark Chart Type' )	then c.SparkChartType
			-- code added for Defect Id: TECH-19347 starts
				when quick_code_value = ('No of Controls Per Line' ) then convert(varchar(10),c.NoofCtrlPerLine)
				when quick_code_value = ('Form Width' ) then  convert(varchar(10),c.FormWidth)
				when quick_code_value = ('Control Width') then convert(varchar(10),c.ControlWidth)
				when quick_code_value = ('Label Width' ) then convert(varchar(10),c.LabelWidth)
				when quick_code_value = ('Label Alignment' ) then convert(varchar(10),c.LabelAlignment)
			-- Added for Rule Builder Starts Defect ID: TECH-35368
				when quick_code_value = ('Rule Builder' ) then convert(varchar(10),c.RuleBuilder) 
				when quick_code_value = ('MultiSelect Combo for Rule Builder' ) then convert(varchar(10),c.MultiSelectComboforRB) 
				when quick_code_value = ('Calendar Control' ) then convert(varchar(10),c.CalendarControl) 
			-- Added for Rule Builder Ends Defect ID: TECH-35368
			-- Added for the Defect ID: TECH-37471 Starts for Set & LEave Focus Events
				when quick_code_value = ('Set Focus Event')   then convert(varchar(10),c.SetFocusEvent) 
				when quick_code_value = ('Leave Focus Event') then convert(varchar(10),c.LeaveFocusEvent) 
				when quick_code_value = ('Set Focus Event Occurence')   then convert(varchar(50),c.SetFocusEventOccurence) 
				when quick_code_value = ('Leave Focus Event Occurence') then convert(varchar(50),c.LeaveFocusEventOccurence) 
				when quick_code_value = ('Gantt Control')     then convert(varchar(10),c.GanttControl) 
			-- code added for Defect Id: TECH-19347 ends
				when quick_code_value = ('Auto Sync')		  then convert(varchar(10),c.AutoSync) -- Added for TECH-37471
				-- Added for TECH-41979 Starts
			   when quick_code_value = ('Is List')					       then convert(varchar(10),c.IsList)	-->added by 13639 
			   when quick_code_value = ('Auto Scan')					       then convert(varchar(10),c.AutoScan)	-->added by 13639 
			   when quick_code_value = ('ListItem Expander')               then convert(varchar(10),c.ListItemExpander)
	         ---code added by 13852 on 20jan2020	

			   when quick_code_value = ('Read Only')		               then convert(varchar(10),c.ReadOnly)
			   when quick_code_value = ('Show Today Line')		           then convert(varchar(10),c.ShowTodayLine)
			   when quick_code_value = ('Show Rollup Tasks')		       then convert(varchar(10),c.ShowRollupTasks)
			   when quick_code_value = ('Show Project Lines')		       then convert(varchar(10),c.ShowProjectLines)
			   when quick_code_value = ('Skip Weekends During DragDrop')   then convert(varchar(10),c.SkipWeekendsDuringDragDrop)
			   when quick_code_value = ('Locked Grid Width')		       then convert(varchar(10),c.LockedGridWidth)
			   when quick_code_value = ('Row Height')		               then convert(varchar(10),c.RowHeight)
			   when quick_code_value = ('Bottom LabelField')		       then convert(varchar(10),c.BottomLabelField)
			   when quick_code_value = ('Top LabelField')		           then convert(varchar(10),c.TopLabelField)
			   when quick_code_value = ('Left LabelField')		           then convert(varchar(10),c.LeftLabelField)
			   when quick_code_value = ('Right LabelField')		           then convert(varchar(10),c.RightLabelField)
			   when quick_code_value = ('Rollup LabelField')		       then convert(varchar(10),c.RollupLabelField)
			   when quick_code_value = ('Scroll To DateCentered')		   then convert(varchar(10),c.ScrollToDateCentered)
			   when quick_code_value = ('Zoom')		                       then convert(varchar(10),c.Zoom)
			   when quick_code_value = ('Fit')		                       then convert(varchar(10),c.Fit)
			   when quick_code_value = ('Export')		                   then convert(varchar(10),c.Export)
			   when quick_code_value = ('Shift')		                   then convert(varchar(10),c.GanttShift)
			   when quick_code_value = ('Expand')		                   then convert(varchar(10),c.GanttExpand)
			   when quick_code_value = ('Insert')		                   then convert(varchar(10),c.GanttInsert)
			   when quick_code_value = ('Delete')		                   then convert(varchar(10),c.GanttDelete)
			   when quick_code_value = ('Indent')		                   then convert(varchar(10),c.Indent)
			   when quick_code_value = ('Calendar')		                   then convert(varchar(10),c.Calendar)
			   when quick_code_value = ('Context Menu')		               then convert(varchar(10),c.ContextMenu)
			   when quick_code_value = ('Popup Task Editor')		       then convert(varchar(10),c.PopupTaskEditor)
			   when quick_code_value = ('Baseline')		                   then convert(varchar(10),c.Baseline)
			   when quick_code_value = ('Highlight')                       then convert(varchar(10),c.Highlight)
			   when quick_code_value = ('Is Chips')                        then convert(varchar(10),c.IsChips)	
			   when quick_code_value = ('Multi Select for List')           then convert(varchar(10),c.MultiSelect)--code added by 13852 on 24nov2020	
			   when quick_code_value = ('Selection Required for List')     then convert(varchar(10),c.IsSelectionReqdList)	--code added by 13639
			   when quick_code_value = ('Row Always Expanded')             then convert(varchar(10),c.RowAlwaysExpanded)	--code added by 13639

			   when quick_code_value = ('Is Scheduler')					   then convert(varchar(10),c.IsScheduler)	--code added by 13639
			   when quick_code_value = ('Is Mobile')					 then convert(varchar(10),c.IsMobile)	--code added by 13639
			   when quick_code_value = ('Pagination Required')               then convert(varchar(10),c.PaginationReqd)	--code added by 13639
			   when quick_code_value = ('Update Task Required')               then convert(varchar(10),c.UpdateTaskReqd)	--code added by 13639
			   when quick_code_value = ('Delete Task Required')               then convert(varchar(10),c.DeleteTaskReqd)	--code added by 13639

			   when quick_code_value = ('Pre Task')               then convert(varchar(10),c.PreTask)	--Code Added for the Defect Id TECH-68066
			   when quick_code_value = ('Post Task')               then convert(varchar(10),c.PostTask)	--Code Added for the Defect Id TECH-68066
			   --Code Added for the Defect Id TECH-71262 starts
			   when quick_code_value = ('Browse Pre Task')         then convert(varchar(10),c.BrowsePreTask)	
			   when quick_code_value = ('Browse Post Task')        then convert(varchar(10),c.BrowsePostTask)	
			   when quick_code_value = ('Delete Pre Task')         then convert(varchar(10),c.DeletePreTask)	
			   when quick_code_value = ('Delete Post Task')        then convert(varchar(10),c.DeletePostTask)	
			   when quick_code_value = ('Button Style')			   then convert(varchar(10),c.ButtonStyle)	
			   --Code Added for the Defect Id TECH-71262 on 14July22 ends
			   
			   when quick_code_value = ('Bulk Download')          then convert(varchar(10),c.BulkDownload)	--code added by 11536 for the defect TECH-68067

			   when quick_code_value = ('Spell Check Required')            then convert(varchar(10),c.IsSpellcheck)
			   when quick_code_value = ('Direct Print')                    then convert(varchar(10),c.DirectPrint)	
				-- Added for TECH-41979 Ends

			  when quick_code_value = ('ShowLines')                    then convert(varchar(10),c.ShowLines)	--TECH-66989

			  --Code added for TECH-69624 Starts
			  when quick_code_value = ('Hide Rule Header')        then convert(varchar(10),c.HideRuleHeader)
			  when quick_code_value = ('Hide AND Operator')       then convert(varchar(10),c.HideANDOperator)
			  when quick_code_value = ('Hide OR Operator')        then convert(varchar(10),c.HideOROperator)
			  when quick_code_value = ('Hide NOT Operator')       then convert(varchar(10),c.HideNOTOperator)
			  when quick_code_value = ('Hide Group Operator')     then convert(varchar(10),c.HideGroupOperator)
			  when quick_code_value = ('Hide Rule Operator')      then convert(varchar(10),c.HideRuleOperator)
			  when quick_code_value = ('Is Toggle')				  then convert(varchar(10),c.IsToggle)
			  when quick_code_value = ('NFC Enabled')			  then convert(varchar(10),c.NFCEnabled)
			  when quick_code_value = ('Select Only List Values') then convert(varchar(10),c.SelectOnlyListValues)
			  --Code added for TECH-69624 ends

			  when quick_code_value = ('Badge Text')			  then convert(varchar(10),c.BadgeText)	--Code Added for the DefectId Tech-72114
			  when  quick_code_value = ('Auto Height')			  then convert(varchar(10),c.AutoHeight) --Code Added for the DefectId Tech-72114
--code modified for the caseid : PNR2.0_28319 ends  
			  --Code Added for the DefectId Tech-73996 starts
			  WHEN quick_code_value = ('Eye Icon for Password')				THEN convert(varchar(10),c.EyeIconForPassword)
			  WHEN quick_code_value = ('Signature')							THEN convert(varchar(10),c.Signature)
			  WHEN quick_code_value = ('Keyup Search')						THEN convert(varchar(10),c.KeyupSearch)
			  WHEN quick_code_value = ('Stepper')							THEN convert(varchar(10),c.Stepper)
			  WHEN quick_code_value = ('Live Clock')						THEN convert(varchar(10),c.LiveClock)
			  WHEN quick_code_value = ('Clear Task')						THEN convert(varchar(10),c.ClearTask)
			  WHEN quick_code_value = ('Show Animation')					THEN convert(varchar(10),c.ShowAnimation)
			  WHEN quick_code_value = ('Prevent Multiple Row Selection')	THEN convert(varchar(10),c.PreventMultipleRowSelection)	

			  --Code Added for the DefectId Tech-73996 ends
-- Added By Feroz  
			else null end  
from	es_ctrl_task_met a (nolock),  
		es_comp_ctrl_type_mst b (nolock)  left outer join 
		es_comp_ctrl_type_mst_extn  c(nolock)
on		b.customer_name		= c.customer_name
and		b.project_name		= c.project_name
and		b.process_name		= c.process_name
and		b.component_name	= c.component_name
and		b.base_ctrl_type	= c.base_ctrl_type
and		b.ctrl_type_name	= c.ctrl_type_name

where	quick_code_type		= 'control'  
and		quick_code			= @engg_basecmb_type  
and		b.ctrl_type_name	= @engg_ctrlcmb_type  
and		b.base_ctrl_type	= @engg_basecmb_type  
and		b.customer_name		= @engg_customer_name  
and		b.project_name		= @engg_project_name  
and		b.process_name		= @engg_process_name  
and		b.component_name	= @engg_comp_name  
end  
  
-- select * from es_ctrl_dtl_tmp(nolock)  
--where component_name = 'de'  
  
  
update	a  set
		a.ctrl_req = case	when a.property = 'Caption Alignment' and b.caption_alignment in( 'right', 'left', 'Center', 'bottom', 'top' ) then 1  
							when a.property = 'Caption Position' and b.caption_position in ( 'right', 'left', 'Center' ) then 1  
							when a.property = 'Caption Required' and b.caption_req = 'y' then 1  
							when a.property = 'Caption Wrap' and b.caption_wrap = 'y' then 1  
							--Code Added for TECH-73996 
							when a.property = 'Step Value'		and c.StepValue	> 0 then 1   
							--Code Added for TECH-73996

--when a.property = 'Control Class' and b.ctrl_class in ( 'x' ) then 1  
							when a.property=  'Control Style' and b.controlstyle in('Image','Default') then 1   
							when a.property = 'Control Position' and b.ctrl_position in ( 'right', 'left', 'Center' ) then 1  
							when a.property = 'Editable' and b.editable_flag = 'y' then 1  
							when a.property = 'Ellipses Required' and b.ellipses_req = 'y' then 1  
							when a.property = 'Handle Events' and b.event_handling_req = 'y' then 1  
							when a.property = 'Help Image Class' and b.hlpimg_class in ( 'x' ) then 1  
							when a.property = 'Help Required' and b.help_req = 'y' then 1  
							when a.property = 'Label Class' and b.label_class in ( 'x' ) then 1  
							when a.property = 'Mandatory' and b.mandatory_flag = 'y' then 1  
							when a.property = 'Password Char' and b.password_char = 'y' then 1  
							when a.property = 'Task Image Class' and b.tskimg_class in ( 'x' ) then 1  
							when a.property = 'Visible' and b.visisble_flag = 'y' then 1  
							when a.property = 'Visible Rows' and b.visisble_rows > 0 then 1  
							when a.property = 'Previous Count' and c.PreviousCount > 0 then 1 --Code Added for TECH-73996
							when a.property = 'ListItem Type' and c.ListItemType in('SingleCheck','MultiCheck')then 1  --13852 aadded on 14may2020
							when a.property = 'Zoom' and b.zoom_req = 'y' then 1  
							when a.property = 'Allow Deletion' and b.delete_req = 'y' then 1  
							when a.property = 'Allow Insertion' and b.insert_req = 'y' then 1  
							when a.property = 'Display only Combo' and b.disponlycmb_req = 'y' then 1  
							when a.property = 'HTML text area' and b.html_txt_area = 'y' then 1  
							when a.property = 'Report Required' and b.report_req = 'y' then 1  
							when a.property = 'Select Flag' and b.select_flag = 'y' then 1  
							when a.property = 'Auto Tab Stop' and b.auto_tab_stop = 'y' then 1 ---added by Ramanujam on 7-dec-2005  
							when a.property = 'Spin Required' and b.spin_required = 'y' then 1 --added by Ramanujam on 01-mar-2006  
--Code modification for PNR2.0_20849 starts  
							when a.property = 'Vertical Scrollbar Required' and b.Vscrollbar_Req = 'y' then 1  
--Code modification for PNR2.0_20849 ends  
							when a.property = 'Inplace Calendar' and b.Inplace_Calendar = 'y' then 1  
							when a.property = 'Edit Mask' and b.Editmask = 'y' then 1 
							--when a.property = 'Edit Mask' and b.Editmask in ( 'x') then 1  --  Commented for Defect Id: TECH-20326 
							when a.property = 'Rich Control' and b.Is_Extjs_Control = 'y' then 1 --added by Feroz for Extnjs Features -- PNR2.0_1790  
-- Code modification for PNR2.0_21576 starts  
							when a.property = 'GridLite Required' and b.gridlite_req = 'y' then 1  
-- Code modification for PNR2.0_21576 ends  
-- Added By Feroz  
							when a.property = 'Button Combo' and b.buttoncombo_req = 'y' then 1  
							when a.property = 'Data as Caption' and b.dataascaption = 'y' then 1  
							when a.property = 'Associated List' and b.associatedlist_req = 'y' then 1  
							when a.property = 'Onfocus Task' and b.onfocustask_req = 'y' then 1  
							when a.property = 'List Refill Task' and b.listrefilltask_req = 'y' then 1  
							when a.property = 'Bullet Link' and b.bulletlink_req = 'y' then 1  
							when a.property = 'Attach Document' and b.attach_document = 'y' then 1  
							when a.property = 'Image Upload' and b.image_upload = 'y' then 1  
							when a.property = 'Inplace Image' and b.inplace_image = 'y' then 1  
							when a.property = 'Image Icon' and b.image_icon = 'y' then 1  
							when a.property = 'Save Document Content to DB' and b.save_doc_content_to_db = 'y' then 1  
							when a.property = 'Save Image Content to DB' and b.save_image_content_to_db = 'y' then 1  
							when a.property = 'Date Highlight' and b.Date_highlight = 'y' then 1  
							when a.property = 'Ezee Report' and b.ezee_report = 'y' then 1  
-- Code Added by Jeya for bug id :PNR2.0_27796 Starts  
							when a.property = 'Lite Attach Document' and b.Lite_Attach_Document = 'y' then 1  
							when a.property = 'Browse Button Enable' and b.Browse_Button_Enable = 'y' then 1  
							when a.property = 'Delete Button Enable' and b.Delete_Button_Enable = 'y' then 1  
-- Code Added by Jeya for bug id :PNR2.0_27796 End  
--code added for the caseid : PNR2.0_28319 starts  
							when a.property = 'Image Preview Required' and b.Image_Preview_Req = 'y' then 1  
							when a.property = 'Lite Attach Image' and b.Lite_Attach_Image = 'y' then 1  
--code added for the caseid : PNR2.0_28319 ends  
--Code Modification for PNR2.0_30869 starts 
							when a.property = 'TimeZone' and b.timezone = 'y' then 1  
--Code Modification for PNR2.0_30869 ends 
							when a.property = 'Auto Expand' and b.autoexpand = 'y' then 1  -- Code Added for the Bug ID PNR2.0_32053 
							when a.property = 'Attachment with Description'  and b.AttachmentWithDesc = 'y' then 1
							when a.property = 'Apply Visible Length' and b.Disp_Only_Apply_Len = 'y' then 1  -- Code Added for the Bug ID PNR2.0_32770 
							when a.property = 'Edit combo Required' and b.editcombo_req = 'Y' then 1/*Modification made by Muthupandi S for Bug id : PNR2.0_33487*/
							when a.property = 'Label Link' and b.Label_Link = 'y' then 1  -- Code Added for the Bug ID PNR2.0_36309 
							when a.property = 'IsListBox'     and b.IsListBox = 'y' then 1 --PLF2.0_03057
							when a.property = 'Combo Link'     and b.combo_link = 'y' then 1 
							when a.property = 'QR Image'     and b.qr_image= 'y' then 1 --shakthi
--code added for bugid: PLF2.0_07676 starts
							when a.property = 'Toolbar Not Required'     and b.Toolbar_Not_Req = 'Y' then 1 
							when a.property = 'Column Border Not Required'     and b.ColumnBorder_Not_Req= 'Y' then 1 
							when a.property = 'Row Border Not Required'     and b.RowBorder_Not_Req = 'Y' then 1 
							when a.property = 'Only page navigation Required'     and b.PagenavigationOnly= 'y' then 1
--code added for bugid: PLF2.0_07676 ends
							when a.property = 'Row No. Not Required'  and b.RowNO_Not_Req= 'y' then 1 --PLF2.0_07805
							when a.property = 'Home Button'  and b.ButtonHome_Req= 'y' then 1   
							when a.property = 'Previous Button'  and b.ButtonPrevious_Req= 'y' then 1
							when a.property = 'ToolTip Not Required'  and b.Tooltip_Not_Req= 'y' then 1
							when a.property = 'Fixed Column Width'  and b.Forcefit= 'y' then 1
							when a.property = 'Grid Header Not Required'  and b.columncaption_Not_Req= 'y' then 1
							when a.property = 'Border Not Required'  and b.Border_Not_Req= 'y' then 1
							when a.property = 'Is Modal'  and b.IsModal= 'y' then 1
							when a.property = 'Alternate Row Color Not Required'  and b.Alternate_Color_Req= 'y' then 1
							when a.property = 'Map In required'  and b.Map_In_Req= 'y' then 1 --kanagavel
							when a.property = 'Map Out Required'  and b.Map_Out_Req= 'y' then 1 --kanagavel
							when a.property = 'Barcode Image '     and b.Barcode_Image= 'y' then 1
							when a.property = 'Is Fallback'  and b.Isfallback='y' then 1 
							when a.property = 'Configuration Parameter'     and b.config_parameter= 'y' then 1
							when a.property = 'Is Data'  and b.config_value='y' then 1 
							when a.property = 'Upload'  and b.upload='y' then 1 
							when a.property = 'Is Varbinary'  and b.Is_Varbinary='y' then 1
							when a.property = 'EMail'  and b.EMail='y' then 1
							when a.property = 'Phone'  and b.Phone='y' then 1
							when a.property = 'Static Caption'  and b.StaticCaption='y' then 1
							when a.property  = 'Data Grid'  and b.DataGrid='y' then 1
							when a.property  = 'Move PreviousSet'  and b.Move_PrevSet='y' then 1
							when a.property  = 'MoveFirst'  and b.MoveFirst='y' then 1
							when a.property  = 'Move Previous'  and b.Move_Previous='y' then 1
							when a.property  = 'Move Next'  and b.Move_Next='y' then 1
							when a.property  = 'Move NextSet'  and b.Move_NextSet='y' then 1
							when a.property  = 'Move Last'  and b.Move_Last='y' then 1
							when a.property  = 'Carousel Required'  and b.Carousel_Req='y' then 1
							when a.property = 'ISDeviceInfo'  and b.ISDeviceInfo='y' then 1
							when a.property = 'List Control'  and b.ListControl='y' then 1
							when a.property = 'Pre Event'  and b.preevent='y' then 1
							when a.property = 'Post Event'  and b.postevent='y' then 1
							when a.property = 'Prevent Download'  and b.PreventDownload='y' then 1
							when a.property = 'Aviation Download'  and b.avn_download='y' then 1
							when a.property = 'Is Hijri'  and b.ishijri='y' then 1
							when a.property = 'Enable Default'  and b.enabledefault='y' then 1
							when a.property = 'Hide	Insert'  and b.hideinsert='y' then 1
							when a.property = 'Hide Delete'  and b.hidedelete='y' then 1
							when a.property = 'Hide Copy and Append Row'  and b.hidecopy='y' then 1
							when a.property = 'Hide Cut and Append Row'  and b.hidecut='y' then 1
							when a.property = 'Hide Filter Data'  and b.hidefilterdata='y' then 1
							when a.property = 'Hide Export to PDF'  and b.hidepdf='y' then 1
							when a.property = 'Hide Export to Report'  and b.hidereport='y' then 1
							when a.property = 'Hide Export to HTML'  and b.hidehtml='y' then 1
							when a.property = 'Hide Export to Excel'  and b.hideexportexcel='y' then 1
							when a.property = 'Hide Export to CSV'  and b.hideexportcsv='y' then 1
							when a.property = 'Hide Export to Text'  and b.hideexporttext='y' then 1
							when a.property = 'Hide Import Data'  and b.hideimportdata='y' then 1
							when a.property = 'Hide Chart'  and b.hidechart='y' then 1
							when a.property = 'Hide Export to Open Office'  and b.hideexportopenoffice='y' then 1
							when a.property = 'Hide Personalization'  and b.hidepersonalize='y' then 1
							when a.property = 'Hide Column Chooser'  and b.hidefiltercolumn='y' then 1
							when a.property = 'Grid Data Search Not Required'  and b.searchhide='y' then 1
							when a.property = 'Spin-System Task'  and b.spin_system_task='y' then 1
							when a.property = 'Auto List Without Filter Not Required'  and b.autolist_not_req='y' then 1
							when a.property = 'Hide Select'  and b.hideselect='y' then 1
							when a.property = 'No Rows to Display Not Required'  and b.norowstodisplay_notreq='y' then 1
							when a.property = 'AutoHeight'  and b.AutoHeight='y' then 1
							when a.property = 'Is Pivot'  and b.IsPivot='y' then 1--Changes for PLF2.0_16291
							when a.property = 'QlikLink'  and b.QlikLink='y' then 1--Changes for PLF2.0_16291
							when a.property = 'Is Marquee'  and b.IsMarquee='y' then 1
							when a.property = 'Is Assorted'  and b.IsAssorted='y' then 1
							
--when a.property = 'Is Rating'  and b.IsRatingControl='y' then 1
--when a.property = 'Is Captcha'  and b.IsCaptcha='y' then 1
							when a.property = 'System Generated File Id'  and b.systemgeneratedfileid='y' then 1
							when a.property = 'Is Chips'  and b.RenderAs='Chips' then 1
							
							when a.property = 'Is Tag'  and b.RenderAs='Chips' then 1
							when a.property = 'Is Tag'  and b.RenderAs='Tag' then 1							
							when a.property = 'Grid to Form'  and b.RenderAs='GridtoForm' then 1
							when a.property = 'Multi-Selector Grid'  and b.RenderAs='MultiSelectorGrid' then 1
							when a.property = 'Row Expander'  and b.RenderAs='RowExpander' then 1
							when a.property = 'Rule Builder'  and b.RenderAs='RB_MetaData' then 1			--Added by 13578							
							when a.property = 'Calander Control'  and b.RenderAs='Calander_event' then 1	--Added by 13578
							when a.property = 'Gantt Control'  and b.RenderAs='Gantt' then 1	
							when a.property = 'Is TreeGrid'  and b.RenderAs='IsTreeGrid' then 1
							when a.property = 'Is Mobile'  and b.RenderAs='MobileGrid' then 1
--when a.property = 'Visible Rows' and b.visisble_rows > 0 then 1  
							when a.property = 'Expand Event' and c.ExpandEvent = 'y' then 1  
							when a.property = 'Expand All Event' and c.ExpandAllEvent = 'y' then 1  
							when a.property = 'Collapse Event' and c.CollapseEvent = 'y' then 1  
							when a.property = 'Collapse All Event' and c.CollapseAllEvent = 'y' then 1  
							when a.property = 'Click Event' and c.ClickEvent = 'y' then 1  
							when a.property = 'Drag Drop ToolTip' and c.DDToolTip = 'y' then 1 
							when a.property = 'Node Icon Required'  and c.NodeIconReqd = 'y' then 1   
							when a.property = 'Node Custom Class'  and c.NodeCustomClass = 'y' then 1
							when a.property = 'Is Organization Chart' and c.IsOrgChart = 'y' then 1  
							when a.property = 'Zoom Maximum'   and c.ZoomMax > 0 then 1  
							when a.property = 'Zoom Minimum'   and c.ZoomMin > 0 then 1  
							when a.property = 'Zoom Step'	   and c.Zoomstep > 0 then 1  
							when a.property = 'Default Zoom'   and c.DefaultZoom > 0 then 1  
							when a.property = 'Node Width'	   and c.NodeWidth > 0 then 1  
							when a.property = 'Node Height'    and c.NodeHeight > 0 then 1  
							when a.property = 'Default File'   and  isnull(c.DefaultFile,'') <> '' then 1
							when a.property = 'Spark Chart Type' and c.SparkChartType in( 'Line','Bar','Discrete','Bullet','Pie','Box','Tri-state') then 1 
							-- code modified for Defect ID : TECH-18349 starts
							when a.property = 'Preserve Horizontal Scroll Position' and c.preserve_gridposition = 'y' then 1  
							when a.property = 'Delayed Password Masking' and c.Delayedpwdmask = 'y' then 1
							when a.property = 'Dynamic file Upload Path'  and c.Dynamicfileupload = 'y' then 1
							when a.property = 'Server Side Print' and c.ServerSidePrint = 'y' then 1
							when a.property = 'Multi File Select'  and c.MultiFileSelect = 'y' then 1
							-- code modified for Defect ID : TECH-18349 ends
						-- code added for Defect Id: TECH-19347 starts
							when a.property = 'Meta Data Based Link'  and c.MetaDataBasedLink = 'y' then 1
							when a.property = 'No of Controls per Line'	and convert(int,c.NoofCtrlPerLine) > 0 then 1 
							when a.property = 'Form Width'	and isnull(c.FormWidth,'')<> '' then 1
							when a.property = 'Control Width' and isnull(c.ControlWidth,'') <> '' then 1 
							when a.property = 'Label Width'	and isnull(c.LabelWidth,'') <> '' then 1  
							when a.property = 'Label Alignment'	and c.LabelAlignment in ('Left','Right','Top') then 1  
						-- Added for Rule Builder Starts Defect ID: TECH-35368
							when a.property = 'Rule Builder'	and isnull(c.RuleBuilder,'') <> '' then 1  
							when a.property = 'MultiSelect Combo for Rule Builder'	and isnull(c.MultiSelectComboforRB,'') <> '' then 1
							when a.property = 'Calander Control'	and isnull(c.CalendarControl,'') <> '' then 1 
						-- Added for Rule Builder Ends Defect ID: TECH-35368
						-- Added for the Defect ID: TECH-37471 Starts for Set & LEave Focus Events
						   when a.property  = 'Set Focus Event'   and c.SetFocusEvent  = 'Y' then 1
						   when a.property  = 'Leave Focus Event' and c.LeaveFocusEvent= 'Y' then 1

						   --when a.property  = 'Set Focus Event Occurence'   and c.SetFocusEventOccurence  = 'Y' then 1
						   --when a.property  = 'Leave Focus Event Occurence' and c.LeaveFocusEventOccurence= 'Y' then 1


						   when a.property  = 'Gantt Control'	  and c.GanttControl   = 'Y' then 1
						-- code added for Defect Id: TECH-19347 ends
						   when a.property  = 'Auto Sync'		  and c.AutoSync	   = 'Y' then 1
						   when a.property  = 'Auto Scan'		  and c.AutoScan	   = 'Y' then 1  -->added by 13639
						   -- Added for TECH-41979 Starts
						   -- when a.property = 'Is List'                       and b.RenderAs='IsList' then 1	-->added by 13639
						   --when a.property = 'ListItem Expander'             and b.RenderAs='ListItemExpander' then 1	-->added by 13639
							
	            ----code added by 13852 on 20jan2020
				           
						   when a.property  = 'Read Only'		              and c.ReadOnly	               = 'Y' then 1
						   when a.property  = 'Show Today Line'		          and c.ShowTodayLine	           = 'Y' then 1
						   when a.property  = 'Show Rollup Tasks'		      and c.ShowRollupTasks	           = 'Y' then 1
						   when a.property  = 'Show Project Lines'		      and c.ShowProjectLines	       = 'Y' then 1
						   when a.property  = 'Skip Weekends During DragDrop' and c.SkipWeekendsDuringDragDrop = 'Y' then 1
						   when a.property  = 'Locked Grid Width'		      and c.LockedGridWidth	           = 'Y' then 1
						   when a.property  = 'Row Height'		              and c.RowHeight	               = 'Y' then 1
						   when a.property  = 'Bottom LabelField'		      and c.BottomLabelField           = 'Y' then 1
						   when a.property  = 'Top LabelField'		          and c.TopLabelField	           = 'Y' then 1
						   when a.property  = 'Left LabelField'		          and c.LeftLabelField	           = 'Y' then 1
						   when a.property  = 'Right LabelField'		      and c.RightLabelField	           = 'Y' then 1
						   when a.property  = 'Rollup LabelField'		      and c.RollupLabelField	       = 'Y' then 1
						   when a.property  = 'Scroll To DateCentered'		  and c.ScrollToDateCentered	   = 'Y' then 1
						   when a.property  = 'Zoom'		                  and c.Zoom	                   = 'Y' then 1
						   when a.property  = 'Fit'		                      and c.Fit	                       = 'Y' then 1
						   when a.property  = 'Export'		                  and c.Export	                   = 'Y' then 1
						   when a.property  = 'Shift'		                  and c.GanttShift	               = 'Y' then 1
						   when a.property  = 'Expand'		                  and c.GanttExpand	               = 'Y' then 1
						   when a.property  = 'Insert'		                  and c.GanttInsert	               = 'Y' then 1
						   when a.property  = 'Delete'		                  and c.GanttDelete	               = 'Y' then 1
						   when a.property  = 'Indent'		                  and c.Indent	                   = 'Y' then 1
						   when a.property  = 'Calendar'		              and c.Calendar	               = 'Y' then 1
						   when a.property  = 'Context Menu'		          and c.ContextMenu	               = 'Y' then 1
						   when a.property  = 'Popup Task Editor'		      and c.PopupTaskEditor            = 'Y' then 1
						   when a.property  = 'Baseline'		              and c.Baseline	               = 'Y' then 1
						   when a.property  = 'Highlight'	                  and c.Highlight	               = 'Y' then 1
						   when a.property  = 'Is Chips'		              and c.IsChips                    = 'Y' then 1	
						    when a.property = 'Multi Select for List'		  and c.MultiSelect                = 'Y' then 1		--code added by 13852 on 24nov2020
						   when a.property  = 'Selection Required for List'	  and c.IsSelectionReqdList        = 'Y' then 1		--code added by 13639
						   when a.property  = 'Row Always Expanded'		      and c.RowAlwaysExpanded          = 'Y' then 1		--code added by 13639	

						   when a.property  = 'Is Scheduler'				  and c.IsScheduler				   = 'Y' then 1		--code added by 13639	

						   when a.property  = 'Pre Task'				  and c.PreTask				   = 'Y' then 1		--Code Added for the Defect Id TECH-68066
						   when a.property  = 'Post Task'				  and c.PostTask			   = 'Y' then 1		--Code Added for the Defect Id TECH-68066
						   --Code Added for the Defect Id TECH-71262 starts
						   when a.property  = 'Browse Pre Task'			  and c.BrowsePreTask		   = 'Y' then 1		
						   when a.property  = 'Browse Post Task'		  and c.BrowsePostTask		   = 'Y' then 1		
						   when a.property  = 'Delete Pre Task'			  and c.DeletePreTask		   = 'Y' then 1		
						   when a.property  = 'Delete Post Task'		  and c.DeletePostTask		   = 'Y' then 1		
						   when a.property  = 'Button Style'			  and c.ButtonStyle			   = 'Y' then 1		
						   --Code Added for the Defect Id TECH-71262 ends
						 
						   when a.property  = 'Bulk Download'			  and c.BulkDownload		   = 'Y' then 1		--code added by 11536 for the defect TECH-68067

						   when a.property  = 'Is Mobile'					 and c.IsMobile					   = 'Y' then 1		--code added by 13639	
						   when a.property  = 'Pagination Required'			 and c.PaginationReqd			   = 'Y' then 1		--code added by 13639	
						   when a.property  = 'Update Task Required'		 and c.UpdateTaskReqd			   = 'Y' then 1		--code added by 13639	
						   when a.property  = 'Delete Task Required'		 and c.DeleteTaskReqd			   = 'Y' then 1		--code added by 13639	

						   when a.property  = 'Is Tag'						  and c.IsChips                    = 'Y' then 1		
						   when a.property  = 'Spell Check Required'          and c.IsSpellcheck	           = 'Y' then 1 
						   when a.property  = 'Direct Print'		          and c.DirectPrint                = 'Y' then 1	
						   when a.property  = 'Is List'						  and c.IsList					   = 'Y' then 1	
						   when a.property  = 'ListItem Expander'	          and c.ListItemExpander           = 'Y' then 1	
						   --code added by 13639 on 23_jan_2020	
						   -- Added for TECH-41979 Ends
						-- code added for Defect Id: TECH-20326 starts
						  when a.property = 'Scan' and c.Scan = 'y' then 1						
						  when a.property = 'Auto Select' and c.Autoselect = 'y' then 1
						  when a.property = 'Auto Scan' and c.AutoScan = 'y' then 1  -->code added by 13639
						-- code added for Defect Id: TECH-20326 ends
						  when a.property  = 'ShowLines'	          and c.ShowLines           = 'Y' then 1	--TECH-66989
						   
						   --Code added for TECH-69624 starts
						   when a.property  = 'Hide Rule Header'		and c.HideRuleHeader				   = 'Y' then 1	
						   when a.property  = 'Hide AND Operator'		and c.HideANDOperator				   = 'Y' then 1	
						   when a.property  = 'Hide OR Operator'		and c.HideOROperator				   = 'Y' then 1	
						   when a.property  = 'Hide NOT Operator'		and c.HideNOTOperator				   = 'Y' then 1	
						   when a.property  = 'Hide Group Operator'		and c.HideGroupOperator				   = 'Y' then 1	
						   when a.property  = 'Hide Rule Operator'		and c.HideRuleOperator				   = 'Y' then 1	
						   when a.property  = 'Is Toggle'				and c.IsToggle						   = 'Y' then 1	
						   when a.property  = 'NFC Enabled'				and c.NFCEnabled					   = 'Y' then 1	
						   when a.property  = 'Select Only List Values'	and c.SelectOnlyListValues			   = 'Y' then 1	
						   --Code added for TECH-69624 Ends
						   when a.property  = 'Badge Text'				and c.BadgeText						   = 'Y' then 1	--Code Added for the DefectId Tech-72114
						   when a.property  = 'Auto Height'				and c.AutoHeight						   = 'Y' then 1  --Code Added for the DefectId Tech-72114
							--Code added for TECH-73996  starts
							when a.property  = 'Eye Icon for Password'			and c.EyeIconForPassword			   = 'Y' then 1
							when a.property  = 'Signature'						and c.Signature						   = 'Y' then 1
							when a.property  = 'Keyup Search'					and c.KeyupSearch					   = 'Y' then 1
							when a.property  = 'Stepper'						and c.Stepper						   = 'Y' then 1
							when a.property  = 'Live Clock'						and c.LiveClock						   = 'Y' then 1
							when a.property  = 'Clear Task'						and c.ClearTask						   = 'Y' then 1
							when a.property  = 'Show Animation'					and c.ShowAnimation					   = 'Y' then 1
							when a.property  = 'Prevent Multiple Row Selection'	and c.PreventMultipleRowSelection	   = 'Y' then 1
						
							--Code added for TECH-73996 Ends
					else 0  
					end  
from	es_ctrl_dtl_tmp  a (nolock),  
		es_comp_ctrl_type_mst  b (nolock)   left outer join 
		es_comp_ctrl_type_mst_extn  c(nolock)
on		b.customer_name		= c.customer_name
and		b.project_name		= c.project_name
and		b.process_name		= c.process_name
and		b.component_name	= c.component_name
and		b.base_ctrl_type	= c.base_ctrl_type
and		b.ctrl_type_name	= c.ctrl_type_name

where	a.customer_name		= @engg_customer_name  
and		a.project_name		= @engg_project_name  
and		a.process_name		= @engg_process_name  
and		a.component_name	= @engg_comp_name  
and		a.base_ctrl_type	= @engg_basecmb_type  
and		a.control_type		= @engg_ctrlcmb_type  
and		b.customer_name		= a.customer_name  
and		b.project_name		= a.project_name  
and		b.process_name		= a.process_name  
and		b.component_name	= a.component_name  
and		b.ctrl_type_name	= a.control_type  
and		b.base_ctrl_type	= a.base_ctrl_type  
and		a.guid				= @guid  

 --select * from es_ctrl_dtl_tmp(nolock)  
--where   property='listitem type'
  
Select	distinct a.property	'engg_prop_desc',  
		a.ctrl_req			'engg_prop_req'  
from	es_ctrl_dtl_tmp  a (nolock),  
		es_ctrl_task_met b (nolock)  
where	a.customer_name		= @engg_customer_name  
and		a.project_name		= @engg_project_name  
and		a.process_name		= @engg_process_name  
and		a.component_name	= @engg_comp_name  
and		a.base_ctrl_type	= @engg_basecmb_type  
and		a.control_type		= @engg_ctrlcmb_type  
and		a.base_ctrl_type	= b.quick_code  
and		b.quick_code_type	= 'control'  
and		isnull(a.enumerated_values, '#' ) = '#'  
and		a.guid				= @guid  
order by 'engg_prop_req'  desc  

Set nocount off  
End  

GO
IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME= 'ep_main13Spfetengg_l' AND TYPE='P')
BEGIN
	GRANT EXEC ON  ep_main13Spfetengg_l TO PUBLIC
END
GO 