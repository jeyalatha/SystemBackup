IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_attachdoc_hiddenview_ins_sp' AND TYPE = 'P')
BEGIN
	DROP PROC ep_attachdoc_hiddenview_ins_sp                            
END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		ep_attachdoc_hiddenview_ins_sp.sql
********************************************************************************/
/*****************************************************************************************/
/* Created by : Ganesh Prabhu S/Ranjitha R      for callid  TECH-10118                   */
/* Created on : 30-May-2017																 */
/* Description : Platform Feature Release												 */
/*****************************************************************************************/
/* Modified by  : JeyaLatha K/Ranjitha R	Date: 31-Jan-2018  Defect ID : TECH-18349	 */
/*****************************************************************************************/
/* Modified by  : Ranjitha R				Date: 04-Jun-2018  Defect ID : TECH-22624    
   Description	: View Name getting duplicated for the hidden views.					 */
/*****************************************************************************************/
/* Modified by : Ponmalar A					Date: 02-Dec-2022  Defect ID : TECH-75230	 */
/*****************************************************************************************/
CREATE PROCEDURE ep_attachdoc_hiddenview_ins_sp
	@ctxt_language engg_ctxt_language,
	@ctxt_ouinstance engg_ctxt_ouinstance,
	@ctxt_service engg_ctxt_service,
	@ctxt_user engg_ctxt_user,
	@engg_customer_name engg_name,
	@engg_project_name engg_name,
	@tmp_proc engg_name,
	@tmp_comp engg_name,
	@tmp_act engg_name,
	@tmp_ui engg_name,
	@engg_cont_page_bts engg_name,
	@engg_cont_sec_bts engg_name,
	@engg_cont_btsynname engg_name,
	@engg_grid_btsynname engg_name,
	@engg_req_no engg_name,
	@tmp_control_type engg_name,
	@engg_cont_elem_type engg_name,
	@controlid engg_name,
	@viewname engg_name,
	@modeflag engg_flag,
	@del_flag engg_flag,
	@del_flag_ph engg_flag,
	@hdrmlflag engg_flag,
	@m_errorid engg_seqno
AS
BEGIN
	SET NOCOUNT ON

	DECLARE @hidden_vew_bt_synonym engg_name,
		@engg_cont_btsynname_tmp engg_name,
		@hidden_vew_bt_synonym_tmp engg_name,
		@ctxt_attach_doc engg_name,
		@engg_base_req_no engg_name,
		@control_id engg_name,
		@viewname_tmp engg_name,
		@view_name engg_name,
		@hview_name_tmp engg_name,
		@control_bt_synonym_tmp engg_name,
		@count INT,
		@control_prfx	engg_name	--TECH-75230


	SELECT @engg_base_req_no = 'BASE'

	IF @hdrmlflag = 'HDR'
	BEGIN
		SELECT @controlid = control_id,
			@viewname = control_id,
			@control_prfx	=	control_prefix --TECH-75230
		FROM ep_ui_control_dtl(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND process_name = @tmp_proc
			AND component_name = @tmp_comp
			AND activity_name = @tmp_act
			AND ui_name = @tmp_ui
			AND page_bt_synonym = @engg_cont_page_bts
			AND section_bt_synonym = @engg_cont_sec_bts
			AND control_bt_synonym = @engg_cont_btsynname			
	END
	ELSE IF @hdrmlflag = 'ML'
	BEGIN
		SELECT @controlid = control_id,
			@viewname = view_name,
			@control_prfx	=	column_prefix --TECH-75230
		FROM ep_ui_grid_dtl(NOLOCK)
		WHERE customer_name = rtrim(@engg_customer_name)
			AND project_name = rtrim(@engg_project_name)
			AND req_no = rtrim(@engg_base_req_no)
			AND process_name = rtrim(@tmp_proc)
			AND component_name = rtrim(@tmp_comp)
			AND activity_name = rtrim(@tmp_act)
			AND ui_name = rtrim(@tmp_ui)
			AND page_bt_synonym = rtrim(@engg_cont_page_bts)
			AND section_bt_synonym = rtrim(@engg_cont_sec_bts)
			AND control_bt_synonym = rtrim(@engg_cont_btsynname)
			AND column_bt_synonym = rtrim(@engg_grid_btsynname)
	END
	
	IF @hdrmlflag = 'HDR'
		SELECT @control_bt_synonym_tmp = @engg_cont_btsynname
	ELSE IF @hdrmlflag = 'ML'
		SELECT @control_bt_synonym_tmp = @engg_grid_btsynname

	IF @tmp_control_type <> @engg_cont_elem_type
	BEGIN
		IF NOT EXISTS (
				SELECT 'x'
				FROM es_comp_ctrl_type_mst(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND ctrl_type_name = @engg_cont_elem_type
					AND (
						attach_document = 'Y'
						AND AttachmentWithDesc = 'y'
						)
				)
		BEGIN
			DELETE
			FROM de_hidden_view_usage
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @tmp_proc
				AND component_name = @tmp_comp
				AND activity_name = @tmp_act
				AND ui_name = @tmp_ui
				AND control_page_name = @engg_cont_page_bts
				AND control_bt_sysnonym = @control_bt_synonym_tmp
				AND hidden_view_bt_sysnonym LIKE ('hdiFID' + @hidden_vew_bt_synonym + '%')

			DELETE
			FROM de_hidden_view
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @tmp_proc
				AND component_name = @tmp_comp
				AND activity_name = @tmp_act
				AND ui_name = @tmp_ui
				AND page_name = @engg_cont_page_bts
				AND section_name = @engg_cont_sec_bts
				AND control_bt_synonym = @control_bt_synonym_tmp
				AND hidden_view_bt_synonym LIKE ('hdiFID' + @hidden_vew_bt_synonym + '%')
		END
	END
IF ISNULL(@modeflag,'') in ('I','X','U','Y')	--TECH-75230
BEGIN --TECH-75230

	IF EXISTS (
			SELECT 'x'
			FROM es_comp_ctrl_type_mst(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @tmp_proc
				AND component_name = @tmp_comp
				AND ctrl_type_name = @engg_cont_elem_type
				AND (
					attach_document = 'Y'
					AND AttachmentWithDesc = 'y'
					)
			) -- If attachment with Description selected
	BEGIN
		--IF NOT EXISTS   (SELECT  'X'
		--FROM    de_hidden_view (NOLOCK)
		--WHERE   customer_name	= @engg_customer_name
		--AND		project_name	= @engg_project_name
		--AND		process_name	= @tmp_proc
		--AND		component_name	= @tmp_comp
		--AND		ui_name			= @tmp_ui
		--AND		page_name		= @engg_cont_page_bts
		--AND		section_name	= @engg_cont_sec_bts
		--and		control_bt_synonym= @control_bt_synonym_tmp)
		--BEGIN 		   
		SET @count = 0

		--Code commented for defectid TECH-75230 starts
		--IF len(@control_bt_synonym_tmp) > 22
		--BEGIN
		--	SELECT @engg_cont_btsynname_tmp = left(@control_bt_synonym_tmp, 20)
		--END
		--ELSE
		--BEGIN
		--	SELECT @engg_cont_btsynname_tmp = @control_bt_synonym_tmp
		--END
		--Code commented for TECH-75230 ends

		WHILE (1 = 1)
		BEGIN
		--	SELECT @hidden_vew_bt_synonym = 'hdiFID' + @engg_cont_btsynname_tmp
			SELECT @hidden_vew_bt_synonym = 'hdiFID' + @control_prfx		--TECH-75230
			
			IF @count = 0
			BEGIN
				SELECT @hidden_vew_bt_synonym_tmp = @hidden_vew_bt_synonym
			END
			ELSE
			BEGIN
				SELECT @hidden_vew_bt_synonym_tmp = @hidden_vew_bt_synonym + cast(@count AS VARCHAR)
			END
		
			IF NOT EXISTS (
					SELECT 'x'
					FROM de_hidden_view(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND activity_name = @tmp_act
						AND ui_name = @tmp_ui
						AND page_name = @engg_cont_page_bts
						AND control_bt_synonym = @engg_cont_btsynname
						AND hidden_view_bt_synonym LIKE 'hdiFID%'
					)
				AND EXISTS (
					SELECT 'x'
					FROM ep_ui_page_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND activity_name = @tmp_act
						AND ui_name = @tmp_ui
						AND page_bt_synonym = @hidden_vew_bt_synonym_tmp
					
					UNION
					
					SELECT 'x'
					FROM ep_ui_section_dtl a(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND activity_name = @tmp_act
						AND ui_name = @tmp_ui
						AND page_bt_synonym = @engg_cont_page_bts
						AND section_bt_synonym = @hidden_vew_bt_synonym_tmp
						AND req_no = @engg_base_req_no
					
					UNION
					
					SELECT 'x'
					FROM ep_ui_control_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND activity_name = @tmp_act
						AND ui_name = @tmp_ui
						AND page_bt_synonym = @engg_cont_page_bts
						AND control_bt_synonym = @hidden_vew_bt_synonym_tmp
						AND req_no = @engg_base_req_no
					
					UNION
					
					SELECT 'x'
					FROM ep_ui_grid_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND activity_name = @tmp_act
						AND ui_name = @tmp_ui
						AND page_bt_synonym = @engg_cont_page_bts
						AND column_bt_synonym = @hidden_vew_bt_synonym_tmp
						AND req_no = @engg_base_req_no
					--Union  
					--Select  'x' 
					--from	de_hidden_view (nolock)  
					--where	customer_name		=  @engg_customer_name  
					--and		project_name		=  @engg_project_name  
					--and		process_name		=  @tmp_proc  
					--and		component_name		=  @tmp_comp  
					--and		activity_name		=  @tmp_act  
					--and		ui_name				=  @tmp_ui  
					--and		page_name			=  @engg_cont_page_bts  
					--and		hidden_view_bt_synonym =  @hidden_vew_bt_synonym_tmp  
					
					UNION
					
					SELECT 'x'
					FROM de_scratch_variable(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND activity_name = @tmp_act
						AND ui_name = @tmp_ui
						AND page_name = @engg_cont_page_bts
						AND scratch_name = @hidden_vew_bt_synonym_tmp
					
					UNION
					
					SELECT 'x'
					FROM de_scratch_variables_sys(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND btsynonym = @hidden_vew_bt_synonym_tmp
					)
			BEGIN
				SELECT @count = @count + 1
			END
			ELSE
			BEGIN
				BREAK
			END
		END

		SELECT @hidden_vew_bt_synonym = @hidden_vew_bt_synonym_tmp
		
		IF NOT EXISTS (
				SELECT 'x'
				FROM ep_component_glossary_mst(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND bt_synonym_name = @hidden_vew_bt_synonym
				)
		BEGIN
			IF EXISTS (
					SELECT 'X'
					FROM es_comp_ctrl_type_mst(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND ctrl_type_name = @engg_cont_elem_type
						AND attach_document = 'Y'
						AND is_varbinary = 'y'
					)
			BEGIN
				SELECT @ctxt_attach_doc = 'varbinary(max)'

				IF EXISTS (
						SELECT 'x'
						FROM de_business_term(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @tmp_proc
							AND component_name = @tmp_comp
							AND length = 8000
							AND data_type = 'varbinary'
						)
				BEGIN
					SELECT @ctxt_attach_doc = bt_name
					FROM de_business_term(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND length = 8000
						AND data_type = 'varbinary'
				END
				ELSE
				BEGIN
					INSERT INTO de_business_term (
						customer_name,
						project_name,
						process_name,
						component_name,
						bt_name,
						bt_descr,
						data_type,
						bt_sysid,
						TIMESTAMP,
						createdby,
						createddate,
						modifiedby,
						modifieddate,
						length,
						precision_type,
						Generatedby,
						ecrno
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@tmp_proc,
						@tmp_comp,
						@ctxt_attach_doc,
						@ctxt_attach_doc,
						'varbinary',
						NEWID(),
						1,
						@ctxt_user,
						GETDATE(),
						@ctxt_user,
						GETDATE(),
						8000,
						NULL,
						'',
						@engg_base_req_no
						)
				END

				EXEC ep_component_glossary_mst_sp_ins @ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@engg_customer_name,
					@engg_project_name,
					@engg_base_req_no,
					@tmp_proc,
					@tmp_comp,
					@hidden_vew_bt_synonym,
					NULL,
					'varbinary',
					8000,
					@hidden_vew_bt_synonym,
					@hidden_vew_bt_synonym,
					@ctxt_attach_doc,
					'U',
					'',
					'',
					1,
					@engg_req_no,
					@m_errorid OUTPUT

				IF @m_errorid <> 0
					RETURN

				INSERT INTO RE_GLOSSARY (
					customer_name,
					project_name,
					bt_synonym_name,
					process_name,
					component_name,
					data_type,
					length,
					bt_synonym_caption,
					glossary_sysid,
					TIMESTAMP,
					createdby,
					createddate,
					modifiedby,
					modifieddate,
					ref_bt_synonym_name,
					bt_synonym_doc,
					bt_name,
					synonym_status,
					singleinst_sample_data,
					multiinst_sample_data,
					rcnno
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@hidden_vew_bt_synonym,
					@tmp_proc,
					@tmp_comp,
					'varbinary',
					8000,
					@hidden_vew_bt_synonym,
					NEWID(),
					1,
					@ctxt_user,
					GETDATE(),
					@ctxt_user,
					GETDATE(),
					'',
					@hidden_vew_bt_synonym,
					@ctxt_attach_doc,
					'R',
					'',
					'',
					''
					)

				INSERT INTO RE_GLOSSARY_LNG_EXTN (
					customer_name,
					project_name,
					process_name,
					component_name,
					bt_synonym_name,
					data_type,
					length,
					bt_synonym_caption,
					glossary_sysid,
					languageid,
					TIMESTAMP,
					createdby,
					createddate,
					modifiedby,
					modifieddate,
					ref_bt_synonym_name,
					bt_synonym_doc,
					bt_name,
					synonym_status,
					singleinst_sample_data,
					multiinst_sample_data,
					rcnno
					)
				SELECT @engg_customer_name,
					@engg_project_name,
					@tmp_proc,
					@tmp_comp,
					@hidden_vew_bt_synonym,
					'varbinary',
					8000,
					@hidden_vew_bt_synonym,
					NEWID(),
					quick_code,
					1,
					@ctxt_user,
					GETDATE(),
					@ctxt_user,
					GETDATE(),
					'',
					@hidden_vew_bt_synonym,
					@ctxt_attach_doc,
					'R',
					'',
					'',
					''
				FROM EP_LANGUAGE_MET(NOLOCK)

				INSERT INTO DE_GLOSSARY (
					customer_name,
					project_name,
					component_name,
					process_name,
					bt_synonym_name,
					data_type,
					length,
					bt_synonym_caption,
					glossary_sysid,
					TIMESTAMP,
					createdby,
					createddate,
					modifiedby,
					modifieddate,
					ref_bt_synonym_name,
					bt_synonym_doc,
					bt_name,
					synonym_status,
					singleinst_sample_data,
					multiinst_sample_data,
					ecrno
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@tmp_comp,
					@tmp_proc,
					@hidden_vew_bt_synonym,
					'varbinary',
					8000,
					@hidden_vew_bt_synonym,
					NEWID(),
					1,
					@ctxt_user,
					GETDATE(),
					@ctxt_user,
					GETDATE(),
					'',
					@hidden_vew_bt_synonym,
					@ctxt_attach_doc,
					'R',
					'',
					'',
					''
					)

				INSERT INTO DE_GLOSSARY_LNG_EXTN (
					customer_name,
					project_name,
					process_name,
					component_name,
					bt_synonym_name,
					data_type,
					length,
					bt_synonym_caption,
					glossary_sysid,
					languageid,
					TIMESTAMP,
					createdby,
					createddate,
					modifiedby,
					modifieddate,
					ref_bt_synonym_name,
					bt_synonym_doc,
					bt_name,
					synonym_status,
					singleinst_sample_data,
					multiinst_sample_data,
					ecrno
					)
				SELECT @engg_customer_name,
					@engg_project_name,
					@tmp_proc,
					@tmp_comp,
					@hidden_vew_bt_synonym,
					'varbinary',
					8000,
					@hidden_vew_bt_synonym,
					NEWID(),
					quick_code,
					1,
					@ctxt_user,
					GETDATE(),
					@ctxt_user,
					GETDATE(),
					'',
					@hidden_vew_bt_synonym,
					@ctxt_attach_doc,
					'R',
					'',
					'',
					''
				FROM EP_LANGUAGE_MET(NOLOCK)
			END
			ELSE ---- Code added for newly added property isvarbinary in control types ends
			BEGIN
				SELECT @ctxt_attach_doc = 'ctxt_attach_doc'

				IF EXISTS (
						SELECT 'x'
						FROM de_business_term(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @tmp_proc
							AND component_name = @tmp_comp
							AND length = 4000
							AND data_type = 'char'
						)
				BEGIN
					SELECT @ctxt_attach_doc = bt_name
					FROM de_business_term(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND length = 4000
						AND data_type = 'char'
				END
				ELSE
				BEGIN
					INSERT INTO de_business_term (
						customer_name,
						project_name,
						process_name,
						component_name,
						bt_name,
						bt_descr,
						data_type,
						bt_sysid,
						TIMESTAMP,
						createdby,
						createddate,
						modifiedby,
						modifieddate,
						length,
						precision_type,
						Generatedby,
						ecrno
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@tmp_proc,
						@tmp_comp,
						@ctxt_attach_doc,
						@ctxt_attach_doc,
						'CHAR',
						NEWID(),
						1,
						@ctxt_user,
						getdate(),
						@ctxt_user,
						getdate(),
						4000,
						NULL,
						'',
						@engg_base_req_no
						)
				END
				
				EXEC ep_component_glossary_mst_sp_ins @ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@engg_customer_name,
					@engg_project_name,
					@engg_base_req_no,
					@tmp_proc,
					@tmp_comp,
					@hidden_vew_bt_synonym,
					NULL,
					'Char', -- Code Modified By Feroz For Bug Id :PNR2.0_23766  
					4000,
					@hidden_vew_bt_synonym,
					@hidden_vew_bt_synonym,
					@ctxt_attach_doc,
					'U',
					'',
					'',
					1,
					@engg_req_no,
					@m_errorid OUTPUT

				IF @m_errorid <> 0
					RETURN

				INSERT INTO RE_GLOSSARY (
					customer_name,
					project_name,
					bt_synonym_name,
					process_name,
					component_name,
					data_type,
					length,
					bt_synonym_caption,
					glossary_sysid,
					TIMESTAMP,
					createdby,
					createddate,
					modifiedby,
					modifieddate,
					ref_bt_synonym_name,
					bt_synonym_doc,
					bt_name,
					synonym_status,
					singleinst_sample_data,
					multiinst_sample_data,
					rcnno
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@hidden_vew_bt_synonym,
					@tmp_proc,
					@tmp_comp,
					'char',
					4000,
					@hidden_vew_bt_synonym,
					newid(),
					1,
					@ctxt_user,
					getdate(),
					@ctxt_user,
					getdate(),
					'',
					@hidden_vew_bt_synonym,
					@ctxt_attach_doc,
					'R',
					'',
					'',
					''
					)

				INSERT INTO RE_GLOSSARY_LNG_EXTN (
					customer_name,
					project_name,
					process_name,
					component_name,
					bt_synonym_name,
					data_type,
					length,
					bt_synonym_caption,
					glossary_sysid,
					languageid,
					TIMESTAMP,
					createdby,
					createddate,
					modifiedby,
					modifieddate,
					ref_bt_synonym_name,
					bt_synonym_doc,
					bt_name,
					synonym_status,
					singleinst_sample_data,
					multiinst_sample_data,
					rcnno
					)
				SELECT @engg_customer_name,
					@engg_project_name,
					@tmp_proc,
					@tmp_comp,
					@hidden_vew_bt_synonym,
					'char',
					4000,
					@hidden_vew_bt_synonym,
					newid(),
					quick_code,
					1,
					@ctxt_user,
					getdate(),
					@ctxt_user,
					getdate(),
					'',
					@hidden_vew_bt_synonym,
					@ctxt_attach_doc,
					'R',
					'',
					'',
					''
				FROM EP_LANGUAGE_MET(NOLOCK)

				INSERT INTO DE_GLOSSARY (
					customer_name,
					project_name,
					component_name,
					process_name,
					bt_synonym_name,
					data_type,
					length,
					bt_synonym_caption,
					glossary_sysid,
					TIMESTAMP,
					createdby,
					createddate,
					modifiedby,
					modifieddate,
					ref_bt_synonym_name,
					bt_synonym_doc,
					bt_name,
					synonym_status,
					singleinst_sample_data,
					multiinst_sample_data,
					ecrno
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@tmp_comp,
					@tmp_proc,
					@hidden_vew_bt_synonym,
					'char',
					4000,
					@hidden_vew_bt_synonym,
					newid(),
					1,
					@ctxt_user,
					getdate(),
					@ctxt_user,
					getdate(),
					'',
					@hidden_vew_bt_synonym,
					@ctxt_attach_doc,
					'R',
					'',
					'',
					''
					)

				INSERT INTO DE_GLOSSARY_LNG_EXTN (
					customer_name,
					project_name,
					process_name,
					component_name,
					bt_synonym_name,
					data_type,
					length,
					bt_synonym_caption,
					glossary_sysid,
					languageid,
					TIMESTAMP,
					createdby,
					createddate,
					modifiedby,
					modifieddate,
					ref_bt_synonym_name,
					bt_synonym_doc,
					bt_name,
					synonym_status,
					singleinst_sample_data,
					multiinst_sample_data,
					ecrno
					)
				SELECT @engg_customer_name,
					@engg_project_name,
					@tmp_proc,
					@tmp_comp,
					@hidden_vew_bt_synonym,
					'char',
					4000,
					@hidden_vew_bt_synonym,
					newid(),
					quick_code,
					1,
					@ctxt_user,
					getdate(),
					@ctxt_user,
					getdate(),
					'',
					@hidden_vew_bt_synonym,
					@ctxt_attach_doc,
					'R',
					'',
					'',
					''
				FROM EP_LANGUAGE_MET(NOLOCK)
			END
		END

		-- end 
		IF @hdrmlflag = 'HDR' -- If 'HDR'
		BEGIN
			IF NOT EXISTS (
					SELECT 'x'
					FROM de_hidden_view(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND activity_name = @tmp_act
						AND ui_name = @tmp_ui
						AND page_name = @engg_cont_page_bts
						AND section_name = @engg_cont_sec_bts
						AND control_bt_synonym = @engg_cont_btsynname
						AND hidden_view_bt_synonym = @hidden_vew_bt_synonym
					)
			BEGIN
				INSERT INTO de_hidden_view (
					customer_name,
					project_name,
					process_name,
					component_name,
					activity_name,
					ui_name,
					page_name,
					section_name,
					control_bt_synonym,
					hidden_view_bt_synonym,
					transfer_flag,
					hidden_view_sysid,
					control_sysid,
					TIMESTAMP,
					createdby,
					createddate,
					modifiedby,
					modifieddate,
					control_id,
					view_name,
					new_control_bt_synonym,
					HIDDEN_VIEW_SOURCE,
					ecrno
					)
				SELECT @engg_customer_name,
					@engg_project_name,
					@tmp_proc,
					@tmp_comp,
					@tmp_act,
					@tmp_ui,
					@engg_cont_page_bts,
					@engg_cont_sec_bts,
					@engg_cont_btsynname,
					@hidden_vew_bt_synonym,
					'N',
					newid(),
					newid(),
					1,
					@ctxt_user,
					getdate(),
					@ctxt_user,
					getdate(),
					@controlid,
					@hidden_vew_bt_synonym,
					@hidden_vew_bt_synonym,
					NULL,
					NULL
			END
		END
		ELSE IF @hdrmlflag = 'ML' -- If 'ML'
		BEGIN
			IF NOT EXISTS (
					SELECT 'x'
					FROM de_hidden_view(NOLOCK) -- If not de_hidden_view
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND activity_name = @tmp_act
						AND ui_name = @tmp_ui
						AND page_name = @engg_cont_page_bts
						AND section_name = @engg_cont_sec_bts
						AND control_bt_synonym = @engg_grid_btsynname
						AND hidden_view_bt_synonym = @hidden_vew_bt_synonym
					)
			BEGIN
				SELECT @viewname_tmp = max(cast(view_name AS INT)) + 1
				FROM ep_ui_grid_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND activity_name = @tmp_act
					AND ui_name = @tmp_ui
					AND page_bt_synonym = @engg_cont_page_bts
					AND section_bt_synonym = @engg_cont_sec_bts
					AND control_bt_synonym = @engg_cont_btsynname

				SELECT @hview_name_tmp = max(cast(a.view_name AS INT)) + 1
				FROM de_hidden_view a(NOLOCK)
				WHERE a.customer_name = @engg_customer_name
					AND a.project_name = @engg_project_name
					AND a.process_name = @tmp_proc
					AND a.component_name = @tmp_comp
					AND a.activity_name = @tmp_act
					AND a.ui_name = @tmp_ui
					AND a.page_name = @engg_cont_page_bts
					AND a.section_name = @engg_cont_sec_bts
					AND a.control_bt_synonym NOT IN (
						SELECT b.control_bt_synonym
						FROM de_ui_control B(NOLOCK)
						WHERE b.customer_name = @engg_customer_name
							AND b.project_name = @engg_project_name
							AND b.process_name = @tmp_proc
							AND b.component_name = @tmp_comp
							AND b.activity_name = @tmp_act
							AND b.ui_name = @tmp_ui
							AND b.page_bt_synonym = @engg_cont_page_bts
							AND b.section_bt_synonym = @engg_cont_sec_bts
						)

				IF isnull(@viewname_tmp, '') = ''
				BEGIN
					SELECT @view_name = '1'
				END
				ELSE
				BEGIN
					IF cast(isnull(@hview_name_tmp, '0') AS INT) > cast(@viewname_tmp AS INT)
					BEGIN
						SELECT @view_name = @hview_name_tmp
					END
					ELSE
					BEGIN
						SELECT @view_name = @viewname_tmp
					END
				END

				INSERT INTO de_hidden_view (
					customer_name,
					project_name,
					process_name,
					component_name,
					activity_name,
					ui_name,
					page_name,
					section_name,
					control_bt_synonym,
					hidden_view_bt_synonym,
					transfer_flag,
					hidden_view_sysid,
					control_sysid,
					TIMESTAMP,
					createdby,
					createddate,
					modifiedby,
					modifieddate,
					control_id,
					view_name,
					new_control_bt_synonym,
					HIDDEN_VIEW_SOURCE,
					ecrno
					)
				SELECT @engg_customer_name,
					@engg_project_name,
					@tmp_proc,
					@tmp_comp,
					@tmp_act,
					@tmp_ui,
					@engg_cont_page_bts,
					@engg_cont_sec_bts,
					@engg_grid_btsynname,
					@hidden_vew_bt_synonym,
					'N',
					newid(),
					newid(),
					1,
					@ctxt_user,
					getdate(),
					@ctxt_user,
					getdate(),
					@controlid,
					cast(@view_name AS INT), -- code modified for Defect Id: TECH-18349
					@hidden_vew_bt_synonym,
					NULL,
					NULL
			END -- If not de_hidden_view
		END -- If 'ML'
	END -- If 'HDR'
			--End 

	IF NOT EXISTS (
			SELECT 'x'
			FROM Ep_ui_control_properties(NOLOCK)
			WHERE customername = @engg_customer_name
				AND projectname = @engg_project_name
				AND processname = @tmp_proc
				AND componentname = @tmp_comp
				AND req_no = @engg_req_no
				AND ilbocode = @tmp_ui
				AND controlid = @controlid
				AND viewname = @viewname
				AND propertyname = 'File ID'
			)
	BEGIN
		INSERT INTO Ep_ui_control_properties (
			customername,
			projectname,
			processname,
			componentname,
			req_no,
			ilbocode,
			controlid,
			viewname,
			propertyname,
			page_bt_synonym,
			control_bt_synonym,
			value,
			TIMESTAMP,
			createdby,
			createddate,
			modifiedby,
			modifieddate
			)
		VALUES (
			@engg_customer_name,
			@engg_project_name,
			@tmp_proc,
			@tmp_comp,
			@engg_req_no,
			@tmp_ui,
			@controlid,
			@viewname,
			'File ID',
			@engg_cont_page_bts,
			@engg_cont_btsynname,
			@hidden_vew_bt_synonym,
			1,
			@ctxt_user,
			getdate(),
			@ctxt_user,
			getdate()
			)
	END
END --TECH-75230
	IF @modeflag = 'D'
		AND isnull(@del_flag, 'T') = 'T' -- Code Modified for PNR2.0_32228 Starts  
		AND isnull(@del_flag_ph, 'T') = 'T'
	BEGIN
		DELETE
		FROM de_hidden_view_usage
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND process_name = @tmp_proc
			AND component_name = @tmp_comp
			AND activity_name = @tmp_act
			AND ui_name = @tmp_ui
			AND control_page_name = @engg_cont_page_bts
			AND control_bt_sysnonym = @control_bt_synonym_tmp

		--and  hidden_view_bt_sysnonym  = @hidden_vew_bt_synonym  
		--if @hdrmlflag = 'Hdr'
		DELETE
		FROM de_hidden_view
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND process_name = @tmp_proc
			AND component_name = @tmp_comp
			AND activity_name = @tmp_act
			AND ui_name = @tmp_ui
			AND page_name = @engg_cont_page_bts
			AND section_name = @engg_cont_sec_bts
			AND control_bt_synonym = @control_bt_synonym_tmp
			-- 	commented for Defect Id: TECH-18349		
			--Else if @hdrmlflag = 'Hdr'
			--	Delete	from de_hidden_view  
			--	where  customer_name	= @engg_customer_name  
			--	and		project_name	= @engg_project_name  
			--	and		process_name	= @tmp_proc  
			--	and		component_name	= @tmp_comp  
			--	and		activity_name	= @tmp_act  
			--	and		ui_name			= @tmp_ui  
			--	and		page_name		= @engg_cont_page_bts  
			--	and		section_name	= @engg_cont_sec_bts  
			--	and		control_bt_synonym = @control_bt_synonym_tmp  
			--	and		hidden_view_bt_synonym  = @hidden_vew_bt_synonym   
	END

	SET NOCOUNT OFF
END

GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME= 'ep_attachdoc_hiddenview_ins_sp' AND TYPE='P')
BEGIN
	GRANT EXEC ON  ep_attachdoc_hiddenview_ins_sp TO PUBLIC
END
GO  
