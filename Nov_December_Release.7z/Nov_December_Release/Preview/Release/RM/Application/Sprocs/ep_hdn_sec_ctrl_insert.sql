IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_hdn_sec_ctrl_insert' AND TYPE = 'P')
BEGIN
	DROP PROC ep_hdn_sec_ctrl_insert                            
END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		ep_hdn_sec_ctrl_insert.sql
********************************************************************************/
/*      V E R S I O N      :  2 . 0 . 4    */
/*      Released By        :  PTech    */
/*      Release Comments   :  Released on 07 - Jan -05 (Patch Release 1)    */
/*      V E R S I O N      :  2.0.2    */
/*      Released By        :  PTech    */
/*      Release Comments   :  Released on  22-Jan-2004    */
/********************************************************************************/
/* procedure      ep_hdn_sec_ctrl_insert                                        */
/* description                                                                  */
/********************************************************************************/
/* project        Preview                                                       */
/* version                                                                      */
/********************************************************************************/
/* referenced                                                                   */
/* tables                                                                       */
/********************************************************************************/
/* development history                                                          */
/********************************************************************************/
/* author         Shafina Begum.B                                               */
/* date           09/ 01/ 2004                                                  */
/********************************************************************************/
/* modification history                                                         */
/********************************************************************************/
/* modified by    Shafina Begum.B                                               */
/* date           14/ 01/ 2004                                                  */
/* description    to select @hdn_ctrl_type='hiddenctrltype'   */
/********************************************************************************/
/* modified by    Hamsika                                          */
/* date           17/ 10/ 2005                                                  */
/* description    While downloading work request "Formal parameter   */
/*'@TSKIMG_CLASS_IN' was defined as OUTPUT but the actual parameter not  */
/* declared OUTPUT."        */
/********************************************************************************/
/* modified by    Balaji S For BugId : PNR2.0_7243                              */
/* date           16/ 03/ 2006                                                  */
/* description    Section type Should be Main For Hdn section     */
/********************************************************************************/
/* modified by    Sri Saravana Kumar S For BugId : PNR2.0_11174                              */
/* date           24/ 11/ 2006                                                  */
/* description    BPC: Solutioning 1) Engineering Preview -> Download work Request */
/* 2) Customer:BCD_PP, Project:PPS_402, Work Request Type :Development 3) Select */
/*'Base', then click 'Download workrequest' button then getting error as 'Formal */
/*Parameter'@SPIN_REQUIRED_IN' was defined as OUTPUT but actual parameter not declared OUTPUT.  */
/********************************************************************************/
/* modified by   : Chanheetha N A        */
/* date     : 17-nov-2007         */
/* BugId    : PNR2.0_16023          */
/************************************************************************************************/
/* modified by     :  Sangeetha G   */
/* date                 :  7-May-08                                               */
/* BugID      :  PNR2.0_17525        */
/* Modified for      : For Every Project setup, a constant hidden edit control is added */
/************************************************************************************************/
/* modified by     :  Gopinath S                                                 */
/* date             :  06-oct-08                                               */
/* BugID      :  PNR2.0_19524              */
/****************************************************************************************/
/* modified by     :  SIVAKUMAR S                                               */
/* date              :  24-APR-08                                          */
/* BugID      :  PNR2.0_22079       */
/* BugDescription   :  The formal parameter "@extnjs_in" was not declared as an OUTPUT */
/*        parameter, but the actual parameter passed in requested output.*/
/*        above error thrown when i download a workrequest   */
/****************************************************************************************/
/* Modified By      : Sangeetha G               */
/* Date            : 05-May-2010             */
/* BugID       : PNR2.0_23541              */
/* Modified For      : To set UserPreference through frontend in spec Layout */
/********************************************************************************/
/* Modified By      : Chanheetha N A               */
/* Date            : 14-May-2010             */
/* BugID       : PNR2.0_26860              */
/* Modified For      : Extra column to specify freezecount                   */
/***************************************************************************************************/
/* modified by  : Ganesh Prabhu S                                      						       */
/* date         : Oct 10 2014                                      							       */
/* BugId        : PLF2.0_09035                                          						   */
/* description  : Model changes for rowspan,colspan,IsStatic,IsCallout in  layout level            */
/***************************************************************************************************/
/* Modified by  : Veena U                                                  */
/* Date         : 25-Feb-2015                                                  */
/* Call ID		: PLF2.0_11499                                                 */
/****************************************************************************************************************/
/* Modified by : Jeya Latha K/Ganesh Prabhu S	Defect ID: TECH-7349 	Date: 14-03-2017						*/
/* Modified on : 14-03-2017				 																		*/
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and New Feature Organization chart */
/* Modified by : Jeya Latha K					Date: 25-Jul-2019		Defect ID: TECH-36371					*/
/* Modified by : Rajeswari M/Priyadharshini U   Date: 28-Jul-2021       Defect ID : TECH-60451					*/
/* TECH-60451  : Launching Help&Link UIs, Popup sections and Grid Extensions in Side Drawer						*/
/****************************************************************************************************************/
/* Modified by	:	Priyadharshini U 											*/
/* Modified on	:	08/06/22				 									*/
/* Defect ID	:	TECH-69624													*/
/* Description	:	Custom border, Custom actions and Responsive layout			*/
/********************************************************************************/
/* Modified by	:	Ponmalar A		 											*/
/* Modified on	:	08/07/2022				 									*/
/* Defect ID	:	Tech-70687													*/
/* Description	:	Tool and Toolbars											*/
/********************************************************************************/
/* Modified by	:	Priyadharshini U / Ponmalar A								*/
/* Modified on	:	22/08/22				 									*/
/* Defect ID	:	TECH-72114													*/
/********************************************************************************/
/* Modified by : Ponmalar A		Date: 02-Dec-2022	Defect ID : TECH-75230		*/
/********************************************************************************/
CREATE PROCEDURE ep_hdn_sec_ctrl_insert
	@ctxt_language engg_ctxt_language,
	@ctxt_ouinstance engg_ctxt_ouinstance,
	@ctxt_service engg_ctxt_service,
	@ctxt_user engg_ctxt_user,
	@engg_customer_name engg_name,
	@engg_project_name engg_name,
	@engg_base_req_no engg_name,
	@process_name engg_name,
	@component_name engg_name,
	@activity_name engg_name,
	@ui_name engg_name,
	@req_no_tmp engg_name,
	@m_errorid INT OUTPUT
AS
BEGIN
	SET NOCOUNT ON

	DECLARE @bt_synonym_name engg_name,
		@page_prefix_tmp engg_name,
		@max_horder engg_length,
		@engg_cont_page_bts engg_name,
		@hdn_ctrl_type engg_name,
		@control_id_tmp engg_name,
		@control_id engg_name,
		--   @view_name  engg_name,  
		@count engg_name,
		@ui_pfx_tmp engg_name,
		@bt_caption engg_description,
		@Sec_CollapseMode Engg_name,
		@Engg_cont_Ctrlimg Engg_name

	SELECT @m_errorid = 0

	--  declare ui_cur cursor for  
	--  select distinct  
	--    process_name, component_name, activity_name, ui_name  
	--  from ep_ui_req_dtl (nolock)  
	--  where customer_name  = @engg_customer_name  
	--  and  project_name  = @engg_project_name  
	--  and  req_no    = @engg_base_req_no  
	--  and  ui_name    <> ''  
	--  
	--  open ui_cur  
	--  while (1=1)  
	--  begin  
	--   fetch next from ui_cur  
	--   into @process_name , @component_name , @activity_name , @ui_name  
	--  
	--   if @@fetch_status <> 0  
	--    break  
	-- code commented For Bug ID :: PNR2.0_17525  starts  
	--   if exists (  
	--      select 'x'  
	--      from es_comp_hdn_ctrl_dtl (nolock)  
	--      where customer_name = @engg_customer_name  
	--      and project_name = @engg_project_name  
	--      and req_no  = @engg_base_req_no  
	--      and process_name = @process_name  
	--      and component_name = @component_name  
	--      )  
	--   begin -- if exists in comp_hdn_ctrl table  
	-- code commented For Bug ID :: PNR2.0_17525  ends  
	IF EXISTS (
			SELECT 'x'
			FROM ep_ui_section_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_base_req_no
				AND process_name = @process_name
				AND component_name = @component_name
				AND activity_name = @activity_name
				AND ui_name = @ui_name
				AND section_bt_synonym = 'PrjHdnSection'
			)
	BEGIN
		SELECT @engg_customer_name = @engg_customer_name
	END
	ELSE
	BEGIN
		EXEC ep_ui_section_dtl_sp_ins @ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			@engg_customer_name,
			@engg_project_name,
			@engg_base_req_no,
			@process_name,
			@component_name,
			@activity_name,
			@ui_name,
			'[mainscreen]',
			'PrjhdnSection',
			'N',
			'N',
			'N',
			'Left',
			'',
			100,
			1,
			'PrjhdnSection',
			1,
			'Main',
			'', -- Code Modfied For BugId : PNR2.0_7243  
			'',
			'',
			'',
			'',
			'',
			@Sec_CollapseMode,
			'',
			@req_no_tmp,
			'',
			'', --chan  
			'',
			'',
			'',
			'',
			'',
			'',
			'',
			'',
			'',
			'',	--Code added for TECH-69624
			'','','','','','',  --Tech-70687
			'',	--Tech-72114
			'',	--TECH-75230
			@m_errorid OUTPUT

		IF @m_errorid <> 0
			--     begin  
			--      close ui_cur  
			--      deallocate ui_cur  
			RETURN
				--     end  
	END

	DECLARE control_cur CURSOR
	FOR
	SELECT bt_synonym_name
	FROM es_comp_hdn_ctrl_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND req_no = @engg_base_req_no
		AND process_name = @process_name
		AND component_name = @component_name
	
	UNION
	
	SELECT 'Prj_hdn_ctrl' -- code added for Bug ID :: PNR2.0_17525  

	OPEN control_cur

	WHILE (1 = 1)
	BEGIN
		FETCH NEXT
		FROM control_cur
		INTO @bt_synonym_name

		IF @@fetch_status <> 0
			BREAK

		--code added by DNR for getting unique prefix ID on 30/12/2003  
		EXEC engg_gen_prefix_id @engg_customer_name,
			@engg_project_name,
			@component_name,
			@activity_name,
			@ui_name,
			@bt_synonym_name,
			'C',
			6,
			@page_prefix_tmp OUTPUT

		/*modified by shafina on 07-jan-2004 to pass Parameters component prefix and label control  
to common insert sp */
		--modifed by shafina on 09-jan-2004 to pass max(horder) and vorder  
		SELECT @max_horder = isnull(max(horder), 0) + 1
		FROM ep_ui_control_dtl(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND req_no = @engg_base_req_no
			AND process_name = @process_name
			AND component_name = @component_name
			AND activity_name = @activity_name
			AND ui_name = @ui_name
			AND section_bt_synonym = 'PrjHdnSection'

		SELECT @hdn_ctrl_type = ctrl_type_name
		FROM es_comp_ctrl_type_mst_vw(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND req_no = @engg_base_req_no
			AND process_name = @process_name
			AND component_name = @component_name
			AND base_ctrl_type = 'Edit'
			AND mandatory_flag = 'N'
			AND visisble_flag = 'N'
			AND editable_flag = 'N'
			AND caption_req = 'N'
			AND select_flag = 'N'
			AND zoom_req = 'N'
			AND insert_req = 'N'
			AND delete_req = 'N'
			AND help_req = 'N'
			AND event_handling_req = 'N'
			AND ellipses_req = 'N'
			AND visisble_rows = 0 -- uncommented on sep30  

		IF @hdn_ctrl_type IS NULL
			OR @hdn_ctrl_type = ''
		BEGIN
			-- COde Modified by Hamsika for the Fix Note : _DM_FN_098  
			EXEC es_comp_ctrl_type_mst_sp_ins @ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@engg_customer_name,
				@engg_project_name,
				@engg_base_req_no,
				@process_name,
				@component_name,
				'HiddenCtrlType',
				'HiddenCtrlType',
				'Edit',
				'N',
				'N',
				'N',
				0,
				'N',
				'N',
				'N',
				'N',
				'N',
				'N',
				'N',
				'N',
				'HiddenCtrlType',
				'left',
				'N',
				'left',
				'Left',
				'',
				-- COde Modified for the BUG ID : PNR2.0_22079 Starts  
				/* PNR2.0_11174 */ '',
				'N',
				'',
				'',
				'',
				'',
				'',
				1,
				'',
				'',
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT -- code modified by Gopinath S for the BugID PNR2.0_19524  

			-- COde Modified for the BUG ID : PNR2.0_22079 Ends  
			-- COde Modified for the Fix Note : _DM_FN_098  
			-- code modified by shafina on 27-May-2004 for PREVIEWENG203ACC_000067  
			-- Control Type for hidden controls are inserted incorectly in some cases.  
			-- modified by shafina on 14-jan-2004 to select @hdn_ctrl_type='hiddenctrltype'  
			SELECT @hdn_ctrl_type = 'hiddenctrltype'
		END

		-- To Generate Control ID/View Names for the newly inserted controls  
		--     select @engg_cont_page_bts = '[MAINSCREEN]'  
		-- code modified by shafina on 17-feb-2004 to CREATE generation of control_id and view_name  
		--     select @ui_pfx_tmp   = page_prefix  
		--     from ep_ui_page_dtl (nolock)  
		--     where  customer_name    = @engg_customer_name  
		--     and   project_name    = @engg_project_name  
		--     and     req_no       = @engg_base_req_no  
		--     and   process_name    = @process_name  
		--     and   component_name   = @component_name  
		--     and   activity_name    = @activity_name  
		--     and   ui_name       = @ui_name  
		--     and  page_bt_synonym  = '[mainscreen]'  
		-- code modified on shafina on 27-May-2004 for PREVIEWENG203ACC_000066  
		-- (controlids are getting duplicated in some cases.)  
		-- code modified by shafina on 12-Aug-2004 for PREVIEWENG203ACC_000085 - Control ID Generation Logic is changed.  
		EXEC ep_controlid_generation @engg_customer_name,
			@engg_project_name,
			@engg_base_req_no,
			@process_name,
			@component_name,
			@activity_name,
			@ui_name,
			@bt_synonym_name,
			'Edit',
			'N',
			'N',
			@control_id OUTPUT

		/*select @control_id_tmp  = max(control_id)  
from ep_ui_control_dtl (nolock)  
where  customer_name    = @engg_customer_name  
and   project_name    = @engg_project_name  
and     req_no       = @engg_base_req_no  
and   process_name    = @process_name  
and   component_name   = @component_name  
and   activity_name    = @activity_name  
and   ui_name       = @ui_name  
--     and  page_bt_synonym  = '[mainscreen]'  
--     and  section_bt_synonym = 'PrjHdnSection'  
  
select @control_id_tmp = right(isnull(@control_id_tmp,0) , 3)  
select @count   = @control_id_tmp + 1  
  
if len(@count) = 1  
begin  
select @control_id = @ui_pfx_tmp + '_' + '00' + @count  
end  
if len(@count) = 2  
begin  
select @control_id = @ui_pfx_tmp + '_' + '0' + @count  
end  
if len(@count) = 3  
begin  
select @control_id = @ui_pfx_tmp + '_' + @count  
end*/
		--     select @view_name = @ui_pfx_tmp + '_' + @count  
		IF EXISTS (
				SELECT 'x'
				FROM ep_ui_control_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @process_name
					AND component_name = @component_name
					AND activity_name = @activity_name
					AND ui_name = @ui_name
					AND page_bt_synonym = '[mainscreen]'
					AND section_bt_synonym = 'PrjHdnSection'
					AND control_bt_synonym = @bt_synonym_name
				)
		BEGIN
			SELECT @engg_customer_name = @engg_customer_name
		END
		ELSE
		BEGIN
			-- modified by shafina on 30-jan-2004 to insert control prefix correctly..  
			EXEC ep_ui_control_dtl_sp_ins @ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@engg_customer_name,
				@engg_project_name,
				@engg_base_req_no,
				@process_name,
				@component_name,
				@activity_name,
				@ui_name,
				'[mainscreen]',
				'PrjhdnSection',
				@bt_synonym_name,
				@control_id,
				/*@control_id,   */ @hdn_ctrl_type,
				0,
				@max_horder,
				1,
				1,
				0,
				0,
				'',
				'',
				@bt_synonym_name,
				@page_prefix_tmp,
				-- code modified by shafina on 22-Dec-2004 for  PREVIEWENG203ACC_000116 (In control_dtl table, label_column_scalemode and data_column_scalemode are added.)  
				'',
				'',
				'',
				'',
				'',
				'',
				'',
				'',
				'',
				1,
				@req_no_tmp,
				'Y',
				0,
				@Engg_cont_Ctrlimg,
				'',
				'',
				'',
				'',
				'',
				--modified by Ranjitha
				'',
				'',
				'',
				'',
				'',
				'',
				'',---Code added for TECH-60451
				'',--code added for TECH-63527
				'',--Code added for TECH-69624
				'',	--Code added for TECH-72114
				'','', --TECH-75230
				@m_errorid OUTPUT --chan      --modified for PNR2.0_23541 --added for PNR2.0_26860     -- nov 2016

			IF @m_errorid > 0
			BEGIN
				CLOSE control_cur

				DEALLOCATE control_cur

				CLOSE ui_cur

				DEALLOCATE ui_cur

				RETURN
			END

			-- code modified by shafina on 16-apr-2004 for REENG203SYS_000002  
			IF NOT EXISTS (
					SELECT 'x'
					FROM ep_component_glossary_mst NOLOCK
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_base_req_no
						AND process_name = @process_name
						AND component_name = @component_name
						AND bt_synonym_name = @bt_synonym_name
					)
			BEGIN
				EXEC ep_generate_caption @bt_synonym_name,
					@bt_caption OUTPUT

				-- code modified by shafinaon 21-June-2004 for PREVIEWENG203SYS_000104 -- Formal parameter error.  
				EXEC ep_component_glossary_mst_sp_ins @ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@engg_customer_name,
					@engg_project_name,
					@engg_base_req_no,
					@process_name,
					@component_name,
					@bt_synonym_name,
					NULL,
					'Char',
					20,
					@bt_caption,
					@bt_synonym_name,
					'',
					'U',
					'',
					'',
					1,
					@req_no_tmp,
					@m_errorid OUTPUT --chan  

				IF @m_errorid <> 0
				BEGIN
					CLOSE control_cur

					DEALLOCATE control_cur

					CLOSE ui_cur

					DEALLOCATE ui_cur

					RETURN
				END
			END
		END
	END

	CLOSE control_cur

	DEALLOCATE control_cur

	--  end -- end of if exists in comp_hdn_ctrl table  (-- commented  For Bug ID :: PNR2.0_17525)  
	--  end  
	--  close ui_cur  
	--  deallocate ui_cur  
	--  Code added for Bug ID :: PNR2.0_17525 starts  
	IF NOT EXISTS (
			SELECT 'x'
			FROM ES_BUSINESS_TERM(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND isnull(bt_name, '') = 'plf_hdn_ctrl_bt'
			)
	BEGIN
		EXEC ES_BUSINESS_TERM_SP_INS @ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			@engg_customer_name,
			@engg_project_name,
			'plf_hdn_ctrl_bt',
			'plf_hdn_ctrl_bt',
			'char',
			20,
			NULL,
			1,
			@m_errorid OUTPUT
	END

	IF EXISTS (
			SELECT 'x'
			FROM ep_component_glossary_mst(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @process_name
				AND component_name = @component_name
				AND bt_synonym_name = 'Prj_hdn_ctrl'
				AND isnull(bt_name, '') = ''
			)
	BEGIN
		UPDATE ep_component_glossary_mst
		SET bt_name = 'plf_hdn_ctrl_bt',
			data_type = 'char',
			length = 20
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND process_name = @process_name
			AND bt_synonym_name = 'Prj_hdn_ctrl'
	END

	--IF EXISTS (
	--		SELECT 'x'
	--		FROM ep_component_glossary_mst_lng_extn(NOLOCK)
	--		WHERE customer_name = @engg_customer_name
	--			AND project_name = @engg_project_name
	--			AND process_name = @process_name
	--			AND component_name = @component_name
	--			AND bt_synonym_name = 'Prj_hdn_ctrl'
	--			AND isnull(bt_name, '') = ''
	--		)
	--BEGIN
	--	UPDATE ep_component_glossary_mst_lng_extn
	--	SET bt_name = 'plf_hdn_ctrl_bt',
	--		data_type = 'char',
	--		length = 20
	--	WHERE customer_name = @engg_customer_name
	--		AND project_name = @engg_project_name
	--		AND process_name = @process_name
	--		AND component_name = @component_name
	--		AND bt_synonym_name = 'Prj_hdn_ctrl'
	--END

	--  Code added for Bug ID :: PNR2.0_17525 ends  
	SET NOCOUNT OFF
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME= 'ep_hdn_sec_ctrl_insert' AND TYPE='P')
BEGIN
	GRANT EXEC ON  ep_hdn_sec_ctrl_insert TO PUBLIC
END
GO