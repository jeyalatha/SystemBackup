IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_systemdefined_controls_ins_sp' AND TYPE = 'P')
BEGIN
	DROP PROC ep_systemdefined_controls_ins_sp
END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		ep_systemdefined_controls_ins_sp.sql
********************************************************************************/
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	15 Dec 2017
Purpose 		ep_systemdefined_controls_ins_sp.sql
*********************************************************************************************/
/* Created by : Ganesh Prabhu S/Ranjitha R      for callid  TECH-10118                   */
/* Created on : 30-May-2017                                                                                        */
/* Description : Platform Feature Release                                                              */
/********************************************************************************/
/* Modified by : Ranjitha R      for callid  TECH-16126                   */
/* Modified on : 21-Nov-2017                                                                                        */
/* Description : Platform Feature Release                                                              */
/***************************************************************************************/
/* Modified by  : JeyaLatha K	Date: 31-Jan-2018  Defect ID : TECH-18349			   */
/* Modified by  : JeyaLatha K	Date: 20-Jun-2019  Defect ID : TECH-35098			   */
/* Modified by : Jeya Latha K   Date: 25-Jul-2019  Defect ID: TECH-36371			   */
/* Modified by : Jeya Latha K   Date: 14-May-2020  Defect ID: TECH-46135			   */
/* Modified by : Rajeswari M/Priyadharshini U Date: 28-Jul-2021  Defect ID : TECH-60451*/
/* TECH-60451  : Launching Help&Link UIs, Popup sections and Grid Extensions in Side Drawer*/
/****************************************************************************************/
/* Modified by	:	Ponmalar A		 													*/
/* Modified on	:	08/07/2022				 											*/
/* Defect ID	:	Tech-70687															*/
/* Description	:	Tool and Toolbars													*/
/****************************************************************************************/
/* Modified by	:	Priyadharshini U / Ponmalar A 										*/
/* Modified on	:	26/07/2022				 											*/
/* Defect ID	:	TECH-71262															*/
/****************************************************************************************/
/* Modified by : Jeya Latha K Date: 28-Jul-2022  Defect ID : TECH-71109					*/  
/****************************************************************************************/  
/* Modified by : Ponmalar A / Priyadharshini U Date: 24-Aug-2022  Defect ID : TECH-72114*/  
/****************************************************************************************/
/* Modified by : Ponmalar A					  Date: 07-Dec-2022   Defect ID : TECH-75230*/  
/****************************************************************************************/
Create PROCEDURE ep_systemdefined_controls_ins_sp
	@ctxt_OUInstance engg_ctxt_OUInstance,
	@ctxt_User engg_ctxt_User,
	@ctxt_Language engg_ctxt_Language,
	@ctxt_Service engg_ctxt_Service,
	@engg_customer_name engg_name,
	@engg_project_name engg_name,
	@engg_process_name engg_name,
	@engg_component_name engg_name,
	@engg_activity_name engg_name,
	@engg_ui_name engg_name,
	@engg_req_no engg_name,
	@engg_page_name engg_name,
	@engg_section_name engg_name,
	@engg_control_name engg_name,
	@engg_controlid engg_name,
	@engg_ui_type engg_name,
	@engg_section_type engg_name,
	@engg_control_type engg_name,
	@engg_basecontrol_type engg_name,
	@engg_renderas engg_name,
	@modeflag engg_modeflag,
	@engg_wrkreq_no engg_name,
	@PaginatationReqd		engg_flag,
	@UpdateTaskReqd			engg_flag,
	@DeleteTaskReqd			engg_flag,
	@m_errorid INT OUTPUT
AS
BEGIN
	SET NOCOUNT ON

	DECLARE @VISISBLE_FLAG_IN engg_flag,
		@TITLE_REQUIRED_IN engg_flag,
		@BORDER_REQUIRED_IN engg_flag,
		@TITLE_ALIGNMENT_IN engg_name,
		@PARENT_SECTION_IN engg_name,
		@HORDER_IN engg_seqno,
		@VORDER_IN engg_seqno,
		@SECTION_DOC_IN engg_documentation,
		@ENGG_SECTION_TYPE_IN engg_name,
		@engg_sec_cap_align engg_name,
		@engg_sec_cap_format engg_flag,
		@sectionheight engg_seqno,
		@sectionwidth engg_seqno,
		@Section_width_Scalemode engg_name,
		@Section_height_Scalemode engg_name,
		@Sec_CollapseMode engg_name,
		@Sec_Collapse engg_name,
		@section_rowspan engg_seqno,
		@section_colspan engg_seqno,
		@Region engg_flag,
		@TitlePosition engg_code,
		@CollapseDir engg_code,
		@SectionLayout engg_flag,
		@XYCoordinates engg_description,
		@ColumnLayWidth engg_description,
		@engg_associatedcontrol engg_name,
		@VISISBLE_LENGTH_IN engg_seqno,
		@ORDER_SEQ_IN engg_seqno,
		@DATA_COLUMN_WIDTH_IN engg_seqno,
		@LABEL_COLUMN_WIDTH_IN engg_seqno,
		@CONTROL_PREFIX_IN engg_name,
		@page_prefix_tmp	engg_name, -- Added for TECH-46135
		@quickcode_tmp	engg_name,
		@controldoc_tmp	engg_description,
		@PrimaryControlBT	engg_name,
		@engg_control_name_tmp	engg_name

	SELECT @VISISBLE_FLAG_IN = 'n',
		@TITLE_REQUIRED_IN = 'n',
		@BORDER_REQUIRED_IN = 'n',
		@TITLE_ALIGNMENT_IN = 'Left',
		@PARENT_SECTION_IN = '',
		@HORDER_IN = 1,
		@VORDER_IN = 1,
		@SECTION_DOC_IN = @engg_section_name,
		@ENGG_SECTION_TYPE_IN = 'Main',
		@engg_sec_cap_align = 'Center',
		@engg_sec_cap_format = 'bes',
		@sectionheight = 0,
		@sectionwidth = 100,
		@Section_width_Scalemode = '%',
		@Section_height_Scalemode = NULL,
		@Sec_CollapseMode = 'NON',
		@Sec_Collapse = 'N',
		@section_rowspan = NULL,
		@section_colspan = NULL,
		@Region = NULL,
		@TitlePosition = 'Top',
		@CollapseDir = '',
		@SectionLayout = 'Table',
		@XYCoordinates = NULL,
		@ColumnLayWidth = NULL,
		@engg_associatedcontrol = NULL,
		@VISISBLE_LENGTH_IN = NULL,
		@ORDER_SEQ_IN = 1,
		@DATA_COLUMN_WIDTH_IN = - 915,
		@LABEL_COLUMN_WIDTH_IN = - 915,
		@CONTROL_PREFIX_IN = '',
		@controldoc_tmp	= ''

	-- Added for TECH-46646 
	--SELECT @PrimaryControlBT	=	@engg_control_name
	SELECT @engg_control_name_tmp		= @engg_control_name -- Added for TECH-71109
	
	DECLARE @seq_no engg_seqno,
		@ViewCode engg_name,
		@ViewName engg_name,
		@ViewCaption engg_name,
		@control_type engg_name,
		@Remarks engg_documentation,
		@AccessKey engg_flag,
		@Icon_class engg_name,
		@icon_position engg_name,
		@Cont_class_ext6 engg_name,
		@prefix engg_name,
		@tasktype engg_name,
		@events_desc engg_name

	IF isnull(@engg_ui_type, '') <> ''
		SELECT @engg_control_type = @engg_ui_type
	ELSE IF isnull(@engg_section_type, '') <> ''
		SELECT @engg_control_type = @engg_section_type
	ELSE
		SELECT @engg_control_type = @engg_control_type
	IF @engg_control_type = 'MobileGrid'
	BEGIN
		DECLARE systemdefined_cur CURSOR FAST_FORWARD
		FOR
		SELECT ViewCode,
			ViewName,
			ViewCaption,
			control_type,
			prefix,
			seq_no
		FROM ep_systemdefined_views(NOLOCK)
		WHERE CreatedFor	= @engg_control_type
		AND		ViewName	<> 'PagGrid'
		--AND		ViewName	NOT IN ('Pagtask', 'PagGrid')
		ORDER BY seq_no
	END
	ELSE
	-- Added for TECH-46646 Starts
	BEGIN
		DECLARE systemdefined_cur CURSOR FAST_FORWARD
		FOR
		SELECT ViewCode,
			ViewName,
			ViewCaption,
			control_type,
			prefix,
			seq_no
		FROM ep_systemdefined_views(NOLOCK)
		WHERE CreatedFor = @engg_control_type
		ORDER BY seq_no
	END
	-- Added for TECH-46646 Ends

	OPEN systemdefined_cur

	FETCH NEXT	FROM systemdefined_cur	INTO @ViewCode,		@ViewName,		@ViewCaption,		@control_type,
							@prefix,	@seq_no

	WHILE @@FETCH_STATUS = 0
		BEGIN						
	
		IF isnull(@ViewCode, '') = 'Section'
		BEGIN
			IF NOT EXISTS (
					SELECT 'x'
					FROM ep_ui_section_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = 'BASE'
						AND process_name = @engg_process_name
						AND component_name = @engg_component_name
						AND activity_name = @engg_activity_name
						AND ui_name = @engg_ui_name
						AND page_bt_synonym = @engg_page_name
						AND section_bt_synonym = @ViewCaption
					)
			BEGIN
				EXEC EP_UI_SECTION_DTL_SP_INS @ctxt_Language,
					@ctxt_OUInstance,
					@ctxt_Service,
					@ctxt_User,
					@engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@engg_process_name,
					@engg_component_name,
					@engg_activity_name,
					@engg_ui_name,
					@engg_page_name,
					@ViewCaption,
					@VISISBLE_FLAG_IN,
					@TITLE_REQUIRED_IN,
					@BORDER_REQUIRED_IN,
					@TITLE_ALIGNMENT_IN,
					@PARENT_SECTION_IN,
					@HORDER_IN,
					@VORDER_IN,
					@SECTION_DOC_IN,
					1,
					@control_type,
					@engg_sec_cap_align,
					@engg_sec_cap_format,
					@sectionheight,
					@sectionwidth,
					'%', --@Section_width_Scalemode,
					NULL, --@Section_height_Scalemode,
					@Sec_CollapseMode,
					'N', --@Sec_Collapse,
					@engg_wrkreq_no,
					0, --@section_rowspan,
					0, -- @section_colspan,
					NULL, --@Region,
					'Top', --@TitlePosition,
					'', --@CollapseDir,
					'Table', --@SectionLayout,
					NULL, --@XYCoordinates,
					NULL, --@ColumnLayWidth,
					NULL, --@engg_associatedcontrol,
					'',--FullView
					'',--IsResponsive
					'',
					'','','','','','', --Tech-70687
					'',	--Tech-72114
					@m_errorid OUTPUT

				IF NOT EXISTS (
						SELECT 's'
						FROM EP_COMPONENT_GLOSSARY_MST
						WHERE CUSTOMER_NAME = @engg_customer_name
							AND PROJECT_NAME = @engg_project_name
							AND REQ_NO = 'base'
							AND PROCESS_NAME = @engg_process_name
							AND COMPONENT_NAME = @engg_component_name
							AND BT_SYNONYM_NAME = @ViewCaption
						)
				BEGIN
					EXEC EP_COMPONENT_GLOSSARY_MST_SP_INS @ctxt_Language,
						@ctxt_OUInstance,
						@ctxt_Service,
						@ctxt_User,
						@engg_customer_name,
						@engg_project_name,
						'base',
						@engg_process_name,
						@engg_component_name,
						@ViewCaption,
						NULL,
						'Char',
						20,
						@ViewCaption,
						@ViewCaption,
						'',
						'U',
						'',
						'',
						1,
						@engg_req_no,
						@M_ERRORID OUTPUT
				END
			END
		END
		ELSE IF isnull(@ViewCode, '') = 'Control'
		BEGIN
			-- code added for callid TECH-16126
			IF isnull(@engg_control_type, '') = 'MobileGrid' -- code added for Defect ID : TECH-18349 
			BEGIN
				

				IF ISNULL(@engg_section_name, '') = 'mstd_tracker_sec'
					AND isnull(@control_type, '') = 'Grid'
				BEGIN
					SELECT @engg_control_name = 'mstd_tracker_ctrl'

					SELECT @ViewCaption = 'Geo Tracker Grid'
				END
						--ELSE IF	ISNULL(@engg_section_name,'')	= 'mstd_tracker_st_sec' and isnull(@control_type,'') = 'Grid'
						--BEGIN
						--	SELECT	@engg_control_name	= 'mstd_tracker_st_ctrl'
						--	SELECT	@ViewCaption		= 'Geo Track Start Grid'
						--END
				ELSE IF ISNULL(@engg_section_name, '') = 'mstd_geofence_sec'
					AND isnull(@control_type, '') = 'Grid'
				BEGIN
					SELECT @engg_control_name = 'mstd_geofence_ctrl'

					SELECT @ViewCaption = 'Geo Fence Grid'
				END
				ELSE --IF isnull(@control_type,'') = 'Grid' and ISNULL(@engg_section_name,'') NOT IN ('mstd_tracker_sp_sec', 'mstd_tracker_st_sec', 'mstd_geofence_sec')
				BEGIN
					SELECT @engg_control_name = section_prefix + '_' + @ViewName
					FROM ep_ui_section_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = 'BASE'
						AND process_name = @engg_process_name
						AND component_name = @engg_component_name
						AND activity_name = @engg_activity_name
						AND ui_name = @engg_ui_name
						AND page_bt_synonym = @engg_page_name
						AND section_bt_synonym = @engg_section_name
				END

				SELECT @CONTROL_PREFIX_IN = @prefix

				SELECT @VORDER_IN = @seq_no
			END

			 --code ends
			IF NOT EXISTS (
					SELECT 'x'
					FROM ep_ui_control_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = 'BASE'
					AND process_name = @engg_process_name
					AND component_name = @engg_component_name
					AND activity_name = @engg_activity_name
					AND ui_name = @engg_ui_name
					AND page_bt_synonym = @engg_page_name
					AND section_bt_synonym = @engg_section_name
					AND control_bt_synonym = @engg_control_name
					)
			BEGIN -- ep_ui_control_dtl if starts
				IF isnull(@engg_control_type, '') = 'Dashboard'
				BEGIN
					SELECT @engg_control_type = 'HiddenEdit'

					SELECT @CONTROL_PREFIX_IN = 'RVFCon'
				END
						-- code added for callid TECH-16126
				ELSE IF isnull(@engg_control_type, '') = 'MobileGrid' -- code added for Defect ID : TECH-18349 
				BEGIN
					IF isnull(@control_type, '') = 'Edit'
					BEGIN
						SELECT @control_type = 'HiddenEdit'

						SELECT @engg_controlid = 'TXT' + @engg_control_name
					END
					ELSE IF isnull(@control_type, '') = 'Grid'
					BEGIN
						--SELECT @control_type = 'Grid5SID'
						--SELECT @control_type = 'islistmobile' --to  check
						SELECT @engg_controlid = 'ML' + @engg_control_name
						SELECT @controldoc_tmp = 'New Mobile Grid' --Added May2020
					END
					ELSE IF isnull(@control_type, '') = 'Button'
					BEGIN
						SELECT @control_type = 'Button'

						SELECT @engg_controlid = 'BTN' + @engg_control_name
						SELECT @PrimaryControlBT = @engg_control_name
					END
				END

				-- To get the prefix Added for TECH-46135
				exec engg_gen_prefix_id 
								@engg_customer_name,	@engg_project_name,		@engg_component_name,		@engg_activity_name,		
								@engg_ui_name,	@engg_control_name,		'C',		6,						@page_prefix_tmp output  

				-- code end
				EXEC EP_UI_CONTROL_DTL_SP_INS 
					@ctxt_Language,
					@ctxt_OUInstance,
					@ctxt_Service,
					@ctxt_User,
					@engg_customer_name,
					@engg_project_name,
					@engg_req_no,
					@engg_process_name,
					@engg_component_name,
					@engg_activity_name,
					@engg_ui_name,
					@engg_page_name,
					@engg_section_name,
					@engg_control_name,
					@engg_controlid,
					@control_type,
					@VISISBLE_LENGTH_IN,
					@HORDER_IN,
					@VORDER_IN,
					@ORDER_SEQ_IN,
					@DATA_COLUMN_WIDTH_IN,
					@LABEL_COLUMN_WIDTH_IN,
					NULL, --'PROTO_TOOLTIP_IN',
					NULL, --'SAMPLE_DATA_IN',
					@controldoc_tmp, --NULL, --'CONTROL_DOC_IN',
					@page_prefix_tmp,--@CONTROL_PREFIX_IN,-- Changed for TECH-46135
					'', --'LABEL_CONTROL_ID_IN',
					NULL, --'label_column_scalemode_in',
					NULL, --'data_column_scalemode_in',
					NULL, --'engg_label_class_in',
					NULL, --'engg_control_class_in',
					NULL, --'engg_label_image_class_in',
					NULL, --'engg_control_image_class_in',
					0, --'engg_tab_sequence_in',
					0, --'engg_tab_stopforhelp_in',
					1,
					@engg_wrkreq_no,
					'Y', --'user_pref',
					NULL, --'freezecount',
					NULL, --'Engg_cont_Ctrlimg',
					0, --'Engg_cont_rowspan',
					0, --'Engg_cont_colspan',
					NULL, --'engg_cont_tempid',
					NULL, --'ctrl_temp_cat',
					NULL, --'ctrl_temp_specific',
					@AccessKey,
					@Icon_class,
					@Icon_position,
					@Cont_class_ext6,
					NULL,
					NULL,
					'',---Code added for TECH-60451
					'',	--TECH-71262
					'',	--TECH-71262
					'',	--Tech-72114
					'','', --TECH-75230
					@m_errorid OUTPUT

				IF NOT EXISTS (
						SELECT 's'
						FROM EP_COMPONENT_GLOSSARY_MST
						WHERE CUSTOMER_NAME = @engg_customer_name
							AND PROJECT_NAME = @engg_project_name
							AND REQ_NO = 'base'
							AND PROCESS_NAME = @engg_process_name
							AND COMPONENT_NAME = @engg_component_name
							AND BT_SYNONYM_NAME = @engg_control_name
						)
				BEGIN
					EXEC EP_COMPONENT_GLOSSARY_MST_SP_INS @ctxt_Language,
						@ctxt_OUInstance,
						@ctxt_Service,
						@ctxt_User,
						@engg_customer_name,
						@engg_project_name,
						'base',
						@engg_process_name,
						@engg_component_name, --@ViewCaption
						@engg_control_name,
						NULL,
						'Char', --2000
						60,
						@ViewCaption,
						@ViewCaption,
						'',
						'U',
						'',
						'',
						1,
						@engg_req_no,
						@m_errorid OUTPUT
				END
			END-- ep_ui_control_dtl if Ends
		END -- Else if section, control Ends
		
		
	

	FETCH NEXT	FROM systemdefined_cur	INTO @ViewCode,		@ViewName,		@ViewCaption,		@control_type,
							@prefix,	@seq_no

	END

	CLOSE systemdefined_cur

	DEALLOCATE systemdefined_cur

	-- Added for TECH-46646 Starts
	--IF ISNULL(@PaginatationReqd, 'N') = 'Y'	-- Commented for TECH-71109
	--BEGIN
	
		--SELECT @events_desc = 'Pagination Event for Mobility'
		SELECT @events_desc = 'Pagination Event for ' + ISNULL(@engg_control_name_tmp, '') -- Added for TECH-71109
		SELECT @tasktype = 'Trans' 

		IF NOT EXISTS ( SELECT 'X'
		FROM	es_ctrl_type_events_mst (nolock)
		WHERE	customer_name	=	@engg_customer_name
		AND		project_name	=	@engg_project_name
		AND		req_no			=	'Base'
		AND		process_name	=	@engg_process_name
		AND		component_name	=	@engg_component_name
		AND		ctrl_type_name	=	@engg_control_type
		AND		events_desc		=	@events_desc
		)
		BEGIN
			INSERT INTO es_ctrl_type_events_mst 
					(customer_name,		project_name,		req_no,			process_name,				component_name,
					ctrl_type_name,		base_ctrl_type,		events_desc,	events_required,			tasktype
					)
			SELECT 
					@engg_customer_name,@engg_project_name,		'Base',			@engg_process_name,		@engg_component_name,
					@engg_control_type,	@engg_basecontrol_type,	@events_desc,	'Y',					@tasktype
		END			

		EXEC ep_layout_save_events_gen @ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			@engg_customer_name,
			@engg_project_name,
			@engg_process_name,
			@engg_component_name,
			@engg_activity_name,
			@engg_ui_name,
			@engg_page_name,
			@engg_section_name,
			@PrimaryControlBT,--@engg_control_name,   -- Changed for TECH-71109
			'BASE',
			'mobilegrid',--@engg_basecontrol_type,
			@events_desc,--'mobilegrid',
			'','', --TECH-75230
			@m_errorid OUTPUT

	--END
		
	IF ISNULL(@UpdateTaskReqd, 'N') = 'Y'
	BEGIN
	--select 'tt1', @PrimaryControlBT
		SELECT @events_desc = 'AssociatedUpdateTask'
		SELECT @tasktype	= 'Trans'
		IF NOT EXISTS ( SELECT 'X'
		FROM	es_ctrl_type_events_mst (nolock)
		WHERE	customer_name	=	@engg_customer_name
		AND		project_name	=	@engg_project_name
		AND		req_no			=	'Base'
		AND		process_name	=	@engg_process_name
		AND		component_name	=	@engg_component_name
		AND		ctrl_type_name	=	@engg_control_type
		AND		events_desc		=	@events_desc
		)
		BEGIN
			INSERT INTO es_ctrl_type_events_mst 
					(customer_name,		project_name,		req_no,			process_name,				component_name,
					ctrl_type_name,		base_ctrl_type,		events_desc,	events_required,			tasktype
					)
			SELECT 
					@engg_customer_name,@engg_project_name,		'Base',			@engg_process_name,		@engg_component_name,
					@engg_control_type,	@engg_basecontrol_type,	@events_desc,	'Y',					@tasktype
		END			

		EXEC ep_layout_save_events_gen @ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			@engg_customer_name,
			@engg_project_name,
			@engg_process_name,
			@engg_component_name,
			@engg_activity_name,
			@engg_ui_name,
			@engg_page_name,
			@engg_section_name,
			@PrimaryControlBT,--@engg_control_name,   -- Changed for TECH-71109
			'BASE',
			'mobilegrid',--@engg_basecontrol_type,
			@events_desc,--'mobilegrid',
			@m_errorid OUTPUT

	END
	IF ISNULL(@DeleteTaskReqd, 'N') = 'Y'
	BEGIN
	
		SELECT @events_desc = 'AssociatedDeleteTask'
		SELECT @tasktype	= 'Trans'
		IF NOT EXISTS ( SELECT 'X'
		FROM	es_ctrl_type_events_mst (nolock)
		WHERE	customer_name	=	@engg_customer_name
		AND		project_name	=	@engg_project_name
		AND		req_no			=	'Base'
		AND		process_name	=	@engg_process_name
		AND		component_name	=	@engg_component_name
		AND		ctrl_type_name	=	@engg_control_type
		AND		events_desc		=	@events_desc
		)
		BEGIN

			INSERT INTO es_ctrl_type_events_mst 
					(customer_name,		project_name,		req_no,			process_name,				component_name,
					ctrl_type_name,		base_ctrl_type,		events_desc,	events_required,			tasktype
					)
			SELECT 
					@engg_customer_name,@engg_project_name,		'Base',			@engg_process_name,		@engg_component_name,
					@engg_control_type,	@engg_basecontrol_type,	@events_desc,	'Y',					@tasktype
		END			

		EXEC ep_layout_save_events_gen @ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			@engg_customer_name,
			@engg_project_name,
			@engg_process_name,
			@engg_component_name,
			@engg_activity_name,
			@engg_ui_name,
			@engg_page_name,
			@engg_section_name,
			@PrimaryControlBT,--@engg_control_name,  -- Changed for TECH-71109
			'BASE',
			'mobilegrid',--@engg_basecontrol_type,
			@events_desc,--'mobilegrid',
			@m_errorid OUTPUT

	END
	-- Added for TECH-46646  Ends

				-- code added for callid TECH-16126
		--IF isnull(@control_type, '') IN ('GRID5SID', 'Button' ) -- Commented since mobile grid creates more than one task
		--BEGIN
			--IF EXISTS (
			--		SELECT 'x'
			--		FROM es_ctrl_type_events_met(NOLOCK)
			--		WHERE base_ctrl_type = 'MobileGrid'
			--		) -- code added for Defect ID : TECH-18349
			--BEGIN
			
				--SELECT @tasktype = tasktype,
				--	@events_desc = events_desc
				--FROM es_ctrl_type_events_met(NOLOCK)
				--WHERE base_ctrl_type = @engg_control_type
			
				--IF NOT EXISTS (
				--		SELECT 'x'
				--		FROM es_ctrl_type_events_mst(NOLOCK)
				--		WHERE customer_name = @engg_customer_name
				--			AND project_name = @engg_project_name
				--			AND req_no = 'base'
				--			AND process_name = @engg_process_name
				--			AND component_name = @engg_component_name
				--			AND ctrl_type_name = @control_type
				--		)
				--BEGIN
			
					--INSERT INTO es_ctrl_type_events_mst (
					--	customer_name,
					--	project_name,
					--	req_no,
					--	process_name,
					--	component_name,
					--	ctrl_type_name,
					--	base_ctrl_type,
					--	events_desc,
					--	events_required,
					--	tasktype
					--	)
					--SELECT (
					--	@engg_customer_name,
					--	@engg_project_name,
					--	'Base',
					--	@engg_process_name,
					--	@engg_component_name,
					--	@control_type,
					--	@control_type,
					--	@events_desc,
					--	'Y',
					--	@tasktype )
						
					--INSERT INTO es_ctrl_type_events_mst (
					--	customer_name,
					--	project_name,
					--	req_no,
					--	process_name,
					--	component_name,
					--	ctrl_type_name,
					--	base_ctrl_type,
					--	events_desc,
					--	events_required,
					--	tasktype
					--	)
					--SELECT 
					--	@engg_customer_name,
					--	@engg_project_name,
					--	'Base',
					--	@engg_process_name,
					--	@engg_component_name,
					--	CASE	WHEN met.quick_Code = 'Section' THEN 'Button'
					--			WHEN met.quick_Code = 'GRID' THEN 'GRID'
					--	END		'ctrl_type_name',
					--	--CASE	WHEN met.quick_Code = 'Section' THEN 'Button'
					--	--		WHEN met.quick_Code = 'GRID' THEN 'GRID'
					--	--END						'base_ctrl_type',
					--	'MobileGrid',
					--	met.events_desc,
					--	'Y',
					--	met.tasktype
						
					--FROM es_ctrl_type_events_met met (NOLOCK)
					--WHERE base_ctrl_type = 'mobilegrid'
					--AND NOT EXISTS (SELECT 'X'
					--				FROM	es_ctrl_type_events_mst (nolock)
					--				WHERE	customer_name	= @engg_customer_name
					--				AND		project_name	= @engg_project_name
					--				AND		process_name	= @engg_process_name
					--				AND		component_name	= @engg_component_name
					--				AND		base_ctrl_type	= 'mobilegrid'
					--				AND		events_desc		= met.events_desc
					--				)

					
				--EXEC ep_layout_save_events_gen @ctxt_language,
				--	@ctxt_ouinstance,
				--	@ctxt_service,
				--	@ctxt_user,
				--	@engg_customer_name,
				--	@engg_project_name,
				--	@engg_process_name,
				--	@engg_component_name,
				--	@engg_activity_name,
				--	@engg_ui_name,
				--	@engg_page_name,
				--	@engg_section_name,
				--	@engg_control_name,
				--	'BASE',
				--	@control_type,
				--	'mobilegrid',
				--	@m_errorid OUTPUT

			-- END
		
	

	------FETCH NEXT	FROM systemdefined_cur	INTO @ViewCode,		@ViewName,		@ViewCaption,		@control_type,
	------						@prefix,	@seq_no

	------END

	------CLOSE systemdefined_cur

	------DEALLOCATE systemdefined_cur

	SET NOCOUNT OFF
END
GO

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_systemdefined_controls_ins_sp' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON ep_systemdefined_controls_ins_sp TO PUBLIC
END
GO
