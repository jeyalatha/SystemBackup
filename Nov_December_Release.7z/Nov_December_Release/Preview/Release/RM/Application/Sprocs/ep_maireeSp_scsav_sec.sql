IF EXISTS(SELECT 'X' From SYSOBJECTS WHERE NAME ='ep_maireeSp_scsav_sec' AND TYPE='P')
   BEGIN
        DROP PROC ep_maireeSp_scsav_sec
   END
GO 
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		ep_maireeSp_scsav_sec.sql
********************************************************************************/
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	15 Dec 2017
Purpose 		ep_maireesp_scsav_sec.sql
********************************************************************************/
/* Procedure    : ep_maireeSp_scsav_sec                                         */
/* Description  :                                                               */
/********************************************************************************/
/* Project      :                                                               */
/* ECR          :                                                               */
/* Version      :                                                               */
/********************************************************************************/
/* Referenced   :                                                               */
/* Tables       :                                                               */
/********************************************************************************/
/* Development history                                                          */
/********************************************************************************/
/* Author       : Model Explorer                                                */
/* Date         : 22/Sep/2005                                                   */
/********************************************************************************/
/* Modification history                                                         */
/********************************************************************************/
/*modified by      Hamsika                                   */
/*modified date    25-Oct-2005                                 */
/*modified purpose      Platform_2.0.3.1_299(PDEV_274)                */
/********************************************************************************/
/* Modified by  : Ramanujam                                                     */
/* Date         : 08/Nov/2005                                                   */
/* Description  : Case ID : Platform_2.0.3.1_68 Case Desc : in specify       */
/*      layout->Specify tree layout->the ui task of node description          */
/*    combo and fetch task are not in sync.                        */
/********************************************************************************/
/* Modified by  : Chanheetha N A                                                */
/* Date         : 08/Feb/2006                                                   */
/* Bug ID       : PNR2.0_6125             */
/********************************************************************************/
/* Modified by  : Gowrisankar M             */
/* Date         : 22-Aug-2006                                                   */
/* Bug ID       : PNR2.0_9983             */
/********************************************************************************/
/* Modified by  : kiruthika R             */
/* Date         : 25-Aug-2006                                                   */
/* Bug ID       : PNR2.0_10027             */
/********************************************************************************/
/* Modified by  : Chanheetha N A                                                */
/* Date         : 25-May-2007                                                   */
/* Bug ID       : PNR2.0_13810             */
/********************************************************************************/
/* modified by   : Chanheetha N A    */
/* date    : 17-nov-2007     */
/* BugId   : PNR2.0_16023      */
/********************************************************************************/
/* modified by   : Balaji S     */
/* date    : 05-Dec-2007     */
/* BugId   : PNR2.0_16202      */
/********************************************************************************/
/* modified by   : Feroz       */
/* date     : 25-nov-2008         */
/* BugId    : PNR2.0_1790          */
/************************************************************************/
/* modified by : Jeya           */
/* date     : 07-jan-2009         */
/* BugId    : PNR2.0_20553          */
/************************************************************************/
/* modified by   : Feroz           */
/* date     : 19-jan-2009         */
/* BugId    : PNR2.0_20693          */
/************************************************************************/
/* modified by   : Feroz           */
/* date     : 20-jan-2009         */
/* BugId    : PNR2.0_20728          */
/************************************************************************/
/* modified by  : Gopinath S     */
/* date    : 13-Jan-2009     */
/* BugId   : PNR2.0_20603      */
/********************************************************************************/
/* modified by  : Feroz                                                */
/* date         : 04-Aug-2009                                                   */
/* Bug Id   : PNR2.0_2179             */
/* Description  : Phase 3 Features - ListEdit, AttachDocument, Image & DateHighlight */
/********************************************************************************/
/* modified by : Gowrisankar M             */
/* date  : 17-Sep-2009              */
/* BugId : PNR2.0_23902               */
/* Desc  : Fprowno to be incremented for modeflag "S"      */
/********************************************************************************/
/* modified by : Balaji D                 */
/* modified on : May 18 2011             */
/* Bug ID  : PNR2.0_31386                 */
/* Case Desc : Tree Grid Feature Enhancement.        */
/********************************************************************************/
/* modified by : Balaji D                 */
/* modified on : June 08 2011             */
/* Bug ID  : PNR2.0_31780                 */
/* Case Desc : Tree Grid Feature Enhancement.        */
/********************************************************************************/
/* modified by  : Muthupandi S            */
/* date         : 01-December-2011           */
/* Bug ID  : PNR2.0_34596             */
/* Description : Validation added to avoid adding a new section with the existing */
/*     section name across UI           */
/*********************************************************************************/
/* modified by  : Shakthi P             */
/* date         : 07-FEB-2014             */
/* Bug ID  : PLF2.0_07428             */
/* Description : Validation added to avoid adding a new section with the existing */
/*     section name across UI           */
/*********************************************************************************/
/* modified by  :	 Shakthi P             											*/
/* date         : 12-Mar-2014            										*/
/* Bug ID  		: PLF2.0_07805          										 */
/* Description 	: Changes for Section Level RowSpan, ColSpan, Filler Section - Control Level RowSpan    */
/*********************************************************************************/
/* modified by  	: Kanagavel A            											*/
/* date         	: 03/06/2014            										*/
/* Description 	: if  BTSynonym Name already exists for another Page or Section or control or Grid Control, display error message   */
/*********************************************************************************/
/* modified by  : Piranava T  			                                        */
/* date         : Oct 10 2014			                                        */
/* BugId        : PLF2.0_09035 			   */
/* description  : Model changes for rowspan,colspan,IsStatic,IsCallout in layout level */
/************************************************************************************/
/* Modified by  : Veena U             */
/* Date         : 25-Feb-2015                                                  */
/* Call ID		: PLF2.0_11499      */
/********************************************************************************/
/* Modified by  : Veena U	                                                  */
/* Date         : 07-Aug-2015                                                  */
/* Defect ID	: PLF2.0_14096                                                 */
/********************************************************************************/
/* Modified by  : Veena U                                                  */
/* Date         : 28-Mar-2016                                                 */
/* Call ID		: PLF2.0_17570                                               */
/********************************************************************************/
/* Modified by : Jeya Latha K/Ganesh Prabhu S	for callid TECH-7349				*/
/* Modified on : 14-03-2017				 											*/
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and New Feature Organization chart */
/***********************************************************************************/
/* Modified by : Ganesh Prabhu S/Ranjitha R      for callid  TECH-10118            */
/* Modified on : 30-May-2017                                                     */
/* Description : Platform Feature Release                                         */
/********************************************************************************/
/* Modified by : Ranjitha R      for callid  TECH-16126                   */
/* Modified on : 21-Nov-2017                                                    */
/* Description : Platform Feature Release                                       */
/********************************************************************************/
/* Modified by  : JeyaLatha K/Ranjitha R	Date: 31-Jan-2018  Defect ID : TECH-18349 */
/***************************************************************************************/
/* Modified by  : Ranjitha R	Date: 28-Feb-2018  Defect ID : TECH-19347 */
/***************************************************************************************/
/* Modified by  : Ranjitha R	Date: 31-May-2018  Defect ID : TECH-21893 */
/***************************************************************************************/
/* Modified by  : Pavithra V	Date: 05-SEP-2018  Defect ID : TECH-24051  FOR THE SECTION TYPE POPOVER VALIDATIONS HAS BEEN ADDED */
/************************************************************************************************************************************************/
/* Modified by : Pavithra V		Date: 31-OCT-2018  Defect ID : TECH-27666 For  sections  the LAYOUT should be a TABLE, displaying error message */
/* Modified by : Jeya Latha     Date: 25-Jul-2019  Defect ID : TECH-36371			                                                            */
/* Modified by : Jeya Latha K   Date: 27-May-2020  Defect ID : TECH-46646 																		*/
/* Modified by : Deepika S		Date: 03-Apr-2021  Defect ID : TECH-57050																		*/
/* Modified by : Manoj S		Date: 29-Mar-2022  Defect ID : TECH-67614																		*/
/************************************************************************************************************************************************/
/* Modified by	:	Priyadharshini U/VimalKumar R															  */
/* Modified on	:	08/06/22				 																  */
/* Defect ID	:	TECH-69624																				  */
/* Description	:	Custom border, Custom actions and Responsive layout										  */
/**************************************************************************************************************/
/* Modified By : Ponmalar A/Jeya Latha K	Date : 08-Jun-2022	Defect ID : TECH-69575						  */
/* Description : ListItem section type is enabled only for native application validation should be commented. */
/**************************************************************************************************************/
/* Modified by	:	Ponmalar A																				  */
/* Modified on	:	11-July-22				 																  */
/* Defect ID	:	TECH-70687																				  */
/* Description	:	Tool and Toolbars																		  */
/**************************************************************************************************************/
/* Modified by	:	Ponmalar A																				  */
/* Modified on	:	23-Aug-2022				 																  */
/* Defect ID	:	TECH-72114																				  */
/* Description	:	Platform Modeling for Section Title Icon												  */
/**************************************************************************************************************/
/* Modified by			: Ponmalar A																		  */
/* Date					: 29-Sep-2022																		  */
/* Defect ID			: TECH-73216																		  */
/**************************************************************************************************************/
/* Modified by			: Priyadharshini U																	  */
/* Date					: 27-Oct-2022																		  */
/* Defect ID			: TECH-73996																		  */
/**************************************************************************************************************/
/* Modified by			: Vimal Kumar R/Ponmalar A															  */
/* Date					: 03-Nov-2022																		  */
/* Defect ID			:																					  */
/**************************************************************************************************************/
/* Modified by			: Ganesh Prabhu S																	  */
/* Date					: 14-Nov-2022																		  */
/* Defect ID			: TECH-74472																		  */
/**************************************************************************************************************/
/* Modified by			: Ponmalar A / Vimal Kumar R														  */
/* Date					: 22-Nov-2022																		  */
/* Defect ID			: TECH-75230																		  */
/**************************************************************************************************************/
CREATE PROCEDURE ep_maireeSp_scsav_sec
	@ctxt_ouinstance ctxt_ouinstance, --Input 
	@ctxt_user ctxt_user, --Input 
	@ctxt_language ctxt_language, --Input 
	@ctxt_service ctxt_service, --Input 
	@enggc_hmodeflag guid, --Input 
	@engg_act_descr engg_description, --Input 
	@engg_component engg_description, --Input 
	@engg_cont_page_bts engg_name, --Input 
	@engg_cont_sec_bts engg_name, --Input 
	@engg_customer_name engg_name, --Input 
	@engg_enum_page_bts engg_name, --Input 
	@engg_enum_sec_bts engg_name, --Input 
	@engg_grid_page_bts engg_name, --Input 
	@engg_grid_sec_bts engg_name, --Input 
	@engg_lay_page_bts engg_name, --Input 
	@engg_process_descr engg_description, --Input 
	@engg_project_name engg_name, --Input 
	@engg_radio_page_bts engg_name, --Input 
	@engg_radio_sec_bts engg_name, --Input 
	@engg_req_no engg_name, --Input 
	@engg_rf_act engg_description, --Input 
	@engg_rf_comp engg_description, --Input 
	@engg_rf_ui engg_description, --Input 
	@engg_sect_doc engg_documentation, --Input 
	@engg_sec_bord_req engg_flag, --Input 
	@engg_sec_btsynname engg_name, --Input 
	@engg_sec_cap_align engg_name, --Input 
	@engg_sec_cap_format engg_name, --Input 
	@engg_sec_descr engg_description, --Input 
	@engg_sec_page_bts engg_name, --Input 
	@engg_sec_secpreclass engg_name, --Input 
	@engg_sec_title_align engg_name, --Input 
	@engg_sec_title_req engg_flag, --Input 
	@engg_sec_type engg_type, --Input 
	@engg_sec_visible engg_flag, --Input 
	@engg_ui_descr engg_name, --Input 
	@engg_ui_xml engg_documentation, --Input 
	@hdncustomer engg_name, --Input 
	@hdnproject engg_name, --Input 
	@modeflag modeflag, --Input 
	@sectionheight engg_name, --Input 
	@sectionwidth engg_name, --Input 
	@sec_collapsemode engg_name, --Input 
	@_sec_fprowno rowno, --Input/Output
	@sec_collapse engg_name, --Input 
	@section_rowspan engg_seqno, --Input 
	@section_colspan engg_seqno, --Input 
	--@IsStatic             	engg_flag, --Input
	@engg_sec_lay_con engg_name, --Input 
	@engg_sect_lay engg_name, --Input 
	@engg_region engg_name, --Input 
	@engg_col_dir engg_name, --Input 
	@engg_title_pos engg_name, --Input 	 
	@engg_associatedcontrol engg_name, --Input 
	@engg_mob_fullview         engg_flag,--Input   ---code added by 13639
    @engg_mob_responsive       engg_flag, --Input  ---code added by 13639
	@engg_sect_forresponsive   engg_seqno, --Input	--Code added for TECH-69624
	@engg_sec_customborder	   engg_code, --Input	--Code added for TECH-69624
	@Orientation			   engg_name, --Input	--TECH-75230
	--TECH-70687
	@engg_sec_titleaction	engg_code,
	@engg_sec_bottomtb		engg_seqno,
	@engg_sec_toptb			engg_seqno,
	@engg_sec_righttb		engg_seqno,
	@engg_sec_lefttb		engg_seqno,
	@engg_sec_minrows		engg_seqno,
	@engg_sec_vwmode		engg_name,
	--TECH-70687
	@engg_sec_titleicon		engg_name,	--TECH-72114
	@m_errorid INT OUTPUT --To Return Execution Status
AS
BEGIN
	-- nocount should be switched on to prevent phantom rows
	SET NOCOUNT ON
	-- @m_errorid should be 0 to Indicate Success
	SET @m_errorid = 0
	--declaration of temporary variables
	--temporary and formal parameters mapping
	SET @ctxt_user = ltrim(rtrim(@ctxt_user))
	SET @ctxt_service = ltrim(rtrim(@ctxt_service))
	SET @engg_act_descr = ltrim(rtrim(@engg_act_descr))
	SET @engg_component = ltrim(rtrim(@engg_component))
	SET @engg_cont_page_bts = ltrim(rtrim(@engg_cont_page_bts))
	SET @engg_cont_sec_bts = ltrim(rtrim(@engg_cont_sec_bts))
	SET @engg_customer_name = ltrim(rtrim(@engg_customer_name))
	SET @engg_enum_page_bts = ltrim(rtrim(@engg_enum_page_bts))
	SET @engg_enum_sec_bts = ltrim(rtrim(@engg_enum_sec_bts))
	SET @engg_grid_page_bts = ltrim(rtrim(@engg_grid_page_bts))
	SET @engg_grid_sec_bts = ltrim(rtrim(@engg_grid_sec_bts))
	SET @engg_lay_page_bts = ltrim(rtrim(@engg_lay_page_bts))
	SET @engg_process_descr = ltrim(rtrim(@engg_process_descr))
	SET @engg_project_name = ltrim(rtrim(@engg_project_name))
	SET @engg_radio_page_bts = ltrim(rtrim(@engg_radio_page_bts))
	SET @engg_radio_sec_bts = ltrim(rtrim(@engg_radio_sec_bts))
	SET @engg_req_no = ltrim(rtrim(@engg_req_no))
	SET @engg_rf_act = ltrim(rtrim(@engg_rf_act))
	SET @engg_rf_comp = ltrim(rtrim(@engg_rf_comp))
	SET @engg_rf_ui = ltrim(rtrim(@engg_rf_ui))
	SET @engg_sect_doc = ltrim(rtrim(@engg_sect_doc))
	SET @engg_sec_bord_req = ltrim(rtrim(@engg_sec_bord_req))
	SET @engg_sec_btsynname = ltrim(rtrim(@engg_sec_btsynname))
	SET @engg_sec_cap_align = ltrim(rtrim(@engg_sec_cap_align))
	SET @engg_sec_cap_format = ltrim(rtrim(@engg_sec_cap_format))
	SET @engg_sec_descr = ltrim(rtrim(@engg_sec_descr))
	SET @engg_sec_page_bts = ltrim(rtrim(@engg_sec_page_bts))
	SET @engg_sec_secpreclass = ltrim(rtrim(@engg_sec_secpreclass))
	SET @engg_sec_title_align = ltrim(rtrim(@engg_sec_title_align))
	SET @engg_sec_title_req = ltrim(rtrim(@engg_sec_title_req))
	SET @engg_sec_type = ltrim(rtrim(@engg_sec_type))
	SET @engg_sec_visible = ltrim(rtrim(@engg_sec_visible))
	SET @engg_ui_descr = ltrim(rtrim(@engg_ui_descr))
	SET @engg_ui_xml = ltrim(rtrim(@engg_ui_xml))
	SET @hdncustomer = ltrim(rtrim(@hdncustomer))
	SET @hdnproject = ltrim(rtrim(@hdnproject))
	SET @modeflag = ltrim(rtrim(@modeflag))
	SET @engg_sec_lay_con = ltrim(rtrim(@engg_sec_lay_con))
	SET @engg_sect_lay = ltrim(rtrim(@engg_sect_lay))
	SET @engg_region = ltrim(rtrim(@engg_region))
	SET @engg_col_dir = ltrim(rtrim(@engg_col_dir))
	SET @engg_title_pos = ltrim(rtrim(@engg_title_pos))
	SET @engg_associatedcontrol = ltrim(rtrim(@engg_associatedcontrol))
	---code added by 13639 starts---
	SET @engg_mob_fullview		=ltrim(rtrim(@engg_mob_fullview))  ---code added by 13639
	SET @engg_mob_responsive	=ltrim(rtrim(@engg_mob_responsive))
	---code added by 13639 ends----
	SET @Orientation			=ltrim(rtrim(@Orientation))			--TECH-75230
	--null checking
	IF @ctxt_ouinstance = - 915
		SET @ctxt_ouinstance = NULL

	IF @ctxt_user = '~#~'
		SET @ctxt_user = NULL

	IF @ctxt_language = - 915
		SET @ctxt_language = NULL

	IF @ctxt_service = '~#~'
		SET @ctxt_service = NULL

	IF @engg_act_descr = '~#~'
		SET @engg_act_descr = NULL

	IF @engg_component = '~#~'
		SET @engg_component = NULL

	IF @engg_cont_page_bts = '~#~'
		SET @engg_cont_page_bts = NULL

	IF @engg_cont_sec_bts = '~#~'
		SET @engg_cont_sec_bts = NULL

	IF @engg_customer_name = '~#~'
		SET @engg_customer_name = NULL

	IF @engg_enum_page_bts = '~#~'
		SET @engg_enum_page_bts = NULL

	IF @engg_enum_sec_bts = '~#~'
		SET @engg_enum_sec_bts = NULL

	IF @engg_grid_page_bts = '~#~'
		SET @engg_grid_page_bts = NULL

	IF @engg_grid_sec_bts = '~#~'
		SET @engg_grid_sec_bts = NULL

	IF @engg_lay_page_bts = '~#~'
		SET @engg_lay_page_bts = NULL

	IF @engg_process_descr = '~#~'
		SET @engg_process_descr = NULL

	IF @engg_project_name = '~#~'
		SET @engg_project_name = NULL

	IF @engg_radio_page_bts = '~#~'
		SET @engg_radio_page_bts = NULL

	IF @engg_radio_sec_bts = '~#~'
		SET @engg_radio_sec_bts = NULL

	IF @engg_req_no = '~#~'
		SET @engg_req_no = NULL

	IF @engg_rf_act = '~#~'
		SET @engg_rf_act = NULL

	IF @engg_rf_comp = '~#~'
		SET @engg_rf_comp = NULL

	IF @engg_rf_ui = '~#~'
		SET @engg_rf_ui = NULL

	IF @engg_sect_doc = '~#~'
		SET @engg_sect_doc = NULL

	IF @engg_sec_bord_req = '~#~'
		SET @engg_sec_bord_req = NULL

	IF @engg_sec_btsynname = '~#~'
		SET @engg_sec_btsynname = NULL

	IF @engg_sec_cap_align = '~#~'
		SET @engg_sec_cap_align = NULL

	IF @engg_sec_cap_format = '~#~'
		SET @engg_sec_cap_format = NULL

	IF @engg_sec_descr = '~#~'
		SET @engg_sec_descr = NULL

	IF @engg_sec_page_bts = '~#~'
		SET @engg_sec_page_bts = NULL

	IF @engg_sec_secpreclass = '~#~'
		SET @engg_sec_secpreclass = NULL

	IF @engg_sec_title_align = '~#~'
		SET @engg_sec_title_align = NULL

	IF @engg_sec_title_req = '~#~'
		SET @engg_sec_title_req = NULL

	IF @engg_sec_type = '~#~'
		SET @engg_sec_type = NULL

	IF @engg_sec_visible = '~#~'
		SET @engg_sec_visible = NULL

	IF @engg_ui_descr = '~#~'
		SET @engg_ui_descr = NULL

	IF @engg_ui_xml = '~#~'
		SET @engg_ui_xml = NULL

	IF @hdncustomer = '~#~'
		SET @hdncustomer = NULL

	IF @hdnproject = '~#~'
		SET @hdnproject = NULL

	IF @modeflag = '~#~'
		SET @modeflag = NULL

	IF @sectionheight = '~#~'
		SET @sectionheight = NULL

	IF @sectionwidth = '~#~'
		SET @sectionwidth = NULL

	IF @_sec_fpRowNo = - 915
		SET @_sec_fpRowNo = NULL

	IF @section_rowspan = - 915
		SELECT @section_rowspan = NULL

	IF @section_colspan = - 915
		SELECT @section_colspan = NULL

	--IF @IsStatic = '~#~' 
	--Select @IsStatic = null  
	IF @engg_sec_lay_con = '~#~'
		SELECT @engg_sec_lay_con = NULL

	IF @engg_sect_lay = '~#~'
		SELECT @engg_sect_lay = NULL

	IF @engg_region = '~#~'
		SELECT @engg_region = NULL

	IF @engg_col_dir = '~#~'
		SELECT @engg_col_dir = NULL

	IF @engg_title_pos = '~#~'
		SELECT @engg_title_pos = NULL

	IF @engg_associatedcontrol = '~#~'
		SELECT @engg_associatedcontrol = NULL
---code added by 13639 starts ------
	IF @engg_mob_fullview = '~#~'
		SELECT @engg_mob_fullview = NULL

	IF @engg_mob_responsive = '~#~'
		SELECT @engg_mob_responsive = NULL
		---code added by 13639 ends---------

		--Code added for TECH-69624
	IF @engg_sect_forresponsive = - 915
		SELECT @engg_sect_forresponsive = NULL
		--Code added for TECH-69624

	IF @Orientation = '~#~'
		SELECT @Orientation = NULL

	--TECH-70687
	IF @engg_sec_minrows = - 915
		SELECT @engg_sec_minrows = NULL
	--TECH-70687

	IF @engg_sec_titleicon =  '~#~'
		SELECT @engg_sec_titleicon = NULL

	DECLARE @engg_control_name engg_name

	IF EXISTS (
			SELECT 'x'
			FROM vid_ilbo_tmp
			WHERE ilbodescription = @engg_ui_descr
			)
	BEGIN
		EXEC uid_ep_maireeSp_scsav_sec @ctxt_ouinstance,
			@ctxt_user,
			@ctxt_language,
			@ctxt_service,
			@enggc_hmodeflag,
			@engg_act_descr,
			@engg_component,
			@engg_cont_page_bts,
			@engg_cont_sec_bts,
			@engg_customer_name,
			@engg_enum_page_bts,
			@engg_enum_sec_bts,
			@engg_grid_page_bts,
			@engg_grid_sec_bts,
			@engg_lay_page_bts,
			@engg_process_descr,
			@engg_project_name,
			@engg_radio_page_bts,
			@engg_radio_sec_bts,
			@engg_req_no,
			@engg_rf_act,
			@engg_rf_comp,
			@engg_rf_ui,
			@engg_sect_doc,
			@engg_sec_bord_req,
			@engg_sec_btsynname,
			@engg_sec_cap_align,
			@engg_sec_cap_format,
			@engg_sec_descr,
			@engg_sec_page_bts,
			@engg_sec_secpreclass,
			@engg_sec_title_align,
			@engg_sec_title_req,
			@engg_sec_type,
			@engg_sec_visible,
			@engg_ui_descr,
			@engg_ui_xml,
			@hdncustomer,
			@hdnproject,
			@modeflag,
			@sectionheight,
			@sectionwidth,
			@sec_collapsemode,
			@_sec_fprowno,
			@sec_collapse,
			@section_rowspan,
			@section_colspan,
			@m_errorid
	END
	ELSE
	BEGIN

		IF (@engg_sec_Type = 'Filler' AND @engg_sec_visible = '0') --PLF2.0_07805
		BEGIN
			RAISERROR ('Filler Section should be visible',16,1)
			RETURN
		END

		/*
		--OuputList
		Select null '_sec_fpRowNo' from ***


		*/
		IF @ModeFlag = 'S' -- added by Gopinath S for the Call ID PNR2.0_20603
		BEGIN
			-- Code added for PNR2.0_23902 by Gowrisankar M on 17-Sep-2009 - Begins
			SELECT @_sec_fpRowNo = isnull(@_sec_fpRowNo, 0) + 1

			SELECT @_sec_fpRowNo '_sec_fpRowNo'

			-- Code added for PNR2.0_23902 by Gowrisankar M on 17-Sep-2009 - Ends
			RETURN
		END

		IF lower(ltrim(rtrim(@engg_sec_cap_format))) = ltrim(rtrim('control besides caption'))
			SELECT @engg_sec_cap_format = 'bes'
		ELSE IF lower(ltrim(rtrim(@engg_sec_cap_format))) = ltrim(rtrim('control under caption'))
			SELECT @engg_sec_cap_format = 'und'

		DECLARE @msg engg_documentation,
			@tmp_proc engg_name,
			@tmp_comp engg_name,
			@tmp_act engg_name,
			@tmp_ui engg_name,
			@engg_base_req_no engg_name,
			@sec_bt_caption engg_name,
			@Section_width_Scalemode engg_name,
			@d_cnt engg_seqno,
			@d_char engg_name,
			@d_num engg_name,
			@Section_height_Scalemode engg_name,
			@l_cnt engg_seqno,
			@l_char engg_name,
			@l_num engg_name,
			@depstatereq engg_name /*Modification made by Muthupandi S for Bug id : PNR2.0_34596*/
		DECLARE @XYCoordinate engg_description,
			@ColLayWid engg_description,
			@phone_in engg_flag,
			@tablet_in engg_flag,
			@Devicetype engg_flag
		DECLARE @error_tmp engg_seqno
		DECLARE @sect_type engg_name -- code added by anu

		SELECT @engg_base_req_no = 'BASE'

		SELECT @_sec_fpRowNo = isnull(@_sec_fpRowNo, 0) + 1

		IF @engg_sec_visible = '1'
		BEGIN
			SELECT @engg_sec_visible = 'y'
		END
		ELSE
		BEGIN
			SELECT @engg_sec_visible = 'n'
		END

		IF @engg_act_descr IS NULL
		BEGIN
			SELECT @msg = 'Select Activity'

			EXEC engg_error_sp 'ep_maireeSp_scsav_sec',
				1,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			RETURN
		END

		--Check whether UI is selected. If not display error message
		IF @engg_ui_descr IS NULL
		BEGIN
			SELECT @msg = 'Select User Interface'

			EXEC engg_error_sp 'ep_maireeSp_scsav_sec',
				2,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			RETURN
		END

		--Check whether Page BT is selected. If not display error message
		IF @engg_sec_page_bts IS NULL
		BEGIN
			SELECT @msg = 'Select page (BT Synonym)'

			EXEC engg_error_sp 'ep_maireeSp_scsav_sec',
				3,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			RETURN
		END

		--For each row, if Section BTSynonym Name is not entered, display error message.
		IF @engg_sec_btsynname IS NULL
		BEGIN
			SELECT @msg = 'BT Synonym for Row ' + convert(CHAR(5), @_sec_fpRowNo) + ' is null'

			EXEC engg_error_sp 'ep_maireeSp_scsav_sec',
				4,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			RETURN
		END

		--For each row, if Section BTSynonym Name contains blank spaces , display error message.
		SELECT @error_tmp = dbo.ep_check_spl_char(@engg_sec_btsynname)

		-- code modified by shafina on 12-May-2004 for PREVIEWENG203ACC_000058
		IF @modeflag <> 'D'
		BEGIN
			IF @error_tmp = 1
			BEGIN
				SELECT @msg = 'BT Synonym for Row ' + convert(CHAR(5), @_sec_fpRowNo) + ' contains special characters.'

				EXEC ENGG_ERROR_SP 'ep_layout_sp_savscscml',
					4,
					@msg,
					@CTXT_LANGUAGE,
					@CTXT_OUINSTANCE,
					@CTXT_SERVICE,
					@CTXT_USER,
					'',
					'',
					'',
					'',
					@M_ERRORID OUTPUT

				RETURN
			END

			-- code modified by shafina on 07-July-2004 for PREVIEWENG203ACC_000076
			-- Length of the BT Synonym must not exceed 30 characters.
			-- Modified by karthik on 14-Mar-2005  ---  Start ---------
			--   if len(@engg_sec_btsynname) > 30
			--   begin
			--    select @msg  = 'Length of Section Bt Synonym must not be greater than 30 for Row ' + convert(char(5), @_sec_fpRowNo )
			--    exec engg_error_sp 'ep_maireeSp_scsav_sec',
			--  4,
			--          @msg,
			--          @ctxt_language,
			--          @ctxt_ouinstance,
			--          @ctxt_service,
			--          @ctxt_user,
			--          '',
			--          '',
			--          '',
			--          '',
			--          @m_errorid  output
			--    return
			--   end
			-- Modified by karthik on 14-Mar-2005  ---  End ---------
			-- Validation added for PNR2.0_9983 on 22-Aug-2006 by Gowrisankar
			IF @engg_sec_btsynname = 'PrjHdnSection'
			BEGIN
				SELECT @msg = 'Section Name cannot be "PrjHdnSection". Error at row no ' + convert(CHAR(5), @_sec_fpRowNo)

				EXEC engg_error_sp 'ep_maireeSp_scsav_sec',
					4,
					@msg,
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					'',
					'',
					'',
					'',
					@m_errorid OUTPUT

				RETURN
			END

			--TECH-73216
			IF @ModeFlag IN ('I','X') AND LEN(@engg_sec_btsynname)>30
			BEGIN
				RAISERROR('Length of Section Bt Synonym must not be greater than 30.',16,1)
				RETURN
			END
			--TECH-73216

			--TECH-75230
			IF @ModeFlag IN ('I','X','U','Y') AND ISNULL(@engg_Sec_type,'') NOT IN ('Stepper Linear','Stepper Non-Linear') AND ISNULL(@Orientation,'') <> ''
			BEGIN
				RAISERROR('Orientation is applicable only for the section types �Linear Stepper� and �Non-Linear Stepper�.',16,1)
				RETURN
			END
			--TECH-75230

			IF @ModeFlag IN (
					'I',
					'X',
					'U',
					'Y',
					'D'
					)
				AND EXISTS (
					SELECT 'x'
					FROM ep_systemdefined_views(NOLOCK)
					WHERE createdfor = 'Dashboard'
						AND viewcaption = @engg_sec_btsynname
					)
				AND EXISTS (
					SELECT 'x'
					FROM ep_ui_mst(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND activity_name = @tmp_act
						AND ui_name = @tmp_ui
						AND req_no = @engg_req_no
						AND ui_subtype = 'Dashboard'
					)
			BEGIN
				RAISERROR (
						'System Defined section cannot be modified/deleted.Error at Row no: ''%d ''',
						16,
						1,
						@_sec_fpRowNo
						)

				RETURN
			END

			-- Validation added for PNR2.0_9983 on 22-Aug-2006 by Gowrisankar
			-- Validation added for PNR2.0_10027 on 25-Aug-2006 by kiruthika
			IF rtrim(@engg_sec_btsynname) = 'wf_hdn_section'
			BEGIN
				SELECT @msg = 'Section Name cannot be "wf_hdn_section". Error at row no ' + convert(CHAR(5), @_sec_fpRowNo)

				EXEC engg_error_sp 'ep_maireeSp_scsav_sec',
					4,
					@msg,
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					'',
					'',
					'',
					'',
					@m_errorid OUTPUT

				RETURN
			END

			-- Validation added for PNR2.0_10027 on 25-Aug-2006 by kiruthika
			-- code modified by shafina on 11-Aug-2004 for checking whether FILLER is given as BTSynonym.- PREVIEWENG203ACC_000086
			IF @engg_sec_btsynname = 'Filler'
			BEGIN
				SELECT @msg = 'Section cannot have Filler as its BTSynonym at row no ' + convert(CHAR(5), @_sec_fpRowNo)

				EXEC engg_error_sp 'ep_maireeSp_scsav_sec',
					4,
					@msg,
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					'',
					'',
					'',
					'',
					@m_errorid OUTPUT

				RETURN
			END
		END

		-----Carousel section validation added against Defect ID :TECH-57050 starts

				IF @engg_sec_type = 'Carousel'and isnull(@sectionheight,'') = ''
				begin
				select @msg= 'kindly provide the section height for the Carousel section '+'"'+@engg_sec_btsynname+'"'
				EXEC engg_error_sp 'ep_maireeSp_scsav_sec',
				4,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT
				return
				end

				--TECH-57050	ends

		-- Validation: popup section can be created only in mainscreen
		IF @engg_sec_type = 'POPUP'
			AND @engg_sec_page_bts <> '[mainscreen]'
		BEGIN
			SELECT @msg = 'Popup Section can be only created in a mainscreen.Error at row no ' + convert(CHAR(5), @_sec_fpRowNo)

			EXEC engg_error_sp 'ep_maireeSp_scsav_sec',
				4,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			RETURN
		END

		----
 /*Tree ,Treegrid restriction --TECH-67614 starts*/
     IF @ModeFlag IN (
					'I',
					'X'
					 )

	 BEGIN
		IF @engg_sec_type in ('Tree','Tree Grid')
			
		BEGIN
			SELECT @msg = 'Section type Tree and Tree Grid are not recommended.Kindly use Tree Grid control type.Error at row no ' + convert(CHAR(5), @_sec_fpRowNo)

			EXEC engg_error_sp 'ep_maireeSp_scsav_sec',
				4,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			RETURN
		END
    END
	/*Tree ,Treegrid restriction --TECH-67614 ends*/
		--GETTING THE PROCESS NAME FOR DESCRIPTION
		SELECT @tmp_proc = process_name
		FROM ep_ui_req_dtl(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND process_descr = @engg_process_descr
			AND req_no = @engg_req_no

		--GETTING THE COMPONENT NAME FOR THE DESCRIPTION
		SELECT @tmp_comp = component_name
		FROM ep_ui_req_dtl(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND process_name = @tmp_proc
			AND component_descr = @engg_component
			AND req_no = @engg_req_no

		--GETTING THE ACTIVITY NAME FOR THE DESCRIPTION
		SELECT @tmp_act = activity_name
		FROM ep_ui_req_dtl(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND process_name = @tmp_proc
			AND component_name = @tmp_comp
			AND activity_descr = @engg_act_descr
			AND req_no = @engg_req_no

		--GETTING THE UI NAME FOR THE DESCRIPTION
		SELECT @tmp_ui = ui_name
		FROM ep_ui_req_dtl(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND process_name = @tmp_proc
			AND component_name = @tmp_comp
			AND activity_name = @tmp_act
			AND ui_descr = @engg_ui_descr
			AND req_no = @engg_req_no
---code added by 13639 starts----
			--IF ISNULL(@engg_mob_responsive, 0) = 1
			--BEGIN
			--	IF NOT EXISTS ( SELECT 'X'
			--	FROM	ep_ui_section_dtl (nolock)
			--	WHERE	
			--	Customer_name=@engg_customer_name and 
			--	project_name=@engg_project_name and
			--	process_name=@tmp_proc and
			--	component_name=@tmp_comp and
			--	activity_name= @tmp_act and 
			--	ui_name=@tmp_ui and
			--	parent_section = @engg_sec_btsynname
			--	)
			--	BEGIN 
			--	Raiserror ('not allowed', 16, 1)
			--	RETURN
			--	end
			--	End
			--	----validation for fullview
			--	if (isnull(@engg_mob_fullview,0)=1 AND isnull(@sect_type,0)!> ('popup''popover'))
			--	BEGIN
			--	IF NOT EXISTS ( SELECT 'X' 
			--	FROM	ep_ui_section_dtl (nolock)
			--	WHERE	
			--	Customer_name=@engg_customer_name and 
			--	project_name=@engg_project_name and
			--	process_name=@tmp_proc and
			--	component_name=@tmp_comp and
			--	activity_name= @tmp_act and 
			--	ui_name=@tmp_ui and 
			--	section_bt_synonym=@engg_sec_btsynname and 
			--	--section_type=@sect_type and
			--	section_type NOT IN('popup','popover')
			--					)
			--	BEGIN 
			--	Raiserror ('fullview is for poptype and popover', 16, 1)
			--	RETURN
			--	END
			--    END
			--	--validation for Isresponsive	
			--	if isnull(@devicetype,0)<>'B''P''T'
			--	begin
			--	if isnull(@engg_mob_responsive,0)=1
			--	begin
			--	if not exists(select * from  ep_ui_mst (nolock) where 
			--	Customer_name=@engg_customer_name and 
			--	project_name=@engg_project_name and
			--	process_name=@tmp_proc and
			--	component_name=@tmp_comp and
			--	activity_name= @tmp_act and 
			--	ui_name=@tmp_ui and 
			--	devicetype=@devicetype)
			--	begin
			--	raiserror('Select any one of the allowed device type',16,1)
			--	return
			--	end
			--	end
			--	end
		
		---code added by 13639 Ends----	

		If	ISNULL(@engg_sec_type,'')	='MobileGrid'
        BEGIN
								    
				IF NOT EXISTS (SELECT 'X'
				FROM ep_ui_section_dtl
				WHERE customer_name        =      @engg_customer_name
				AND project_name           =      @engg_project_name
				AND process_name           =      @tmp_proc
				AND component_name         =      @tmp_comp
				AND activity_name          =      @tmp_act
				AND ui_name                =      @tmp_ui
				AND page_bt_synonym        =      @engg_sec_page_bts
				AND req_no                 =      @engg_base_req_no
				AND section_type           =	'MobileGrid'  )
                BEGIN
                                  
					RAISERROR ('Please use section type as MAIN and base control type as GRID for Mobility screen.', 16,1) --11537 TECH-74472
                    RETURN
                END
		END
                     



		---- Glance validation Starts
		--IF @ModeFlag <> 'd' and @tmp_ui not in ('HRMSBCSER_UI','HRMSQBILCON_UI','HRMSQINVGEN_UI')
		--BEGIN
		--	IF EXISTS (
		--			SELECT 'X'
		--			FROM ep_new_ui_mst a(NOLOCK),
		--				ep_ui_mst b(NOLOCK)
		--			WHERE a.customer_name	 = @engg_customer_name
		--				AND a.project_name	 = @engg_project_name
		--				AND a.process_name	 = @tmp_proc
		--				AND a.component_name = @tmp_comp
		--				AND a.activity_name  = @tmp_act
		--				AND a.ui_name		 = @tmp_ui
		--				AND isnull(b.DeviceType, '') NOT IN (
		--					'p',
		--					't',
		--					'B'
		--					)
		--				AND a.customer_name = b.customer_name
		--				AND a.project_name = b.project_name
		--				AND a.process_name = b.process_name
		--				AND a.component_name = b.component_name
		--				AND a.activity_name = b.activity_name
		--				AND a.ui_name = b.ui_name
		--			)
		--	BEGIN
		--		IF NOT EXISTS (
		--				SELECT TOP 1 (section_bt_synonym)
		--				FROM ep_ui_section_dtl(NOLOCK)
		--				WHERE customer_name = @engg_customer_name
		--					AND project_name = @engg_project_name
		--					AND process_name = @tmp_proc
		--					AND component_name = @tmp_comp
		--					AND activity_name = @tmp_act
		--					AND ui_name = @tmp_ui
		--					AND section_bt_synonym <> 'PrjhdnSection'
		--				)
		--		BEGIN
		--			RAISERROR (
		--					'Please use Glance tool for new desktop user interface layout modelling',
		--					16,
		--					1
		--					)

		--			RETURN
		--		END
		--	END
		--END

		---- Glance validation Ends
		/*Modification made by Muthupandi S for Bug id : PNR2.0_34596 Starts*/
		SELECT @depstatereq = current_value
		FROM es_project_param_mst(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND param_category = 'DEPSTATEREQ'

		IF @ModeFlag = 'I'
		BEGIN
			IF @depstatereq = 'Y'
			BEGIN
				IF EXISTS (
						SELECT 'X'
						FROM ep_ui_section_dtl(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @tmp_proc
							AND component_name = @tmp_comp
							AND activity_name = @tmp_act
							AND ui_name = @tmp_ui
							AND section_bt_synonym = @engg_sec_btsynname
						)
				BEGIN
					SELECT @msg = 'section name given at row no ' + convert(CHAR(5), @_sec_fpRowNo) + ' is already exists in ui' + '"' + @tmp_ui + '"'

					EXEC engg_error_sp 'ep_maireeSp_scsav_sec',
						4,
						@msg,
						@ctxt_language,
						@ctxt_ouinstance,
						@ctxt_service,
						@ctxt_user,
						'',
						'',
						'',
						'',
						@m_errorid OUTPUT
				END
			END
		END

		-- NGPLF Changes Starts
		DECLARE @ctxt_role ENGG_NAME = NULL

		IF @modeflag IN (
				'I',
				'X',
				'U',
				'Y'
				)
			AND @engg_sec_visible = 'Y'
		BEGIN
			IF EXISTS (
					SELECT 'X'
					FROM ep_ui_mst(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND activity_name = @tmp_act
						AND ui_name = @tmp_ui
						AND ISNULL(ISGLANCE, 'N') = 'Y'
					)
			BEGIN
				EXEC ngplf_validate_specifylayout @ctxt_language,
					@ctxt_ouinstance,
					@ctxt_user,
					@Ctxt_role,
					@engg_customer_name,
					@engg_project_name,
					@tmp_proc,
					@tmp_comp,
					@tmp_act,
					@tmp_ui,
					@engg_sec_page_bts,
					@engg_sec_btsynname,
					'S'
			END
		END

		IF @modeflag IN (
				'I',
				'X',
				'U',
				'Y'
				)
			AND @engg_sec_visible = 'N'
		BEGIN
			IF EXISTS (
					SELECT 'X'
					FROM ep_ui_mst(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND activity_name = @tmp_act
						AND ui_name = @tmp_ui
						AND ISNULL(ISGLANCE, 'N') = 'Y'
					)
			BEGIN
				EXEC ngplf_validate_specifylayout @ctxt_language,
					@ctxt_ouinstance,
					@ctxt_user,
					@Ctxt_role,
					@engg_customer_name,
					@engg_project_name,
					@tmp_proc,
					@tmp_comp,
					@tmp_act,
					@tmp_ui,
					@engg_sec_page_bts,
					@engg_sec_btsynname,
					'SP'
			END
		END

		-- NGPLF Changes ends
		--------- PLF2.0_18888         starts
		----------Pavithra V  TECH-27666

		--commented by 14469 for TECH-69624
		----BEGIN
		----	IF NOT EXISTS (
		----			SELECT 'x'
		----			FROM ep_ui_mst(NOLOCK)
		----			WHERE customer_name = @engg_customer_name
		----				AND project_name = @engg_project_name
		----				AND process_name = @tmp_proc
		----				AND component_name = @tmp_comp
		----				AND activity_name = @tmp_act
		----				AND ui_name = @tmp_ui
		----				AND IsGlance = 'y'
		----			)
		----	BEGIN
		----		IF isnull(@engg_sect_lay, '') NOT IN ('TABLE')
		----		BEGIN
		----			RAISERROR (
		----					'For the section name ''%s'' layout should be a TABLE',
		----					16,
		----					1,
		----					@engg_sec_btsynname
		----					)

		----			RETURN
		----		END
		----	END
		----END
		--commented by 14469  for TECH-69624

		----------Pavithra V   TECH-27666
		--------- PLF2.0_18888         starts
		-- 11742 Pavithra @engg_sec_Type
		IF LOWER(@engg_sec_visible) = 'n'
			AND @engg_sec_Type = 'PopOver'
		BEGIN
			RAISERROR (
					'Visible Property should be selected if Section Type is PopOver',
					16,
					1
					)

			RETURN
		END

		-- 11742 		
		--if (@engg_col_dir not in ('top','bottom'))
		--	begin
		IF isnull(@engg_col_dir, '') NOT IN (
				'top',
				'bottom'
				)
			AND @engg_sec_Type = 'PopOver'
		BEGIN
			RAISERROR (
					'Collapse Direction Top/Bottom should be selected if Section Type is PopOver',
					16,
					1
					)

			RETURN
		END

		--End
		--	 Pavithra
		--kanagavel
		-- TECH-27913 code starts 
		IF EXISTS (
				SELECT 'x'
				FROM ep_ui_mst(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND activity_name = @tmp_act
					AND ui_name = @tmp_ui
					AND isnull(DeviceType, '') NOT IN (
						'P',
						'T',
						'B'
						)
				)
		BEGIN
			IF isnull(@engg_title_pos, '') = ''
				SET @engg_title_pos = 'Top'

			IF @sec_collapse = 'Y'
				AND isnull(@sec_collapsemode, 'Non') = 'NON'
				SELECT @sec_collapsemode = 'EXP',
					@engg_col_dir = 'Top'

			IF @sec_collapse = 'N'
				AND isnull(@sec_collapsemode, '') <> 'NON'
				SELECT @sec_collapsemode = 'NON',
					@engg_col_dir = ''

			IF isnull(@engg_sec_title_req, 0) = 0
				SELECT @sec_collapse = 'N',
					@sec_collapsemode = 'NON',
					@engg_col_dir = ''
		END

		-- TECH-27913 code Ends
		-- Code Added for the BugId PNR2.0_1790 Starts
		DECLARE @page_type engg_type

		IF @modeflag IN (
				'U',
				'Y',
				'I',
				'X'
				)
		BEGIN
			IF (ISNULL(@engg_sec_type,'') NOT IN ('Popup', 'Popover') AND ISNULL(@engg_mob_fullview, 0) = 1)
			BEGIN
				Raiserror ('Full View option is applicable only for Popup and Popover sections. Error at Row no: ''%d ''', 16, 1, @_sec_fpRowNo)
				RETURN
			END

				SELECT	@Devicetype	= ISNULL(DeviceType, 'N')		
				FROM	ep_ui_mst (nolock)
				WHERE	customer_name	= @engg_customer_name
				AND		project_name	= @engg_project_name
				AND		process_name	= @tmp_proc
				AND		component_name	= @tmp_comp
				AND		activity_name	= @tmp_act	
				AND		ui_name			= @tmp_ui

		--select 'tt', @Devicetype
		IF ISNULL(@engg_mob_responsive, 0) = 1
		BEGIN
		--select 'tt1', @Devicetype
				IF @Devicetype NOT IN ('P', 'B', 'T')
				OR NOT EXISTS ( SELECT 'X'
				FROM	ep_ui_section_dtl (nolock)
				WHERE	Customer_name	=	@engg_customer_name 
				AND 	project_name	=	@engg_project_name 
				AND		process_name	=	@engg_process_descr 
				AND		component_name	=	@engg_component 
				AND		activity_name	=	@engg_act_descr 
				AND 	ui_name			=	@engg_ui_descr 
				AND 	parent_section	=	@engg_sec_btsynname
				)
						
				BEGIN 
			--	select 'tt2', @Devicetype
				Raiserror ('''Is Responsive'' is applicable only for Parent Section of Mobile UI(s).Error at Row no: ''%d ''', 16, 1, @_sec_fpRowNo)
				RETURN
				END				
			END

			SELECT @page_type = rtrim(isnull(page_type, 'Normal'))
			FROM EP_UI_PAGE_DTL(NOLOCK)
			WHERE CUSTOMER_NAME = @engg_customer_name
				AND PROJECT_NAME = @engg_project_name
				AND REQ_NO = 'BASE'
				AND PROCESS_NAME = @tmp_proc
				AND COMPONENT_NAME = @tmp_comp
				AND ACTIVITY_NAME = @tmp_act
				AND UI_NAME = @tmp_ui
				AND PAGE_BT_SYNONYM = @engg_sec_page_bts

			IF @page_type = 'Grouping'
				AND isnull(@engg_sec_title_req, 0) = 0
			BEGIN
				RAISERROR (
						'''Title Required'' should be selected since the pagetype is ''Grouping'' for the given page. Error at Row no: ''%d ''',
						16,
						1,
						@_sec_fpRowNo
						)

				RETURN
			END
		END

		-- Code Added for the BugId PNR2.0_1790 Ends
		/* code added by lavanya on 7/11/2005 */
		--For each row that is fetched, if Section BT Synonym Name is altered, display error message.
		IF @modeflag IN (
				'U',
				'Y'
				)
			AND NOT EXISTS (
				SELECT 'A'
				FROM ep_ui_section_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND activity_name = @tmp_act
					AND ui_name = @tmp_ui
					AND page_bt_synonym = @engg_sec_page_bts
					AND section_bt_synonym = @engg_sec_btsynname
				)
		BEGIN
			SELECT @msg = 'BT Synonym ' + @engg_sec_btsynname + ' cannot be modified.'

			EXEC engg_error_sp 'ep_maireeSp_scsav_sec',
				1,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			RETURN
		END

		IF @modeflag IN (
				'U',
				'Y'
				)
		BEGIN
			--Added by RAMANUJAM
			IF @engg_sec_btsynname LIKE 'hdnspin%'
			BEGIN
				RAISERROR (
						'No Changesns Allowed for the Section  ''%s''',
						16,
						1,
						@engg_sec_btsynname
						)

				RETURN
			END
					--Added by ramanujam ends
		END

		-- code added by anu - start
		IF @Modeflag IN (
				'U',
				'Y'
				)
		BEGIN
			SELECT @sect_type = section_type
			FROM ep_ui_section_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_base_req_no
				AND process_name = @tmp_proc
				AND component_name = @tmp_comp
				AND activity_name = @tmp_act
				AND ui_name = @tmp_ui
				AND page_bt_synonym = @engg_sec_page_bts
				AND section_bt_synonym = @engg_sec_btsynname

			IF (@sect_type = 'Main')
				AND (
					(@engg_sec_type = 'Tree')
					OR (@engg_sec_type = 'chart')
					-- Added By Feroz PNR2.0_20728 for bug id
					OR @engg_sec_type IN (
						'Text Scroller',
						'Formatted Text',
						'Report List',
						'Property Window',
						'Pivot',
						'Tree Grid',
						'IFrame',
						'RSS Feed'
						)
					)
			BEGIN
				IF EXISTS (
						SELECT 'A'
						FROM ep_ui_control_dtl(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND req_no = @engg_base_req_no
							AND process_name = @tmp_proc
							AND component_name = @tmp_comp
							AND activity_name = @tmp_act
							AND ui_name = @tmp_ui
							AND page_bt_synonym = @engg_sec_page_bts
							AND section_bt_synonym = @engg_sec_btsynname
						)
				BEGIN
					SELECT @msg = 'Controls are defined under the section ' + @engg_sec_btsynname + ' .Delete the controls and then change the section type.'

					EXEC engg_error_sp 'ep_maireeSp_scsav_sec',
						1,
						@msg,
						@ctxt_language,
						@ctxt_ouinstance,
						@ctxt_service,
						@ctxt_user,
						'',
						'',
						'',
						'',
						@m_errorid OUTPUT

					RETURN
				END
			END -- (@sect_type = 'Main')

			--code added for the call id  : PNR2.0_13810
			IF (@engg_sec_type <> @sect_type)
				AND (@sect_type = 'Tree')
			BEGIN
				IF EXISTS (
						SELECT 'A'
						FROM ep_tree_dtl(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @tmp_proc
							AND component_name = @tmp_comp
							AND activity_name = @tmp_act
							AND ui_name = @tmp_ui
							AND page_bt_synonym = @engg_sec_page_bts
							AND section_bt_synonym = @engg_sec_btsynname
						)
				BEGIN
					SELECT @msg = 'Node type defined for Section Bt Synonym :' + @engg_sec_btsynname + '. Cannot update  at row no: ' + convert(CHAR(3), @_sec_fpRowNo)

					EXEC engg_error_sp 'ep_maireeSp_scsav_sec',
						1,
						@msg,
						@ctxt_language,
						@ctxt_ouinstance,
						@ctxt_service,
						@ctxt_user,
						'',
						'',
						'',
						'',
						@m_errorid OUTPUT

					RETURN
				END
			END
					--code added for the call id  : PNR2.0_13810
		END -- @Modeflag in ('U','Y')
				-- code added by anu - end

		--For each row that is selected for deletion, if controls exists for the section, display error message.
		IF @modeflag = 'D'
			AND @engg_sec_type <> 'Tree'
			AND (
				@engg_sec_type NOT IN (
					'Text Scroller',
					'Formatted Text',
					'Report List',
					'Property Window',
					'Pivot',
					'Tree Grid',
					'IFrame',
					'RSS Feed', -- added by feroz for extn js -- PNR2.0_1790
					'MobileGrid', -- Code added for Defect Id TECH-16126 
					'MobileCalendar' -- changed for the Defect id: TECH-21893
					)
				)
			AND EXISTS (
				SELECT 'A'
				FROM ep_ui_control_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND activity_name = @tmp_act
					AND ui_name = @tmp_ui
					AND page_bt_synonym = @engg_sec_page_bts
					AND section_bt_synonym = @engg_sec_btsynname
				)
		BEGIN
			SELECT @msg = 'Section BT synonym ' + @engg_sec_btsynname + ' is in use. Cannot Delete. at row no: ' + convert(CHAR(3), @_sec_fpRowNo)

			EXEC engg_error_sp 'ep_maireeSp_scsav_sec',
				1,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			RETURN
		END

		-- modified by jeya PNR2.0_20553
		IF (
				@modeflag = 'D'
				AND @engg_sec_type <> 'Tree'
				)
			OR (
				@modeflag = 'D'
				AND @engg_sec_type NOT IN (
					'Text Scroller',
					'Formatted Text',
					'Report List',
					'Property Window',
					'Pivot',
					'Tree Grid',
					'IFrame',
					'RSS Feed'
					)
				) -- added by feroz for extn js -- PNR2.0_1790
		BEGIN
			--Code added by Chanheetha N A on 26-Nov-05 for Bug Id:PNR2.0_4789
			IF EXISTS (
					SELECT 'A'
					FROM ep_ui_section_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_base_req_no
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND activity_name = @tmp_act
						AND ui_name = @tmp_ui
						AND page_bt_synonym = @engg_sec_page_bts
						AND parent_section = @engg_sec_btsynname
					)
			BEGIN
				SELECT @msg = 'Parent Section BT synonym ' + @engg_sec_btsynname + ' is in use. Cannot Delete. at row no: ' + convert(CHAR(3), @_sec_fpRowNo)

				EXEC engg_error_sp 'ep_maireeSp_scsav_sec',
					1,
					@msg,
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					'',
					'',
					'',
					'',
					@m_errorid OUTPUT

				RETURN
			END
		END

		--code added for the call id  : PNR2.0_13810
		IF @modeflag = 'D'
			AND @engg_sec_type = 'Tree'
			AND EXISTS (
				SELECT 'A'
				FROM ep_tree_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND activity_name = @tmp_act
					AND ui_name = @tmp_ui
					AND page_bt_synonym = @engg_sec_page_bts
					AND section_bt_synonym = @engg_sec_btsynname
				)
		BEGIN
			SELECT @msg = 'Node type defined for the Section : ''' + @engg_sec_btsynname + ''' . Cannot Delete at row no: ' + convert(CHAR(3), @_sec_fpRowNo)

			EXEC engg_error_sp 'ep_maireeSp_scsav_sec',
				1,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			RETURN
		END

		--Code added By Jeya for Dynamic Section Starts
		IF @modeflag = 'D'
			AND @engg_sec_type = 'Dynamic'
			AND EXISTS (
				SELECT 'A'
				FROM ep_dynamic_sec_control_map(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND activity_name = @tmp_act
					AND ui_name = @tmp_ui
					AND page_bt_synonym = @engg_sec_page_bts
					AND section_bt_synonym = @engg_sec_btsynname
				)
		BEGIN
			SELECT @msg = 'Controls are mapped for the Section : ''' + @engg_sec_btsynname + ''' . Cannot Delete at row no: ' + convert(CHAR(3), @_sec_fpRowNo)

			EXEC engg_error_sp 'ep_maireeSp_scsav_sec',
				1,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			RETURN
		END

		--Code added By Jeya for Dynamic Section End
		--code added for the call id  : PNR2.0_13810
		--Kanagavel
		--For each row, if Section BTSynonym Name already exists for another Page or Section or control or Grid Control, display error message.
		-- code commented by shafinaon 16-Nov-2004 for PREVIEWENG203SYS_000178 (Unable to delete the controls in specifylayout. Platform has accepted same control name for both Page Name and controls. It didnt validate while creating, but on deletion it 
		--validates)
		IF @modeflag IN (
				'I',
				'X'
				)
			AND EXISTS (
				SELECT 'A'
				FROM ep_ui_page_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND activity_name = @tmp_act
					AND ui_name = @tmp_ui
					--    and  page_bt_synonym  = @engg_sec_page_bts
					AND page_bt_synonym = @engg_sec_btsynname
				)
		BEGIN
			SELECT @msg = 'Synonym ' + @engg_sec_btsynname + ' already exists in the UI as a Page Bt Synonym'

			EXEC engg_error_sp 'ep_maireeSp_scsav_sec',
				1,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			RETURN
		END

		IF @modeflag IN (
				'I',
				'X'
				)
		BEGIN
			IF EXISTS (
					SELECT 'A'
					FROM ep_ui_section_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_base_req_no
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND activity_name = @tmp_act
						AND ui_name = @tmp_ui
						--and page_bt_synonym   = @engg_sec_page_bts
						AND section_bt_synonym = @engg_sec_btsynname
					)
			BEGIN
				SELECT @msg = 'Synonym ' + @engg_sec_btsynname + ' already exists in the UI as a Section Bt Synonym'

				RAISERROR (
						@msg,
						16,
						1
						)

				RETURN
			END
		END

		/* code changes for the Bug id:PLF2.0_07428 starts */
		IF @modeflag IN ('I')
			AND EXISTS (
				SELECT 'A'
				FROM ep_ui_section_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND activity_name = @tmp_act
					AND ui_name = @tmp_ui
					--and	page_bt_synonym = @engg_sec_page_bts
					AND section_bt_synonym = @engg_sec_btsynname
				)
		BEGIN
			SELECT @msg = 'Synonym ' + @engg_sec_btsynname + ' already exists in the UI as a Section Bt Synonym'

			EXEC engg_error_sp 'ep_maireeSp_scsav_sec',
				1,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			RETURN
		END

		IF @modeflag IN (
				'I',
				'X'
				)
			AND EXISTS (
				SELECT 'A'
				FROM ep_ui_control_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND activity_name = @tmp_act
					AND ui_name = @tmp_ui
					--and	page_bt_synonym = @engg_sec_page_bts
					AND control_bt_synonym = @engg_sec_btsynname
				)
		BEGIN
			SELECT @msg = 'Synonym ' + @engg_sec_btsynname + ' already exists in the UI as a Control Bt Synonym'

			EXEC engg_error_sp 'ep_maireeSp_scsav_sec',
				1,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			RETURN
		END

		/* code changes for the Bug id:PLF2.0_07428 End */
	
		IF (@engg_sec_Type = 'ListItem')
			AND NOT EXISTS (
				SELECT 'X'
				FROM ep_ui_mst(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND activity_name = @tmp_act
					AND ui_name = @tmp_ui
					AND devicetype IN (
						'P',
						'B',
						'T'
						)
				)
		BEGIN
			RAISERROR (
					'ListItem section is applicable only for Mobile UIs',
					16,
					1
					)

			RETURN
		END

		--Commented for defectid TECH-69575 starts
		----IF (@engg_sec_Type = 'ListItem')
		----	AND NOT EXISTS (
		----		SELECT 'X'
		----		FROM ep_ui_mst(NOLOCK)
		----		WHERE customer_name = @engg_customer_name
		----			AND project_name = @engg_project_name
		----			AND req_no = @engg_base_req_no
		----			AND process_name = @tmp_proc
		----			AND component_name = @tmp_comp
		----			AND activity_name = @tmp_act
		----			AND ui_name = @tmp_ui
		----			AND NativeApplication = 'Y'
		----		)
		----BEGIN
		----	RAISERROR (
		----			'ListItem section is applicable only for ''Native Application'' enabled Mobile UIs',
		----			16,
		----			1
		----			)

		----	RETURN
		----END
		--Commented for defectid TECH-69575 starts


		IF ISNULL(@engg_AssociatedControl, '') <> ''
			AND @engg_sec_Type = 'ListItem'
		BEGIN
			IF NOT EXISTS (
					SELECT 'X'
					FROM ep_ui_control_dtl ctl(NOLOCK),
						es_comp_ctrl_Type_mst typ(NOLOCK)
					WHERE ctl.customer_name = @engg_customer_name
						AND ctl.project_name = @engg_project_name
						AND ctl.req_no = @engg_base_req_no
						AND ctl.process_name = @tmp_proc
						AND ctl.component_name = @tmp_comp
						AND ctl.activity_name = @tmp_act
						AND ctl.ui_name = @tmp_ui
						AND ctl.control_bt_synonym = @engg_AssociatedControl
						AND ctl.customer_name = typ.customer_name
						AND ctl.project_name = typ.project_name
						AND ctl.process_name = typ.process_name
						AND ctl.component_name = typ.component_name
						AND ctl.control_type = typ.ctrl_type_name
						AND typ.base_ctrl_type = 'Grid'
					)
			BEGIN
				RAISERROR (
						'ListItem section can be associated with only Grid Controls. Error at Row No: %i',
						16,
						1,
						@_sec_fpRowNo
						)

				RETURN
			END

			IF EXISTS (
					SELECT 'X'
					FROM ep_ui_section_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_base_req_no
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND activity_name = @tmp_act
						AND ui_name = @tmp_ui
						AND page_bt_synonym = @engg_sec_page_bts
						AND Associated_control = @engg_AssociatedControl
						AND section_type = 'ListItem'
					)
			BEGIN
				RAISERROR (
						'Same Grid control cannot be associated with more than one ListItem section. Error at Row No: %i',
						16,
						1,
						@_sec_fpRowNo
						)

				RETURN
			END
		END

		IF @modeflag IN (
				'I',
				'X'
				)
			AND EXISTS (
				SELECT 'A'
				FROM ep_ui_grid_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND activity_name = @tmp_act
					AND ui_name = @tmp_ui
					--and page_bt_synonym	= @engg_sec_page_bts
					AND column_bt_synonym = @engg_sec_btsynname
				)
		BEGIN
			SELECT @msg = 'Synonym ' + @engg_sec_btsynname + ' already exists in the UI as a Column Bt Synonym'

			EXEC engg_error_sp 'ep_maireeSp_scsav_sec',
				1,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			RETURN
		END

		-- Code added for Defect Id TECH-16126 starts
		IF isnull(@engg_sec_type, '') = 'MobileGrid'
		BEGIN
			IF EXISTS (
					SELECT 'x'
					FROM ep_ui_mst(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND activity_name = @tmp_act
						AND ui_name = @tmp_ui
						AND DeviceType NOT IN (
							'P',
							'T',
							'B'
							)
					)
			BEGIN
				RAISERROR (
						'Applicable Device Type should be Phone to enable MobileGrid Section Type. ',
						16,
						1
						)

				RETURN
			END

			IF EXISTS (
					SELECT 'x'
					FROM ep_ui_grid_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND activity_name = @tmp_act
						AND ui_name = @tmp_ui
						AND page_bt_synonym = @engg_sec_page_bts
						AND section_bt_synonym = @engg_sec_btsynname
					)
			BEGIN
				SELECT @msg = 'Section BT synonym ' + @engg_sec_btsynname + ' is in use. Cannot Delete. at row no: ' + convert(CHAR(3), @_sec_fpRowNo)

				RAISERROR (
						@msg,
						16,
						1
						)

				RETURN
			END

			-- Code added for Defect Id: TECH-19347 starts
			IF isnull(@sectionheight, '') = ''
			BEGIN
				RAISERROR (
						' Please Specify Section Height for Mobile Grid Section. Error at Row no.',
						16,
						1,
						@_sec_fpRowNo
						)

				RETURN
			END
					-- Code added for Defect Id: TECH-19347 ends
		END

		-- Code added for Defect Id TECH-16126 ends
		------------------------------11742
		IF isnull(@engg_sec_type, '') = 'PopOver'
		BEGIN
			IF EXISTS (
					SELECT 'x'
					FROM ep_ui_mst(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND activity_name = @tmp_act
						AND ui_name = @tmp_ui
						AND DeviceType NOT IN (
							'P',
							'T'
							)
					)
			BEGIN
				RAISERROR (
						'Section Type  Popover is applicable only for Tablet/Phone. ',
						16,
						1
						)

				RETURN
			END
		END

		-----11742
		-- code modified by shafina on 01-Sep-2004 for PREVIEWENG203ACC_000095 (When a new BT synonym is entered , it must be checked whether it exists as a hidden view already.)
		IF @modeflag IN (
				'I',
				'X'
				)
			AND EXISTS (
				SELECT 'A'
				FROM de_hidden_view(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					--and req_no			= @engg_base_req_no
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND activity_name = @tmp_act
					AND ui_name = @tmp_ui
					--and page_name			= @engg_sec_page_bts
					AND control_bt_synonym = @engg_sec_btsynname
				)
		BEGIN
			SELECT @msg = 'Synonym ' + @engg_sec_btsynname + ' already exists in the UI as a Hidden View Bt Synonym'

			EXEC engg_error_sp 'ep_maireeSp_scsav_sec',
				1,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			RETURN
		END

		-- code modified by shafina on 10-Dec-2004 for PREVIEWENG203ACC_000095 (When a new BT synonym is entered , it must be checked whether it exists as a scratch variable already.)
		IF @modeflag IN (
				'I',
				'X'
				)
			AND EXISTS (
				SELECT 'A'
				FROM de_scratch_variable(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND activity_name = @tmp_act
					AND ui_name = @tmp_ui
					--and page_name			= @engg_sec_page_bts
					AND scratch_name = @engg_sec_btsynname
				)
		BEGIN
			SELECT @msg = 'Synonym ' + @engg_sec_btsynname + ' already exists in the UI as a User Defined Scratch Variable'

			EXEC engg_error_sp 'ep_maireeSp_scsav_sec',
				1,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			RETURN
		END

		-- Code Modified by Hamsika for the Bug ID : Platform_2.0.3.1_299(PDEV_274)
		IF @Modeflag IN (
				'I',
				'X',
				'U',
				'Y'
				)
		BEGIN
			IF LEN(LTRIM(RTRIM(@engg_sec_btsynname))) > 0
			BEGIN
				IF EXISTS (
						SELECT 'X'
						FROM DE_META_VBKEYWORDS(NOLOCK)
						WHERE KEYWORD = @engg_sec_btsynname
						)
				BEGIN
					EXEC ENGG_ERROR_SP 'ep_maireeSp_scsav_sec',
						102,
						'Keyword not Allowed as a Parameter',
						@CTXT_LANGUAGE,
						@CTXT_OUINSTANCE,
						@CTXT_SERVICE,
						@CTXT_USER,
						NULL,
						NULL,
						NULL,
						NULL,
						@m_errorid OUTPUT

					IF @m_errorid <> 0
						RETURN
				END
			END
		END

		-- Code Modified by Hamsika for the Bug ID : Platform_2.0.3.1_299(PDEV_274)
		-- code modified by shafina on 06-Dec-2004 for PREVIEWPF204ACC_000001 (Default Scratch variables must not be used as user defined bt synonyms.)
		IF EXISTS (
				SELECT 'x'
				FROM de_scratch_variables_sys(NOLOCK)
				WHERE btsynonym = @engg_sec_btsynname
				)
			-- code modified by shafina on 22-Dec-2004 for PREVIEWENG203ACC_000115 (Modeflag must not be allowed to be entered as bt synonym.)
			OR @engg_sec_btsynname = 'Modeflag'
		BEGIN
			SELECT @msg = 'Section Bt Synonym ' + @engg_sec_btsynname + ' already exists as a Default Scratch Variable'

			EXEC engg_error_sp 'en_comp_sp_savcon_hsv',
				7,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			RETURN
		END

		-- code addded by Anu -- start
		IF @Modeflag <> 'D'
		BEGIN
			-- code addded by Anu -- end
			IF @engg_sec_bord_req = '1'
			BEGIN
				SELECT @engg_sec_bord_req = 'y'
			END
			ELSE
			BEGIN
				SELECT @engg_sec_bord_req = 'n'
			END

			IF @engg_sec_title_req = '1'
			BEGIN
				SELECT @engg_sec_title_req = 'y'
			END
			ELSE
			BEGIN
				SELECT @engg_sec_title_req = 'n'
			END

			--if @isstatic = '1'
			--begin
			--select @isstatic = 'y'
			--end
			--else
			--begin
			--select @isstatic = 'n'
			--end
			IF @sectionheight IS NULL
				OR @sectionheight = '-915'
				SET @sectionheight = ''

			IF @sectionwidth IS NULL
				OR @sectionwidth = '-915'
				SET @sectionwidth = 100

			DECLARE @sectionheight_temp engg_name,
				@sectionwidth_temp engg_name

			SET @sectionheight_temp = @sectionheight
			SET @sectionwidth_temp = @sectionwidth

			-- code addded by Anu -- start
			IF LOWER(@engg_sec_visible) = 'n'
				AND @engg_sec_type = 'Tree'
			BEGIN
				RAISERROR (
						'Visible Property should be selected if Section Type is Tree',
						16,
						1
						)

				RETURN
			END

			IF LOWER(@engg_sec_visible) = 'n'
				AND @engg_sec_type = 'chart'
			BEGIN
				RAISERROR (
						'Visible Property should be selected if Section Type is chart',
						16,
						1
						)

				RETURN
			END
		END

		-- code addded by Anu -- end
		-- code modified by shafina on 12-Apr-2004 for PREVIEWENG203ACC_000028
		--  if @engg_sec_title_align = 'Center'
		--  begin
		--   select @engg_sec_title_align = 'Centr'
		--  end

		IF isnull(@sectionwidth, '') <> ''
		BEGIN
			IF isnumeric(left(@sectionwidth, 1)) <> 1
			BEGIN
				SELECT @msg = 'Data Column Width for Row ' + convert(CHAR(5), @_sec_fpRowNo) + ' must start with a number'

				EXEC ENGG_ERROR_SP 'ep_layout_sp_savctlcnml',
					11,
					@msg,
					@CTXT_LANGUAGE,
					@CTXT_OUINSTANCE,
					@CTXT_SERVICE,
					@CTXT_USER,
					'',
					'',
					'',
					'',
					@M_ERRORID OUTPUT

				RETURN
			END

			SELECT @sectionwidth = replace(@sectionwidth, ' ', '')

			SELECT @d_cnt = 1

			WHILE (1 = 1)
			BEGIN
				SELECT @d_char = substring(@sectionwidth, @d_cnt, 1)

				IF isnumeric(@d_char) = 1
				BEGIN
					SELECT @d_num = isnull(@d_num, '') + @d_char

					SELECT @d_cnt = @d_cnt + 1
				END
				ELSE
				BEGIN
					BREAK
				END
			END

			SELECT @Section_width_Scalemode = substring(@sectionwidth, @d_cnt, len(@sectionwidth) - @d_cnt + 1)

			SELECT @sectionwidth = @d_num

			-- code modified by shafina on 18-feb-2005 for PREVIEWPFSUPPORT_000012 (When scale mode is not specified for column width , '%' must be taken as default scale mode)
			IF isnull(@Section_width_Scalemode, '') = ''
				SELECT @Section_width_Scalemode = '%'

			-- code modified by shafina on 18-feb-2005 for PREVIEWPFSUPPORT_000012 (When scale mode is not specified for column width , '%' must be taken as default scale mode)
			IF @modeflag <> 'D'
			BEGIN
				IF Charindex('%', @sectionheight_temp) <> 0
				BEGIN
					RAISERROR (
							'Section Height Can only be given in Pixels',
							16,
							1
							)

					RETURN
				END

				IF Charindex('px', @sectionwidth_temp) <> 0
					AND @engg_sec_type NOT IN (
						'Tree',
						'Chart'
						)
					AND @engg_sect_lay NOT IN ('absolute')
				BEGIN
					RAISERROR (
							'Section Width in Pixels is applicable only for Tree and Chart Sections',
							16,
							1
							)

					RETURN
				END
						--if Charindex('%',@sectionwidth_temp) <> 0  and @engg_sec_type in ('Tree', 'Chart')
						--	begin 
						--	Raiserror('Section Width in Percentage is not applicable for Tree and Chart Sections',16,1)
						--Return
						--end			
			END

			IF @Section_width_Scalemode NOT IN (
					'Px',
					'C',
					'%'
					)
			BEGIN
				SELECT @msg = 'Data Scale Mode must be Px , C or % for Row ' + convert(CHAR(5), @_sec_fpRowNo)

				EXEC ENGG_ERROR_SP 'ep_layout_sp_savctlcnml',
					11,
					@msg,
					@CTXT_LANGUAGE,
					@CTXT_OUINSTANCE,
					@CTXT_SERVICE,
					@CTXT_USER,
					'',
					'',
					'',
					'',
					@M_ERRORID OUTPUT

				RETURN
			END
		END

		IF isnull(@sectionheight, '') <> ''
		BEGIN
			IF isnumeric(left(@sectionheight, 1)) <> 1
			BEGIN
				SELECT @msg = 'Label Column Width for Row ' + convert(CHAR(5), @_sec_fpRowNo) + ' must start with a number'

				EXEC ENGG_ERROR_SP 'ep_layout_sp_savctlcnml',
					11,
					@msg,
					@CTXT_LANGUAGE,
					@CTXT_OUINSTANCE,
					@CTXT_SERVICE,
					@CTXT_USER,
					'',
					'',
					'',
					'',
					@M_ERRORID OUTPUT

				RETURN
			END

			SELECT @sectionheight = replace(@sectionheight, ' ', '')

			SELECT @l_cnt = 1

			WHILE (1 = 1)
			BEGIN
				SELECT @l_char = substring(@sectionheight, @l_cnt, 1)

				IF isnumeric(@l_char) = 1
				BEGIN
					SELECT @l_num = isnull(@l_num, '') + @l_char

					SELECT @l_cnt = @l_cnt + 1
				END
				ELSE
				BEGIN
					BREAK
				END
			END

			SELECT @Section_height_Scalemode = substring(@sectionheight, @l_cnt, len(@sectionheight) - @l_cnt + 1)

			SELECT @sectionheight = @l_num

			-- code modified by shafina on 18-feb-2005 for PREVIEWPFSUPPORT_000012 (When scale mode is not specified for column width , '%' must be taken as default scale mode)
			IF isnull(@Section_height_Scalemode, '') = ''
				SELECT @Section_height_Scalemode = 'px'

			-- code modified by shafina on 18-feb-2005 for PREVIEWPFSUPPORT_000012 (When scale mode is not specified for column width , '%' must be taken as default scale mode)
			IF @Section_height_Scalemode NOT IN (
					'Px',
					'C',
					'%'
					)
			BEGIN
				SELECT @msg = 'Label Scale Mode must be Px , C or % for Row ' + convert(CHAR(5), @_sec_fpRowNo)

				EXEC ENGG_ERROR_SP 'ep_layout_sp_savctlcnml',
					11,
					@msg,
					@CTXT_LANGUAGE,
					@CTXT_OUINSTANCE,
					@CTXT_SERVICE,
					@CTXT_USER,
					'',
					'',
					'',
					'',
					@M_ERRORID OUTPUT

				RETURN
			END
		END

		IF @engg_sect_lay NOT IN (
				'absolute',
				'Column'
				)
			AND isnull(@engg_sec_lay_con, '') <> ''
		BEGIN
			RAISERROR (
					'Layout Configuration Can have values only when Section Layout is "Absolute" or "Column". Error in Row %i',
					16,
					4,
					@_sec_fpRowNo
					)

			RETURN
		END

		IF @engg_sect_lay IN (
				'absolute',
				'Column'
				)
			AND isnull(@engg_sec_lay_con, '') = ''
		BEGIN
			RAISERROR (
					'Layout Configuration needs to have value when Section Layout is "Column" or "Absolute".Kindly provide a value in Row %i',
					16,
					4,
					@_sec_fpRowNo
					)

			RETURN
		END

		IF @engg_sect_lay = 'absolute'
		BEGIN
			DECLARE @len1 engg_seqno,
				@len2 engg_seqno

			IF @engg_sect_lay = 'absolute'
				AND isnull(@engg_sec_lay_con, '') NOT LIKE '%~%'
			BEGIN
				RAISERROR (
						'For layout configuration, X and Y Coordinates needs to be given with Delimiters.(Ex: 50~80).Error in Row %i',
						16,
						4,
						@_sec_fpRowNo
						)

				RETURN
			END

			IF isnumeric(isnull(LEFT(@engg_sec_lay_con, CHARINDEX('~', @engg_sec_lay_con) - 1), - 915)) = 0
				OR isnumeric(isnull(RIGHT(@engg_sec_lay_con, LEN(@engg_sec_lay_con) - CHARINDEX('~', @engg_sec_lay_con)), - 915)) = 0
			BEGIN
				RAISERROR (
						'For layout configuration, X and Y Coordinates needs to be integer value greater than 0 given with Delimiters.(Ex: 50~80).Error in Row %i',
						16,
						4,
						@_sec_fpRowNo
						)

				RETURN
			END

			SELECT @len1 = convert(INT, LEFT(@engg_sec_lay_con, CHARINDEX('~', @engg_sec_lay_con) - 1)),
				@len2 = convert(INT, RIGHT(@engg_sec_lay_con, LEN(@engg_sec_lay_con) - CHARINDEX('~', @engg_sec_lay_con)))

			IF @engg_sect_lay = 'absolute'
				AND (
					@len1 < 1
					OR @len2 < 1
					)
			BEGIN
				RAISERROR (
						'For layout configuration, X and Y Coordinates needs to be given with Delimiters.(Ex: 50~80).Error in Row %i',
						16,
						4,
						@_sec_fpRowNo
						)

				RETURN
			END
		END

		IF @engg_sect_lay = 'absolute'
			SELECT @XYCoordinate = isnull(@engg_sec_lay_con, '')

		IF @engg_sect_lay = 'Column'
			SELECT @ColLayWid = isnull(@engg_sec_lay_con, '')

		SELECT @engg_sect_lay = parameter_code
		FROM ep_device_quick_code_met(NOLOCK)
		WHERE parameter_type = 'SectionLayout'
			AND parameter_text = @engg_sect_lay

		SELECT @engg_region = parameter_code
		FROM ep_device_quick_code_met(NOLOCK)
		WHERE parameter_type = 'Region'
			AND parameter_text = @engg_region

		SELECT @engg_col_dir = parameter_code
		FROM ep_device_quick_code_met(NOLOCK)
		WHERE parameter_type = 'TabTitleStyle'
			AND parameter_text = @engg_col_dir

		SELECT @engg_title_pos = parameter_code
		FROM ep_device_quick_code_met(NOLOCK)
		WHERE parameter_type = 'TitlePosition'
			AND parameter_text = @engg_title_pos

		--TECH-69624
		IF ISNULL(@modeflag,'') IN ('I','X','U','Y') AND ISNULL(@engg_sect_forresponsive,0)<>0
		BEGIN
			IF EXISTS
			(SELECT 'X'
			 FROM	ep_ui_page_dtl WITH (NOLOCK)
			 WHERE  customer_name	= @engg_customer_name
			 AND	project_name	= @engg_project_name
			 AND	process_name	= @tmp_proc
			 AND	component_name	= @tmp_comp
			 AND	activity_name	= @tmp_act
			 AND	ui_name			= @tmp_ui
			 AND	page_bt_synonym = @engg_sec_page_bts
			 AND	pagelayout		<> 'Responsive')
			 OR	    (ISNULL(@engg_sect_lay,'')  <> 'Responsive')
			 BEGIN
				RAISERROR('Page layout & Section layout should be ''Responsive'' at rowno: %i',16,1,@_sec_fprowno)
				RETURN
			 END
		END

		--TECH-69624

		--Tech-73996
		IF ISNULL(@modeflag,'')	IN	('U','Y') AND @engg_sec_visible	=	'n'
					BEGIN
						IF EXISTS ( SELECT 'X'
									FROM	ep_ui_state_section_dtl WITH(NOLOCK)
									WHERE	customer_name		=	@engg_customer_name
									AND		project_name		=	@engg_project_name
									AND		process_name		=	@tmp_proc
									AND		component_name		=	@tmp_comp
									AND		activity_name		=	@tmp_act
									AND		ui_name				=	@tmp_ui
									AND		page_bt_synonym		=	@engg_sec_page_bts
									AND		section_bt_synonym	=	@engg_sec_btsynname )
							BEGIN
									RAISERROR('Selected Section ''%s'' cannot be made as hidden.Since it is involved in RT State.Error at rowno: %i.',16,1,@engg_sec_btsynname,@_sec_fprowno)
							END

					IF EXISTS(	SELECT	'X'
								FROM	iruledb..fw_req_ilbo_rule_property_stmt  a WITH(NOLOCK)
								JOIN	iruledb..fw_req_ilbo_rule_property_value	b WITH(NOLOCK)
								ON		a.CustomerName	=	b.customername
								and		a.projectname	=	b.projectname
								and		a.ComponentName	=	b.ComponentName
								and		a.ILBOCode		=	b.ILBOCode
								and		a.StmtID		=	b.StmtID
								WHERE	a.CustomerName	=	@engg_customer_name
								AND		a.ProjectName	=	@engg_project_name
								AND		a.ComponentName	=	@tmp_comp
								AND		a.ILBOCode		=	@tmp_ui
								AND		a.SectionName	=	@engg_sec_btsynname
								and		b.PropertyName	=	'Hide'
								and		b.PropertyValue	=	'true' )
							BEGIN
								RAISERROR('Selected Section ''%s'' cannot be made as hidden.Since it is involved in iRule State.Error at rowno: %i.',16,1,@engg_sec_btsynname,@_sec_fprowno)
							RETURN
							END
			END	
		--Tech-73996

		--TECH-70687
		DECLARE @max_horder engg_seqno

		IF ISNULL(@modeflag,'') IN ('I','X','U','Y') AND ISNULL(@engg_sec_minrows,0)<>0
		BEGIN
			 SELECT @max_horder =  MAX(horder)
			 FROM	ep_ui_control_dtl WITH (NOLOCK)
			 WHERE  customer_name	= @engg_customer_name
			 AND	project_name	= @engg_project_name
			 AND	process_name	= @tmp_proc
			 AND	component_name	= @tmp_comp
			 AND	activity_name	= @tmp_act
			 AND	ui_name			= @tmp_ui
			 AND	page_bt_synonym = @engg_sec_page_bts
			 AND	section_bt_synonym = @engg_sec_btsynname

			 IF @engg_sec_minrows > @max_horder
			 BEGIN
				RAISERROR('Minimized rows should not be greater than number of rows in section ''%s'' at rowno: %i',16,1,@engg_sec_btsynname,@_sec_fprowno)
				RETURN
			 END
		END
		--TECH-70687

		----Code added by 14469 for TECH-73216 starts
		--IF ISNULL(@modeflag,'')	IN ('I','X') 
		--AND EXISTS (SELECT 'X' 
		--FROM ep_ui_page_dtl (NOLOCK)
		--WHERE  customer_name	= @engg_customer_name
		--AND	   project_name		= @engg_project_name
		--AND	   req_no			= @engg_base_req_no
		--AND	   page_bt_synonym  = @engg_sec_btsynname
		--UNION
		--SELECT 'X' 
		--FROM ep_ui_section_dtl (NOLOCK)
		--WHERE  customer_name	= @engg_customer_name
		--AND	   project_name		= @engg_project_name
		--AND	   req_no			= @engg_base_req_no
		--AND	   section_bt_synonym  = @engg_sec_btsynname
		--UNION
		--SELECT 'X' 
		--FROM ep_ui_control_dtl (NOLOCK)
		--WHERE  customer_name	= @engg_customer_name
		--AND	   project_name		= @engg_project_name
		--AND	   req_no			= @engg_base_req_no
		--AND	   control_bt_synonym  = @engg_sec_btsynname
		--UNION
		--SELECT 'X' 
		--FROM ep_ui_grid_dtl (NOLOCK)
		--WHERE  customer_name	= @engg_customer_name
		--AND	   project_name		= @engg_project_name
		--AND	   req_no			= @engg_base_req_no
		--AND	   column_bt_synonym  = @engg_sec_btsynname
		--UNION
		--SELECT 'X' 
		--FROM de_hidden_view (NOLOCK)
		--WHERE  customer_name	= @engg_customer_name
		--AND	   project_name		= @engg_project_name
		--AND	   control_bt_synonym = @engg_sec_btsynname)
		--BEGIN
		--	RAISERROR ('Btsynonym name should be unique for Customer Project level.',16,1)
		--	RETURN
		--END
		--Code added by 14469 for TECH-73216 ends


		-- code added by Anu -- start
		IF @Modeflag <> 'D'
		BEGIN
			IF @Modeflag IN (
					'U',
					'Y'
					)
			BEGIN
				SELECT @sect_type = section_type
				FROM ep_ui_section_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND activity_name = @tmp_act
					AND ui_name = @tmp_ui
					AND page_bt_synonym = @engg_sec_page_bts
					AND section_bt_synonym = @engg_sec_btsynname

				IF (@engg_sec_type = 'Main')
					AND (@sect_type = 'tree') --or (@sect_type = 'chart'))
				BEGIN
					DECLARE @control_name engg_name

					SELECT @control_name = control_bt_synonym
					FROM ep_ui_control_dtl
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_base_req_no
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND activity_name = @tmp_act
						AND ui_name = @tmp_ui
						AND page_bt_synonym = @engg_sec_page_bts
						AND section_bt_synonym = @engg_sec_btsynname

					DELETE
					FROM ep_action_mst
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND activity_name = @tmp_act
						AND ui_name = @tmp_ui
						AND page_bt_synonym = @engg_sec_page_bts
						AND primary_control_bts = @control_name

					DELETE
					FROM ep_action_mst_lng_extn
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND activity_name = @tmp_act
						AND ui_name = @tmp_ui
						AND page_bt_synonym = @engg_sec_page_bts
						AND primary_control_bts = @control_name

					DELETE
					FROM ep_component_glossary_mst
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND bt_synonym_name = @control_name

					DELETE
					FROM ep_component_glossary_mst_lng_extn
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND bt_synonym_name = @control_name

					DELETE
					FROM ep_ui_control_dtl
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_base_req_no
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND activity_name = @tmp_act
						AND ui_name = @tmp_ui
						AND page_bt_synonym = @engg_sec_page_bts
						AND section_bt_synonym = @engg_sec_btsynname
				END

				--end
				-- code added by Anu -- End
				IF EXISTS (
						SELECT 'A'
						FROM ep_ui_section_dtl(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND req_no = @engg_base_req_no
							AND process_name = @tmp_proc
							AND component_name = @tmp_comp
							AND activity_name = @tmp_act
							AND ui_name = @tmp_ui
							AND page_bt_synonym = @engg_sec_page_bts
							AND section_bt_synonym = @engg_sec_btsynname
						)
				BEGIN
					--Code Added by Swaminathan R. on 01/10/2005 Starts
					IF LOWER(@engg_sec_visible) = 'n'
						AND @engg_sec_type = 'Tree'
					BEGIN
						RAISERROR (
								'Visible Property should be selected if Section Type is Tree',
								16,
								1
								)

						RETURN
					END

					IF (@engg_associatedcontrol IS NOT NULL)
						SET @engg_associatedcontrol = LOWER(@engg_associatedcontrol)

					--Code Added by Swaminathan R. on 01/10/2005 Ends
					/*
If @IsStatic = 1
	set @IsStatic = 'y'
else
	set @IsStatic = 'n'*/

					UPDATE ep_ui_section_dtl
					SET visisble_flag = @engg_sec_visible,
						title_required = @engg_sec_title_req,
						border_required = @engg_sec_bord_req,
						section_doc = @engg_sect_doc,
						title_alignment = @engg_sec_title_align,
						ctrl_caption_align = @engg_sec_cap_align, -- @engg_ctrl_caption_align,
						caption_Format = @engg_sec_cap_format,
						Section_width_Scalemode = @Section_width_Scalemode,
						Section_height_Scalemode = @Section_height_Scalemode,
						SectionPrefixClass = @engg_sec_secpreclass,
						section_type = @engg_sec_type,
						width = @sectionwidth,
						height = @sectionheight,
						section_collapsemode = @Sec_CollapseMode,
						section_collapse = @Sec_Collapse,
						-- code added by shafina on 07-Sep-2004 for PREVIEWENG203ACC_000098 (Modified Date must be updated.)
						modifiedby = @ctxt_user,
						modifieddate = getdate(),
						NColSpan = @section_colspan,
						NRowSpan = @section_rowspan,
						Region = @engg_region,
						TitlePosition = @engg_title_pos,
						CollapseDir = @engg_col_dir,
						SectionLayout = @engg_sect_lay,
						XYCoordinates = @XYCoordinate,
						ColumnLayWidth = @ColLayWid,
						Associated_Control = @engg_associatedcontrol,
						---CODE ADDED BY 13639  STARTS---
						IsResponsive     = CASE WHEN @engg_mob_responsive = '1' THEN 'Y'
												WHEN @engg_mob_responsive = '0' THEN 'N'
											END,
						mob_pop_fullview  = CASE WHEN @engg_mob_fullview = '1' THEN 'Y'
												WHEN @engg_mob_fullview = '0' THEN 'N'
											END	,	
														
						--CODE ADDED BY 13639  ENDS---
						--IsStatic	=	@IsStatic
						ForResponsive	=	@engg_sect_forresponsive,	--Code added for TECH-69624
						Orientation		=	@Orientation,				--TECH-75230
						--TECH-70687
						LeftToolbar		= CASE WHEN @engg_sec_lefttb = 1 THEN 'Y' ELSE 'N' END ,
						RightToolbar	= CASE WHEN @engg_sec_righttb  = 1 THEN 'Y' ELSE 'N' END,
						TopToolbar		= CASE WHEN @engg_sec_toptb  = 1 THEN 'Y' ELSE 'N' END,
						BottomToolbar	= CASE WHEN @engg_sec_bottomtb = 1 THEN 'Y' ELSE 'N' END,
						MinimizedRows	= @engg_sec_minrows ,
						ViewMode		= CASE WHEN ISNULL(@engg_sec_minrows,'')='' THEN '' ELSE @engg_sec_vwmode END,
						--TECH-70687
						TitleIcon		= @engg_sec_titleicon		--TECH-72114
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_base_req_no
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND activity_name = @tmp_act
						AND ui_name = @tmp_ui
						AND page_bt_synonym = @engg_sec_page_bts
						AND section_bt_synonym = @engg_sec_btsynname
				END
			END
		END
				
		IF isnull(@engg_sec_type, '') = 'MobileCalendar'
			AND len(@engg_sec_btsynname) > 15 -- changed for the Defect id: TECH-21893
		BEGIN
	
			RAISERROR (
					'Section name cannot exceed 15 characters for Mobile Calendar.',
					16,
					1
					)

			RETURN
		END

		IF NOT EXISTS (
				SELECT 'A'
				FROM ep_ui_section_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND activity_name = @tmp_act
					AND ui_name = @tmp_ui
					AND page_bt_synonym = @engg_sec_page_bts
					AND section_bt_synonym = @engg_sec_btsynname
				)
		BEGIN
			EXEC ep_ui_section_dtl_sp_ins @ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@engg_customer_name,
				@engg_project_name,
				@engg_base_req_no,
				@tmp_proc,
				@tmp_comp,
				@tmp_act,
				@tmp_ui,
				@engg_sec_page_bts,
				@engg_sec_btsynname,
				@engg_sec_visible, --Code Commented by Swaminathan R. on 01/10/2005--added by shriram  for PNR2.0_6125
				--'y' ,      -- Code Added by Swaminathan R. on 01/10/2005--code commented by shriram for PNR2.0_6125
				@engg_sec_title_req,
				@engg_sec_bord_req,
				@engg_sec_title_align,
				'',
				0,
				0,
				@engg_sect_doc,
				1,
				@engg_sec_type,
				@engg_sec_cap_align,
				@engg_sec_cap_format,
				@sectionheight,
				@sectionwidth,
				@Section_width_Scalemode,
				@Section_height_Scalemode,
				@Sec_CollapseMode, --shakthi
				@Sec_Collapse,
				@engg_req_no, --chan,
				@section_rowspan,
				@section_colspan, --@IsStatic,
				@engg_region,
				@engg_title_pos,
				@engg_col_dir,
				@engg_sect_lay,
				@XYCoordinate,
				@ColLayWid,
				@engg_associatedcontrol,	
				@engg_mob_fullview,
				@engg_mob_responsive,
				@engg_sect_forresponsive,	--Code added for TECH-69624
				@Orientation,				--TECH-75230
				--TECH-70687
				@engg_sec_bottomtb,
				@engg_sec_toptb,
				@engg_sec_righttb,
				@engg_sec_lefttb,
				@engg_sec_minrows,
				@engg_sec_vwmode,
				--TECH-70687
				@engg_sec_titleicon, --TECH-72114
				@m_errorid OUTPUT

			-----CODE ADDED BY 13639  STARTS---
				UPDATE ep_ui_section_dtl set SectionPrefixClass     = @engg_sec_secpreclass										
				WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_base_req_no
				AND process_name = @tmp_proc
				AND component_name = @tmp_comp
				AND activity_name = @tmp_act
				AND ui_name = @tmp_ui
				AND page_bt_synonym = @engg_sec_page_bts
				AND section_bt_synonym = @engg_sec_btsynname
			--			---CODE ADDED BY 13639  ENDS---

			/* Code  added by hema for Extjs insert starts here -- PNR2.0_1790*/
			---
			IF @Modeflag IN (
					'I',
					'X'
					)
			BEGIN
				SELECT @devicetype = ''

				SELECT @Devicetype = isnull(devicetype, '')
				FROM ep_ui_mst(NOLOCK)
				WHERE customer_name = rtrim(@engg_customer_name)
					AND project_name = rtrim(@engg_project_name)
					AND req_no = rtrim(@engg_base_req_no)
					AND process_name = rtrim(@tmp_proc)
					AND component_name = rtrim(@tmp_comp)
					AND activity_name = rtrim(@tmp_act)
					AND ui_name = rtrim(@tmp_ui)

				IF isnull(@devicetype, '') = ''
					SELECT @phone_in = NULL,
						@tablet_in = NULL

				IF isnull(@devicetype, '') = 'P'
					SELECT @phone_in = 1,
						@tablet_in = NULL

				IF isnull(@devicetype, '') = 'T'
					SELECT @phone_in = NULL,
						@tablet_in = 1

				IF isnull(@devicetype, '') = 'B'
					SELECT @phone_in = 1,
						@tablet_in = 1
						--Exec ep_layout_phone_tablet_ins_sp 
						--@ctxt_language,
						--@ctxt_ouinstance,
						--@ctxt_service,
						--@ctxt_user,
						--@tmp_act,
						--@tmp_comp,
						--@engg_customer_name,
						--@engg_sec_page_bts,
						--@engg_sec_btsynname,
						--null,
						--null,
						--@tmp_proc,
						--@engg_project_name,
						--@engg_req_no,
						--@tmp_ui,
						--@phone_in,
						--@tablet_in,
						--'Page',
						--null,
						--@m_errorid
						--Exec ep_layout_phone_tablet_ins_sp 
						--Exec ep_layout_phone_ins_sp 
						--@ctxt_language,
						--@ctxt_ouinstance,
						--@ctxt_service,
						--@ctxt_user,
						--@tmp_act,
						--@tmp_comp,
						--@engg_customer_name,
						--@engg_sec_page_bts,
						--@engg_sec_btsynname,
						--null,
						--null,
						--@tmp_proc,
						--@engg_project_name,
						--@engg_req_no,
						--@tmp_ui,
						--@phone_in,
						--@tablet_in,
						--'Section',
						--null,
						--@m_errorid
						--Exec ep_layout_phone_tablet_ins_sp 
						--@ctxt_language,
						--@ctxt_ouinstance,
						--@ctxt_service,
						--@ctxt_user,
						--@tmp_act,
						--@tmp_comp,
						--@engg_customer_name,
						--@engg_sec_page_bts,
						--@engg_sec_btsynname,
						--null,
						--null,
						--@tmp_proc,
						--@engg_project_name,
						--@engg_req_no,
						--@tmp_ui,
						--@phone_in,
						--@tablet_in,
						--'Control',
						--null,
						--@m_errorid
						--Exec ep_layout_phone_tablet_ins_sp 
						--@ctxt_language,
						--@ctxt_ouinstance,
						--@ctxt_service,
						--@ctxt_user,
						--@tmp_act,
						--@tmp_comp,
						--@engg_customer_name,
						--@engg_sec_page_bts,
						--@engg_sec_btsynname,
						--null,
						--null,
						--@tmp_proc,
						--@engg_project_name,
						--@engg_req_no,
						--@tmp_ui,
						--@phone_in,
						--@tablet_in,
						--'Column',
						--null,
						--@m_errorid
			END

			IF @engg_sec_type NOT IN (
					'Main',
					'Tree',
					'Chart',
					'Dynamic'
					)
			BEGIN
				IF NOT EXISTS (
						SELECT 'x'
						FROM ep_ext_js_section_dtl(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND req_no = @engg_base_req_no
							AND process_name = @tmp_proc
							AND component_name = @tmp_comp
							AND activity_name = @tmp_act
							AND ui_name = @tmp_ui
							AND page_bt_synonym = @engg_sec_page_bts
							AND section_bt_synonym = @engg_sec_btsynname
						)
				BEGIN
					INSERT INTO ep_ext_js_section_dtl (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						activity_name,
						ui_name,
						page_bt_synonym,
						section_bt_synonym,
						section_type,
						Section_Width,
						Section_Height,
						Section_Class,
						RVW_Task,
						Callout_Task,
						Direction,
						Scroll_Behaviour,
						Scroll_Delay,
						Fade_Delay,
						No_Of_Columns,
						Report_Item_Class,
						Property_Class,
						Value_Class,
						sample_data,
						wrkreqno,
						createdby,
						createddate,
						modifiedby,
						modifieddate
						)
					SELECT @engg_customer_name,
						@engg_project_name,
						@engg_base_req_no,
						@tmp_proc,
						@tmp_comp,
						@tmp_act,
						@tmp_ui,
						@engg_sec_page_bts,
						@engg_sec_btsynname,
						@engg_sec_type,
						@sectionwidth,
						@sectionheight,
						NULL,
						NULL,
						NULL,
						NULL,
						NULL,
						NULL,
						NULL,
						NULL,
						NULL,
						NULL,
						NULL,
						NULL,
						NULL,
						@ctxt_user,
						getdate(),
						@ctxt_user,
						getdate()
				END
				ELSE
				BEGIN
				--select 'tt', @sectionheight,@sectionwidth
					UPDATE ep_ext_js_section_dtl
					SET Section_Height = @sectionheight,
						Section_Width = @sectionwidth
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_base_req_no
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND activity_name = @tmp_act
						AND ui_name = @tmp_ui
						AND page_bt_synonym = @engg_sec_page_bts
						AND section_bt_synonym = @engg_sec_btsynname
				END
			END

			/* Code  added by hema for Extjs insert ends here -- PNR2.0_1790*/
			IF @m_errorid <> 0
				RETURN

			--  Added By feroz for Extjs generate prefix for section -- PNR2.0_1790
			DECLARE @section_prfx engg_prefix

			EXEC ep_sec_unique_prefix_id @engg_customer_name,
				@engg_project_name,
				@tmp_comp,
				@tmp_act,
				@tmp_ui,
				@engg_sec_btsynname,
				'P',
				4,
				@section_prfx OUTPUT

			UPDATE ep_ui_section_dtl
			SET section_prefix = @section_prfx
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_base_req_no
				AND process_name = @tmp_proc
				AND component_name = @tmp_comp
				AND activity_name = @tmp_act
				AND ui_name = @tmp_ui
				AND page_bt_synonym = @engg_sec_page_bts
				AND section_bt_synonym = @engg_sec_btsynname

			--  Added By feroz for Extjs generate prefix for section -- PNR2.0_1790
			--modified by vasu date:29-12-2003
			-- if section bt synonym is not in glossary, insert it
			-- modified by shafina on 13-jan-2004 to change the length of btsynonym
			DECLARE @btLength engg_seqno

			SELECT @btLength = 20

			IF NOT EXISTS (
					SELECT 'x'
					FROM ep_component_glossary_mst NOLOCK
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_base_req_no
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND bt_synonym_name = @engg_sec_btsynname
					)
			BEGIN
				-- code modified by shafina on 24-feb-2004
				EXEC ep_generate_caption @engg_sec_btsynname,
					@sec_bt_caption OUTPUT

				-- code modified by shafina on 17-June-2004 for PREVIEWENG203ACC_000073
				EXEC ep_component_glossary_mst_sp_ins @ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@engg_customer_name,
					@engg_project_name,
					-- code modified by shafina on 08-July-2004 as req_no is inserted wrongly
					@engg_base_req_no,
					@tmp_proc,
					@tmp_comp,
					@engg_sec_btsynname,
					NULL,
					'Char',
					@btLength,
					@sec_bt_caption,
					@engg_sec_btsynname,
					'',
					'U',
					'',
					'',
					1,
					@engg_req_no, --chan
					@m_errorid OUTPUT

				IF @m_errorid <> 0
					RETURN
			END
		END

		IF @engg_sec_type IN (
				'Main',
				'User Section',
				'ListItem'
				)
			OR @engg_sec_type = 'Dynamic'
		BEGIN
			IF @modeflag = 'D'
			BEGIN
				IF @engg_sec_type = 'User Section'
				BEGIN
					IF EXISTS (
							SELECT 'K'
							FROM ep_user_section_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @tmp_proc
								AND component_name = @tmp_comp
								AND activity_name = @tmp_act
								AND ui_name = @tmp_ui
								AND section_bt_synonym = @engg_sec_btsynname
							)
					BEGIN
						RAISERROR (
								'Kindly unmap the section in user section creation',
								16,
								1
								)

						RETURN
					END
				END

				EXEC ep_ui_section_dtl_sp_del @ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@engg_customer_name,
					@engg_project_name,
					@engg_base_req_no,
					@tmp_proc,
					@tmp_comp,
					@tmp_act,
					@tmp_ui,
					@engg_sec_page_bts,
					@engg_sec_btsynname,
					@m_errorid OUTPUT

				IF @m_errorid <> 0
					RETURN

				---Delete from phone and tablet
				DELETE
				FROM ep_phone_section_dtl
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND activity_name = @tmp_act
					AND ui_name = @tmp_ui
					AND page_bt_synonym = @engg_sec_page_bts
					AND section_bt_synonym = @engg_sec_btsynname

				DELETE
				FROM ep_tablet_section_dtl
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND activity_name = @tmp_act
					AND ui_name = @tmp_ui
					AND page_bt_synonym = @engg_sec_page_bts
					AND section_bt_synonym = @engg_sec_btsynname
					-- modified by vasu date:28-12-2003
					-- to delete the section bt synonym from glossary
					-- modified by shafina on 07-feb-2004 to check for existence of btsynonym
					-- modified by shafina on 09-Apr-2004 for PREVIEWENG203ACC_000013
					/*  declare @count int
select @count = 0
select @count = count('x')
from ep_ui_page_dtl (nolock)
where customer_name = @engg_customer_name
and  project_name = @engg_project_name
and  page_bt_synonym = @engg_sec_btsynname

select @count = @count +
(
select count('x')
from ep_ui_section_dtl (nolock)
where customer_name = @engg_customer_name
and  project_name = @engg_project_name
and  section_bt_synonym = @engg_sec_btsynname
)

select @count = @count +
(
select count('x')
from ep_ui_control_dtl (nolock)
where customer_name = @engg_customer_name
and  project_name = @engg_project_name
and  control_bt_synonym = @engg_sec_btsynname
)

select @count = @count +
(
select count('x')
from ep_ui_grid_dtl (nolock)
where customer_name = @engg_customer_name
and  project_name = @engg_project_name
and  column_bt_synonym = @engg_sec_btsynname
)
if @count  = 0
begin
if exists  (select 'x'
from ep_component_glossary_mst (nolock)
where  customer_name =   @engg_customer_name
and    project_name    =   @engg_project_name
and    req_no          =   @engg_base_req_no
and  process_name =  @tmp_proc
and  component_name =  @tmp_comp
and    bt_synonym_name = @engg_sec_btsynname)
begin
exec ep_component_glossary_mst_sp_del
@ctxt_language,
@ctxt_ouinstance,
@ctxt_service,
@ctxt_user,
@engg_customer_name,
@engg_project_name,
@engg_base_req_no,
@tmp_proc,
@tmp_comp,
@engg_sec_btsynname,
@m_errorid  out

if @m_errorid <> 0
return
end
end*/
			END
		END

		--- Added against TECH-218 starts
		IF @modeflag IN (
				'I',
				'X'
				)
		BEGIN
			IF EXISTS (
					SELECT 'X'
					FROM ep_ui_section_dtl(NOLOCK)
					WHERE customer_name = rtrim(@engg_customer_name)
						AND project_name = rtrim(@engg_project_name)
						AND req_no = rtrim(@engg_req_no)
						AND process_name = rtrim(@tmp_proc)
						AND component_name = rtrim(@tmp_comp)
						AND activity_name = rtrim(@tmp_act)
						AND ui_name = rtrim(@tmp_ui)
						AND page_bt_synonym = rtrim(@engg_lay_page_bts)
						AND section_bt_synonym <> 'PrjHdnSection'
						AND Section_width_Scalemode = 'px'
						AND ISNULL(width, '0') > 0
					)
			BEGIN
				RAISERROR (
						'Section Width should be in %% at Row no: ''%d ''',
						16,
						1,
						@_sec_fpRowNo
						)

				RETURN
			END
		END

		--- Added against TECH-218 ends
		IF @modeflag NOT IN ('S')
		BEGIN
			-- section type is tree
			IF @engg_sec_type = 'Tree'
			BEGIN
				DECLARE @section_len engg_seqno

				--
				--  if  @engg_sec_visible = 'y'
				--  begin
				--   select @msg  =   'Tree Section should be hidden, Uncheck the Visible Property'
				--      exec engg_error_sp 'ep_maireeSp_scsav_sec',
				--         12,
				--         @msg,
				--         @ctxt_language,
				--         @ctxt_ouinstance,
				--  @ctxt_service,
				--         @ctxt_user,
				--         @_sec_fpRowNo ,
				--         '',
				--         '',
				--         '',
				--         @m_errorid  output
				--   return
				--  end
				SELECT @section_len = len(@engg_sec_btsynname)

				IF @section_len > 20
				BEGIN
					SELECT @msg = 'Section Name Length is greater than 20 at Rowno <%1>'

					EXEC engg_error_sp 'ep_maireeSp_scsav_sec',
						10,
						@msg,
						@ctxt_language,
						@ctxt_ouinstance,
						@ctxt_service,
						@ctxt_user,
						@_sec_fpRowNo,
						'',
						'',
						'',
						@m_errorid OUTPUT

					RETURN
				END

				EXEC ep_create_tree_sp @ctxt_ouinstance,
					@ctxt_user,
					@ctxt_language,
					@ctxt_service,
					@engg_customer_name,
					@engg_project_name,
					@tmp_proc,
					@tmp_comp,
					@tmp_act,
					@tmp_ui,
					@engg_base_req_no,
					@engg_sec_type,
					@engg_sec_page_bts,
					@engg_sec_btsynname,
					@modeflag,
					@engg_req_no, --chan
					@m_errorid OUTPUT

				IF @m_errorid <> 0
					RETURN
			END
		END

		IF @Modeflag = 'D'
			AND @engg_sec_type = 'Filler'
		BEGIN
			IF EXISTS (
					SELECT 'X'
					FROM ep_ui_section_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND activity_name = @tmp_act
						AND ui_name = @tmp_ui
						AND page_bt_synonym = @engg_sec_page_bts
						AND section_bt_synonym = @engg_sec_btsynname
						AND req_no = @engg_base_req_no
						AND section_type = 'Filler'
					)
			BEGIN
				DELETE
				FROM ep_ui_section_dtl
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND activity_name = @tmp_act
					AND ui_name = @tmp_ui
					AND page_bt_synonym = @engg_sec_page_bts
					AND section_bt_synonym = @engg_sec_btsynname
					AND req_no = @engg_base_req_no
					AND section_type = 'Filler'
			END
		END

		------------11742 PAVITHRA V
		IF @Modeflag = 'D'
			AND @engg_sec_type = 'Popover'
		BEGIN
			IF EXISTS (
					SELECT 'X'
					FROM ep_ui_section_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND activity_name = @tmp_act
						AND ui_name = @tmp_ui
						AND page_bt_synonym = @engg_sec_page_bts
						AND section_bt_synonym = @engg_sec_btsynname
						AND req_no = @engg_base_req_no
						AND section_type = 'Popover'
					)
			BEGIN
				DELETE
				FROM ep_ui_section_dtl
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND activity_name = @tmp_act
					AND ui_name = @tmp_ui
					AND page_bt_synonym = @engg_sec_page_bts
					AND section_bt_synonym = @engg_sec_btsynname
					AND req_no = @engg_base_req_no
					AND section_type = 'PopOver'
			END
		END

		--11742 pavithra V
		--Code Added by Swaminathan R. on 06/01/2006 for Chart Sec Type Deltion Starts
		IF @Modeflag = 'D'
			AND @engg_sec_type = 'Chart'
		BEGIN
			IF EXISTS (
					SELECT 'X'
					FROM ep_chart_series(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND activity_name = @tmp_act
						AND ui_name = @tmp_ui
						AND page_bt_synonym = @engg_sec_page_bts
						AND section_bt_synonym = @engg_sec_btsynname
						AND req_no = @engg_base_req_no
					)
			BEGIN
				RAISERROR (
						'Cannot delete Section as Series/Sample Data Exists',
						16,
						1
						)

				RETURN
			END
					--Code Added by Swaminathan R. on 06/01/2006 for Chart Sec Type Deltion Ends
					/* code Added by Lavanya   on 09/01/2006  */
			ELSE
			BEGIN
				DELETE
				FROM ep_chart_header
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND activity_name = @tmp_act
					AND ui_name = @tmp_ui
					AND page_bt_synonym = @engg_sec_page_bts
					AND section_bt_synonym = @engg_sec_btsynname
					AND req_no = @engg_base_req_no

				DELETE
				FROM ep_ui_section_dtl
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND activity_name = @tmp_act
					AND ui_name = @tmp_ui
					AND page_bt_synonym = @engg_sec_page_bts
					AND section_bt_synonym = @engg_sec_btsynname
					AND req_no = @engg_base_req_no
					AND section_type = 'Chart'
			END
					/* code Added by Lavanya   on 09/01/2006  */
		END

		IF @modeflag IN (
				'U',
				'Y'
				)
		BEGIN
			--   --RAMANUJAM
			--   IF  @engg_sec_btsynname LIKE 'hdnspin%'
			--   begin
			--    raiserror('no modification allowed',16,1)
			--    return
			--   end
			-- added By Feroz for bug id :PNR2.0_20693
			IF @engg_sec_type NOT IN (
					'Main',
					'Tree',
					'Chart',
					'Dynamic'
					)
			BEGIN
				IF NOT EXISTS (
						SELECT 'x'
						FROM ep_ext_js_section_dtl(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND req_no = @engg_base_req_no
							AND process_name = @tmp_proc
							AND component_name = @tmp_comp
							AND activity_name = @tmp_act
							AND ui_name = @tmp_ui
							AND page_bt_synonym = @engg_sec_page_bts
							AND section_bt_synonym = @engg_sec_btsynname
						)
				BEGIN
					INSERT INTO ep_ext_js_section_dtl (
						customer_name,
						project_name,
						req_no,
						process_name,
						component_name,
						activity_name,
						ui_name,
						page_bt_synonym,
						section_bt_synonym,
						section_type,
						Section_Width,
						Section_Height,
						Section_Class,
						RVW_Task,
						Callout_Task,
						Direction,
						Scroll_Behaviour,
						Scroll_Delay,
						Fade_Delay,
						No_Of_Columns,
						Report_Item_Class,
						Property_Class,
						Value_Class,
						sample_data,
						wrkreqno,
						createdby,
						createddate,
						modifiedby,
						modifieddate
						)
					SELECT @engg_customer_name,
						@engg_project_name,
						@engg_base_req_no,
						@tmp_proc,
						@tmp_comp,
						@tmp_act,
						@tmp_ui,
						@engg_sec_page_bts,
						@engg_sec_btsynname,
						@engg_sec_type,
						@sectionwidth,
						@sectionheight,
						NULL,
						NULL,
						NULL,
						NULL,
						NULL,
						NULL,
						NULL,
						NULL,
						NULL,
						NULL,
						NULL,
						NULL,
						NULL,
						@ctxt_user,
						getdate(),
						@ctxt_user,
						getdate()
				END
			END
			
			-- added By Feroz for bug id :PNR2.0_20693
			-- added by hema for ext js -- PNR2.0_1790
			UPDATE ep_ext_js_section_dtl
			SET Section_Height = @sectionheight,
				Section_Width = @sectionwidth
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_base_req_no
				AND process_name = @tmp_proc
				AND component_name = @tmp_comp
				AND activity_name = @tmp_act
				AND ui_name = @tmp_ui
				AND page_bt_synonym = @engg_sec_page_bts
				AND section_bt_synonym = @engg_sec_btsynname

			-- added by hema for ext js -- PNR2.0_1790
			IF EXISTS (
					SELECT section_type
					FROM ep_ui_section_dtl
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND activity_name = @tmp_act
						AND ui_name = @tmp_ui
						AND page_bt_synonym = @engg_sec_page_bts
						AND section_bt_synonym = @engg_sec_btsynname
						AND req_no = @engg_base_req_no
						AND section_type <> 'Tree'
						AND @engg_sec_type = 'Tree'
					)
			BEGIN
				RAISERROR (
						'Section type cannot be Modified',
						16,
						1
						)

				RETURN
			END

			IF EXISTS (
					SELECT 'X'
					FROM ep_ui_section_dtl
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND activity_name = @tmp_act
						AND ui_name = @tmp_ui
						AND page_bt_synonym = @engg_sec_page_bts
						AND section_bt_synonym = @engg_sec_btsynname
						AND req_no = @engg_base_req_no
						AND section_type = 'Chart'
						AND @engg_sec_type = 'chart'
					)
			BEGIN
				UPDATE ep_ui_section_dtl
				SET visisble_flag = @engg_sec_visible,
					title_required = @engg_sec_title_req,
					border_required = @engg_sec_bord_req,
					section_doc = @engg_sect_doc,
					title_alignment = @engg_sec_title_align,
					ctrl_caption_align = @engg_sec_cap_align, -- @engg_ctrl_caption_align,
					caption_Format = @engg_sec_cap_format,
					Section_width_Scalemode = @Section_width_Scalemode,
					Section_height_Scalemode = @Section_height_Scalemode,
					SectionPrefixClass = @engg_sec_secpreclass,
					section_type = @engg_sec_type,
					width = @sectionwidth,
					height = @sectionheight,
					section_collapsemode = @Sec_CollapseMode, --shakthi
					section_collapse = @Sec_Collapse,
					Associated_Control = @engg_associatedcontrol,
					---code added by 13639 starts----
					IsResponsive   =@engg_mob_responsive,
					mob_pop_fullview =@engg_mob_fullview
					---code added by 13639 ends----
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND activity_name = @tmp_act
					AND ui_name = @tmp_ui
					AND page_bt_synonym = @engg_sec_page_bts
					AND section_bt_synonym = @engg_sec_btsynname
					AND req_no = @engg_base_req_no
					AND section_type = 'Chart'

				UPDATE ep_chart_header
				SET width = isnull(@sectionwidth, 400),
					height = isnull(@sectionheight, 400)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND activity_name = @tmp_act
					AND ui_name = @tmp_ui
					AND page_bt_synonym = @engg_sec_page_bts
					AND section_bt_synonym = @engg_sec_btsynname
			END

			IF EXISTS (
					SELECT section_type
					FROM ep_ui_section_dtl
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @tmp_proc
						AND component_name = @tmp_comp
						AND activity_name = @tmp_act
						AND ui_name = @tmp_ui
						AND page_bt_synonym = @engg_sec_page_bts
						AND section_bt_synonym = @engg_sec_btsynname
						AND req_no = @engg_base_req_no
						AND section_type = 'Chart'
						AND @engg_sec_type = 'Main'
						AND NOT EXISTS (
							SELECT 'X'
							FROM ep_chart_header
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @tmp_proc
								AND component_name = @tmp_comp
								AND activity_name = @tmp_act
								AND ui_name = @tmp_ui
								AND page_bt_synonym = @engg_sec_page_bts
								AND section_bt_synonym = @engg_sec_btsynname
								AND req_no = @engg_base_req_no
							)
					)
			BEGIN
				UPDATE ep_ui_section_dtl
				SET section_type = 'Main'
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND activity_name = @tmp_act
					AND ui_name = @tmp_ui
					AND page_bt_synonym = @engg_sec_page_bts
					AND section_bt_synonym = @engg_sec_btsynname
					AND req_no = @engg_base_req_no
					AND section_type = 'Chart'
			END
					--   Else
					--   Begin
					--    Raiserror ('Section type cannot be Modified',16,1)
					--    RETURN
					--   END
		END

		IF EXISTS (
				SELECT 'x'
				FROM sysobjects(NOLOCK)
				WHERE name = 'de_customer_space'
					AND type = 'u'
				)
		BEGIN
			UPDATE de_customer_space
			SET validate_req = 'Y'
			WHERE customername = @engg_customer_name
				AND projectname = @engg_project_name
				AND processname = @tmp_proc
				AND componentname = @tmp_comp
		END

		-- start code added by feroz for extjs -- PNR2.0_1790
		IF @modeflag <> 'S'
		BEGIN
			IF @sect_type <> @engg_sec_type
				AND @sect_type IN (
					'Text Scroller',
					'Formatted Text',
					'Report List',
					'Property Window',
					'Pivot',
					'Tree Grid',
					'IFrame',
					'RSS Feed'
					)
			BEGIN
				SELECT @msg = 'Section type cannot be changed for the ' + @engg_sec_btsynname + ' . Delete the section or add new section for Ext Js.'

				EXEC engg_error_sp 'ep_maireeSp_scsav_sec',
					1,
					@msg,
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					'',
					'',
					'',
					'',
					@m_errorid OUTPUT
			END

			IF @engg_sec_type IN (
					'Text Scroller',
					'Formatted Text',
					'Report List',
					'Property Window',
					'Pivot',
					'Tree Grid',
					'IFrame',
					'RSS Feed'
					)
			BEGIN
				SELECT @section_len = len(@engg_sec_btsynname)

				IF @section_len > 25
				BEGIN
					SELECT @msg = 'Section Name Length is greater than 25 at Rowno <%1>'

					EXEC engg_error_sp 'ep_maireeSp_scsav_sec',
						10,
						@msg,
						@ctxt_language,
						@ctxt_ouinstance,
						@ctxt_service,
						@ctxt_user,
						@_sec_fpRowNo,
						'',
						'',
						'',
						@m_errorid OUTPUT

					RETURN
				END

				SELECT @sect_type = section_type
				FROM ep_ui_section_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND activity_name = @tmp_act
					AND ui_name = @tmp_ui
					AND page_bt_synonym = @engg_sec_page_bts
					AND section_bt_synonym = @engg_sec_btsynname

				--code added for Bug ID :PNR2.0_31386 starts
				DECLARE @Assc_tCtrl engg_name

				SELECT @Assc_tCtrl = Associated_control
				FROM ep_ui_section_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND activity_name = @tmp_act
					AND ui_name = @tmp_ui
					AND page_bt_synonym = @engg_sec_page_bts
					AND section_bt_synonym = @engg_sec_btsynname

				--code added for Bug ID :PNR2.0_31386 ends
				EXEC ep_create_extnjs_sp @ctxt_ouinstance,
					@ctxt_user,
					@ctxt_language,
					@ctxt_service,
					@engg_customer_name,
					@engg_project_name,
					@tmp_proc,
					@tmp_comp,
					@tmp_act,
					@tmp_ui,
					@engg_base_req_no,
					@engg_sec_type,
					@engg_sec_page_bts,
					@engg_sec_btsynname,
					@modeflag,
					@engg_req_no,
					@m_errorid OUTPUT
			END

			--code added for Bug ID :PNR2.0_31386 starts
			IF @engg_sec_type = 'Tree Grid' --code modified for the Bug ID: PNR2.0_31780
			BEGIN
				EXEC ep_create_TreeGrid_HdnCtrl_sp @ctxt_OUInstance,
					@ctxt_User,
					@ctxt_Language,
					@ctxt_Service,
					@engg_customer_name,
					@engg_project_name,
					@tmp_proc,
					@tmp_comp,
					@tmp_act,
					@tmp_ui,
					@engg_sec_page_bts,
					@engg_sec_btsynname,
					@engg_req_no,
					@Assc_tCtrl,
					@ModeFlag,
					@m_errorid OUTPUT
			END
					--code added for Bug ID :PNR2.0_31386 ends
		END

		IF isnull(@engg_sec_type, '') = 'MobileCalendar' -- Changed for the Defect id: TECH-21893
		BEGIN
			EXEC EP_UI_MOBCALENDAR_SECTION_SP @ctxt_OUInstance,
				@ctxt_User,
				@ctxt_Language,
				@ctxt_Service,
				@engg_customer_name,
				@engg_project_name,
				@tmp_proc,
				@tmp_comp,
				@tmp_act,
				@tmp_ui,
				@engg_sec_page_bts,
				@engg_sec_btsynname,
				@engg_sec_descr,
				@engg_base_req_no,
				@ModeFlag,
				@m_errorid OUTPUT
		END

		----Code added for Defect Id TECH-16126 started
		--IF isnull(@engg_sec_type, '') = 'MobileGrid' -- added for Defect id : TECH-18349
		--BEGIN
		--	EXEC ep_paginationgrid_ins_sp @ctxt_OUInstance,
		--		@ctxt_User,
		--		@ctxt_Language,
		--		@ctxt_Service,
		--		@engg_customer_name,
		--		@engg_project_name,
		--		@tmp_proc,
		--		@tmp_comp,
		--		@tmp_act,
		--		@tmp_ui,
		--		@engg_base_req_no,
		--		@engg_sec_page_bts,
		--		@engg_sec_btsynname,
		--		'',
		--		'',
		--		'',
		--		--@engg_control_name,			@engg_controlid,		@engg_ui_type,
		--		@engg_sec_type,
		--		'',
		--		'',
		--		'',
		--		--@engg_control_type,	@engg_basecontrol_type,		@engg_renderas,
		--		@modeflag,
		--		@engg_req_no,
		--		@m_errorid OUTPUT
		--END

		/* 
		If isnull(@devicetype,'') in( 'P', 'B' )
		Begin
			Exec ep_layout_phone_ins_sp 
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			@tmp_act,
			@tmp_comp,
			@engg_customer_name,
			@engg_sec_page_bts,
			@engg_sec_btsynname,
			null,
			null,
			@tmp_proc,
			@engg_project_name,
			@engg_req_no,
			@tmp_ui,
			@phone_in,
			@tablet_in,
			'Section',
			null,
			@m_errorid
		End

		If isnull(@devicetype,'') in( 'T', 'B' )
		Begin
			Exec ep_layout_tablet_ins_sp 
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			@tmp_act,
			@tmp_comp,
			@engg_customer_name,
			@engg_sec_page_bts,
			@engg_sec_btsynname,
			null,
			null,
			@tmp_proc,
			@engg_project_name,
			@engg_req_no,
			@tmp_ui,
			@phone_in,
			@tablet_in,
			'Section',
			null,
			@m_errorid
		End */
		-- Code ends
		IF @modeflag = 'D'
		BEGIN
			EXEC ep_ext_js_section_dtl_sp_del @ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@engg_customer_name,
				@engg_project_name,
				@engg_base_req_no,
				@tmp_proc,
				@tmp_comp,
				@tmp_act,
				@tmp_ui,
				@engg_sec_page_bts,
				@engg_sec_btsynname,
				@m_errorid OUTPUT
		END

		-- end code added by feroz for extjs  -- PNR2.0_1790
		SELECT @_sec_fpRowNo '_sec_fpRowNo'
	END

	-- ************
			SELECT  @section_prfx		=	section_prefix 
			FROM	ep_ui_Section_dtl (nolock)
			WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND req_no = @engg_base_req_no
			AND process_name = @tmp_proc
			AND component_name = @tmp_comp
			AND activity_name = @tmp_act
			AND ui_name = @tmp_ui
			AND page_bt_synonym = @engg_sec_page_bts
			AND section_bt_synonym = @engg_sec_btsynname

	SELECT @engg_control_name = 'hdn' + ISNULL(@section_prfx, '') + 'DS'

IF @modeflag = 'D' AND ISNULL(@engg_sec_secpreclass,'') = 'Dynamic'
BEGIN
	DELETE FROM ep_ui_control_dtl
	WHERE	customer_name			= @engg_customer_name
	AND		project_name			= @engg_project_name	
	AND		process_name			= @tmp_proc
	AND		component_name			= @tmp_comp
	AND		activity_name			= @tmp_act
	AND		ui_name					= @tmp_ui
	AND		page_bt_synonym			= @engg_sec_page_bts
	AND		section_bt_synonym		= @engg_sec_btsynname
	AND		control_bt_synonym		= @engg_control_name
END



IF ISNULL(@engg_sec_secpreclass,'') = 'Dynamic' and @modeflag <> 'D'
BEGIN
	
			Exec ep_controlcreation_sp
									@ctxt_OUInstance			= @ctxt_OUInstance,
									@ctxt_User					= @ctxt_User,
									@ctxt_Language				= @ctxt_Language,
									@ctxt_Service				= @ctxt_Service,
									@engg_customer_name			= @engg_customer_name,
									@engg_project_name			= @engg_project_name,
									@engg_process_name			= @tmp_proc,
									@engg_component_name		= @tmp_comp,
									@engg_activity_name			= @tmp_act,
									@engg_ui_name				= @tmp_ui,
									@engg_page_name				= @engg_sec_page_bts,
									@engg_section_name			= @engg_sec_btsynname,
									@engg_control_name			= @engg_control_name,
									@engg_req_no				= @engg_base_req_no,
									@ModeFlag					= @ModeFlag,
									@CreatingFor				= 'SectionDynamicStyle',
									@m_errorid					= @m_errorid output
END
ELSE IF ISNULL(@engg_sec_secpreclass,'') <> 'Dynamic' and  ISNULL(@engg_sec_secpreclass,'') = ''
	
BEGIN

		DELETE 
		FROM	ep_ui_control_dtl
		WHERE	customer_name			= @engg_customer_name
		AND		project_name			= @engg_project_name		
		AND		process_name			= @tmp_proc
		AND		component_name			= @tmp_comp
		AND		activity_name			= @tmp_act
		AND		ui_name					= @tmp_ui
		AND		page_bt_synonym			= @engg_sec_page_bts
		AND		section_bt_synonym		= @engg_sec_btsynname
		AND		control_bt_synonym		= @engg_control_name

END

			--TECH-70687
			EXEC ep_toolbar_sec_creation_sp
				@ctxt_language				= @ctxt_language,
				@ctxt_ouinstance			= @ctxt_ouinstance,  
				@ctxt_service				= @ctxt_service,
				@ctxt_user					= @ctxt_user,
				@customer_name				= @engg_customer_name,
				@project_name				= @engg_project_name,
				@req_no						= @engg_req_no,
				@process_name				= @tmp_proc,
				@component_name				= @tmp_comp,
				@activity_name				= @tmp_act,
				@ui_name					= @tmp_ui,
				@page_name					= @engg_sec_page_bts,
				@section_name				= @engg_sec_btsynname,
				@toptoolbar					= @engg_sec_toptb,
				@bottomtoolbar				= @engg_sec_bottomtb,
				@lefttoolbar				= @engg_sec_lefttb,
				@righttoolbar				= @engg_sec_righttb,
				@sidebarrequired			= '',
				@m_errorid					= @m_errorid OUTPUT 
			--TECH-70687
		--TECH-74049
		IF ISNULL(@engg_sec_type,'') = 'Stepper Linear' and @modeflag <> 'D'
		BEGIN
			
					Exec ep_controlcreation_sp
											@ctxt_OUInstance			= @ctxt_OUInstance,
											@ctxt_User					= @ctxt_User,
											@ctxt_Language				= @ctxt_Language,
											@ctxt_Service				= @ctxt_Service,
											@engg_customer_name			= @engg_customer_name,
											@engg_project_name			= @engg_project_name,
											@engg_process_name			= @tmp_proc,
											@engg_component_name		= @tmp_comp,
											@engg_activity_name			= @tmp_act,
											@engg_ui_name				= @tmp_ui,
											@engg_page_name				= @engg_sec_page_bts,
											@engg_section_name			= @engg_sec_btsynname,
											@engg_control_name			= @engg_control_name,
											@engg_req_no				= @engg_base_req_no,
											@ModeFlag					= @ModeFlag,
											@CreatingFor				= 'StepperLinear',
											@m_errorid					= @m_errorid output
		END
		
		IF ISNULL(@engg_sec_type,'') = 'Stepper Non-Linear' and @modeflag <> 'D'
		BEGIN
			
					Exec ep_controlcreation_sp
											@ctxt_OUInstance			= @ctxt_OUInstance,
											@ctxt_User					= @ctxt_User,
											@ctxt_Language				= @ctxt_Language,
											@ctxt_Service				= @ctxt_Service,
											@engg_customer_name			= @engg_customer_name,
											@engg_project_name			= @engg_project_name,
											@engg_process_name			= @tmp_proc,
											@engg_component_name		= @tmp_comp,
											@engg_activity_name			= @tmp_act,
											@engg_ui_name				= @tmp_ui,
											@engg_page_name				= @engg_sec_page_bts,
											@engg_section_name			= @engg_sec_btsynname,
											@engg_control_name			= @engg_control_name,
											@engg_req_no				= @engg_base_req_no,
											@ModeFlag					= @ModeFlag,
											@CreatingFor				= 'StepperNonLinear',
											@m_errorid					= @m_errorid output
		END


	SET NOCOUNT OFF
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME= 'ep_maireeSp_scsav_sec' AND TYPE='P')
BEGIN
	GRANT EXEC ON  ep_maireeSp_scsav_sec TO PUBLIC
END
GO

