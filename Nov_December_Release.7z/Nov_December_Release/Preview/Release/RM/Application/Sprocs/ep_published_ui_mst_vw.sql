if Exists ( Select 'x' From sysobjects Where name = 'ep_published_ui_mst_vw' And type in ('V','v'))
Begin
Drop view ep_published_ui_mst_vw
End
go
/*	Creating View Script - ep_published_ui_mst_vw on 	Jun 26 2005 11:46PM		*/	

/************************************************************************************
procedure name and id   ep_published_ui_mst_vw
description             
name of the author      
date created            
query file name         ep_published_ui_mst_vw.sql
modifications history   
modified by				Sangeetha G     
modified date			30-Dec-2010   
modified for			PNR2.0_29595        
************************************************************************************/
/* modified by  : Veena U   			                                        */
/* date         : Oct 10 2014			                                        */
/* BugId        : PLF2.0_09035													*/
/* description  : Model changes for rowspan,colspan,IsStatic,IsCallout 
				  in  layout level.												*/
/********************************************************************************/
/* Modified by  : Veena U	                                                  */
/* Date         : 07-Aug-2015                                                  */
/* Defect ID	: PLF2.0_14096                                                 */
/********************************************************************************/
/* modified by  : Veena U        */
/* date         : 28-Mar-2016              */
/* Bug ID  		: PLF2.0_17570           */
/*************************************************************************************/
/* modified by                    Date                       Defect ID            */
/* Veena U                        08-Jun-2016                PLF2.0_18487         */
/**********************************************************************************/
/* Modified by : Ganesh Prabhu S/Ranjitha R      for callid  TECH-10118                   */
/* Modified on : 30-May-2017                                                                                        */
/* Description : Platform Feature Release                                                              */
/********************************************************************************/
/**********************************************************************************/
/* Modified by : Hareesh K      for Added New column     */
/* Modified on : 19-July-2019                                                                                      */
/* Description : Platform Feature Release                                                              */
/********************************************************************************/
/* Modified by	:	VimalKumar R												*/
/* Modified on	:	11/07/22				 									*/
/* Defect ID	:	TECH-70687													*/
/* Description	:	Tool and Toolbars											*/
/********************************************************************************/
/* Modified by	:	Priyadharshini U											*/
/* Modified on	:	23/08/22				 									*/
/* Defect ID	:	Tech-72114													*/
/* Description	:	Provision to upload mobility config xml, template and CSS 
					into model and integrating with mobility code generator		*/
/********************************************************************************/
/* Modified by : Ponmalar A														*/
/* Modified on : 01-Dec-2022													*/
/* Defect ID   : TECH-75230														*/
/* Description : Platform Features for the Month of Nov'22						*/
/********************************************************************************/
CREATE view ep_published_ui_mst_vw
as
select 	customer_name		'customer_name',
		project_name		'project_name',
		req_no				'req_no',
		process_name		'process_name',
		component_name		'component_name',
		activity_name		'activity_name',
		ui_name				'ui_name',
		ui_descr			'ui_descr',
		ui_type				'ui_type',
		ui_format			'ui_format',
		caption_alignment	'caption_alignment',
		trail_bar			'trail_bar',
		tab_height			'tab_height',
		ui_sysid			'ui_sysid',
		timestamp			'timestamp',
		createdby			'createdby',
		createddate			'createddate',
		modifiedby			'modifiedby',
		modifieddate		'modifieddate',
		ui_doc				'ui_doc',
		base_component_name	'base_component_name',
		base_activity_name	'base_activity_name',
		base_ui_name		'base_ui_name',
		grid_type			'grid_type',
		state_processing	'state_processing',
		callout_type		'callout_type',
		taskpane_req		'taskpane_req',---- Column addition  for  PNR2.0_29495 
		New_Line_Ui 		'New_Line_Ui',
		Tab_Type			'Tab_Type'	 ,
		PostLaunchTask		'PostLaunchTask',
		TabPosition			'TabPosition',
		SmartHide			'SmartHide',
		Is_device			'Is_device',
		HideIlbotitlemenu_req		'HideIlbotitlemenu_req',
		personalization		'personalization',
		Exclude_Systemtabindex	'Exclude_Systemtabindex',
		DeviceType			'DeviceType',--PLF2.0_17570
		TabStyle			'TabStyle',
		IsDesktop			'IsDesktop',
		Hide_Print			'Hide_Print'	,
		Layout				'Layout',
		XYCoordinates		'XYCoordinates',
		ColumnLayWidth		'ColumnLayWidth',
		TabHeaderPostion	'TabHeaderPostion',
		TabRotation			'TabRotation',
		hide_imp_defaults	'hide_imp_defaults',
		ui_subtype			'ui_subtype',
		DBName				'DBName',
		IsGlance			'IsGlance',
		NativeApplication	'NativeApplication',
		Conditional_popupclose	'Conditional_popupclose',
		Titlebar_Search		'Titlebar_Search',
		--Code added for TECH-70687 starts
		Sidebar					'Sidebar',
		Docked					'Docked',
		LeftToolbar				'LeftToolbar',
		RightToolbar			'RightToolbar',
		TopToolbar				'TopToolbar',
		BottomToolbar			'BottomToolbar',
		--Code added for TECH-70687	ends
		--Code added for the Defect Id Tech-72114 starts
		TemplateJSON			'TemplateJSON',
		StyleSheet				'StyleSheet',
		ConfigurationXML		'ConfigurationXML',
		TemplateJSONDBC			'TemplateJSONDBC',
		StyleSheetDBC			'StyleSheetDBC',
		ConfigurationXMLDBC		'ConfigurationXMLDBC',
		--Code added for the Defect Id Tech-72114 ends
		PullToRefresh			'PullToRefresh'	--TECH-75230
from	ep_published_ui_mst (nolock)
go
if exists(select 'x' from sysobjects where name = 'ep_published_ui_mst_vw' and xtype = 'V')
begin
grant select on ep_published_ui_mst_vw to public
end
go