IF EXISTS  (SELECT 'X' FROM SYSOBJECTS WHERE NAME ='ep_layout_sp_savctlgdml_o' AND TYPE = 'P')
    BEGIN
        DROP PROC ep_layout_sp_savctlgdml_o
    END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		ep_layout_sp_savctlgdml_o.sql
********************************************************************************/
/******************************************************************************/
/* Procedure					: ep_layout_sp_savctlgdml_o								 */
/* Description					: 								 */
/******************************************************************************/
/* Project						: 								 */
/* EcrNo						: 								 */
/* Version						: 								 */
/******************************************************************************/
/* Referenced					: 								 */
/* Tables						: 								 */
/******************************************************************************/
/* Development history			: 								 */
/******************************************************************************/
/* Author						: ModelExplorer								 */
/* Date							: Mar 30 2016  6:49PM								 */
/******************************************************************************/
/* Modification History			: 								 */
/******************************************************************************/
/* Modified By					: 								 */
/* Date							: 								 */
/* Description					: 								 */
/******************************************************************************/
/* Modified by  : Veena U                                                  */
/* Date         : 28-Mar-2016                                                 */
/* Call ID		: PLF2.0_17570                                               */
/********************************************************************************/
/* modified by			Date				Defect ID							*/
/* Veena U				08-Jun-2016			PLF2.0_18487						*/
/********************************************************************************/
/* Modified by : Jeya Latha K/Ganesh Prabhu S	for callid TECH-7349				*/
/* Modified on : 14-03-2017				 											*/
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and New Feature Organization chart */
/***********************************************************************************/
/* Modified by : Ponmalar A		Date: 01-Dec-2022  Defect ID : TECH-75230		   */
/***********************************************************************************/
CREATE PROCEDURE ep_layout_sp_savctlgdml_o
	@ctxt_language_in ctxt_language, --Input 
	@ctxt_ouinstance_in ctxt_ouinstance, --Input 
	@ctxt_service_in ctxt_service, --Input 
	@ctxt_user_in ctxt_user, --Input 
	@engg_act_descr_in engg_description, --Input 
	@engg_component_in engg_description, --Input 
	@engg_cont_page_bts_in engg_name, --Input 
	@engg_cont_sec_bts_in engg_name, --Input 
	@engg_customer_name_in engg_name, --Input 
	@engg_ui_descr_in engg_description, --Input 
	@engg_req_no_in engg_name, --Input 
	@engg_process_descr engg_description, --Input 
	@engg_project_name engg_name, --Input 
	@m_errorid INT OUTPUT --To Return Execution Status
AS
BEGIN
	-- nocount should be switched on to prevent phantom rows
	SET NOCOUNT ON
	-- @m_errorid should be 0 to Indicate Success
	SET @m_errorid = 0

	--declaration of temporary variables
	--declaration of temporary variables
	DECLARE @ctxt_language engg_ctxt_language
	DECLARE @ctxt_ouinstance engg_ctxt_ouinstance
	DECLARE @ctxt_service engg_ctxt_service
	DECLARE @ctxt_user engg_ctxt_user
	DECLARE @engg_act_descr engg_description
	DECLARE @engg_att_ui_cap_align engg_name
	DECLARE @engg_att_ui_format engg_description
	DECLARE @engg_att_ui_trail_bar engg_name
	DECLARE @engg_att_ui_type engg_name
	DECLARE @engg_component engg_description
	DECLARE @engg_customer_name engg_name
	DECLARE @engg_req_no engg_name
	DECLARE @engg_rf_act engg_description
	DECLARE @engg_rf_comp engg_description
	DECLARE @engg_rf_ui engg_description
	DECLARE @engg_tab_height engg_length
	DECLARE @engg_ui_descr engg_description
	DECLARE @guid engg_guid

	--temporary and formal parameters mapping
	SELECT @ctxt_language = @ctxt_language_in

	SELECT @ctxt_ouinstance = @ctxt_ouinstance_in

	SELECT @ctxt_service = ltrim(rtrim(@ctxt_service_in))

	SELECT @ctxt_user = ltrim(rtrim(@ctxt_user_in))

	SELECT @engg_act_descr = ltrim(rtrim(@engg_act_descr_in))

	SELECT @engg_component = ltrim(rtrim(@engg_component_in))

	SELECT @engg_customer_name = ltrim(rtrim(@engg_customer_name_in))

	SELECT @engg_req_no = ltrim(rtrim(@engg_req_no_in))

	SELECT @engg_ui_descr = ltrim(rtrim(@engg_ui_descr_in))

	--null checking
	IF @ctxt_language = - 915
		SELECT @ctxt_language = NULL

	IF @ctxt_ouinstance = - 915
		SELECT @ctxt_ouinstance = NULL

	IF @ctxt_service = '~#~'
		SELECT @ctxt_service = NULL

	IF @ctxt_user = '~#~'
		SELECT @ctxt_user = NULL

	IF @engg_act_descr = '~#~'
		SELECT @engg_act_descr = NULL

	IF @engg_component = '~#~'
		SELECT @engg_component = NULL

	IF @engg_cont_page_bts_in = '~#~'
		SELECT @engg_cont_page_bts_in = NULL

	IF @engg_cont_sec_bts_in = '~#~'
		SELECT @engg_cont_sec_bts_in = NULL

	IF @engg_customer_name = '~#~'
		SELECT @engg_customer_name = NULL

	IF @engg_ui_descr = '~#~'
		SELECT @engg_ui_descr = NULL

	IF @engg_req_no = '~#~'
		SELECT @engg_req_no = NULL

	IF @engg_process_descr = '~#~'
		SELECT @engg_process_descr = NULL

	IF @engg_project_name = '~#~'
		SELECT @engg_project_name = NULL

	--errors mapped
	DECLARE @tmp_comp_name engg_name,
		@tmp_proc engg_name,
		@tmp_acty_name engg_name,
		@tmp_ui_name engg_name,
		@engg_base_req_no engg_name

	SELECT @engg_base_req_no = 'BASE'

	--select process name for description
	SELECT @tmp_proc = rtrim(process_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_req_no)
		AND process_descr = rtrim(@engg_process_descr)

	--select component name for description
	SELECT @tmp_comp_name = rtrim(component_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_descr = rtrim(@engg_component)

	--select activity name for description
	SELECT @tmp_acty_name = rtrim(activity_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp_name)
		AND activity_descr = rtrim(@engg_act_descr)

	--select UI name for description
	SELECT @tmp_ui_name = rtrim(ui_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp_name)
		AND activity_name = rtrim(@tmp_acty_name)
		AND ui_descr = rtrim(@engg_ui_descr)

	/*select the min of page*/
	DECLARE @page_bt_synonym_tmp engg_name
	DECLARE @section_bt_synonym_tmp engg_name
	DECLARE @control_bt_synonym_tmp engg_name

	SELECT TOP 1 @page_bt_synonym_tmp = rtrim(p.page_bt_synonym)
	FROM ep_ui_page_dtl p(NOLOCK)
	WHERE p.customer_name = rtrim(@engg_customer_name)
		AND p.project_name = rtrim(@engg_project_name)
		AND p.req_no = rtrim(@engg_base_req_no)
		AND p.process_name = rtrim(@tmp_proc)
		AND p.component_name = rtrim(@tmp_comp_name)
		AND p.activity_name = rtrim(@tmp_acty_name)
		AND p.ui_name = rtrim(@tmp_ui_name)
		AND p.page_bt_synonym IN (
			SELECT c.page_bt_synonym
			FROM ep_ui_control_dtl c(NOLOCK),
				es_comp_ctrl_type_mst_vw v(NOLOCK)
			WHERE p.customer_name = c.customer_name
				AND p.project_name = c.project_name
				AND p.process_name = c.process_name
				AND p.component_name = c.component_name
				AND p.activity_name = c.activity_name
				AND p.ui_name = c.ui_name
				AND p.page_bt_synonym = c.page_bt_synonym
				AND c.customer_name = v.customer_name
				AND c.project_name = v.project_name
				AND c.process_name = v.process_name
				AND c.component_name = v.component_name
				AND c.control_type = v.ctrl_type_name
				--and		v.base_ctrl_type	= 'Grid'
				AND v.base_ctrl_type IN (
					'Grid',
					'Assorted',
					'Pivot',
					'TreeGrid'
					)
				AND isnull(v.Is_Extjs_Control, 'N') <> 'Y'
			)
	ORDER BY p.horder,
		p.vorder

	SELECT @section_bt_synonym_tmp = min(s.section_bt_synonym)
	FROM ep_ui_section_dtl s(NOLOCK),
		ep_ui_control_dtl c(NOLOCK),
		es_comp_ctrl_type_mst_vw v(NOLOCK)
	WHERE s.customer_name = rtrim(@engg_customer_name)
		AND s.project_name = rtrim(@engg_project_name)
		AND s.req_no = rtrim(@engg_base_req_no)
		AND s.process_name = rtrim(@tmp_proc)
		AND s.component_name = rtrim(@tmp_comp_name)
		AND s.activity_name = rtrim(@tmp_acty_name)
		AND s.ui_name = rtrim(@tmp_ui_name)
		AND s.page_bt_synonym = rtrim(@page_bt_synonym_tmp)
		AND s.customer_name = c.customer_name
		AND s.project_name = c.project_name
		AND s.process_name = c.process_name
		AND s.component_name = c.component_name
		AND s.activity_name = c.activity_name
		AND s.ui_name = c.ui_name
		AND s.page_bt_synonym = c.page_bt_synonym
		AND s.section_bt_synonym = c.section_bt_synonym
		AND c.customer_name = v.customer_name
		AND c.project_name = v.project_name
		AND c.process_name = v.process_name
		AND c.component_name = v.component_name
		AND c.control_type = v.ctrl_type_name
		--and		v.base_ctrl_type	= 'Grid'
		AND v.base_ctrl_type IN (
			'Grid',
			'Assorted',
			'Pivot',
			'TreeGrid'
			)
		AND isnull(v.Is_Extjs_Control, 'N') <> 'Y'
		AND s.section_bt_synonym NOT IN (
			'PrjHdnSection',
			'[tabcontrol]'
			)
		AND s.section_type IN (
			'Main',
			'Carousel'
			)

	/*select the min of control*/
	SELECT @control_bt_synonym_tmp = min(rtrim(a.control_bt_synonym))
	FROM ep_ui_control_dtl a(NOLOCK),
		es_comp_ctrl_type_mst_vw b(NOLOCK)
	WHERE a.customer_name = rtrim(@engg_customer_name)
		AND a.project_name = rtrim(@engg_project_name)
		AND a.req_no = rtrim(@engg_base_req_no)
		AND a.process_name = rtrim(@tmp_proc)
		AND a.component_name = rtrim(@tmp_comp_name)
		AND a.activity_name = rtrim(@tmp_acty_name)
		AND a.ui_name = rtrim(@tmp_ui_name)
		AND a.page_bt_synonym = rtrim(@page_bt_synonym_tmp)
		AND a.section_bt_synonym = rtrim(@section_bt_synonym_tmp)
		AND b.customer_name = a.customer_name
		AND b.project_name = a.project_name
		AND b.process_name = a.process_name
		AND b.component_name = a.component_name
		AND a.control_type = b.ctrl_type_name
		--and		b.base_ctrl_type		= 'GRID'
		AND b.base_ctrl_type IN (
			'Grid',
			'Assorted',
			'Pivot',
			'TreeGrid'
			)
		AND isnull(b.Is_Extjs_Control, 'N') <> 'Y'

	SELECT rtrim(b.bt_synonym_caption) 'engg_col_descr',
		rtrim(column_bt_synonym) 'engg_grid_btsynname',
		rtrim(column_no) 'engg_grid_colno',
		rtrim(col_doc) 'engg_grid_doc',
		rtrim(column_type) 'engg_grid_elem_type',
		rtrim(sample_data) 'engg_grid_samp_data',
		rtrim(proto_tooltip) 'engg_grid_tooltip',
		rtrim(visible_length) 'engg_grid_vis_length',
		visible 'engg_grd_visible',
		a.ColumnClass 'columnclass',
		CASE a.forcefit
			WHEN 'Y'
				THEN '1'
			ELSE '0'
			END 'Forcefit',
		RTRIM(ISNULL(a.TemplateID, '')) 'engg_col_tempid',
		Parameter_Text 'col_temp_cat',
		TemplateSpecific 'col_temp_specific',
		Icon_position	'col_Icon_position'		--TECH-75230
	FROM ep_component_glossary_mst b(NOLOCK)
	RIGHT JOIN ep_ui_grid_dtl a(NOLOCK) ON b.customer_name = a.customer_name
		AND b.project_name = a.project_name
		AND b.req_no = a.req_no
		AND b.process_name = a.process_name
		AND b.component_name = a.component_name
		AND b.bt_synonym_name = a.column_bt_synonym
	LEFT JOIN ep_device_quick_code_met(NOLOCK) ON parameter_code = templatecategory
		AND parameter_type = 'TemplateCategory'
	WHERE a.customer_name = rtrim(@engg_customer_name)
		AND a.project_name = rtrim(@engg_project_name)
		AND a.req_no = rtrim(@engg_base_req_no)
		AND a.process_name = rtrim(@tmp_proc)
		AND a.component_name = rtrim(@tmp_comp_name)
		AND a.activity_name = rtrim(@tmp_acty_name)
		AND a.ui_name = rtrim(@tmp_ui_name)
		AND a.page_bt_synonym = rtrim(@page_bt_synonym_tmp)
		AND a.section_bt_synonym = rtrim(@section_bt_synonym_tmp)
		AND a.control_bt_synonym = rtrim(@control_bt_synonym_tmp)
	ORDER BY a.column_no

	/* 
	--OutputList
		Select
		null 'engg_grid_btsynname', 
		null 'engg_grid_colno', 
		null 'engg_grid_doc', 
		null 'engg_grid_elem_type', 
		null 'engg_grid_samp_data', 
		null 'engg_grid_tooltip', 
		null 'engg_grid_vis_length', 
		null 'engg_grid_default', 
		null 'engg_grd_visible', 
		null 'columnclass', 
		null 'set_user_pref_ml', 
		null 'forcefit', 
		null 'engg_col_tempid', 
		null 'engg_col_descr', 
	*/
	SET NOCOUNT OFF
END
GO

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_layout_sp_savctlgdml_o' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON ep_layout_sp_savctlgdml_o TO PUBLIC
END
GO

