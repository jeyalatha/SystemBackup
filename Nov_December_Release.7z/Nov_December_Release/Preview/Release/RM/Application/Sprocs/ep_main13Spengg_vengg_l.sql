IF EXISTS(SELECT 'X' From SYSOBJECTS WHERE NAME ='ep_main13Spengg_vengg_l' AND TYPE='P')
   BEGIN
        DROP PROC ep_main13Spengg_vengg_l
   END
GO 
/****************************************************************************************************/
/*      V E R S I O N      :  PNR2.0_25308															*/  
/*      Released By        :  Development Team														*/  
/*      Release Comments   :  Phase 4 Release														*/  
/****************************************************************************************************/  
/* Procedure    : ep_main13Spengg_vengg_l															*/  
/* Description  :																					*/  
/****************************************************************************************************/  
/* Project      :																					*/  
/* ECR          :																					*/  
/* Version      :																					*/  
/****************************************************************************************************/  
/* Referenced   :																					*/  
/* Tables       :																					*/  
/****************************************************************************************************/  
/* Development history																				*/  
/****************************************************************************************************/  
/* Author       : A Yuvaraj																			*/  
/* Date         : 22/Mar/2005																		*/  
/****************************************************************************************************/  
/* Modification history																				*/  
/****************************************************************************************************/  
/* Modified by  : S. Ramanujam																		*/  
/* Date         : 26-10-2005																		*/  
/* Description  : Case ID : Platform_2.0.3.1_43														*/  
/*Case Desc : when i create a control type with base class edit and then change						*/  
/*the base class to button and set the visible property to false and if i revert					*/  
/*back to edit base class the user defined control type is not listed in the combo					*/  
/* for control type in specify layout.																*/  
/****************************************************************************************************/  
/* Modified by  : Hamsika																			*/  
/* Date         : 26-10-2005																		*/  
/* Description  : Case ID : Platform_2.0.3.1_49														*/  
/****************************************************************************************************/  
/* Modified by  : Chanheetha N A																	*/  
/* Date         : 22-07-2006																		*/  
/* Call ID      : PNR2.0_9056																		*/  
/****************************************************************************************************/  
/* Modified by  :  Feroz																			*/  
/* Date         :  03-Jul-2008																		*/  
/* Bug ID       :  PNR2.0_18395																		*/  
/****************************************************************************************************/  
/* modified by   : Jeya																				*/  
/* date     : 25-nov-2008																			*/  
/* BugId    : PNR2.0_1790																			*/  
/****************************************************************************************************/  
/* modified by  : Sangeetha G																		*/  
/* date         : 11-Feb-2009																		*/  
/* Bug Id       : PNR2.0_20849																		*/  
/* Bug Desc     : To include NoofLinesPerRow,RowHeight,Vscrollbar_Req,language settings property	*/  
/****************************************************************************************************/  
/* modified by  : Sangeetha G																		*/  
/* date         : 15-Apr-2009																		*/  
/* Bug Id       : PNR2.0_21576																		*/  
/* Modification : To include the gridlite property for grid type controls							*/  
/****************************************************************************************************/  
/* modified by  : Feroz																				*/  
/* date         : 04-Aug-2009																		*/  
/* Bug Id   : PNR2.0_2179																			*/  
/* Description  : Phase 3 Features - ListEdit, AttachDocument, Image & DateHighlight				*/  
/****************************************************************************************************/  
/* Modified By     : Feroz																			*/  
/* Date       : 26-Aug-2009																			*/  
/* Description     : PNR2.0_23463																	*/  
/****************************************************************************************************/  
/* modified by  : Feroz																				*/  
/* date         : 19-Jan-2010																		*/  
/* Bug Id   : PNR2.0_25308																			*/  
/* Description  : Phase 4 Features																	*/  
/****************************************************************************************************/  
/* modified by  : Jeya Latha K																		*/  
/* date         : 23-Jul-2010																		*/  
/* Bug Id  : PNR2.0_27796																			*/  
/* Description : Attach document for htm environment												*/  
/****************************************************************************************************/  
/* Modified By      : Chanheetha N A																*/  
/* Date            : 15-Sep-2010																	*/  
/* BugID       : PNR2.0_28319																		*/  
/* Description  : image upload for htm environment													*/  
/****************************************************************************************************/  
/* modified by   : Sangeetha G																		*/  
/* date			 : 11-Apr-2011																		*/  
/* BugId		 : PNR2.0_30869																		*/  
/* modified for		 : Feature Release  - timezone													*/  
/****************************************************************************************************/  
/* modified by   : Jeya Latha K																		*/  
/* date			 : 27-Jun-2011																		*/  
/* BugId		 : PNR2.0_32053																		*/  
/****************************************************************************************************/ 
/* modified by   : Balaji D																			*/  
/* date			 : July 06 2011																		*/  
/* BugId		 : PNR2.0_32224																		*/  
/****************************************************************************************************/ 
/* modified by   : Balaji D																			*/  
/* date			 : 01-Aug-2011																		*/  
/* BugId		 : PNR2.0_32770																		*/  
/* modified for	 : Provision to Specify Visible Length for Displayonly								*/ 
/*				   Control																			*/ 
/****************************************************************************************************/ 
/* modified by  :	Muthupandi S																	*/
/* date         :	22-September-2011																*/
/* Bug ID		:	PNR2.0_33487																	*/
/* Description	:	To add the property "Edit Combo Required" for the controltype combo				*/
/****************************************************************************************************/
/* modified by   : Balaji D																			*/  
/* date			 : 01-Aug-2011																		*/  
/* BugId		 : PNR2.0_36309																		*/  
/* modified for	 : Label Link features																*/ 
/****************************************************************************************************/ 
/* modified by  :	Gankan G																		*/
/* date         :	03-Nov-2012																		*/
/* Bug ID		:	PLF2.0_03057 																	*/
/* Description	:	Code Modified to inlucde new ISList Box property								*/
/****************************************************************************************************/
/* modified by  :	Shakthi P																		*/
/* date         :	26-FEB-2014												     					*/
/* Bug ID		:	PLF2.0_07676 																	*/
/* Description	:	Changes for 2.x-3.x iEDK Tab Index,Custom CSS inclusion, Grid Tool,Bar Hiding,	*/
/* Grid Tool Bar With Only Pagination, Grid Without Column Seperator and Grid Without Row Seperator	*/
/****************************************************************************************************/
/* modified by  :	 Shakthi P             															*/
/* date         : 12-Mar-2014            															*/
/* Bug ID  		: PLF2.0_07805          															*/
/* Description 	: Changes for Section Level RowSpan, ColSpan, Filler Section - Control Level RowSpan*/
/****************************************************************************************************/
/* modified by  : Shakthi P                                                     					*/
/* date         : 30 May 2014                                                 						*/
/* Bug Id       : PLF2.0_08470                                      	        					*/
/* Description  : Tooltip Not Required.ForceFit,Grid Column Caption Not Required 					*/
/* There is log of changes so,no modification History                            					*/
/****************************************************************************************************/
/* modified by  : Kanagavel A                                                    					*/
/* date         : 17/06/2014                                                 						*/
/* Description  : For section type Map Mapin and mapout added					 					*/
/****************************************************************************************************/
/* modified by  : Piranava T  																		*/
/* date         : Oct 10 2014																		*/
/* BugId        : PLF2.0_09035 																		*/
/* description  : Model changes for rowspan,colspan,IsStatic,IsCallout in� layout level				*/
/****************************************************************************************************/
/* modified by  : Piranava T  																		*/
/* date         : Dec 9 2014																		*/ 
/* description  : Model changes for Isfallback														*/
/****************************************************************************************************/
/* Modified by  : Veena U																			*/
/* Date         : 25-Feb-2015																		*/
/* Call ID		: PLF2.0_11499																		*/
/****************************************************************************************************/  
/* Modified by  : Veena U																			*/
/* Date         : 07-Aug-2015																		*/
/* Defect ID	: PLF2.0_14096																		*/
/****************************************************************************************************/
/* Modified by  : Veena U																			*/
/* Date         : 02-Feb-2016																		*/
/* Defect ID	: PLF2.0_16291																		*/
/****************************************************************************************************/
/* Modified by  : Veena U																			*/
/* Date         : 28-Mar-2016																		*/
/* Call ID		: PLF2.0_17570																		*/
/****************************************************************************************************/ 
/* modified by			Date				Defect ID											    */
/* Veena U				08-Jun-2016			PLF2.0_18487										    */
/****************************************************************************************************/
/* modified by                    Date                       Defect ID								*/
/* Veena U                        22-Jun-2016                PLF2.0_19034�							*/
/****************************************************************************************************/
/* Modified by : Jeya Latha K/Ganesh Prabhu S	for callid TECH-7349								*/
/* Modified on : 14-03-2017				 															*/
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and New Feature		*/
/*					Organization chart       														*/
/****************************************************************************************************/
/* Modified by : Ganesh Prabhu S/Ranjitha R      for callid  TECH-10118								*/
/* Modified on : 30-May-2017                                                                        */
/* Description : Platform Feature Release                                                           */
/****************************************************************************************************/
/* Modified by  : Jeya Latha K		Date: 16-Aug-2017  Defect ID	:TECH-12776						*/  
/****************************************************************************************************/
/* Modified by  : JeyaLatha K/Ranjitha R	Date: 31-Jan-2018  Defect ID : TECH-18349				*/  
/****************************************************************************************************/
/* Modified by  : Ranjitha R	Date: 28-Feb-2018  Defect ID : TECH-19347							*/  
/****************************************************************************************************/
/* Modified by  : Ranjitha R					  Date: 29-Mar-2018			 Defect ID : TECH-20326 */  
/* Modified by	: Jeya Latha K					  Defect ID: TECH-27036      On: 11-Oct-2018		*/
/* Modified by  : Jeya Latha K/Venkatesan K       Date: 17-Jun-2019          Defect ID : TECH-34971 */
/* Modified by : Jeya Latha K					  Date: 17-Jun-2019			 Defect ID: TECH-35368	*/
/* Modified by : Jeya Latha K                     Date: 30-Aug-2019			 Defect ID: TECH-37471	*/
/* Modified by  : Hareesh K						  Date: 07-Nov-2019			Defect ID: TECH-39785	*/
/****************************************************************************************************/
/* Modified by : Jeya Latha K                    Date: 04-Dec-2019  Defect ID : TECH-40809          */
/* Modified by : Jeya Latha K				     Date: 14-Jan-2020	Defect ID : TECH-41979          */
/* Modified by : Priyadharshini U/Rajeswari M	 Date: 29-Jan-2020  Defect ID : TECH-42483	        */
/* Modified by : Priyadharshini U/Rajeswari M	 Date: 26-May-2020  Defect ID : TECH-46646			*/
/* Modified by : Priyadharshini U/Rajeswari M	 Date: 26-NOV-2020  Defect ID : TECH-52688	        */
/* Modified by : Priyadharshini U/Jeya Latha K	 Date: 31-Mar-2022  Defect ID : TECH-66989	        */
/* Modified by : Priyadharshini U/Jeya Latha K	 Date: 13-Apr-2022  Defect ID : TECH-68066	        */
/* Modified by : Venkatesan K					 Date: 13-Apr-2022  Defect ID : TECH-68067	        */
/****************************************************************************************************/
/* Modified by	:	Priyadharshini U 																*/
/* Modified on	:	08/06/22				 														*/
/* Defect ID	:	TECH-69624																		*/
/* Description	:	Custom border, Custom actions and Responsive layout								*/
/****************************************************************************************************/
/* Modified by : Priyadharshini U/Vimal Kumar R														*/
/* Modified on : 27-July-2022																		*/
/* Defect ID   : TECH-71262																			*/
/* Description : Platform Features for the Month of July'22											*/
/****************************************************************************************************/
/* Modified by : Priyadharshini U / Athul M															*/
/* Modified on : 23-Aug-2022																		*/
/* Defect ID   : Tech-72114																			*/
/* Description : BadgeText Property for DataHyperLink Controls/Columns								*/
/****************************************************************************************************/
/* Modified by			: Priyadharshini U/Vimal Kumar R											*/
/* Date					: 27-Oct-2022																*/
/* Defect ID			: TECH-73996																*/
/****************************************************************************************************/
/* Modified by : Ponmalar A						Date: 13-Apr-2022  Defect ID : TECH-68066	        */
/****************************************************************************************************/
CREATE PROCEDURE ep_main13Spengg_vengg_l
@ctxt_ouinstance                        engg_ctxt_OUInstance,  --Input  
@ctxt_user                              engg_ctxt_User,  --Input  
@ctxt_language                          engg_ctxt_Language,  --Input  
@ctxt_service                           engg_ctxt_Service,  --Input  
@engg_basecmb_type                      engg_name,  --Input  
@engg_component                         engg_description,  --Input  
@engg_ctrlcmb_type                      engg_name,  --Input  
@engg_customer_name                     engg_name,  --Input  
@engg_modctr_desc                       engg_description,  --Input  
@engg_modctr_docu                       engg_description,  --Input  
@engg_process_descr                     engg_description,  --Input  
@engg_project_name                      engg_name,  --Input  
@engg_prop_desc                         engg_description,  --Input  
@engg_prop_req                          engg_seqno,  --Input  
@engg_req_no                            engg_name,  --Input 
@guid									engg_guid,  
@hidden_control1						engg_description,  
@modeflag                               engg_ModeFlag,  --Input  
@engg_1_fprowno                         engg_RowNo,  --Input/Output  
@engg_l_fprowno                         engg_RowNo,  --Input/Output  
@m_errorid                              engg_seqno output --To Return Execution Status  
  
as  
Begin  
-- nocount should be switched on to prevent phantom rows  
Set nocount on  
  
-- @m_errorid should be 0 to Indicate Success  
Set @m_errorid = 0  
  
--declaration of temporary variables  
  
--temporary and formal parameters mapping  
SET @ctxt_user                               = ltrim(rtrim(@ctxt_user))  
SET @ctxt_service                            = ltrim(rtrim(@ctxt_service))  
SET @modeflag                                = ltrim(rtrim(@modeflag))  
  
--null checking  
IF @ctxt_ouinstance = -915  
	SET @ctxt_ouinstance = null  

IF @ctxt_user = '~#~'  
	SET @ctxt_user = null  

IF @ctxt_language = -915  
	SET @ctxt_language = null  

IF @ctxt_service = '~#~'  
	SET @ctxt_service = null  

IF @engg_basecmb_type = '~#~'  
	SET @engg_basecmb_type = null  

IF @engg_component = '~#~'  
	SET @engg_component = null  

IF @engg_ctrlcmb_type = '~#~'  
	SET @engg_ctrlcmb_type = null  

IF @engg_customer_name = '~#~'  
	SET @engg_customer_name = null  

IF @engg_modctr_desc = '~#~'  
	SET @engg_modctr_desc = null 
	 
IF @engg_modctr_docu = '~#~'  
	SET @engg_modctr_docu = null  

IF @engg_process_descr = '~#~'  
	SET @engg_process_descr = null  

IF @engg_project_name = '~#~'  
	SET @engg_project_name = null  

IF @engg_prop_desc = '~#~'  
	SET @engg_prop_desc = null  

IF @engg_prop_req = -915  
	SET @engg_prop_req = null  

IF @engg_req_no = '~#~'  
	SET @engg_req_no = null

 
IF @modeflag = '~#~'  
	SET @modeflag = null 
	 
IF @engg_1_fprowno = -915  
	SET @engg_1_fprowno = null  

IF @engg_l_fprowno = -915  
	SET @engg_l_fprowno = null  
  
/*  
--OuputList  
Select null 'engg_1_fprowno',  
null 'engg_l_fprowno' from ***  
*/  

--SELECT 'Check', @engg_prop_desc 'ColumnName', @engg_prop_req 'Property'

If @ModeFlag ='S'
	Return
  
declare @engg_process_name			  engg_name,  
		@engg_comp_name				  engg_name,  
--code added by chanheetha on 22-Jun-2006 for the call id:PNR2.0_9056  
		@engg_ct_helpreq              engg_flag,  
		@engg_handleevent             engg_flag,  
		@engg_ct_zoomreq              engg_flag,  
		@engg_ct_base_ctrltype        engg_name,  
		@bse_ctl					  engg_name,  
		@hlp_req					  engg_flag,  
		@zm_req						  engg_flag,  
		@evt_req                      engg_flag,  
		@msg                          engg_description  
--code added by chanheetha on 22-Jun-2006 for the call id:PNR2.0_9056  
  
Select	@engg_process_name  = process_name,  
		@engg_comp_name		= component_name  
from	ep_ui_req_dtl (nolock)  
where	customer_name	= @engg_customer_name  
and		project_name	= @engg_project_name  
and		process_descr	= @engg_process_descr  
and		component_descr = @engg_component  
order by 1, 2  
  
if exists(Select 'x'  
from	es_comp_ctrl_type_mst(nolock)  
where	customer_name	= @engg_customer_name  
and		project_name	= @engg_project_name  
and		process_name    = @engg_process_name  
and		component_name  = @engg_comp_name  
and		ctrl_type_name  = @engg_ctrlcmb_type  
and		Inplace_Calendar= 'Y'  
and		base_ctrl_type  <> 'Edit'  )  
begin  
	Raiserror ('Inplace Calendar property is applicable only for Edit controls.',16,1)  
	return  
end  
  
if @engg_prop_desc = 'Handle Events' and @engg_prop_req = ''
begin
	set @engg_handleevent = case when @engg_prop_req = 1 then  'Y'  else 'N' end
end

--  if exists(Select 'x'  
--   from es_comp_ctrl_type_mst(nolock)  
--   where  customer_name = @engg_customer_name  
--   and project_name  =@engg_project_name  
--   and process_name   = @engg_process_name  
--   and component_name  = @engg_comp_name  
--   and ctrl_type_name = @engg_ctrlcmb_type  
-- --  and editmask_req  = 'Y'  
--   and base_ctrl_type <> 'Edit'  
--   )  
--  begin  
--   Raiserror ('EditMask property is applicable only for Edit controls.',16,1)  
--   return  
--  end  
  
--  if exists(Select 'x'  
--   from es_comp_ctrl_type_mst(nolock)  
--   where  customer_name = @engg_customer_name  
--   and project_name  =@engg_project_name  
--   and process_name   = @engg_process_name  
--   and component_name  = @engg_comp_name  
--   and ctrl_type_name = @engg_ctrlcmb_type  
--   and Inplace_Calendar  = 'Y'  
--   and base_ctrl_type = 'Edit'  
--   )  
--  begin  
--   if not exists ( select  'x'  
--      from  ep_ui_control_dtl (nolock)  
--      where  customer_name = @engg_customer_name  
--      and  project_name  = @engg_project_name  
--      and  process_name   = @engg_process_name  
--      and  component_name  = @engg_comp_name  
--      and  control_type  =	  
--       )  
--   begin  
--    Raiserror ('Inplace Calendar property is applicable only for Header controls.',16,1)  
--    return  
--   end  
--  end  
  
if exists(Select 'x'  
from	es_comp_ctrl_type_mst(nolock)  
where	customer_name	= @engg_customer_name  
and		project_name	= @engg_project_name  
and		process_name	= @engg_process_name  
and		component_name  = @engg_comp_name  
and		ctrl_type_name	= @engg_ctrlcmb_type  
and		spin_required   = 'Y')  
begin  
	if exists ( select  'x'  
	from	ep_ui_control_dtl (nolock)  
	where	customer_name	= @engg_customer_name  
	and		project_name	= @engg_project_name  
	and		process_name	= @engg_process_name  
	and		component_name  = @engg_comp_name  
	and		control_type	= @engg_ctrlcmb_type  )  
	begin  
		Raiserror ('Control type is mapped to a control, spin required property cannot be unchecked',16,1)  
		return  
	end  
end  

---- Validations For EMail, Phone ,Static Caption starts
if @engg_prop_desc = 'Editable' and @engg_prop_req = 1
begin
	if exists(Select 'x'
	from	es_comp_ctrl_type_mst(nolock)  
	where	customer_name	= @engg_customer_name  
	and		project_name	= @engg_project_name  
	and		process_name	= @engg_process_name  
	and		component_name  = @engg_comp_name  
	and		ctrl_type_name	= @engg_ctrlcmb_type  
	and		EMail			= 'Y')
	begin
		raiserror('Editable cannot be set when the Property Email is Chosen',16,1)
		return
	end
end

if @engg_prop_desc = 'Editable' and @engg_prop_req = 1
begin
	if exists (Select 'x'
	from	es_comp_ctrl_type_mst(nolock)  
	where	customer_name	= @engg_customer_name  
	and		project_name	= @engg_project_name  
	and		process_name	= @engg_process_name  
	and		component_name  = @engg_comp_name  
	and		ctrl_type_name	= @engg_ctrlcmb_type  
	and		Phone			= 'Y')
	begin
		raiserror('Editable cannot be set when the Property Phone is Chosen',16,1)
		return
	end
end

if @engg_prop_desc = 'StaticCaption' and @engg_prop_req = 1
begin
	if exists (Select 'x'
	from	es_comp_ctrl_type_mst(nolock)  
	where	customer_name	= @engg_customer_name  
	and		project_name	= @engg_project_name  
	and		process_name	= @engg_process_name  
	and		component_name  = @engg_comp_name  
	and		ctrl_type_name	= @engg_ctrlcmb_type  
	and		attach_document = 'N')
	begin
		raiserror('Attach Document Needs to be set when the Property Static Caption is Chosen',16,1)
		return
	end
end

if @engg_prop_desc = 'Browse Button' and @engg_prop_req = 1
begin
	if exists (Select 'x'
	from	es_comp_ctrl_type_mst(nolock)  
	where	customer_name	= @engg_customer_name  
	and		project_name	= @engg_project_name  
	and		process_name	= @engg_process_name  
	and		component_name  = @engg_comp_name  
	and		ctrl_type_name	= @engg_ctrlcmb_type  
	and		StaticCaption	= 'Y')
	begin
		raiserror('Browse Button cannot to be set when the Property Static Caption is Chosen',16,1)
		return
	end
end

if @engg_prop_desc = 'Caption Required' and @engg_prop_req = 1
begin
	if exists(Select 'x'
	from	es_comp_ctrl_type_mst(nolock)  
	where	customer_name = @engg_customer_name  
	and		project_name  = @engg_project_name  
	and		process_name  = @engg_process_name  
	and		component_name= @engg_comp_name  
	and		ctrl_type_name= @engg_ctrlcmb_type  
	and		StaticCaption = 'Y')
	begin
		raiserror('Caption Required cannot to be set when the Property Static Caption is Chosen',16,1)
		return
	end
end

--added for preevent postevent handling
if @modeflag in ('X','I')
begin 
	if @engg_prop_desc in ('Pre Event','Post Event') 
	begin
		if not exists (Select 'x'
		from	es_comp_ctrl_type_mst(nolock)  
		where	customer_name	= @engg_customer_name  
		and		project_name	= @engg_project_name  
		and		process_name	= @engg_process_name  
		and		component_name  = @engg_comp_name  
		and		ctrl_type_name  = @engg_ctrlcmb_type  
		and		(Browse_Button_Enable  = 'Y' or Delete_Button_Enable  = 'Y' or Upload  = 'Y'))
		begin
			raiserror('preevent and postevent both are applicable for browse/upload/delete enabled button',16,1)
			return
		end
	end
end

if @modeflag in ('X','I','U','Y')
begin 
--added for preevent postevent handling
	if @engg_prop_desc in ('Pre Event','Post Event') 
	begin
		if exists (Select 'x'
		from	es_comp_ctrl_type_mst(nolock)  
		where	customer_name	= @engg_customer_name  
		and		project_name	= @engg_project_name  
		and		process_name	= @engg_process_name  
		and		component_name  = @engg_comp_name  
		and		ctrl_type_name	= @engg_ctrlcmb_type  
		and		postevent		= 'Y' 
		and		preevent		= 'Y')
		begin
			raiserror('preevent and postevent both are not applicable for one controltype',16,1)
			return
		end
	end
end
---- Validations For EMail, Phone ,Static Caption ends
---- Validations For Is Hijri Starts
if @modeflag in ('X','I','U','Y')
Begin
	if @engg_prop_desc in ('Is Hijri')  and	@engg_prop_req = 1	
	Begin
		if exists(Select 'x'  
		from	es_comp_ctrl_type_mst(nolock)  
		where	customer_name	= @engg_customer_name  
		and 	project_name	= @engg_project_name  
		and 	process_name    = @engg_process_name  
		and 	component_name  = @engg_comp_name  
		and 	ctrl_type_name  = @engg_ctrlcmb_type  
		and 	ishijri			='Y'
		and 	isnull(editable_flag,'')<> 'Y')  
		begin  
			Raiserror ('Is Hijri property is applicable only for Editable property is enabled.',16,1)  
			return  
		end  
	End
End
---- Validations For Is Hijri Starts

--  if exists ( Select 'x'  
--     from es_comp_ctrl_type_mst (nolock)  
--     where customer_name = @engg_customer_name  
--     and project_name = @engg_project_name  
--     and process_name = @engg_process_name  
--     and component_name = @engg_comp_name  
--     and ctrl_type_name = @engg_ctrlcmb_type  
--     and base_ctrl_type <> @engg_basecmb_type  
--    )  
--  begin  
--   if  exists ( Select 'x'  
--      from ep_ui_control_dtl (nolock)  
--      where customer_name   = @engg_customer_name  
--      and    project_name = @engg_project_name  
--      and    component_name = @engg_comp_name  
--      and    process_name    = @engg_process_name  
--      and control_type = @engg_ctrlcmb_type  
--      union  
--      select 'x'  
--      from ep_ui_grid_dtl (nolock)  
--      where customer_name   = @engg_customer_name  
--      and    project_name = @engg_project_name  
--      and    component_name = @engg_comp_name  
--      and    process_name    = @engg_process_name  
--      and column_type = @engg_ctrlcmb_type  
--    )  
--   begin  
--    select @msg = 'Control Type is in use. It Cannot be modifeid. '  
--    exec   engg_error_sp  
--     es_cmpui_sp_savectctml, '7',   @msg,  @ctxt_language,  
--     @ctxt_ouinstance,       @ctxt_service,  @ctxt_user, '',  
--     '',      '',    '',   @m_errorid out  
--    if @m_errorid <> 0  
--    return  
--   end  
--  end  
--code added by chanheetha on 22-Jun-2006 for the call id:PNR2.0_9056  
/*
----------Rating and Captcha
if @modeflag in ('X','I','U','Y')
begin 
	if @engg_prop_desc in ('Is Rating') and	@engg_prop_req = 1
	begin
		if exists(Select 'x'
		from es_comp_ctrl_type_mst(nolock)  
		where  customer_name	= @engg_customer_name  
		and  project_name		= @engg_project_name  
		and  process_name		= @engg_process_name  
		and  component_name		= @engg_comp_name  
		and  ctrl_type_name		= @engg_ctrlcmb_type  
		and	 isnull(IsCaptcha,'N')= 'Y')
		begin
			raiserror('Is Rating and Is Captcha both are not applicable for one controltype',16,1)
			return
		end
	end
	
	if @engg_prop_desc in ('Is Captcha') and	@engg_prop_req = 1
	begin
		if exists(Select 'x'
		from es_comp_ctrl_type_mst(nolock)  
		where  customer_name	= @engg_customer_name  
		and  project_name		= @engg_project_name  
		and  process_name		= @engg_process_name  
		and  component_name		= @engg_comp_name  
		and  ctrl_type_name		= @engg_ctrlcmb_type  
		and	 isnull(IsRatingControl,'N')	= 'Y')
		begin
			raiserror('Is Rating and Is Captcha both are not applicable for one controltype',16,1)
			return
		end
	end	
end*/
-----------------------
if @engg_prop_desc = 'System Generated File ID' and @engg_prop_req = 1 
begin
	if exists(Select 'x'
	from	es_comp_ctrl_type_mst(nolock)  
	where	customer_name	= @engg_customer_name  
	and		project_name	= @engg_project_name  
	and		process_name	= @engg_process_name  
	and		component_name  = @engg_comp_name  
	and		ctrl_type_name	= @engg_ctrlcmb_type  
	and		AttachmentWithDesc = 'y')
	begin 
		raiserror('Attach Document Description and System Generated File id both are not applicable for one controltype',16,1)
		return
	end
end

if @engg_prop_desc = 'Attachment with Description' and @engg_prop_req = 1 
begin
	if exists(Select 'x'
	from	es_comp_ctrl_type_mst(nolock)  
	where	customer_name	= @engg_customer_name  
	and		project_name	= @engg_project_name  
	and		process_name	= @engg_process_name  
	and		component_name  = @engg_comp_name  
	and		ctrl_type_name	= @engg_ctrlcmb_type  
	and		SystemGeneratedFileId  = 'y')
	begin
		raiserror('Attach Document Description and System Generated File id both are not applicable for one controltype',16,1)
		return
	end
end

----04Feb2022 (14469)

IF @engg_prop_desc = 'Dynamic File Upload Path' AND @engg_prop_req = 1
BEGIN
	IF EXISTS(SELECT 'x'
	FROM	es_comp_ctrl_type_mst(NOLOCK)  
	WHERE	customer_name				= @engg_customer_name  
	AND		project_name				= @engg_project_name  
	AND		process_name				= @engg_process_name  
	AND		component_name				= @engg_comp_name  
	AND		ctrl_type_name				= @engg_ctrlcmb_type  
	AND		isnull(AttachmentWithDesc,'')	= '')
	BEGIN
		RAISERROR('If "Dynamic File Upload Path" is selected, then "Attachment with description" attribute must be selected.',16,1)
		RETURN
	END
END

----Commented for TECH-75230
--Code added for the Defect Id Tech-68066 starts

--IF @engg_prop_desc IN( 'Pre Task','Post Task') AND @engg_prop_req = 1
--BEGIN
--	IF EXISTS(SELECT 'x'
--	FROM	es_comp_ctrl_type_mst(NOLOCK)  
--	WHERE	customer_name				= @engg_customer_name  
--	AND		project_name				= @engg_project_name  
--	AND		process_name				= @engg_process_name  
--	AND		component_name				= @engg_comp_name  
--	AND		ctrl_type_name				= @engg_ctrlcmb_type 
--	AND		isnull(attach_document,'')	= ''
--	BEGIN
--		RAISERROR('Attachment Document must be selected for PreTask, PostTask and Bulk Download.',16,1)
--		RETURN
--	END
--END
----Commented for TECH-75230

--Code added for the Defect Id Tech-68066 Ends

--Code added for the Defect Id Tech-71262 on 14July22 starts

IF @engg_prop_desc IN( 'Browse Post Task','Browse Pre Task') AND @engg_prop_req = 1
BEGIN
	IF EXISTS(SELECT 'x'
	FROM	es_comp_ctrl_type_mst(NOLOCK)  
	WHERE	customer_name				= @engg_customer_name  
	AND		project_name				= @engg_project_name  
	AND		process_name				= @engg_process_name  
	AND		component_name				= @engg_comp_name  
	AND		ctrl_type_name				= @engg_ctrlcmb_type   
	AND		(isnull(Browse_Button_Enable,'')	= ''
	OR		isnull(Browse_Button_Enable,'')	= 'N' ))
	BEGIN
		RAISERROR('Browse Button must be selected for Browse Pre Task, Browse Post Task.',16,1)
		RETURN
	END
END
IF @engg_prop_desc IN( 'Delete Pre Task','Delete Post Task') AND @engg_prop_req = 1
BEGIN
	IF EXISTS(SELECT 'x'
	FROM	es_comp_ctrl_type_mst(NOLOCK)  
	WHERE	customer_name				= @engg_customer_name  
	AND		project_name				= @engg_project_name  
	AND		process_name				= @engg_process_name  
	AND		component_name				= @engg_comp_name  
	AND		ctrl_type_name				= @engg_ctrlcmb_type 
	AND		(isnull(Delete_Button_Enable,'')	= ''
	OR		isnull(Delete_Button_Enable,'')	= 'N' ))
	BEGIN
		RAISERROR('Delete Button must be selected for Delete Pre Task, Delete Post Task.',16,1)
		RETURN
	END
END

IF @engg_prop_desc IN( 'Button Style') AND @engg_prop_req = 1
BEGIN
	IF EXISTS(SELECT 'x'
	FROM	es_comp_ctrl_type_mst(NOLOCK)  
	WHERE	customer_name				= @engg_customer_name  
	AND		project_name				= @engg_project_name  
	AND		process_name				= @engg_process_name  
	AND		component_name				= @engg_comp_name  
	AND		ctrl_type_name				= @engg_ctrlcmb_type 
	AND		(isnull(editable_flag,'')	= 'Y'))
	BEGIN
		RAISERROR('Button Style is applicable only for Display only controls.',16,1)
		RETURN
	END
END

IF @engg_prop_desc IN( 'Editable') AND @engg_prop_req = 1
BEGIN
	IF EXISTS(SELECT 'x'
	FROM	es_comp_ctrl_type_mst_extn(NOLOCK)  
	WHERE	customer_name				= @engg_customer_name  
	AND		project_name				= @engg_project_name  
	AND		process_name				= @engg_process_name  
	AND		component_name				= @engg_comp_name  
	AND		ctrl_type_name				= @engg_ctrlcmb_type 
	AND		(isnull(ButtonStyle,'')	= 'Y'))
	BEGIN
		RAISERROR('Editable is applicable only for Display only controls.',16,1)
		RETURN
	END
END


IF @engg_prop_desc IN( 'Is List','Is Mobile') AND @engg_prop_req = 1
BEGIN
	IF EXISTS(SELECT 'x'
	FROM	es_comp_ctrl_type_mst_extn(NOLOCK)  
	WHERE	customer_name				= @engg_customer_name  
	AND		project_name				= @engg_project_name  
	AND		process_name				= @engg_process_name  
	AND		component_name				= @engg_comp_name  
	AND		ctrl_type_name				= @engg_ctrlcmb_type 
	AND		(ISNULL(islist,'')	= 'y'
	OR		ISNULL(ismobile,'')	= 'y' ))
	BEGIN
		RAISERROR('Please select either Is List or Is Mobile Attributes.',16,1)
		RETURN
	END
END
--Code added for the Defect Id Tech-71262 on 14July22 Ends
--TECH-73996

DECLARE @cnt_control_type	engg_seqno,
		@cnt_column_type	engg_seqno

SELECT 	@cnt_control_type		=	count(*) 
FROM (	SELECT	control_type,ui_name
		FROM	ep_ui_control_dtl WITH(NOLOCK)
		WHERE	customer_name	= @engg_customer_name  
		AND		project_name	= @engg_project_name  
		AND		process_name	= @engg_process_name  
		AND		component_name	= @engg_comp_name  
		AND		control_type	= @engg_ctrlcmb_type
		GROUP BY ui_name,control_type) a

SELECT 	@cnt_column_type		=	count(*) 
FROM (	SELECT	 column_type,ui_name
		FROM	 ep_ui_grid_dtl WITH(NOLOCK)
		WHERE	 customer_name	= @engg_customer_name  
		AND		 project_name	= @engg_project_name  
		AND		 process_name	= @engg_process_name  
		AND		 component_name	= @engg_comp_name  
		AND		 column_type	= @engg_ctrlcmb_type
		GROUP BY ui_name,column_type) b

	IF @cnt_column_type > 1 OR @cnt_control_type >	1
	BEGIN 
	IF EXISTS (	SELECT 'X' 
				FROM es_quick_code_met WITH(NOLOCK)
				WHERE	CustomerName	=	@engg_customer_name
				AND		ProjectName		=	@engg_project_name
				AND		ParameterCode	=	'ControlTypeChange'
				AND		ParameterText	=	'UI_LEVEL_CONTROL_TYPE'
				AND		ParameterValue	=	'Y' )
		BEGIN
		RAISERROR('Selected Control type is used in more than one User Interfaces. Please create a new control type and choose the required attributes.',16,1)
		END
		END
			
--TECH-73996


/** 
	For Validating anyone of the Grid Property is selected.
	code added for Defect Id: TECH-20326 starts. */	

Declare @renderas engg_description

select	@renderas		= isnull(renderas,'')
from	es_comp_ctrl_type_mst  (nolock)  
where	customer_name	= @engg_customer_name  
and		project_name	= @engg_project_name  
and		process_name	= @engg_process_name  
and		component_name	= @engg_comp_name  
and		ctrl_type_name	= @engg_ctrlcmb_type  
--select 'tt',@renderas
--If	isnull(@renderas,'') = 'Chips'
--Begin
--select 'tt1'
If	isnull(@renderas,'') <> '' and 
		  ((@engg_prop_desc ='Is Tag' and @engg_prop_req = 1) or (@engg_prop_desc ='Grid to Form' and @engg_prop_req = 1) or 
		  (@engg_prop_desc ='Multi-Selector Grid' and @engg_prop_req = 1) or (@engg_prop_desc ='Row Expander'	and @engg_prop_req = 1)
		  or (@engg_prop_desc ='Rule Builder'	and @engg_prop_req = 1) or (@engg_prop_desc ='Calendar Control'	and @engg_prop_req = 1))--Added for TECH-35368
		 
Begin
		Raiserror ('Kindly provide any one attribute from the following list ''Is Tag, Multi-Selector Grid, Row Expander, Grid to Form, Rule Builder, Calendar''.', 16,1)
		Return
	End	
--End
--Else If	isnull(@renderas,'') <> 'Chips'
--Begin
----select 'tt2'
--	If	isnull(@renderas,'') <> ''  and 
--			  ((@engg_prop_desc ='Is Tag' and @engg_prop_req = 1) or (@engg_prop_desc ='Grid to Form' and @engg_prop_req = 1) or 
--			  (@engg_prop_desc ='Multi-Selector Grid' and @engg_prop_req = 1) or (@engg_prop_desc ='Row Expander'	and @engg_prop_req = 1)
--			  or (@engg_prop_desc ='Rule Builder'	and @engg_prop_req = 1) or (@engg_prop_desc ='Calendar Control'	and @engg_prop_req = 1)--Added for TECH-35368
--			   )
--	Begin
--		Raiserror ('Kindly provide any one attribute from the following list ''Is Tag, Multi-Selector Grid, Row Expander, Grid to Form, Rule Builder, Calendar''.', 16,1)
--		Return
--	End	
--End
/** code added for Defect Id: TECH-20326 ends. */		

if exists( select 'X'  
from   es_comp_ctrl_type_mst(nolock)  
where  customer_name  = @engg_customer_name  
and    project_name   = @engg_project_name  
and    component_name = @engg_comp_name  
and    process_name   = @engg_process_name  
and    ctrl_type_name = @engg_ctrlcmb_type )  
begin  
	if exists (select 'x' from  
	ep_ui_control_dtl (nolock)  
	where  customer_name	= @engg_customer_name  
	and    project_name		= @engg_project_name  
	and    component_name	= @engg_comp_name  
	and    process_name		= @engg_process_name  
	and    control_type		= @engg_ctrlcmb_type  
	union  
	select 'x' from  
	ep_ui_grid_dtl (nolock)  
	where  customer_name	= @engg_customer_name  
	and    project_name		= @engg_project_name  
	and    component_name	= @engg_comp_name  
	and    process_name		= @engg_process_name  
	and    column_type		= @engg_ctrlcmb_type )  
	begin   
		if @engg_prop_desc = 'Handle Events'  
		begin  
			set @engg_handleevent = case when @engg_prop_req = 1 then  'Y'  else 'N' end  
		end  
  
		if @engg_prop_desc = 'Help Required'  
		begin  
			set @engg_ct_helpreq  = case when @engg_prop_req = 1 then  'Y'  else 'N' end  
		end  
  
		if @engg_prop_desc = 'Zoom'  
		begin  
			set @engg_ct_zoomreq  = case when @engg_prop_req = 1 then  'Y'  else 'N' end  
		end  
  
		select	@bse_ctl = base_ctrl_type,  
				@hlp_req = help_req,  
				@zm_req  = zoom_req,  
				@evt_req = event_handling_req  
		from	es_comp_ctrl_type_mst(nolock)  
		where	customer_name  = @engg_customer_name  
		and     project_name   = @engg_project_name  
		and     component_name = @engg_comp_name  
		and     process_name   = @engg_process_name  
		and     ctrl_type_name = @engg_ctrlcmb_type  
  
		if  @engg_basecmb_type <> @bse_ctl	or  isnull(@engg_ct_helpreq,@hlp_req)  <> @hlp_req or  
			isnull(@engg_ct_zoomreq,@zm_req)  <> @zm_req  or  isnull(@engg_handleevent,@evt_req)  <> @evt_req  
		begin  
			select @msg  = 'Control Name '''+ @engg_ctrlcmb_type + ''' is in use.'  
			exec engg_error_sp  
				ep_uip_sp_savectctml,	'1',		@msg,		@ctxt_language,		 @ctxt_ouinstance,  
				@ctxt_service,			@ctxt_user, '',			'',					 '',  
				'',						@m_errorid out  
			if @m_errorid <> 0  
				return  
		end  
	end  
end  
  
--code added by chanheetha on 22-Jun-2006 for the call id:PNR2.0_9056  
-- Modified By feroz for bug id :PNR2.0_23463  
-- Adde by Feroz for Date highlight -- start  
-- If @modeflag = 'U'  
-- Begin  
--  if @engg_prop_desc = 'Date Highlight' and @engg_prop_req = 1 and @engg_basecmb_type = 'ListEdit'  
--  begin  
--   if not exists ( select 'x'  
--      from ep_date_highlight_column (nolock)  
--      where customer_name  = @engg_customer_name  
--      and     project_name   = @engg_project_name  
--      and     component_name = @engg_comp_name  
--      and     process_name   = @engg_process_name  
--      and     listedit_synonym = @engg_ctrlcmb_type)  
--   begin  
--  
--    if len(@engg_ctrlcmb_type) > 21  
--    begin  
--     Raiserror ('Control type length should be less than 21 characters if Date Higlight is selected',16,1)  
--     return  
--    end  
--  
--    insert into ep_date_highlight_column  
--    (customer_name, project_name, req_no, process_name, component_name, listedit_synonym, listedit_column_synonym, createdby, createddate, wrkreqno)  
--    select  
--     @engg_customer_name, @engg_project_name, 'Base', @engg_process_name, @engg_comp_name, @engg_ctrlcmb_type, @engg_ctrlcmb_type + '_listdate', @ctxt_user, getdate(), @engg_req_no  
--    union  
--    select  
--    @engg_customer_name, @engg_project_name, 'Base', @engg_process_name, @engg_comp_name, @engg_ctrlcmb_type, @engg_ctrlcmb_type + '_color', @ctxt_user, getdate(), @engg_req_no  
--    union  
--    select  
--    @engg_customer_name, @engg_project_name, 'Base', @engg_process_name, @engg_comp_name, @engg_ctrlcmb_type, @engg_ctrlcmb_type + '_tooltip', @ctxt_user, getdate(), @engg_req_no  
--  
--   end  
--  end  
-- end  
-- Adde by Feroz for Date highlight -- End  
-- Modified By feroz for bug id :PNR2.0_23463  
  
  
--For Static Controls  
Declare  @required  Engg_name  
Declare  @column	Engg_name  
declare  @event		Engg_name  
  
If @engg_prop_req = 1  
	Set @required = 'y' else set @required = 'N'  
  
If @modeflag = 'U'  
Begin  
  
	if exists( select 'X'  
	from   es_comp_stat_ctrl_type_mst(nolock)  
	where  customer_name  = @engg_customer_name  
	and    project_name   = @engg_project_name  
	and    component_name = @engg_comp_name  
	and    process_name   = @engg_process_name  
	and    ctrl_type_name = @engg_ctrlcmb_type )  
	begin  
		Raiserror ('Static control property cannot be modified',16,1)  
		return  
	end  
	If  @engg_prop_desc  = 'Caption Required'  
		Set  @column   = 'caption_req'  
	If  @engg_prop_desc  = 'Handle Events'  
		Set  @column   = 'event_handling_req'  
	If  @engg_prop_desc  = 'Handle Events'  
		Set  @column   = 'event_handling_req'  
	If  @engg_prop_desc  = 'Caption Wrap'  
		Set  @column   = 'caption_wrap'  
	If  @engg_prop_desc  = 'Editable'  
		Set  @column   = 'editable_flag'  
	If  @engg_prop_desc  = 'Ellipses Required'  
		Set  @column   = 'ellipses_req'  
	If  @engg_prop_desc  = 'Ellipses Required'  
		Set  @column   = 'ellipses_req'  
	If  @engg_prop_desc  = 'Help Required'  
		Set  @column   = 'help_req'  
	If  @engg_prop_desc  = 'Mandatory'  
		Set  @column   = 'mandatory_flag'  
	If  @engg_prop_desc  = 'Password Char'  
		Set  @column   = 'password_char'  
	If  @engg_prop_desc  = 'Visible'  
		Set  @column   = 'visisble_flag'  
	If  @engg_prop_desc  = 'Zoom'  
		Set  @column   = 'zoom_req'  
	If  @engg_prop_desc  = 'Zoom'  
		Set  @column   = 'zoom_req'  
	If  @engg_prop_desc  = 'Allow Deletion'  
		Set  @column   = 'delete_req'  
	If  @engg_prop_desc  = 'Allow Insertion'  
		Set  @column   = 'insert_req'  
	If  @engg_prop_desc  = 'Display only combo'  
		Set  @column   = 'disponlycmb_req'  
	If  @engg_prop_desc  = 'HTML text area'  
		Set  @column   = 'html_txt_area'  
	If  @engg_prop_desc  = 'Report Required'  
		Set  @column   = 'report_req'  
	If  @engg_prop_desc  = 'Select Flag'  
		Set  @column   = 'select_flag'  
	If  @engg_prop_desc  = 'Inplace Calendar'  
		Set  @column   = 'Inplace_Calendar'  
-- Code Added by Jeya for bug id :PNR2.0_27796 Starts  
	If  @engg_prop_desc  = 'Lite Attach Document'  
		Set  @column   = 'Lite_Attach_Document'  
	If  @engg_prop_desc  = 'Browse Button'  
		Set  @column   = 'Browse_Button_Enable'  
	If  @engg_prop_desc  = 'Delete Button'  
		Set  @column   = 'Delete_Button_Enable'  
-- Code Added by Jeya for bug id :PNR2.0_27796 End  
--code added for the caseid : PNR2.0_28319 starts  
	If  @engg_prop_desc  = 'Image Preview Required'  
		Set  @column   = 'Image_Preview_Req'   
	If  @engg_prop_desc  = 'Lite Attach Image'  
		Set  @column   = 'Lite_Attach_Image'  
--code added for the caseid : PNR2.0_28319 ends  
--   If  @engg_prop_desc  = 'EditMask required'  
--   Set  @column   = 'EditMask_req'  
--select @column  
-- code commented by feroz for bug id : PNR2.0_18395  

--Code Modification for PNR2.0_30869 starts
	If  @engg_prop_desc  = 'TimeZone'  
		Set  @column   = 'timezone'  
--Code Modification for PNR2.0_30869 ends
  
--Code Modification for PNR2.0_32053 starts
	If  @engg_prop_desc  = 'Auto Expand'  
		Set  @column   = 'autoexpand'  
--Code Modification for PNR2.0_32053 ends

--If  @engg_prop_desc  = 'Attachment with Description'
--Set  @column   = 'AttachmentWithDesc'  

--Code Modification for PNR2.0_32770 starts
	If	@engg_prop_desc  = 'Apply Visible Length'  
		Set @column			 = 'Disp_Only_Apply_Len'  
--Code Modification for PNR2.0_32770 ends
/*Modification made by Muthupandi S for Bug id : PNR2.0_33487 Starts*/
	If @engg_prop_desc  = 'Edit combo Required'
		Set @column    = 'editcombo_req'
/*Modification made by Muthupandi S for Bug id : PNR2.0_33487 Ends*/

--Code Modification for PNR2.0_36309 starts
	If	@engg_prop_desc  = 'Label Link'  
		Set @column			 = 'Label_Link'  
--Code Modification for PNR2.0_36309 ends

	If	@engg_prop_desc  = 'Is Fallback'  
		Set @column			 = 'Isfallback'  
	If	@engg_prop_desc  = 'Upload'  
		Set @column			 = 'Upload'  
	If	@engg_prop_desc  = 'Is Data'  
		Set @column			 = 'config_value'  
	If	@engg_prop_desc  = 'Configuration Parameter'  
		Set @column			 = 'config_parameter'  
	If @engg_prop_desc	=	'Is Varbinary'
		Set @column			 = 'Is_Varbinary'
	If @engg_prop_desc  = 'EMail'
		Set @column    = 'EMail'
	If @engg_prop_desc  = 'Phone'
		Set @column    = 'Phone'
	If @engg_prop_desc  = 'Static Caption'
		Set @column    = 'StaticCaption'
	If @engg_prop_desc  = 'Data Grid'
		Set @column    = 'DataGrid'
	If @engg_prop_desc  = 'Move PreviousSet'
		Set @column    = 'Move_PrevSet'
	If @engg_prop_desc  = 'Move First'
		Set @column    = 'MoveFirst'
	If @engg_prop_desc  = 'Move Previous'
		Set @column    = 'Move_Previous'
	If @engg_prop_desc  = 'Move Next'
		Set @column    = 'Move_Next'
	If @engg_prop_desc  = 'Move NextSet'
		Set @column    = 'Move_NextSet'
	If @engg_prop_desc  = 'Move Last'
		Set @column    = 'Move_Last'
	If @engg_prop_desc  = 'Carousel Required'
		Set @column    = 'Carousel_Req'
	If @engg_prop_desc  = 'ISDeviceInfo'
		Set @column    = 'ISDeviceInfo'
	If @engg_prop_desc  = 'List Control'
		Set @column    = 'ListControl'
	If @engg_prop_desc  = 'Pre Event'
		Set @column    = 'Pre Event'
	If @engg_prop_desc  = 'Post Event'
		Set @column    = 'Post Event'
	If @engg_prop_desc  = 'Prevent Download'
		Set @column    = 'PreventDownload'
	If @engg_prop_desc  = 'Aviation Download'
		Set @column    = 'avn_download'
	If @engg_prop_desc  = 'Is Hijri'
		Set @column    = 'ishijri'
	If @engg_prop_desc  = 'Enable Default'  
		Set @column    = 'enabledefault'
	If @engg_prop_desc  = 'Hide	Insert'
		Set @column    = 'hideinsert'
	If @engg_prop_desc  = 'Hide Delete'  
		Set @column    = 'hidedelete'
	If @engg_prop_desc  = 'Hide Copy and Append Row'  
		Set @column    = 'hidecopy'
	If @engg_prop_desc  = 'Hide Cut and Append Row'  
		Set @column    = 'hidecut'
	If @engg_prop_desc  = 'Hide Filter Data'  
		Set @column    = 'hidefilterdata'
	If @engg_prop_desc  = 'Hide Export to PDF'  
		Set @column    = 'hidepdf'
	If @engg_prop_desc  = 'Hide Export to Report'  
		Set @column    = 'hidereport'
	If @engg_prop_desc  = 'Hide Export to HTML'  
		Set @column    = 'hidehtml'
	If @engg_prop_desc  = 'Hide Export to Excel'  
		Set @column    = 'hideexportexcel'
	If @engg_prop_desc  = 'Hide Export to CSV'  
		Set @column    = 'hideexportcsv'
	If @engg_prop_desc  = 'Hide Export to Text'  
		Set @column    = 'hideexporttext'
	If @engg_prop_desc  = 'Hide Import Data'  
		Set @column    = 'hideimportdata'
	If @engg_prop_desc  = 'Hide Chart'  
		Set @column    = 'hidechart'
	If @engg_prop_desc  = 'Hide Export to Open Office'  
		Set @column    = 'hideexportopenoffice'
	If @engg_prop_desc  = 'Hide Personalization'  
		Set @column    = 'hidepersonalize'
	If @engg_prop_desc  = 'Hide Column Chooser'  
		Set @column    = 'hidefiltercolumn'
	If @engg_prop_desc  = 'Spin-System Task'  
		Set @column    = 'spin_system_task'
	If @engg_prop_desc  = 'Auto List Without Filter Not Required' 
		Set @column    = 'autolist_not_req'
	If @engg_prop_desc  =  'Hide Select' 
		Set @column    = 'hideselect'
	If @engg_prop_desc  =  'No Rows to Display Not Required' 
		Set @column    = 'norowstodisplay_notreq'
	If @engg_prop_desc  =  'AutoHeight' 
		Set @column    = 'AutoHeight'
--Changes for PLF2.0_16291
--If @engg_prop_desc  =  'Is Pivot'-- code added for PLF2.0_16291 
--Set @column    = 'IsPivot'
	If @engg_prop_desc  =  'QlikLink'
		Set @column    = 'QlikLink'
	If @engg_prop_desc  =  'Is Marquee'
		Set @column    = 'IsMarquee'
--If @engg_prop_desc  =  'Is Assorted'
--Set @column    = 'IsAssorted'
/*If @engg_prop_desc  =  'Is Captcha'
Set @column    = 'IsCaptcha'
If @engg_prop_desc  =  'Is Rating'
Set @column    = 'IsRatingControl' */
	If @engg_prop_desc  =  'System Generated File Id'
		Set @column    = 'systemgeneratedfileid'
	If @engg_prop_desc  in  ('Is Tag', 'Grid to Form', 'Multi-Selector Grid', 'Row Expander','Is Organization Chart','Rule Builder','Calendar Control')--Added for TECH-35368
		Set @column    = 'RenderAs'
	--If @engg_prop_desc  =  'Is TreeGrid'
--Set @column    = 'RenderAs'
	If @engg_prop_desc  =  'Is Chips'
		Set @column    = 'IsChips'

	If @engg_prop_desc  =  'Multi Select For List'
		Set @column    = 'MultiSelect'				--code added by 13639 on 24th Nov2020

	If @engg_prop_desc  =  'Is Mobile'
		Set @column    = 'IsMobile'			--code added by 13639 

	If @engg_prop_desc  =  'Is Scheduler'
		Set @column    = 'IsScheduler'			--code added by 13639 

	If @engg_prop_desc  =  'Pagination Required'
		Set @column    = 'PaginationReqd'		--code added by 13639 

	If @engg_prop_desc  =  'Update Task Required'
		Set @column    = 'UpdateTaskReqd'		--code added by 13639 

	If @engg_prop_desc  =  'Delete Task Required'
		Set @column    = 'DeleteTaskReqd'		--code added by 13639 

	If @engg_prop_desc  =  'Pre Task'
		Set @column    = 'PreTask'		----Code added for the Defect Id Tech-68066 

	If @engg_prop_desc  =  'Post Task'
		Set @column    = 'PostTask'		----Code added for the Defect Id Tech-68066 

	----Code added for the Defect Id Tech-71262 on 14July22 starts
	If @engg_prop_desc  =  'Browse Pre Task'
		Set @column    = 'BrowsePreTask'		

	If @engg_prop_desc  =  'Browse Post Task'
		Set @column    = 'BrowsePostTask'		
	
	If @engg_prop_desc  =  'Delete Pre Task'
		Set @column    = 'DeletePreTask'		

	If @engg_prop_desc  =  'Delete Post Task'
		Set @column    = 'DeletePostTask'		

	If @engg_prop_desc  =  'Button Style'
		Set @column    = 'ButtonStyle'		
	----Code added for the Defect Id Tech-71262 on 14July22 ends
	--Code added for Defect Id Tech-73996 starts 
	If @engg_prop_desc  =  'Eye Icon for Password'
		Set @column    = 'EyeIconForPassword'	
	If @engg_prop_desc  =  'Signature'
		Set @column    = 'Signature'	
	If @engg_prop_desc  =  'Keyup Search'
		Set @column    = 'KeyupSearch'	
	If @engg_prop_desc  =  'Stepper'
		Set @column    = 'Stepper'	
	If @engg_prop_desc  =  'Live Clock'
		Set @column    = 'LiveClock'
	If @engg_prop_desc  =  'Clear Task'
		Set @column    = 'ClearTask'	
	If @engg_prop_desc  =  'Show Animation'
		Set @column    = 'ShowAnimation'	
	If @engg_prop_desc  =  'Prevent Multiple Row Selection'
		Set @column    = 'PreventMultipleRowSelection'	
	
	--Code added for Defect Id Tech-73996 ends 

	If @engg_prop_desc  =  'Bulk Download'
		Set @column    = 'BulkDownload'		--code added by 11536 for the defect TECH-68067

	If @engg_prop_desc  =  'ShowLines'
		Set @column    = 'ShowLines'		--TECH-66989

--Code added for TECH-69624 starts

	If @engg_prop_desc  =  'Hide Rule Header'
		Set @column    = 'HideRuleHeader'	

	If @engg_prop_desc  =  'Hide AND Operator'
		Set @column    = 'HideANDOperator'	

	If @engg_prop_desc  =  'Hide OR Operator'
		Set @column    = 'HideOROperator'	

	If @engg_prop_desc  =  'Hide NOT Operator'
		Set @column    = 'HideNOTOperator'	

	If @engg_prop_desc  =  'Hide Group Operator'
		Set @column    = 'HideGroupOperator'	

	If @engg_prop_desc  =  'Hide Rule Operator'
		Set @column    = 'HideRuleOperator'	

	If @engg_prop_desc  =  'Is Toggle'
		Set @column    = 'IsToggle'	

	If @engg_prop_desc  =  'NFC Enabled'
		Set @column    = 'NFCEnabled'	

	If @engg_prop_desc  =  'Select Only List Values'
		Set @column    = 'SelectOnlyListValues'	
--Code added for TECH-69624 ends

	If @engg_prop_desc  =  'Spell Check Required'
		Set @column    = 'IsSpellCheck'
	If @engg_prop_desc  =  'Direct Print'
		Set @column    = 'DirectPrint'
	If @engg_prop_desc  =  'Selection Required for List' --code added by 13639
		Set @column    = 'IsSelectionReqdList'
	If @engg_prop_desc  =  'Row Always Expanded'
		Set @column    = 'RowAlwaysExpanded'			--code added by 13639
	If @engg_prop_desc  =  'Gantt Control'
		Set @column    = 'GanttControl'
 
	If @engg_prop_desc  =  'Auto Sync'
		Set @column    = 'AutoSync'

----code added by 13852 on 20jan2020

	If @engg_prop_desc  =  'Auto Scan'
		Set @column     = 'AutoScan'   --code added by 13639 

    If @engg_prop_desc  =  'Read Only'
		Set @column     = 'ReadOnly'

    If @engg_prop_desc  =  'Show Today Line'
		Set @column     = 'ShowTodayLine'

	 If @engg_prop_desc  =  'Show Rollup Tasks'
		Set @column      = 'ShowRollupTasks'

    If @engg_prop_desc  =  'Show Project Lines'
		Set @column     = 'ShowProjectLines'

    If @engg_prop_desc  =  'Skip Weekends During DragDrop'
		Set @column     = 'SkipWeekendsDuringDragDrop'

    If @engg_prop_desc  =  'Locked Grid Width'
		Set @column     = 'LockedGridWidth'

    If @engg_prop_desc  =  'Row Height'
		Set @column     = 'RowHeight'

    If @engg_prop_desc  =  'Bottom LabelField'
		Set @column     = 'BottomLabelField'

    If @engg_prop_desc  =  'Top LabelField'
		Set @column     = 'TopLabelField'

	If @engg_prop_desc  =  'Left LabelField'
		Set @column     =  'LeftLabelField'


	If @engg_prop_desc  =  'Right LabelField'
		Set @column     =  'RightLabelField'

	If @engg_prop_desc  =  'Rollup LabelField'
		Set @column     = 'RollupLabelField'

	 If @engg_prop_desc  =  'Scroll To DateCentered'
		Set @column      = 'ScrollToDateCentered'

	If @engg_prop_desc  =  'Zoom'
		Set @column     = 'Zoom'

	 If @engg_prop_desc  =  'Fit'
		Set @column      = 'Fit'

	 If @engg_prop_desc  =  'Export'
		Set @column      = 'Export'

	 If @engg_prop_desc  =  'Shift'
		Set @column      = 'GanttShift'

	 If @engg_prop_desc  =  'Expand'
		Set @column      = 'GanttExpand'

	 If @engg_prop_desc  =  'Insert'
		Set @column      = 'GanttInsert'

	 If @engg_prop_desc  =  'Delete'
		Set @column      = 'GanttDelete'

	If @engg_prop_desc  =  'Indent'
		Set @column     = 'Indent'

	 If @engg_prop_desc  =  'Calendar'
		Set @column      = 'Calendar'

	 If @engg_prop_desc  =  'Context Menu'
		Set @column      = 'ContextMenu'

	 If @engg_prop_desc  =  'Popup Task Editor'
		Set @column      = 'PopupTaskEditor'

	 If @engg_prop_desc  =  'Baseline'
		Set @column      = 'Baseline'

	 If @engg_prop_desc  =  'Highlight'
		Set @column      = 'Highlight'


    If @engg_prop_desc  =  'Click Event'
		Set @column    = 'ClickEvent'
	If @engg_prop_desc  =  'Collapse All Event'
		Set @column    = 'CollapseAllEvent'
	If @engg_prop_desc  =  'Collapse Event'
		Set @column    = 'CollapseEvent'
	If @engg_prop_desc  =  'Expand All Event'
		Set @column    = 'ExpandAllEvent'
	If @engg_prop_desc  =  'Expand Event'
		Set @column    = 'ExpandEvent'
	If @engg_prop_desc  =  'Drag Drop ToolTip'
		Set @column    = 'DDToolTip'
	If @engg_prop_desc  =  'Is Organization Chart'
		Set @column    = 'IsOrgChart'
	If @engg_prop_desc  =  'bufferred rows'
		Set @column    = 'bufferredrows'
	If @engg_prop_desc  =  'Node Icon Required'
		Set @column    = 'NodeIconReqd'
	If @engg_prop_desc  =  'Node Custom Class'
		Set @column    = 'NodeCustomClass'
	If @engg_prop_desc  =  'Preserve Horizontal Scroll Position'
		Set @column    = 'preserve_gridposition'
	If @engg_prop_desc  =  'Delayed Password Masking'
		Set @column    = 'Delayedpwdmask'
	If  @engg_prop_desc  = 'Edit Mask'  
		Set  @column   = 'Editmask'
	If  @engg_prop_desc  = 'Set focus event'  
		Set  @column   = 'Setfocusevent'

	If  @engg_prop_desc  = 'Leave focus event'  
		Set  @column   = 'Leavefocusevent'
	If  @engg_prop_desc  = 'Set Focus Event Occurence'  
		Set  @column   = 'SetFocusEventOccurence'
	If  @engg_prop_desc  = 'Leave Focus Event Occurence'  
		Set  @column   = 'LeaveFocusEventOccurence'

	If  @engg_prop_desc  = 'Badge Text'  
		Set  @column   = 'BadgeText'	--Code Added for the DefectId Tech-72114
	If  @engg_prop_desc  = 'Auto Height'  --Code Added for the DefectId Tech-72114
		Set  @column   = 'AutoHeight'--Code Added for the DefectId Tech-72114

	declare	@select varchar (8000)  
	declare @val	varchar(10)  

	CREATE TABLE #COL (COL1 VARCHAR(10))  
  
	Select @select = 'INSERT INTO #COL SELECT '  +@column+' from es_ctrl_type_met where  ctrl_type_name = '''+@engg_ctrlcmb_type+''' And base_ctrl_type = '''+@engg_basecmb_type+''''  
  
	EXEC (@select)  
  
	select	@EVENT = COL1 FROM #COL  
  
	If @EVENT= 'Y' and @required = 'N'   
	Begin  
		Raiserror ('Basic property of combo cannot be unchecked',16,1)  
		return  
	End  
  
	If @engg_ctrlcmb_type like 'vw%'  
	begin  
		If @engg_prop_desc = 'Handle Events'  
		If   exists (Select '*' 
		from	es_stat_ctrl_type_met (nolock)  
		where	ctrl_type_name  = @engg_ctrlcmb_type  
		and		base_ctrl_type	= @engg_basecmb_type)  
		Begin  
			update	a set
					a.handle_events = case  when @engg_prop_desc = 'Handle Events' and @engg_prop_req = 1 then  'Y'  
											when @engg_prop_desc = 'Handle Events' and @engg_prop_req = 0 then  'N'  
									  else a.handle_events 
									end   
			from	es_comp_stat_ctrl_type_mst a (nolock)  
			where	customer_name	= @engg_customer_name  
			and		project_name	= @engg_project_name  
			and		process_name	= @engg_process_name  
			and		component_name	= @engg_comp_name  
			and		ctrl_type_name	= @engg_ctrlcmb_type  
		End  
	End  
End

--Modeflag'U'  
--For Static Controls  
  
update	a set
		a.caption_req	= case	when @engg_prop_desc = 'Caption Required' and @engg_prop_req = 1  then 'Y'  
								when @engg_prop_desc = 'Caption Required' and @engg_prop_req = 0  then 'N'  
						else a.caption_req end,  
		a.caption_wrap	= case	when @engg_prop_desc = 'Caption Wrap' and @engg_prop_req = 1 then  'Y'  
								when @engg_prop_desc = 'Caption Wrap' and @engg_prop_req = 0 then  'N'  
						else a.caption_wrap end,  
		a.editable_flag = case  when @engg_prop_desc = 'Editable' and @engg_prop_req = 1 then  'Y'  
								when @engg_prop_desc = 'Editable' and @engg_prop_req = 0 then  'N'  
						  else a.editable_flag end,  
		a.ellipses_req  = case	when @engg_prop_desc = 'Ellipses Required' and @engg_prop_req = 1 then  'Y'  
								when @engg_prop_desc = 'Ellipses Required' and @engg_prop_req = 0 then  'N'  
								when @engg_basecmb_type = 'combo' then 'N'-- code modified by Ramanujam on 26-10-2005 for Case ID : Platform_2.0.3.1_43  
								when @engg_basecmb_type = 'link'  then 'N'-- code modified by Ramanujam on 26-10-2005 for Case ID : Platform_2.0.3.1_43  
								when @engg_basecmb_type = 'checkbox'  then 'N'-- code modified by Ramanujam on 26-10-2005 for Case ID : Platform_2.0.3.1_43  
						else a.ellipses_req end,  
		a.event_handling_req = case when @engg_prop_desc = 'Handle Events' and @engg_prop_req = 1 then  'Y'  
									when @engg_prop_desc = 'Handle Events' and @engg_prop_req = 0 then  'N'  
							else a.event_handling_req end,  
		a.help_req		= case	when @engg_prop_desc = 'Help Required' and @engg_prop_req = 1 then  'Y'  
								when @engg_prop_desc = 'Help Required' and @engg_prop_req = 0 then  'N'  
						  else a.help_req end,  
		a.mandatory_flag = case when @engg_prop_desc = 'Mandatory' and @engg_prop_req = 1 then  'Y'  
								when @engg_prop_desc = 'Mandatory' and @engg_prop_req = 0 then  'N'  
						   else a.mandatory_flag end,  
		a.password_char = case  when @engg_prop_desc = 'Password Char' and @engg_prop_req = 1 then  'Y'  
								when @engg_prop_desc = 'Password Char' and @engg_prop_req = 0 then  'N'  
						  else a.password_char end,  
		a.visisble_flag = case  when @engg_prop_desc = 'Visible' and @engg_prop_req = 1 then  'Y'  
								when @engg_prop_desc = 'Visible' and @engg_prop_req = 0 then  'N'  
						  else a.visisble_flag end,  
		a.zoom_req		= case	when @engg_prop_desc = 'Zoom' and @engg_prop_req = 1 then  'Y'  
								when @engg_prop_desc = 'Zoom' and @engg_prop_req = 0 then  'N'  
						  else a.zoom_req  end,  
		a.delete_req	= case  when @engg_prop_desc = 'Allow Deletion' and @engg_prop_req = 1 then  'Y'  
								when @engg_prop_desc = 'Allow Deletion' and @engg_prop_req = 0 then  'N'  
						  else a.delete_req end,  
		a.insert_req	= case  when @engg_prop_desc = 'Allow Insertion' and @engg_prop_req = 1 then  'Y'  
								when @engg_prop_desc = 'Allow Insertion' and @engg_prop_req = 0 then  'N'  
						  else a.insert_req end,  
		a.disponlycmb_req= case  when @engg_prop_desc = 'Display only Combo' and @engg_prop_req = 1 then  'Y' 
								 when @engg_prop_desc = 'Display only Combo' and @engg_prop_req = 0 then  'N'  
						  else a.disponlycmb_req end,  
		a.html_txt_area = case  when @engg_prop_desc = 'HTML Text area' and @engg_prop_req = 1 then  'Y'  
								when @engg_prop_desc = 'HTML Text area' and @engg_prop_req = 0 then  'N'  
						  else a.html_txt_area end,  
		a.report_req	= case	when @engg_prop_desc = 'Report Required' and @engg_prop_req = 1 then  'Y'  
								when @engg_prop_desc = 'Report Required' and @engg_prop_req = 0 then  'N'  
						  else a.report_req end,  
		a.select_flag	= case  when @engg_prop_desc = 'Select Flag' and @engg_prop_req = 1 then  'Y'  
								when @engg_prop_desc = 'Select Flag' and @engg_prop_req = 0 then  'N'  
						  else a.select_flag end,  
		a.auto_tab_stop = case  when @engg_prop_desc = 'Auto Tab Stop' and @engg_prop_req = 1 then 'Y'  
								when @engg_prop_desc = 'Auto Tab Stop' and @engg_prop_req = 0 then  'N'  
						  else a.auto_tab_stop end,-- added by Ramanujam on 7-dec-2005  
		a.spin_required = case  when @engg_prop_desc = 'Spin Required' and @engg_prop_req = 1 then  'Y'  
								when @engg_prop_desc = 'Spin Required' and @engg_prop_req = 0 then  'N'  
						  else a.spin_required end,-- added by Ramanujam on 01-mar-2006  
		a.Inplace_Calendar= case  when @engg_prop_desc = 'Inplace Calendar' and @engg_prop_req = 1 then  'Y'  
								  when @engg_prop_desc = 'Inplace Calendar' and @engg_prop_req = 0 then  'N'  
							else a.Inplace_Calendar end,  
--Code modification for PNR2.0_20849 starts  
  
		a.Vscrollbar_Req = case when @engg_prop_desc = 'Vertical Scrollbar Required' and @engg_prop_req = 1 then  'Y'  
								when @engg_prop_desc = 'Vertical Scrollbar Required' and @engg_prop_req = 0 then  'N'  
						   else a.Vscrollbar_Req end,  
--Code modification for PNR2.0_20849 ends  
--   a.EditMask_req = case  when @engg_prop_desc = 'EditMask required' and @engg_prop_req = 1 then  'Y'  
-- when @engg_prop_desc = 'EditMask required' and @engg_prop_req = 0 then  'N'  
--       else a.EditMask_req end,  
		a.Is_Extjs_Control= case   when @engg_prop_desc = 'Rich Control' and @engg_prop_req = 1 then  'Y'  
									when @engg_prop_desc = 'Rich Control' and @engg_prop_req = 0 then  'N'  
							 else a.Is_Extjs_Control end, -- Added BY Feroz For Extnjs -- PNR2.0_1790  
-- Code modification for PNR2.0_21576 starts  
		a.gridlite_req = case when @engg_prop_desc = 'GridLite Required' and @engg_prop_req = 1 then  'Y'  
							  when @engg_prop_desc = 'GridLite Required' and @engg_prop_req = 0 then  'N'  
						 else a.gridlite_req end,  
-- Code modification for PNR2.0_21576 ends  
-- Added By Feroz  
		a.buttoncombo_req = case when @engg_prop_desc = 'Button Combo' and @engg_prop_req = 1 then  'Y'  
								 when @engg_prop_desc = 'Button Combo' and @engg_prop_req = 0 then  'N'  
							else a.buttoncombo_req end,  
		a.dataascaption	  = case when @engg_prop_desc = 'Data As Caption' and @engg_prop_req = 1 then  'Y'  
								 when @engg_prop_desc = 'Data As Caption' and @engg_prop_req = 0 then  'N'  
							else a.dataascaption end,  
		a.associatedlist_req = case when @engg_prop_desc = 'Associated List' and @engg_prop_req = 1 then  'Y'  
									when @engg_prop_desc = 'Associated List' and @engg_prop_req = 0 then  'N'  
								else a.associatedlist_req end,  
		a.onfocustask_req = case when @engg_prop_desc = 'Onfocus Task' and @engg_prop_req = 1 then  'Y'  
								 when @engg_prop_desc = 'Onfocus Task' and @engg_prop_req = 0 then  'N'  
								else a.onfocustask_req end,  
		a.listrefilltask_req = case when @engg_prop_desc = 'List Refill Task' and @engg_prop_req = 1 then  'Y'  
									when @engg_prop_desc = 'List Refill Task' and @engg_prop_req = 0 then  'N'  
							   else a.listrefilltask_req end,  
		a.bulletlink_req = case when @engg_prop_desc = 'Bullet Link' and @engg_prop_req = 1 then  'Y'  
								when @engg_prop_desc = 'Bullet Link' and @engg_prop_req = 0 then  'N'  
						   else a.bulletlink_req end,  
		a.attach_document = case when @engg_prop_desc = 'Attach Document' and @engg_prop_req = 1 then  'Y'  
								 when @engg_prop_desc = 'Attach Document' and @engg_prop_req = 0 then  'N'  
							else a.attach_document end,  
		a.image_upload  = case when @engg_prop_desc = 'Image Upload' and @engg_prop_req = 1 then  'Y'  
							   when @engg_prop_desc = 'Image Upload' and @engg_prop_req = 0 then  'N'  
						  else a.image_upload end,  
		a.inplace_image = case	when @engg_prop_desc = 'Inplace Image' and @engg_prop_req = 1 then  'Y'  
								when @engg_prop_desc = 'Inplace Image' and @engg_prop_req = 0 then  'N'  
						  else a.inplace_image end,  
		a.image_icon	= case	when @engg_prop_desc = 'Image Icon' and @engg_prop_req = 1 then  'Y'  
								when @engg_prop_desc = 'Image Icon' and @engg_prop_req = 0 then  'N'  
						  else a.image_icon end,  
		a.save_doc_content_to_db = case when @engg_prop_desc = 'Save Document Content to DB' and @engg_prop_req = 1 then  'Y'  
										when @engg_prop_desc = 'Save Document Content to DB' and @engg_prop_req = 0 then  'N'  
								   else a.save_doc_content_to_db end,  
		a.save_image_content_to_db = case	when @engg_prop_desc = 'Save Image Content to DB' and @engg_prop_req = 1 then  'Y'  
											when @engg_prop_desc = 'Save Image Content to DB' and @engg_prop_req = 0 then  'N'  
									 else a.save_image_content_to_db end,  
		a.Date_highlight	= case	when @engg_prop_desc = 'Date Highlight' and @engg_prop_req = 1 then  'Y'  
									when @engg_prop_desc = 'Date Highlight' and @engg_prop_req = 0 then  'N'  
							  else a.Date_highlight end,  
-- Added By Feroz  
		a.ezee_report		= case	when @engg_prop_desc = 'Ezee Report' and @engg_prop_req = 1 then  'Y'  
									when @engg_prop_desc = 'Ezee Report' and @engg_prop_req = 0 then  'N'  
							  else a.ezee_report end,  
-- Code Added by Jeya for bug id :PNR2.0_27796 Starts  
		a.Lite_Attach_Document = case	when @engg_prop_desc = 'Lite Attach Document' and @engg_prop_req = 1 then  'Y'  
										when @engg_prop_desc = 'Lite Attach Document' and @engg_prop_req = 0 then  'N'  
								 else a.Lite_Attach_Document end,  
		a.Browse_Button_Enable = case	when @engg_prop_desc = 'Browse Button' and @engg_prop_req = 1 then  'Y'  
										when @engg_prop_desc = 'Browse Button' and @engg_prop_req = 0 then  'N'  
								 else a.Browse_Button_Enable end,  
		a.Delete_Button_Enable = case	when @engg_prop_desc = 'Delete Button' and @engg_prop_req = 1 then  'Y'  
										when @engg_prop_desc = 'Delete Button' and @engg_prop_req = 0 then  'N'  
								 else a.Delete_Button_Enable end,  
-- Code Added by Jeya for bug id :PNR2.0_27796 End  
--code added for the caseid : PNR2.0_28319 starts  
		a.Image_Preview_Req = case	when @engg_prop_desc = 'Image Preview Required' and @engg_prop_req = 1 then  'Y'  
									when @engg_prop_desc = 'Image Preview Required' and @engg_prop_req = 0 then  'N'  
							  else a.Image_Preview_Req end,  
		a.Lite_Attach_Image = case	when @engg_prop_desc = 'Lite Attach Image' and @engg_prop_req = 1 then  'Y'  
									when @engg_prop_desc = 'Lite Attach Image' and @engg_prop_req = 0 then  'N'  
							  else a.Lite_Attach_Image end,  
--code added for the caseid : PNR2.0_28319 ends  
--Code Modification for PNR2.0_30869 starts
		a.timezone			= case	when @engg_prop_desc = 'TimeZone' and @engg_prop_req = 1 then  'Y'  
									when @engg_prop_desc = 'TimeZone' and @engg_prop_req = 0 then  'N'  
							  else a.timezone end,  
--Code Modification for PNR2.0_30869 ends
-- Code Added for the Bug ID PNR2.0_32053 Starts
		a.autoexpand		= case	when @engg_prop_desc = 'Auto Expand' and @engg_prop_req = 1 then  'Y'  
									when @engg_prop_desc = 'Auto Expand' and @engg_prop_req = 0 then  'N'  -- Code Modified for the Bug ID PNR2.0_32224
							  else a.autoexpand end,  
		a.AttachmentWithDesc = case when @engg_prop_desc = 'Attachment with Description' and @engg_prop_req = 1 then  'Y'  
									when @engg_prop_desc = 'Attachment with Description' and @engg_prop_req = 0 then  'N'  -- Code Modified for the Bug ID PNR2.0_32224
							   else a.AttachmentWithDesc end,  
-- Code Added for the Bug ID PNR2.0_32053 End
-- Code Added for the Bug ID PNR2.0_32770 Starts
		a.Disp_Only_Apply_Len = case when @engg_prop_desc = 'Apply Visible Length' and @engg_prop_req = 1 then  'Y'  
									 when @engg_prop_desc = 'Apply Visible Length' and @engg_prop_req = 0 then  'N'  -- Code Modified for the Bug ID PNR2.0_32224
								else a.Disp_Only_Apply_Len end,  
-- Code Added for the Bug ID PNR2.0_32770 End
/*Modification made by Muthupandi S for Bug id : PNR2.0_33487 Starts*/
		a.editcombo_req = case	when @engg_prop_desc = 'Edit combo Required' and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc = 'Edit combo Required' and @engg_prop_req = 0 then  'N'  -- Code Modified for the Bug ID PNR2.0_32224
						  else a.editcombo_req end,
/*Modification made by Muthupandi S for Bug id : PNR2.0_33487 Ends*/
-- Code Added for the Bug ID PNR2.0_36309 Starts
		a.Label_Link = case when @engg_prop_desc = 'Label Link' and @engg_prop_req = 1 then  'Y'  
							when @engg_prop_desc = 'Label Link' and @engg_prop_req = 0 then  'N' 
					   else a.Label_Link end,  
-- Code Added for the Bug ID PNR2.0_36309 End
--PLF2.0_03057 starts
		a.IsListBox = case	when @engg_prop_desc = 'IsListBox' and @engg_prop_req = 1 then  'Y'
							when @engg_prop_desc = 'IsListBox' and @engg_prop_req = 0 then  'N'
					  else a.IsListBox end,
		a.combo_link = case when @engg_prop_desc = 'Combo Link' and @engg_prop_req = 1 then  'Y' --shakthi
							when @engg_prop_desc = 'Combo Link' and @engg_prop_req = 0 then  'N'
					   else a.combo_link end,
		a.QR_Image	 = case	when @engg_prop_desc = 'QR Image' and @engg_prop_req = 1 then  'Y' --shakthi
							when @engg_prop_desc = 'QR Image' and @engg_prop_req = 0 then  'N'
					   else a.QR_Image end,
--code added for bugid: PLF2.0_07676 starts
		a.Toolbar_Not_Req = case	when @engg_prop_desc = 'Toolbar Not Required' and @engg_prop_req = 1 then  'Y' 
									when @engg_prop_desc = 'Toolbar Not Required' and @engg_prop_req = 0 then  'N'
							else a.Toolbar_Not_Req end,
		a.ColumnBorder_Not_Req = case	when @engg_prop_desc = 'Column Border Not Required' and @engg_prop_req = 1 then  'Y' 
										when @engg_prop_desc = 'Column Border Not Required' and @engg_prop_req = 0 then  'N'
								 else a.ColumnBorder_Not_Req end,
		a.RowBorder_Not_Req = case	when @engg_prop_desc = 'Row Border Not Required' and @engg_prop_req = 1 then  'Y' 
									when @engg_prop_desc = 'Row Border Not Required' and @engg_prop_req = 0 then  'N'
							  else a.RowBorder_Not_Req end,
		a.PagenavigationOnly = case when @engg_prop_desc = 'Only page navigation Required' and @engg_prop_req = 1 then  'Y' 
									when @engg_prop_desc = 'Only page navigation Required' and @engg_prop_req = 0 then  'N'
							   else a.PagenavigationOnly end,
--code added for bugid: PLF2.0_07676 ends
		a.RowNO_Not_Req = case	when @engg_prop_desc = 'Row No. Not Required' and @engg_prop_req = 1 then  'Y' 
								when @engg_prop_desc = 'Row No. Not Required' and @engg_prop_req = 0 then  'N'
						  else a.RowNO_Not_Req end,
		a.ButtonHome_Req = case when @engg_prop_desc = 'Home Button' and @engg_prop_req = 1 then  'Y' 
								when @engg_prop_desc = 'Home Button' and @engg_prop_req = 0 then  'N'
						   else a.ButtonHome_Req end,
		a.ButtonPrevious_Req = case when @engg_prop_desc = 'Previous Button' and @engg_prop_req = 1 then  'Y' 
									when @engg_prop_desc = 'Previous Button' and @engg_prop_req = 0 then  'N'
							   else a.ButtonPrevious_Req end, --PLF2.0_07805
--PLF2.0_03057 ends
		a.Tooltip_Not_Req = case	when @engg_prop_desc = 'ToolTip Not Required' and @engg_prop_req = 1 then  'Y' 
									when @engg_prop_desc = 'ToolTip Not Required' and @engg_prop_req = 0 then  'N'
							else a.Tooltip_Not_Req end,
		a.Forcefit		  = case	when @engg_prop_desc = 'Fixed Column Width' and @engg_prop_req = 1 then  'Y' 
									when @engg_prop_desc = 'Fixed Column Width' and @engg_prop_req = 0 then  'N'
							else a.Forcefit end,
		a.columncaption_Not_Req = case  when @engg_prop_desc = 'Grid Header Not Required' and @engg_prop_req = 1 then  'Y' 
										when @engg_prop_desc = 'Grid Header Not Required' and @engg_prop_req = 0 then  'N'
								  else a.columncaption_Not_Req end,
		a.Border_Not_Req = case when @engg_prop_desc = 'Border Not Required' and @engg_prop_req = 1 then  'Y' 
								when @engg_prop_desc = 'Border Not Required' and @engg_prop_req = 0 then  'N'
						   else a.Border_Not_Req end,
		a.IsModal		 = case	when @engg_prop_desc = 'Is Modal' and @engg_prop_req = 1 then  'Y' 
								when @engg_prop_desc = 'Is Modal' and @engg_prop_req = 0 then  'N'
						   else a.IsModal end,
		a.Alternate_Color_Req = case	when @engg_prop_desc = 'Alternate Row Color Not Required' and @engg_prop_req = 1 then  'Y' 
										when @engg_prop_desc = 'Alternate Row Color Not Required' and @engg_prop_req = 0 then  'N'
								else a.Alternate_Color_Req end,
		a.Map_In_Req = case when @engg_prop_desc = 'Map In required' and @engg_prop_req = 1 then  'Y' 
							when @engg_prop_desc = 'Map In required' and @engg_prop_req = 0 then  'N'
					   else a.Map_In_Req end,
		a.Map_Out_Req = case when @engg_prop_desc = 'Map Out Required' and @engg_prop_req = 1 then  'Y' 
							 when @engg_prop_desc = 'Map Out Required' and @engg_prop_req = 0 then  'N'
						else a.Map_Out_Req end,
		a.Barcode_Image = case	when @engg_prop_desc = 'Barcode Image' and @engg_prop_req = 1 then  'Y' --shakthi
								when @engg_prop_desc = 'Barcode Image' and @engg_prop_req = 0 then  'N'
						  else a.Barcode_Image end,
		a.Isfallback = case when @engg_prop_desc = 'Is Fallback' and @engg_prop_req = 1 then  'Y' --Kanagavel
							when @engg_prop_desc = 'Is Fallback' and @engg_prop_req = 0 then  'N'
					   else a.Isfallback end,
		a.config_parameter = case when @engg_prop_desc = 'Configuration Parameter' and @engg_prop_req = 1 then  'Y' --Kanagavel
								 when @engg_prop_desc  = 'Configuration Parameter' and @engg_prop_req = 0 then  'N'
							 else a.config_parameter end,
		a.config_value = case when @engg_prop_desc = 'Is Data' and @engg_prop_req = 1 then  'Y' --Kanagavel
							  when @engg_prop_desc = 'Is Data' and @engg_prop_req = 0 then  'N'
						 else a.config_value end,
		a.upload	   = case	when @engg_prop_desc = 'Upload' and @engg_prop_req = 1 then  'Y' --Piranava
								when @engg_prop_desc = 'Upload' and @engg_prop_req = 0 then  'N'
						 else a.upload end,
		a.Is_Varbinary = case	when @engg_prop_desc = 'Is Varbinary' and @engg_prop_req = 1 then  'Y' 
								when @engg_prop_desc = 'Is Varbinary' and @engg_prop_req = 0 then  'N'
						 else a.Is_Varbinary end,

		a.EMail		  = case when @engg_prop_desc = 'EMail' and @engg_prop_req = 1 then  'Y'
							  when @engg_prop_desc = 'EMail' and @engg_prop_req = 0 then  'N'
						else a.EMail end,
		a.Phone		   = case	when @engg_prop_desc = 'Phone' and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc = 'Phone' and @engg_prop_req = 0 then  'N'
						 else a.Phone end,
		a.StaticCaption = case	when @engg_prop_desc = 'Static Caption' and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc = 'Static Caption' and @engg_prop_req = 0 then  'N'
						  else a.StaticCaption end,
		a.DataGrid		= case	when @engg_prop_desc = 'Data Grid' and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc = 'Data Grid' and @engg_prop_req = 0 then  'N'
						  else a.DataGrid end,
		a.Move_PrevSet = case	when @engg_prop_desc = 'Move PreviousSet' and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc = 'Move PreviousSet' and @engg_prop_req = 0 then  'N'
						 else a.Move_PrevSet end,
		a.MoveFirst	   = case	when @engg_prop_desc = 'Move First' and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc = 'Move First' and @engg_prop_req = 0 then  'N'
						 else a.MoveFirst end,
		a.Move_Previous = case	when @engg_prop_desc = 'Move Previous' and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc = 'Move Previous' and @engg_prop_req = 0 then  'N'
						  else a.Move_Previous end,
		a.Move_Next     = case	when @engg_prop_desc = 'Move Next' and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc = 'Move Next' and @engg_prop_req = 0 then  'N'
						  else a.Move_Next end,
		a.Move_NextSet  = case	when @engg_prop_desc = 'Move NextSet' and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc = 'Move NextSet' and @engg_prop_req = 0 then  'N'
						  else a.Move_NextSet end,
		a.Move_Last		= case	when @engg_prop_desc = 'Move Last' and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc = 'Move Last' and @engg_prop_req = 0 then  'N'
						  else a.Move_Last end,
		a.Carousel_Req  = case	when @engg_prop_desc = 'Carousel Required' and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc = 'Carousel Required' and @engg_prop_req = 0 then  'N'
						  else a.Carousel_Req end,
		a.ISDeviceInfo  = case	when @engg_prop_desc = 'ISDeviceInfo' and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc = 'ISDeviceInfo' and @engg_prop_req = 0 then  'N'
						  else a.ISDeviceInfo end,
		a.ListControl	= case	when @engg_prop_desc = 'List Control' and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc = 'List Control' and @engg_prop_req = 0 then  'N'
						  else a.ListControl end,
		a.preevent		= case	when @engg_prop_desc = 'Pre Event' and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc = 'Pre Event' and @engg_prop_req = 0 then  'N'
						  else a.preevent end,
		a.postevent		= case	when @engg_prop_desc = 'Post Event' and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc = 'Post Event' and @engg_prop_req = 0 then  'N'
						  else a.postevent end,
		a.PreventDownload= case	when @engg_prop_desc = 'Prevent Download' and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc = 'Prevent Download' and @engg_prop_req = 0 then  'N'
						   else a.PreventDownload end,
		a.avn_download   = case when @engg_prop_desc = 'Aviation Download' and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc = 'Aviation Download' and @engg_prop_req = 0 then  'N'
						   else a.avn_download end,
		a.ishijri		 = case when @engg_prop_desc = 'Is Hijri' and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc = 'Is Hijri' and @engg_prop_req = 0 then  'N'
						   else a.ishijri end,
		a.enabledefault  = case when @engg_prop_desc ='Enable Default'   and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc = 'Enable Default'   and @engg_prop_req = 0 then  'N'
						   else a.enabledefault end,
		a.hideinsert	 = case when @engg_prop_desc ='Hide Insert'  and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc = 'Hide Insert' and @engg_prop_req = 0 then  'N'
						   else a.hideinsert end,
		a.hidedelete	 = case when @engg_prop_desc = 'Hide Delete' and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc = 'Hide Delete' and @engg_prop_req = 0 then  'N'
					       else a.hidedelete end,
		a.hidecopy		 = case	when @engg_prop_desc =  'Hide Copy and Append Row' and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc =  'Hide Copy and Append Row' and @engg_prop_req = 0 then  'N'
						   else a.hidecopy end,
		a.hidecut		 = case when @engg_prop_desc ='Hide Cut and Append Row'   and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc = 'Hide Cut and Append Row'  and @engg_prop_req = 0 then  'N'
						   else a.hidecut end,
		a.hidefilterdata = case when @engg_prop_desc ='Hide Filter Data'   and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc = 'Hide Filter Data'  and @engg_prop_req = 0 then  'N'
						   else a.hidefilterdata end,
		a.hidepdf		 = case when @engg_prop_desc ='Hide Export to PDF'   and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc = 'Hide Export to PDF' and @engg_prop_req = 0 then  'N'
						   else a.hidepdf end,
		a.hidereport	= case  when @engg_prop_desc ='Hide Export to Report'   and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc = 'Hide Export to Report'  and @engg_prop_req = 0 then  'N'
						  else a.hidereport end,
		a.hidehtml		= case  when @engg_prop_desc ='Hide Export to HTML'  and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc = 'Hide Export to HTML'  and @engg_prop_req = 0 then  'N'
						  else a.hidehtml end,
		a.hideexportexcel= case when @engg_prop_desc ='Hide Export to Excel'  and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc = 'Hide Export to Excel'  and @engg_prop_req = 0 then  'N'
						   else a.hideexportexcel end,
		a.hideexportcsv  = case	when @engg_prop_desc ='Hide Export to CSV'   and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc = 'Hide Export to CSV' and @engg_prop_req = 0 then  'N'
						   else a.hideexportcsv end,
		a.hideexporttext = case when @engg_prop_desc ='Hide Export to Text'   and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc = 'Hide Export to Text' and @engg_prop_req = 0 then  'N'
						   else a.hideexporttext end,
		a.hideimportdata = case when @engg_prop_desc ='Hide Import Data'   and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc = 'Hide Import Data'and @engg_prop_req = 0 then  'N'
						   else a.hideimportdata end,
		a.hidechart		 = case	when @engg_prop_desc ='Hide Chart'  and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc = 'Hide Chart'  and @engg_prop_req = 0 then  'N'
							else a.hidechart end,
		a.hideexportopenoffice = case	when @engg_prop_desc ='Hide Export to Open Office'  and @engg_prop_req = 1 then  'Y'
										when @engg_prop_desc = 'Hide Export to Open Office'and @engg_prop_req = 0 then  'N'
								 else a.hideexportopenoffice end,
		a.hidepersonalize = case when @engg_prop_desc ='Hide Personalization'   and @engg_prop_req = 1 then  'Y'
								 when @engg_prop_desc = 'Hide Personalization' and @engg_prop_req = 0 then  'N'
							else a.hidepersonalize end,
		a.hidefiltercolumn= case	when @engg_prop_desc ='Hide Column Chooser'    and @engg_prop_req = 1 then  'Y'
									when @engg_prop_desc = 'Hide Column Chooser' and @engg_prop_req = 0 then  'N'
							else a.hidefiltercolumn end,
		a.spin_system_task= case when @engg_prop_desc ='Spin-System Task'     and @engg_prop_req = 1 then  'Y'
								 when @engg_prop_desc ='Spin-System Task' and @engg_prop_req = 0 then  'N'
							else a.spin_system_task end,
		a.searchhide = case when @engg_prop_desc ='Grid Data Search Not Required'   and @engg_prop_req = 1 then  'Y'
							when @engg_prop_desc ='Grid Data Search Not Required' and @engg_prop_req = 0 then  'N'
							else a.searchhide end,
		a.autolist_not_req = case	when @engg_prop_desc ='Auto List Without Filter Not Required'     and @engg_prop_req = 1 then  'Y'
									when @engg_prop_desc ='Auto List Without Filter Not Required'and @engg_prop_req = 0 then  'N'
							  else a.autolist_not_req end,
		a.hideselect = case when @engg_prop_desc ='Hide Select'   and @engg_prop_req = 1 then  'Y'
							when @engg_prop_desc ='Hide Select' and @engg_prop_req = 0 then  'N'
					   else a.hideselect end,
		a.norowstodisplay_notreq = case when @engg_prop_desc ='No Rows to Display Not Required'   and @engg_prop_req = 1 then  'Y'
										when @engg_prop_desc ='No Rows to Display Not Required' and @engg_prop_req = 0 then  'N'
								   else a.norowstodisplay_notreq end,
		a.AutoHeight	= case	when @engg_prop_desc ='AutoHeight'   and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc ='AutoHeight' and @engg_prop_req = 0 then  'N'
						  else a.AutoHeight end,
--Changes for PLF2.0_16291
--a.IsPivot = case when @engg_prop_desc ='Is Pivot'   and @engg_prop_req = 1 then  'Y'
--when @engg_prop_desc ='Is Pivot' and @engg_prop_req = 0 then  'N'
--else a.IsPivot end,
		a.QlikLink		= case	when @engg_prop_desc ='QlikLink'   and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc ='QlikLink' and @engg_prop_req = 0 then  'N'
						  else a.QlikLink end,
		a.IsMarquee		= case	when @engg_prop_desc ='Is Marquee'   and @engg_prop_req = 1 then  'Y'
								when @engg_prop_desc ='Is Marquee' and @engg_prop_req = 0 then  'N'
						  else a.IsMarquee end,
--a.IsAssorted = case when @engg_prop_desc ='Is Assorted'   and @engg_prop_req = 1 then  'Y'
--when @engg_prop_desc ='Is Assorted' and @engg_prop_req = 0 then  'N'
--else a.IsAssorted	end,
		a.SystemGeneratedFileId = case	when @engg_prop_desc ='System Generated File Id'   and @engg_prop_req = 1 then  'Y'
										when @engg_prop_desc ='System Generated File Id' and @engg_prop_req = 0 then  'N'
								  else a.SystemGeneratedFileId	end,
		a.EditMask = case  when @engg_prop_desc = 'Edit Mask' and @engg_prop_req = 1 then  'Y'  
								when @engg_prop_desc = 'Edit Mask' and @engg_prop_req = 0 then  'N'  
								  else a.EditMask	end,
--a.preserve_gridposition = case when @engg_prop_desc ='Preserve Horizontal Scroll Position'   and @engg_prop_req = 1 then  'Y'
--when @engg_prop_desc ='Preserve Horizontal Scroll Position' and @engg_prop_req = 0 then  'N'
--else a.preserve_gridposition end,
a.RenderAs = case 
	--	when @engg_prop_desc ='Is Chips'			and @engg_prop_req = 1	then  'Chips'
		when @engg_prop_desc ='Is Tag'				and @engg_prop_req = 1	then  'Tag'
		when @engg_prop_desc ='Grid to Form'		and @engg_prop_req = 1	then  'GridtoForm'
		when @engg_prop_desc ='Multi-Selector Grid' and @engg_prop_req = 1	then  'MultiSelectorGrid'
			  
 	    when @engg_prop_desc ='Is Mobile'		and @engg_prop_req = 1		then  'MobileGrid'				---code added by 13639
		
		when @engg_prop_desc ='Row Expander'		and @engg_prop_req = 1	then  'RowExpander'
		when @engg_prop_desc ='Is Organization Chart'and @engg_prop_req = 1 then  'OrganizationChart'
		when @engg_prop_desc ='Rule Builder'	     and @engg_prop_req = 1	then  'RB_MetaData'		--Added for TECH-35368
		when @engg_prop_desc ='Calendar Control'	 and @engg_prop_req = 1	then  'Calendar_event'	--Added for TECH-35368
		when @engg_prop_desc ='Gantt Control'		 and @engg_prop_req = 1	then  'Gantt'	-- Added for TECH-37471
		
		when @engg_basecmb_type in ('Pivot', 'Assorted', 'Slider')		then @engg_basecmb_type -- 'TreeGrid', 
		else a.RenderAs end	,		
a.ctrl_type_descr	= @engg_modctr_desc,  
a.ctrl_type_doc		= @engg_modctr_docu,  
a.base_ctrl_type	= @engg_basecmb_type,  a.modifiedby =@ctxt_user ,a.modifieddate =getdate() 
from	es_comp_ctrl_type_mst a (nolock) 
where	a.customer_name		= @engg_customer_name  
and		a.project_name		= @engg_project_name  
and		a.process_name		= @engg_process_name  
and		a.component_name	= @engg_comp_name  
and		a.ctrl_type_name	= @engg_ctrlcmb_type  

--For removing renderas property 

--select @engg_prop_desc 'test',
--	   @engg_prop_req  'test1'

-- Code added for Defect id : TECH-19347 starts
if not exists (select 'x'
from	es_comp_ctrl_type_mst_extn (nolock)
where	customer_name		= @engg_customer_name  
and		project_name		= @engg_project_name
and		process_name		= @engg_process_name 
and		component_name		= @engg_comp_name
and		ctrl_type_name		= @engg_ctrlcmb_type)
--and     base_ctrl_type		= @engg_basecmb_type) -- 10th Oct
begin
	Insert into es_comp_ctrl_type_mst_extn
		(customer_name,			project_name,			req_no,				process_name,		component_name,			ctrl_type_name,			
		ctrl_type_descr,		base_ctrl_type,			timestamp,			createdby,			createddate,			modifiedby,
		modifieddate)
	Select 
		@engg_customer_name,	@engg_project_name,		'base',				@engg_process_name,	@engg_comp_name,		@engg_ctrlcmb_type,		
		@engg_modctr_desc,	    @engg_basecmb_type,		1,					@ctxt_user,			getdate(),				@ctxt_user,
		getdate()
end
--Code added for Defect id : TECH-19347 ends



update	b  set
		b.ClickEvent		= case	when @engg_prop_desc ='Click Event'		and @engg_prop_req = 1 then  'Y'
									when @engg_prop_desc ='Click Event'		and @engg_prop_req = 0 then  'N'
							  else b.ClickEvent end,
		b.ExpandEvent		= case	when @engg_prop_desc ='Expand Event'	and @engg_prop_req = 1 then  'Y'
									when @engg_prop_desc ='Expand Event'	and @engg_prop_req = 0 then  'N'
							  else b.ExpandEvent end,
		b.ExpandAllEvent	= case	when @engg_prop_desc ='Expand All Event'	and @engg_prop_req = 1 then  'Y'
									when @engg_prop_desc ='Expand All Event'	and @engg_prop_req = 0 then  'N'
							  else b.ExpandAllEvent end,
		b.CollapseEvent		= case	when @engg_prop_desc ='Collapse Event'		and @engg_prop_req = 1 then  'Y'
									when @engg_prop_desc ='Collapse Event'		and @engg_prop_req = 0 then  'N'
							  else b.CollapseEvent end,
		b.CollapseAllEvent  = case	when @engg_prop_desc ='Collapse All Event'		and @engg_prop_req = 1 then  'Y'
									when @engg_prop_desc ='Collapse All Event'		and @engg_prop_req = 0 then  'N'
							  else b.CollapseAllEvent end,
		b.DDToolTip			= case  when @engg_prop_desc ='Drag Drop ToolTip'   and @engg_prop_req = 1 then  'Y'
								    when @engg_prop_desc ='Drag Drop ToolTip'			 and @engg_prop_req = 0 then  'N'
							  else b.DDToolTip end,
		b.IsOrgChart		= case  when @engg_prop_desc ='Is Organization Chart'   and @engg_prop_req = 1 then  'Y'
									when @engg_prop_desc ='Is Organization Chart' and @engg_prop_req = 0 then  'N'
							  else b.IsOrgChart end,
		b.bufferedrows		= case	when @engg_prop_desc ='buffered rows'   and @engg_prop_req = 1 then  'Y'
									when @engg_prop_desc ='buffered rows' and @engg_prop_req = 0 then  'N'
							  else b.bufferedrows end,
		b.NodeIconReqd		= case	when @engg_prop_desc ='Node Icon Required'   and @engg_prop_req = 1 then  'Y'
									when @engg_prop_desc ='Node Icon Required' and @engg_prop_req = 0 then  'N'
							  else b.NodeIconReqd end,
		b.NodeCustomClass	= case	when @engg_prop_desc ='Node Custom Class'   and @engg_prop_req = 1 then  'Y'
									when @engg_prop_desc ='Node Custom Class' and @engg_prop_req = 0 then  'N'
							  else b.NodeCustomClass end,
		-- Code added for Defect ID : TECH-18349 starts
		b.Delayedpwdmask		= case  when @engg_prop_desc = 'Delayed Password Masking' and @engg_prop_req = 1 then  'Y'  
										when @engg_prop_desc = 'Delayed Password Masking' and @engg_prop_req = 0 then  'N'  
								  else b.Delayedpwdmask end, 
		b.preserve_gridposition = case when @engg_prop_desc ='Preserve Horizontal Scroll Position'   and @engg_prop_req = 1 then  'Y'
									   when @engg_prop_desc ='Preserve Horizontal Scroll Position'	 and @engg_prop_req = 0 then  'N'
								  else b.preserve_gridposition end,
		b.Dynamicfileupload		= case  when @engg_prop_desc = 'Dynamic File Upload Path' and @engg_prop_req = 1 then  'Y'  
										when @engg_prop_desc = 'Dynamic File Upload Path' and @engg_prop_req = 0 then  'N'  
								  else b.Dynamicfileupload end,
		b.ServerSidePrint		= case  when @engg_prop_desc = 'Server Side Print' and @engg_prop_req = 1 then  'Y'  
										when @engg_prop_desc = 'Server Side Print' and @engg_prop_req = 0 then  'N'  
								  else b.ServerSidePrint end, 
		b.MultiFileSelect		= case  when @engg_prop_desc = 'Multi File Select' and @engg_prop_req = 1 then  'Y'  
										when @engg_prop_desc = 'Multi File Select' and @engg_prop_req = 0 then  'N'  
								  else b.MultiFileSelect end,
		-- Code added for Defect ID : TECH-18349 ends
	-- code added for Defect Id: TECH-19347 starts
		b.metadatabasedLink		= case  when @engg_prop_desc = 'Meta Data based Link' and @engg_prop_req = 1 then  'Y'  
										when @engg_prop_desc = 'Meta Data based Link' and @engg_prop_req = 0 then  'N'  
								  else b.metadatabasedlink end,
	--code added for Defect Id: TECH-19347 ends		
		-- Code added for Defect id: TECH-20326 starts
		b.scan					= case  when @engg_prop_desc = 'Scan' and @engg_prop_req = 1 then  'Y'  
										when @engg_prop_desc = 'Scan' and @engg_prop_req = 0 then  'N'  
								  else b.Scan end,
		b.Autoselect			= case  when @engg_prop_desc = 'Auto Select' and @engg_prop_req = 1 then  'Y'  
										when @engg_prop_desc = 'Auto Select' and @engg_prop_req = 0 then  'N'  
								  else b.Autoselect end,
	-- Added for Rule Builder Starts Defect ID: TECH-35368
		b.RuleBuilder		= case  when @engg_prop_desc = 'Rule Builder' and @engg_prop_req = 1 then  'Y'  
								when @engg_prop_desc = 'Rule Builder' and @engg_prop_req = 0 then  'N'  
							else b.RuleBuilder end,
        
		b.MultiSelectComboforRB		= case  when @engg_prop_desc = 'MultiSelect Combo for Rule Builder' and @engg_prop_req = 1 then  'Y'  
								when @engg_prop_desc = 'MultiSelect Combo for Rule Builder' and @engg_prop_req = 0 then  'N'  
							else b.MultiSelectComboforRB end,
		b.CalendarControl		= case  when @engg_prop_desc = 'Calendar Control' and @engg_prop_req = 1 then  'Y'  
								when @engg_prop_desc = 'Calendar Control' and @engg_prop_req = 0 then  'N'  
							else b.CalendarControl end,
	-- Added for Rule Builder Ends Defect ID: TECH-35368
	-- Added for the Defect ID: TECH-37471 Starts for Set & LEave Focus Events
		b.Setfocusevent  =  case when @engg_prop_desc = 'Set Focus Event' and @engg_prop_req =1 then 'Y'
								 when @engg_prop_desc = 'Set Focus Event' and @engg_prop_req =0 then 'N'
								else b.Setfocusevent end,

		b.Leavefocusevent =  case when @engg_prop_desc = 'Leave Focus Event' and @engg_prop_req =1 then 'Y'
								  when @engg_prop_desc = 'Leave Focus Event' and @engg_prop_req =0 then 'N'
								  else b.Leavefocusevent end,	

		b.SetFocusEventOccurence =  case when @engg_prop_desc = 'Set Focus Event Occurence' and @engg_prop_req =1 then 'Y'
								 when @engg_prop_desc = 'Set Focus Event Occurence' and @engg_prop_req =0 then 'N'
								else b.SetFocusEventOccurence end,

		b.LeaveFocusEventOccurence =  case when @engg_prop_desc = 'Leave Focus Event Occurence' and @engg_prop_req =1 then 'Y'
								  when @engg_prop_desc = 'Leave Focus Event Occurence' and @engg_prop_req =0 then 'N'
								  else b.LeaveFocusEventOccurence end,	


			
	    b.GanttControl =  case when @engg_prop_desc = 'Gantt Control' and @engg_prop_req =1 then 'Y'
								  when @engg_prop_desc = 'Gantt Control' and @engg_prop_req =0 then 'N'
								  else b.GanttControl end,
		-- Code added for Defect id: TECH-20326 ends
		-- Added for TECH-41979 Starts
		 b.IsChips						= case when @engg_prop_desc = 'Is Chips' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Is Chips' and @engg_prop_req =0 then 'N'
										  else b.IsChips end,

		 b.MultiSelect					= case when @engg_prop_desc = 'Multi Select For List' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Multi Select For List' and @engg_prop_req =0 then 'N'
										  else b.MultiSelect end,   --code added by 13639 on 24th Nov2020
        
		b.IsSpellcheck					= case when @engg_prop_desc	=	'Spell Check Required' and @engg_prop_req	=	1 then 'Y'
										  when @engg_prop_desc	=	'Spell Check Required'	and @engg_prop_req	=	0 then 'N'
										  else	b.IsSpellcheck end,
 --code added by 13639 on 22jan2020
		b.IsSelectionReqdList			= case when @engg_prop_desc	=	'Selection Required for List' and @engg_prop_req	=	1 then 'Y'
										  when @engg_prop_desc	=	'Selection Required for List'	and @engg_prop_req	=	0 then 'N'
										  else	b.IsSelectionReqdList end, ---code added by 13639

		b.RowAlwaysExpanded				= case when @engg_prop_desc	=	'Row Always Expanded' and @engg_prop_req	=	1 then 'Y'
										  when @engg_prop_desc	=	'Row Always Expanded'	and @engg_prop_req	=	0 then 'N'
										  else	b.RowAlwaysExpanded end, --code added by 13639

										  ---code added by 13639 starts
		 b.IsMobile						= case when @engg_prop_desc = 'Is Mobile' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Is Mobile' and @engg_prop_req =0 then 'N'
										  else b.IsMobile end,

		 b.PaginationReqd				= case when @engg_prop_desc = 'Pagination Required' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Pagination Required' and @engg_prop_req =0 then 'N'
										  else b.PaginationReqd end,

		 b.UpdateTaskReqd				= case when @engg_prop_desc = 'Update Task Required' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Update Task Required' and @engg_prop_req =0 then 'N'
										  else b.UpdateTaskReqd end,

		 b.DeleteTaskReqd				= case when @engg_prop_desc = 'Delete Task Required' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Delete Task Required' and @engg_prop_req =0 then 'N'
										  else b.DeleteTaskReqd end,			
		  ---code added by 13639 ends
		  --Code added for the Defect Id Tech-68066 starts
		 b.PreTask				= case when @engg_prop_desc = 'Pre Task' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Pre Task' and @engg_prop_req =0 then 'N'
										  else b.PreTask end,

		 b.PostTask				= case when @engg_prop_desc = 'Post Task' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Post Task' and @engg_prop_req =0 then 'N'
										  else b.PostTask end,		

		--Code added for the Defect Id Tech-68066 Ends

		--Code added for the Defect Id Tech-71262 on 14July22 starts
		 b.BrowsePreTask				= CASE WHEN @engg_prop_desc = 'Browse Pre Task' and @engg_prop_req =1 THEN 'Y'
										  WHEN @engg_prop_desc = 'Browse Pre Task' and @engg_prop_req =0 THEN 'N'
										  ELSE b.BrowsePreTask END,

		 b.BrowsePostTask				= CASE WHEN @engg_prop_desc = 'Browse Post Task' and @engg_prop_req =1 THEN 'Y'
										  WHEN @engg_prop_desc = 'Browse Post Task' and @engg_prop_req =0 THEN 'N'
										  ELSE b.BrowsePostTask END,	
										  
		 b.DeletePreTask				= CASE WHEN @engg_prop_desc = 'Delete Pre Task' and @engg_prop_req =1 THEN 'Y'
										  WHEN @engg_prop_desc = 'Delete Pre Task' and @engg_prop_req =0 THEN 'N'
										  ELSE b.DeletePreTask END,

		 b.DeletePostTask				= CASE WHEN @engg_prop_desc = 'Delete Post Task' and @engg_prop_req =1 THEN 'Y'
										  WHEN @engg_prop_desc = 'Delete Post Task' and @engg_prop_req =0 THEN 'N'
										  ELSE b.DeletePostTask END,
		
		 b.ButtonStyle					= CASE WHEN @engg_prop_desc = 'Button Style' and @engg_prop_req =1 THEN 'Y'
										  WHEN @engg_prop_desc = 'Button Style' and @engg_prop_req =0 THEN 'N'
										  ELSE b.ButtonStyle END,	

		--Code added for the Defect Id Tech-71262 on 14July22 Ends
		--Code added for Defect Id Tech-73996 starts 
		 b.EyeIconForPassword			 = CASE WHEN @engg_prop_desc = 'Eye Icon for Password' and @engg_prop_req =1 THEN 'Y'
										  WHEN @engg_prop_desc = 'Eye Icon for Password'and @engg_prop_req =0 THEN 'N'
										  ELSE b.EyeIconForPassword END,
		 b.Signature					= CASE WHEN @engg_prop_desc = 'Signature' and @engg_prop_req =1 THEN 'Y'
										  WHEN @engg_prop_desc = 'Signature' and @engg_prop_req =0 THEN 'N'
										  ELSE b.Signature END,	
		 b.KeyupSearch					= CASE WHEN @engg_prop_desc = 'Keyup Search' and @engg_prop_req =1 THEN 'Y'
										  WHEN @engg_prop_desc = 'Keyup Search' and @engg_prop_req =0 THEN 'N'
										  ELSE b.KeyupSearch END,	
		 b.Stepper						= CASE WHEN @engg_prop_desc = 'Stepper' and @engg_prop_req =1 THEN 'Y'
										  WHEN @engg_prop_desc = 'Stepper' and @engg_prop_req =0 THEN 'N'
										  ELSE b.Stepper END,	
		 b.LiveClock					= CASE WHEN @engg_prop_desc = 'Live Clock' and @engg_prop_req =1 THEN 'Y'
										  WHEN @engg_prop_desc = 'Live Clock' and @engg_prop_req =0 THEN 'N'
										  ELSE b.LiveClock END,	
		 b.ClearTask					= CASE WHEN @engg_prop_desc = 'Clear Task' and @engg_prop_req =1 THEN 'Y'
										  WHEN @engg_prop_desc = 'Clear Task' and @engg_prop_req =0 THEN 'N'
										  ELSE b.ClearTask END,	
		 b.ShowAnimation				= CASE WHEN @engg_prop_desc = 'Show Animation' and @engg_prop_req =1 THEN 'Y'
										  WHEN @engg_prop_desc = 'Show Animation' and @engg_prop_req =0 THEN 'N'
										  ELSE b.ShowAnimation END,
		 b.PreventMultipleRowSelection	= CASE WHEN @engg_prop_desc = 'Prevent Multiple Row Selection' and @engg_prop_req =1 THEN 'Y'
										  WHEN @engg_prop_desc = 'Prevent Multiple Row Selection' and @engg_prop_req =0 THEN 'N'
										  ELSE b.PreventMultipleRowSelection END,

		--Code added for Defect Id Tech-73996 ends 


		 b.BulkDownload			= case when @engg_prop_desc = 'Bulk Download' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Bulk Download' and @engg_prop_req =0 then 'N'
										  else b.BulkDownload end,		--code added by 11536 for the defect TECH-68067

		 b.IsScheduler					= case when @engg_prop_desc = 'Is Scheduler' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Is Scheduler' and @engg_prop_req =0 then 'N'
										  else b.IsScheduler end,
 	
		 b.ShowLines				= case when @engg_prop_desc = 'ShowLines' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'ShowLines' and @engg_prop_req =0 then 'N'
										  else b.ShowLines end,		--TECH-66989
		 --Code added for TECH-69624 Starts
		 b.HideRuleHeader				= case when @engg_prop_desc = 'Hide Rule Header' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Hide Rule Header' and @engg_prop_req =0 then 'N'
										  else b.HideRuleHeader end,	

		 b.HideANDOperator				= case when @engg_prop_desc = 'Hide AND Operator' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Hide AND Operator' and @engg_prop_req =0 then 'N'
										  else b.HideANDOperator end,	

		 b.HideOROperator				= case when @engg_prop_desc = 'Hide OR Operator' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Hide OR Operator' and @engg_prop_req =0 then 'N'
										  else b.HideOROperator end,	

		 b.HideNOTOperator				= case when @engg_prop_desc = 'Hide NOT Operator' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Hide NOT Operator' and @engg_prop_req =0 then 'N'
										  else b.HideNOTOperator end,	

		 b.HideGroupOperator			= case when @engg_prop_desc = 'Hide Group Operator' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Hide Group Operator' and @engg_prop_req =0 then 'N'
										  else b.HideGroupOperator end,	

		 b.HideRuleOperator				= case when @engg_prop_desc = 'Hide Rule Operator' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Hide Rule Operator' and @engg_prop_req =0 then 'N'
										  else b.HideRuleOperator end,	

		 b.IsToggle						= case when @engg_prop_desc = 'Is Toggle' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Is Toggle' and @engg_prop_req =0 then 'N'
										  else b.IsToggle end,	

		 b.NFCEnabled					= case when @engg_prop_desc = 'NFC Enabled' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'NFC Enabled' and @engg_prop_req =0 then 'N'
										  else b.NFCEnabled end,	

		 b.SelectOnlyListValues			= case when @engg_prop_desc = 'Select Only List Values' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Select Only List Values' and @engg_prop_req =0 then 'N'
										  else b.SelectOnlyListValues end,	
		--Code added for TECH-69624 ends
		 b.IsList						= case when @engg_prop_desc = 'Is List' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Is List' and @engg_prop_req =0 then 'N'
										  else b.IsList end,

        b.ListItemExpander				= case when @engg_prop_desc = 'ListItem Expander' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'ListItem Expander' and @engg_prop_req =0 then 'N'
									      else b.ListItemExpander end,

		b.DirectPrint					= case when @engg_prop_desc	=	'Direct Print' and @engg_prop_req	=	1 then 'Y'
										  when @engg_prop_desc	=	'Direct Print'	and @engg_prop_req	=	0 then 'N'
										  else	b.DirectPrint end,
		-- Added for TECH-41979 Ends
		 b.AutoSync						= case when @engg_prop_desc = 'Auto Sync' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Auto Sync' and @engg_prop_req =0 then 'N'
								          else b.AutoSync end,


		 b.AutoScan						= case when @engg_prop_desc = 'Auto Scan' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Auto Scan' and @engg_prop_req =0 then 'N'
										  else b.AutoScan end,  --code added by 13639

--code added by 13852 on 20jan2020
	     b.ReadOnly						= case when @engg_prop_desc = 'Read Only' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Read Only' and @engg_prop_req =0 then 'N'
										  else b.ReadOnly end,

		  b.ShowTodayLine				= case when @engg_prop_desc = 'Show Today Line' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Show Today Line' and @engg_prop_req =0 then 'N'
										  else b.ShowTodayLine end,

		  b.ShowRollupTasks				= case when @engg_prop_desc = 'Show Rollup Tasks' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Show Rollup Tasks' and @engg_prop_req =0 then 'N'
										  else b.ShowRollupTasks end,

		  b.ShowProjectLines			= case when @engg_prop_desc = 'Show Project Lines' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Show Project Lines' and @engg_prop_req =0 then 'N'
										  else b.ShowProjectLines end,

		  b.SkipWeekendsDuringDragDrop  = case when @engg_prop_desc = 'Skip Weekends During DragDrop' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Skip Weekends During DragDrop' and @engg_prop_req =0 then 'N'
										  else b.SkipWeekendsDuringDragDrop end,

		  b.LockedGridWidth			    = case when @engg_prop_desc = 'Locked Grid Width' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Locked Grid Width' and @engg_prop_req =0 then 'N'
										  else b.LockedGridWidth end,
	
		  b.RowHeight					= case when @engg_prop_desc = 'Row Height' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Row Height' and @engg_prop_req =0 then 'N'
										  else b.RowHeight end,

		  b.BottomLabelField		    = case when @engg_prop_desc = 'Bottom LabelField' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Bottom LabelField' and @engg_prop_req =0 then 'N'
										  else b.BottomLabelField end,

		  b.TopLabelField				= case when @engg_prop_desc = 'Top LabelField' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Top LabelField' and @engg_prop_req =0 then 'N'
										  else b.TopLabelField end,

		 b.LeftLabelField				= case when @engg_prop_desc = 'Left LabelField' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Left LabelField' and @engg_prop_req =0 then 'N'
										  else b.LeftLabelField end,

		b.RightLabelField				= case when @engg_prop_desc = 'Right LabelField' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Right LabelField' and @engg_prop_req =0 then 'N'
										  else b.RightLabelField end,

		b.RollupLabelField				= case when @engg_prop_desc = 'Rollup LabelField' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Rollup LabelField' and @engg_prop_req =0 then 'N'
										  else b.RollupLabelField end,

		b.Baseline						= case when @engg_prop_desc = 'Baseline' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Baseline' and @engg_prop_req =0 then 'N'
										  else b.Baseline end,

		b.ScrollToDateCentered			= case when @engg_prop_desc = 'Scroll To DateCentered' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Scroll To DateCentered' and @engg_prop_req =0 then 'N'
										  else b.ScrollToDateCentered end,

		b.Zoom						    = case when @engg_prop_desc = 'Zoom' and @engg_prop_req =1 then 'Y'
								          when @engg_prop_desc = 'Zoom' and @engg_prop_req =0 then 'N'
								          else b.Zoom end,

		b.Fit						    = case when @engg_prop_desc = 'Fit' and @engg_prop_req =1 then 'Y'
								          when @engg_prop_desc = 'Fit' and @engg_prop_req =0 then 'N'
								          else b.Fit end,
	     
		b.Export                       = case when @engg_prop_desc = 'Export' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Export' and @engg_prop_req =0 then 'N'
										  else b.Export end,

		b.Highlight					   = case when @engg_prop_desc = 'Highlight' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Highlight' and @engg_prop_req =0 then 'N'
								          else b.Highlight end,

		b.Indent					   = case when @engg_prop_desc = 'Indent' and @engg_prop_req =1 then 'Y'
								         when @engg_prop_desc = 'Indent' and @engg_prop_req =0 then 'N'
								         else b.Indent end,

		b.Calendar					   = case when @engg_prop_desc = 'Calendar' and @engg_prop_req =1 then 'Y'
								         when @engg_prop_desc = 'Calendar' and @engg_prop_req =0 then 'N'
								         else b.Calendar end,

	   b.ContextMenu				   = case when @engg_prop_desc = 'Context Menu' and @engg_prop_req =1 then 'Y'
										 when @engg_prop_desc = 'Context Menu' and @engg_prop_req =0 then 'N'
										 else b.ContextMenu end,

	  b.PopupTaskEditor				   = case when @engg_prop_desc = 'Popup Task Editor' and @engg_prop_req =1 then 'Y'
										 when @engg_prop_desc = 'Popup Task Editor' and @engg_prop_req =0 then 'N'
								         else b.PopupTaskEditor end,

	 b.GanttShift					   = case when @engg_prop_desc = 'Shift' and @engg_prop_req =1 then 'Y'
										 when @engg_prop_desc = 'Shift' and @engg_prop_req =0 then 'N'
								         else b.GanttShift end,

    b.GanttExpand					   = case when @engg_prop_desc = 'Expand' and @engg_prop_req =1 then 'Y'
										 when @engg_prop_desc = 'Expand' and @engg_prop_req =0 then 'N'
										 else b.GanttExpand end,

    b.GanttInsert					   =  case when @engg_prop_desc = 'Insert' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Insert' and @engg_prop_req =0 then 'N'
										  else b.GanttInsert end,

    b.GanttDelete					   =  case when @engg_prop_desc = 'Delete' and @engg_prop_req =1 then 'Y'
								          when @engg_prop_desc = 'Delete' and @engg_prop_req =0 then 'N'
								          else b.GanttDelete end,

	b.BadgeText							= case when @engg_prop_desc = 'Badge Text' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Badge Text' and @engg_prop_req =0 then 'N'
										  else b.BadgeText end,		--Code Added for the DefectId Tech-72114

	b.AutoHeight						= case when @engg_prop_desc = 'Auto Height' and @engg_prop_req =1 then 'Y'
										  when @engg_prop_desc = 'Auto Height' and @engg_prop_req =0 then 'N'
										  else b.AutoHeight end,	--Code Added for the DefectId Tech-72114
   
		b.ctrl_type_descr		= @engg_modctr_desc,  
		b.base_ctrl_type		= @engg_basecmb_type, 
		b.modifiedby			= @ctxt_user ,
		b.modifieddate			= getdate() 
		from	es_comp_ctrl_type_mst_extn b (nolock) 
		where	b.customer_name = @engg_customer_name  
		and		b.project_name	= @engg_project_name  
		and		b.process_name	= @engg_process_name  
		and		b.component_name= @engg_comp_name  
		and		b.ctrl_type_name= @engg_ctrlcmb_type  
		
update a 
set a.RenderAs = case 
		when @engg_prop_desc ='Is Chips'				and @engg_prop_req = 0 then  'Tag'
		when @engg_prop_desc ='Is Tag'					and @engg_prop_req = 0 then  ''
		when @engg_prop_desc ='Grid to Form'			and @engg_prop_req = 0 then  ''
		when @engg_prop_desc ='Multi-Selector Grid'		and @engg_prop_req = 0 then  ''
		when @engg_prop_desc ='Row Expander'			and @engg_prop_req = 0 then  ''
		when @engg_prop_desc ='Is Organization Chart'	and @engg_prop_req = 0 then  ''
	-- Added for Rule Builder Starts Defect ID: TECH-35368
		when @engg_prop_desc ='Rule Builder'			and @engg_prop_req = 0 then  ''
		when @engg_prop_desc ='MultiSelect Combo for Rule Builder'			and @engg_prop_req = 0 then  ''
		when @engg_prop_desc ='Calendar Control'		and @engg_prop_req = 0 then  ''
		when @engg_prop_desc ='Gantt Control'			and @engg_prop_req = 0 then  '' -- Added for TECH-37471 
		
	-- Added for Rule Builder Ends Defect ID: TECH-35368			
				  
		when @engg_prop_desc ='Is Mobile'				 and @engg_prop_req = 0 then  ''		--code added by 13639
		
 	   
		--when isnull(a.RenderAs,'') = ''					then @engg_basecmb_type   -- commented for  Defect ID : TECH-19347
		else a.RenderAs end,		
a.ctrl_type_descr	= @engg_modctr_desc,  
a.ctrl_type_doc		= @engg_modctr_docu,  
a.base_ctrl_type	= @engg_basecmb_type,  a.modifiedby =@ctxt_user ,a.modifieddate =getdate() 
from es_comp_ctrl_type_mst a (nolock)  
where customer_name	= @engg_customer_name  
and project_name	= @engg_project_name  
and process_name    = @engg_process_name  
and component_name	= @engg_comp_name  
and ctrl_type_name	= @engg_ctrlcmb_type	

		-- Code added for  Defect ID : TECH-19347 starts
		Update es_comp_ctrl_type_mst set renderas = @engg_basecmb_type
		where	customer_name	= @engg_customer_name
		and		project_name	= @engg_project_name
		and		req_no			= 'Base'
		and		process_name	= @engg_process_name
		and		component_name	= @engg_comp_name
		and		ctrl_type_name	= @engg_ctrlcmb_type
		and		base_ctrl_type	= @engg_basecmb_type
		and		base_ctrl_type	 in ('Pivot', 'Slider', 'Assorted')--'TreeGrid', -- Modified for TECH-37471 
		and		isnull(renderas,'') = ''
		-- Code added for  Defect ID : TECH-19347 ends
		
		--- Code added for the defect id TECH-23503 Starts

		Update a
		set a.renderas = 'Scan'
		from es_comp_ctrl_type_mst		a (nolock),
			 es_comp_ctrl_type_mst_extn	b (nolock)
		where	a.customer_name	= @engg_customer_name
		and		a.project_name	= @engg_project_name
		and		a.req_no			= 'Base'
		and		a.process_name	= @engg_process_name
		and		a.component_name	= @engg_comp_name
		and		a.ctrl_type_name	= @engg_ctrlcmb_type
		and		a.base_ctrl_type	= @engg_basecmb_type
		and		a.customer_name		= b.customer_name
		and		a.project_name		=	b.project_name	
		and		a.req_no			=	b.req_no		
		and		a.process_name		=	b.process_name	
		and		a.component_name	=	b.component_name
		and		a.ctrl_type_name	=	b.ctrl_type_name
		and		a.base_ctrl_type	=	b.base_ctrl_type
				and		isnull(b.Scan,'') = 'y'
		
				Update a
		set a.renderas = 'MetaDataBasedLink'
		from es_comp_ctrl_type_mst		a (nolock),
			 es_comp_ctrl_type_mst_extn	b (nolock)
		where	a.customer_name	= @engg_customer_name
		and		a.project_name	= @engg_project_name
		and		a.req_no			= 'Base'
		and		a.process_name	= @engg_process_name
		and		a.component_name	= @engg_comp_name
		and		a.ctrl_type_name	= @engg_ctrlcmb_type
		and		a.base_ctrl_type	= @engg_basecmb_type
		and		a.customer_name		= b.customer_name
		and		a.project_name		=	b.project_name	
		and		a.req_no			=	b.req_no		
		and		a.process_name		=	b.process_name	
		and		a.component_name	=	b.component_name
		and		a.ctrl_type_name	=	b.ctrl_type_name
		and		a.base_ctrl_type	=	b.base_ctrl_type
				and		isnull(b.MetaDataBasedLink,'') = 'y'
	

update a 
set a.RenderAs = case 
		when @engg_prop_desc ='scan'					and @engg_prop_req = 0 then  ''
		when @engg_prop_desc ='MetaDataBasedLink'		and @engg_prop_req = 0 then  ''
		else a.RenderAs end,		
a.ctrl_type_descr	= @engg_modctr_desc,  
a.ctrl_type_doc		= @engg_modctr_docu,  
a.base_ctrl_type	= @engg_basecmb_type,  a.modifiedby =@ctxt_user ,a.modifieddate =getdate() 
from es_comp_ctrl_type_mst a (nolock)  
where customer_name	= @engg_customer_name  
and project_name	= @engg_project_name  
and process_name    = @engg_process_name  
and component_name	= @engg_comp_name  
and ctrl_type_name	= @engg_ctrlcmb_type	
	
	--- Code added for the defect id TECH-23503 Ends
		
Declare @tasktype		engg_name,
		@events_desc	engg_name

if exists ( select 'x'
from	es_ctrl_type_events_met (nolock)
where	events_desc		 = @engg_prop_desc
and		base_ctrl_type	 = @engg_basecmb_type) 
Begin
	select	@tasktype		= tasktype,
			@events_desc	= events_desc
	from	es_ctrl_type_events_met (nolock)
	where	events_desc		 = @engg_prop_desc
	and		base_ctrl_type	 = @engg_basecmb_type

	if	isnull(@engg_prop_req,0) = 1
	Begin
		If not exists (select 'x'
		from	es_ctrl_type_events_mst (nolock)
		where	customer_name 	= @engg_customer_name
		and		project_name 	= @engg_project_name
		and		process_name 	= @engg_process_name
		and		component_name 	= @engg_comp_name
		and		ctrl_type_name 	= @engg_ctrlcmb_type
		and		base_ctrl_type	= @engg_basecmb_type
		and		events_desc		= @events_desc)
			insert into es_ctrl_type_events_mst 
				(customer_name,			project_name,		req_no,				process_name,		component_name,		ctrl_type_name,
				base_ctrl_type,			events_desc,		events_required,	tasktype)
			values	
				(@engg_customer_name,	@engg_project_name,	'Base',				@engg_process_name,	@engg_comp_name,	@engg_ctrlcmb_type,
				@engg_basecmb_type,		@events_desc,		'Y',				@tasktype)
	End
	Else if	isnull(@engg_prop_req,0) = 0
	Begin
		If exists (select 'x'
		from	es_ctrl_type_events_mst (nolock)
		where	customer_name 	= @engg_customer_name
		and		project_name 	= @engg_project_name
		and		process_name 	= @engg_process_name
		and		component_name 	= @engg_comp_name
		and		ctrl_type_name 	= @engg_ctrlcmb_type
		and		base_ctrl_type	= @engg_basecmb_type
		and		events_desc		= @events_desc)
			Delete from es_ctrl_type_events_mst 
			where	customer_name 	= @engg_customer_name
			and		project_name 	= @engg_project_name
			and		process_name 	= @engg_process_name
			and		component_name 	= @engg_comp_name
			and		ctrl_type_name 	= @engg_ctrlcmb_type
			and		base_ctrl_type	= @engg_basecmb_type
			and		events_desc		= @events_desc
	End	
End

if	exists (select 'x'
from	es_comp_ctrl_type_mst	a	(nolock)
where	customer_name 	= @engg_customer_name
and		project_name 	= @engg_project_name
and		process_name 	= @engg_process_name
and		component_name 	= @engg_comp_name
and		ctrl_type_name 	= @engg_ctrlcmb_type
and 	IsAssorted		= 'Y'
and		visisble_rows	<> 1)
Begin
	Update  es_comp_ctrl_type_mst
	set		visisble_rows	= 1
	where	customer_name 	= @engg_customer_name
	and		project_name 	= @engg_project_name
	and		process_name 	= @engg_process_name
	and		component_name 	= @engg_comp_name
	and		ctrl_type_name 	= @engg_ctrlcmb_type
	and 	IsAssorted		= 'Y'
End

-- Set Visible rows for Tag Control
if	exists (select 'x'
from	es_comp_ctrl_type_mst	a	(nolock)
where	customer_name 	= @engg_customer_name
and		project_name 	= @engg_project_name
and		process_name 	= @engg_process_name
and		component_name 	= @engg_comp_name
and		ctrl_type_name 	= @engg_ctrlcmb_type
and 	renderas		= 'Tag'
and		(visisble_rows	<=0) or (visisble_rows >25))
Begin
	Update  es_comp_ctrl_type_mst
	set		visisble_rows	= 25
	where	customer_name 	= @engg_customer_name
	and		project_name 	= @engg_project_name
	and		process_name 	= @engg_process_name
	and		component_name 	= @engg_comp_name
	and		ctrl_type_name 	= @engg_ctrlcmb_type
	and 	renderas		= 'Tag'
End
-- Set Visible rows for Multi-Selector Grid	
if	exists (select 'x'
from	es_comp_ctrl_type_mst	a	(nolock)
where	customer_name 	= @engg_customer_name
and		project_name 	= @engg_project_name
and		process_name 	= @engg_process_name
and		component_name 	= @engg_comp_name
and		ctrl_type_name 	= @engg_ctrlcmb_type
and 	renderas		= 'MultiSelectorGrid'
and		(visisble_rows	<=0) or (visisble_rows >25))
Begin
	Update  es_comp_ctrl_type_mst
	set		visisble_rows	= 25
	where	customer_name 	= @engg_customer_name
	and		project_name 	= @engg_project_name
	and		process_name 	= @engg_process_name
	and		component_name 	= @engg_comp_name
	and		ctrl_type_name 	= @engg_ctrlcmb_type
	and 	renderas		= 'MultiSelectorGrid'
End
	
Select  @engg_1_fprowno   'engg_1_fprowno',  
		@engg_l_fprowno   'engg_l_fprowno'  
  
Set nocount off  
End  
GO
IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME= 'ep_main13Spengg_vengg_l' AND TYPE='P')
BEGIN
	GRANT EXEC ON  ep_main13Spengg_vengg_l TO PUBLIC
END
GO 
