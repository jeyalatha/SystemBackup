IF EXISTS(SELECT 'X' From SYSOBJECTS WHERE NAME ='ep_main13Spengg_vHdrChk' AND TYPE='P')
   BEGIN
        DROP PROC ep_main13Spengg_vHdrChk
   END
GO 
/********************************************************************************/
/* Procedure    : ep_main13Spengg_vHdrChk                                       */
/* Description  :                                                               */
/********************************************************************************/
/* Project      :                                                               */
/* ECR          :                                                               */
/* Version      :                                                               */
/********************************************************************************/
/* Referenced   :                                                               */
/* Tables       :                                                               */
/********************************************************************************/
/* Development history                                                          */
/********************************************************************************/
/* Author       : A Yuvaraj                                                     */
/* Date         : 22/Mar/2005                                                   */
/********************************************************************************/
/* Modification history                                                         */
/********************************************************************************/
/* modified by  : Feroz               */
/* date         : 04-Aug-2009                                                   */
/* Bug Id  : PNR2.0_2179             */
/* Description  : Phase 3 Features - ListEdit, AttachDocument, Image & DateHighlight */
/********************************************************************************/
/* Modified By  : Feroz               */
/* Date   : 26-Aug-2009             */
/* Description  : PNR2.0_23463             */
/********************************************************************************/
/* modified by  : Jeya Latha K                                                  */
/* date         : 23-Jul-2010                                                   */
/* Bug Id  : PNR2.0_27796             */
/* Description : Attach document for htm environment       */
/********************************************************************************/
/* Modified By      :   Jeya Latha K          */
/* date           :   17 Aug 2010           */
/* BugID           :   PNR2.0_28003          */
/********************************************************************************/
/* Modified By      : Chanheetha N A                    */
/* Date            : 15-Sep-2010                  */
/* BugID       : PNR2.0_28319                 */
/* Description  : image upload for htm environment       */
/********************************************************************************/
/* Modified By      : Balaji D                    */
/* Date            : July 19 2011                  */
/* BugID       : PNR2.0_32456                */
/* Description  : image for DataHyperlink         */
/********************************************************************************/
/* modified by   : Balaji D            */
/* date    : 01-Aug-2011           */
/* BugId   : PNR2.0_32288           */
/* modified for  : Provision to Apply Visible Length for Displayonly    */
/*       Control in Htm environment       */
/************************************************************************/
/* modified by   : Balaji D            */
/* date    : 01-Aug-2011           */
/* BugId   : PNR2.0_36309           */
/* modified for  : Label Link features                                  */
/************************************************************************/
/* modified by  :	 Shakthi P             															*/
/* date         : 12-Mar-2014            														*/
/* Bug ID  		: PLF2.0_07805     														  */
/* Description 	: Changes for Section Level RowSpan, ColSpan, Filler Section - Control Level RowSpan */
/*********************************************************************************/
/* modified by  :	Kanagavel														 */
/* date         :	13-Jun-2014												     	 */
/* Bug ID		:	PLF2.0_08772 													 */
/* Description	:	Validation has been added for section type map	*/
/* More changes, so, no modification history										*/
/*************************************************************************************/
/* modified by  : Piranava T  			                                        */
/* date         : Oct 10 2014			                                        */
/* BugId        : PLF2.0_09035 			                                        */
/* description  : Model changes for rowspan,colspan,IsStatic,IsCallout in? layout level */
/************************************************************************************/
/* Modified by  : Veena U                                                  */
/* Date         : 25-Feb-2015                                                  */
/* Call ID		: PLF2.0_11499                                                 */
/********************************************************************************/ 
/* Modified by  : Loganayaki P                                                 */
/* Date         : 14-OCT-2016                                                 */
/* Call ID		: TECH-218                                               */
/********************************************************************************/ 
/* Modified by  : JeyaLatha K/Ranjitha R	Date: 31-Jan-2018  Defect ID : TECH-18349 */  
/***************************************************************************************/
/* Modified by  : Ranjitha R					  Date: 06-Apr-2018			 Defect ID : TECH-20461 */
/* Modified By : Jeya Latha K					  Date: 08-Jan-2019			 Defect ID: TECH-28436  */  
/* Modified by : Jeya Latha K					  Date: 28-Jun-2019			 Defect ID: TECH-35368  */
/* Modified by  : Jeya Latha K					  Date: 30-Aug-2019			 Defect ID: TECH-37471 */
/* Modified by  : Hareesh K						  Date: 07-Nov-2019			Defect ID: TECH-39785	*/
/****************************************************************************************************/
/* Modified by : Jeya Latha K                    Date: 04-Dec-2019  Defect ID : TECH-40809          */
/* Modified by : Jeya Latha K				     Date: 14-Jan-2020	Defect ID : TECH-41979          */
/* Modified by : Priyadharshini U/Rajeswari M	 Date: 29-Jan-2020  Defect ID : TECH-42483	        */
/* Modified by : Priyadharshini U/Rajeswari M	 Date: 26-May-2020  Defect ID : TECH-46646	        */
/* Modified by : Priyadharshini U/Rajeswari M	 Date: 26-NOV-2020  Defect ID : TECH-52688	        */
/* Modified by : Deepika S						 Date: 12-FEB-2022  Defect ID : TECH-65312	        */
/* Modified by : Ponmalar A/Jeya Latha K		 Date: 28-JUL-2022  Defect ID : TECH-71109	        */
/****************************************************************************************************/
/* Modified by : Athul M / Vimal Kumar R															*/
/* Modified on : 27-Oct-2022																		*/
/* Defect ID   : TECH-73996																			*/
/* Description : Addition of attributes for control types in setup ui preferences screen			*/
/****************************************************************************************************/
/* Modified by : Ponmalar A						Date: 01-Dec-2022  Defect ID : TECH-75230           */
/****************************************************************************************************/
create Procedure ep_main13Spengg_vHdrChk
@ctxt_ouinstance                        engg_ctxt_OUInstance,  --Input
@ctxt_user								engg_ctxt_User,  --Input
@ctxt_language                          engg_ctxt_Language,  --Input
@ctxt_service                           engg_ctxt_Service,  --Input
@engg_basecmb_type                      engg_name,  --Input
@engg_component                         engg_description,  --Input
@engg_ctrlcmb_type                      engg_name,  --Input
@engg_customer_name                     engg_name,  --Input
@engg_modctr_desc                       engg_description,  --Input
@engg_modctr_docu                       engg_description,  --Input
@engg_process_descr                     engg_description,  --Input
@engg_project_name                      engg_name,  --Input
@engg_req_no                            engg_name,  --Input
@guid									engg_guid,
@hidden_control1						engg_description,
@engg_1_fprowno                         engg_RowNo,  --Input/Output
@engg_l_fprowno                         engg_RowNo,  --Input/Output
@m_errorid                              int output --To Return Execution Status

as
Begin
-- nocount should be switched on to prevent phantom rows
Set nocount on

-- @m_errorid should be 0 to Indicate Success
Set @m_errorid = 0

--declaration of temporary variables

--temporary and formal parameters mapping
SET @ctxt_user                               = ltrim(rtrim(@ctxt_user))
SET @ctxt_service                            = ltrim(rtrim(@ctxt_service))

--null checking
IF @ctxt_ouinstance = - 915
	SET @ctxt_ouinstance = NULL

IF @ctxt_user = '~#~'
	SET @ctxt_user = NULL

IF @ctxt_language = - 915
	SET @ctxt_language = NULL

IF @ctxt_service = '~#~'
	SET @ctxt_service = NULL

IF @engg_basecmb_type = '~#~'
	SET @engg_basecmb_type = NULL

IF @engg_component = '~#~'
	SET @engg_component = NULL

IF @engg_ctrlcmb_type = '~#~'
	SET @engg_ctrlcmb_type = NULL

IF @engg_customer_name = '~#~'
	SET @engg_customer_name = NULL

IF @engg_modctr_desc = '~#~'
	SET @engg_modctr_desc = NULL

IF @engg_modctr_docu = '~#~'
	SET @engg_modctr_docu = NULL

IF @engg_process_descr = '~#~'
	SET @engg_process_descr = NULL

IF @engg_project_name = '~#~'
	SET @engg_project_name = NULL

IF @engg_req_no = '~#~'
	SET @engg_req_no = NULL

IF @engg_1_fprowno = - 915
	SET @engg_1_fprowno = NULL

IF @engg_l_fprowno = - 915
	SET @engg_l_fprowno = NULL

/*
--OuputList
Select null 'engg_1_fprowno',
null 'engg_l_fprowno' from ***
*/
declare	@engg_process_name		engg_name,
		@engg_comp_name			engg_name,
		@msg					engg_documentation

Select	@engg_process_name	= process_name,
		@engg_comp_name		= component_name
from	ep_ui_req_dtl (nolock)
where	customer_name = @engg_customer_name
and		project_name = @engg_project_name
and		process_descr = @engg_process_descr
and		component_descr = @engg_component
order by 1, 2

--11536
if exists (select 'x'
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name			=		@engg_customer_name
and		project_name			=		@engg_project_name
and		process_name			=		@engg_process_name
and		component_name			=		@engg_comp_name
and		ctrl_type_name			=		@engg_ctrlcmb_type
and		base_ctrl_type			=		'Grid'
and		isnull(delete_req,'N')	=		'Y'
and		isnull(select_flag,'N') <>		'Y')

begin
	Raiserror ('"Select Flag" propery is required, if you choose "Allow Deletion" property for the grid.',16,1)
	return
end

if exists (select 'x'
from	es_comp_ctrl_type_mst (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		Is_Extjs_Control= 'Y'
and		isnull(Extjs_Ctrl_type, '') = '')
begin
	Raiserror ('Specify valid Rich Control Type',16,1)
	return
end

-- Added By Feroz Start

if exists (select 'x'
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		isnull(buttoncombo_req,'N') = 'N'
and		isnull(dataascaption,'N')	= 'Y')
begin
	Raiserror ('Button Combo property should be selected for selecting Data As Caption property.',16,1)
	return
end

if exists (select 'x'
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		isnull(image_upload,'N')	= 'Y'
and		isnull(attach_document,'N') = 'Y')

begin
	Raiserror ('Image Upload and Attach Document both cannot be specified select any one.',16,1)
	return
end

----------------------Code added Against the Defect ID : TECH-65312 starts -------------------------------
if exists (select 'x'
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name						= @engg_customer_name
and		project_name						= @engg_project_name
and		process_name						= @engg_process_name
and		component_name						= @engg_comp_name
and		ctrl_type_name						= @engg_ctrlcmb_type
and		isnull(attach_document,'N')			= 'Y'
and		isnull(save_doc_content_to_db,'n')	<>'y'
and		isnull(AttachmentWithDesc,'n')		= 'n')

begin
			raiserror('For the Attachment control Type, Attachment with Desc is mandatory',16,1)
	return
end

if exists (select 'x'
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name						= @engg_customer_name
and		project_name						= @engg_project_name
and		process_name						= @engg_process_name
and		component_name						= @engg_comp_name
and		ctrl_type_name						= @engg_ctrlcmb_type
and		isnull(image_upload,'N')			= 'Y'
and		isnull(save_image_content_to_db,'n')<>'y'
and		isnull(AttachmentWithDesc,'n')		= 'n')

begin
			raiserror('For the Attachment control Type, Attachment with Desc is mandatory',16,1)
	return
end
----------------------Code added Against the Defect ID : TECH-65312 ends -------------------------------

if exists (select 'x'
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		isnull(image_upload,'N')	= 'N'
and		(isnull(inplace_image,'N')	= 'Y' or isnull(image_icon,'N') = 'Y')
and		Base_ctrl_type not in ('Link','Datahyperlink'))--Code added for the Bug ID : PNR2.0_32456
begin
	Raiserror ('Image Upload Property should be selected for selecting Inplace Image/Image Icon',16,1)
	return
end



if exists (select 'x'
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		isnull(image_upload,'N')	= 'Y'
and		isnull(inplace_image,'N')	= 'Y'
and		isnull(image_icon,'N')		= 'Y')
begin
Raiserror ('For Image Upload select any one property Inplace Image or Image Icon',16,1)
return
end



if exists (select 'x'
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		isnull(inplace_image,'N')	= 'Y'
and		isnull(image_row_height,'') = '')
begin
	Raiserror ('Specify Image Row Height for Inplace Image',16,1)
	return
end
--Code added for the Bug ID : PNR2.0_32456 starts
if exists (select 'x'
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		isnull(image_icon,'N')		= 'Y'
and		Base_ctrl_type  in ('Link','Datahyperlink')
and		isnull(image_row_height,'') = '')
begin
	Raiserror ('Specify Image Row Height for Image Icon',16,1)
	return
end

if exists (select 'x'
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		isnull(image_icon,'N')		= 'Y'
and		Base_ctrl_type  in ('Link','Datahyperlink')
and		isnull(image_row_width,'')	= '')
begin
	Raiserror ('Specify Image Row Width for Image Icon',16,1) --9508
	return
end
--Code added for the Bug ID : PNR2.0_32456 ends

if exists (select 'x'
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		isnull(attach_document,'N')				= 'Y'
and		(isnull(save_image_content_to_db,'')	= 'Y' or isnull(relative_image_path,'') <> ''
or		isnull(inplace_image,'')				= 'Y' or isnull(image_icon,'N') = 'Y'))
begin
	Raiserror ('For Attach Document,  Relative Image Path / Save Image Content to DB / Inplace Image / Image Icon Property not applicable',16,1)
	return
end

-- code added for Defect ID : TECH-18349 starts
if exists(Select 'x'  
from	es_comp_ctrl_type_mst (nolock)
where	customer_name		= @engg_customer_name  
and		project_name		= @engg_project_name  
and		process_name		= @engg_process_name  
and		component_name		= @engg_comp_name  
and		ctrl_type_name		= @engg_ctrlcmb_type  
and		base_ctrl_type		= 'Edit'
and     isnull(AttachmentWithDesc,'N') = 'Y'
and     isnull(save_doc_content_to_db,'N') = 'Y')
begin  
	Raiserror ('Remove one of the attibute from Attachment with Description and Save document content to DB to perform Attach document.',16,1)  
	return  
end 
--code added for Defect ID : TECH-18349 ends

if exists (select 'x'
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		isnull(image_upload,'N')			= 'Y'
and		(isnull(save_doc_content_to_db,'')	= 'Y' or isnull(relative_document_path,'') <> ''))
begin
	Raiserror ('For Image Upload,  Relative Document Path / Save Document Content to DB Property not applicable',16,1)
	return
end

if exists (select 'x'
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		isnull(image_upload,'N') = 'Y'
and		isnull(attach_document,'N') = 'Y' )
begin
	Raiserror ('Image Upload / Attach Document Specify any one property',16,1)
	return
end


if exists (select 'x'
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		isnull(image_upload,'N')		= 'Y'
and		isnull(associatedlist_req,'N')	= 'Y' )
begin
	Raiserror ('Image Upload / Associated List Specify any one property',16,1)
	return
end


if exists (select 'x'
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		isnull(attach_document,'N')		= 'Y'
and		isnull(associatedlist_req,'N')	= 'Y' )
begin
	Raiserror ('Attach Document / Associated List Specify any one property',16,1)
	return
end

if exists (select 'x'
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		isnull(associatedlist_req,'')	= 'N'
and		(isnull(onfocustask_req, '')	= 'Y'
or		isnull(listrefilltask_req,'')	= 'Y'))
begin
	Raiserror (' Specify Associated List property for Onfocus Task / List Refill Task ',16,1)
	return
end

if exists ( select 'x'
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		isnull(Date_highlight,'N')		= 'Y'
and		isnull(associatedlist_req,'N')	= 'Y' )
begin
	Raiserror ('Date Highlight / Associated List Specify any one property',16,1)
	return
end

if exists (select 'x'
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		isnull(Date_highlight,'N')	= 'Y'
and		isnull(attach_document,'N') = 'Y' )
begin
	Raiserror ('Date Highlight / Attach Document Specify any one property',16,1)
	return
end

if exists (select 'x'
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		isnull(Date_highlight,'N')	= 'Y'
and		isnull(image_upload,'N')	= 'Y' )
begin
	Raiserror ('Date Highlight / Image Upload Specify any one property',16,1)
	return
end

-- Modified By feroz for bug id :PNR2.0_23463
if exists (select 'x'
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		base_ctrl_type	= 'ListEdit'
and		isnull(Date_highlight,'N')		= 'Y'
and		isnull(listedit_noofcolumns,0) <> 3 )
begin
	Raiserror ('For Date Highlight No of Columns should be 3',16,1)
	return
end
-- Modified By feroz for bug id :PNR2.0_23463

-- Added By Feroz ends
-- Code Added by Jeya for bug id :PNR2.0_27796 Starts
if exists (select 'x'
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		base_ctrl_type	= 'Edit'
and		isnull(Lite_Attach_Document,'N') = 'Y'
and		isnull(attach_document,'N')		 <> 'Y' )
begin
	Raiserror ('For Lite Attach Document, ''Attach Document'' Attribute is mandatory.',16,1)
	return
end

if exists (select 'x'
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name = @engg_customer_name
and		project_name = @engg_project_name
and		process_name = @engg_process_name
and		component_name = @engg_comp_name
and		ctrl_type_name = @engg_ctrlcmb_type
and		base_ctrl_type = 'Edit'
and		isnull(Lite_Attach_Document,'N') = 'Y'
and		isnull(editable_flag,'N') = 'Y' )
begin
	Raiserror ('''Editable'' Attribute should not be selected for Lite Attach Document.',16,1)
	return
end
-- Code Added by Jeya for bug id :PNR2.0_27796 End

-- Code Added for the BugId: PNR2.0_28003 Starts
--if exists (select 'x'
--from	es_comp_ctrl_type_mst  (nolock)
--where	customer_name = @engg_customer_name
--and		project_name = @engg_project_name
--and		process_name = @engg_process_name
--and		component_name = @engg_comp_name
--and		ctrl_type_name = @engg_ctrlcmb_type
--and		base_ctrl_type = 'Grid'
--and		isnull(visisble_flag,'') <> 'Y')
--begin
--	Raiserror ('''Visible'' Attribute is mandatory for Grids.',16,1)
--	return
--end

update	es_comp_ctrl_type_mst  set 
		visisble_rows = 25
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		RenderAs		= 'Tag'
and		(isnull(visisble_rows,0) = 0 or isnull(visisble_rows,0) >25 )

if exists (select 'x'
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		base_ctrl_type	in ('Grid', 'ListView')	-- ListView added for TECH-28436
and		isnull(visisble_rows,0) = 0)
begin
	Raiserror ('Enter a valid value (greater than zero) for Visible Rows.',16,1)
	return
end
-- Code Added for the BugId: PNR2.0_28003 End
--code added for the caseid : PNR2.0_28319 starts

if exists (select 'x'
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		base_ctrl_type	= 'Edit'
and		isnull(Lite_Attach_Image,'N') = 'Y'
and		isnull(image_upload,'N')	  <> 'Y' )
begin
	Raiserror ('For Lite Attach Image, ''Image Upload'' Attribute is mandatory.',16,1)
	return
end

if exists (select 'x'
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		base_ctrl_type	= 'Edit'
and		isnull(Lite_Attach_Image,'N') = 'Y'
and		isnull(editable_flag,'N')	  = 'Y' )
begin
	Raiserror ('''Editable'' Attribute should not be selected for Lite Attach Image.',16,1)
	return
end

if exists (select 'x'
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		base_ctrl_type	= 'Edit'
and		isnull(Lite_Attach_Image,'N')	= 'Y'
and		isnull(relative_image_path,'')	= '' )
begin
	Raiserror ('Please provide Relative Image Path',16,1)
	return
end

if exists (select 'x'
from  es_comp_ctrl_type_mst  (nolock)
where customer_name		= @engg_customer_name
and   project_name		= @engg_project_name
and   process_name		= @engg_process_name
and   component_name	= @engg_comp_name
and   ctrl_type_name	= @engg_ctrlcmb_type
and   base_ctrl_type	= 'Edit'
and   isnull(Lite_Attach_Image,'N') = 'Y'
and   isnull(image_row_height,0)	= 0 )
begin
	Raiserror ('Please provide Image height',16,1)
	return
end

if exists (select 'x'
from  es_comp_ctrl_type_mst  (nolock)
where customer_name		= @engg_customer_name
and   project_name		= @engg_project_name
and   process_name		= @engg_process_name
and   component_name	= @engg_comp_name
and   ctrl_type_name	= @engg_ctrlcmb_type
and   base_ctrl_type	= 'Edit'
and   isnull(Lite_Attach_Image,'N') = 'Y'
and   isnull(image_row_width,0)		= 0 )
begin
	Raiserror ('Please provide Image width',16,1)
	return
end

if exists (select 'x'
from  es_comp_ctrl_type_mst  (nolock)
where customer_name		= @engg_customer_name
and   project_name		= @engg_project_name
and   process_name		= @engg_process_name
and   component_name	= @engg_comp_name
and   ctrl_type_name	= @engg_ctrlcmb_type
and   base_ctrl_type	= 'Edit'
and   isnull(image_preview_req,'N')		= 'Y'
and   isnull(image_preview_height,0)	= 0 )
begin
	Raiserror ('Please provide Preview Image height',16,1)
	return
end

if exists (select 'x'
from  es_comp_ctrl_type_mst  (nolock)
where customer_name = @engg_customer_name
and   project_name	= @engg_project_name
and   process_name	= @engg_process_name
and   component_name= @engg_comp_name
and   ctrl_type_name= @engg_ctrlcmb_type
and   base_ctrl_type= 'Edit'
and   isnull(image_preview_req,'N') = 'Y'
and   isnull(image_preview_width,0) = 0 )
begin
	Raiserror ('Please provide Preview Image width',16,1)
	return
end
--code added for the caseid : PNR2.0_28319 ends
--code added for the caseid : PNR2.0_32288 starts
if exists (select 'x'
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		base_ctrl_type	= 'Edit'
and		isnull(Disp_Only_Apply_Len,'N') = 'Y'
and		isnull(editable_flag,'N')		= 'Y' )
begin
	Raiserror ('Editable / Apply Visible Length, Specify any one property',16,1)
	return
end

if exists (select 'x'
from  es_comp_ctrl_type_mst  (nolock)
where customer_name = @engg_customer_name
and  project_name	= @engg_project_name
and  process_name	= @engg_process_name
and  component_name = @engg_comp_name
and  ctrl_type_name = @engg_ctrlcmb_type
and  base_ctrl_type = 'Edit'
and  isnull(Disp_Only_Apply_Len,'N') = 'Y'
and  isnull(visisble_rows,0)		 <> 0)
begin
	Raiserror ('Visible Rows should not be greater than Zero ,If Apply Visible Length property is checked.',16,1)
	return
end
--code added for the caseid : PNR2.0_32288 ends

--code added for the caseid : PNR2.0_36309 starts
if exists (select 'x'
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		isnull(caption_req,'N') <> 'Y'
and		isnull(Label_Link,'N')	= 'Y' )
begin
	Raiserror ('''Caption Required'' Attribute is mandatory,If Label Link property is checked.',16,1)
	return
end

if exists (select 'x'
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		(isnull(buttoncombo_req,'N') = 'Y' or isnull(dataascaption,'N') = 'Y')
and		isnull(Label_Link,'N')		 = 'Y' )
begin
	Raiserror ('Button Combo / Label Link Specify any one property',16,1)
	return
end

if exists (select 'x'
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		isnull(help_req,'N')	= 'Y'
and		isnull(Label_Link,'N')	= 'Y' )
begin
	Raiserror ('Help Required / Label Link Specify any one property',16,1)
	return
end
--code added for the caseid : PNR2.0_36309 ends
if exists (select 'x'   --PLF2.0_07805    
from	es_comp_ctrl_type_mst  (nolock)  
where	customer_name	= @engg_customer_name  
and		project_name	= @engg_project_name  
and		process_name	= @engg_process_name  
and		component_name	= @engg_comp_name  
and		ctrl_type_name	= @engg_ctrlcmb_type  
and		isnull(ButtonHome_Req,'N')		= 'Y'  
and		isnull(ButtonPrevious_Req,'N')	= 'Y' ) 
begin  
	Raiserror ('Home Button / Previous Button Specify any one property',16,1)  
	return  
end  

if exists (select 'x'  
from	es_comp_ctrl_type_mst  (nolock)  
where	customer_name	= @engg_customer_name  
and		project_name	= @engg_project_name  
and		process_name	= @engg_process_name  
and		component_name	= @engg_comp_name  
and		ctrl_type_name	= @engg_ctrlcmb_type  
and		isnull(combo_link,'N')			= 'Y'  
and		isnull(event_handling_req,'N')	= 'Y' )  
begin  
	Raiserror ('''Handle Events'' Attribute should not be selected for Combo Link.',16,1)  
	return  
end  

-- Added for Rule Builder Starts Defect ID: TECH-35368

if exists(Select 'x'  
from	es_comp_ctrl_type_mst mst (nolock),
		es_comp_ctrl_type_mst_extn extn (nolock)
where	extn.customer_name	= @engg_customer_name  
and		extn.project_name	= @engg_project_name  
and		extn.process_name	= @engg_process_name  
and		extn.component_name	= @engg_comp_name  
and		extn.ctrl_type_name	= @engg_ctrlcmb_type  
and		extn.base_ctrl_type	= 'Grid'
and     extn.MultiSelectComboforRB ='Y'											
and		isnull(extn.RuleBuilder,'')<>'y' 
and		mst.customer_name	= extn.customer_name  
and		mst.project_name	= extn.project_name  
and		mst.process_name	= extn.process_name
and		mst.component_name	= extn.component_name
and		mst.ctrl_type_name	= extn.ctrl_type_name
and		mst.base_ctrl_type	= extn.base_ctrl_type
)  
begin  
	Raiserror ('For the MultiSelect Combo Rule Builder property Should be enabled.',16,1)  
	return  
end 

if exists(Select 'x'  
from	es_comp_ctrl_type_mst mst (nolock),
		es_comp_ctrl_type_mst_extn extn (nolock)
where	extn.customer_name	= @engg_customer_name  
and		extn.project_name	= @engg_project_name  
and		extn.process_name	= @engg_process_name  
and		extn.component_name	= @engg_comp_name  
and		extn.ctrl_type_name	= @engg_ctrlcmb_type  
and		extn.base_ctrl_type	= 'Grid'
and     extn.CalendarControl ='Y'		
and		extn.RuleBuilder	='Y'		
and		mst.customer_name	= extn.customer_name  
and		mst.project_name	= extn.project_name  
and		mst.process_name	= extn.process_name
and		mst.component_name	= extn.component_name
and		mst.ctrl_type_name	= extn.ctrl_type_name
and		mst.base_ctrl_type	= extn.base_ctrl_type
)  
begin 
	Raiserror ('Please select either ''Calendar Control'' or ''Rule Builder'' property.',16,1)   
	--Raiserror ('For the Calendar Control, Rule Builder property Should be disabled.',16,1)  
	return  
end 
--Added for the Defect id: TECH-46646  starts

if exists(Select 'x'  
from	es_comp_ctrl_type_mst mst (nolock),
		es_comp_ctrl_type_mst_extn extn (nolock)
where	extn.customer_name	= @engg_customer_name  
and		extn.project_name	= @engg_project_name  
and		extn.process_name	= @engg_process_name  
and		extn.component_name	= @engg_comp_name  
and		extn.ctrl_type_name	= @engg_ctrlcmb_type  
and		extn.base_ctrl_type	= 'Grid'
and     extn.RowAlwaysExpanded ='Y'		
and    isnull(mst.renderas,'') <> 'RowExpander'
and		mst.customer_name	= extn.customer_name  
and		mst.project_name	= extn.project_name  
and		mst.process_name	= extn.process_name
and		mst.component_name	= extn.component_name
and		mst.ctrl_type_name	= extn.ctrl_type_name
and		mst.base_ctrl_type	= extn.base_ctrl_type
)  
begin 
	Raiserror ('Please select  ''Row Expander''  ''to enable  Row Always Expanded property''.',16,1)   
	 return  
end 


if exists(Select 'x'  
from	es_comp_ctrl_type_mst mst (nolock),
		es_comp_ctrl_type_mst_extn ext (nolock)
where	ext.customer_name	= @engg_customer_name  
and		ext.project_name	= @engg_project_name  
and		ext.process_name	= @engg_process_name  
and		ext.component_name	= @engg_comp_name  
and		ext.ctrl_type_name	= @engg_ctrlcmb_type  
and		ext.base_ctrl_type	= 'Grid'
and     ISNULL(ext.ListItemType,'') IN ('SingleCheck', 'MultiCheck')
and		isnull(ext.IsList,'N')	= 'N'

and		mst.customer_name	= ext.customer_name  
and		mst.project_name	= ext.project_name  
and		mst.process_name	= ext.process_name
and		mst.component_name	= ext.component_name
and		mst.ctrl_type_name	= ext.ctrl_type_name
and		mst.base_ctrl_type	= ext.base_ctrl_type
)  
begin 
	Raiserror ('''ListItem Type'' attribute can be enabled for Is List . Please select the ''Is List''.',16,1)   	
	return  
end

--Code added For the Defect id : TECH-52688 Starts

--Code commented For the Defect id : TECH-71109 starts
--if exists(Select 'x'  
--from	es_comp_ctrl_type_mst_extn ext (nolock)
--where	ext.customer_name	= @engg_customer_name  
--and		ext.project_name	= @engg_project_name  
--and		ext.process_name	= @engg_process_name  
--and		ext.component_name	= @engg_comp_name  
--and		ext.ctrl_type_name	= @engg_ctrlcmb_type  
--and		ext.base_ctrl_type	= 'Grid'
--and		(ISNULL(multiselect,'')	= 'Y' AND ISNULL(IsMobile,'N')='N')
--)
--begin 
--	Raiserror ('Please select ''Is Mobile'' attribute to enable ''Multi Select for List'' attribute',16,1)     	
--	return  
--end 
--Code commented For the Defect id : TECH-71109 ends


--Code added For the Defect id : TECH-52688 Ends


--if exists(Select 'x'  
--from	es_comp_ctrl_type_mst_extn ext (nolock)
--where	ext.customer_name	= @engg_customer_name  
--and		ext.project_name	= @engg_project_name  
--and		ext.process_name	= @engg_process_name  
--and		ext.component_name	= @engg_comp_name  
--and		ext.ctrl_type_name	= @engg_ctrlcmb_type  
--and		ext.base_ctrl_type	= 'Grid'
--and		(IsList	= 'Y' OR IsMobile='N')
--)  
--begin 
--	Raiserror ('Please select ''Is Mobile'' to enable the attribute ''Is List''.',16,1)   	
--	return  
--end 

if exists(Select 'x'  
from	es_comp_ctrl_type_mst mst (nolock),
		es_comp_ctrl_type_mst_extn ext (nolock)
where	ext.customer_name	= @engg_customer_name  
and		ext.project_name	= @engg_project_name  
and		ext.process_name	= @engg_process_name  
and		ext.component_name	= @engg_comp_name  
and		ext.ctrl_type_name	= @engg_ctrlcmb_type  
and		ext.base_ctrl_type	= 'Grid'
and		IsSelectionReqdList='Y'
and    ISNULL(ext.ListItemType,'')=''

and		mst.customer_name	= ext.customer_name  
and		mst.project_name	= ext.project_name  
and		mst.process_name	= ext.process_name
and		mst.component_name	= ext.component_name
and		mst.ctrl_type_name	= ext.ctrl_type_name
and		mst.base_ctrl_type	= ext.base_ctrl_type
)  
begin 
	Raiserror ('''Selection Required for List'' attribute can be enabled for ListItem Type  . Please select the ''ListItem Type''.',16,1)   	
	return  
end 

if exists(Select 'x'  
from	es_comp_ctrl_type_mst mst (nolock),
		es_comp_ctrl_type_mst_extn extn (nolock)
where	mst.customer_name	= @engg_customer_name  
and		mst.project_name	= @engg_project_name  
and		mst.process_name	= @engg_process_name  
and		mst.component_name	= @engg_comp_name  
and		mst.ctrl_type_name	= @engg_ctrlcmb_type  
and		mst.base_ctrl_type	= 'Grid'
and    ( PaginationReqd	= 'Y'
OR      UpdateTaskReqd  = 'Y'
OR      DeleteTaskReqd  = 'Y')
and     ISNULL(IsMobile,'N')=  'N'
and		mst.customer_name	= extn.customer_name  
and		mst.project_name	= extn.project_name  
and		mst.process_name	= extn.process_name
and		mst.component_name	= extn.component_name
and		mst.ctrl_type_name	= extn.ctrl_type_name
and		mst.base_ctrl_type	= extn.base_ctrl_type)
begin  
	Raiserror ('Please select ''Is Mobile'' to enable Pagination Required/Update Task Required/Delete Task Required.',16,1)  
	return  
end 


--Added for the Defect id: TECH-46646  ends

-- Added for Rule Builder Ends Defect ID: TECH-35368
-- Added for TECH-37471
if exists(Select 'x'  
from	es_comp_ctrl_type_mst mst (nolock),
		es_comp_ctrl_type_mst_extn ext (nolock)
where	ext.customer_name	= @engg_customer_name  
and		ext.project_name	= @engg_project_name  
and		ext.process_name	= @engg_process_name  
and		ext.component_name	= @engg_comp_name  
and		ext.ctrl_type_name	= @engg_ctrlcmb_type  
and		ext.base_ctrl_type	= 'TreeGrid'
and     ext.AutoSync		= 'Y'		
and		isnull(ext.GanttControl,'N')	= 'N'

and		mst.customer_name	= ext.customer_name  
and		mst.project_name	= ext.project_name  
and		mst.process_name	= ext.process_name
and		mst.component_name	= ext.component_name
and		mst.ctrl_type_name	= ext.ctrl_type_name
and		mst.base_ctrl_type	= ext.base_ctrl_type
)  
begin 
	Raiserror ('''Auto Sync'' attribute can be enabled for Gantt. Please select the ''Gantt Control'' attribute.',16,1)   	
	return  
end 

if exists(Select 'x'  
from	es_comp_ctrl_type_mst mst (nolock),
		es_comp_ctrl_type_mst_extn ext (nolock)
where	ext.customer_name	= @engg_customer_name  
and		ext.project_name	= @engg_project_name  
and		ext.process_name	= @engg_process_name  
and		ext.component_name	= @engg_comp_name  
and		ext.ctrl_type_name	= @engg_ctrlcmb_type  
and		ext.base_ctrl_type	= 'TreeGrid'
and     ISNULL(ext.Orientation,'') IN ('Horizontal', 'Vertical')
and		isnull(ext.IsOrgChart,'N')	= 'N'

and		mst.customer_name	= ext.customer_name  
and		mst.project_name	= ext.project_name  
and		mst.process_name	= ext.process_name
and		mst.component_name	= ext.component_name
and		mst.ctrl_type_name	= ext.ctrl_type_name
and		mst.base_ctrl_type	= ext.base_ctrl_type
)  
begin 
	Raiserror ('''Orientation'' attribute can be enabled for Organization Chart. Please select the ''Organization Chart''.',16,1)   	
	return  
end 

--Kanagavel 
if exists (select 'x' --PLF2.0_07805
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		base_ctrl_type	= 'Edit'
and		isnull(Map_In_Req,'N')	= 'Y'
and		isnull(Map_Out_Req,'N') = 'Y' )
begin
	Raiserror ('Map In Req / Map Out Req Specify any one property',16,1)
	return
end

if exists (select 'x' --PLF2.0_07805
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		(isnull(Barcode_Image,'N') = 'Y' or  isnull(QR_Image,'N') = 'Y')
and		base_ctrl_type <> 'Edit' )
begin
	Raiserror ('BarCode Image / QR Image property is applicable only for Edit controls.',16,1)
	return
end
-- Below validation added against TECH-218   Starts

if exists (select 'x' --PLF2.0_07805
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		base_ctrl_type	= 'Edit'
and		isnull(Barcode_Image,'N')	= 'Y'
and		isnull(QR_Image,'N')		= 'Y' )
begin
	Raiserror ('BarCode Image / QR Image Specify any one property',16,1)
	return
end

if exists (select 'x'
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		isnull(attach_document,'N')			= 'Y'
and		(isnull(save_doc_content_to_db,'')	= 'Y' and  isnull(relative_document_path,'') <> ''))
begin
	Raiserror ('For Attach Document,Give either Relative Document Path / Save Document Content to DB Property',16,1)
	return
end
-- Below validation added against TECH-218   Ends

if exists (select 'x'
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		isnull(image_upload,'N')			 = 'Y'
and		(isnull(save_image_content_to_db,'') = 'Y' and isnull(relative_image_path,'') <> ''))
begin
	Raiserror ('For Attach Image,Give either Relative Document Path / Save Document Content to DB Property',16,1)
	return
end

-- Below validation added against case id : TECH-8474 Starts
if exists (select 'x'
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		isnull(relative_document_path,'')<>''
and		attach_document = 'y'
and		(dbo.check_spl_char(relative_document_path) =1))
begin
	Raiserror ('For Attach Document,special character is not allowed. Kindly change the Relative Document Path and proceed',16,1)
	return
end

if exists (select 'x'
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name	= @engg_customer_name
and		project_name	= @engg_project_name
and		process_name	= @engg_process_name
and		component_name	= @engg_comp_name
and		ctrl_type_name	= @engg_ctrlcmb_type
and		isnull(Relative_Image_Path,'')<>''
and		image_upload	='Y'
and		(dbo.check_spl_char(Relative_Image_Path) =1))
begin
	Raiserror ('For Attach Document,special character is not allowed. Kindly change the Relative image Path and proceed',16,1)
	return
end

-- Below validation added against case id : TECH-8474 Ends

-- code added for Defect ID : TECH-18349 starts
if exists(Select 'x'  
from	es_comp_ctrl_type_mst(nolock)  
where	customer_name	= @engg_customer_name  
and		project_name	= @engg_project_name  
and		process_name	= @engg_process_name  
and		component_name	= @engg_comp_name  
and		ctrl_type_name	= @engg_ctrlcmb_type  
and		base_ctrl_type	= 'TreeGrid'
and     visisble_rows   <= 0)  
begin  
	Raiserror ('Visible rows should be greater than zero for Treegrid.',16,1)  
	return  
end 


if exists(Select 'x'  
from	es_comp_ctrl_type_mst mst (nolock),
		es_comp_ctrl_type_mst_extn extn (nolock)
where	mst.customer_name	= @engg_customer_name  
and		mst.project_name	= @engg_project_name  
and		mst.process_name	= @engg_process_name  
and		mst.component_name	= @engg_comp_name  
and		mst.ctrl_type_name	= @engg_ctrlcmb_type  
and		mst.base_ctrl_type	= 'Edit'
and     Delayedpwdmask		= 'Y'
and		(password_char		= 'N'
or		password_char       is null)
and		mst.customer_name	= extn.customer_name  
and		mst.project_name	= extn.project_name  
and		mst.process_name	= extn.process_name
and		mst.component_name	= extn.component_name
and		mst.ctrl_type_name	= extn.ctrl_type_name
and		mst.base_ctrl_type	= extn.base_ctrl_type)
begin  
	Raiserror ('Please select ''Password Char'' to enable Delayed Password Masking.',16,1)  
	return  
end 
/*
if exists(Select 'x'  
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name	= @engg_customer_name  
and		project_name	= @engg_project_name  
and		process_name	= @engg_process_name  
and		component_name	= @engg_comp_name  
and		ctrl_type_name	= @engg_ctrlcmb_type  
and		base_ctrl_type	= 'Edit'
and		AttachmentWithDesc = 'Y'
and		(attach_document	= 'N'
or      attach_document  is null))
begin  
	Raiserror ('Please select ''Attach Document'' to enable Attachment with Describtion.',16,1)  
	return  
end 
*/

----------------------Code added Against the Defect ID : TECH-65312 starts -------------------------------

if exists(Select 'x'  
from	es_comp_ctrl_type_mst  (nolock)
where	customer_name			= @engg_customer_name  
and		project_name			= @engg_project_name  
and		process_name			= @engg_process_name  
and		component_name			= @engg_comp_name  
and		ctrl_type_name			= @engg_ctrlcmb_type  
and		base_ctrl_type			= 'Edit'
and		AttachmentWithDesc		= 'Y'
and		(attach_document		= 'N'
or      attach_document  is null)
and     isnull(image_upload,'n') ='n')
begin  
	Raiserror ('Please select ''Attach Document'' or ''Image Upload'' to enable Attachment with Description.',16,1)  
	return  
end 


----------------------Code added Against the Defect ID : TECH-65312 ends -------------------------------

if exists(Select 'x'  
from	es_comp_ctrl_type_mst mst (nolock),
		es_comp_ctrl_type_mst_extn extn (nolock)
where	mst.customer_name	= @engg_customer_name  
and		mst.project_name	= @engg_project_name  
and		mst.process_name	= @engg_process_name  
and		mst.component_name	= @engg_comp_name  
and		mst.ctrl_type_name	= @engg_ctrlcmb_type  
and		mst.base_ctrl_type	= 'Edit'
and     Dynamicfileupload	= 'Y'
and		((AttachmentWithDesc  = 'N'
or      AttachmentWithDesc  is null) and image_icon='N')
and		mst.customer_name	= extn.customer_name  
and		mst.project_name	= extn.project_name  
and		mst.process_name	= extn.process_name
and		mst.component_name	= extn.component_name
and		mst.ctrl_type_name	= extn.ctrl_type_name
and		mst.base_ctrl_type	= extn.base_ctrl_type)
begin  
	Raiserror ('Please select ''Attachment with Description '' to enable Dynamic file upload path.',16,1)  
	return  
end 

if exists(Select 'x'  
from	es_comp_ctrl_type_mst mst (nolock),
		es_comp_ctrl_type_mst_extn extn (nolock)
where	mst.customer_name	= @engg_customer_name  
and		mst.project_name	= @engg_project_name  
and		mst.process_name	= @engg_process_name  
and		mst.component_name	= @engg_comp_name  
and		mst.ctrl_type_name	= @engg_ctrlcmb_type  
and		mst.base_ctrl_type	= 'Edit'
and     MultiFileSelect		= 'Y'
and		(AttachmentWithDesc = 'N'
or      AttachmentWithDesc  is null)
and		mst.customer_name	= extn.customer_name  
and		mst.project_name	= extn.project_name  
and		mst.process_name	= extn.process_name
and		mst.component_name	= extn.component_name
and		mst.ctrl_type_name	= extn.ctrl_type_name
and		mst.base_ctrl_type	= extn.base_ctrl_type)
begin  
	Raiserror ('Please select Attachment with Description options to enable MultiFileSelect.',16,1)  
	return  
end 

if exists(Select 'x'  
from	es_comp_ctrl_type_mst mst (nolock),
		es_comp_ctrl_type_mst_extn extn (nolock)
where	mst.customer_name	= @engg_customer_name  
and		mst.project_name	= @engg_project_name  
and		mst.process_name	= @engg_process_name  
and		mst.component_name	= @engg_comp_name  
and		mst.ctrl_type_name	= @engg_ctrlcmb_type  
and		mst.base_ctrl_type	= 'Edit'
and     Dynamicfileupload	= 'Y'
and     relative_document_path  is not null
and		mst.customer_name	= extn.customer_name  
and		mst.project_name	= extn.project_name  
and		mst.process_name	= extn.process_name
and		mst.component_name	= extn.component_name
and		mst.ctrl_type_name	= extn.ctrl_type_name
and		mst.base_ctrl_type	= extn.base_ctrl_type)
begin  
	Raiserror ('Relative Document Path can not be specified for Dynamic File Upload Path attribute.',16,1)  
	return  
end 

if exists(Select 'x'  
from	es_comp_ctrl_type_mst mst (nolock),
		es_comp_ctrl_type_mst_extn extn (nolock)
where	mst.customer_name	= @engg_customer_name  
and		mst.project_name	= @engg_project_name  
and		mst.process_name	= @engg_process_name  
and		mst.component_name	= @engg_comp_name  
and		mst.ctrl_type_name	= @engg_ctrlcmb_type  
and		mst.base_ctrl_type	in  ('Button', 'Link', 'Datahyperlink')
and     ServerSidePrint		= 'Y' 
and		(report_req			= 'N'
or      report_req  is null)
and		mst.customer_name	= extn.customer_name  
and		mst.project_name	= extn.project_name  
and		mst.process_name	= extn.process_name
and		mst.component_name	= extn.component_name
and		mst.ctrl_type_name	= extn.ctrl_type_name
and		mst.base_ctrl_type	= extn.base_ctrl_type)
begin  
	Raiserror ('Report required attribute is mandatory to perform Server side print.',16,1)  
	return  
end 
-- code added for Defect ID : TECH-18349 ends

if exists(Select 'x'  
from	es_comp_ctrl_type_mst mst (nolock),
		es_comp_ctrl_type_mst_extn extn (nolock)
where	mst.customer_name	= @engg_customer_name  
and		mst.project_name	= @engg_project_name  
and		mst.process_name	= @engg_process_name  
and		mst.component_name	= @engg_comp_name  
and		mst.ctrl_type_name	= @engg_ctrlcmb_type  
and		mst.base_ctrl_type	in  ('Button', 'Link', 'Datahyperlink')
and     DirectPrint		= 'Y' 
and		(report_req		= 'N'
or      report_req  is null)
and		mst.customer_name	= extn.customer_name  
and		mst.project_name	= extn.project_name  
and		mst.process_name	= extn.process_name
and		mst.component_name	= extn.component_name
and		mst.ctrl_type_name	= extn.ctrl_type_name
and		mst.base_ctrl_type	= extn.base_ctrl_type)
begin  
	Raiserror ('Direct Print attribute is applicable only for Report required option.',16,1)  
	return  
end 

if exists(Select 'x'  
from	es_comp_ctrl_type_mst mst (nolock),
		es_comp_ctrl_type_mst_extn extn (nolock)
where	mst.customer_name	= @engg_customer_name  
and		mst.project_name	= @engg_project_name  
and		mst.process_name	= @engg_process_name  
and		mst.component_name	= @engg_comp_name  
and		mst.ctrl_type_name	= @engg_ctrlcmb_type  
and		mst.base_ctrl_type	= 'TreeGrid'
and     ISNULL(IsOrgChart, 'N')	= 'Y' 
and		ISNULL(GanttControl,'N')	= 'Y'
and		mst.customer_name	= extn.customer_name  
and		mst.project_name	= extn.project_name  
and		mst.process_name	= extn.process_name
and		mst.component_name	= extn.component_name
and		mst.ctrl_type_name	= extn.ctrl_type_name
and		mst.base_ctrl_type	= extn.base_ctrl_type)
begin  
	Raiserror ('Please select either ''Is Organization chart'' OR ''Gantt Control''.',16,1)  
	return  
end 

if exists(Select 'x'  
from	es_comp_ctrl_type_mst mst (nolock),
		es_comp_ctrl_type_mst_extn extn (nolock)
where	mst.customer_name	= @engg_customer_name  
and		mst.project_name	= @engg_project_name  
and		mst.process_name	= @engg_process_name  
and		mst.component_name	= @engg_comp_name  
and		mst.ctrl_type_name	= @engg_ctrlcmb_type  
and		mst.base_ctrl_type	= 'Grid'
and     ISNULL(ListItemExpander, 'N')	= 'Y' 
and		ISNULL(IsList,'N')	= 'N'
and		mst.customer_name	= extn.customer_name  
and		mst.project_name	= extn.project_name  
and		mst.process_name	= extn.process_name
and		mst.component_name	= extn.component_name
and		mst.ctrl_type_name	= extn.ctrl_type_name
and		mst.base_ctrl_type	= extn.base_ctrl_type)
begin  
	Raiserror ('''List Item Expander'' attribute is applicable only when IsList option is enabled for base control type ''Grid''.',16,1)  
	return  
end 

if exists(Select 'x'  
from	es_comp_ctrl_type_mst mst (nolock),
		es_comp_ctrl_type_mst_extn extn (nolock)
where	mst.customer_name	= @engg_customer_name  
and		mst.project_name	= @engg_project_name  
and		mst.process_name	= @engg_process_name  
and		mst.component_name	= @engg_comp_name  
and		mst.ctrl_type_name	= @engg_ctrlcmb_type  
and		mst.base_ctrl_type	= 'Grid'
and		extn.IsChips			= 'Y'
and     ISNULL(mst.RenderAs,'')	<> 'Tag' 
and		mst.customer_name	= extn.customer_name  
and		mst.project_name	= extn.project_name  
and		mst.process_name	= extn.process_name
and		mst.component_name	= extn.component_name
and		mst.ctrl_type_name	= extn.ctrl_type_name
and		mst.base_ctrl_type	= extn.base_ctrl_type)
begin  

	Raiserror ('''Is Chips'' attribute is applicable only for Tag control.',16,1)  
	return  
end 
ELSE
BEGIN
	UPDATE mst SET mst.RenderAs	= 'Chips'
	FROM es_comp_ctrl_type_mst mst (nolock),
		es_comp_ctrl_type_mst_extn extn (nolock)
	where	mst.customer_name	= @engg_customer_name  
	and		mst.project_name	= @engg_project_name  
	and		mst.process_name	= @engg_process_name  
	and		mst.component_name	= @engg_comp_name  
	and		mst.ctrl_type_name	= @engg_ctrlcmb_type  
	and		mst.base_ctrl_type	= 'Grid'
	and		extn.IsChips			= 'Y'
	and     ISNULL(mst.RenderAs,'')	= 'Tag' 
	and		mst.customer_name	= extn.customer_name  
	and		mst.project_name	= extn.project_name  
	and		mst.process_name	= extn.process_name
	and		mst.component_name	= extn.component_name
	and		mst.ctrl_type_name	= extn.ctrl_type_name
	and		mst.base_ctrl_type	= extn.base_ctrl_type
END

	/** Defaulting Label width, Control width, Form width for Grid to form if it is null. 
		Code added for the Defect id: TECH-20461 starts.
	*/
	if exists (select 'x'
	from	es_comp_ctrl_type_mst (nolock)
	where	customer_name	= @engg_customer_name
	and		project_name	= @engg_project_name
	and		process_name	= @engg_process_name
	and		component_name	= @engg_comp_name
	and		ctrl_type_name	= @engg_ctrlcmb_type
	and		base_ctrl_type	= 'Grid'
	and		RenderAs		= 'GridtoForm')
	begin
		Update	es_comp_ctrl_type_mst_extn set FormWidth = '40%'
		where	customer_name		 = @engg_customer_name
		and		project_name		 = @engg_project_name
		and		process_name		 = @engg_process_name
		and		component_name		 = @engg_comp_name
		and		ctrl_type_name		 = @engg_ctrlcmb_type
		and		base_ctrl_type		 = 'Grid'
		and		isnull(FormWidth,'') = ''	

		Update	es_comp_ctrl_type_mst_extn set ControlWidth = '100%'
		where	customer_name			= @engg_customer_name
		and		project_name			= @engg_project_name
		and		process_name			= @engg_process_name
		and		component_name			= @engg_comp_name
		and		ctrl_type_name			= @engg_ctrlcmb_type
		and		base_ctrl_type			= 'Grid'
		and		isnull(ControlWidth,'') = ''	

		Update	es_comp_ctrl_type_mst_extn set LabelWidth = '100%'
		where	customer_name			= @engg_customer_name
		and		project_name			= @engg_project_name
		and		process_name			= @engg_process_name
		and		component_name			= @engg_comp_name
		and		ctrl_type_name			= @engg_ctrlcmb_type
		and		base_ctrl_type			= 'Grid'
		and		isnull(LabelWidth,'')	= ''
	end
/** Code added for the Defect id: TECH-20461 ends. */

	IF EXISTS(	SELECT 'x'  
				FROM	es_comp_ctrl_type_mst mst WITH(NOLOCK)
				INNER JOIN es_comp_ctrl_type_mst_extn extn WITH(NOLOCK)
				ON		mst.customer_name    = extn.customer_name  
				AND     mst.project_name     = extn.project_name  
				AND     mst.process_name     = extn.process_name
				AND     mst.component_name   = extn.component_name
				AND     mst.ctrl_type_name   = extn.ctrl_type_name
				AND     mst.base_ctrl_type   = extn.base_ctrl_type
				WHERE	extn.customer_name   = @engg_customer_name  
				AND     extn.project_name    = @engg_project_name  
				AND     extn.process_name    = @engg_process_name  
				AND     extn.component_name  = @engg_comp_name  
				AND     extn.ctrl_type_name  = @engg_ctrlcmb_type  
				AND     extn.base_ctrl_type  = 'EDIT'
				AND		(ISNULL(extn.Setfocusevent, 'N') = 'Y' )
			)
	BEGIN  
		
		IF NOT EXISTS(	SELECT 'x'  
				FROM	es_comp_ctrl_type_mst mst WITH(NOLOCK)
				INNER JOIN es_comp_ctrl_type_mst_extn extn WITH(NOLOCK)
				ON		mst.customer_name    = extn.customer_name  
				AND     mst.project_name     = extn.project_name  
				AND     mst.process_name     = extn.process_name
				AND     mst.component_name   = extn.component_name
				AND     mst.ctrl_type_name   = extn.ctrl_type_name
				AND     mst.base_ctrl_type   = extn.base_ctrl_type
				WHERE	extn.customer_name   = @engg_customer_name  
				AND     extn.project_name    = @engg_project_name  
				AND     extn.process_name    = @engg_process_name  
				AND     extn.component_name  = @engg_comp_name  
				AND     extn.ctrl_type_name  = @engg_ctrlcmb_type  
				AND     extn.base_ctrl_type  = 'EDIT'
				AND		ISNULL(SetFocusEventOccurence,'') IN ( 'First time', 'Every time')
				)
			BEGIN

			RAISERROR ('Provide the value for ''Set Focus Event Occurence'' if Set Focus Event is enabled.',16,1)  
			RETURN  
			END
	END 

	IF EXISTS(	SELECT 'x'  
				FROM	es_comp_ctrl_type_mst mst WITH(NOLOCK)
				INNER JOIN es_comp_ctrl_type_mst_extn extn WITH(NOLOCK)
				ON		mst.customer_name    = extn.customer_name  
				AND     mst.project_name     = extn.project_name  
				AND     mst.process_name     = extn.process_name
				AND     mst.component_name   = extn.component_name
				AND     mst.ctrl_type_name   = extn.ctrl_type_name
				AND     mst.base_ctrl_type   = extn.base_ctrl_type
				WHERE	extn.customer_name   = @engg_customer_name  
				AND     extn.project_name    = @engg_project_name  
				AND     extn.process_name    = @engg_process_name  
				AND     extn.component_name  = @engg_comp_name  
				AND     extn.ctrl_type_name  = @engg_ctrlcmb_type  
				AND     extn.base_ctrl_type  = 'EDIT'
				AND		(ISNULL(extn.Leavefocusevent, 'N') = 'Y' )
			)
	BEGIN  
		
		IF NOT EXISTS(	SELECT 'x'  
				FROM	es_comp_ctrl_type_mst mst WITH(NOLOCK)
				INNER JOIN es_comp_ctrl_type_mst_extn extn WITH(NOLOCK)
				ON		mst.customer_name    = extn.customer_name  
				AND     mst.project_name     = extn.project_name  
				AND     mst.process_name     = extn.process_name
				AND     mst.component_name   = extn.component_name
				AND     mst.ctrl_type_name   = extn.ctrl_type_name
				AND     mst.base_ctrl_type   = extn.base_ctrl_type
				WHERE	extn.customer_name   = @engg_customer_name  
				AND     extn.project_name    = @engg_project_name  
				AND     extn.process_name    = @engg_process_name  
				AND     extn.component_name  = @engg_comp_name  
				AND     extn.ctrl_type_name  = @engg_ctrlcmb_type  
				AND     extn.base_ctrl_type  = 'EDIT'
				AND		ISNULL(LeaveFocusEventOccurence,'') IN ( 'First time', 'Every time')
				)
			BEGIN

			RAISERROR ('Provide the value for ''Leave Focus Event Occurence'' if Leave Focus Event is enabled.',16,1)  
			RETURN  
			END
	END 

	IF EXISTS(	SELECT 'x'  
				FROM	es_comp_ctrl_type_mst mst WITH(NOLOCK)
				INNER JOIN es_comp_ctrl_type_mst_extn extn WITH(NOLOCK)
				ON		mst.customer_name    = extn.customer_name  
				AND     mst.project_name     = extn.project_name  
				AND     mst.process_name     = extn.process_name
				AND     mst.component_name   = extn.component_name
				AND     mst.ctrl_type_name   = extn.ctrl_type_name
				AND     mst.base_ctrl_type   = extn.base_ctrl_type
				WHERE	extn.customer_name   = @engg_customer_name  
				AND     extn.project_name    = @engg_project_name  
				AND     extn.process_name    = @engg_process_name  
				AND     extn.component_name  = @engg_comp_name  
				AND     extn.ctrl_type_name  = @engg_ctrlcmb_type  
				AND     extn.base_ctrl_type  = 'EDIT'
				AND     ISNULL(extn.LeaveFocusEventOccurence,'') IN ('First time', 'Every time')
			)
	BEGIN  
		IF NOT EXISTS(	SELECT 'x'  
				FROM	es_comp_ctrl_type_mst mst WITH(NOLOCK)
				INNER JOIN es_comp_ctrl_type_mst_extn extn WITH(NOLOCK)
				ON		mst.customer_name    = extn.customer_name  
				AND     mst.project_name     = extn.project_name  
				AND     mst.process_name     = extn.process_name
				AND     mst.component_name   = extn.component_name
				AND     mst.ctrl_type_name   = extn.ctrl_type_name
				AND     mst.base_ctrl_type   = extn.base_ctrl_type
				WHERE	extn.customer_name   = @engg_customer_name  
				AND     extn.project_name    = @engg_project_name  
				AND     extn.process_name    = @engg_process_name  
				AND     extn.component_name  = @engg_comp_name  
				AND     extn.ctrl_type_name  = @engg_ctrlcmb_type  
				AND     extn.base_ctrl_type  = 'EDIT'
				AND     ISNULL(extn.Leavefocusevent,'') = 'Y'
			)
		
		BEGIN
			RAISERROR ('Leave focus event occurence is applicable only for ''Leave Focus Event''.',16,1)  
			RETURN  
	   END
	END 

	IF EXISTS(	SELECT 'x'  
				FROM	es_comp_ctrl_type_mst mst WITH(NOLOCK)
				INNER JOIN es_comp_ctrl_type_mst_extn extn WITH(NOLOCK)
				ON		mst.customer_name    = extn.customer_name  
				AND     mst.project_name     = extn.project_name  
				AND     mst.process_name     = extn.process_name
				AND     mst.component_name   = extn.component_name
				AND     mst.ctrl_type_name   = extn.ctrl_type_name
				AND     mst.base_ctrl_type   = extn.base_ctrl_type
				WHERE	extn.customer_name   = @engg_customer_name  
				AND     extn.project_name    = @engg_project_name  
				AND     extn.process_name    = @engg_process_name  
				AND     extn.component_name  = @engg_comp_name  
				AND     extn.ctrl_type_name  = @engg_ctrlcmb_type  
				AND     extn.base_ctrl_type  = 'EDIT'
				AND     ISNULL(extn.SetFocusEventOccurence,'') IN ('First time', 'Every time')
			)
	BEGIN  
		IF NOT EXISTS(	SELECT 'x'  
				FROM	es_comp_ctrl_type_mst mst WITH(NOLOCK)
				INNER JOIN es_comp_ctrl_type_mst_extn extn WITH(NOLOCK)
				ON		mst.customer_name    = extn.customer_name  
				AND     mst.project_name     = extn.project_name  
				AND     mst.process_name     = extn.process_name
				AND     mst.component_name   = extn.component_name
				AND     mst.ctrl_type_name   = extn.ctrl_type_name
				AND     mst.base_ctrl_type   = extn.base_ctrl_type
				WHERE	extn.customer_name   = @engg_customer_name  
				AND     extn.project_name    = @engg_project_name  
				AND     extn.process_name    = @engg_process_name  
				AND     extn.component_name  = @engg_comp_name  
				AND     extn.ctrl_type_name  = @engg_ctrlcmb_type  
				AND     extn.base_ctrl_type  = 'EDIT'
				AND     ISNULL(extn.setfocusevent,'') = 'Y'
			)
		
		BEGIN
			RAISERROR ('Set focus event occurence is applicable only for ''Set Focus Event''.',16,1)  
			RETURN  
	   END
	END 


	--Code Added for TECH-73996 starts 

	IF EXISTS(	SELECT 'x'  
				FROM	es_comp_ctrl_type_mst mst WITH(NOLOCK)
				INNER JOIN es_comp_ctrl_type_mst_extn extn WITH(NOLOCK)
				ON		mst.customer_name    = extn.customer_name  
				AND     mst.project_name     = extn.project_name  
				AND     mst.process_name     = extn.process_name
				AND     mst.component_name   = extn.component_name
				AND     mst.ctrl_type_name   = extn.ctrl_type_name
				AND     mst.base_ctrl_type   = extn.base_ctrl_type
				WHERE	extn.customer_name   = @engg_customer_name  
				AND     extn.project_name    = @engg_project_name  
				AND     extn.process_name    = @engg_process_name  
				AND     extn.component_name  = @engg_comp_name  
				AND     extn.ctrl_type_name  = @engg_ctrlcmb_type  
				AND		extn.base_ctrl_type = 'Edit'
				AND		isnull(EyeIconForPassword,'') = 'Y'
				AND		isnull(password_char,'') = 'N' )
			BEGIN
				RAISERROR ('''Password Char'' Attribute should be selected for Eye Icon For Password.',16,1)
				RETURN
			END

			IF EXISTS(	SELECT 'x'  
				FROM	es_comp_ctrl_type_mst mst WITH(NOLOCK)
				INNER JOIN es_comp_ctrl_type_mst_extn extn WITH(NOLOCK)
				ON		mst.customer_name    = extn.customer_name  
				AND     mst.project_name     = extn.project_name  
				AND     mst.process_name     = extn.process_name
				AND     mst.component_name   = extn.component_name
				AND     mst.ctrl_type_name   = extn.ctrl_type_name
				AND     mst.base_ctrl_type   = extn.base_ctrl_type
				WHERE	extn.customer_name   = @engg_customer_name  
				AND     extn.project_name    = @engg_project_name  
				AND     extn.process_name    = @engg_process_name  
				AND     extn.component_name  = @engg_comp_name  
				AND     extn.ctrl_type_name  = @engg_ctrlcmb_type  
				AND		extn.base_ctrl_type = 'Edit'
				AND		isnull(Signature,'') = 'Y'
				AND		isnull(editable_flag,'') = 'N' )
			BEGIN
				RAISERROR ('''Editable'' Attribute should be selected for Signature.',16,1)
				RETURN
			END
			
		IF EXISTS(	SELECT 'x'  
				FROM	es_comp_ctrl_type_mst mst WITH(NOLOCK)
				INNER JOIN es_comp_ctrl_type_mst_extn extn WITH(NOLOCK)
				ON		mst.customer_name    = extn.customer_name  
				AND     mst.project_name     = extn.project_name  
				AND     mst.process_name     = extn.process_name
				AND     mst.component_name   = extn.component_name
				AND     mst.ctrl_type_name   = extn.ctrl_type_name
				AND     mst.base_ctrl_type   = extn.base_ctrl_type
				WHERE	extn.customer_name   = @engg_customer_name  
				AND     extn.project_name    = @engg_project_name  
				AND     extn.process_name    = @engg_process_name  
				AND     extn.component_name  = @engg_comp_name  
				AND     extn.ctrl_type_name  = @engg_ctrlcmb_type  
				AND		extn.base_ctrl_type = 'Edit'
				AND		ISNULL(Stepper,NULL) = 'Y'
				AND		isnull(Minvalue,'') = '' )
			BEGIN
				RAISERROR ('Please Enter the Value for Minimum value.',16,1)
				RETURN
			END
			IF EXISTS(	SELECT 'x'  
				FROM	es_comp_ctrl_type_mst mst WITH(NOLOCK)
				INNER JOIN es_comp_ctrl_type_mst_extn extn WITH(NOLOCK)
				ON		mst.customer_name    = extn.customer_name  
				AND     mst.project_name     = extn.project_name  
				AND     mst.process_name     = extn.process_name
				AND     mst.component_name   = extn.component_name
				AND     mst.ctrl_type_name   = extn.ctrl_type_name
				AND     mst.base_ctrl_type   = extn.base_ctrl_type
				WHERE	extn.customer_name   = @engg_customer_name  
				AND     extn.project_name    = @engg_project_name  
				AND     extn.process_name    = @engg_process_name  
				AND     extn.component_name  = @engg_comp_name  
				AND     extn.ctrl_type_name  = @engg_ctrlcmb_type  
				AND		extn.base_ctrl_type = 'Edit'
				AND		ISNULL(Stepper,NULL) = 'Y'
				AND		isnull(Maxvalue,'') = '' )
			BEGIN
				RAISERROR ('Please Enter the Value for Maximum value.',16,1)
				RETURN
			END
			IF EXISTS(	SELECT 'x'  
				FROM	es_comp_ctrl_type_mst mst WITH(NOLOCK)
				INNER JOIN es_comp_ctrl_type_mst_extn extn WITH(NOLOCK)
				ON		mst.customer_name    = extn.customer_name  
				AND     mst.project_name     = extn.project_name  
				AND     mst.process_name     = extn.process_name
				AND     mst.component_name   = extn.component_name
				AND     mst.ctrl_type_name   = extn.ctrl_type_name
				AND     mst.base_ctrl_type   = extn.base_ctrl_type
				WHERE	extn.customer_name   = @engg_customer_name  
				AND     extn.project_name    = @engg_project_name  
				AND     extn.process_name    = @engg_process_name  
				AND     extn.component_name  = @engg_comp_name  
				AND     extn.ctrl_type_name  = @engg_ctrlcmb_type  
				AND		extn.base_ctrl_type = 'Edit'
				AND		ISNULL(Stepper,NULL) = 'Y'
				AND		isnull(Stepvalue,'') = '' )
			BEGIN
				RAISERROR ('Please Enter the Value for Step value.',16,1)
				RETURN
			END


			IF EXISTS(	SELECT 'x'  
				FROM	es_comp_ctrl_type_mst mst WITH(NOLOCK)
				INNER JOIN es_comp_ctrl_type_mst_extn extn WITH(NOLOCK)
				ON		mst.customer_name    = extn.customer_name  
				AND     mst.project_name     = extn.project_name  
				AND     mst.process_name     = extn.process_name
				AND     mst.component_name   = extn.component_name
				AND     mst.ctrl_type_name   = extn.ctrl_type_name
				AND     mst.base_ctrl_type   = extn.base_ctrl_type
				WHERE	extn.customer_name   = @engg_customer_name  
				AND     extn.project_name    = @engg_project_name  
				AND     extn.process_name    = @engg_process_name  
				AND     extn.component_name  = @engg_comp_name  
				AND     extn.ctrl_type_name  = @engg_ctrlcmb_type  
				AND		extn.base_ctrl_type = 'Edit'
				AND		isnull(ClearTask,'') = 'Y'
				AND		isnull(editable_flag,'') = 'N' )
			BEGIN
				RAISERROR ('''Editable'' Attribute should be selected for Clear Task.',16,1)
				RETURN
			END

			IF EXISTS(	SELECT 'x'  
				FROM	es_comp_ctrl_type_mst mst WITH(NOLOCK)
				INNER JOIN es_comp_ctrl_type_mst_extn extn WITH(NOLOCK)
				ON		mst.customer_name    = extn.customer_name  
				AND     mst.project_name     = extn.project_name  
				AND     mst.process_name     = extn.process_name
				AND     mst.component_name   = extn.component_name
				AND     mst.ctrl_type_name   = extn.ctrl_type_name
				AND     mst.base_ctrl_type   = extn.base_ctrl_type
				WHERE	extn.customer_name   = @engg_customer_name  
				AND     extn.project_name    = @engg_project_name  
				AND     extn.process_name    = @engg_process_name  
				AND     extn.component_name  = @engg_comp_name  
				AND     extn.ctrl_type_name  = @engg_ctrlcmb_type  
				AND		extn.base_ctrl_type = 'Grid'
				AND		isnull(extn.ShowAnimation,'') = 'Y'
				AND		isnull(mst.Datagrid, 'N') = 'N' )	
			BEGIN
				RAISERROR ('''Data Grid'' Attribute should be selected for Show Animation.',16,1)
				RETURN
			END

			IF EXISTS(	SELECT 'x'  
				FROM	es_comp_ctrl_type_mst mst WITH(NOLOCK)
				INNER JOIN es_comp_ctrl_type_mst_extn extn WITH(NOLOCK)
				ON		mst.customer_name    = extn.customer_name  
				AND     mst.project_name     = extn.project_name  
				AND     mst.process_name     = extn.process_name
				AND     mst.component_name   = extn.component_name
				AND     mst.ctrl_type_name   = extn.ctrl_type_name
				AND     mst.base_ctrl_type   = extn.base_ctrl_type
				WHERE	extn.customer_name   = @engg_customer_name  
				AND     extn.project_name    = @engg_project_name  
				AND     extn.process_name    = @engg_process_name  
				AND     extn.component_name  = @engg_comp_name  
				AND     extn.ctrl_type_name  = @engg_ctrlcmb_type  
				AND		extn.base_ctrl_type = 'Button'
				AND		isnull(PreviousCount,0) <> 0
				AND		isnull(ButtonPrevious_Req,'N') = 'N' )
			BEGIN
				RAISERROR ('Previous Count is applicable only for the ''Previous Button'' attribute is selected.',16,1)
				RETURN
			END



	--Code Added for TECH-73996 ends

	--TECH-75230
	IF EXISTS(SELECT 'x'
	FROM	es_comp_ctrl_type_mst mst WITH(NOLOCK)
	INNER JOIN es_comp_ctrl_type_mst_extn extn WITH(NOLOCK)
	ON		mst.customer_name    = extn.customer_name  
	AND     mst.project_name     = extn.project_name  
	AND     mst.process_name     = extn.process_name
	AND     mst.component_name   = extn.component_name
	AND     mst.ctrl_type_name   = extn.ctrl_type_name
	AND     mst.base_ctrl_type   = extn.base_ctrl_type
	WHERE	extn.customer_name				= @engg_customer_name  
	AND		extn.project_name				= @engg_project_name  
	AND		extn.process_name				= @engg_process_name  
	AND		extn.component_name				= @engg_comp_name  
	AND		extn.ctrl_type_name				= @engg_ctrlcmb_type 
	AND		extn.base_ctrl_type			= 'Edit'
	AND		(isnull(pretask,'')			=	'Y'
	OR		isnull(posttask,'')			=	'Y')
	AND		isnull(attach_document,'')	= ''
	AND		isnull(relative_document_path,'') = ''	
	AND		isnull(relative_image_path,'') = '')  	
	BEGIN
		RAISERROR('Attachment Document must be selected for PreTask, PostTask and Bulk Download.',16,1)
		RETURN
	END
	--TECH-75230


Select  @engg_1_fprowno   'engg_1_fprowno',
		@engg_l_fprowno   'engg_l_fprowno'

Set nocount off
End



GO
IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME= 'ep_main13Spengg_vHdrChk' AND TYPE='P')
BEGIN
	GRANT EXEC ON  ep_main13Spengg_vHdrChk TO PUBLIC
END
GO 
