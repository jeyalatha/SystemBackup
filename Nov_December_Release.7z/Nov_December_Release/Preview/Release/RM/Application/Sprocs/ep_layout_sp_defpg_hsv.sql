IF EXISTS(SELECT 'X' From SYSOBJECTS WHERE NAME ='ep_layout_sp_defpg_hsv' AND TYPE='P')
   BEGIN
        DROP PROC ep_layout_sp_defpg_hsv
   END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		ep_layout_sp_defpg_hsv.sql
********************************************************************************/
/*      V E R S I O N      :  2.0.2    */
/*      Released By        :  PTech    */
/*      Release Comments   :  Released on  22-Jan-2004    */
/********************************************************************************/
/* procedure      ep_layout_sp_defpg_hsv                                        */
/* description                                                                  */
/********************************************************************************/
/* project        Preview                                                       */
/* version                                                                      */
/********************************************************************************/
/* referenced                                                                   */
/* tables                                                                       */
/********************************************************************************/
/* development history                                                          */
/********************************************************************************/
/* author         Shafina Begum.B                                               */
/* date           28/ 11/ 2003                                                  */
/********************************************************************************/
/* modification history                                                         */
/********************************************************************************/
/* modified by  : B.Shafina Begum                                               */
/* date         : 04-feb-2004                                                 */
/* description  : To check for ui's req_status            */
/* modified by  : ARUNN                                                   */
/* date         : 29-Jun-2005                                                 */
/* bugid  : PNR2.0_3088             */
/* bug desc  : On Clicking 'Default from reference UI', getting an error message */
/*      Cannot insert the value NULL into column 'tab_height',        */
/*                table 'rvw20appdb.dbo.ep_ui_mst'; column does not allow nulls.*/
/*      UPDATE fails.             */
/********************************************************************************/
/********************************************************************************/
/* modified by  : C Lavanya                                         */
/* date         : 21-oct-2005                                                */
/* description  : Htm Problem in Specify tree layout , Sp changed for default From Reference UI  in specify Layout.
for fixnote : _DM_FN_124        */
/********************************************************************************/
/* modified by   : Chanheetha N A        */
/* date     : 17-nov-2007         */
/* BugId    : PNR2.0_16023          */
/************************************************************************/
/* modified by   : Jeya Latha K         */
/* date     : 12-Jan-2009         */
/* BugId    : PNR2.0_20601         */
/************************************************************************/
/* Modified by   : Kanagavel A 	                                                  */
/* Date         	: 21-10-2016                                                 */
/* Description	: changes for new column addition                                   */
/************************************************************************************/
/* Modified by : Jeya Latha K/Ganesh Prabhu S	for callid TECH-7349				*/
/* Modified on : 14-03-2017				 											*/
/* Description :  New Base Control types RSAssorted, RSPivotGrid, 
				  RSTreeGrid and New Feature Organization chart						*/
/************************************************************************************/
/* Modified by	:	Priyadharshini U 												*/
/* Modified on	:	08/07/2022				 										*/
/* Defect ID	:	Tech-70687														*/
/* Description	:	Tool and Toolbars												*/
/************************************************************************************/
/* Modified by					:	Ponmalar A										*/
/* Modified on					:	23-Aug-2022				 						*/
/* Defect ID					:	TECH-72114										*/
/* Description					:	Platform Modeling for Section Title Icon		*/
/************************************************************************************/
/* Modified by		:	Ponmalar A 													*/
/* Modified on		:	02/11/22				 									*/
/* Defect ID		:	TECH-75230													*/
/* Description		:	Platform Release for the Month of Nov'22					*/
/************************************************************************************/
CREATE PROCEDURE ep_layout_sp_defpg_hsv
	@ctxt_language_in engg_ctxt_language,
	@ctxt_ouinstance_in engg_ctxt_ouinstance,
	@ctxt_service_in engg_ctxt_service,
	@ctxt_user_in engg_ctxt_user,
	@engg_act_descr_in engg_description,
	@engg_component_in engg_description,
	@engg_customer_name_in engg_name,
	@engg_process_descr_in engg_description,
	@engg_project_name_in engg_name,
	@engg_req_no_in engg_name,
	@engg_rf_act_in engg_description,
	@engg_rf_comp_in engg_description,
	@engg_rf_ui_in engg_description,
	@engg_ui_descr_in engg_description,
	@guid_in engg_guid,
	@m_errorid INT OUTPUT
AS
BEGIN
	SET NOCOUNT ON

	--declaration of temporary variables
	DECLARE @ctxt_language engg_ctxt_language
	DECLARE @ctxt_ouinstance engg_ctxt_ouinstance
	DECLARE @ctxt_service engg_ctxt_service
	DECLARE @ctxt_user engg_ctxt_user
	DECLARE @engg_act_descr engg_description
	DECLARE @engg_component engg_description
	DECLARE @engg_customer_name engg_name
	DECLARE @engg_process_descr engg_description
	DECLARE @engg_project_name engg_name
	DECLARE @engg_req_no engg_name
	DECLARE @engg_rf_act engg_description
	DECLARE @engg_rf_comp engg_description
	DECLARE @engg_rf_ui engg_description
	DECLARE @engg_ui_descr engg_description
	DECLARE @guid engg_guid

	--temporary and formal parameters mapping
	SELECT @ctxt_language = @ctxt_language_in

	SELECT @ctxt_ouinstance = @ctxt_ouinstance_in

	SELECT @ctxt_service = ltrim(rtrim(@ctxt_service_in))

	SELECT @ctxt_user = ltrim(rtrim(@ctxt_user_in))

	SELECT @engg_act_descr = ltrim(rtrim(@engg_act_descr_in))

	SELECT @engg_component = ltrim(rtrim(@engg_component_in))

	SELECT @engg_customer_name = ltrim(rtrim(@engg_customer_name_in))

	SELECT @engg_process_descr = ltrim(rtrim(@engg_process_descr_in))

	SELECT @engg_project_name = ltrim(rtrim(@engg_project_name_in))

	SELECT @engg_req_no = ltrim(rtrim(@engg_req_no_in))

	SELECT @engg_rf_act = ltrim(rtrim(@engg_rf_act_in))

	SELECT @engg_rf_comp = ltrim(rtrim(@engg_rf_comp_in))

	SELECT @engg_rf_ui = ltrim(rtrim(@engg_rf_ui_in))

	SELECT @engg_ui_descr = ltrim(rtrim(@engg_ui_descr_in))

	SELECT @guid = ltrim(rtrim(@guid_in))

	--null checking
	IF @ctxt_language = - 915
		SELECT @ctxt_language = NULL

	IF @ctxt_ouinstance = - 915
		SELECT @ctxt_ouinstance = NULL

	IF @ctxt_service = '~#~'
		SELECT @ctxt_service = NULL

	IF @ctxt_user = '~#~'
		SELECT @ctxt_user = NULL

	IF @engg_act_descr = '~#~'
		SELECT @engg_act_descr = NULL

	IF @engg_component = '~#~'
		SELECT @engg_component = NULL

	IF @engg_customer_name = '~#~'
		SELECT @engg_customer_name = NULL

	IF @engg_process_descr = '~#~'
		SELECT @engg_process_descr = NULL

	IF @engg_project_name = '~#~'
		SELECT @engg_project_name = NULL

	IF @engg_req_no = '~#~'
		SELECT @engg_req_no = NULL

	IF @engg_rf_act = '~#~'
		SELECT @engg_rf_act = NULL

	IF @engg_rf_comp = '~#~'
		SELECT @engg_rf_comp = NULL

	IF @engg_rf_ui = '~#~'
		SELECT @engg_rf_ui = NULL

	IF @engg_ui_descr = '~#~'
		SELECT @engg_ui_descr = NULL

	IF @guid = '~#~'
		SELECT @guid = NULL

	--errors mapped
	--output parameters
	DECLARE @page_name engg_name,
		@page_doc engg_documentation,
		@horder engg_seqno,
		@vorder engg_seqno,
		@maxhorder engg_seqno,
		@rowcount engg_seqno,
		@page_type engg_name
	DECLARE @iudmodeflag VARCHAR(2),
		@tmp_processname engg_name,
		@tmp_componentname engg_name,
		@tmp_activity engg_name,
		@tmp_ui engg_name,
		@tmp_ref_componentname engg_name,
		@tmp_ref_activity engg_name,
		@tmp_ref_ui engg_name,
		@msg engg_documentation,
		@engg_base_req_no engg_name,
		@page_prefix_tmp engg_name,
		@btLength engg_seqno,
		@page_bt_caption engg_description,
		/*fIXNOTE:_DM_FN_124*/
		@engg_sec_cap_format engg_flag,
		@sectionheight engg_seqno,
		@sectionwidth engg_seqno,
		@Section_width_Scalemode engg_name,
		@Section_height_Scalemode engg_name,
		@ENGG_SECTION_TYPE_IN engg_name,
		@engg_sec_cap_align engg_name

	/*fIXNOTE:_DM_FN_124*/
	SELECT @engg_base_req_no = 'BASE'

	--GETTING THE PROCESS NAME FOR DESCRIPTION
	SELECT @tmp_processname = process_name
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND req_no = @engg_req_no
		AND process_descr = @engg_process_descr

	--GETTING THE COMPONENT NAME FOR THE DESCRIPTION
	SELECT @tmp_componentname = component_name
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND req_no = @engg_req_no
		AND process_name = @tmp_processname
		AND component_descr = @engg_component

	--GETTING THE ACTIVITY NAME FOR THE DESCRIPTION
	SELECT @tmp_activity = activity_name
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND req_no = @engg_req_no
		AND process_name = @tmp_processname
		AND component_name = @tmp_componentname
		AND activity_descr = @engg_act_descr

	--GETTING THE UI NAME FOR THE DESCRIPTION
	SELECT @tmp_ui = ui_name
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND req_no = @engg_req_no
		AND process_name = @tmp_processname
		AND component_name = @tmp_componentname
		AND activity_name = @tmp_activity
		AND ui_descr = @engg_ui_descr

	IF EXISTS (
			SELECT 'x'
			FROM ep_ui_req_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_req_no
				AND process_name = @tmp_processname
				AND component_name = @tmp_componentname
				AND activity_name = @tmp_activity
				AND ui_name = @tmp_ui
				AND req_status = 'P'
			)
	BEGIN
		SELECT @msg = 'Cannot default as Selected UI is in published status'

		EXEC engg_error_sp 'ep_layout_sp_defpg_hsv',
			1,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		IF @m_errorid <> 0
			RETURN
	END

	--VALIDATIONS
	--Check whether activity is selected. If not display error message
	IF @engg_act_descr IS NULL
	BEGIN
		SELECT @msg = 'Select Activity'

		EXEC engg_error_sp 'ep_layout_sp_defpg_hsv',
			1,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		RETURN
	END

	--Check whether UI is selected. If not display error message
	IF @engg_ui_descr IS NULL
	BEGIN
		SELECT @msg = 'Select User Interface'

		EXEC engg_error_sp 'ep_layout_sp_defpg_hsv',
			2,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		RETURN
	END

	--select @engg_rf_ui = 'CreateCustomer'
	--Select @engg_rf_act = 'CreateCustomer'
	--For the selected activity/UI combination check whether refernce UI has been defined. If not, display error message
	IF @engg_rf_ui IS NULL
	BEGIN
		SELECT @msg = 'Reference UI does not exists for the selected UI.'

		EXEC engg_error_sp 'ep_layout_sp_defpg_hsv',
			3,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		RETURN
	END

	--GETTING THE REF COMPONENT NAME FOR THE DESCRIPTION
	SELECT @tmp_ref_componentname = component_name
	--  from  ep_ui_req_dtl (nolock)
	FROM Fw_BPT_RE_NameDesc_Vw(NOLOCK) -- Modified By Arunn for pnr2.0_3088
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		-- and req_no    = @engg_req_no
		-- code modified by shafina on 07-July-2004 for PREVIEWENG203SYS_000115
		-- When i click 'Default from Reference UI' task in Pages tab, Page details is not defaulted.
		-- and  process_name   = @tmp_processname
		AND component_descr = @engg_rf_comp

	--GETTING THE REF ACTIVITY NAME FOR THE DESCRIPTION
	SELECT @tmp_ref_activity = activity_name
	--  from  ep_ui_req_dtl (nolock)
	FROM Fw_BPT_RE_NameDesc_Vw(NOLOCK) -- Modified By Arunn for pnr2.0_3088
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		-- and req_no   = @engg_req_no
		-- and process_name  = @tmp_processname
		AND component_name = @tmp_ref_componentname
		AND activity_descr = @engg_rf_act

	--GETTING THE REF UI NAME FOR THE DESCRIPTION
	SELECT @tmp_ref_ui = ui_name
	--  from  ep_ui_req_dtl (nolock)
	FROM Fw_BPT_RE_NameDesc_Vw(NOLOCK) -- Modified By Arunn for pnr2.0_3088
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		-- and req_no   = @engg_req_no
		-- and process_name  = @tmp_processname
		AND component_name = @tmp_ref_componentname
		AND activity_name = @tmp_ref_activity
		AND ui_descr = @engg_rf_ui

	/*Check whether no pages exist for the normal ui.else display error*/
	IF (
			SELECT count('x')
			FROM ep_ui_page_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_base_req_no
				AND process_name = @tmp_processname
				AND component_name = @tmp_componentname
				AND activity_name = @tmp_activity
				AND ui_name = @tmp_ui
				AND page_bt_synonym <> '[mainscreen]'
			) = 0
	BEGIN
		SELECT @tmp_ui = rtrim(@tmp_ui)
	END
	ELSE
	BEGIN
		SELECT @msg = 'Default from Reference UI cannot be done as there are pages defined for this UI already'

		EXEC engg_error_sp 'ep_layout_sp_defpg_hsv',
			4,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		RETURN
	END

	/*
EXPANATION FOR THE FOLLOWING QUERY:

First Part [Query part before Union]:
-------------------------------------

Selecting all the page details for the selected customer, project, process, reference component,
reference activity and reference ui from the table ep_ui_page_dtl filtering the ui names
for which the page detail already saved
Inserting the above selected values in the ep_ui_page_dtl table for the selected customer,
project, process, component, activity and ui

Second Part [Query part after Union]:
-------------------------------------

Selecting all the page details for the selected customer, project, process, component,
activity and ui from the table ep_ui_page_dtl along with the BT Synonym caption for the
corresponding page_bt_synonym from the table ep_glossary_mst.
*/
	DECLARE @pageimage engg_name,
		@width engg_seqno,
		@HeaderPosition engg_code,
		@TabRotation engg_code,
		@TabTitleStyle engg_flag,
		@TabIconPosition engg_code,
		@PageLayout engg_flag,
		@XYCoordinates engg_description,
		@ColumnLayWidth engg_description,
		@Sec_CollapseMode engg_name,
		@Sec_Collapse engg_name,
		@section_rowspan engg_seqno,
		@section_colspan engg_seqno,
		@Region engg_flag,
		@TitlePosition engg_flag,
		@CollapseDir engg_flag,
		@SectionLayout engg_flag,
		@engg_associatedcontrol engg_name,
		--Tech-70687
		@engg_bottomtb		engg_seqno,
		@engg_toptb			engg_seqno,
		@engg_righttb		engg_seqno,	
		@engg_lefttb		engg_seqno,			
		@MinimizedRows		engg_seqno,
		@ViewMode			engg_name,
		--Tech-70687
		@engg_sec_titleicon	engg_name, --TECH-72114
		@Orientation	engg_name --TECH-75230

	DECLARE insert_cur INSENSITIVE CURSOR
	FOR
	SELECT a.page_bt_synonym,
		a.page_doc,
		a.horder,
		a.vorder,
		a.page_Type, -- Column added for the Bug ID : PNR2.0_20601
		pageimage,
		HeaderPosition,
		TabRotation,
		TabTitleStyle,
		TabIconPosition,
		PageLayout,
		XYCoordinates,
		ColumnLayWidth,
		--Code added for the Defect Id Tech-70687 starts 
		case when a.Lefttoolbar		=	'y' then 1 else 0 end	,
		case when a.Righttoolbar	=	'y' then 1 else 0 end	,
		case when a.TopToolbar		=	'y' then 1 else 0 end	,
		case when a.Bottomtoolbar	=	'y' then 1 else 0 end			
		--Code added for the Defect Id Tech-70687 ends
	FROM ep_ui_page_dtl a(NOLOCK)
	WHERE a.customer_name = @engg_customer_name
		AND a.project_name = @engg_project_name
		AND a.req_no = @engg_base_req_no
		--  and a.process_name  = @tmp_processname
		AND a.component_name = @tmp_ref_componentname
		AND a.activity_name = @tmp_ref_activity
		AND a.ui_name = @tmp_ref_ui
		AND a.horder <> 0
		AND a.vorder <> 0

	/*and  not exists( select 'A' from ep_ui_page_dtl c (nolock)
where a.customer_name  = c.customer_name
and  a.project_name  = c.project_name
and  a.req_no   =  c.req_no
and  a.process_name  = c.process_name
and  a.component_name = c.component_name
and  a.activity_name  = c.activity_name
and  a.ui_name   <> c.ui_name
and  a.page_bt_synonym = c.page_bt_synonym)*/
	OPEN insert_cur

	WHILE (1 = 1)
	BEGIN
		FETCH NEXT
		FROM insert_cur
		INTO @page_name,
			@page_doc,
			@horder,
			@vorder,
			@page_Type -- Column added for the Bug ID : PNR2.0_20601
			,
			@pageimage,
			@HeaderPosition,
			@TabRotation,
			@TabTitleStyle,
			@TabIconPosition,
			@PageLayout,
			@XYCoordinates,
			@ColumnLayWidth,
			--Tech-70687
			@engg_lefttb	,
			@engg_righttb	,
			@engg_toptb		,
			@engg_bottomtb			
			--Tech-70687

		IF @@fetch_status <> 0
			BREAK
		--code added by DNR for getting unique prefix ID on 30/12/2003
		EXEC engg_gen_prefix_id @engg_customer_name,
			@engg_project_name,
			@tmp_componentname,
			@tmp_activity,
			@tmp_ui,
			@page_name,
			'P',
			6,
			@page_prefix_tmp OUTPUT

		EXEC ep_ui_page_dtl_sp_ins @ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			@engg_customer_name,
			@engg_project_name,
			@engg_base_req_no,
			@tmp_processname,
			@tmp_componentname,
			@tmp_activity,
			@tmp_ui,
			@page_name,
			@horder,
			@vorder,
			@page_doc,
			@page_prefix_tmp,
			1,
			@engg_req_no, --chan
			@page_Type, -- Column added for the Bug ID : PNR2.0_20601
			@pageimage,
			@HeaderPosition,
			@TabRotation,
			@TabTitleStyle,
			@TabIconPosition,
			@PageLayout,
			@XYCoordinates,
			@ColumnLayWidth, ----Kanagavel 
			--Tech-70687
			@engg_lefttb	,	
			@engg_righttb	,
			@engg_toptb		,
			@engg_bottomtb	,		
			--Tech-70687
			@m_errorid OUTPUT
	
		IF @m_errorid <> 0
		BEGIN
			CLOSE insert_cur

			DEALLOCATE insert_cur

			RETURN
		END

		-- code modified by shafina on 09-June-2004 for PREVIEWENG203ACC_000070
		-- When controls/columns are defaulted form reference ui , corresponding glossary entry and task entry is not done.
		SELECT @btLength = 20

		IF NOT EXISTS (
				SELECT 'x'
				FROM ep_component_glossary_mst NOLOCK
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @tmp_processname
					AND component_name = @tmp_componentname
					AND bt_synonym_name = @page_name
				)
		BEGIN
			-- code modified by shafina on 14-June-2004 for PREVIEWENG203ACC_000070
			--    exec ep_generate_caption @page_name,@page_bt_caption out
			SELECT @page_bt_caption = bt_synonym_caption
			FROM ep_component_glossary_mst(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_base_req_no
				AND component_name = @tmp_ref_componentname
				AND bt_synonym_name = @page_name

			-- code modified by shafina on 17-June-2004 for PREVIEWENG203ACC_000073
			EXEC ep_component_glossary_mst_sp_ins @ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@engg_customer_name,
				@engg_project_name,
				'base',
				@tmp_processname,
				@tmp_componentname,
				@page_name,
				NULL,
				'Char',
				@btLength,
				@page_bt_caption,
				@page_name,
				'',
				'U',
				'',
				'',
				1,
				@engg_req_no, --chan
				@m_errorid OUTPUT

			IF @m_errorid <> 0
			BEGIN
				CLOSE insert_cur

				DEALLOCATE insert_cur

				RETURN
			END
		END

		/*fIXNOTE:_DM_FN_124*/
		--  end
		--  close  insert_cur
		--  deallocate insert_cur
		/*fIXNOTE:_DM_FN_124*/
		-- modified by shafina on 07-feb-2004 to insert a '[tabcontrol]' section for '[mainscreen]'
		IF EXISTS (
				SELECT 'x'
				FROM ep_ui_page_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @tmp_processname
					AND component_name = @tmp_componentname
					AND activity_name = @tmp_activity
					AND ui_name = @tmp_ui
					AND page_bt_synonym <> '[mainscreen]'
				)
		BEGIN
			IF NOT EXISTS (
					SELECT 'x'
					FROM ep_ui_section_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_base_req_no
						AND process_name = @tmp_processname
						AND component_name = @tmp_componentname
						AND activity_name = @tmp_activity
						AND ui_name = @tmp_ui
						AND page_bt_synonym = '[mainscreen]'
						AND section_bt_synonym = '[tabcontrol]'
					)
			BEGIN
				/*fIXNOTE:_DM_FN_124*/
				SELECT @ENGG_SECTION_TYPE_IN = section_type,
					@engg_sec_cap_align = ctrl_caption_align,
					@engg_sec_cap_format = caption_Format,
					@sectionheight = height,
					@sectionwidth = width,
					@Section_width_Scalemode = Section_width_Scalemode,
					@Section_height_Scalemode = Section_height_Scalemode,
					@Sec_CollapseMode = section_collapsemode,
					@Sec_Collapse = section_collapse,
					@section_rowspan = NRowSpan,
					@section_colspan = NColSpan,
					@Region = Region,
					@TitlePosition = TitlePosition,
					@CollapseDir = CollapseDir,
					@SectionLayout = SectionLayout,
					@XYCoordinates = XYCoordinates,
					@ColumnLayWidth = ColumnLayWidth,
					@engg_associatedcontrol = Associated_control,
					@Orientation		=	Orientation, --TECH-75230
					--Tech-70687
					@engg_bottomtb		=	case when BottomToolbar	= 'Y' then 1 else 0 end,
					@engg_toptb			=	case when TopToolbar	= 'Y' then 1 else 0 end	,	
					@engg_righttb		=	case when RightToolbar	= 'Y' then 1 else 0 end,	
					@engg_lefttb		=	case when LeftToolbar	= 'Y' then 1 else 0 end	,
					@MinimizedRows		=	MinimizedRows,
					@ViewMode			=	ViewMode,
					--Tech-70687
					@engg_sec_titleicon	=	TitleIcon		 --TECH-72114	
				FROM ep_ui_section_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					--   and process_name  =  @tmp_processname
					AND component_name = @tmp_ref_componentname
					AND activity_name = @tmp_ref_activity
					AND ui_name = @tmp_ref_ui
					AND page_bt_synonym = '[mainscreen]'
					AND section_bt_synonym = '[tabcontrol]'
				
				/*fIXNOTE:_DM_FN_124*/
				EXEC ep_ui_section_dtl_sp_ins
					-- code modified by shafina on 14-Apr-2004 for PREVIEWENG203ACC_000031
					/*fIXNOTE:_DM_FN_124*/ /* New Parameters were added */
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@engg_customer_name,
					@engg_project_name,
					@engg_base_req_no,
					@tmp_processname,
					@tmp_componentname,
					@tmp_activity,
					@tmp_ui,
					'[mainscreen]',
					'[tabcontrol]',
					'N',
					'N',
					'N',
					'Left',
					'',
					0,
					0,
					'[tabcontrol]',
					1,
					@ENGG_SECTION_TYPE_IN,
					@engg_sec_cap_align,
					@engg_sec_cap_format,
					@sectionheight,
					@sectionwidth,
					@Section_width_Scalemode,
					@Section_height_Scalemode,
					@Sec_CollapseMode,
					@Sec_Collapse,
					@engg_req_no,
					@section_rowspan,
					@section_colspan,
					@Region,
					@TitlePosition,
					@CollapseDir,
					@SectionLayout,
					@XYCoordinates,
					@ColumnLayWidth,
					@engg_associatedcontrol,
					'',
					'',
					'',
					@Orientation,	--TECH-75230
					--Tech-70687
					@engg_bottomtb	,
					@engg_toptb		,					
					@engg_righttb	,
					@engg_lefttb	,					
					@MinimizedRows	,
					@ViewMode		,	
					--Tech-70687
					@engg_sec_titleicon, --TECH-72114
					@m_errorid OUTPUT --chan

				IF @m_errorid <> 0
					/*fIXNOTE:_DM_FN_124*/
				BEGIN
					CLOSE insert_cur

					DEALLOCATE insert_cur

					RETURN
				END
						--    return
			END
		END
		ELSE
		BEGIN
			IF EXISTS (
					SELECT 'x'
					FROM ep_ui_section_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_base_req_no
						AND process_name = @tmp_processname
						AND component_name = @tmp_componentname
						AND activity_name = @tmp_activity
						AND ui_name = @tmp_ui
						AND page_bt_synonym = '[mainscreen]'
						AND section_bt_synonym = '[tabcontrol]'
					)
			BEGIN
				EXEC ep_ui_section_dtl_sp_del @ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@engg_customer_name,
					@engg_project_name,
					@engg_base_req_no,
					@tmp_processname,
					@tmp_componentname,
					@tmp_activity,
					@tmp_ui,
					'[mainscreen]',
					'[tabcontrol]',
					@engg_req_no,
					@m_errorid OUTPUT --chan

				IF @m_errorid <> 0
					/*fIXNOTE:_DM_FN_124*/
				BEGIN
					CLOSE insert_cur

					DEALLOCATE insert_cur

					RETURN
				END
			END

			CLOSE insert_cur

			DEALLOCATE insert_cur
				--    return
		END
	END

	-- select  null     'fprowno'
	SET NOCOUNT OFF
END

GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME= 'ep_layout_sp_defpg_hsv' AND TYPE='P')
BEGIN
	GRANT EXEC ON  ep_layout_sp_defpg_hsv TO PUBLIC
END
GO