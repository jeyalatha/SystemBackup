IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_layout_sp_savgrdgdml' AND TYPE = 'P')
BEGIN
	DROP PROC ep_layout_sp_savgrdgdml                            
END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	27 Aug 2019
Purpose 		ep_layout_sp_savgrdgdml.sql
********************************************************************************/
/*      V E R S I O N      :  2.0.4    */
/*      Released By        :  PTech    */
/*      Release Comments   :  Released on 22-12-2004 (Patch Release 1)    */
/*      V E R S I O N      :  2.0.2    */
/*      Released By        :  PTech    */
/*      Release Comments   :  Released on  22-Jan-2004    */
/****** Object:  Stored Procedure dbo.ep_layout_sp_savgrdgdml    Script Date: 1p1/6/03 5:21:04 PM ******/
/* Modified by : Jeya Latha K     Date: 27-May-2020		Defect ID: TECH-46646 		*/
/************************************************************************************  
procedure name and id :ep_layout_sp_savgrdgdml  
description             :Service the Save Task in GridContents Save, Validating and  
Saving the ML Values  
name of the author      :Madugula Srinivas  
date created            :22-Oct-2003  
query file name         :ep_layout_sp_savgrdgdml.sql  
method name  :ep_layout_mt_savgrdgdml  
modifications history   :  
modified by             Shafina Begum.B  
modified date           13-jan-2004  
modified purpose        to change the length of bt synonym  
modified by             Shafina Begum.B  
modified date           13-jan-2004  
modified purpose        to change the length of bt synonym  
modified by             Shafina Begum.B  
modified date           17-jan-2004  
modified purpose        to fetch the task name based on the default_for column  
to insert the primary control_bts  
modified by             Shafina Begum.B  
modified date           21-jan-2004  
modified purpose        to insert the control_id correctly  
modified by             Balaji S  
modified date           06-Aug-2005  
modified purpose        Validation to be added For not to add Label in Grid(Platform_2.0.3.X_55)  
************************************************************************************/
/*modified by             Sangeetha L         */
/*modified date           24-Aug-2005         */
/*modified purpose       Validation added for KEYWORD NOT ALLOWED AS A PARAMETER   */
/***********************************************************************************/
/*modified by             Chanheetha N A                                           */
/*modified date           29-Nov-2005                                              */
/*modified purpose        Validation To Display the Column Name which is a keyword*/
/*BugId             PNR2.0_4824                                                */
/*modified by             Gowrisankar M  for PNR2.0_4942  
modified date           13-Dec-2005  
modified purpose        Validation to be added for default dataitems not to be defined as BT Synonym */
/***********************************************************************************/
/* modified by  : Balaji S                                                    */
/* date         : 29-JUN-2006                                                    */
/* Bug Id  : PNR2.0_9131       */
/* Description  : New Base Control Type Label */
/********************************************************************************/
/* Modified by  : kiruthika R             */
/* Date         : 25-Aug-2006                                                   */
/* Bug ID       : PNR2.0_10027             */
/********************************************************************************/
/* modified by  : Anuradha M                                                    */
/* date         : 06-Nov-2006                                                   */
/* description  : PNR2.0_10832                                                  */
/********************************************************************************/
/* modified by  : Chanheetha N A                     */
/* date         : 15-Nov-2006                                                   */
/* description  : PNR2.0_11000                                                  */
/********************************************************************************/
/* modified by   : Chanheetha N A        */
/* date     : 17-nov-2007         */
/* BugId    : PNR2.0_16023          */
/************************************************************************/
/* modified by  : Feroz                   */
/* date      : 25-07-2008                  */
/* BugId     : PNR2.0_18706                  */
/************************************************************************/
/* modified by   : Feroz           */
/* date     : 25-nov-2008         */
/* BugId    : PNR2.0_1790          */
/************************************************************************/
/* modified by  : Sangeetha G                                                       */
/* date         : 15-Apr-2009                                                                    */
/* Bug Id       : PNR2.0_21576                                         */
/* Modification : To include the gridlite property for grid type controls       */
/**************************************************************************************************/
/* modified by  : Feroz                                                */
/* date         : 04-Aug-2009                                                   */
/* Bug Id   : PNR2.0_2179             */
/* Description  : Phase 3 Features - ListEdit, AttachDocument, Image & DateHighlight */
/********************************************************************************/
/* modified by  : Gopinath S                            */
/* date         : 05-Nov-2009                                                   */
/* Bug Id  : PNR2.0_24645       */
/* Description  : state column no's are repeating and it is not in order */
/********************************************************************************/
/* modified by  : Chanheetha N A                           */
/* date         : 14-Dec-2009                                                   */
/* Bug Id  : PNR2.0_25211       */
/* Description  : Conversion failed when converting the varchar value 'hhLineNo_Hidn' to data type int.  */
/*********************************************************************************************************/
/* Modified By      : Sangeetha G               */
/* Date            : 05-May-2010             */
/* BugID       : PNR2.0_23541              */
/* Modified For      : To set UserPreference through frontend in spec Layout */
/*          Inplace of SP - ep_layout_sp_savgrdgdml  */
/********************************************************************************/
/* Modified by  : Shakthi P                                                            */
/* Date         : 07-April-2011                                                        */
/* Description  : Validation for Listedit controls,while add,delete and update         */
/* CaseID       : PNR2.0_30886                                                         */
/***************************************************************************************/
/* modified by   : Sangeetha G           */
/* date    : 11-Apr-2011           */
/* BugId   : PNR2.0_30869           */
/* modified for  : Feature Release          */
/****************************************************************************************/
/* modified by  : Muthupandi S              */
/* date         : 08-june-2011              */
/* Bug ID  : PNR2.0_31754                     */
/* Description : Validation added to avoid ,             */
/*     deleting controls when the task by the control      */
/*     is mapped as a page event"            */
/****************************************************************************************/
/* modified by  : Muthupandi S              */
/* date         : 25-July-2011              */
/* Bug ID  : PNR2.0_32543                     */
/* Description : To add the validation to avoid deleting link controls,without  */
/*     removing the Link - ezee view Sp          */
/*     mapping in specify ezee view link .            */
/****************************************************************************************/
/* Modified by  : Shakthi P                                                             */
/* Date         : 03-August-2011                                                        */
/* Description  : Default can be set only to Edit/Combo columns                         */
/* CaseID       : PNR2.0_32759                                                          */
/****************************************************************************************/
/* Modified By : Vignesh                */
/* Date   : 29-Aug-2011               */
/* BugId  : PNR2.0_32228                */
/****************************************************************************************/
/* Modified By : Jeya Latha K               */
/* Date   : 21-Sep-2011               */
/* BugId  : PNR2.0_33469                */
/****************************************************************************************/
/* Modified By : Balaji D                 */
/* Date   : 18-Oct-2011               */
/* BugId  : PNR2.0_33877               */
/* Description : Control having base control type as Datahayperlink is not    */
/*      listing in ezeeview screen           */
/****************************************************************************************/
/* modified by : Balaji D                                                     */
/* date   : 10-jan-2012                                                   */
/* BugId  : PNR2.0_35200                                                    */
/* Description : Default cannot be set to DisplayOnly columns.             */
/****************************************************************************************/
/* modified by  : Gankan G               */
/* date         : 03-Nov-2012                     */
/* Bug ID  : PLF2.0_03057               */
/* Description : Code Modified to inlucde new ISList Box property     */
/****************************************************************************************/
/* modified by  : Gankan G               */
/* date         : 03-Nov-2012                     */
/* Bug ID  : PLF2.0_03114               */
/* Description : Code Modified to handle ISList Box property       */
/****************************************************************************************/
/* modified by  : Gankan G               */
/* date         : 03-Dec-2013                     */
/* Bug ID  : PLF2.0_06660               */
/* Description : Code changes to disable hiddencontrol insertion for Grid Defaulting */
/****************************************************************************************/
/* modified by   : Kanagavel A                        */
/* date          : 03/06/2014                      */
/* Description  : if  BTSynonym Name already exists for another Page or Section or control or Grid Control, display error message       */
/*********************************************************************************/
/* modified by  : Ganesh Prabhu S                                               */
/* date         : Oct 10 2014                                                    */
/* BugId        : PLF2.0_09035                                                   */
/* description  : Model changes for rowspan,colspan,IsStatic,IsCallout in  layout level            */
/***************************************************************************************************/
/* Modified by  : Veena U                                                  */
/* Date     : 25-Feb-2015                                          */
/* Call ID  : PLF2.0_11499         */
/********************************************************************************/
/* Modified by  : Kalidas S	                                                  */
/* Date         : 03-Aug-2015                                                  */
/* Defect ID	: PLF2.0_14096                                                 */
/********************************************************************************/
/* Modified by  : Veena U	                                                  */
/* Date         : 02-Feb-2016                                                  */
/* Defect ID	: PLF2.0_16291													*/
/********************************************************************************/
/* Created by  	: Veena U                                                */
/* Date         : 16-March-2016                                                  */
/*Defect Id 	: PLF2.0_17326												*/
/********************************************************************************/
/* Modified by  : Veena U                                                  */
/* Date         : 28-Mar-2016                                                 */
/* Call ID		: PLF2.0_17570                                               */
/********************************************************************************/
/* modified by			Date				Defect ID							*/
/* Veena U				08-Jun-2016			PLF2.0_18487						*/
/********************************************************************************/
/* Modified by : Jeya Latha K/Ganesh Prabhu S	for callid TECH-7349				*/
/* Modified on : 14-03-2017				 											*/
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and New Feature Organization chart */
/***********************************************************************************/
/* Modified by : Ganesh Prabhu S/Ranjitha R      for callid  TECH-10118                   */
/* Modified on : 30-May-2017                                                                                        */
/* Description : Platform Feature Release                                                              */
/********************************************************************************/
/* Modified by  : Jeya Latha K		Date: 16-Aug-2017  Defect ID	:TECH-12776	*/
/********************************************************************************/
/* Modified by  : Ranjitha R		Date: 4-Dec-2017  Defect ID	:TECH-16126	*/
/********************************************************************************/
/* Modified by  : JeyaLatha K/Ranjitha R	Date: 31-Jan-2018  Defect ID : TECH-18349 */
/***************************************************************************************/
/* Modified by  : Ranjitha R	Date: 28-Feb-2018  Defect ID : TECH-19347 */
/***************************************************************************************/
/* Modified by : Ranjitha R      for callid  TECH-19826									*/
/* Modified on : 14-Mar-2018                                                            */
/* Description : While selecting row expander it shows below error.						
To Enable 'Row Expander', corresponding control type must be enabled for 'Row Expander'.*/
/* Modified by  : Jeya Latha K		Date: 28-Mar-2018  Defect ID	:TECH-20258	*/
/* Modified by  : Ranjitha R		Date: 29-Mar-2018  Defect ID	: TECH-20326 */
/********************************************************************************/
/*Modified by	: Ranjitha R   Defect ID: TECH-20897      On: 30-Apr-2018      */
/* Forcefit Value 0,1 changed as y/n by Venkatesh								*/
/* Modified by  : Ranjitha R					Date: 31-May-2018  Defect ID: TECH-21893			 */
/* Modified By : Jeya Latha K					Date: 08-Jan-2019  Defect ID: TECH-28436	      	 */
/* Modified by : Jeya Latha K				    Date: 04-Dec-2019  Defect ID : TECH-40809			 */
/* Modified by : Jeya Latha K					Date: 07-Feb-2020  Defect ID : TECH-42760,TECH-42697 */
/* Modified by : Priyadharshini U/Jeya Latha K  Date: 27-Feb-2020  Defect ID : TECH-43307			 */
/* Modified by : Jeya Latha K					Date: 27-May-2020  Defect ID : TECH-46646			 */
/* Modified by : Priyadharshini U/Jeya Latha K  Date: 12-Nov-2020  Defect ID : TECH-51746			 */
/* Modified by : Manoj S						Date: 24-Jan-2021  Defect ID : TECH-52773            */
/* Modified by : Deepika S						Date: 08-Apr-2021  Defect ID : ECE-425               */
/* Modified by : Rajeswari M/Priyadharshini U   Date: 28-Jul-2021  Defect ID : TECH-60451            */
/* TECH-60451  : Launching Help&Link UIs, Popup sections and Grid Extensions in Side Drawer          */
/* Modified by : Ponmalar A/Jeya Latha K		Date: 28-Jul-2021  Defect ID : TECH-64327            */
/* TECH-64327  : Default required should be enabled by system for the Edit & Combo control in		 */ 
/*				Grid based on the meta data entry in the table es_proj_hdn_ctrl_dtl					 */
/*****************************************************************************************************/
/* Modified by : Ponmalar A/Jeya Latha K		  Date: 13-Apr-2022     Defect ID : TECH-68066		 */
/* TECH-68066  : Post and Pre Tasks for Attachment controls											 */	
/*****************************************************************************************************/
/* Modified by : Priyadharshini U		  Date: 15-June-2022     Defect ID : TECH-69784				 */
/*****************************************************************************************************/
/* Modified by : Ponmalar A / Priyadharshini U		  Date: 08-July-2022     Defect ID : Tech-70687  */
/*****************************************************************************************************/
/* Modified by : Ponmalar A						  Date: 27-July-2022     Defect ID : TECH-71262		 */
/* Description : Platform Features for the Month of July'22											 */	
/*****************************************************************************************************/
/* Modified by : Athul M																			 */
/* Modified on : 27-July-2022																		 */
/* Defect ID   : TECH-71262																			 */
/* Description : Platform Features for the Month of July'22											 */
/*****************************************************************************************************/
/* Modified by : Manoj S						Date: 28-Jul-2022  Defect ID : TECH-71379            */
/*****************************************************************************************************/
/* Modified by : Ponmalar A						Date: 09-Aug-2022  Defect ID : Tech-72114            */
/*****************************************************************************************************/
/* Modified by			: Ponmalar A																 */
/* Date					: 29-Sep-2022																 */
/* Defect ID			: TECH-73216																 */
/*****************************************************************************************************/
/* Modified by			: Ponmalar A/Priyadharshini U												 */
/* Date					: 27-Oct-2022																 */
/* Defect ID			: TECH-73996																 */
/*****************************************************************************************************/
/* Modified by : Ponmalar A						Date: 02-Dec-2022  Defect ID : TECH-75230            */
/*****************************************************************************************************/
CREATE PROCEDURE ep_layout_sp_savgrdgdml
	@ctxt_language ctxt_language, --Input   
	@ctxt_ouinstance ctxt_ouinstance, --Input   
	@ctxt_service ctxt_service, --Input   
	@ctxt_user ctxt_user, --Input   
	@engg_act_descr engg_description, --Input   
	@engg_col_descr engg_description, --Input   
	@engg_component engg_description, --Input   
	@engg_customer_name engg_name, --Input   
	@engg_enum_page_bts engg_name, --Input   
	@engg_enum_sec_bts engg_name, --Input   
	@engg_grid_btsynname engg_name, --Input   
	@engg_grid_colno engg_seqno, --Input   
	@engg_grid_doc engg_documentation, --Input   
	@engg_grid_elem_type engg_name, --Input   
	@engg_grid_grid_code engg_name, --Input   
	@engg_grid_page_bts engg_name, --Input   
	@engg_grid_samp_data engg_documentation, --Input   
	@engg_grid_sec_bts engg_name, --Input   
	@engg_grid_tooltip engg_documentation, --Input   
	@engg_grid_vis_length engg_length, --Input   
	@engg_process_descr engg_description, --Input   
	@engg_project_name engg_name, --Input   
	@engg_req_no engg_name, --Input   
	@engg_ui_descr engg_name, --Input   
	@guid guid, --Input   
	@modeflag modeflag, --Input   
	@engg_grid_default engg_flag, --Input   
	@fprowno rowno, --Input/Output  
	@engg_del_columns engg_documentation, --Input/Output  
	@engg_grd_visible engg_flag, --Input   
	@columnclass engg_name, --Input   
	--@columnheaderclass     engg_name, --Input   
	@forcefit engg_flag, --Input   
	@set_user_pref_ml checkflag_int, --Input   
	@engg_col_tempid engg_name, --Input   
	@col_temp_cat engg_name,
	@col_temp_specific engg_documentation,
	@col_associate_ctrl engg_name,		--Code added for TECH-71262
	@RowExpander engg_flag,
	@FormEnabled engg_flag,
	@engg_tree_column engg_flag,
	--Ranjitha
	@col_Icon_class engg_name,
	@col_Icon_position engg_name,
	@Col_class_ext6 engg_name,
	@Col_transform_as engg_name,
	@col_compact_view	engg_flag,
	@engg_extensionreqd engg_seqno, --Input
	@engg_extensionorder engg_seqno, --Input
		@m_errorid INT OUTPUT  --To Return Execution Status  
AS
BEGIN
	-- nocount should be switched on to prevent phantom rows  
	SET NOCOUNT ON
	-- @m_errorid should be 0 to Indicate Success  
	SET @m_errorid = 0
	--declaration of temporary variables  
	--temporary and formal parameters mapping  
	SET @ctxt_service = ltrim(rtrim(@ctxt_service))
	SET @ctxt_user = ltrim(rtrim(@ctxt_user))
	SET @engg_act_descr = ltrim(rtrim(@engg_act_descr))
	SET @engg_col_descr = ltrim(rtrim(@engg_col_descr))
	SET @engg_component = ltrim(rtrim(@engg_component))
	SET @engg_customer_name = ltrim(rtrim(@engg_customer_name))
	SET @engg_enum_page_bts = ltrim(rtrim(@engg_enum_page_bts))
	SET @engg_enum_sec_bts = ltrim(rtrim(@engg_enum_sec_bts))
	SET @engg_grid_btsynname = ltrim(rtrim(@engg_grid_btsynname))
	SET @engg_grid_doc = ltrim(rtrim(@engg_grid_doc))
	SET @engg_grid_elem_type = ltrim(rtrim(@engg_grid_elem_type))
	SET @engg_grid_grid_code = ltrim(rtrim(@engg_grid_grid_code))
	SET @engg_grid_page_bts = ltrim(rtrim(@engg_grid_page_bts))
	SET @engg_grid_samp_data = ltrim(rtrim(@engg_grid_samp_data))
	SET @engg_grid_sec_bts = ltrim(rtrim(@engg_grid_sec_bts))
	SET @engg_grid_tooltip = ltrim(rtrim(@engg_grid_tooltip))
	SET @engg_process_descr = ltrim(rtrim(@engg_process_descr))
	SET @engg_project_name = ltrim(rtrim(@engg_project_name))
	SET @engg_req_no = ltrim(rtrim(@engg_req_no))
	SET @engg_ui_descr = ltrim(rtrim(@engg_ui_descr))
	SET @guid = ltrim(rtrim(@guid))
	SET @modeflag = ltrim(rtrim(@modeflag))
	SET @engg_grid_default = ltrim(rtrim(@engg_grid_default))
	SET @engg_del_columns = ltrim(rtrim(@engg_del_columns))
	SET @engg_grd_visible = ltrim(rtrim(@engg_grd_visible))
	SET @columnclass = ltrim(rtrim(@columnclass))
	--Set @columnheaderclass     = ltrim(rtrim(@columnheaderclass))  
	SET @forcefit = ltrim(rtrim(@forcefit))
	SET @engg_col_tempid = ltrim(rtrim(@engg_col_tempid))
	SET @RowExpander = ltrim(rtrim(@RowExpander))
	SET @FormEnabled = ltrim(rtrim(@FormEnabled))
	SET @engg_tree_column = ltrim(rtrim(@engg_tree_column))
	--Ranjitha
	SET @col_Icon_class = ltrim(rtrim(@col_Icon_class))
	SET @col_Icon_position = ltrim(rtrim(@col_Icon_position))
	SET @Col_class_ext6 = ltrim(rtrim(@Col_class_ext6))
	SET @Col_transform_as = ltrim(rtrim(@Col_transform_as))
	SET @col_compact_view = ltrim(rtrim(@col_compact_view))
	
	--null checking  
	IF @ctxt_language = - 915
		SELECT @ctxt_language = NULL

	IF @ctxt_ouinstance = - 915
		SELECT @ctxt_ouinstance = NULL

	IF @ctxt_service = '~#~'
		SELECT @ctxt_service = NULL

	IF @ctxt_user = '~#~'
		SELECT @ctxt_user = NULL

	IF @engg_act_descr = '~#~'
		SELECT @engg_act_descr = NULL

	IF @engg_col_descr = '~#~'
		SELECT @engg_col_descr = NULL

	IF @engg_component = '~#~'
		SELECT @engg_component = NULL

	IF @engg_customer_name = '~#~'
		SELECT @engg_customer_name = NULL

	IF @engg_enum_page_bts = '~#~'
		SELECT @engg_enum_page_bts = NULL

	IF @engg_enum_sec_bts = '~#~'
		SELECT @engg_enum_sec_bts = NULL

	IF @engg_grid_btsynname = '~#~'
		SELECT @engg_grid_btsynname = NULL

	IF @engg_grid_colno = - 915
		SELECT @engg_grid_colno = NULL

	IF @engg_grid_doc = '~#~'
		SELECT @engg_grid_doc = NULL

	IF @engg_grid_elem_type = '~#~'
		SELECT @engg_grid_elem_type = NULL

	IF @engg_grid_grid_code = '~#~'
		SELECT @engg_grid_grid_code = NULL

	IF @engg_grid_page_bts = '~#~'
		SELECT @engg_grid_page_bts = NULL

	IF @engg_grid_samp_data = '~#~'
		SELECT @engg_grid_samp_data = NULL

	IF @engg_grid_sec_bts = '~#~'
		SELECT @engg_grid_sec_bts = NULL

	IF @engg_grid_tooltip = '~#~'
		SELECT @engg_grid_tooltip = NULL

	IF @engg_grid_vis_length = - 915
		SELECT @engg_grid_vis_length = NULL

	IF @engg_process_descr = '~#~'
		SELECT @engg_process_descr = NULL

	IF @engg_project_name = '~#~'
		SELECT @engg_project_name = NULL

	IF @engg_req_no = '~#~'
		SELECT @engg_req_no = NULL

	IF @engg_ui_descr = '~#~'
		SELECT @engg_ui_descr = NULL

	IF @guid = '~#~'
		SELECT @guid = NULL

	IF @modeflag = '~#~'
		SELECT @modeflag = NULL

	IF @engg_grid_default = '~#~'
		SELECT @engg_grid_default = NULL

	IF @fprowno = - 915
		SELECT @fprowno = NULL

	IF @engg_del_columns = '~#~'
		SELECT @engg_del_columns = NULL

	IF @engg_grd_visible = '~#~'
		SELECT @engg_grd_visible = NULL

	IF @columnclass = '~#~'
		SELECT @columnclass = NULL

	--IF @columnheaderclass = '~#~'   
	--Select @columnheaderclass = null    
	IF @forcefit = '~#~'
		SELECT @forcefit = NULL

	IF @set_user_pref_ml = - 915
		SELECT @set_user_pref_ml = NULL

	IF @engg_col_tempid = '~#~'
		SELECT @engg_col_tempid = NULL

	IF @col_temp_cat = '~#~'
		SELECT @col_temp_cat = NULL

	IF @col_temp_specific = '~#~'
		SELECT @col_temp_specific = NULL

	IF @col_associate_ctrl = '~#~'			--Code Added for TECH-71262
		SELECT @col_associate_ctrl = NULL

	IF @RowExpander = '~#~'
		SELECT @RowExpander = NULL

	IF @FormEnabled = '~#~'
		SELECT @FormEnabled = NULL

	IF @engg_tree_column = '~#~'
		SELECT @engg_tree_column = NULL

	--Ranjitha
	IF @col_Icon_class = '~#~'
		SELECT @col_Icon_class = NULL

	IF @col_Icon_position = '~#~'
		SELECT @col_Icon_position = NULL

	IF @Col_class_ext6 = '~#~'
		SELECT @Col_class_ext6 = NULL

	IF @Col_transform_as = '~#~'
		SELECT @Col_transform_as = NULL

	IF @col_compact_view = '~#~'
		SELECT @col_compact_view = NULL

	--code added on 19th July 2021
	IF @engg_extensionreqd = -915
		SELECT @engg_extensionreqd = NULL

	IF @engg_extensionorder = -915
		SELECT @engg_extensionorder = NULL

	IF @modeflag = 'S'
		RETURN

	IF @col_temp_cat IS NULL
	BEGIN
		SET @engg_col_tempid = NULL
	END

	IF EXISTS (
			SELECT 'x'
			FROM vid_ilbo_tmp
			WHERE ilbodescription = @engg_ui_descr
			)
	BEGIN
		EXEC uid_ep_layout_sp_savgrdgdml @ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			@engg_act_descr,
			@engg_col_descr,
			@engg_component,
			@engg_customer_name,
			@engg_enum_page_bts,
			@engg_enum_sec_bts,
			@engg_grid_btsynname,
			@engg_grid_colno,
			@engg_grid_doc,
			@engg_grid_elem_type,
			@engg_grid_grid_code,
			@engg_grid_page_bts,
			@engg_grid_samp_data,
			@engg_grid_sec_bts,
			@engg_grid_tooltip,
			@engg_grid_vis_length,
			@engg_process_descr,
			@engg_project_name,
			@engg_req_no,
			@engg_ui_descr,
			@guid,
			@modeflag,
			@engg_grid_default,
			@fprowno,
			@engg_del_columns,
			@engg_grd_visible,
			@columnclass,
			@forcefit,
			@engg_col_tempid,
			@set_user_pref_ml,
			@engg_col_tempid,
			@m_errorid
	END
	ELSE
	BEGIN
		DECLARE @component_name_tmp engg_name,
			@prc_name_tmp engg_name,
			@act_name_tmp engg_name,
			@ui_name_tmp engg_name,
			@vis_flag engg_flag,
			@allow_hdn_ctrl engg_description,
			@col_bt_syn_chk engg_name,
			@control_id_tmp engg_name,
			@count engg_name,
			@ctrl_bt_syn_id engg_name,
			@view_name engg_name,
			@event_req engg_flag,
			@help_req engg_flag,
			@old_help_req engg_flag,
			@zoom_req engg_flag,
			@editable engg_flag,
			@tmp_ctl engg_name,
			@page_prefix_tmp engg_name,
			@tmp_control_type engg_name,
			@viewname_tmp engg_name,
			@hview_name_tmp engg_name, /* PNR2.0_11000*/
			@rstr engg_name,
			@task_name engg_name,
			@vlen INT,
			@ccnt INT,
			@cstr engg_name,
			@grid_bt_caption engg_name,
			@base_ctrl_type_tmp engg_name,
			@enumcap engg_description,
			@spin_required engg_flag,
			@report_req engg_flag -- code modified by Anuradha on 06-Nov-2006 for the Bug ID :: PNR2.0_10832    
			,
			@QlikLink engg_flag,
			@QlikLink_pre engg_flag,
			@page_prefix_sec engg_name,
			@tmp_cotrol_id engg_name,
			@appid engg_name,
			@Sheetid engg_name,
			@cont_name engg_name,
			@len_app engg_seqno,
			@len_sht engg_seqno,
			@max_horder engg_seqno,
			@ctl_base_control engg_name,
			@issys_defined	engg_name,
			@controltype engg_name,
			@selectionreqdforList engg_flag

		DECLARE @phone_in engg_flag,
			@tablet_in engg_flag,
			@Devicetype engg_flag
		DECLARE @error_tmp engg_rowno
		DECLARE @msg engg_documentation
		DECLARE @engg_base_req_no engg_name,
				@column_prefix	engg_name	--TECH-75230

		SELECT @engg_base_req_no = 'BASE'

		--  select @seq_no = 0    
		--Modification for PNR2.0_23541 starts    
		DECLARE @user_pref engg_flag

		IF isnull(@set_user_pref_ml, '') IN (
				'',
				0
				)
			SELECT @user_pref = 'Y'

		IF isnull(@set_user_pref_ml, '') = 1
			SELECT @user_pref = 'N'

		--Modification for PNR2.0_23541 ends    
		--Code Modification for PNR2.0_30869 starts    
		DECLARE @control_id engg_name
		DECLARE @grid_def engg_flag
		DECLARE @renderas engg_name
		
		IF isnull(@engg_grid_default, '') = 1
			SELECT @grid_def = 'Y'
		ELSE
			SELECT @grid_def = 'N'

		--Code Modification for PNR2.0_30869 ends    
		/*Getting Process Name for incoming Process Desc.*/
		SELECT @prc_name_tmp = rtrim(process_name)
		FROM ep_ui_req_dtl(NOLOCK)
		WHERE customer_name = rtrim(@engg_customer_name)
			AND project_name = rtrim(@engg_project_name)
			AND req_no = rtrim(@engg_req_no)
			AND process_descr = rtrim(@engg_process_descr)

		/*Getting Component Name for Given Component Description*/
		SELECT @component_name_tmp = rtrim(component_name)
		FROM ep_ui_req_dtl(NOLOCK)
		WHERE customer_name = rtrim(@engg_customer_name)
			AND project_name = rtrim(@engg_project_name)
			AND req_no = rtrim(@engg_req_no)
			AND process_name = rtrim(@prc_name_tmp)
			AND component_descr = rtrim(@engg_component)

		/*Getting Activity Name for Activity Desc*/
		SELECT @act_name_tmp = rtrim(activity_name)
		FROM ep_ui_req_dtl(NOLOCK)
		WHERE customer_name = rtrim(@engg_customer_name)
			AND project_name = rtrim(@engg_project_name)
			AND req_no = rtrim(@engg_req_no)
			AND process_name = rtrim(@prc_name_tmp)
			AND component_name = rtrim(@component_name_tmp)
			AND activity_descr = rtrim(@engg_act_descr)

		/*Getting UI Name for UI Desc*/
		SELECT @ui_name_tmp = rtrim(ui_name)
		FROM ep_ui_req_dtl(NOLOCK)
		WHERE customer_name = rtrim(@engg_customer_name)
			AND project_name = rtrim(@engg_project_name)
			AND req_no = rtrim(@engg_req_no)
			AND process_name = rtrim(@prc_name_tmp)
			AND component_name = rtrim(@component_name_tmp)
			AND activity_name = rtrim(@act_name_tmp)
			AND ui_descr = rtrim(@engg_ui_descr)

		--GETTING THE CTRL NAME FOR THE DESCRIPTION    
		SELECT @tmp_ctl = base_ctrl_type,
			@help_req = help_req,
			@event_req = event_handling_req,
			@zoom_req = zoom_req,
			@editable = editable_flag,
			@spin_required = spin_required,
			@report_req = report_req -- code modified by Anuradha on 06-Nov-2006 for the Bug ID :: PNR2.0_10832
			,
			@Qliklink = Qliklink
		FROM es_comp_ctrl_type_mst_vw(NOLOCK)
		WHERE customer_name = rtrim(@engg_customer_name)
			AND project_name = rtrim(@engg_project_name)
			AND process_name = rtrim(@prc_name_tmp)
			AND component_name = rtrim(@component_name_tmp)
			AND ctrl_type_name = rtrim(@engg_grid_elem_type)
			AND req_no = rtrim(@engg_base_req_no)

		SELECT @renderas = isnull(RenderAs, ''),
			@ctl_base_control = isnull(base_ctrl_type, ''),
			@controltype	= ISNULL(ctrl_Type_name,'')
		FROM es_comp_ctrl_type_mst ctype(NOLOCK),
			ep_ui_control_dtl ctrl(NOLOCK)
		WHERE ctype.customer_name = ctrl.customer_name
			AND ctype.project_name = ctrl.project_name
			AND ctype.process_name = ctrl.process_name
			AND ctype.component_name = ctrl.component_name
			AND ctype.ctrl_type_name = ctrl.control_type
			AND ctype.customer_name = @engg_customer_name
			AND ctype.project_name = @engg_project_name
			AND ctype.process_name = @prc_name_tmp
			AND ctype.component_name = @component_name_tmp
			AND ctrl.activity_name = @act_name_tmp -- code added for Defect id: TECH-19826
			AND ctrl.ui_name = @ui_name_tmp
			AND ctrl.control_bt_synonym = @engg_grid_grid_code

			SELECT	@selectionreqdforList	= ISNULL(IsSelectionReqdList, 'N')
			FROM	es_comp_ctrl_type_mst_extn (nolock)
			WHERE	customer_name	= @engg_customer_name
			AND		project_name	= @engg_project_name
			AND		process_name	= @prc_name_tmp
			AND		component_name	= @component_name_tmp
			AND		ctrl_type_name	= @controltype
			AND		Base_ctrl_type	= @ctl_base_control


	SELECT @issys_defined = 'N'

	SELECT	@viewname_tmp		= View_name
	FROM	ep_ui_grid_dtl (nolock)
	WHERE	customer_name		= @engg_customer_name
	AND		project_name		= @engg_project_name
	AND		process_name		= @prc_name_tmp
	AND		component_name		= @component_name_tmp
	AND		activity_name		= @act_name_tmp 
	AND		ui_name				= @ui_name_tmp
	AND		control_bt_synonym	= @engg_grid_grid_code	
	AND		Column_bt_synonym	= @engg_grid_btsynname
 --TECH-75230
	SELECT	@column_prefix		= column_prefix
	FROM	ep_ui_grid_dtl (NOLOCK)
	WHERE	customer_name	= rtrim(@engg_customer_name)
	and		project_name	= rtrim(@engg_project_name)
	and		process_name	= rtrim(@prc_name_tmp)
	and		component_name	= rtrim(@component_name_tmp)
	and		activity_name	= rtrim(@act_name_tmp)
	and		ui_name			= rtrim(@ui_name_tmp)
	and		page_bt_synonym	= rtrim(@engg_grid_page_bts)
	and		section_bt_synonym = rtrim(@engg_grid_sec_bts)
	and		column_bt_synonym  = rtrim(@engg_grid_btsynname)
--TECH-75230
 
	IF EXISTS ( SELECT 'x'
		FROM ep_systemdefined_views(NOLOCK)
		WHERE viewname = @viewname_tmp
		) and @RenderAs = 'Gantt'
	BEGIN
		SELECT @issys_defined = 'Y'
	END

	IF (@modeflag = 'D'  AND @issys_defined = 'Y')
	BEGIN
		RAISERROR (	'System Created Columns cannot be Deleted',	16,	4,	@engg_grid_btsynname)
		RETURN
	END	


	IF (@RenderAs = 'Gantt' AND 		@engg_tree_column = 'Y' AND @modeflag in ('U', 'Y'))
	BEGIN
		Raiserror ('Tree Column cannot be modified.', 16, 1)
		RETURN
	END
	--TECH-71379 starts
	IF EXISTS (
	select 'x'
	from ep_ui_grid_dtl a (nolock)
	join ep_ui_state_column_dtl b(nolock) 
	on a.customer_name			= b.customer_name
	and a.project_name			= b.project_name
	and a.component_name		= b.component_name
	and a.process_name			= b.process_name
	and a.activity_name			= b.activity_name
	and a.ui_name				= b.ui_name
	and a.control_bt_synonym	= b.control_bt_synonym
	and a.column_bt_synonym		= b.column_bt_synonym
	and a.customer_name			= rtrim(@engg_customer_name)
	and a.project_name			= rtrim(@engg_project_name)
	and a.process_name			= rtrim(@prc_name_tmp)
	and a.component_name		= rtrim(@component_name_tmp)
	and a.activity_name			= rtrim(@act_name_tmp)
	and a.ui_name				= rtrim(@ui_name_tmp)
	and a.control_bt_synonym	= @engg_grid_grid_code
	and a.column_bt_synonym		= @engg_grid_btsynname
	and b.visible				= 'y'
	and @engg_grd_visible		= 'NO'
	)
	BEGIN
	RAISERROR('Column at row no %i has been made visible through state modelling.Kindly remove the state modelling for the column and proceed',16,1,@fprowno)
	RETURN
	END
	--TECH-71379 ends
	--TECH-52773 starts
IF  exists 
( select 'X' from es_comp_ctrl_type_mst (nolock)
where customer_name = @engg_customer_name
AND		project_name	= @engg_project_name
AND		req_no			= @engg_base_req_no
AND		process_name	= @prc_name_tmp
AND		component_name	= @component_name_tmp
AND		ctrl_type_name	= @engg_grid_elem_type
AND		base_ctrl_type  = 'EDIT'
AND		isnull(visisble_flag,'')  = 'Y'
AND		isnull(editable_flag,'')  = 'N'
)
AND  @Col_class_ext6 = 'Icon'
BEGIN 
RAISERROR('For Display Only Column kindly provide valid control class at ronw no %i',16,6,@fprowno)
RETURN
END
--TECH-52773 ends
		-- NGPLF Changes Starts
		DECLARE @ctxt_role engg_name = NULL

		IF @modeflag IN (
				'I',
				'X',
				'U',
				'Y'
				)
		BEGIN
			IF EXISTS (
					SELECT 'X'
					FROM ep_ui_mst(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND ISNULL(ISGLANCE, 'N') = 'Y'
					)
			BEGIN
				EXEC ngplf_validate_specifylayout @ctxt_language,
					@ctxt_ouinstance,
					@ctxt_user,
					@Ctxt_role,
					@engg_customer_name,
					@engg_project_name,
					@prc_name_tmp,
					@component_name_tmp,
					@act_name_tmp,
					@ui_name_tmp,
					@engg_grid_sec_bts,
					@engg_grd_visible,
					'HCol'
			END
		END

		-- NGPLF Changes Ends
		IF isnull(@RowExpander, 0) = 1
			AND isnull(@renderas, '') <> 'RowExpander'
		BEGIN
			RAISERROR (
					'To Enable ''Row Expander'', corresponding control type must be enabled for ''Row Expander''.',
					16,
					1
					)

			RETURN
		END

		IF isnull(@formenabled, 0) = 1
			AND isnull(@renderas, '') <> 'GridtoForm'
		BEGIN
			RAISERROR (
					'To Enable ''Grid to Form'', corresponding control type must be enabled for ''Grid to Form''.',
					16,
					1
					)

			RETURN
		END

		IF isnull(@renderas, '') NOT IN (
				'TreeGrid',
				'OrgChart'
				)
			AND isnull(@engg_tree_column, 0) = 1
		BEGIN
			RAISERROR (
					'Tree Column is applicable only for the Control type ''TreeGrid''.',
					16,
					1
					)

			RETURN
		END

		-- Added for TECH-28436
		IF @engg_grid_elem_type <> 'displayonly'
			AND @ctl_base_control = 'ListView'
		BEGIN
			RAISERROR (
					'ListView Control can have only ''displayonly'' Column(s).',
					16,
					1
					)
		END

		-- Code Added for PNR2.0_32228 Starts 
		DECLARE @del_flag engg_flag,
			@del_flag_ph engg_flag

		--PLF2.0_03057 starts    
		IF EXISTS (
				SELECT 'x'
				FROM ep_ui_control_dtl a(NOLOCK),
					es_comp_ctrl_type_mst b(NOLOCK)
				WHERE a.customer_name = @engg_customer_name
					AND a.project_name = @engg_project_name
					AND a.process_name = @prc_name_tmp
					AND a.component_name = @component_name_tmp
					AND a.page_bt_synonym = @engg_grid_page_bts
					AND a.control_bt_synonym = @engg_grid_grid_code
					AND a.customer_name = b.customer_name
					AND a.project_name = b.project_name
					AND a.process_name = b.process_name
					AND a.component_name = b.component_name
					AND a.control_type = b.ctrl_type_name
					AND b.base_ctrl_type = 'GRID'
					AND b.IsListBox = 'Y'
				)
		BEGIN
			IF NOT EXISTS (
					SELECT 'x' -- Code changes for PLF2.0_03114    
					FROM es_comp_ctrl_type_mst(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND ctrl_type_name = @engg_grid_elem_type
						AND base_ctrl_type IN (
							'link',
							'edit'
							)
						AND editable_flag = 'n'
					)
			BEGIN
				RAISERROR (
						'For the Grid with list box property selected, Only column types with displayonly and link can be added !.',
						16,
						1
						)

				RETURN
			END
		END

		--PLF2.0_03057 ends   
		-- Code added for Defect Id: TECH-19347 starts
		IF @modeflag IN (
				'U',
				'Y'
				)
		BEGIN
			IF EXISTS (
					SELECT 'x'
					FROM ep_ui_grid_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = @engg_grid_page_bts
						AND control_bt_synonym = @engg_grid_grid_code
						AND column_bt_synonym = @engg_grid_btsynname
						AND view_name = '__nodeexpand'
					)
			BEGIN
				RAISERROR (
						'System Defined controls cannot be modified.',
						16,
						1
						)

				RETURN
			END
		END

		-- Code added for Defect Id: TECH-19347 ends
		-- code added for PLF2.0_16291 starts
		IF @modeflag IN ('D')
		BEGIN
			IF EXISTS (
					SELECT 'X'
					FROM ep_pivot_fields(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND page_name = @engg_grid_page_bts
						AND control_bt_synonym = @engg_grid_grid_code
						AND column_bt_synonym = @engg_grid_btsynname
					)
			BEGIN
				RAISERROR (
						'The Column %s cannot be deleted as it is involved in Specify Pivot Grid.',
						16,
						4,
						@engg_grid_btsynname
						)

				RETURN
			END

			IF EXISTS (
					SELECT 'X'
					FROM ep_ui_column_group_mapping(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND Page_bt_synonym = @engg_grid_page_bts
						AND grid_control_bt_synonym = @engg_grid_grid_code
						AND column_bt_synonym = @engg_grid_btsynname
					)
			BEGIN
				RAISERROR (
						'The Column %s cannot be deleted as it is involved in Column Grouping.',
						16,
						4,
						@engg_grid_btsynname
						)

				RETURN
			END
		END

		-- code added for PLF2.0_16291 ends 
		IF @modeflag IN (
				'D',
				'Y',
				'U'
				)
		BEGIN
			IF EXISTS (
					SELECT 'X'
					FROM ep_ui_column_group_mapping(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND Page_bt_synonym = @engg_grid_page_bts
						AND grid_control_bt_synonym = @engg_grid_grid_code
						AND column_bt_synonym = @engg_grid_btsynname
						AND isnull(@engg_grd_visible, '') = 'No'
					)
			BEGIN
				RAISERROR (
						'The Column %s involved in Column Grouping. Please remove from Grouping.',
						16,
						4,
						@engg_grid_btsynname
						)

				RETURN
			END

			-- If condition added for the Defect ID TECH-20258 to ignore the validations for user defined -- Starts
			IF EXISTS (
					SELECT 'x'
					FROM ep_ui_section_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = @engg_grid_page_bts
						AND section_bt_synonym = @engg_grid_sec_bts
						AND section_type IN (
							'MobileCalendar',
							'MobileGrid'
							)
						AND req_no = @engg_base_req_no
					
					UNION
					
					SELECT 'x'
					FROM ep_ui_mst(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND ui_subtype = 'Dashboard'
						AND req_no = @engg_base_req_no
					
					UNION
					
					SELECT 'X'
					FROM ep_ui_control_dtl a(NOLOCK),
						es_comp_ctrl_type_mst b(NOLOCK)
					WHERE a.customer_name = @engg_customer_name
						AND a.project_name = @engg_project_name
						AND a.process_name = @prc_name_tmp
						AND a.component_name = @component_name_tmp
						AND a.activity_name = @act_name_tmp
						AND a.ui_name = @ui_name_tmp
						AND a.control_bt_synonym = @engg_grid_btsynname
						AND a.customer_name = b.customer_name
						AND a.project_name = b.project_name
						AND a.process_name = b.process_name
						AND a.component_name = b.component_name
						AND a.control_type = b.ctrl_type_name
						AND b.base_ctrl_type = 'TreeGrid'
					)
			BEGIN -- If condition added for the Defect ID TECH-20258 to ignore the validations for user defined -- Ends
				IF EXISTS (
						SELECT 'x'
						FROM ep_systemdefined_views(NOLOCK)
						WHERE viewname = @engg_grid_btsynname
						)
				BEGIN
					RAISERROR (
							'System Created Columns cannot be updated / Deleted',
							16,
							4,
							@engg_grid_btsynname
							)

					RETURN
				END
			END
		END

		-----------------------------------------------multi-selector--validation
		/*Validation added against DEFECT ID : ECE-425 Starts*/
			IF @MODEFLAG  in ('D','U','Y')
			BEGIN 
			IF EXISTS (
					SELECT 'x' from ep_ui_grid_dtl grd(nolock)
					where
						  grd.customer_name			=	@engg_customer_name
						and grd.project_name		=	@engg_project_name
						and grd.process_name		=	@prc_name_tmp
						and grd.component_name		=	@component_name_tmp
						and grd.activity_name		=	@act_name_tmp
						and grd.ui_name				=	@ui_name_tmp
						AND grd.page_bt_synonym		=	@engg_grid_page_bts
						AND grd.section_bt_synonym	=	@engg_grid_sec_bts

						and grd.control_bt_synonym	=	@engg_grid_grid_code
						AND	grd.Column_bt_synonym	=	@engg_grid_btsynname

						and grd.view_name  in ('multiselectkey','multiselectseq','multiselectval')
						)

					BEGIN 
				    RAISERROR (
						'System generated columns of Multi-Selector Grid  can not be modified.',
						16,
						1
						)

					return 
					end
					
			end
					/*Validation added against DEFECT ID : ECE-425 Ends*/


		SELECT @del_flag = 'F'

		IF @modeflag IN (
				'U',
				'Y',
				'I',
				'X'
				)
		BEGIN
			IF EXISTS (
					SELECT 'x'
					FROM es_comp_ctrl_type_mst ctype(NOLOCK),
						ep_ui_control_dtl ctrl(NOLOCK)
					WHERE ctype.customer_name = ctrl.customer_name
						AND ctype.project_name = ctrl.project_name
						AND ctype.process_name = ctrl.process_name
						AND ctype.component_name = ctrl.component_name
						AND ctype.ctrl_type_name = ctrl.control_type
						AND ctype.customer_name = @engg_customer_name
						AND ctype.project_name = @engg_project_name
						AND ctype.process_name = @prc_name_tmp
						AND ctype.component_name = @component_name_tmp
						AND ctrl.control_bt_synonym = @engg_grid_grid_code
						AND ctype.renderas = 'Tag'
					)
			BEGIN
				RAISERROR (
						'Tag control information can not be modified.',
						16,
						1
						)

				RETURN
			END

			/*Commented for the DEFECT ID : ECE-425*/
			--IF EXISTS (
			--		SELECT 'x'
			--		FROM es_comp_ctrl_type_mst ctype(NOLOCK),
			--			ep_ui_control_dtl ctrl(NOLOCK)
			--		WHERE ctype.customer_name = ctrl.customer_name
			--			AND ctype.project_name = ctrl.project_name
			--			AND ctype.process_name = ctrl.process_name
			--			AND ctype.component_name = ctrl.component_name
			--			AND ctype.ctrl_type_name = ctrl.control_type
			--			AND ctype.customer_name = @engg_customer_name
			--			AND ctype.project_name = @engg_project_name
			--			AND ctype.process_name = @prc_name_tmp
			--			AND ctype.component_name = @component_name_tmp
			--			AND ctrl.control_bt_synonym = @engg_grid_grid_code
			--			AND ctype.renderas = 'MultiSelectorGrid'
			--		)
			--BEGIN
			--	RAISERROR (
			--			'Multi-Selector Grid information can not be modified.',
			--			16,
			--			1
			--			)

			--	RETURN
			--END
		END

		-- Mobility Errors 
		-- Modified for Defect id :Tech 16126 
		IF @modeflag IN (
				'I',
				'X',
				'U',
				'Y'
				)
		BEGIN
			IF charindex('~', @columnclass) > 0
			BEGIN
				IF NOT EXISTS (
						SELECT 'x'
						FROM ep_ui_mst(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @prc_name_tmp
							AND component_name = @component_name_tmp
							AND activity_name = @act_name_tmp
							AND ui_name = @ui_name_tmp
							AND devicetype IN (
								'P',
								'B',
								'T'
								)
						)
				BEGIN
					RAISERROR (
							'This column class is applicable for Phone/Tablet.',
							16,
							1
							)

					RETURN
				END

				IF NOT EXISTS (
						SELECT 'x'
						FROM es_comp_ctrl_type_mst(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @prc_name_tmp
							AND component_name = @component_name_tmp
							AND ctrl_type_name = @engg_grid_elem_type
							AND base_ctrl_type IN (
								'Link',
								'DataHyperLink'
								)
						)
				BEGIN
					RAISERROR (
							'This column class is applicable only for datahyperlink.',
							16,
							1
							)

					RETURN
				END
			END
		END

		-- Code ends
		----------Template Related Errors-----
		IF @modeflag IN (
				'U',
				'Y',
				'I',
				'X',
				'Z'
				)
		BEGIN
			IF EXISTS (
					SELECT 'x'
					FROM es_comp_ctrl_type_mst ctype(NOLOCK),
						ep_ui_control_dtl ctrl(NOLOCK)
					WHERE ctype.customer_name = ctrl.customer_name
						AND ctype.project_name = ctrl.project_name
						AND ctype.process_name = ctrl.process_name
						AND ctype.component_name = ctrl.component_name
						AND ctype.ctrl_type_name = ctrl.control_type
						AND ctype.customer_name = @engg_customer_name
						AND ctype.project_name = @engg_project_name
						AND ctype.process_name = @prc_name_tmp
						AND ctype.component_name = @component_name_tmp
						AND ctrl.control_bt_synonym = @engg_grid_grid_code
						AND ctype.base_ctrl_type = 'Assorted'
					)
				--and		ctype.IsAssorted		= 'Y')
			BEGIN
				--------Check Control types
				IF NOT EXISTS (
						SELECT 'x'
						FROM es_comp_ctrl_type_mst(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND req_no = @engg_base_req_no
							AND process_name = @prc_name_tmp
							AND component_name = @component_name_tmp
							AND ctrl_type_name = @engg_grid_elem_type
							and base_ctrl_type  in  ('EDIT','DataHyperLink') --Code uncommented for the DefectId TECH-69784
							--AND base_ctrl_type IN (
							--	'EDIT',
							--	'Link'
							--	) --11536	--TECH-69784
							AND editable_flag = 'N'
						)
				BEGIN
					RAISERROR (
							'Column type should be among DisplayOnly,DataHyperLink,AttachDocs and Images as Assorted Controls.Error in Row %i',
							16,
							4,
							@fprowno
							)

					RETURN
				END
			END

			IF EXISTS (
					SELECT 'x'
					FROM es_template_mst(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND TemplateID = @engg_col_tempid
					)
			BEGIN
				RAISERROR (
						'System	Template "%s" cannot be used as a template. Error in Row %i.',
						16,
						4,
						@engg_col_tempid,
						@fprowno
						)

				RETURN
			END

			IF isnull(@engg_col_tempid, '') = ''
				AND isnull(@col_temp_cat, '') <> ''
			BEGIN
				--Raiserror ('Template Category cannot be specified as the Template ID is blank. Error in Row %i.',16,4,@fprowno)
				--Return
				UPDATE ep_ui_grid_dtl
				SET TemplateID = 'y' -- code changed by Ganesh Prabhu S
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = @engg_grid_page_bts
					AND control_bt_synonym = @engg_grid_grid_code
					AND column_bt_synonym = @engg_grid_btsynname

				SET @engg_col_tempid = 'Y' -- code changed by Ganesh Prabhu S
			END

			IF isnull(@engg_col_tempid, '') = ''
				AND isnull(@col_temp_cat, '') <> ''
			BEGIN
				RAISERROR (
						'Template Category cannot be specified as the Template ID is blank. Error in Row %i.',
						16,
						4,
						@fprowno
						)

				RETURN
			END

			IF isnull(@engg_col_tempid, '') = ''
				AND isnull(@col_temp_specific, '') <> ''
			BEGIN
				RAISERROR (
						'Template Specification cannot be specified as the Template ID is blank. Error in Row %i.',
						16,
						4,
						@fprowno
						)

				RETURN
			END
		END

		IF (@modeflag  IN ( 'U','Y')) -- 11537
		BEGIN
			IF isnull(@col_temp_cat, '') = '' AND ISNULL(@issys_defined, 'N')  = 'N'
			BEGIN
				UPDATE ep_ui_grid_dtl
				SET TemplateID = @col_temp_cat,
					templatecategory = @col_temp_cat,
					column_type = @engg_grid_elem_type,
					modifiedby = @ctxt_user,
					IsExtension = CASE WHEN @engg_extensionreqd='1' THEN 'Y' ELSE 'N' END, --Code added for TECH-60451
					ExtensionOrder=CASE WHEN @engg_extensionreqd='1' then @engg_extensionorder END --Code added for TECH-60451
				WHERE customer_name = rtrim(@engg_customer_name)
					AND project_name = rtrim(@engg_project_name)
					AND req_no = rtrim(@engg_base_req_no)
					AND process_name = rtrim(@prc_name_tmp)
					AND component_name = rtrim(@component_name_tmp)
					AND activity_name = rtrim(@act_name_tmp)
					AND ui_name = rtrim(@ui_name_tmp)
					AND page_bt_synonym = rtrim(@engg_grid_page_bts)
					AND section_bt_synonym = rtrim(@engg_grid_sec_bts)
					AND control_bt_synonym = rtrim(@engg_grid_grid_code)
					AND column_bt_synonym = rtrim(@engg_grid_btsynname)
			END
		END

		-- TECH-21468 Code changed by Ganesh Prabhu Ends
		-- Code added for Defect Id: TECH-19347 starts
		--if exists (select 'x'
		--from	es_comp_ctrl_type_mst mst (nolock),
		--		es_comp_ctrl_type_mst_extn extn (nolock)
		--where	mst.customer_name	= rtrim(@engg_customer_name)
		--and     mst.project_name	= rtrim(@engg_project_name)
		--and		mst.process_name    = rtrim(@prc_name_tmp)  
		--and     mst.component_name  = rtrim(@component_name_tmp)
		--and     mst.ctrl_type_name	= @engg_grid_elem_type
		--and		Metadatabasedlink	= 'Y'
		--and     mst.base_ctrl_type  = 'Datahyperlink'   
		--and		mst.customer_name	= extn.customer_name  
		--and		mst.project_name	= extn.project_name  
		--and		mst.process_name	= extn.process_name
		--and		mst.component_name	= extn.component_name
		--and		mst.ctrl_type_name	= extn.ctrl_type_name)
		--begin
		--	Raiserror('Meta Data Based Link feature can be enabled for the Base Control type ''Link'' for Grid Section. Error at Row No %i',16,1,@fprowno)
		--	return
		--end
		-- Code added for Defect Id: TECH-19347 ends
		SELECT @col_temp_cat = parameter_code
		FROM ep_device_quick_code_met(NOLOCK)
		WHERE parameter_type = 'TemplateCategory'
			AND parameter_text = @col_temp_cat

		/** Hidden Controls cretaed for Edit Mask cannot be modified or deleted. 
	Code added for Defect id : TECH-20326  starts
	*/
		IF @modeflag = 'D'
		BEGIN
			IF EXISTS (
					SELECT 'x'
					FROM ep_ui_grid_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = @engg_grid_page_bts
						AND control_bt_synonym = @engg_grid_grid_code
						AND column_bt_synonym = @engg_grid_btsynname
						AND col_doc = 'System'
					)
			BEGIN
				RAISERROR (
						'System Controls cannot be Deleted.',
						16,
						1
						)

				RETURN
			END
		END

		/**  Code added for Defect id : TECH-20326 ends. */
		IF @modeflag = 'D'
		BEGIN
			IF EXISTS (
					SELECT 'x'
					FROM de_fw_des_ilbo_Service_view_datamap(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ilbocode = @ui_name_tmp
						AND page_bt_synonym = @engg_grid_page_bts
						AND control_bt_synonym = @engg_grid_btsynname
						AND controlid = 'ML' + isnull(@engg_grid_grid_code, '')
					)
			BEGIN
				INSERT INTO ep_ui_control_del_dtl (
					customer_name,
					project_name,
					process_name,
					component_name,
					activity_name,
					ui_name,
					page_bt_synonym,
					section_bt_synonym,
					control_bt_synonym,
					control_type,
					req_no,
					guid,
					Deletion_type,
					controlid
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@prc_name_tmp,
					@component_name_tmp,
					@act_name_tmp,
					@ui_name_tmp,
					@engg_grid_page_bts,
					@engg_grid_sec_bts,
					@engg_grid_btsynname,
					@tmp_ctl,
					@engg_base_req_no,
					@guid,
					'Column',
					'ML' + isnull(@engg_grid_grid_code, '')
					)

				SELECT @del_flag = 'F'

				-- Code modified for Bug Id :PNR2.0_33469 Starts    
				IF isnull(@engg_del_columns, '') = ''
				BEGIN
					SELECT @engg_del_columns = @engg_grid_btsynname
				END
				ELSE
				BEGIN
					SELECT @engg_del_columns = isnull(@engg_del_columns, '') + ', ' + @engg_grid_btsynname
				END
						--select @m_errorid = 10001    
						--Raiserror ('This Column is used in one or more Service(s). Do you want to Delete', 16,1)    
						--Return    
						-- Code modified for Bug Id :PNR2.0_33469 Ends    
			END
			ELSE
			BEGIN
				SELECT @del_flag = 'T'
			END

			/** Deleting Hidden columns created for Edit Mask when corresponding Column deletes. 
		Code added for Defect id : TECH-20326  starts
		 */
			--DELETE
			--FROM ep_component_glossary_mst_lng_extn
			--WHERE customer_name = @engg_customer_name
			--	AND project_name = @engg_project_name
			--	AND process_name = @prc_name_tmp
			--	AND component_name = @component_name_tmp
			--	AND bt_synonym_name IN (
			--		'm' + @engg_grid_btsynname + '_rd',
			--		'm' + @engg_grid_btsynname + '_rc',
			--		'm' + @engg_grid_btsynname + '_ex'
			--		)

			DELETE
			FROM ep_component_glossary_mst
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @prc_name_tmp
				AND component_name = @component_name_tmp
				AND bt_synonym_name IN (
					'm' + @engg_grid_btsynname + '_rd',
					'm' + @engg_grid_btsynname + '_rc',
					'm' + @engg_grid_btsynname + '_ex'
					)

			DELETE
			FROM ep_ui_grid_dtl
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @prc_name_tmp
				AND component_name = @component_name_tmp
				AND activity_name = @act_name_tmp
				AND ui_name = @ui_name_tmp
				AND page_bt_synonym = @engg_grid_page_bts
				AND section_bt_synonym = @engg_grid_sec_bts
				AND control_bt_synonym = @engg_grid_grid_code
				AND column_bt_synonym IN (
					'm' + @engg_grid_btsynname + '_rd',
					'm' + @engg_grid_btsynname + '_rc',
					'm' + @engg_grid_btsynname + '_ex'
					)
				AND col_doc = 'System'
				/** Code added for Defect id : TECH-20326  ends.*/
		END

		-- Code Added for PNR2.0_32228 End    
		-- Code modification for PNR2.0_21576 starts    
		DECLARE @gridlite_req engg_name

		SELECT @gridlite_req = b.gridlite_req
		FROM ep_ui_control_dtl a(NOLOCK),
			es_comp_ctrl_type_mst_vw b(NOLOCK)
		WHERE a.customer_name = rtrim(@engg_customer_name)
			AND a.project_name = rtrim(@engg_project_name)
			AND a.req_no = rtrim(@engg_base_req_no)
			AND a.process_name = rtrim(@prc_name_tmp)
			AND a.component_name = rtrim(@component_name_tmp)
			AND a.activity_name = rtrim(@act_name_tmp)
			AND a.ui_name = rtrim(@ui_name_tmp)
			AND a.page_bt_synonym = rtrim(@engg_grid_page_bts)
			AND a.section_bt_synonym = rtrim(@engg_grid_sec_bts)
			AND a.control_bt_synonym = rtrim(@engg_grid_grid_code)
			AND a.customer_name = b.customer_name
			AND a.project_name = b.project_name
			AND a.process_name = b.process_name
			AND a.component_name = b.component_name
			AND a.control_type = b.ctrl_type_name

		IF isnull(@gridlite_req, 'N') = 'Y'
		BEGIN
			IF isnull(@editable, 'N') = 'Y'
			BEGIN
				EXEC engg_error_sp 'ep_layout_sp_savgrdgdml',
					1,
					'Grid with gridlite property enabled cannot have editable column. Check RowNo <%1>',
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@fprowno,
					'',
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid > 0
					RETURN
			END

			IF isnull(@help_req, 'N') = 'Y'
			BEGIN
				EXEC engg_error_sp 'ep_layout_sp_savgrdgdml',
					1,
					'Grid with gridlite property enabled cannot have column associated with help task. Check RowNo <%1>',
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@fprowno,
					'',
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid > 0
					RETURN
			END
		END

		-- Code modification for PNR2.0_21576 ends    
		-- Added by JL   
		IF EXISTS (
				SELECT 'X'
				FROM es_comp_ctrl_type_mst_vw(NOLOCK)
				WHERE customer_name = rtrim(@engg_customer_name)
					AND project_name = rtrim(@engg_project_name)
					AND process_name = rtrim(@prc_name_tmp)
					AND component_name = rtrim(@component_name_tmp)
					-- code modfied by feroz for bug id: PNR2.0_18706    
					--   and    @tmp_ctl     =  'Edit'    
					AND ctrl_type_name = rtrim(@engg_grid_elem_type)
					AND InPlace_Calendar = 'Y'
				)
		BEGIN
			RAISERROR (
					'Inplace Calendar property is applicable only for Header controls.',
					16,
					1
					)

			RETURN
		END

		/* Code added for the Case ID:PNR2.0_32759 By Shakthi P begins*/
		IF @engg_grid_default = '1'
		BEGIN
			IF EXISTS (
					SELECT 'X'
					FROM es_comp_ctrl_type_mst_vw(NOLOCK)
					WHERE customer_name = rtrim(@engg_customer_name)
						AND project_name = rtrim(@engg_project_name)
						AND process_name = rtrim(@prc_name_tmp)
						AND component_name = rtrim(@component_name_tmp)
						AND ctrl_type_name = rtrim(@engg_grid_elem_type)
						AND base_ctrl_type IN (
							'Edit',
							'Combo'
							)
						--and   (editable_flag  = 'N' or help_req        ='Y'))--Bug ID:PNR2.0_35200    
						AND editable_flag = 'N'
					)
			BEGIN
				--Raiserror ('Default cannot be set to DisplayOnly/Help event associated columns.',16,1)    
				RAISERROR (
						'Default cannot be set to DisplayOnly columns.',
						16,
						1
						) --Bug ID:PNR2.0_35200    

				RETURN
			END
		END

		IF @engg_grid_default = '1'
		BEGIN
			IF EXISTS (
					SELECT 'X'
					FROM es_comp_ctrl_type_mst_vw(NOLOCK)
					WHERE customer_name = rtrim(@engg_customer_name)
						AND project_name = rtrim(@engg_project_name)
						AND process_name = rtrim(@prc_name_tmp)
						AND component_name = rtrim(@component_name_tmp)
						AND ctrl_type_name = rtrim(@engg_grid_elem_type)
						AND base_ctrl_type NOT IN (
							'Edit',
							'Combo'
							)
					)
			BEGIN
				RAISERROR (
						'Default can be set only to Edit/Combo columns.',
						16,
						1
						)

				RETURN
			END
		END

		/* Code added for the Case ID:PNR2.0_32759 By Shakthi P End*/
		-- Added BY Feroz For List Edit    
		IF EXISTS (
				SELECT 'X'
				FROM es_comp_ctrl_type_mst_vw(NOLOCK)
				WHERE customer_name = rtrim(@engg_customer_name)
					AND project_name = rtrim(@engg_project_name)
					AND process_name = rtrim(@prc_name_tmp)
					AND component_name = rtrim(@component_name_tmp)
					AND ctrl_type_name = rtrim(@engg_grid_elem_type)
					AND (
						listrefilltask_req = 'Y'
						OR onfocustask_req = 'Y'
						)
				)
		BEGIN
			EXEC engg_error_sp 'ep_layout_sp_savgrdgdml',
				5,
				'List Refill Task/Onfocus Task property is applicable only for Header controls',
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@fprowno,
				'',
				'',
				'',
				@m_errorid OUTPUT

			IF @m_errorid > 0
				RETURN
		END

		-- Added BY Feroz For List Edit    
		-- Added by feroz for static    
		IF EXISTS (
				SELECT 'x'
				FROM es_comp_stat_ctrl_type_mst(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND ctrl_type_name = @engg_grid_elem_type
				)
		BEGIN
			IF isnull(@engg_grid_samp_data, '') <> ''
			BEGIN
				RAISERROR (
						'sample data is not applicable for static control types',
						16,
						1
						)

				RETURN
			END

			SELECT @event_req = handle_events,
				@tmp_ctl = base_ctrl_type
			FROM es_comp_stat_ctrl_type_mst(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @prc_name_tmp
				AND component_name = @component_name_tmp
				AND ctrl_type_name = @engg_grid_elem_type
		END

		-- code added by Feroz for Ext js -- PNR2.0_1790    
		IF @modeflag IN (
				'U',
				'Y',
				'I',
				'X',
				'D'
				)
		BEGIN
			IF EXISTS (
					SELECT 'x'
					FROM ep_ui_section_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = @engg_grid_page_bts
						AND section_bt_synonym = @engg_grid_sec_bts
						AND section_type IN (
							'Text Scroller',
							'Formatted Text',
							'Report List',
							'Property Window',
							'Pivot',
							'Tree Grid',
							'IFrame',
							'RSS Feed',
							'TextType Writer',
							'Marquee Ticker',
							'EMail',
							'Bar Code'
							)
						AND req_no = @engg_base_req_no
					)
			BEGIN
				RAISERROR (
						'Insertion/Modification/Deletion not allowed  for ExtensionJs Section',
						16,
						1
						)

				RETURN
			END
		END

		-- code added by Feroz for Ext js -- PNR2.0_1790    
		/*Modification made by Muthupandi S for Bug id : PNR2.0_31754 Starts*/
		IF @modeflag = 'D'
		BEGIN
			IF EXISTS (
					SELECT 'X'
					FROM ep_ui_pageevents_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND task_onclick IN (
							SELECT task_name
							FROM ep_action_mst(NOLOCK) /*Modification made by Muthupandi S for Bug id : PNR2.0_32543*/
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @prc_name_tmp
								AND component_name = @component_name_tmp
								AND activity_name = @act_name_tmp
								AND ui_name = @ui_name_tmp
								AND page_bt_synonym = @engg_grid_page_bts
								AND primary_control_bts = @engg_grid_btsynname
							)
					)
			BEGIN
				SELECT @msg = 'The task of the grid column ' + '"' + @engg_grid_btsynname + '"' + 'is used as a PageEvent.Hence Column cannot be deleted .Check Specify Page Events Link'

				RAISERROR (
						@msg,
						16,
						1
						)

				RETURN
			END
		END

		/*Modification made by Muthupandi S for Bug id : PNR2.0_31754 Ends*/
		/*Modification made by Muthupandi S for Bug id : PNR2.0_32543 Starts*/
		IF @modeflag = 'D'
		BEGIN
			IF EXISTS (
					SELECT 'X'
					FROM ep_layout_ezeeview_sp(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = @engg_grid_page_bts
						AND Link_ControlName = @engg_grid_btsynname
					)
			BEGIN
				SELECT @msg = 'The "Link" type column ' + '"' + @engg_grid_btsynname + '"' + ' is Mapped with an ezee view sp.Hence Column cannot be deleted .Check Specify ezee view Link'

				RAISERROR (
						@msg,
						16,
						1
						)

				RETURN
			END
		END

		/*Modification made by Muthupandi S for Bug id : PNR2.0_32543 Ends*/
		IF @tmp_ctl = 'Edit'
			AND @spin_required = 'y'
		BEGIN
			RAISERROR (
					'Column Type cannot be ''%s'' since Spin Required is checked',
					16,
					1,
					@engg_grid_elem_type
					)

			RETURN
		END

		/*Check null for column number*/
		IF rtrim(@engg_grid_colno) IS NULL
		BEGIN
			EXEC engg_error_sp 'ep_layout_sp_savgrdgdml',
				9,
				'Column Number Cannot be Null at Row no<%1>',
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@fprowno,
				'',
				'',
				'',
				@m_errorid OUTPUT

			IF @m_errorid > 0
				RETURN
		END

		/*Check null for Control BT synonym*/
		IF rtrim(@engg_grid_btsynname) IS NULL
		BEGIN
			EXEC engg_error_sp 'ep_layout_sp_savgrdgdml',
				1,
				'Column(BT Synonym) Cannot be Null at Row no<%1>',
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@fprowno,
				'',
				'',
				'',
				@m_errorid OUTPUT

			IF @m_errorid > 0
				RETURN
		END

		/*Code Added For BugId : Platform_2.0.3.X_55*/
		--Code Modified For BugId : PNR2.0_9131    
		IF rtrim(@engg_grid_elem_type) = 'Label'
			OR @tmp_ctl = 'label'
		BEGIN
			EXEC engg_error_sp 'ep_layout_sp_savgrdgdml',
				1,
				'Label Control at rowno <%1> is not allowed in Multiline',
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@fprowno,
				'',
				'',
				'',
				@m_errorid OUTPUT

			IF @m_errorid > 0
				RETURN
		END

		--For each row, if Grid Column BTSynonym Name contains blank spaces , display error message.    
		SELECT @error_tmp = dbo.ep_check_spl_char(@engg_grid_btsynname)

		-- code modified by shafina on 12-May-2004 for PREVIEWENG203ACC_000058    
		IF @modeflag <> 'D'
		BEGIN
			IF @error_tmp = 1
			BEGIN
				SELECT @msg = 'BT Synonym for Row ' + convert(CHAR(5), @fprowno) + ' contains special characters.'

				EXEC ENGG_ERROR_SP 'ep_layout_sp_savgrdgdml',
					4,
					@msg,
					@CTXT_LANGUAGE,
					@CTXT_OUINSTANCE,
					@CTXT_SERVICE,
					@CTXT_USER,
					'',
					'',
					'',
					'',
					@M_ERRORID OUTPUT

				RETURN
			END

			--code modified by kiruthika for bugid:  PNR2.0_10027    
			IF rtrim(@engg_grid_btsynname) = 'HdnWFDocKey'
			BEGIN
				EXEC engg_error_sp 'ep_layout_sp_savgrdgdml',
					1,
					'Column cannot have "HdnWFDocKey" as its BT Synonym at Row no<%1>',
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@fprowno,
					'',
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid > 0
					RETURN
			END

			IF rtrim(@engg_grid_btsynname) = 'HdnWFOrgUnit'
			BEGIN
				EXEC engg_error_sp 'ep_layout_sp_savgrdgdml',
					1,
					'Column cannot have "HdnWFOrgUnit" as its BT Synonym at Row no<%1>',
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@fprowno,
					'',
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid > 0
					RETURN
			END

			--code modified by kiruthika for bugid:  PNR2.0_10027    
			-- code modified by shafina on 07-July-2004 for PREVIEWENG203ACC_000076    
			-- Length of the BT Synonym must not exceed 30 characters.    
			-- code modified by shafina on 19-Nov-2004 for PREVIEWENG203ACC_000076(Length of the BT Synonym must not exceed 28 characters)    
			IF len(rtrim(@engg_grid_btsynname)) > 28
			BEGIN
				EXEC engg_error_sp 'ep_layout_sp_savgrdgdml',
					1,
					'Length of Column(BT Synonym) cannot be greater than 28 at Row no<%1>',
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@fprowno,
					'',
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid > 0
					RETURN
			END

			-- code modified by shafina on 11-Aug-2004 for checking whether FILLER is given as BTSynonym.- PREVIEWENG203ACC_000086    
			IF rtrim(@engg_grid_btsynname) = 'FILLER'
			BEGIN
				EXEC engg_error_sp 'ep_layout_sp_savgrdgdml',
					1,
					'Column cannot have FILLER as its BT Synonym at Row no<%1>',
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@fprowno,
					'',
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid > 0
					RETURN
			END

			-- code added by Gowrisankar for PNR2.0_4942 on 13-Dec-2005    
			IF EXISTS (
					SELECT 'x'
					FROM re_quick_code_mst(NOLOCK)
					WHERE quick_code_type = 'RE_CONTEXT'
						AND quick_code_value = @engg_grid_btsynname
					)
			BEGIN
				SELECT @msg = 'Default dataitems can not be defined as Column BT Synonym at Row No:' + cast(@fprowno AS VARCHAR(10))

				EXEC engg_error_sp ep_layout_sp_savgrdgdml,
					'1',
					@msg,
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					'',
					'',
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid <> 0
					RETURN
			END -- code added by Gowrisankar for PNR2.0_4942 on 13-Dec-2005    
		END

		IF @modeflag IN (
				'X',
				'I'
				)
		BEGIN
			-- code modified by shafina on 25-Aug-2004 for PREVIEWENG203ACC_000093 ( When a control bt synonym / column bt synonym is repeated within a UI , it's length must not exceed 24 characters.)    
			IF EXISTS (
					SELECT 'X'
					FROM ep_ui_control_dtl(NOLOCK)
					WHERE customer_name = rtrim(@engg_customer_name)
						AND project_name = rtrim(@engg_project_name)
						AND req_no = rtrim(@engg_base_req_no)
						AND process_name = rtrim(@prc_name_tmp)
						AND component_name = rtrim(@component_name_tmp)
						AND activity_name = rtrim(@act_name_tmp)
						AND ui_name = rtrim(@ui_name_tmp)
						AND control_bt_synonym = rtrim(@engg_grid_btsynname)
					
					UNION
					
					SELECT 'X'
					FROM ep_ui_grid_dtl(NOLOCK)
					WHERE customer_name = rtrim(@engg_customer_name)
						AND project_name = rtrim(@engg_project_name)
						AND req_no = rtrim(@engg_base_req_no)
						AND process_name = rtrim(@prc_name_tmp)
						AND component_name = rtrim(@component_name_tmp)
						AND activity_name = rtrim(@act_name_tmp)
						AND ui_name = rtrim(@ui_name_tmp)
						AND column_bt_synonym = rtrim(@engg_grid_btsynname)
					)
				AND len(@engg_grid_btsynname) > 24
			BEGIN
				EXEC engg_error_sp 'ep_layout_sp_savgrdgdml',
					2,
					'Column (BT Synonym):<%2> length must not exceed 24 at row:<%1>',
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@fprowno,
					@engg_grid_btsynname,
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid > 0
					RETURN
			END

			/*Check duplication of Column BT synonym within the Activity/UI/Page*/
			-- code commented by shafina on 16-Nov-2004 for PREVIEWENG203SYS_000178 (Unable to delete the controls in specifylayout. Platform has accepted same control name for 
			-- both Page Name and controls. It didnt validate while creating, but on deletion it is validating)    
			/*  if exists (    
select 'X'    
from ep_ui_page_dtl (nolock)    
where customer_name = rtrim(@engg_customer_name)    
and  project_name = rtrim(@engg_project_name)    
and  req_no   = rtrim(@engg_base_req_no)    
and  process_name = rtrim(@prc_name_tmp)    
and  component_name = rtrim(@component_name_tmp)    
and  activity_name = rtrim(@act_name_tmp)    
and  ui_name   = rtrim(@ui_name_tmp)    
--    and  page_bt_synonym = rtrim(@engg_grid_page_bts)    
and  page_bt_synonym = rtrim(@engg_grid_btsynname)    
)    
begin    
exec engg_error_sp 'ep_layout_sp_savgrdgdml',2,'Column (BT Synonym):<%2> already exists as a Page(BT Synonym) at row:<%1>',    
@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,    
@fprowno,@engg_grid_btsynname,'','',@m_errorid output    
if @m_errorid > 0    
return    
end*/
			/*Check duplication of Column BT synonym within the Activity/UI/Page/Section*/
			--code added by Sangeetha L for the bug id : Platform_2.0.3.X_265    
			--bug Descr :I have generated a service with a parameter "Name".    
			--The service got generated without any errors.But,when I tried to change the flow direction ,It is throwing an error    
			IF len(ltrim(rtrim(@engg_grid_btsynname))) > 0
			BEGIN
				IF EXISTS (
						SELECT 'x'
						FROM de_meta_vbkeywords(NOLOCK)
						WHERE keyword = @engg_grid_btsynname
						)
				BEGIN
					-- Code modified by Chanheetha N A on 29-Nov-2005 for the BUG ID:PNR2.0_4824    
					SET @msg = 'The Keyword "' + @engg_grid_btsynname + '" not allowed as a Column Name'

					EXEC engg_error_sp 'ep_layout_sp_savgrdgdml',
						102,
						@msg,
						@ctxt_language,
						@ctxt_ouinstance,
						@ctxt_service,
						@ctxt_user,
						NULL,
						NULL,
						NULL,
						NULL,
						@m_errorid OUTPUT

					IF @m_errorid <> 0
						RETURN
				END
			END

			IF EXISTS (
					SELECT 'X'
					FROM ep_ui_section_dtl(NOLOCK)
					WHERE customer_name = rtrim(@engg_customer_name)
						AND project_name = rtrim(@engg_project_name)
						AND req_no = rtrim(@engg_base_req_no)
						AND process_name = rtrim(@prc_name_tmp)
						AND component_name = rtrim(@component_name_tmp)
						AND activity_name = rtrim(@act_name_tmp)
						AND ui_name = rtrim(@ui_name_tmp)
						AND page_bt_synonym = rtrim(@engg_grid_page_bts)
						AND section_bt_synonym = rtrim(@engg_grid_btsynname)
					)
			BEGIN
				EXEC engg_error_sp 'ep_layout_sp_savgrdgdml',
					3,
					'Column (BT Synonym):<%2> already exists as a Section(BT Synonym) at row:<%1>',
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@fprowno,
					@engg_grid_btsynname,
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid > 0
					RETURN
			END

			/*Check duplication of Column BT synonym within the Activity/UI/Page/Section/Control*/
			IF EXISTS (
					SELECT 'X'
					FROM ep_ui_control_dtl(NOLOCK)
					WHERE customer_name = rtrim(@engg_customer_name)
						AND project_name = rtrim(@engg_project_name)
						AND req_no = rtrim(@engg_base_req_no)
						AND process_name = rtrim(@prc_name_tmp)
						AND component_name = rtrim(@component_name_tmp)
						AND activity_name = rtrim(@act_name_tmp)
						AND ui_name = rtrim(@ui_name_tmp)
						AND page_bt_synonym = rtrim(@engg_grid_page_bts)
						AND control_bt_synonym = rtrim(@engg_grid_btsynname)
					)
			BEGIN
				EXEC engg_error_sp 'ep_layout_sp_savgrdgdml',
					4,
					'Column (BT Synonym):<%2> already exists as a Control(BT Synonym) at row:<%1>',
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@fprowno,
					@engg_grid_btsynname,
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid > 0
					RETURN
			END

			/*Check duplication of Column BT synonym within the Activity/UI/Page/Section/Grid*/
			IF EXISTS (
					SELECT 'X'
					FROM ep_ui_grid_dtl(NOLOCK)
					WHERE customer_name = rtrim(@engg_customer_name)
						AND project_name = rtrim(@engg_project_name)
						AND req_no = rtrim(@engg_base_req_no)
						AND process_name = rtrim(@prc_name_tmp)
						AND component_name = rtrim(@component_name_tmp)
						AND activity_name = rtrim(@act_name_tmp)
						AND ui_name = rtrim(@ui_name_tmp)
						AND page_bt_synonym = rtrim(@engg_grid_page_bts)
						--    and  section_bt_synonym <>rtrim(@engg_grid_sec_bts)    
						AND column_bt_synonym = rtrim(@engg_grid_btsynname)
					)
			BEGIN
				EXEC engg_error_sp 'ep_layout_sp_savgrdgdml',
					5,
					'Column (BT Synonym):<%2> already exists as a Grid(BT Synonym) at row:<%1>',
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@fprowno,
					@engg_grid_btsynname,
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid > 0
					RETURN
			END

			-- code modified by shafina on 01-Sep-2004 for PREVIEWENG203ACC_000095 (When a new BT synonym is entered , it must be checked whether it exists as a hidden view already.)    
			IF EXISTS (
					SELECT 'X'
					FROM de_hidden_view(NOLOCK)
					WHERE customer_name = rtrim(@engg_customer_name)
						AND project_name = rtrim(@engg_project_name)
						AND process_name = rtrim(@prc_name_tmp)
						AND component_name = rtrim(@component_name_tmp)
						AND activity_name = rtrim(@act_name_tmp)
						AND ui_name = rtrim(@ui_name_tmp)
						AND page_name = rtrim(@engg_grid_page_bts)
						AND hidden_view_bt_synonym = rtrim(@engg_grid_btsynname)
					)
			BEGIN
				EXEC engg_error_sp 'ep_layout_sp_savgrdgdml',
					3,
					'Column (BT Synonym):<%2> already exists as a Hidden View(BT Synonym) at row:<%1>',
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@fprowno,
					@engg_grid_btsynname,
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid > 0
					RETURN
			END

			-- code modified by shafina on 10-Dec-2004 for PREVIEWENG203ACC_000095 (When a new BT synonym is entered , it must be checked whether it exists as a scratch variable already.)    
			IF EXISTS (
					SELECT 'X'
					FROM de_scratch_variable(NOLOCK)
					WHERE customer_name = rtrim(@engg_customer_name)
						AND project_name = rtrim(@engg_project_name)
						AND process_name = rtrim(@prc_name_tmp)
						AND component_name = rtrim(@component_name_tmp)
						AND activity_name = rtrim(@act_name_tmp)
						AND ui_name = rtrim(@ui_name_tmp)
						AND page_name = rtrim(@engg_grid_page_bts)
						AND scratch_name = rtrim(@engg_grid_btsynname)
					)
			BEGIN
				EXEC engg_error_sp 'ep_layout_sp_savgrdgdml',
					3,
					'Column (BT Synonym):<%2> already exists as a User Defined Scratch Variable at row:<%1>',
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@fprowno,
					@engg_grid_btsynname,
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid > 0
					RETURN
			END

			-- code modified by shafina on 06-Dec-2004 for PREVIEWPF204ACC_000001 (Default Scratch variables must not be used as user defined bt synonyms.)    
			IF EXISTS (
					SELECT 'x'
					FROM de_scratch_variables_sys(NOLOCK)
					WHERE btsynonym = @engg_grid_btsynname
					)
				-- code modified by shafina on 22-Dec-2004 for PREVIEWENG203ACC_000115 (Modeflag must not be allowed to be entered as bt synonym.)    
				OR @engg_grid_btsynname = 'Modeflag'
			BEGIN
				SELECT @msg = 'Column Bt Synonym ' + @engg_grid_btsynname + ' already exists as a Default Scratch Variable'

				EXEC engg_error_sp 'en_comp_sp_savcon_hsv',
					7,
					@msg,
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					'',
					'',
					'',
					'',
					@m_errorid OUTPUT

				RETURN
			END
		END /*End of Modeflag X and I*/

		/*Checking for Dependencies on Deletion in Traversal*/
		IF @modeflag IN ('D')
		BEGIN
			/*Code modified by vijay on 26/12/03 for combo change on grid details*/
			/*Checking for Dependencies on Deletion in Enum*/
			IF EXISTS (
					SELECT 'X'
					FROM ep_enum_value_dtl(NOLOCK)
					WHERE customer_name = rtrim(@engg_customer_name)
						AND project_name = rtrim(@engg_project_name)
						AND req_no = rtrim(@engg_base_req_no)
						AND process_name = rtrim(@prc_name_tmp)
						AND component_name = rtrim(@component_name_tmp)
						AND activity_name = rtrim(@act_name_tmp)
						AND ui_name = rtrim(@ui_name_tmp)
						AND page_bt_synonym = rtrim(@engg_grid_page_bts)
						AND section_bt_synonym = rtrim(@engg_grid_sec_bts)
						AND control_bt_synonym = rtrim(@engg_grid_btsynname)
					)
			BEGIN
				EXEC engg_error_sp 'ep_layout_sp_savgrdgdml',
					6,
					'Column (BT Synonym):<%2> at row:<%1> is in use in Enumeration',
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@fprowno,
					@engg_grid_btsynname,
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid > 0
					RETURN
			END

			/*Code modified by vijay on 26/12/03 for combo change on grid details*/
			IF EXISTS (
					SELECT 'X'
					FROM ep_ui_traversal_dtl(NOLOCK)
					WHERE customer_name = rtrim(@engg_customer_name)
						AND project_name = rtrim(@engg_project_name)
						AND req_no = rtrim(@engg_base_req_no)
						AND process_name = rtrim(@prc_name_tmp)
						AND component_name = rtrim(@component_name_tmp)
						AND activity_name = rtrim(@act_name_tmp)
						AND ui_name = rtrim(@ui_name_tmp)
						AND page_bt_synonym = rtrim(@engg_grid_page_bts)
						AND section_bt_synonym = rtrim(@engg_grid_sec_bts)
						AND control_bt_synonym = rtrim(@engg_grid_btsynname)
						-- modified by shafina on 19-Apr-2004 for PREVIEWENG203ACC_000038    
						AND isnull(linked_component, '') <> ''
						AND isnull(linked_activity, '') <> ''
						AND isnull(linked_ui, '') <> ''
					)
			BEGIN
				EXEC engg_error_sp 'ep_layout_sp_savgrdgdml',
					7,
					'Column (BT Synonym):<%2> at row:<%1> is in use in Traversal',
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@fprowno,
					@engg_grid_btsynname,
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid > 0
					RETURN
			END

			/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P begin*/
			IF EXISTS (
					SELECT 'X'
					FROM es_comp_ctrl_type_mst(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND ctrl_type_name = @engg_grid_elem_type
						AND base_ctrl_type = 'Listedit'
					)
			BEGIN
				IF EXISTS (
						SELECT 'X'
						FROM ep_listedit_control_map(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @prc_name_tmp
							AND component_name = @component_name_tmp
							AND activity_name = @act_name_tmp
							AND ui_name = @ui_name_tmp
							AND listedit_synonym = @engg_grid_btsynname
						)
				BEGIN
					EXEC engg_error_sp 'ep_layout_sp_savgrdgdml',
						6,
						'Column (BT Synonym):<%2> at row:<%1> is in use in Listedit',
						@ctxt_language,
						@ctxt_ouinstance,
						@ctxt_service,
						@ctxt_user,
						@fprowno,
						@engg_grid_btsynname,
						'',
						'',
						@m_errorid OUTPUT

					IF @m_errorid > 0
						RETURN
				END

				IF EXISTS (
						SELECT 'X'
						FROM ep_listedit_column_dtl(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @prc_name_tmp
							AND component_name = @component_name_tmp
							AND activity_name = @act_name_tmp
							AND ui_name = @ui_name_tmp
							AND listedit_synonym = @engg_grid_btsynname
						)
				BEGIN
					EXEC engg_error_sp 'ep_layout_sp_savgrdgdml',
						6,
						'Column (BT Synonym):<%2> at row:<%1> is in use in Enumeration',
						@ctxt_language,
						@ctxt_ouinstance,
						@ctxt_service,
						@ctxt_user,
						@fprowno,
						@engg_grid_btsynname,
						'',
						'',
						@m_errorid OUTPUT

					IF @m_errorid > 0
						RETURN
				END

				IF EXISTS (
						SELECT 'X'
						FROM ep_resolvelist_data_map(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @prc_name_tmp
							AND component_name = @component_name_tmp
							AND activity_name = @act_name_tmp
							AND ui_name = @ui_name_tmp
							AND listedit_synonym = @engg_grid_btsynname
						)
				BEGIN
					EXEC engg_error_sp 'ep_layout_sp_savgrdgdml',
						6,
						'Column (BT Synonym):<%2> at row:<%1> is in use in Enumeration',
						@ctxt_language,
						@ctxt_ouinstance,
						@ctxt_service,
						@ctxt_user,
						@fprowno,
						@engg_grid_btsynname,
						'',
						'',
						@m_errorid OUTPUT

					IF @m_errorid > 0
						RETURN
				END
			END

			IF EXISTS (
					SELECT 'X'
					FROM es_comp_ctrl_type_mst(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND ctrl_type_name = @engg_grid_elem_type
						--and  base_ctrl_type   ='edit'    
						AND associatedlist_req = 'y'
					)
			BEGIN
				IF EXISTS (
						SELECT 'X'
						FROM ep_listedit_control_map(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @prc_name_tmp
							AND component_name = @component_name_tmp
							AND activity_name = @act_name_tmp
							AND ui_name = @ui_name_tmp
							AND page_bt_synonym = @engg_grid_page_bts
							AND mapped_bt_synonym = @engg_grid_btsynname
						)
				BEGIN
					EXEC engg_error_sp 'ep_layout_sp_savgrdgdml',
						6,
						'Column (BT Synonym):<%2> at row:<%1> is in use in Enumeration',
						@ctxt_language,
						@ctxt_ouinstance,
						@ctxt_service,
						@ctxt_user,
						@fprowno,
						@engg_grid_btsynname,
						'',
						'',
						@m_errorid OUTPUT

					IF @m_errorid > 0
						RETURN
				END

				IF EXISTS (
						SELECT 'X'
						FROM ep_resolvelist_data_map(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @prc_name_tmp
							AND component_name = @component_name_tmp
							AND activity_name = @act_name_tmp
							AND ui_name = @ui_name_tmp
							AND page_bt_synonym = @engg_grid_page_bts
							AND mapped_bt_synonym = @engg_grid_btsynname
						)
				BEGIN
					EXEC engg_error_sp 'ep_layout_sp_savgrdgdml',
						6,
						'Column (BT Synonym):<%2> at row:<%1> is in use in Enumeration',
						@ctxt_language,
						@ctxt_ouinstance,
						@ctxt_service,
						@ctxt_user,
						@fprowno,
						@engg_grid_btsynname,
						'',
						'',
						@m_errorid OUTPUT

					IF @m_errorid > 0
						RETURN
				END
			END

			IF EXISTS (
					SELECT 'X'
					FROM ep_resolvelist_data_map(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND mapped_bt_syn_page = @engg_grid_page_bts
						AND data_mapped_synonym = @engg_grid_btsynname
					)
			BEGIN
				EXEC engg_error_sp 'ep_layout_sp_savgrdgdml',
					6,
					'Column (BT Synonym):<%2> at row:<%1> is in use in Enumeration',
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@fprowno,
					@engg_grid_btsynname,
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid > 0
					RETURN
			END
					/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P End*/
		END /*End for mode flag 'D'*/

		/*Checking for Dependencies on Deletion in Links*/
		/*if exists ( select 'X'    
from engg_subscription_dtl (nolock)    
where customer_name  = rtrim(@engg_customer_name)    
and project_name  = rtrim(@engg_project_name)    
and req_no   = rtrim(@engg_req_no)    
and process_name  = rtrim(@prc_name_tmp)    
and component_name  = rtrim(@component_name_tmp)    
and activity_name  = rtrim(@act_name_tmp)    
and ui_name   = rtrim(@ui_name_tmp)    
--    and page_bt_synonym  = rtrim(@engg_grid_page_bts) --will not be in Sub. dtl    
--    and section_bt_synonym = rtrim(@engg_grid_sec_bts) --will not be in Sub. dtl    
and control_bt_synonym = rtrim(@engg_grid_btsynname)    
)    
begin    
exec engg_error_sp 'ep_layout_sp_savgrdgdml',8,'Column (BT Synonym):<%2> at row:<%1> is in use in Links',    
@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,    
@fprowno,@engg_grid_btsynname,'','',@m_errorid output    
if @m_errorid > 0    
return    
end    
*/
		/*Checking for Dependencies on Deletion in Task*/
		/* if exists ( select 'X'    
from engg_action_mst (nolock)    
where customer_name  = rtrim(@engg_customer_name)    
and project_name  = rtrim(@engg_project_name)    
and req_no   = rtrim(@engg_req_no)    
and process_name  = rtrim(@prc_name_tmp)    
and component_name  = rtrim(@component_name_tmp)    
and activity_name  = rtrim(@act_name_tmp)    
and ui_name   = rtrim(@ui_name_tmp)    
--    and page_bt_synonym  = rtrim(@engg_grid_page_bts)    
--    and section_bt_synonym = rtrim(@engg_grid_sec_bts)    
and triggering_ctrl_bt_synonym = rtrim(@engg_grid_btsynname)    
)    
begin    
exec engg_error_sp 'ep_layout_sp_savgrdgdml',9,'Column (BT Synonym):<%2> at row:<%1> is in use in Task',    
@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,    
@fprowno,@engg_grid_btsynname,'','',@m_errorid output    
if @m_errorid > 0    
return    
end    
*/
		/*Check Control Type for hidden controls existence*/
		/*Getting the Component Parameter*/
		SELECT @allow_hdn_ctrl = rtrim(current_value)
		FROM es_comp_param_mst_vw(NOLOCK)
		WHERE customer_name = rtrim(@engg_customer_name)
			AND project_name = rtrim(@engg_project_name)
			AND req_no = rtrim(@engg_base_req_no)
			AND process_name = rtrim(@prc_name_tmp)
			AND component_name = rtrim(@component_name_tmp)
			AND param_category = 'ADDHDNCTRL'
			AND param_type = 'CONFIG'

		/*Getting the Visible Flag*/
		SELECT @vis_flag = rtrim(visisble_flag)
		FROM es_comp_ctrl_type_mst_vw(NOLOCK)
		WHERE customer_name = rtrim(@engg_customer_name)
			AND project_name = rtrim(@engg_project_name)
			AND req_no = rtrim(@engg_base_req_no)
			AND process_name = rtrim(@prc_name_tmp)
			AND component_name = rtrim(@component_name_tmp)
			AND ctrl_type_name = rtrim(@engg_grid_elem_type)

		--Kanagavel  
		--For each row, if column BTSynonym Name already exists for another Page or Section or control or Grid Control, display error message.  
		IF @modeflag IN (
				'I',
				'X'
				)
		BEGIN
			IF EXISTS (
					SELECT 'A'
					FROM ep_ui_page_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_base_req_no
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = @engg_grid_btsynname
					)
			BEGIN
				SELECT @msg = 'Synonym ' + @engg_grid_btsynname + ' already exists in the UI as a Page Bt Synonym'

				RAISERROR (
						@msg,
						16,
						1
						)

				RETURN
			END
		END

		IF @modeflag IN (
				'I',
				'X'
				)
		BEGIN
			IF EXISTS (
					SELECT 'A'
					FROM ep_ui_section_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_base_req_no
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND section_bt_synonym = @engg_grid_btsynname
					)
			BEGIN
				SELECT @msg = 'Synonym ' + @engg_grid_btsynname + ' already exists in the UI as a Section Bt Synonym'

				RAISERROR (
						@msg,
						16,
						1
						)

				RETURN
			END
		END

		IF @modeflag IN (
				'I',
				'X'
				)
		BEGIN
			IF EXISTS (
					SELECT 'A'
					FROM ep_ui_control_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_base_req_no
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND control_bt_synonym = @engg_grid_btsynname
					)
			BEGIN
				SELECT @msg = 'Synonym ' + @engg_grid_btsynname + ' already exists in the UI as a control Bt Synonym'

				RAISERROR (
						@msg,
						16,
						1
						)

				RETURN
			END
		END

		IF @modeflag IN (
				'I',
				'X'
				)
		BEGIN
			IF EXISTS (
					SELECT 'A'
					FROM ep_ui_grid_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_base_req_no
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND column_bt_synonym = @engg_grid_btsynname
					)
			BEGIN
				SELECT @msg = 'Synonym ' + @engg_grid_btsynname + ' already exists in the UI as a control Bt Synonym'

				RAISERROR (
						@msg,
						16,
						1
						)

				RETURN
			END
		END

		/* Hidden Control = 'Do not allow modifications' and Visible Flag = 'N'*/
		IF upper(@allow_hdn_ctrl) = 'DO NOT ALLOW MODIFICATIONS'
			AND upper(@vis_flag) = 'N'
		BEGIN
			EXEC engg_error_sp 'ep_layout_sp_savgrdgdml',
				13,
				'Row <%1> has a hidden control. Hidden controls are not allowed to be created',
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@fprowno,
				'',
				'',
				'',
				@m_errorid OUTPUT

			IF @m_errorid > 0
				RETURN
		END

		/*Check correctness of Visible Length*/
		IF @engg_grid_vis_length < 0
		BEGIN
			EXEC engg_error_sp 'ep_layout_sp_savgrdgdml',
				10,
				'Visible Length:<%2> is not valid for row:<%1>',
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@fprowno,
				@engg_grid_vis_length,
				'',
				'',
				@m_errorid OUTPUT

			IF @m_errorid > 0
				RETURN
		END

		/*Check repetitions in Columns Only on Insertion*/
		IF @modeflag IN (
				'X',
				'I'
				)
		BEGIN
			IF EXISTS (
					SELECT 'X'
					FROM ep_ui_grid_dtl(NOLOCK)
					WHERE customer_name = rtrim(@engg_customer_name)
						AND project_name = rtrim(@engg_project_name)
						AND req_no = rtrim(@engg_base_req_no)
						AND process_name = rtrim(@prc_name_tmp)
						AND component_name = rtrim(@component_name_tmp)
						AND activity_name = rtrim(@act_name_tmp)
						AND ui_name = rtrim(@ui_name_tmp)
						AND page_bt_synonym = rtrim(@engg_grid_page_bts)
						AND section_bt_synonym = rtrim(@engg_grid_sec_bts)
						AND control_bt_synonym = rtrim(@engg_grid_grid_code)
						AND column_no = @engg_grid_colno
					)
			BEGIN
			
				EXEC engg_error_sp 'ep_layout_sp_savgrdgdml',
					12,
					'There are duplicates in column numbers',
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					'',
					'',
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid > 0
					RETURN
			END
		END /*End for Mode Flag X,I*/

		/*Check whether column number is negative.ELse display error message*/
		IF @engg_grid_colno < 1
		BEGIN
			EXEC engg_error_sp 'ep_layout_sp_savgrdgdml',
				14,
				'Column Number <%1> cannot be Negative or Zero at row <%2>',
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@engg_grid_colno,
				@fprowno,
				'',
				'',
				@m_errorid OUTPUT

			IF @m_errorid > 0
				RETURN
		END

		--validations for template id
		-- Added for PLF2.0_14096 Starts
		IF @modeflag IN (
				'I',
				'X',
				'U',
				'Y'
				)
			AND @col_temp_cat IS NOT NULL -- 11537 TECH-21468
		BEGIN
			IF NOT EXISTS (
					SELECT 'x'
					FROM es_comp_ctrl_type_mst(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_base_req_no
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND ctrl_type_name = @engg_grid_elem_type
						AND base_ctrl_type IN ('EDIT')
						AND editable_flag = 'N'
					
					UNION
					
					SELECT 'x'
					FROM es_comp_ctrl_type_mst(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_base_req_no
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND ctrl_type_name = @engg_grid_elem_type
						AND base_ctrl_type IN (
							'Link',
							'DataHyperlink'
							)
					)
				--and editable_flag  = 'N'
			BEGIN
				RAISERROR (
						'Template ID is applicable only for displayonly and datahyperlink',
						16,
						1
						)

				RETURN
			END
		END

		--Code added by 14469 for TECH-73216 starts
		--IF ISNULL(@modeflag,'')	IN ('I','X') 
		--AND EXISTS (SELECT 'X' 
		--FROM ep_ui_page_dtl (NOLOCK)
		--WHERE  customer_name	= @engg_customer_name
		--AND	   project_name		= @engg_project_name
		--AND	   req_no			= @engg_base_req_no
		--AND	   page_bt_synonym  = @engg_grid_btsynname
		--UNION
		--SELECT 'X' 
		--FROM ep_ui_section_dtl (NOLOCK)
		--WHERE  customer_name	= @engg_customer_name
		--AND	   project_name		= @engg_project_name
		--AND	   req_no			= @engg_base_req_no
		--AND	   section_bt_synonym  = @engg_grid_btsynname
		--UNION
		--SELECT 'X' 
		--FROM ep_ui_control_dtl (NOLOCK)
		--WHERE  customer_name	= @engg_customer_name
		--AND	   project_name		= @engg_project_name
		--AND	   req_no			= @engg_base_req_no
		--AND	   control_bt_synonym  = @engg_grid_btsynname
		--UNION
		--SELECT 'X' 
		--FROM ep_ui_grid_dtl (NOLOCK)
		--WHERE  customer_name	= @engg_customer_name
		--AND	   project_name		= @engg_project_name
		--AND	   req_no			= @engg_base_req_no
		--AND	   column_bt_synonym  = @engg_grid_btsynname
		--UNION
		--SELECT 'X' 
		--FROM de_hidden_view (NOLOCK)
		--WHERE  customer_name	= @engg_customer_name
		--AND	   project_name		= @engg_project_name
		--AND	   control_bt_synonym = @engg_grid_btsynname)
		--BEGIN
		--	RAISERROR ('Btsynonym name should be unique for Customer Project level.',16,1)
		--	RETURN
		--END
		----Code added by 14469 for TECH-73216 ends
		declare @ctrlid		engg_name
		--TECH-73996
				SELECT @ctrlid = control_id
				FROM ep_ui_control_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_base_req_no
				AND process_name = @prc_name_tmp
				AND component_name = @component_name_tmp
				AND activity_name = @act_name_tmp
				AND ui_name = @ui_name_tmp
				AND page_bt_synonym = @engg_grid_page_bts
				AND section_bt_synonym = @engg_grid_sec_bts
				AND control_bt_synonym = @engg_grid_grid_code

		IF ISNULL(@modeflag,'')	IN	('U','Y') AND @engg_grd_visible	=	'No'
				BEGIN
						IF EXISTS ( SELECT 'X'
									FROM	ep_ui_state_column_dtl WITH(NOLOCK)
									WHERE	customer_name		=	@engg_customer_name
									AND		project_name		=	@engg_project_name
									AND		req_no				=	@engg_base_req_no
									AND		process_name		=	@prc_name_tmp
									AND		component_name		=	@component_name_tmp
									AND		activity_name		=	@act_name_tmp
									AND		ui_name				=	@ui_name_tmp
									AND		page_bt_synonym		=	@engg_grid_page_bts
									AND		section_bt_synonym	=	@engg_grid_sec_bts
									AND		control_bt_synonym	=	@engg_grid_grid_code
									AND		column_bt_synonym	=	@engg_grid_btsynname )
							BEGIN
									RAISERROR('Selected column ''%s'' cannot be made as hidden.Since it is involved in RT State.Error at rowno: %i.',16,1,@engg_grid_btsynname,@fprowno)
									RETURN
							END

				IF	EXISTS (	SELECT 'X'
									FROM	iruledb..fw_req_ilbo_rule_property_stmt a(nolock)
									JOIN	iruledb..fw_req_ilbo_rule_property_value b(nolock)
									ON		a.CustomerName	=	b.customername
									AND		a.projectname	=	b.projectname
									AND		a.ComponentName	=	b.ComponentName
									AND		a.ILBOCode		=	b.ILBOCode
									AND		a.StmtID		=	b.StmtID
									JOIN	iruledb..inf_req_rule_ilbo_grid_view_details c (nolock)
									ON		a.customername	=	c.customername
									AND		a.projectname	=	c.projectname
									AND		a.ComponentName	=	c.ComponentName
									AND		a.ilbocode		=	c.ilbocode
									--AND		a.controlid		=	c.controlid
									AND		a.GridName		=	c.GridName
									AND		a.viewname		=	c.viewname
									WHERE	c.CustomerName	=	@engg_customer_name
									AND		c.ProjectName		=	@engg_project_name
									AND		c.ProcessName		=	@prc_name_tmp
									AND		c.ComponentName		=	@component_name_tmp
									AND		c.ActivityName		=	@act_name_tmp
									AND		c.ILBOCode			=	@ui_name_tmp
									AND		c.TabName			=	@engg_grid_page_bts
									AND		c.SectionName		=	@engg_grid_sec_bts
									AND		c.gridname			=	@ctrlid
									AND		c.BTSynonym			=	@engg_grid_btsynname
									AND		b.PropertyName		=	'Hide'
									AND		b.PropertyValue		=	'true' )
									
						BEGIN
							RAISERROR('Selected column ''%s'' cannot be made as hidden.Since it is involved in iRule State.Error at rowno: %i.',16,1,@engg_grid_btsynname,@fprowno)
							RETURN
						END
			END	
		--TECH-73996

		----TECH-71262  --TECH-75230
		--Code commneted for TECH-73996 starts
		--IF EXISTS
		--(SELECT 'X' 
		-- FROM ep_ui_mst WITH (NOLOCK)
		-- WHERE	customer_name	= rtrim(@engg_customer_name)
		-- AND	project_name	= rtrim(@engg_project_name)
		-- AND	req_no			= rtrim(@engg_base_req_no)
		-- AND	process_name	= rtrim(@prc_name_tmp)
		-- AND	component_name	= rtrim(@component_name_tmp)
		-- AND	activity_name	= rtrim(@act_name_tmp)
		-- AND	ui_name			= rtrim(@ui_name_tmp)
		-- AND	DeviceType		= 'P')
		-- BEGIN
		--	IF EXISTS(
		--	SELECT  'X'
		--	FROM	ep_ui_control_dtl ctl (NOLOCK)
		--	JOIN	es_comp_ctrl_type_mst_extn extn (NOLOCK)
		--	ON	    ctl.customer_name		= extn.customer_name			
		--	AND		ctl.project_name		= extn.project_name		
		--	AND		ctl.process_name		= extn.process_name		
		--	AND		ctl.component_name		= extn.component_name		
		--	AND     ctl.control_type		= extn.ctrl_type_name
		--	JOIN	es_comp_ctrl_type_mst mst (NOLOCK)
		--	ON		extn.customer_name		= mst.customer_name	
		--	AND		extn.project_name		= mst.project_name	
		--	AND		extn.process_name		= mst.process_name	
		--	AND		extn.component_name		= mst.component_name	
		--	AND		extn.ctrl_type_name		= mst.ctrl_type_name	
		--	WHERE	ctl.customer_name		= RTRIM(@engg_customer_name)
		--	AND     ctl.project_name		= RTRIM(@engg_project_name)
		--	AND     ctl.process_name		= RTRIM(@prc_name_tmp)
		--	AND     ctl.component_name		= RTRIM(@component_name_tmp)
		--	AND		ctl.activity_name		= RTRIM(@act_name_tmp)
		--	AND		ctl.ui_name				= RTRIM(@ui_name_tmp)
		--	AND		ctl.page_bt_synonym		= RTRIM(@engg_grid_page_bts)
		--	AND		ctl.section_bt_synonym	= RTRIM(@engg_grid_sec_bts)
		--	AND		ctl.control_bt_synonym	= RTRIM(@engg_grid_grid_code)
		--	AND		extn.base_ctrl_type		= 'GRID'
		--	AND     ISNULL(extn.IsMobile,'N') = 'N'
		--	AND		ISNULL(extn.IsList,'N') = 'N'
		--	AND     ISNULL(mst.DataGrid,'N') = 'N')
		--	BEGIN
		--		RAISERROR ('Grid control should have ''Ismobile'' attribute for MobileUI.',16,1)
		--	END
		--END
		--Code commneted for TECH-73996 ends

		--IF EXISTS(
		--SELECT  'X'
		--FROM	ep_ui_control_dtl ctl (NOLOCK)
		--JOIN	es_comp_ctrl_type_mst_extn extn (NOLOCK)
		--ON	    ctl.customer_name		= extn.customer_name			
		--AND		ctl.project_name		= extn.project_name		
		--AND		ctl.process_name		= extn.process_name		
		--AND		ctl.component_name		= extn.component_name		
		--AND     ctl.control_type		= extn.ctrl_type_name	
		--WHERE	ctl.customer_name		= @engg_customer_name
		--AND     ctl.project_name		= @engg_project_name
		--AND     ctl.process_name		= @prc_name_tmp
		--AND     ctl.component_name		= @component_name_tmp
		--AND	    ctl.control_bt_synonym  = @engg_grid_grid_code
		--AND     extn.IsMobile			= 'Y')
		--BEGIN
		--		IF NOT EXISTS(
		--		SELECT 'X'
		--		FROM es_comp_ctrl_type_mst mst WITH (NOLOCK)
		--		WHERE mst.customer_name		= @engg_customer_name
		--		AND   mst.project_name		= @engg_project_name
		--		AND   mst.process_name		= @prc_name_tmp
		--		AND   mst.component_name	= @component_name_tmp
		--		AND   mst.ctrl_type_name	= @engg_grid_elem_type
		--		AND   mst.base_ctrl_type	IN ('DataHyperlink','Edit')
		--		UNION
		--		SELECT 'X'
		--		FROM es_comp_ctrl_type_mst mst WITH (NOLOCK)
		--		WHERE mst.customer_name		= @engg_customer_name
		--		AND   mst.project_name		= @engg_project_name
		--		AND   mst.process_name		= @prc_name_tmp
		--		AND   mst.component_name	= @component_name_tmp
		--		AND   mst.ctrl_type_name	= @engg_grid_elem_type
		--		AND   mst.base_ctrl_type    = 'Edit'
		--		AND   mst.editable_flag		= 'N'
		--		)
		--		BEGIN
		--		RAISERROR ('Only Edit, Displayonly and Datahyperlink controls are allowed for ''Mobile Grid''.',16,1)
		--		RETURN
		--		END
		--END

		--Code commented for TECH-72114 starts
		--IF EXISTS(
		--SELECT  'X'
		--FROM	ep_ui_control_dtl ctl (NOLOCK)
		--JOIN	es_comp_ctrl_type_mst_extn extn (NOLOCK)
		--ON	    ctl.customer_name		= extn.customer_name			
		--AND		ctl.project_name		= extn.project_name		
		--AND		ctl.process_name		= extn.process_name		
		--AND		ctl.component_name		= extn.component_name		
		--AND     ctl.control_type		= extn.ctrl_type_name	
		--WHERE	ctl.customer_name		= @engg_customer_name
		--AND     ctl.project_name		= @engg_project_name
		--AND     ctl.process_name		= @prc_name_tmp
		--AND     ctl.component_name		= @component_name_tmp
		--AND	    ctl.control_bt_synonym  = @engg_grid_grid_code
		--AND     extn.IsList				= 'Y')
		--BEGIN
		--		IF NOT EXISTS(
		--		SELECT 'X'
		--		FROM es_comp_ctrl_type_mst mst WITH (NOLOCK)
		--		WHERE mst.customer_name		= @engg_customer_name
		--		AND   mst.project_name		= @engg_project_name
		--		AND   mst.process_name		= @prc_name_tmp
		--		AND   mst.component_name	= @component_name_tmp
		--		AND   mst.ctrl_type_name	= @engg_grid_elem_type
		--		AND   mst.base_ctrl_type	= 'DataHyperlink'
		--		UNION
		--		SELECT 'X'
		--		FROM es_comp_ctrl_type_mst mst WITH (NOLOCK)
		--		WHERE mst.customer_name		= @engg_customer_name
		--		AND   mst.project_name		= @engg_project_name
		--		AND   mst.process_name		= @prc_name_tmp
		--		AND   mst.component_name	= @component_name_tmp
		--		AND   mst.ctrl_type_name	= @engg_grid_elem_type
		--		AND   mst.base_ctrl_type    = 'Edit'
		--		AND   mst.editable_flag		= 'N'
		--		)
		--		BEGIN
		--		RAISERROR ('Only Displayonly and Datahyperlink controls are allowed for ''List Control''.',16,1)
		--		RETURN
		--		END
		--END
		----TECH-75230
		--Code commented for TECH-72114 ends

		--Added for PLF2.0_14096 Ends 
		--	IF @engg_grid_elem_type not in ('Button','CheckBox','Combo','DataHyperLink','Edit','Grid','Link') and @engg_col_tempid is not null
		--	begin
		--		raiserror('Template Id can be provided only for controls having base control type as Button,CheckBox,Combo,DataHyperLink,Edit,Grid,Link.Select a valid Control type and Proceed',16,1)
		--		return
		--	end
		--end
		--validations for template id
		-- Added for PLF2.0_14096 Starts
		/*
if @modeflag = 'D'  
begin  
		If exists (Select 'x' from ep_phone_grid_dtl(nolock)
				where	customer_name		= @engg_customer_name
				and		project_name		= @engg_project_name
				and		process_name		= rtrim(@prc_name_tmp)    
				and		component_name		= rtrim(@component_name_tmp)    
				and		activity_name		= rtrim(@act_name_tmp)    
				and		ui_name				= rtrim(@ui_name_tmp)    
				and 	page_bt_synonym		= rtrim(@engg_grid_page_bts)    
				and 	section_bt_synonym	= rtrim(@engg_grid_sec_bts)    
				and 	control_bt_synonym	= rtrim(@engg_grid_grid_code) 
				and		column_bt_synonym  	= rtrim(@engg_grid_btsynname))
		or exists (Select 'x' from ep_tablet_grid_dtl(nolock)
				where	customer_name		= @engg_customer_name
				and		project_name		= @engg_project_name
				and		process_name		= rtrim(@prc_name_tmp)    
				and		component_name		= rtrim(@component_name_tmp)    
				and		activity_name		= rtrim(@act_name_tmp)    
				and		ui_name				= rtrim(@ui_name_tmp)    
				and 	page_bt_synonym		= rtrim(@engg_grid_page_bts)    
				and 	section_bt_synonym	= rtrim(@engg_grid_sec_bts)    
				and 	control_bt_synonym	= rtrim(@engg_grid_grid_code)   
				and		column_bt_synonym  	= rtrim(@engg_grid_btsynname))
		Begin
		    
			insert into ep_ui_control_del_dtl    
			(customer_name,  project_name,  process_name,  component_name,  activity_name,  ui_name,  page_bt_synonym,    
			section_bt_synonym, control_bt_synonym, control_type,  req_no,    guid, Deletion_type, controlid)    
			Values    
			(@engg_customer_name, @engg_project_name,@prc_name_tmp,   @component_name_tmp,   @act_name_tmp,   @ui_name_tmp,  @engg_grid_page_bts,    
			@engg_grid_sec_bts,  @engg_grid_btsynname, @tmp_ctl, @engg_base_req_no,    @guid, 'Column', 'ML' + isnull(@engg_grid_grid_code,''))    
			    
			select @del_flag_ph = 'F'    

			If isnull(@engg_del_columns,'') = ''    
			Begin    
			select @engg_del_columns = @engg_grid_btsynname    
			End    
			Else    
			Begin    
			select @engg_del_columns = isnull(@engg_del_columns,'') + ', ' + @engg_grid_btsynname    
			End    
		End	 
		Else  
		Begin  
			select @del_flag_ph = 'T'  
		End  
End   */
		DECLARE @GridToForm engg_name

		IF @modeflag IN (
				'U',
				'Y'
				)
		BEGIN
			-- modified b shafina on 22-jan-2004 to check for updation in controltypes   
			SELECT @renderas = RenderAs
			FROM ep_ui_control_dtl a(NOLOCK),
				es_comp_ctrl_type_mst b(NOLOCK)
			WHERE a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.control_type = b.ctrl_type_name
				AND a.customer_name = @engg_customer_name
				AND a.project_name = @engg_project_name
				AND a.process_name = @prc_name_tmp
				AND a.component_name = @component_name_tmp
				AND a.activity_name = @act_name_tmp
				AND a.ui_name = @ui_name_tmp
				AND a.page_bt_synonym = rtrim(@engg_grid_page_bts)
				AND a.section_bt_synonym = rtrim(@engg_grid_sec_bts)
				AND a.control_bt_synonym = rtrim(@engg_grid_grid_code)

			--select  @GridToForm			= coalesce(GridToForm,'N') ,
			--		@col_transform_as	= isnull(column_Transformas,'')
			--from ep_ui_grid_dtl (nolock)    
			--where customer_name   = @engg_customer_name    
			--and  project_name   = @engg_project_name    
			--and  process_name   = @prc_name_tmp    
			--and  component_name   = @component_name_tmp    
			--and  activity_name = @act_name_tmp    
			--and  ui_name     = @ui_name_tmp    
			--and  page_bt_synonym   = rtrim(@engg_grid_page_bts)    
			--and  section_bt_synonym  = rtrim(@engg_grid_sec_bts)    
			--and  control_bt_synonym  = rtrim(@engg_grid_grid_code)    
			--and  column_bt_synonym  = rtrim(@engg_grid_btsynname)    
			--and  req_no     = @engg_base_req_no    
			SELECT @base_ctrl_type_tmp = base_ctrl_type
			FROM es_comp_ctrl_type_mst_vw(NOLOCK)
			WHERE customer_name = rtrim(@engg_customer_name)
				AND project_name = rtrim(@engg_project_name)
				AND process_name = rtrim(@prc_name_tmp)
				AND component_name = rtrim(@component_name_tmp)
				AND ctrl_type_name = rtrim(@engg_grid_elem_type)
				AND req_no = rtrim(@engg_base_req_no)

			IF @FormEnabled = 1
				SELECT @GridToForm = 'Y'

			IF lower(@base_ctrl_type_tmp) NOT IN (
					'edit',
					'checkbox',
					'combo'
					)
				AND @renderas = 'GridtoForm'
				AND @GridToForm = 'Y'
			BEGIN
				RAISERROR (
						'''Grid to Form'' attribute can be enabled for ''Edit, Check Box & Combo'' Controls. Error in Row %i',
						16,
						4,
						@fprowno
						)

				RETURN
			END

			IF isnull(@GridToForm, '') = 'Y'
				AND isnull(@col_transform_as, '') = ''
			BEGIN
				RAISERROR (
						'''Transform As'' is mandatory for ''Grid To Form'' enabled columns.',
						16,
						1
						)

				RETURN
			END

			--if  not  exists(select 'x'
			--		from es_comp_ctrl_type_mst(nolock)
			--		where customer_name = @engg_customer_name
			--		and project_name = @engg_project_name
			--		and req_no = @engg_base_req_no
			--		and process_name = @prc_name_tmp
			--		and component_name = @component_name_tmp
			--		and ctrl_type_name = @engg_grid_elem_type 				
			--		and base_ctrl_type  = 'EDIT'
			--		and editable_flag  = 'Y'
			--		) and ( isnull(@col_transform_as,'') not in ('Edit','SliderHorizontal','SliderRainbow','SliderStar','SliderVertical'))
			--Begin
			--	Raiserror('''Edit,SliderHorizontal,SliderRainbow,SliderStar,SliderVertical'' can be selected for ''Transform  As''.Error in Row %i',16, 4,@fprowno)
			--	Return
			--End
			--		if  not  exists(select 'x'
			--		from es_comp_ctrl_type_mst(nolock)
			--		where customer_name = @engg_customer_name
			--		and project_name = @engg_project_name
			--		and req_no = @engg_base_req_no
			--		and process_name = @prc_name_tmp
			--		and component_name = @component_name_tmp
			--		and ctrl_type_name = @engg_grid_elem_type 				
			--		and base_ctrl_type  = 'EDIT'
			--		and editable_flag  = 'N'
			--		) and ( isnull(@col_transform_as,'') not in ('Edit','SliderRainbow','SliderStar'))
			--Begin
			--	Raiserror('''Edit,SliderRainbow,SliderStar'' can be selected for ''Transform  As''.Error in Row %i',16, 4,@fprowno)
			--	Return
			--End
			--if  not  exists(select 'x'
			--		from es_comp_ctrl_type_mst(nolock)
			--		where customer_name = @engg_customer_name
			--		and project_name = @engg_project_name
			--		and req_no = @engg_base_req_no
			--		and process_name = @prc_name_tmp
			--		and component_name = @component_name_tmp
			--		and ctrl_type_name = @engg_grid_elem_type 				
			--		and base_ctrl_type  = 'Combo'				
			--		) and ( isnull(@col_transform_as,'') not in ('Edit','RadioButton'))
			--Begin
			--	Raiserror('''Edit,RadioButton'' can be selected for ''Transform  As''.Error in Row %i',16, 4,@fprowno)
			--	Return
			--End
			--if  not  exists(select 'x'
			--		from es_comp_ctrl_type_mst(nolock)
			--		where customer_name = @engg_customer_name
			--		and project_name = @engg_project_name
			--		and req_no = @engg_base_req_no
			--		and process_name = @prc_name_tmp
			--		and component_name = @component_name_tmp
			--		and ctrl_type_name = @engg_grid_elem_type 				
			--		and base_ctrl_type  = 'CheckBox'				
			--		) and ( isnull(@col_transform_as,'') not in ('ToggleButton'))
			--Begin
			--	Raiserror('''ToggleButton'' can be selected for ''Transform  As''.Error in Row %i',16, 4,@fprowno)
			--	Return
			--End
			IF EXISTS (
					SELECT 'x'
					FROM ep_ui_traversal_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = rtrim(@engg_grid_page_bts)
						AND section_bt_synonym = rtrim(@engg_grid_sec_bts)
						AND control_bt_synonym = rtrim(@engg_grid_btsynname)
						AND req_no = @engg_base_req_no
						AND linked_component <> ''
						AND linked_activity <> ''
						AND linked_ui <> ''
					)
			BEGIN
				IF @tmp_control_type <> @engg_grid_elem_type
				BEGIN
					-- code modified by shafina on 16-Aug-2004 for PREVIEWENG203ACC_000089 ( Eventhough Help Details exists in Traversal table , it is allowing to change the datatype og help control if the base control type is same )    
					SELECT @old_help_req = help_req
					FROM es_comp_ctrl_type_mst(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND ctrl_type_name = @tmp_control_type

					IF @base_ctrl_type_tmp <> @tmp_ctl
					BEGIN
						SELECT @msg = 'Control Type cannot be updated as this control exists as a link or help'

						EXEC engg_error_sp 'engg_layout_sp_savctlcnml',
							9,
							@msg,
							@ctxt_language,
							@ctxt_ouinstance,
							@ctxt_service,
							@ctxt_user,
							'',
							'',
							'',
							'',
							@m_errorid OUTPUT

						IF @m_errorid <> 0
							RETURN
					END

					IF @old_help_req <> @help_req
					BEGIN
						SELECT @msg = 'Control Type cannot be updated as this control exists as a help'

						EXEC engg_error_sp 'engg_layout_sp_savgrdgdml',
							9,
							@msg,
							@ctxt_language,
							@ctxt_ouinstance,
							@ctxt_service,
							@ctxt_user,
							'',
							'',
							'',
							'',
							@m_errorid OUTPUT

						IF @m_errorid <> 0
							RETURN
					END
				END

				/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P begin*/
				IF @tmp_control_type <> @engg_grid_elem_type
				BEGIN
					IF EXISTS (
							SELECT 'X'
							FROM es_comp_ctrl_type_mst(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @prc_name_tmp
								AND component_name = @component_name_tmp
								AND ctrl_type_name = @tmp_control_type
								AND base_ctrl_type = 'Listedit'
							)
					BEGIN
						IF EXISTS (
								SELECT 'X'
								FROM ep_listedit_control_map(NOLOCK)
								WHERE customer_name = @engg_customer_name
									AND project_name = @engg_project_name
									AND process_name = @prc_name_tmp
									AND component_name = @component_name_tmp
									AND activity_name = @act_name_tmp
									AND ui_name = @ui_name_tmp
									AND listedit_synonym = @engg_grid_btsynname
								)
						BEGIN
							RAISERROR (
									'Control Type cannot be updated as this control exists as a Listedit',
									16,
									1
									)

							RETURN
						END

						IF EXISTS (
								SELECT 'X'
								FROM ep_listedit_column_dtl(NOLOCK)
								WHERE customer_name = @engg_customer_name
									AND project_name = @engg_project_name
									AND process_name = @prc_name_tmp
									AND component_name = @component_name_tmp
									AND activity_name = @act_name_tmp
									AND ui_name = @ui_name_tmp
									AND listedit_synonym = @engg_grid_btsynname
								)
						BEGIN
							RAISERROR (
									'Control Type cannot be updated as this control exists as a Listedit',
									16,
									1
									)

							RETURN
						END

						IF EXISTS (
								SELECT 'X'
								FROM ep_resolvelist_data_map(NOLOCK)
								WHERE customer_name = @engg_customer_name
									AND project_name = @engg_project_name
									AND process_name = @prc_name_tmp
									AND component_name = @component_name_tmp
									AND activity_name = @act_name_tmp
									AND ui_name = @ui_name_tmp
									AND listedit_synonym = @engg_grid_btsynname
								)
						BEGIN
							RAISERROR (
									'Control Type cannot be updated as this control exists as a Listedit',
									16,
									1
									)

							RETURN
						END
					END

					IF EXISTS (
							SELECT 'X'
							FROM es_comp_ctrl_type_mst(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @prc_name_tmp
								AND component_name = @component_name_tmp
								AND ctrl_type_name = @tmp_control_type
								--and  base_ctrl_type   ='edit'    
								AND associatedlist_req = 'y'
							)
					BEGIN
						IF EXISTS (
								SELECT 'X'
								FROM ep_listedit_control_map(NOLOCK)
								WHERE customer_name = @engg_customer_name
									AND project_name = @engg_project_name
									AND process_name = @prc_name_tmp
									AND component_name = @component_name_tmp
									AND activity_name = @act_name_tmp
									AND ui_name = @ui_name_tmp
									AND page_bt_synonym = @engg_grid_page_bts
									AND mapped_bt_synonym = @engg_grid_btsynname
								)
						BEGIN
							RAISERROR (
									'Control Type cannot be updated as this control exists as a Listedit',
									16,
									1
									)

							RETURN
						END

						IF EXISTS (
								SELECT 'X'
								FROM ep_resolvelist_data_map(NOLOCK)
								WHERE customer_name = @engg_customer_name
									AND project_name = @engg_project_name
									AND process_name = @prc_name_tmp
									AND component_name = @component_name_tmp
									AND activity_name = @act_name_tmp
									AND ui_name = @ui_name_tmp
									AND page_bt_synonym = @engg_grid_page_bts
									AND mapped_bt_synonym = @engg_grid_btsynname
								)
						BEGIN
							RAISERROR (
									'Control Type cannot be updated as this control exists as a Listedit',
									16,
									1
									)

							RETURN
						END
					END

					IF EXISTS (
							SELECT 'X'
							FROM ep_resolvelist_data_map(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @prc_name_tmp
								AND component_name = @component_name_tmp
								AND activity_name = @act_name_tmp
								AND ui_name = @ui_name_tmp
								AND mapped_bt_syn_page = @engg_grid_page_bts
								AND data_mapped_synonym = @engg_grid_btsynname
							)
					BEGIN
						RAISERROR (
								'Control Type cannot be updated as this control exists as a Listedit',
								16,
								1
								)

						RETURN
					END
				END
						/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P End*/
			END

			/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P begin*/
			IF @modeflag IN (
					'U',
					'Y',
					'I',
					'X'
					)
			BEGIN
				IF EXISTS (
						SELECT 'X'
						FROM ep_ui_control_dtl a(NOLOCK),
							es_comp_ctrl_type_mst b(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.process_name = @prc_name_tmp
							AND a.component_name = @component_name_tmp
							AND a.activity_name = @act_name_tmp
							AND a.ui_name = @ui_name_tmp
							AND a.control_bt_synonym = @engg_grid_btsynname
							AND a.customer_name = b.customer_name
							AND a.project_name = b.project_name
							AND a.process_name = b.process_name
							AND a.component_name = b.component_name
							AND a.control_type = b.ctrl_type_name
							AND b.base_ctrl_type = 'Listedit'
						)
				BEGIN
					RAISERROR (
							'Control Type cannot be updated as this control exists as a Listedit control.Unmap and proceed',
							16,
							1
							)

					RETURN
				END

				IF EXISTS (
						SELECT 'X'
						FROM ep_ui_grid_dtl a(NOLOCK),
							es_comp_ctrl_type_mst b(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.process_name = @prc_name_tmp
							AND a.component_name = @component_name_tmp
							AND a.activity_name = @act_name_tmp
							AND a.ui_name = @ui_name_tmp
							AND a.column_bt_synonym = @engg_grid_btsynname
							AND a.customer_name = b.customer_name
							AND a.project_name = b.project_name
							AND a.process_name = b.process_name
							AND a.component_name = b.component_name
							AND a.column_type = b.ctrl_type_name
							AND b.base_ctrl_type = 'Listedit'
						)
				BEGIN
					RAISERROR (
							'Control Type cannot be updated as this control exists as a Listedit control.Unmap and proceed',
							16,
							1
							)

					RETURN
				END
			END

			/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P End*/
			IF EXISTS (
					SELECT 'x'
					FROM ep_enum_value_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = rtrim(@engg_grid_page_bts)
						AND section_bt_synonym = rtrim(@engg_grid_sec_bts)
						AND control_bt_synonym = rtrim(@engg_grid_btsynname)
						AND req_no = @engg_base_req_no
					)
			BEGIN
				IF @tmp_control_type <> @engg_grid_elem_type
				BEGIN
					IF @base_ctrl_type_tmp <> @tmp_ctl
					BEGIN
						SELECT @msg = 'Control Type cannot be updated as this control exists as a combo control'

						EXEC engg_error_sp 'engg_layout_sp_savctlcnml',
							9,
							@msg,
							@ctxt_language,
							@ctxt_ouinstance,
							@ctxt_service,
							@ctxt_user,
							'',
							'',
							'',
							'',
							@m_errorid OUTPUT

						IF @m_errorid <> 0
							RETURN
					END
				END
			END

			/*Not allowing to Modify the Column BT Synonym Name*/
			IF EXISTS (
					SELECT 'X'
					FROM ep_ui_grid_dtl(NOLOCK)
					WHERE customer_name = rtrim(@engg_customer_name)
						AND project_name = rtrim(@engg_project_name)
						AND req_no = rtrim(@engg_base_req_no)
						AND process_name = rtrim(@prc_name_tmp)
						AND component_name = rtrim(@component_name_tmp)
						AND activity_name = rtrim(@act_name_tmp)
						AND ui_name = rtrim(@ui_name_tmp)
						AND page_bt_synonym = rtrim(@engg_grid_page_bts)
						AND section_bt_synonym = rtrim(@engg_grid_sec_bts)
						AND control_bt_synonym = rtrim(@engg_grid_grid_code)
						AND column_bt_synonym = rtrim(@engg_grid_btsynname)
					)
			BEGIN
				--modified by shafina on 22-jan-2004    
				-- to delete the rows in traversal table when control_type is updated..    
				IF EXISTS (
						SELECT 'x'
						FROM ep_ui_traversal_dtl(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @prc_name_tmp
							AND component_name = @component_name_tmp
							AND activity_name = @act_name_tmp
							AND ui_name = @ui_name_tmp
							AND page_bt_synonym = rtrim(@engg_grid_page_bts)
							AND section_bt_synonym = rtrim(@engg_grid_sec_bts)
							AND control_bt_synonym = rtrim(@engg_grid_btsynname)
							AND req_no = @engg_base_req_no
							AND isnull(linked_component, '') = ''
							AND isnull(linked_activity, '') = ''
							AND isnull(linked_ui, '') = ''
						)
				BEGIN
					SELECT @tmp_control_type = column_type
					FROM ep_ui_grid_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = rtrim(@engg_grid_page_bts)
						AND section_bt_synonym = rtrim(@engg_grid_sec_bts)
						AND control_bt_synonym = rtrim(@engg_grid_grid_code)
						AND column_bt_synonym = rtrim(@engg_grid_btsynname)
						AND req_no = @engg_base_req_no

					IF @tmp_control_type <> @engg_grid_elem_type
					BEGIN
						-- code modified by shafina on 20-Nov-2004 for Primary key modification in traversal tables.    
						DELETE
						FROM ep_ui_traversal_dtl
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND req_no = @engg_base_req_no
							AND process_name = @prc_name_tmp
							AND component_name = @component_name_tmp
							AND activity_name = @act_name_tmp
							AND ui_name = @ui_name_tmp
							AND page_bt_synonym = @engg_grid_page_bts
							AND section_bt_synonym = @engg_grid_sec_bts
							AND control_bt_synonym = @engg_grid_btsynname
							AND isnull(linked_component, '') = ''
							AND isnull(linked_activity, '') = ''
							AND isnull(linked_ui, '') = ''
					END
				END
			

				IF @issys_defined = 'Y'
				BEGIN
				
					UPDATE ep_ui_grid_dtl SET 
									column_no		= @engg_grid_colno,
									visible_length	= rtrim(@engg_grid_vis_length),					
									visible			= @engg_grd_visible,
									IsExtension		= CASE WHEN @engg_extensionreqd='1' THEN 'Y' ELSE 'N' END, --Code added for TECH-60451
									ExtensionOrder	= CASE WHEN @engg_extensionreqd='1' THEN @engg_extensionorder END  ---Code added for TECH-60451

					WHERE	customer_name			= rtrim(@engg_customer_name)
					AND		project_name			= rtrim(@engg_project_name)
					AND		req_no					= rtrim(@engg_base_req_no)
					AND		process_name			= rtrim(@prc_name_tmp)
					AND		component_name			= rtrim(@component_name_tmp)
					AND		activity_name			= rtrim(@act_name_tmp)
					AND		ui_name					= rtrim(@ui_name_tmp)
					AND		page_bt_synonym			= rtrim(@engg_grid_page_bts)
					AND		section_bt_synonym		= rtrim(@engg_grid_sec_bts)
					AND		control_bt_synonym		= rtrim(@engg_grid_grid_code)
					AND		column_bt_synonym		= rtrim(@engg_grid_btsynname)
				END
				ELSE
				BEGIN

				UPDATE ep_ui_grid_dtl
				SET column_type = rtrim(@engg_grid_elem_type),
					column_no = @engg_grid_colno,
					visible_length = rtrim(@engg_grid_vis_length),
					proto_tooltip = rtrim(@engg_grid_tooltip),
					sample_data = rtrim(@engg_grid_samp_data),
					col_doc = rtrim(@engg_grid_doc),
					Set_User_Pref = @user_pref, -- modified  for  PNR2.0_23541    
					Default_required = @grid_def, --Code Modified for PNR2.0_30869    
					-- code added by shafina on 07-Sep-2004 for PREVIEWENG203ACC_000098 (Modified Date must be updated.)    
					modifiedby = @ctxt_user,
					modifieddate = getdate(),
					columnclass = @columnclass,
					--ColumnHdrClass = @columnheaderclass, 
					TemplateID = @engg_col_tempid,
					forcefit = CASE @forcefit
						WHEN 1
							THEN 'Y'
						ELSE 'N'
						END,
					treecolumn = CASE @engg_tree_column
						WHEN 1
							THEN 'Y'
						ELSE 'N'
						END, --11537
					visible = @engg_grd_visible,
					TemplateCategory = @col_temp_cat,
					TemplateSpecific = @col_temp_specific,
					AssociateControl = @col_associate_ctrl, --Code Added for TECH-71262
 					RowExpander = CASE @RowExpander
						WHEN 1
							THEN 'Y'
						ELSE 'N'
						END,
					GridtoForm = CASE @FormEnabled
						WHEN 1
							THEN 'Y'
						ELSE 'N'
						END,
					--Ranjitha
					Column_class_ext6 = @col_class_ext6,
					icon_position = @col_icon_position,
					icon_class = @col_icon_class,
					column_Transformas = @col_transform_as
				WHERE customer_name = rtrim(@engg_customer_name)
					AND project_name = rtrim(@engg_project_name)
					AND req_no = rtrim(@engg_base_req_no)
					AND process_name = rtrim(@prc_name_tmp)
					AND component_name = rtrim(@component_name_tmp)
					AND activity_name = rtrim(@act_name_tmp)
					AND ui_name = rtrim(@ui_name_tmp)
					AND page_bt_synonym = rtrim(@engg_grid_page_bts)
					AND section_bt_synonym = rtrim(@engg_grid_sec_bts)
					AND control_bt_synonym = rtrim(@engg_grid_grid_code)
					AND column_bt_synonym = rtrim(@engg_grid_btsynname)
				END

				SET @forcefit = CASE @forcefit
						WHEN 1
							THEN 'Y' -- Added by Kanagavel to avoid new insertion in forcefit column as 1/0
						ELSE 'N'
						END
				SET @engg_tree_column = CASE @engg_tree_column
						WHEN 1
							THEN 'Y' -- Added by Kanagavel to avoid new insertion in forcefit column as 1/0
						ELSE 'N'
						END


					DECLARE @vorder engg_name
					DECLARE @horder engg_name
					DECLARE @newcontrol engg_name
					DECLARE @ControlDoc ENGG_DOCUMENTATION
					DECLARE @newctrlprefix engg_name
				--Code Modification for PNR2.0_30869 starts    
				--Code commented for TECH-73996 starts (grid default)
				----IF @engg_grid_default = 1
				----BEGIN
				----	DECLARE @vorder engg_name
				----	DECLARE @horder engg_name
				----	DECLARE @newcontrol engg_name
				----	DECLARE @ControlDoc ENGG_DOCUMENTATION
				----	DECLARE @newctrlprefix engg_name

				----	SELECT @newcontrol = @engg_grid_grid_code + 'SetDef'

				----	IF len(@newcontrol) > 57
				----		SELECT @newcontrol = left(@engg_grid_grid_code, 51) + 'SetDef'

				----	EXEC engg_gen_prefix_id @engg_customer_name,
				----		@engg_project_name,
				----		@component_name_tmp,
				----		@act_name_tmp,
				----		@ui_name_tmp,
				----		@engg_grid_grid_code,
				----		'C',
				----		6,
				----		@newctrlprefix OUTPUT

				----	SELECT @newctrlprefix = left(@newctrlprefix, 5) + 'd'

				----	EXEC ep_controlid_generation @engg_customer_name,
				----		@engg_project_name,
				----		@engg_base_req_no,
				----		@prc_name_tmp,
				----		@component_name_tmp,
				----		@act_name_tmp,
				----		@ui_name_tmp,
				----		@newcontrol,
				----		'Edit',
				----		'N',
				----		'N',
				----		@control_id OUTPUT

				----	SELECT @ControlDoc = 'Grid Defaulting Control for the Grid' + @engg_grid_grid_code
				--Code commented for TECH-73996 ends (grid default)

					--Commented for PLF2.0_06660    
					--If not exists ( select 'x'    
					--from ep_component_glossary_mst (nolock)    
					--where customer_name = @engg_customer_name    
					--and  project_name = @engg_project_name    
					--and  process_name    = @prc_name_tmp    
					--and  component_name  = @component_name_tmp    
					--and  bt_synonym_name = @newcontrol    
					--)    
					--begin    
					-- exec ep_component_glossary_mst_sp_ins @ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user, @engg_customer_name,    
					--   @engg_project_name, @engg_base_req_no, @prc_name_tmp, @component_name_tmp, @newcontrol, null, 'Char', 60,    
					--   'Grid Defaulting Control', @ControlDoc, '', 'U', '', '', 1, @engg_req_no, @m_errorid out 
					-- if @m_errorid <> 0    
					--  return    
					--end    
					-- Code Added for the Bug ID:PNR2.0_35200 starts
					--Code commented for TECH-73996 starts (grid default)
					----IF NOT EXISTS (
					----		SELECT 'x'
					----		FROM ep_ui_section_dtl(NOLOCK)
					----		WHERE customer_name = @engg_customer_name
					----			AND project_name = @engg_project_name
					----			AND process_name = @prc_name_tmp
					----			AND component_name = @component_name_tmp
					----			AND activity_name = @act_name_tmp
					----			AND ui_name = @ui_name_tmp
					----			AND page_bt_synonym = '[mainscreen]'
					----			AND section_bt_synonym = 'PrjhdnSection'
					----		)
					----BEGIN
					----	--- Tech-406 parameter mismatch
					----	EXEC ep_ui_section_dtl_sp_ins @ctxt_language,
					----		@ctxt_ouinstance,
					----		@ctxt_service,
					----		@ctxt_user,
					----		@engg_customer_name,
					----		@engg_project_name,
					----		@engg_base_req_no,
					----		@prc_name_tmp,
					----		@component_name_tmp,
					----		@act_name_tmp,
					----		@ui_name_tmp,
					----		'[mainscreen]',
					----		'PrjhdnSection',
					----		'N',
					----		'N',
					----		'N',
					----		'Left',
					----		'',
					----		100,
					----		1,
					----		'PrjhdnSection',
					----		1,
					----		'Main',
					----		'',
					----		'',
					----		'',
					----		'',
					----		'',
					----		'',
					----		'',
					----		'',
					----		@engg_req_no,
					----		'',
					----		'',
					----		'',
					----		'',
					----		'',
					----		'',
					----		'',
					----		'',
					----		'',
					----		'',
					----		'',
					----		'', --Tech-70687
					----		'','','','','','', --Tech-70687
					----		'', --Tech-72114
					----		@m_errorid OUTPUT

					----	IF @m_errorid <> 0
					----		RETURN
					----END

					------ Code Added for the Bug ID:PNR2.0_35200 ends    
					----IF EXISTS (
					----		SELECT 'x'
					----		FROM ep_ui_control_dtl(NOLOCK)
					----		WHERE customer_name = @engg_customer_name
					----			AND project_name = @engg_project_name
					----			AND process_name = @prc_name_tmp
					----			AND component_name = @component_name_tmp
					----			AND activity_name = @act_name_tmp
					----			AND ui_name = @ui_name_tmp
					----			AND page_bt_synonym = '[mainscreen]'
					----			AND section_bt_synonym = 'PrjhdnSection'
					----		)
					----BEGIN
					----	SELECT @horder = isnull(max(horder), 0)
					----	FROM ep_ui_control_dtl(NOLOCK)
					----	WHERE customer_name = @engg_customer_name
					----		AND project_name = @engg_project_name
					----		AND process_name = @prc_name_tmp
					----		AND component_name = @component_name_tmp
					----		AND activity_name = @act_name_tmp
					----		AND ui_name = @ui_name_tmp
					----		AND page_bt_synonym = '[mainscreen]'
					----		AND section_bt_synonym = 'PrjhdnSection'
					----END
					----ELSE
					----	SELECT @horder = 1

					----IF EXISTS (
					----		SELECT 'x'
					----		FROM ep_ui_control_dtl(NOLOCK)
					----		WHERE customer_name = @engg_customer_name
					----			AND project_name = @engg_project_name
					----			AND process_name = @prc_name_tmp
					----			AND component_name = @component_name_tmp
					----			AND activity_name = @act_name_tmp
					----			AND ui_name = @ui_name_tmp
					----			AND page_bt_synonym = '[mainscreen]'
					----			AND section_bt_synonym = 'PrjhdnSection'
					----		)
					----BEGIN
					----	SELECT @vorder = isnull(max(vorder), 0) + 1
					----	FROM ep_ui_control_dtl(NOLOCK)
					----	WHERE customer_name = @engg_customer_name
					----		AND project_name = @engg_project_name
					----		AND process_name = @prc_name_tmp
					----		AND component_name = @component_name_tmp
					----		AND activity_name = @act_name_tmp
					----		AND ui_name = @ui_name_tmp
					----		AND page_bt_synonym = '[mainscreen]'
					----		AND section_bt_synonym = 'PrjhdnSection'
					----END
					----ELSE
					----	SELECT @vorder = 1
							--Commented for PLF2.0_06660    
							--If not exists ( select 'x'    
							--from  ep_ui_control_dtl (nolock)    
							--where customer_name  = @engg_customer_name    
							--and  project_name  = @engg_project_name    
							--and  process_name  = @prc_name_tmp    
							--and  component_name  = @component_name_tmp    
							--and  activity_name  = @act_name_tmp    
							--and  ui_name    = @ui_name_tmp    
							--and  page_bt_synonym  = '[mainscreen]'    
							--and  section_bt_synonym = 'PrjhdnSection'    
							--and  control_bt_synonym = @newcontrol    
							-- )    
							--Begin    
							-- Exec ep_ui_control_dtl_sp_ins @ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user, @engg_customer_name, @engg_project_name,    
							--@engg_base_req_no, @prc_name_tmp, @component_name_tmp, @act_name_tmp, @ui_name_tmp, '[mainscreen]',    
							--'PrjhdnSection', @newcontrol, @control_id, 'HiddenEdit', 20, @horder, @vorder, 1, 0, 0, '', 'Grid Defaulting',    
							--'Grid Defaulting', @newctrlprefix, '', '%', '%',   null, null,  null, null, 0, null,    
							--1, @engg_req_no, null, 0, @m_errorid out    
							--End    
			----	END
				--Code commented for TECH-73996 ends (grid default)

				--Code Modification for PNR2.0_30869 ends    
				IF EXISTS (
						SELECT 'x' -- code addition by Gopinath for the Call Id PNR2.0_24645 S begins    
						FROM ep_ui_state_column_dtl(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND req_no = @engg_base_req_no
							AND process_name = @prc_name_tmp
							AND component_name = @component_name_tmp
							AND activity_name = @act_name_tmp
							AND ui_name = @ui_name_tmp
							AND page_bt_synonym = @engg_grid_page_bts
							AND section_bt_synonym = @engg_grid_sec_bts
							AND control_bt_synonym = @engg_grid_grid_code
							AND column_bt_synonym = @engg_grid_btsynname
						)
				BEGIN
					UPDATE ep_ui_state_column_dtl
					SET column_no = @engg_grid_colno
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_base_req_no
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = @engg_grid_page_bts
						AND section_bt_synonym = @engg_grid_sec_bts
						AND control_bt_synonym = @engg_grid_grid_code
						AND column_bt_synonym = @engg_grid_btsynname
				END -- code addition by Gopinath for the Call Id PNR2.0_24645 S ends    
			END
			ELSE
			BEGIN
				EXEC engg_error_sp 'ep_layout_sp_savgrdgdml',
					13,
					'Column (BT Synonym):<%2> cannot be modified at row:<%1>',
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@fprowno,
					@engg_grid_btsynname,
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid > 0
					RETURN
			END
		END /*End of Mode Flag Y and U*/

		-- code modified by shafina on 09-Sep-2004 for PREVIEWENG203SYS_000144 (Enumerated value is not comin in combo) 
		IF @modeflag IN (
				'u',
				'y',
				's',
				'z'
				)
		BEGIN
			IF EXISTS (
					SELECT 'x'
					FROM ep_enum_value_dtl(NOLOCK)
					WHERE customer_name = rtrim(@engg_customer_name)
						AND project_name = rtrim(@engg_project_name)
						AND req_no = rtrim(@engg_base_req_no)
						AND process_name = rtrim(@prc_name_tmp)
						AND component_name = rtrim(@component_name_tmp)
						AND activity_name = rtrim(@act_name_tmp)
						AND ui_name = rtrim(@ui_name_tmp)
						AND page_bt_synonym = rtrim(@engg_grid_page_bts)
						AND section_bt_synonym = rtrim(@engg_grid_sec_bts)
						AND control_bt_synonym = rtrim(@engg_grid_btsynname)
					)
				AND @tmp_ctl = 'combo'
			BEGIN
				SELECT @engg_grid_samp_data = ''

				SELECT @enumcap = ''

				DECLARE enum_curr CURSOR
				FOR
				SELECT enum_caption
				FROM ep_enum_value_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = @engg_grid_page_bts
					AND section_bt_synonym = @engg_grid_sec_bts
					AND control_bt_synonym = @engg_grid_btsynname
				ORDER BY default_flag DESC

				OPEN enum_curr

				WHILE 1 = 1
				BEGIN
					FETCH NEXT
					FROM enum_curr
					INTO @enumcap

					IF @@fetch_status <> 0
						BREAK

					SELECT @engg_grid_samp_data = @engg_grid_samp_data + ltrim(rtrim(@enumcap)) + '~'
				END

				CLOSE enum_curr

				DEALLOCATE enum_curr

				IF len(@engg_grid_samp_data) > 0
					SELECT @engg_grid_samp_data = substring(@engg_grid_samp_data, 1, len(@engg_grid_samp_data) - 1)
			END
			

			UPDATE ep_ui_grid_dtl
			SET sample_data = rtrim(@engg_grid_samp_data),
				Set_User_Pref = @user_pref, -- modified  for  PNR2.0_23541    
				Default_required = @grid_def, --Code Modified for PNR2.0_30869
				TemplateID = @engg_col_tempid,
				TemplateCategory = @col_temp_cat,
				TemplateSpecific = @col_temp_specific,	
				AssociateControl = @col_associate_ctrl,--Code Added for TECH-71262
				modifiedby = @ctxt_user,
				modifieddate = getdate()
			WHERE customer_name = rtrim(@engg_customer_name)
				AND project_name = rtrim(@engg_project_name)
				AND req_no = rtrim(@engg_base_req_no)
				AND process_name = rtrim(@prc_name_tmp)
				AND component_name = rtrim(@component_name_tmp)
				AND activity_name = rtrim(@act_name_tmp)
				AND ui_name = rtrim(@ui_name_tmp)
				AND page_bt_synonym = rtrim(@engg_grid_page_bts)
				AND section_bt_synonym = rtrim(@engg_grid_sec_bts)
				AND control_bt_synonym = rtrim(@engg_grid_grid_code)
				AND column_bt_synonym = rtrim(@engg_grid_btsynname)
		END

		/*If a Column BT exists, Update else Insert*/

		IF @modeflag IN (
				'X',
				'I'
				)
		BEGIN
			IF EXISTS (
					SELECT 'X'
					FROM ep_ui_grid_dtl(NOLOCK)
					WHERE customer_name = rtrim(@engg_customer_name)
						AND project_name = rtrim(@engg_project_name)
						AND req_no = rtrim(@engg_base_req_no)
						AND process_name = rtrim(@prc_name_tmp)
						AND component_name = rtrim(@component_name_tmp)
						AND activity_name = rtrim(@act_name_tmp)
						AND ui_name = rtrim(@ui_name_tmp)
						AND page_bt_synonym = rtrim(@engg_grid_page_bts)
						AND section_bt_synonym = rtrim(@engg_grid_sec_bts)
						AND control_bt_synonym = rtrim(@engg_grid_grid_code)
						AND column_bt_synonym = rtrim(@engg_grid_btsynname)
					)
			BEGIN
			
				UPDATE ep_ui_grid_dtl
				SET column_type = rtrim(@engg_grid_elem_type),
					column_no = @engg_grid_colno,
					visible_length = rtrim(@engg_grid_vis_length),
					proto_tooltip = rtrim(@engg_grid_tooltip),
					TemplateID = @engg_col_tempid,
					sample_data = rtrim(@engg_grid_samp_data),
					col_doc = rtrim(@engg_grid_doc),
					Set_User_Pref = @user_pref, -- modified  for  PNR2.0_23541    
					Default_required = @grid_def, --Code Modified for PNR2.0_30869    
					modifiedby = @ctxt_user,
					modifieddate = getdate(),
					TemplateCategory = @col_temp_cat,
					TemplateSpecific = @col_temp_specific,
					AssociateControl = @col_associate_ctrl,--Code Added for TECH-71262
					column_Transformas = @Col_transform_as -- added for GridToForm TECH-12776
				WHERE customer_name = rtrim(@engg_customer_name)
					AND project_name = rtrim(@engg_project_name)
					AND req_no = rtrim(@engg_base_req_no)
					AND process_name = rtrim(@prc_name_tmp)
					AND component_name = rtrim(@component_name_tmp)
					AND activity_name = rtrim(@act_name_tmp)
					AND ui_name = rtrim(@ui_name_tmp)
					AND page_bt_synonym = rtrim(@engg_grid_page_bts)
					AND section_bt_synonym = rtrim(@engg_grid_sec_bts)
					AND control_bt_synonym = rtrim(@engg_grid_grid_code)
					AND column_bt_synonym = rtrim(@engg_grid_btsynname)
			END
			ELSE
				/*Insertion of New Row*/
			BEGIN
				-- To Generate Control ID/View Names for the newly inserted controls    
				-- To select the control_id of the grid control from control_dtl..    
				SELECT @ctrl_bt_syn_id = control_id
				FROM ep_ui_control_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = @engg_grid_page_bts
					AND section_bt_synonym = @engg_grid_sec_bts
					AND control_bt_synonym = @engg_grid_grid_code

				SELECT @ctrl_bt_syn_id = isnull(@ctrl_bt_syn_id, '')

				-- code modified by chanheetha N A  for the call id : PNR2.0_11000 on15-Nov-2006    
				-- -- code modified by shafina on 08-June-2004 for PREVIEWENG203ACC_000071 ( duplication of view name )    
				--    
				--    select @viewname_tmp  = max(convert(int,view_name))    
				--    from ep_ui_grid_dtl (nolock)    
				--    where  customer_name    = @engg_customer_name    
				--    and   project_name    = @engg_project_name    
				--    and     req_no       = @engg_base_req_no    
				--    and   process_name    = @prc_name_tmp    
				--    and   component_name   = @component_name_tmp    
				--    and   activity_name    = @act_name_tmp    
				--    and   ui_name       = @ui_name_tmp    
				--    and   page_bt_synonym   = @engg_grid_page_bts    
				--    and  section_bt_synonym = @engg_grid_sec_bts    
				--    and  control_bt_synonym = @engg_grid_grid_code    
				-- -- code modified by shafina on 03-mar-2004 to CREATE generation of view name    
				--    if isnull(@viewname_tmp,'') = ''    
				--    begin    
				--     select @view_name = '1'    
				--    end    
				--    else    
				--    begin    
				--     select @view_name = @viewname_tmp + 1    
				--    end    
				SELECT @viewname_tmp = ''

				SELECT @viewname_tmp = ISNULL(max(cast(view_name AS INT)),0) + 1
				FROM ep_ui_grid_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = @engg_grid_page_bts
					AND section_bt_synonym = @engg_grid_sec_bts
					AND control_bt_synonym = @engg_grid_grid_code
					and isnumeric(view_name) = 1 -- Added for TECH-42697
					AND view_name NOT IN (
						SELECT DISTINCT viewname
						FROM ep_systemdefined_views(NOLOCK)
						)

				--and  column_bt_synonym not in ('__nodeid','__nodeexpand','__parentnodeid', '__nodetype')
				--and  column_bt_synonym not in (column_prefix+'__parentnodeid',column_prefix+'__nodeid')    
				SELECT @hview_name_tmp = ISNULL(max(cast(a.view_name AS INT)), 0) + 1
				FROM de_hidden_view a(NOLOCK)
				WHERE a.customer_name = @engg_customer_name
					AND a.project_name = @engg_project_name
					AND a.process_name = @prc_name_tmp
					AND a.component_name = @component_name_tmp
					AND a.activity_name = @act_name_tmp
					AND a.ui_name = @ui_name_tmp
					AND a.page_name = @engg_grid_page_bts
					AND a.section_name = @engg_grid_sec_bts
					and isnumeric(view_name) = 1
					AND ltrim(rtrim(a.control_bt_synonym)) NOT IN (
						SELECT ltrim(rtrim(b.control_bt_synonym)) --PNR2.0_25211    
						FROM de_ui_control B(NOLOCK)
						WHERE b.customer_name = @engg_customer_name
							AND b.project_name = @engg_project_name
							AND b.process_name = @prc_name_tmp
							AND b.component_name = @component_name_tmp
							AND b.activity_name = @act_name_tmp
							AND b.ui_name = @ui_name_tmp
							AND b.page_bt_synonym = @engg_grid_page_bts
							AND b.section_bt_synonym = @engg_grid_sec_bts
						)

				IF isnull(@viewname_tmp, '') = ''
				BEGIN
					SELECT @view_name = '1'
				END
				ELSE
				BEGIN
					IF cast(isnull(@hview_name_tmp, '0') AS INT) > cast(@viewname_tmp AS INT)
					BEGIN
						SELECT @view_name = @hview_name_tmp
					END
					ELSE
					BEGIN
						SELECT @view_name = @viewname_tmp
					END
				END

				-- code modified by chanheetha N A  for the call id : PNR2.0_11000 on15-Nov-2006    
				-- modified by shafina on 30-jan-2004 to CREATE generation of view_name    
				-- modified by shafina on 28-jan-2004 to insert view_name    
				/*   if isnull(@viewname_tmp,'') = ''    
begin    
select @view_name = @ctrl_bt_syn_id+'_1'    
end    
else    
begin    
select @vlen = len(@viewname_tmp)    
select @ccnt = 0,    
@rstr = ''    
    
while @ccnt = 0    
begin    
select @cstr = substring(@viewname_tmp,@vlen,1)    
    
if @cstr = '_'    
begin    
select @ccnt = @vlen    
end    
else    
begin    
select @vlen = @vlen - 1,    
@rstr = @cstr + @rstr    
end    
end    
select @rstr = cast(@rstr as int) + 1    
    
select @view_name = @ctrl_bt_syn_id+'_'+@rstr    
end*/
				-- modified by shafina on 21-jan-2004 to generate the controlid    
				--     if len(@count) = 1    
				--     begin    
				--      select @control_id = @ctrl_bt_syn_id + '-' + '00' + @count    
				--     end    
				--     if len(@count) = 2    
				--     begin    
				--      select @control_id = @ctrl_bt_syn_id + '-' + '0' + @count    
				--     end    
				--     if len(@count) = 3    
				--     begin  
				--      select @control_id = @ctrl_bt_syn_id + '-' + @count    
				--     end    
				--    end    
				--    select  @control_id = isnull(@control_id,'')    
				-- Space is passed for Column Prefix for inserting thru common sp - Ramachandran.T 25 Dec 2003    
				/*Insert SP*/
				--code added by DNR for getting unique prefix ID on 30/12/2003    
				EXEC engg_gen_prefix_id @engg_customer_name,
					@engg_project_name,
					@component_name_tmp,
					@act_name_tmp,
					@ui_name_tmp,
					@engg_grid_btsynname,
					'C',
					6,
					@page_prefix_tmp OUTPUT

				SET @RowExpander = CASE @RowExpander
						WHEN 1
							THEN 'Y'
						ELSE 'N'
						END
				SET @FormEnabled = CASE @FormEnabled
						WHEN 1
							THEN 'Y'
						ELSE 'N'
						END
				SET @forcefit = CASE @forcefit
						WHEN 1
							THEN 'Y' -- Added by 11536 to avoid new insertion in forcefit column as 1/0
						ELSE 'N'
						END
				SET @engg_tree_column = CASE @engg_tree_column
						WHEN 1
							THEN 'Y'
						ELSE 'N'
						END
		/*TECH-64327 added by 14469 on 25Nov2021 */
		
		IF @modeflag IN ('I','X') AND @engg_grid_elem_type IN ('Edit') 
		AND EXISTS (SELECT 'X' FROM es_quick_code_met (NOLOCK)
		WHERE	CustomerName = @engg_customer_name 
		AND ProjectName = @engg_project_name 
		AND	ParameterCode = 'AutoDefaultRequired' 
		AND ParameterText = 'AUTO_DEFAULT_ML_EDIT' 
		AND ISNULL(ParameterValue,'') IN ('Y','1')  --TECH-73216
		)
		BEGIN
		SELECT @engg_grid_default = 1
		END

		IF @modeflag IN ('I','X') AND @engg_grid_elem_type IN ('Combo') 
		AND EXISTS (SELECT 'X' FROM es_quick_code_met (NOLOCK)
		WHERE  CustomerName = @engg_customer_name 
		AND ProjectName = @engg_project_name 
		AND	ParameterCode = 'AutoDefaultRequired' 
		AND ParameterText = 'AUTO_DEFAULT_ML_COMBO'
		AND ISNULL(ParameterValue,'') IN ('Y','1') ) --TECH-73216
		BEGIN
		SELECT @engg_grid_default = 1
		END

		/*TECH-64327 added by 14469 on 25Nov2021 */

		IF isnull(@engg_grid_default, '') = 1
			SELECT @grid_def = 'Y'
		ELSE
			SELECT @grid_def = 'N'

				EXEC ep_ui_grid_dtl_sp_ins @ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@engg_customer_name,
					@engg_project_name,
					@engg_base_req_no,
					@prc_name_tmp,
					@component_name_tmp,
					@act_name_tmp,
					@ui_name_tmp,
					@engg_grid_page_bts,
					@engg_grid_sec_bts,
					@engg_grid_grid_code,
					@engg_grid_btsynname,
					@ctrl_bt_syn_id,
					@view_name,
					@engg_grid_elem_type,
					@engg_grid_colno,
					@engg_grid_vis_length,
					@engg_grid_tooltip,
					@engg_grid_samp_data,
					@engg_grid_doc,
					@page_prefix_tmp,
					1,
					@engg_req_no,
					@user_pref,
					@grid_def,
					@engg_grd_visible,
					@columnclass, /* @columnheaderclass,*/
					@engg_col_tempid,
					@forcefit,
					@col_temp_cat,
					@col_temp_specific,
					@col_associate_ctrl,--Code Added for TECH-71262
					@RowExpander,
					@FormEnabled,
					@engg_tree_column,
					--Ranjitha
					@col_Icon_class,
					@col_Icon_position,
					@Col_class_ext6,
					@Col_transform_as,
					@engg_extensionreqd, --Code added for TECH-60451
					@engg_extensionorder,  --Code added for TECH-60451
					@m_errorid OUTPUT --chan    --UserPref added for PNR2.0_23541   --Code Modified for PNR2.0_30869  
					
				IF @m_errorid > 0
					RETURN
			END

	/** To insert the Hidden controls when new column with edit mask feature creates. 
	Code added for Defect id : TECH-20326  starts
	*/
			IF EXISTS (
					SELECT 'x'
					FROM ep_ui_grid_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = @engg_grid_page_bts
						AND section_bt_synonym = @engg_grid_sec_bts
						AND control_bt_synonym = @engg_grid_grid_code
						AND column_bt_synonym = 'm' + @engg_grid_btsynname + '_rd'
					)
				OR (isnull(@tmp_ctl, '') = 'Edit')
			BEGIN
				EXEC ep_editmask_ins @ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@engg_customer_name,
					@engg_project_name,
					@prc_name_tmp,
					@component_name_tmp,
					@act_name_tmp,
					@ui_name_tmp,
					@engg_grid_page_bts,
					@engg_grid_sec_bts,
					@engg_grid_grid_code,
					@engg_grid_btsynname,
					@engg_grid_elem_type,
					'Ml',
					@engg_base_req_no,
					@m_errorid
			END

			/** Code added for Defect id : TECH-20326 ends. */
			IF @Modeflag IN (
					'I',
					'X'
					)
			BEGIN
				SELECT @devicetype = ''

				SELECT @Devicetype = isnull(devicetype, '')
				FROM ep_ui_mst(NOLOCK)
				WHERE customer_name = rtrim(@engg_customer_name)
					AND project_name = rtrim(@engg_project_name)
					AND req_no = rtrim(@engg_base_req_no)
					AND process_name = rtrim(@prc_name_tmp)
					AND component_name = rtrim(@component_name_tmp)
					AND activity_name = rtrim(@act_name_tmp)
					AND ui_name = rtrim(@ui_name_tmp)

				IF isnull(@devicetype, '') = ''
					SELECT @phone_in = NULL,
						@tablet_in = NULL

				IF isnull(@devicetype, '') = 'P'
					AND EXISTS (
						SELECT 'x'
						FROM ep_phone_control_dtl a(NOLOCK),
							es_comp_ctrl_type_mst b(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.process_name = @prc_name_tmp
							AND a.component_name = @component_name_tmp
							AND a.page_bt_synonym = @engg_grid_page_bts
							AND a.control_bt_synonym = @engg_grid_grid_code
							AND a.customer_name = b.customer_name
							AND a.project_name = b.project_name
							AND a.process_name = b.process_name
							AND a.component_name = b.component_name
							AND a.control_type = b.ctrl_type_name
							AND b.base_ctrl_type = 'GRID'
						)
				BEGIN
					SELECT @phone_in = 1,
						@tablet_in = NULL
				END

				IF isnull(@devicetype, '') = 'T'
					AND EXISTS (
						SELECT 'x'
						FROM ep_tablet_control_dtl a(NOLOCK),
							es_comp_ctrl_type_mst b(NOLOCK)
						WHERE a.customer_name = @engg_customer_name
							AND a.project_name = @engg_project_name
							AND a.process_name = @prc_name_tmp
							AND a.component_name = @component_name_tmp
							AND a.page_bt_synonym = @engg_grid_page_bts
							AND a.control_bt_synonym = @engg_grid_grid_code
							AND a.customer_name = b.customer_name
							AND a.project_name = b.project_name
							AND a.process_name = b.process_name
							AND a.component_name = b.component_name
							AND a.control_type = b.ctrl_type_name
							AND b.base_ctrl_type = 'GRID'
						)
				BEGIN
					SELECT @phone_in = NULL,
						@tablet_in = 1
				END

				IF isnull(@devicetype, '') = 'B'
				BEGIN
					IF EXISTS (
							SELECT 'x'
							FROM ep_phone_control_dtl a(NOLOCK),
								es_comp_ctrl_type_mst b(NOLOCK)
							WHERE a.customer_name = @engg_customer_name
								AND a.project_name = @engg_project_name
								AND a.process_name = @prc_name_tmp
								AND a.component_name = @component_name_tmp
								AND a.page_bt_synonym = @engg_grid_page_bts
								AND a.control_bt_synonym = @engg_grid_grid_code
								AND a.customer_name = b.customer_name
								AND a.project_name = b.project_name
								AND a.process_name = b.process_name
								AND a.component_name = b.component_name
								AND a.control_type = b.ctrl_type_name
								AND b.base_ctrl_type = 'GRID'
							)
					BEGIN
						SELECT @phone_in = 1,
							@tablet_in = NULL
					END

					IF EXISTS (
							SELECT 'x'
							FROM ep_tablet_control_dtl a(NOLOCK),
								es_comp_ctrl_type_mst b(NOLOCK)
							WHERE a.customer_name = @engg_customer_name
								AND a.project_name = @engg_project_name
								AND a.process_name = @prc_name_tmp
								AND a.component_name = @component_name_tmp
								AND a.page_bt_synonym = @engg_grid_page_bts
								AND a.control_bt_synonym = @engg_grid_grid_code
								AND a.customer_name = b.customer_name
								AND a.project_name = b.project_name
								AND a.process_name = b.process_name
								AND a.component_name = b.component_name
								AND a.control_type = b.ctrl_type_name
								AND b.base_ctrl_type = 'GRID'
							)
					BEGIN
						SELECT @phone_in = NULL,
							@tablet_in = 1
					END

					IF EXISTS (
							SELECT 'x'
							FROM ep_phone_control_dtl a(NOLOCK),
								es_comp_ctrl_type_mst b(NOLOCK)
							WHERE a.customer_name = @engg_customer_name
								AND a.project_name = @engg_project_name
								AND a.process_name = @prc_name_tmp
								AND a.component_name = @component_name_tmp
								AND a.page_bt_synonym = @engg_grid_page_bts
								AND a.control_bt_synonym = @engg_grid_grid_code
								AND a.customer_name = b.customer_name
								AND a.project_name = b.project_name
								AND a.process_name = b.process_name
								AND a.component_name = b.component_name
								AND a.control_type = b.ctrl_type_name
								AND b.base_ctrl_type = 'GRID'
							)
						AND EXISTS (
							SELECT 'x'
							FROM ep_tablet_control_dtl a(NOLOCK),
								es_comp_ctrl_type_mst b(NOLOCK)
							WHERE a.customer_name = @engg_customer_name
								AND a.project_name = @engg_project_name
								AND a.process_name = @prc_name_tmp
								AND a.component_name = @component_name_tmp
								AND a.page_bt_synonym = @engg_grid_page_bts
								AND a.control_bt_synonym = @engg_grid_grid_code
								AND a.customer_name = b.customer_name
								AND a.project_name = b.project_name
								AND a.process_name = b.process_name
								AND a.component_name = b.component_name
								AND a.control_type = b.ctrl_type_name
								AND b.base_ctrl_type = 'GRID'
							)
					BEGIN
						SELECT @phone_in = 1,
							@tablet_in = 1
					END
				END
						--Exec ep_layout_phone_tablet_ins_sp	@ctxt_language,@ctxt_ouinstance, @ctxt_service, @ctxt_user, act_name_tmp, @component_name_tmp, @engg_customer_name, @engg_grid_page_bts,
						--					@engg_grid_sec_bts,@engg_grid_grid_code,	@engg_grid_btsynname,	@prc_name_tmp,	@engg_project_name,	@engg_req_no,	@ui_name_tmp,	@phone_in,
						--					@tablet_in,'Column',null,@m_errorid
						/* 
If isnull(@devicetype,'') in( 'P', 'B' )
Begin
Exec ep_layout_phone_ins_sp	@ctxt_language,@ctxt_ouinstance, @ctxt_service, @ctxt_user, act_name_tmp, @component_name_tmp, @engg_customer_name, @engg_grid_page_bts,
					@engg_grid_sec_bts,@engg_grid_grid_code,	@engg_grid_btsynname,	@prc_name_tmp,	@engg_project_name,	@engg_req_no,	@ui_name_tmp,	@phone_in,
					@tablet_in,'Column',null,@m_errorid
End
If isnull(@devicetype,'') in( 'T', 'B' )
Begin
Exec ep_layout_tablet_ins_sp	@ctxt_language,@ctxt_ouinstance, @ctxt_service, @ctxt_user, act_name_tmp, @component_name_tmp, @engg_customer_name, @engg_grid_page_bts,
					@engg_grid_sec_bts,@engg_grid_grid_code,	@engg_grid_btsynname,	@prc_name_tmp,	@engg_project_name,	@engg_req_no,	@ui_name_tmp,	@phone_in,
					@tablet_in,'Column',null,@m_errorid
End*/
			END

			--Code Modification for PNR2.0_30869 starts    
		--Code commented for TECH-73996 starts (grid default)
		----	IF @engg_grid_default = 1
		----	BEGIN
		----		SELECT @newcontrol = @engg_grid_grid_code + 'SetDef'

		----		IF len(@newcontrol) > 57
		----			SELECT @newcontrol = left(@engg_grid_grid_code, 51) + 'SetDef'

		----		EXEC engg_gen_prefix_id @engg_customer_name,
		----			@engg_project_name,
		----			@component_name_tmp,
		----			@act_name_tmp,
		----			@ui_name_tmp,
		----			@engg_grid_grid_code,
		----			'C',
		----			6,
		----			@newctrlprefix OUTPUT

		----		SELECT @newctrlprefix = left(@newctrlprefix, 5) + 'd'

		----		EXEC ep_controlid_generation @engg_customer_name,
		----			@engg_project_name,
		----			@engg_base_req_no,
		----			@prc_name_tmp,
		----			@component_name_tmp,
		----			@act_name_tmp,
		----			@ui_name_tmp,
		----			@newcontrol,
		----			'Edit',
		----			'N',
		----			'N',
		----			@control_id OUTPUT
				
		------TECH-64327 added by 14469 on 25nov2021
		----		IF @modeflag NOT IN ('I','X') AND @engg_grid_elem_type NOT IN ('Edit','Combo') AND 
		----		NOT EXISTS (SELECT 'X' FROM es_quick_code_met WHERE CustomerName = @engg_customer_name AND ProjectName = @engg_project_name AND ParameterText IN ('AUTO_DEFAULT_ML_EDIT','AUTO_DEFAULT_ML_COMBO')	AND	ParameterCode = 'AutoDefaultRequired')
		----		BEGIN
		------TECH-64327 added by 14469 on 25nov2021
		----		IF NOT EXISTS (
		----				SELECT 'x'
		----				FROM ep_component_glossary_mst(NOLOCK)
		----				WHERE customer_name = @engg_customer_name
		----					AND project_name = @engg_project_name
		----					AND process_name = @prc_name_tmp
		----					AND component_name = @component_name_tmp
		----					AND bt_synonym_name = @newcontrol
		----				)
		----		BEGIN
		----			EXEC ep_component_glossary_mst_sp_ins @ctxt_language,
		----				@ctxt_ouinstance,
		----				@ctxt_service,
		----				@ctxt_user,
		----				@engg_customer_name,
		----				@engg_project_name,
		----				@engg_base_req_no,
		----				@prc_name_tmp,
		----				@component_name_tmp,
		----				'PrjhdnSection',
		----				NULL,
		----				'Char',
		----				60,
		----				'Section for Grid Defaulting',
		----				'PrjhdnSection',
		----				'',
		----				'U',
		----				'',
		----				'',
		----				1,
		----				@engg_req_no,
		----				@m_errorid OUTPUT

		----			IF @m_errorid <> 0
		----				RETURN
		----		END

		----		END --TECH-64327 added by 14469 on 25nov2021

		----		IF EXISTS (
		----				SELECT 'x'
		----				FROM ep_ui_control_dtl(NOLOCK)
		----				WHERE customer_name = @engg_customer_name
		----					AND project_name = @engg_project_name
		----					AND process_name = @prc_name_tmp
		----					AND component_name = @component_name_tmp
		----					AND activity_name = @act_name_tmp
		----					AND ui_name = @ui_name_tmp
		----					AND page_bt_synonym = '[mainscreen]'
		----					AND section_bt_synonym = 'PrjhdnSection'
		----				)
		----		BEGIN
		----			SELECT @horder = isnull(max(horder), 0)
		----			FROM ep_ui_control_dtl(NOLOCK)
		----			WHERE customer_name = @engg_customer_name
		----				AND project_name = @engg_project_name
		----				AND process_name = @prc_name_tmp
		----				AND component_name = @component_name_tmp
		----				AND activity_name = @act_name_tmp
		----				AND ui_name = @ui_name_tmp
		----				AND page_bt_synonym = '[mainscreen]'
		----				AND section_bt_synonym = 'PrjhdnSection'
		----		END
		----		ELSE
		----			SELECT @horder = 1

		----		IF EXISTS (
		----				SELECT 'x'
		----				FROM ep_ui_control_dtl(NOLOCK)
		----				WHERE customer_name = @engg_customer_name
		----					AND project_name = @engg_project_name
		----					AND process_name = @prc_name_tmp
		----					AND component_name = @component_name_tmp
		----					AND activity_name = @act_name_tmp
		----					AND ui_name = @ui_name_tmp
		----					AND page_bt_synonym = '[mainscreen]'
		----					AND section_bt_synonym = 'PrjhdnSection'
		----				)
		----		BEGIN
		----			SELECT @vorder = isnull(max(vorder), 0) + 1
		----			FROM ep_ui_control_dtl(NOLOCK)
		----			WHERE customer_name = @engg_customer_name
		----				AND project_name = @engg_project_name
		----				AND process_name = @prc_name_tmp
		----				AND component_name = @component_name_tmp
		----				AND activity_name = @act_name_tmp
		----				AND ui_name = @ui_name_tmp
		----				AND page_bt_synonym = '[mainscreen]'
		----				AND section_bt_synonym = 'PrjhdnSection'
		----		END
		----		ELSE
		----			SELECT @vorder = 1

		----		IF NOT EXISTS (
		----				SELECT 'x'
		----				FROM ep_ui_control_dtl(NOLOCK)
		----				WHERE customer_name = @engg_customer_name
		----					AND project_name = @engg_project_name
		----					AND process_name = @prc_name_tmp
		----					AND component_name = @component_name_tmp
		----					AND activity_name = @act_name_tmp
		----					AND ui_name = @ui_name_tmp
		----					AND page_bt_synonym = '[mainscreen]'
		----					AND section_bt_synonym = 'PrjhdnSection'
		----					AND control_bt_synonym = @newcontrol
		----				)
		----		BEGIN
		----			EXEC ep_ui_control_dtl_sp_ins @ctxt_language,
		----				@ctxt_ouinstance,
		----				@ctxt_service,
		----				@ctxt_user,
		----				@engg_customer_name,
		----				@engg_project_name,
		----				@engg_base_req_no,
		----				@prc_name_tmp,
		----				@component_name_tmp,
		----				@act_name_tmp,
		----				@ui_name_tmp,
		----				'[mainscreen]',
		----				'PrjhdnSection',
		----				@newcontrol,
		----				@control_id,
		----				'HiddenEdit',
		----				0,
		----				@horder,
		----				@vorder,
		----				1,
		----				0,
		----				0,
		----				'',
		----				'Grid Defaulting',
		----				'Grid Defaulting',
		----				@newctrlprefix,
		----				'',
		----				'',
		----				'',
		----				NULL,
		----				NULL,
		----				NULL,
		----				NULL,
		----				0,
		----				NULL,
		----				1,
		----				@engg_req_no,
		----				NULL,
		----				0,
		----				'',
		----				'',
		----				'',
		----				'',
		----				'',
		----				'',
		----				'',-------------added on 13852 on 27july2021
		----				'',
		----				'',
		----				'',
		----				'',
		----				'',
		----				'',
		----				'',		---24Nov2021
		----				'',	--TECH-73216
		----				'', --TECH-73216
		----				@m_errorid OUTPUT --Nov2016
		----		END
		----	END
		----			--Code Modification for PNR2.0_30869 ends   
		--Code commented for TECH-73996 ends (grid default)
		END /*End For Mode Flag 'X' and 'I'*/

		---QlikLink Starts
		--Check if the Length is greater that 20
		IF len(@engg_grid_btsynname) > 20
			AND @Qliklink = 'Y'
		BEGIN
			RAISERROR (
					'Length of Column Name should not be greater than 20 for QlikLink control at Row no: %i',
					16,
					1,
					@fprowno
					)

			RETURN
		END

		SELECT @QlikLink_pre = QlikLink
		FROM es_comp_ctrl_type_mst(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND process_name = @prc_name_tmp
			AND component_name = @component_name_tmp
			AND ctrl_type_name = @tmp_control_type

		SELECT @max_horder = max(isnull(Horder, 0)) + 1
		FROM ep_ui_control_dtl(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND process_name = @prc_name_tmp
			AND component_name = @component_name_tmp
			AND activity_name = @act_name_tmp
			AND ui_name = @ui_name_tmp
			AND page_bt_synonym = '[mainscreen]'
			AND section_bt_Synonym = 'PrjhdnSection'

		-- If QlikLink is deleted
		IF @modeflag = 'D'
		BEGIN
			IF EXISTS (
					SELECT 'X'
					FROM ep_ui_grid_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = @engg_grid_page_bts
						AND section_bt_synonym = @engg_grid_sec_bts
						AND control_bt_synonym = @engg_grid_grid_code
						AND column_bt_synonym = @engg_grid_btsynname
						AND @QlikLink = 'Y'
					)
			BEGIN
				SELECT @appid = isnull(propertycontrol, '')
				FROM ep_ui_control_association_map(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = @engg_grid_page_bts
					AND section_bt_synonym = @engg_grid_sec_bts
					AND control_id = @ctrl_bt_syn_id
					AND view_name = @view_name
					AND propertyname = 'AppCtrl'

				SELECT @sheetid = isnull(propertycontrol, '')
				FROM ep_ui_control_association_map(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = @engg_grid_page_bts
					AND section_bt_synonym = @engg_grid_sec_bts
					AND control_id = @ctrl_bt_syn_id
					AND view_name = @view_name
					AND propertyname = 'SheetCtrl'

				DELETE
				FROM ep_ui_control_association_map
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = @engg_grid_page_bts
					AND section_bt_synonym = @engg_grid_sec_bts
					AND control_id = @ctrl_bt_syn_id
					AND view_name = @view_name

				DELETE
				FROM ep_ui_control_dtl
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = '[mainscreen]'
					AND section_bt_synonym = 'PrjhdnSection'
					AND control_bt_synonym IN (
						@appid,
						@sheetid
						)
			END
		END

		IF @modeflag IN (
				'U',
				'Y'
				)
		BEGIN
			/** If Edit Mask Control need to Updated. 
		Code added for the Defect id: TECH-20326 starts. */
			IF EXISTS (
					SELECT 'x'
					FROM ep_ui_grid_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = @engg_grid_page_bts
						AND section_bt_synonym = @engg_grid_sec_bts
						AND control_bt_synonym = @engg_grid_grid_code
						AND column_bt_synonym = 'm' + @engg_grid_btsynname + '_rd'
					)
				OR (isnull(@tmp_ctl, '') = 'Edit')
			BEGIN
				EXEC ep_editmask_ins @ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@engg_customer_name,
					@engg_project_name,
					@prc_name_tmp,
					@component_name_tmp,
					@act_name_tmp,
					@ui_name_tmp,
					@engg_grid_page_bts,
					@engg_grid_sec_bts,
					@engg_grid_grid_code,
					@engg_grid_btsynname,
					@engg_grid_elem_type,
					'Ml',
					@engg_base_req_no,
					@m_errorid
			END
					/** Code added for the Defect id: TECH-20326 ends. */
		END

		-- If QlikLink is Updated
		IF @modeflag IN (
				'U',
				'Y'
				)
		BEGIN
			IF EXISTS (
					SELECT 'X'
					FROM ep_ui_grid_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = @engg_grid_page_bts
						AND section_bt_synonym = @engg_grid_sec_bts
						AND control_bt_synonym = @engg_grid_grid_code
						AND column_bt_synonym = @engg_grid_btsynname
						AND @QlikLink_pre = 'Y'
						AND @QlikLink <> 'Y'
					)
			BEGIN
				SELECT @appid = isnull(propertycontrol, '')
				FROM ep_ui_control_association_map(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = @engg_grid_page_bts
					AND section_bt_synonym = @engg_grid_sec_bts
					AND control_id = @ctrl_bt_syn_id
					AND view_name = @view_name
					AND propertyname = 'AppCtrl'

				SELECT @sheetid = isnull(propertycontrol, '')
				FROM ep_ui_control_association_map(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = @engg_grid_page_bts
					AND section_bt_synonym = @engg_grid_sec_bts
					AND control_id = @ctrl_bt_syn_id
					AND view_name = @view_name
					AND propertyname = 'SheetCtrl'

				DELETE
				FROM ep_ui_control_association_map
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = @engg_grid_page_bts
					AND section_bt_synonym = @engg_grid_sec_bts
					AND control_id = @ctrl_bt_syn_id
					AND view_name = @view_name

				DELETE
				FROM ep_ui_control_dtl
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = '[mainscreen]'
					AND section_bt_synonym = 'PrjhdnSection'
					AND control_bt_synonym IN (
						@appid,
						@sheetid
						)
			END
		END

		IF EXISTS (
				SELECT 'X'
				FROM ep_ui_grid_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = @engg_grid_page_bts
					AND section_bt_synonym = @engg_grid_sec_bts
					AND control_bt_synonym = @engg_grid_grid_code
					AND column_bt_synonym = @engg_grid_btsynname
					AND @QlikLink_pre <> 'Y'
					AND @QlikLink = 'Y'
					AND @modeflag IN (
						'Y',
						'U'
						)
				)
			OR @modeflag IN (
				'I',
				'X'
				)
			AND @QlikLink = 'Y'
		BEGIN
			SELECT @len_app = len(@engg_grid_btsynname)

			SELECT @len_sht = len(@engg_grid_btsynname)

			--- create a unique AppCtrl			
			WHILE (@len_app > 0)
			BEGIN
				SELECT @appid = @engg_grid_btsynname + '_aid'

				IF NOT EXISTS (
						SELECT 'X'
						FROM ep_ui_control_dtl(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @prc_name_tmp
							AND component_name = @component_name_tmp
							AND activity_name = @act_name_tmp
							AND ui_name = @ui_name_tmp
							AND control_bt_synonym = @appid
						)
				BEGIN
					BREAK
				END
				ELSE
				BEGIN
					SELECT @cont_name = substring(@engg_grid_btsynname, 1, @len_app - 1)

					SELECT @len_app = len(@cont_name)
				END
			END

			--- create a unique SheetCtrl
			WHILE (@len_sht > 0)
			BEGIN
				SELECT @sheetid = @engg_grid_btsynname + '_sid'

				IF NOT EXISTS (
						SELECT 'X'
						FROM ep_ui_control_dtl(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @prc_name_tmp
							AND component_name = @component_name_tmp
							AND activity_name = @act_name_tmp
							AND ui_name = @ui_name_tmp
							AND control_bt_synonym = @sheetid
						)
				BEGIN
					BREAK
				END
				ELSE
				BEGIN
					SELECT @cont_name = substring(@engg_grid_btsynname, 1, @len_sht - 1)

					SELECT @len_sht = len(@cont_name)
				END
			END

			--Insert appctrl and sheetctrl
			INSERT INTO ep_ui_control_dtl (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				control_type,
				horder,
				vorder,
				order_seq,
				data_column_width,
				label_column_width,
				ui_control_sysid,
				ui_section_sysid,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				control_id,
				view_name,
				visisble_length,
				proto_tooltip,
				sample_data,
				control_doc,
				control_prefix,
				label_control_id,
				label_column_scalemode,
				data_column_scalemode,
				tab_seq,
				help_tabstop,
				LabelClass,
				ControlClass,
				LabelImageClass,
				ControlImageClass,
				wrkreqno,
				AccessKey,
				Set_User_Pref,
				freezecount,
				controlimage,
				colspan,
				rowspan,
				TemplateID
				)
			SELECT @engg_customer_name,
				@engg_project_name,
				'BASE',
				@prc_name_tmp,
				@component_name_tmp,
				@act_name_tmp,
				@ui_name_tmp,
				'[mainscreen]',
				'PrjhdnSection',
				@appid,
				'DisplayOnly',
				@max_horder,
				1,
				1,
				0,
				0,
				newid(),
				newid(),
				1,
				@ctxt_user,
				getdate(),
				@ctxt_user,
				getdate(),
				'DSP' + @appid,
				'DSP' + @appid,
				NULL,
				'',
				'',
				@appid,
				@appid,
				'',
				'',
				'',
				0,
				'N',
				'',
				'',
				'',
				'',
				@engg_req_no,
				'',
				'Y',
				0,
				'',
				'',
				'',
				''
			
			UNION
			
			SELECT @engg_customer_name,
				@engg_project_name,
				'BASE',
				@prc_name_tmp,
				@component_name_tmp,
				@act_name_tmp,
				@ui_name_tmp,
				'[mainscreen]',
				'PrjhdnSection',
				@sheetid,
				'DisplayOnly',
				@max_horder,
				2,
				1,
				0,
				0,
				newid(),
				newid(),
				1,
				@ctxt_user,
				getdate(),
				@ctxt_user,
				getdate(),
				'DSP' + @sheetid,
				'DSP' + @sheetid,
				NULL,
				'',
				'',
				@sheetid,
				@sheetid,
				'',
				'',
				'',
				0,
				'N',
				'',
				'',
				'',
				'',
				@engg_req_no,
				'',
				'Y',
				0,
				'',
				'',
				'',
				''

			---Insert a Bt
			IF NOT EXISTS (
					SELECT 'X'
					FROM de_business_term(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND bt_name = 'engg_name'
					)
			BEGIN
				INSERT INTO de_business_term (
					customer_name,
					project_name,
					process_name,
					component_name,
					bt_name,
					bt_descr,
					data_type,
					bt_sysid,
					TIMESTAMP,
					createdby,
					createddate,
					modifiedby,
					modifieddate,
					length,
					precision_type,
					ecrno
					)
				VALUES (
					@engg_customer_name,
					@engg_project_name,
					@prc_name_tmp,
					@component_name_tmp,
					'engg_name',
					'engg_name',
					'Char',
					newid(),
					1,
					@ctxt_user,
					getdate(),
					@ctxt_user,
					getdate(),
					60,
					NULL,
					@engg_req_no
					)
			END

			---Insert appid into glossary 
			
			IF NOT EXISTS (
					SELECT 'X'
					FROM ep_component_glossary_mst(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND bt_synonym_name = @appid
					)
			BEGIN
				INSERT INTO ep_component_glossary_mst (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					bt_synonym_name,
					data_type,
					length,
					bt_synonym_caption,
					glossary_sysid,
					TIMESTAMP,
					createdby,
					createddate,
					modifiedby,
					modifieddate,
					ref_bt_synonym_name,
					bt_synonym_doc,
					bt_name,
					synonym_status,
					singleinst_sample_data,
					multiinst_sample_data,
					wrkreqno
					)
				SELECT @engg_customer_name,
					@engg_project_name,
					'BASE',
					@prc_name_tmp,
					@component_name_tmp,
					@appid,
					'Char',
					60,
					@appid,
					newid(),
					1,
					@ctxt_user,
					getdate(),
					@ctxt_user,
					getdate(),
					NULL,
					@appid,
					'engg_name',
					'R',
					'',
					'',
					@engg_req_no
			END
			
			---Insert sheetid into glossary 
			IF NOT EXISTS (
					SELECT 'X'
					FROM ep_component_glossary_mst(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND bt_synonym_name = @sheetid
					)
			BEGIN
				INSERT INTO ep_component_glossary_mst (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					bt_synonym_name,
					data_type,
					length,
					bt_synonym_caption,
					glossary_sysid,
					TIMESTAMP,
					createdby,
					createddate,
					modifiedby,
					modifieddate,
					ref_bt_synonym_name,
					bt_synonym_doc,
					bt_name,
					synonym_status,
					singleinst_sample_data,
					multiinst_sample_data,
					wrkreqno
					)
				SELECT @engg_customer_name,
					@engg_project_name,
					'BASE',
					@prc_name_tmp,
					@component_name_tmp,
					@sheetid,
					'Char',
					60,
					@sheetid,
					newid(),
					1,
					@ctxt_user,
					getdate(),
					@ctxt_user,
					getdate(),
					NULL,
					@sheetid,
					'engg_name',
					'R',
					'',
					'',
					@engg_req_no
			END
			
			---Insert appid and sheetid into glossary lng mst
			--IF NOT EXISTS (
			--		SELECT 'X'
			--		FROM ep_component_glossary_mst_lng_extn(NOLOCK)
			--		WHERE customer_name = @engg_customer_name
			--			AND project_name = @engg_project_name
			--			AND process_name = @prc_name_tmp
			--			AND component_name = @component_name_tmp
			--			AND languageid = 1
			--			AND (
			--				bt_synonym_name = @appid
			--				OR bt_synonym_name = @sheetid
			--				)
			--		)
			--BEGIN
			--	INSERT INTO ep_component_glossary_mst_lng_extn (
			--		customer_name,
			--		project_name,
			--		req_no,
			--		process_name,
			--		component_name,
			--		bt_synonym_name,
			--		data_type,
			--		length,
			--		bt_synonym_caption,
			--		glossary_sysid,
			--		languageid,
			--		TIMESTAMP,
			--		createdby,
			--		createddate,
			--		modifiedby,
			--		modifieddate,
			--		ref_bt_synonym_name,
			--		bt_synonym_doc,
			--		bt_name,
			--		synonym_status,
			--		singleinst_sample_data,
			--		multiinst_sample_data,
			--		wrkreqno
			--		)
			--	SELECT a.customer_name,
			--		a.project_name,
			--		a.req_no,
			--		a.process_name,
			--		a.component_name,
			--		a.bt_synonym_name,
			--		a.data_type,
			--		a.length,
			--		a.bt_synonym_caption,
			--		newid(),
			--		1,
			--		1,
			--		@ctxt_user,
			--		getdate(),
			--		@ctxt_user,
			--		getdate(),
			--		NULL,
			--		a.bt_synonym_doc,
			--		a.bt_name,
			--		a.synonym_status,
			--		'',
			--		'',
			--		@engg_req_no
			--	FROM ep_component_glossary_mst a(NOLOCK)
			--	WHERE a.customer_name = @engg_customer_name
			--		AND a.project_name = @engg_project_name
			--		AND req_no = @engg_req_no
			--		AND process_name = @prc_name_tmp
			--		AND component_name = @component_name_tmp
			--		AND bt_synonym_name IN (
			--			@appid,
			--			@sheetid
			--			)
			--		AND NOT EXISTS (
			--			SELECT 's'
			--			FROM ep_component_glossary_mst_lng_extn c(NOLOCK)
			--			WHERE c.customer_name = a.customer_name
			--				AND c.project_name = a.project_name
			--				AND c.req_no = a.req_no
			--				AND c.process_name = a.process_name
			--				AND c.component_name = a.component_name
			--				AND c.bt_synonym_name = a.bt_synonym_name
			--				AND c.languageid = 1
			--			)
			--END

			--Insert appctrl and sheetctrl in ep_ui_control_association_map
			INSERT INTO ep_ui_control_association_map (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				Control_id,
				view_name,
				propertyname,
				propertycontrol,
				property_controlid,
				property_viewname,
				createdby,
				createddate,
				modifiedby,
				modifieddate
				)
			SELECT @engg_customer_name,
				@engg_project_name,
				'BASE',
				@prc_name_tmp,
				@component_name_tmp,
				@act_name_tmp,
				@ui_name_tmp,
				@engg_grid_page_bts,
				@engg_grid_sec_bts,
				@ctrl_bt_syn_id,
				@view_name,
				'AppCtrl',
				@appid,
				'DSP' + @appid,
				'DSP' + @appid,
				@ctxt_user,
				getdate(),
				@ctxt_user,
				getdate()
			
			UNION
			
			SELECT @engg_customer_name,
				@engg_project_name,
				'BASE',
				@prc_name_tmp,
				@component_name_tmp,
				@act_name_tmp,
				@ui_name_tmp,
				@engg_grid_page_bts,
				@engg_grid_sec_bts,
				@ctrl_bt_syn_id,
				@view_name,
				'SheetCtrl',
				@sheetid,
				'DSP' + @sheetid,
				'DSP' + @sheetid,
				@ctxt_user,
				getdate(),
				@ctxt_user,
				getdate()
		END

		---QlikLink Ends
		--  modified by shafina on 17-jan-2004 to fetch the task name based on the default_for column    
		-- and to insert the primary control_bts    
		IF @modeflag <> 'D'
		BEGIN
			-- code modified by shafina on 04-June-2004 for PREVIEWENG203ACC_000070    
			--modified by vasu date:29-12-2003    
			-- if control bt synonym which is residing in grid control from glossary    
			-- modified by shafina on 13-jan-2004 to insert length of bt synonym    
			DECLARE @btLength engg_rowno

			SELECT @btLength = isnull(@engg_grid_vis_length, 20)

			-- code modified by shafina on 09-June-2004 for PREVIEWENG203ACC_000072    
			IF @engg_grid_vis_length = 0
				SELECT @btLength = 20

			IF NOT EXISTS (
					SELECT 'x'
					FROM ep_component_glossary_mst(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_base_req_no
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND bt_synonym_name = @engg_grid_btsynname
					)
			BEGIN
				-- code modified by shafina on 24-feb-2004    
				EXEC ep_generate_caption @engg_grid_btsynname,
					@grid_bt_caption OUTPUT

				-- code modified by shafina on 17-June-2004 for PREVIEWENG203ACC_000073    
				EXEC ep_component_glossary_mst_sp_ins @ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@engg_customer_name,
					@engg_project_name,
					@engg_base_req_no,
					@prc_name_tmp,
					@component_name_tmp,
					@engg_grid_btsynname,
					NULL,
					'Char',
					@btLength,
					@grid_bt_caption,
					@engg_grid_btsynname,
					'',
					'U',
					'',
					'',
					1,
					@engg_req_no, --chan    
					@m_errorid OUTPUT
			END
		

			-- code added by shafina on 17-feb-2004 to insert into traversal table    
			IF NOT EXISTS (
					SELECT 'x'
					FROM ep_ui_traversal_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_base_req_no
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = @engg_grid_page_bts
						AND section_bt_synonym = @engg_grid_sec_bts
						AND control_bt_synonym = @engg_grid_btsynname
					)
			BEGIN
				IF @tmp_ctl IN (
						'Link',
						'DataHyperlink'
						) -- code modified for the Bug ID: PNR2.0_33877    
				BEGIN
					EXEC ep_ui_traversal_dtl_sp_ins @ctxt_language,
						@ctxt_ouinstance,
						@ctxt_service,
						@ctxt_user,
						@engg_customer_name,
						@engg_project_name,
						@engg_base_req_no,
						@prc_name_tmp,
						@component_name_tmp,
						@act_name_tmp,
						@ui_name_tmp,
						@engg_grid_page_bts,
						@engg_grid_sec_bts,
						@engg_grid_btsynname,
						'Lnk',
						'',
						'',
						'',
						'',
						1,
						@engg_req_no,
						'',
						'',
						'',
						'',
						@m_errorid OUTPUT --chan    

					IF @m_errorid <> 0
						RETURN
				END

				IF @help_req = 'y'
				BEGIN
					EXEC ep_ui_traversal_dtl_sp_ins @ctxt_language,
						@ctxt_ouinstance,
						@ctxt_service,
						@ctxt_user,
						@engg_customer_name,
						@engg_project_name,
						@engg_base_req_no,
						@prc_name_tmp,
						@component_name_tmp,
						@act_name_tmp,
						@ui_name_tmp,
						@engg_grid_page_bts,
						@engg_grid_sec_bts,
						@engg_grid_btsynname,
						'Hlp',
						'',
						'',
						'',
						'',
						1,
						@engg_req_no,
						'',
						'',
						'',
						'',
						@m_errorid OUTPUT --chan    

					IF @m_errorid <> 0
						RETURN
				END
			END

			--code modified by shafina on 27-jan-2004 to insert into flow_br_mst table    
			--code modified by shafina on 12-Apr-2004 for PREVIEWENG203ACC_000027    
			EXEC ep_task_generation @ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@engg_customer_name,
				@engg_project_name,
				@engg_base_req_no,
				@prc_name_tmp,
				@component_name_tmp,
				@act_name_tmp,
				@ui_name_tmp,
				@engg_grid_page_bts,
				@engg_grid_sec_bts,
				@engg_grid_grid_code,
				@engg_grid_btsynname,
				@tmp_ctl,
				@event_req,
				@help_req,
				@zoom_req,
				@editable,
				'COLUMN',
				@report_req,
				@engg_req_no,
				-- code modified by Anuradha on 06-Nov-2006 for the Bug ID :: PNR2.0_10832    
				@m_errorid OUTPUT
		END -- end of if modeflag <> 'D'    

		-- Code added By Feroz for Image Control / Ataach Document Control hidden view creation    
		---- Code added for Attachment with Description and Dynamic File upload path of Ataach Document Control Starts
		--select	@control_id_tmp	= Control_id,
		--		@view_name		= view_name
		--from	ep_ui_grid_dtl (nolock)
		--where	customer_name		= @engg_customer_name    
		--and  	project_name		= @engg_project_name    
		--and  	process_name		= @prc_name_tmp    
		--and  	component_name  	= @component_name_tmp    
		--and  	activity_name		= @act_name_tmp    
		--and  	ui_name				= @ui_name_tmp    
		--and  	page_bt_synonym		= @engg_grid_page_bts    
		--and		control_bt_synonym  = @engg_grid_grid_code
		--and		column_bt_synonym	= @engg_grid_btsynname 
		--if @modeflag <> 'S'    
		--begin    
		--	if exists (select 'X' from es_comp_ctrl_type_mst (nolock)   
		--	where customer_name    = @engg_customer_name  
		--	and  project_name   = @engg_project_name  
		--	and  process_name  = @prc_name_tmp    
		--	and  component_name = @component_name_tmp    
		--	and    ctrl_type_name  = @engg_grid_elem_type  
		-- 	and (attach_document = 'Y'	
		--		and  AttachmentWithDesc ='y'))  
		--	Begin
		--		Exec ep_attachdoc_hiddenview_ins_sp 
		--				@ctxt_language,			@ctxt_ouinstance,			@ctxt_service,			@ctxt_user,				@engg_customer_name,
		--				@engg_project_name,		@prc_name_tmp,				@component_name_tmp,	@act_name_tmp,			@ui_name_tmp,
		--				@engg_grid_page_bts,	@engg_grid_sec_bts,			@engg_grid_grid_code,	@engg_grid_btsynname,	@engg_req_no,			--@hidden_vew_bt_synonym,
		--				@tmp_control_type,		@engg_grid_elem_type,		@control_id_tmp ,		@view_name,				@modeflag,
		--				@del_flag,				@del_flag_ph,				'ML',					@m_errorid
		--	End
		--	--12545
		--	if exists (select 'x' 
		--	from	es_comp_ctrl_type_mst mst(nolock),
		--			es_comp_ctrl_type_mst_extn extn (nolock) 
		--	where	mst.customer_name		= @engg_customer_name  
		--	and		mst.project_name		= @engg_project_name  
		--	and		mst.process_name		= @prc_name_tmp    
		--	and		mst.component_name		= @component_name_tmp    
		--	and		mst.ctrl_type_name		= @engg_grid_elem_type 
		--	and		mst.customer_name		= extn.customer_name  
		--	and		mst.project_name		= extn.project_name  
		--	and		mst.process_name		= extn.process_name
		--	and		mst.component_name		= extn.component_name
		--	and		mst.ctrl_type_name		= extn.ctrl_type_name
		--	and		mst.base_ctrl_type		= extn.base_ctrl_type 
		-- 	and		(attach_document		= 'Y'	
		--	and		AttachmentWithDesc		= 'y'
		--	and		Dynamicfileupload		= 'Y'))  
		--	Begin
		--		Exec ep_Dynamicfileupload_hdnview_sp 
		--				@ctxt_language,			@ctxt_ouinstance,			@ctxt_service,			@ctxt_user,				@engg_customer_name,
		--				@engg_project_name,		@prc_name_tmp,				@component_name_tmp,	@act_name_tmp,			@ui_name_tmp,
		--				@engg_grid_page_bts,	@engg_grid_sec_bts,			@engg_grid_grid_code,	@engg_grid_btsynname,	@engg_req_no,	
		--				@tmp_control_type,		@engg_grid_elem_type,		@control_id_tmp ,		@view_name,				@modeflag,
		--				@del_flag,				@del_flag_ph,				'ML',					@m_errorid
		--	End
		--	--12545
		-- Code added for Attachment with Description and Dynamic File upload path of Ataach Document Control Ends
		/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P begin*/
		DECLARE @hidden_vew_bt_synonym engg_name,
			@engg_grid_btsynname_tmp engg_name
		DECLARE @hidden_vew_bt_synonym_tmp engg_name,
			@ctxt_attach_doc engg_name,
			@hdicount INT

		/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P End*/
		IF @tmp_control_type <> @engg_grid_elem_type
		BEGIN
			/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P begin*/
			IF NOT EXISTS (
					SELECT 'X'
					FROM es_comp_ctrl_type_mst(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND ctrl_type_name = @engg_grid_elem_type
						AND (
							image_upload = 'Y'
							OR attach_document = 'Y'
							)
						AND (
							save_image_content_to_db = 'y'
							OR save_doc_content_to_db = 'y'
							)
					)
			BEGIN
				DELETE
				FROM de_hidden_view_usage
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND control_page_name = @engg_grid_page_bts
					AND control_bt_sysnonym = @engg_grid_btsynname
					AND hidden_view_bt_sysnonym LIKE ('hdi' + @hidden_vew_bt_synonym + '%')

				/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P End*/
				DELETE
				FROM de_hidden_view
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND page_name = @engg_grid_page_bts
					AND section_name = @engg_grid_sec_bts
					AND control_bt_synonym = @engg_grid_btsynname
					/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P */
					AND hidden_view_bt_synonym LIKE ('hdi' + @hidden_vew_bt_synonym + '%')
			END
		END

		IF EXISTS (
				SELECT 'x'
				FROM es_comp_ctrl_type_mst_vw(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND ctrl_type_name = @engg_grid_elem_type
					/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P begin*/
					--and   req_no     = @engg_base_req_no    
					AND (
						image_upload = 'Y'
						OR attach_document = 'Y'
						)
					AND (
						save_image_content_to_db = 'y'
						OR save_doc_content_to_db = 'y'
						)
				)
			/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P End*/
		BEGIN
			IF NOT EXISTS (
					SELECT 'X'
					FROM de_hidden_view(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND ui_name = @ui_name_tmp
						AND page_name = @engg_grid_page_bts
						AND section_name = @engg_grid_sec_bts
						AND control_bt_synonym = @engg_grid_btsynname
					)
			BEGIN
				/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P begin*/
				SET @hdicount = 0

				--TECH-75230
				--IF len(@engg_grid_btsynname) > 25
				--BEGIN
				--	SELECT @engg_grid_btsynname_tmp = left(@engg_grid_btsynname, 23)
				--END
				--ELSE
				--BEGIN
				--	SELECT @engg_grid_btsynname_tmp = @engg_grid_btsynname
				--END
				--TECH-75230

				WHILE (1 = 1)
				BEGIN
				--	SELECT @hidden_vew_bt_synonym = 'hdi' + @engg_grid_btsynname_tmp	--TECH-75230
					SELECT @hidden_vew_bt_synonym = 'hdi' + @column_prefix	 --TECH-75230

					IF @count = 0
					BEGIN
						SELECT @hidden_vew_bt_synonym_tmp = @hidden_vew_bt_synonym
					END
					ELSE
					BEGIN
						SELECT @hidden_vew_bt_synonym_tmp = @hidden_vew_bt_synonym + cast(@hdicount AS VARCHAR)
					END

					IF EXISTS (
							SELECT 'x'
							FROM ep_ui_page_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @prc_name_tmp
								AND component_name = @component_name_tmp
								AND activity_name = @act_name_tmp
								AND ui_name = @ui_name_tmp
								AND page_bt_synonym = @hidden_vew_bt_synonym_tmp
							
							UNION
							
							SELECT 'x'
							FROM ep_ui_section_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @prc_name_tmp
								AND component_name = @component_name_tmp
								AND activity_name = @act_name_tmp
								AND ui_name = @ui_name_tmp
								AND page_bt_synonym = @engg_grid_page_bts
								AND section_bt_synonym = @hidden_vew_bt_synonym_tmp
								AND req_no = @engg_base_req_no
							
							UNION
							
							SELECT 'x'
							FROM ep_ui_control_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @prc_name_tmp
								AND component_name = @component_name_tmp
								AND activity_name = @act_name_tmp
								AND ui_name = @ui_name_tmp
								AND page_bt_synonym = @engg_grid_page_bts
								AND control_bt_synonym = @hidden_vew_bt_synonym_tmp
								AND req_no = @engg_base_req_no
							
							UNION
							
							SELECT 'x'
							FROM ep_ui_grid_dtl(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @prc_name_tmp
								AND component_name = @component_name_tmp
								AND activity_name = @act_name_tmp
								AND ui_name = @ui_name_tmp
								AND page_bt_synonym = @engg_grid_page_bts
								AND column_bt_synonym = @hidden_vew_bt_synonym_tmp
								AND req_no = @engg_base_req_no
							
							UNION
							
							SELECT 'x'
							FROM de_hidden_view(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @prc_name_tmp
								AND component_name = @component_name_tmp
								AND activity_name = @act_name_tmp
								AND ui_name = @ui_name_tmp
								AND page_name = @engg_grid_page_bts
								AND hidden_view_bt_synonym = @hidden_vew_bt_synonym_tmp
							
							UNION
							
							SELECT 'x'
							FROM de_scratch_variable(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @prc_name_tmp
								AND component_name = @component_name_tmp
								AND activity_name = @act_name_tmp
								AND ui_name = @ui_name_tmp
								AND page_name = @engg_grid_page_bts
								AND scratch_name = @hidden_vew_bt_synonym_tmp
							
							UNION
							
							SELECT 'x'
							FROM de_scratch_variables_sys(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @prc_name_tmp
								AND component_name = @component_name_tmp
								AND btsynonym = @hidden_vew_bt_synonym_tmp
							)
					BEGIN
						SELECT @hdicount = @hdicount + 1
					END
					ELSE
					BEGIN
						BREAK
					END
				END

				SELECT @hidden_vew_bt_synonym = @hidden_vew_bt_synonym_tmp

				/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P End*/
				IF NOT EXISTS (
						SELECT 'x'
						FROM ep_component_glossary_mst(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND req_no = @engg_base_req_no
							AND process_name = @prc_name_tmp
							AND component_name = @component_name_tmp
							AND bt_synonym_name = @hidden_vew_bt_synonym
						)
				BEGIN
					/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P begin*/
					SELECT @ctxt_attach_doc = 'ctxt_attach_doc'

					IF EXISTS (
							SELECT 'x'
							FROM de_business_term(NOLOCK)
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND process_name = @prc_name_tmp
								AND component_name = @component_name_tmp
								AND length = 4000
								AND data_type = 'char'
							)
					BEGIN
						SELECT @ctxt_attach_doc = bt_name
						FROM de_business_term(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @prc_name_tmp
							AND component_name = @component_name_tmp
							AND length = 4000
							AND data_type = 'char'
					END
					ELSE
					BEGIN
						INSERT INTO de_business_term (
							customer_name,
							project_name,
							process_name,
							component_name,
							bt_name,
							bt_descr,
							data_type,
							bt_sysid,
							TIMESTAMP,
							createdby,
							createddate,
							modifiedby,
							modifieddate,
							length,
							precision_type,
							Generatedby,
							ecrno
							)
						VALUES (
							@engg_customer_name,
							@engg_project_name,
							@prc_name_tmp,
							@component_name_tmp,
							@ctxt_attach_doc,
							@ctxt_attach_doc,
							'CHAR',
							NEWID(),
							1,
							@ctxt_user,
							getdate(),
							@ctxt_user,
							getdate(),
							4000,
							NULL,
							'',
							@engg_base_req_no
							)
					END

					/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P End*/
					EXEC ep_component_glossary_mst_sp_ins @ctxt_language,
						@ctxt_ouinstance,
						@ctxt_service,
						@ctxt_user,
						@engg_customer_name,
						@engg_project_name,
						@engg_base_req_no,
						@prc_name_tmp,
						@component_name_tmp,
						@hidden_vew_bt_synonym,
						NULL,
						'Char',
						4000,
						@hidden_vew_bt_synonym,
						@hidden_vew_bt_synonym,
						/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P */
						@ctxt_attach_doc,
						'U',
						'',
						'',
						1,
						@engg_req_no,
						@m_errorid OUTPUT

					IF @m_errorid <> 0
						RETURN 

					/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P begin*/
					INSERT INTO RE_GLOSSARY (
						customer_name,
						project_name,
						bt_synonym_name,
						process_name,
						component_name,
						data_type,
						length,
						bt_synonym_caption,
						glossary_sysid,
						TIMESTAMP,
						createdby,
						createddate,
						modifiedby,
						modifieddate,
						ref_bt_synonym_name,
						bt_synonym_doc,
						bt_name,
						synonym_status,
						singleinst_sample_data,
						multiinst_sample_data,
						rcnno
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@hidden_vew_bt_synonym,
						@prc_name_tmp,
						@component_name_tmp,
						'char',
						4000,
						@hidden_vew_bt_synonym,
						newid(),
						1,
						@ctxt_user,
						getdate(),
						@ctxt_user,
						getdate(),
						'',
						@hidden_vew_bt_synonym,
						@ctxt_attach_doc,
						'R',
						'',
						'',
						''
						)

					--INSERT INTO RE_GLOSSARY_LNG_EXTN (
					--	customer_name,
					--	project_name,
					--	process_name,
					--	component_name,
					--	bt_synonym_name,
					--	data_type,
					--	length,
					--	bt_synonym_caption,
					--	glossary_sysid,
					--	languageid,
					--	TIMESTAMP,
					--	createdby,
					--	createddate,
					--	modifiedby,
					--	modifieddate,
					--	ref_bt_synonym_name,
					--	bt_synonym_doc,
					--	bt_name,
					--	synonym_status,
					--	singleinst_sample_data,
					--	multiinst_sample_data,
					--	rcnno
					--	)
					--SELECT @engg_customer_name,
					--	@engg_project_name,
					--	@prc_name_tmp,
					--	@component_name_tmp,
					--	@hidden_vew_bt_synonym,
					--	'char',
					--	4000,
					--	@hidden_vew_bt_synonym,
					--	newid(),
					--	quick_code,
					--	1,
					--	@ctxt_user,
					--	getdate(),
					--	@ctxt_user,
					--	getdate(),
					--	'',
					--	@hidden_vew_bt_synonym,
					--	@ctxt_attach_doc,
					--	'R',
					--	'',
					--	'',
					--	''
					--FROM EP_LANGUAGE_MET(NOLOCK)

					INSERT INTO DE_GLOSSARY (
						customer_name,
						project_name,
						component_name,
						process_name,
						bt_synonym_name,
						data_type,
						length,
						bt_synonym_caption,
						glossary_sysid,
						TIMESTAMP,
						createdby,
						createddate,
						modifiedby,
						modifieddate,
						ref_bt_synonym_name,
						bt_synonym_doc,
						bt_name,
						synonym_status,
						singleinst_sample_data,
						multiinst_sample_data,
						ecrno
						)
					VALUES (
						@engg_customer_name,
						@engg_project_name,
						@component_name_tmp,
						@prc_name_tmp,
						@hidden_vew_bt_synonym,
						'char',
						4000,
						@hidden_vew_bt_synonym,
						newid(),
						1,
						@ctxt_user,
						getdate(),
						@ctxt_user,
						getdate(),
						'',
						@hidden_vew_bt_synonym,
						@ctxt_attach_doc,
						'R',
						'',
						'',
						''
						)

					--INSERT INTO DE_GLOSSARY_LNG_EXTN (
					--	customer_name,
					--	project_name,
					--	process_name,
					--	component_name,
					--	bt_synonym_name,
					--	data_type,
					--	length,
					--	bt_synonym_caption,
					--	glossary_sysid,
					--	languageid,
					--	TIMESTAMP,
					--	createdby,
					--	createddate,
					--	modifiedby,
					--	modifieddate,
					--	ref_bt_synonym_name,
					--	bt_synonym_doc,
					--	bt_name,
					--	synonym_status,
					--	singleinst_sample_data,
					--	multiinst_sample_data,
					--	ecrno
					--	)
					--SELECT @engg_customer_name,
					--	@engg_project_name,
					--	@prc_name_tmp,
					--	@component_name_tmp,
					--	@hidden_vew_bt_synonym,
					--	'char',
					--	4000,
					--	@hidden_vew_bt_synonym,
					--	newid(),
					--	quick_code,
					--	1,
					--	@ctxt_user,
					--	getdate(),
					--	@ctxt_user,
					--	getdate(),
					--	'',
					--	@hidden_vew_bt_synonym,
					--	@ctxt_attach_doc,
					--	'R',
					--	'',
					--	'',
					--	''
					--FROM EP_LANGUAGE_MET(NOLOCK)
						/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P End*/
				END

				IF NOT EXISTS (
						SELECT 'x'
						FROM de_hidden_view(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @prc_name_tmp
							AND component_name = @component_name_tmp
							AND activity_name = @act_name_tmp
							AND ui_name = @ui_name_tmp
							AND page_name = @engg_grid_page_bts
							AND section_name = @engg_grid_sec_bts
							AND control_bt_synonym = @engg_grid_btsynname
							AND hidden_view_bt_synonym = @hidden_vew_bt_synonym
						)
				BEGIN
					SELECT @ctrl_bt_syn_id = control_id
					FROM ep_ui_grid_dtl(NOLOCK)
					WHERE customer_name = rtrim(@engg_customer_name)
						AND project_name = rtrim(@engg_project_name)
						AND req_no = rtrim(@engg_base_req_no)
						AND process_name = rtrim(@prc_name_tmp)
						AND component_name = rtrim(@component_name_tmp)
						AND activity_name = rtrim(@act_name_tmp)
						AND ui_name = rtrim(@ui_name_tmp)
						AND page_bt_synonym = rtrim(@engg_grid_page_bts)
						AND section_bt_synonym = rtrim(@engg_grid_sec_bts)
						AND control_bt_synonym = rtrim(@engg_grid_grid_code)
						AND column_bt_synonym = rtrim(@engg_grid_btsynname)

					SELECT @viewname_tmp = ISNULL(max(cast(view_name AS INT)), 0) + 1
					FROM ep_ui_grid_dtl(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND req_no = @engg_base_req_no
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = @engg_grid_page_bts
						AND section_bt_synonym = @engg_grid_sec_bts
						AND control_bt_synonym = @engg_grid_grid_code

					SELECT @hview_name_tmp = ISNULL(max(cast(a.view_name AS INT)),0) + 1
					FROM de_hidden_view a(NOLOCK)
					WHERE a.customer_name = @engg_customer_name
						AND a.project_name = @engg_project_name
						AND a.process_name = @prc_name_tmp
						AND a.component_name = @component_name_tmp
						AND a.activity_name = @act_name_tmp
						AND a.ui_name = @ui_name_tmp
						AND a.page_name = @engg_grid_page_bts
						AND a.section_name = @engg_grid_sec_bts
						AND a.control_bt_synonym NOT IN (
							SELECT b.control_bt_synonym
							FROM de_ui_control B(NOLOCK)
							WHERE b.customer_name = @engg_customer_name
								AND b.project_name = @engg_project_name
								AND b.process_name = @prc_name_tmp
								AND b.component_name = @component_name_tmp
								AND b.activity_name = @act_name_tmp
								AND b.ui_name = @ui_name_tmp
								AND b.page_bt_synonym = @engg_grid_page_bts
								AND b.section_bt_synonym = @engg_grid_sec_bts
							)

					IF isnull(@viewname_tmp, '') = ''
					BEGIN
						SELECT @view_name = '1'
					END
					ELSE
					BEGIN
						IF cast(isnull(@hview_name_tmp, '0') AS INT) > cast(@viewname_tmp AS INT)
						BEGIN
							SELECT @view_name = @hview_name_tmp
						END
						ELSE
						BEGIN
							SELECT @view_name = @viewname_tmp
						END
					END

					INSERT INTO de_hidden_view (
						customer_name,
						project_name,
						process_name,
						component_name,
						activity_name,
						ui_name,
						page_name,
						section_name,
						control_bt_synonym,
						hidden_view_bt_synonym,
						transfer_flag,
						hidden_view_sysid,
						control_sysid,
						TIMESTAMP,
						createdby,
						createddate,
						modifiedby,
						modifieddate,
						control_id,
						view_name,
						new_control_bt_synonym,
						HIDDEN_VIEW_SOURCE,
						ecrno
						)
					SELECT @engg_customer_name,
						@engg_project_name,
						@prc_name_tmp,
						@component_name_tmp,
						@act_name_tmp,
						@ui_name_tmp,
						@engg_grid_page_bts,
						@engg_grid_sec_bts,
						@engg_grid_btsynname,
						@hidden_vew_bt_synonym,
						'N',
						newid(),
						newid(),
						1,
						@ctxt_user,
						getdate(),
						@ctxt_user,
						getdate(),
						@ctrl_bt_syn_id,
						@view_name + 1,
						@hidden_vew_bt_synonym,
						NULL,
						NULL
				END
			END

			IF @modeflag = 'D'
				AND isnull(@del_flag, 'T') = 'T' -- Code Modified for PNR2.0_32228   
				AND isnull(@del_flag_ph, 'T') = 'T'
			BEGIN
				/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P begin*/
				DELETE
				FROM de_hidden_view_usage
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND control_page_name = @engg_grid_page_bts
					AND control_bt_sysnonym = @engg_grid_btsynname

				/* Code Modified for the Case ID:PNR2.0_30886 By Shakthi P End*/
				DELETE
				FROM de_hidden_view
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND page_name = @engg_grid_page_bts
					AND section_name = @engg_grid_sec_bts
					AND control_bt_synonym = @engg_grid_btsynname
					AND hidden_view_bt_synonym = @hidden_vew_bt_synonym
			END
		END
	END

	-- Code added By Feroz for Image Control / Ataach Document Control hidden view creation    
	-- Code added for Attachment with Description and Dynamic File upload path of Ataach Document Control Starts
	--select	@control_id_tmp	= Control_id,
	--		@view_name		= view_name
	--from	ep_ui_grid_dtl (nolock)
	--where	customer_name		= @engg_customer_name    
	--and  	project_name		= @engg_project_name    
	--and  	process_name		= @prc_name_tmp    
	--and  	component_name  	= @component_name_tmp    
	--and  	activity_name		= @act_name_tmp    
	--and  	ui_name				= @ui_name_tmp    
	--and  	page_bt_synonym		= @engg_grid_page_bts    
	--and		control_bt_synonym  = @engg_grid_grid_code
	--and		column_bt_synonym	= @engg_grid_btsynname 
	IF @modeflag <> 'S'
	BEGIN
		IF EXISTS (
				SELECT 'X'
				FROM es_comp_ctrl_type_mst(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND ctrl_type_name = @engg_grid_elem_type
					AND (
						attach_document = 'Y'
						AND AttachmentWithDesc = 'y'
						)
				)
		BEGIN
			EXEC ep_attachdoc_hiddenview_ins_sp @ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@engg_customer_name,
				@engg_project_name,
				@prc_name_tmp,
				@component_name_tmp,
				@act_name_tmp,
				@ui_name_tmp,
				@engg_grid_page_bts,
				@engg_grid_sec_bts,
				@engg_grid_grid_code,
				@engg_grid_btsynname,
				@engg_req_no, --@hidden_vew_bt_synonym,
				@tmp_control_type,
				@engg_grid_elem_type,
				@ctrl_bt_syn_id,
				@view_name,
				@modeflag,
				@del_flag,
				@del_flag_ph,
				'ML',
				@m_errorid
		END

		-- code added for Defect ID : TECH-18349 starts
		IF EXISTS (
				SELECT 'x'
				FROM es_comp_ctrl_type_mst mst(NOLOCK),
					es_comp_ctrl_type_mst_extn extn(NOLOCK)
				WHERE mst.customer_name = @engg_customer_name
					AND mst.project_name = @engg_project_name
					AND mst.process_name = @prc_name_tmp
					AND mst.component_name = @component_name_tmp
					AND mst.ctrl_type_name = @engg_grid_elem_type
					AND mst.customer_name = extn.customer_name
					AND mst.project_name = extn.project_name
					AND mst.process_name = extn.process_name
					AND mst.component_name = extn.component_name
					AND mst.ctrl_type_name = extn.ctrl_type_name
					AND mst.base_ctrl_type = extn.base_ctrl_type
					AND (
						attach_document = 'Y'
						AND AttachmentWithDesc = 'y'
						AND Dynamicfileupload = 'Y'
						)
				UNION
				SELECT 'x'
				FROM es_comp_ctrl_type_mst mst(NOLOCK),
					es_comp_ctrl_type_mst_extn extn(NOLOCK)
				WHERE mst.customer_name = @engg_customer_name
					AND mst.project_name = @engg_project_name
					AND mst.process_name = @prc_name_tmp
					AND mst.component_name = @component_name_tmp
					AND mst.ctrl_type_name = @engg_grid_elem_type
					AND mst.customer_name = extn.customer_name
					AND mst.project_name = extn.project_name
					AND mst.process_name = extn.process_name
					AND mst.component_name = extn.component_name
					AND mst.ctrl_type_name = extn.ctrl_type_name
					AND mst.base_ctrl_type = extn.base_ctrl_type
					AND (
						mst.base_ctrl_type		= 'Edit'	
						and		Dynamicfileupload		= 'Y'
						and		image_icon				= 'Y'
						)
				)
		BEGIN
			EXEC ep_Dynamicfileupload_hdnview_sp @ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@engg_customer_name,
				@engg_project_name,
				@prc_name_tmp,
				@component_name_tmp,
				@act_name_tmp,
				@ui_name_tmp,
				@engg_grid_page_bts,
				@engg_grid_sec_bts,
				@engg_grid_grid_code,
				@engg_grid_btsynname,
				@engg_req_no,
				@tmp_control_type,
				@engg_grid_elem_type,
				@ctrl_bt_syn_id,
				@view_name,
				@modeflag,
				@del_flag,
				@del_flag_ph,
				'ML',
				@m_errorid
		END

		-- code added for Defect ID : TECH-18349 starts
		IF EXISTS (
				SELECT 'x'
				FROM es_comp_ctrl_type_mst mst(NOLOCK),
					es_comp_ctrl_type_mst_extn extn(NOLOCK)
				WHERE mst.customer_name = @engg_customer_name
					AND mst.project_name = @engg_project_name
					AND mst.process_name = @prc_name_tmp
					AND mst.component_name = @component_name_tmp
					AND mst.ctrl_type_name = @engg_grid_elem_type
					AND mst.customer_name = extn.customer_name
					AND mst.project_name = extn.project_name
					AND mst.process_name = extn.process_name
					AND mst.component_name = extn.component_name
					AND mst.ctrl_type_name = extn.ctrl_type_name
					AND mst.base_ctrl_type = extn.base_ctrl_type
					AND (
						attach_document = 'Y'
						AND AttachmentWithDesc = 'y'
						AND MultifileSelect = 'Y'
						)
				)
		BEGIN
			EXEC ep_MultiFileSelect_hdnview_sp @ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@engg_customer_name,
				@engg_project_name,
				@prc_name_tmp,
				@component_name_tmp,
				@act_name_tmp,
				@ui_name_tmp,
				@engg_grid_page_bts,
				@engg_grid_sec_bts,
				@engg_grid_grid_code,
				@engg_grid_btsynname,
				@engg_req_no,
				@tmp_control_type,
				@engg_grid_elem_type,
				@ctrl_bt_syn_id,
				@view_name,
				@modeflag,
				@del_flag,
				@del_flag_ph,
				'ML',
				@m_errorid
		END

		-- code added for JL starts
		IF EXISTS (
				SELECT 'x'
				FROM es_comp_ctrl_type_mst mst(NOLOCK),
					es_comp_ctrl_type_mst_extn extn(NOLOCK)
				WHERE mst.customer_name = @engg_customer_name
					AND mst.project_name = @engg_project_name
					AND mst.process_name = @prc_name_tmp
					AND mst.component_name = @component_name_tmp
					AND mst.ctrl_type_name = @engg_grid_elem_type
					AND mst.customer_name = extn.customer_name
					AND mst.project_name = extn.project_name
					AND mst.process_name = extn.process_name
					AND mst.component_name = extn.component_name
					AND mst.ctrl_type_name = extn.ctrl_type_name
					AND mst.base_ctrl_type = extn.base_ctrl_type
					AND (
						extn.MetaDataBasedLink = 'Y'
						AND mst.base_ctrl_type IN (
							'DataHyperLink',
							'Link'
							)
						)
				)
		BEGIN
			EXEC ep_MetaDataBasedLink_hdnview_sp @ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@engg_customer_name,
				@engg_project_name,
				@prc_name_tmp,
				@component_name_tmp,
				@act_name_tmp,
				@ui_name_tmp,
				@engg_grid_page_bts,
				@engg_grid_sec_bts,
				@engg_grid_grid_code,
				@engg_grid_btsynname,
				@engg_req_no,
				@tmp_control_type,
				@engg_grid_elem_type,
				@ctrl_bt_syn_id,
				@view_name,
				@modeflag,
				@del_flag,
				@del_flag_ph,
				'ML',
				@m_errorid
		END

		-- code added for JL ends
		/*code added by vijay on 29/12/03 for inserting into ep_action_mst*/
		IF @modeflag = 'D'
			AND isnull(@del_flag, 'T') = 'T' -- Code Modified for PNR2.0_32228    
			AND isnull(@del_flag_ph, 'T') = 'T'
		BEGIN
			IF EXISTS (
					SELECT 'X'
					FROM ep_ui_grid_dtl(NOLOCK)
					WHERE customer_name = rtrim(@engg_customer_name)
						AND project_name = rtrim(@engg_project_name)
						AND req_no = rtrim(@engg_base_req_no)
						AND process_name = rtrim(@prc_name_tmp)
						AND component_name = rtrim(@component_name_tmp)
						AND activity_name = rtrim(@act_name_tmp)
						AND ui_name = rtrim(@ui_name_tmp)
						AND page_bt_synonym = rtrim(@engg_grid_page_bts)
						AND section_bt_synonym = rtrim(@engg_grid_sec_bts)
						AND control_bt_synonym = rtrim(@engg_grid_grid_code)
						AND column_bt_synonym = rtrim(@engg_grid_btsynname)
					)
			BEGIN
				-- code modified by shafina on 27-April-2004 for PREVIEWENG203ACC_000045    
				DECLARE task_del_cur INSENSITIVE CURSOR
				FOR
				SELECT task_name
				FROM ep_action_mst a(NOLOCK),
					ep_ui_grid_dtl b(NOLOCK)
				WHERE a.customer_name = @engg_customer_name
					AND a.project_name = @engg_project_name
					AND a.req_no = @engg_base_req_no
					AND a.process_name = @prc_name_tmp
					AND a.component_name = @component_name_tmp
					AND a.activity_name = @act_name_tmp
					AND a.ui_name = @ui_name_tmp
					AND a.page_bt_synonym = @engg_grid_page_bts
					AND a.customer_name = b.customer_name
					AND a.project_name = b.project_name
					AND a.req_no = b.req_no
					AND a.process_name = b.process_name
					AND a.component_name = b.component_name
					AND a.activity_name = b.activity_name
					AND a.ui_name = b.ui_name
					AND a.page_bt_synonym = b.page_bt_synonym
					AND b.section_bt_synonym = @engg_grid_sec_bts
					AND b.control_bt_synonym = @engg_grid_grid_code
					AND b.column_bt_synonym = @engg_grid_btsynname
					AND a.primary_control_bts = @engg_grid_btsynname

				OPEN task_del_cur

				WHILE (1 = 1)
				BEGIN
					FETCH NEXT
					FROM task_del_cur
					INTO @task_name

					IF @@fetch_status <> 0
						BREAK

					IF isnull(@task_name, '') <> ''
					BEGIN
						IF EXISTS (
								SELECT 'x'
								FROM ep_flowbr_mst(NOLOCK)
								WHERE customer_name = @engg_customer_name
									AND project_name = @engg_project_name
									AND req_no = @engg_base_req_no
									AND process_name = @prc_name_tmp
									AND component_name = @component_name_tmp
									AND activity_name = @act_name_tmp
									AND ui_name = @ui_name_tmp
									AND page_bt_synonym = @engg_grid_page_bts
									AND task_name = @task_name
								)
						BEGIN
							DELETE ep_flowbr_mst
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND req_no = @engg_base_req_no
								AND process_name = @prc_name_tmp
								AND component_name = @component_name_tmp
								AND activity_name = @act_name_tmp
								AND ui_name = @ui_name_tmp
								AND page_bt_synonym = @engg_grid_page_bts
								AND task_name = @task_name
						END

						IF EXISTS (
								SELECT 'x'
								FROM ep_action_section_map(NOLOCK)
								WHERE customer_name = @engg_customer_name
									AND project_name = @engg_project_name
									AND req_no = @engg_base_req_no
									AND process_name = @prc_name_tmp
									AND component_name = @component_name_tmp
									AND activity_name = @act_name_tmp
									AND ui_name = @ui_name_tmp
									AND page_bt_synonym = @engg_grid_page_bts
									AND task_name = @task_name
								)
						BEGIN
							DELETE ep_action_section_map
							WHERE customer_name = @engg_customer_name
								AND project_name = @engg_project_name
								AND req_no = @engg_base_req_no
								AND process_name = @prc_name_tmp
								AND component_name = @component_name_tmp
								AND activity_name = @act_name_tmp
								AND ui_name = @ui_name_tmp
								AND page_bt_synonym = @engg_grid_page_bts
								AND task_name = @task_name
						END

						EXEC ep_action_mst_sp_del @ctxt_language,
							@ctxt_ouinstance,
							@ctxt_service,
							@ctxt_user,
							@engg_customer_name,
							@engg_project_name,
							@engg_base_req_no,
							@prc_name_tmp,
							@component_name_tmp,
							@act_name_tmp,
							@ui_name_tmp,
							@engg_grid_page_bts,
							@task_name,
							@m_errorid OUTPUT

						IF @m_errorid <> 0
						BEGIN
							CLOSE task_del_cur

							DEALLOCATE task_del_cur

							RETURN
						END
					END
				END

				CLOSE task_del_cur

				DEALLOCATE task_del_cur

				DELETE
				FROM ep_ui_traversal_dtl
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = @engg_grid_page_bts
					AND section_bt_synonym = @engg_grid_sec_bts
					AND control_bt_synonym = @engg_grid_btsynname
					AND isnull(linked_component, '') = ''
					AND isnull(linked_activity, '') = ''
					AND isnull(linked_ui, '') = ''

				EXEC ep_ui_grid_dtl_sp_del @ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@engg_customer_name,
					@engg_project_name,
					@engg_base_req_no,
					@prc_name_tmp,
					@component_name_tmp,
					@act_name_tmp,
					@ui_name_tmp,
					@engg_grid_page_bts,
					@engg_grid_sec_bts,
					@engg_grid_grid_code,
					@engg_grid_btsynname,
					@m_errorid OUTPUT

				--For Deleting Control which does not exist in grid dtl 
				DELETE ep_phone_grid_dtl
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = @engg_grid_page_bts
					AND section_bt_synonym = @engg_grid_sec_bts
					AND control_bt_synonym = @engg_grid_grid_code
					AND column_bt_synonym = @engg_grid_btsynname

				DELETE ep_tablet_grid_dtl
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = @engg_grid_page_bts
					AND section_bt_synonym = @engg_grid_sec_bts
					AND control_bt_synonym = @engg_grid_grid_code
					AND column_bt_synonym = @engg_grid_btsynname

				IF @m_errorid > 0
					RETURN
						-- modified by vasu date:28-12-2003    
						-- to delete the control bt synonym from glossary which is in grid control    
						-- modified by shafina on 07-feb-2004 to check for existence of btsynonym    
						-- modified by shafina on 09-Apr-2004 for PREVIEWENG203ACC_000013    
						/*  declare @cnt int    
select @cnt = 0    
select @cnt = count('x')    
from ep_ui_page_dtl (nolock)    
where customer_name = @engg_customer_name    
and  project_name = @engg_project_name    
and  page_bt_synonym = @engg_grid_btsynname    
    
select @cnt = @cnt +    
(    
select count('x')    
from ep_ui_section_dtl (nolock)    
where customer_name = @engg_customer_name    
and  project_name = @engg_project_name    
and  section_bt_synonym = @engg_grid_btsynname    
)    
    
select @cnt = @cnt +    
(    
select count('x')    
from ep_ui_control_dtl (nolock)    
where customer_name = @engg_customer_name    
and  project_name = @engg_project_name    
and  control_bt_synonym = @engg_grid_btsynname    
)    
    
select @cnt = @cnt +    
(    
select count('x')    
from ep_ui_grid_dtl (nolock)    
where customer_name = @engg_customer_name    
and  project_name = @engg_project_name    
and  column_bt_synonym = @engg_grid_btsynname    
)    
if @cnt  = 0    
begin    
if exists  (select 'x'    
from ep_component_glossary_mst (nolock)    
where  customer_name =   @engg_customer_name    
and    project_name    =   @engg_project_name    
and    req_no          =   @engg_base_req_no    
and  process_name =  @prc_name_tmp    
and  component_name =  @component_name_tmp    
and    bt_synonym_name = @engg_grid_btsynname)    
begin    
exec ep_component_glossary_mst_sp_del    
@ctxt_language,    
@ctxt_ouinstance,    
@ctxt_service,    
@ctxt_user,    
@engg_customer_name,    
@engg_project_name,    
@engg_base_req_no,    
@prc_name_tmp,    
@component_name_tmp,    
@engg_grid_btsynname,    
@m_errorid out--PARAMETER ADDED BY GIRIDHARAN V ON 10/01/2004    
    
If @m_errorID >0    
return    
end    
end*/
			END
		END

		IF EXISTS (
				SELECT 'x'
				FROM sysobjects(NOLOCK)
				WHERE name = 'de_customer_space'
					AND type = 'u'
				)
		BEGIN
			UPDATE de_customer_space
			SET validate_req = 'Y'
			WHERE customername = @engg_customer_name
				AND projectname = @engg_project_name
				AND processname = @prc_name_tmp
				AND componentname = @component_name_tmp
		END

		-- For Tag Control Starts
		DECLARE @temp_column_name engg_name,
			@cnt engg_seqno,
			@count_stack engg_seqno

		IF @modeflag IN (
				'I',
				'X',
				'U',
				'Y'
				)
		BEGIN
			IF EXISTS (
					SELECT 'x'
					FROM es_comp_ctrl_type_mst_vw(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND ctrl_type_name = @engg_grid_elem_type
						AND req_no = @engg_base_req_no
						AND renderas = 'Tag'
					)
			BEGIN
				SELECT @control_id = control_id
				FROM ep_ui_control_dtl(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @prc_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @act_name_tmp
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = @engg_grid_page_bts
					AND section_bt_synonym = @engg_grid_sec_bts
					AND control_bt_synonym = @engg_grid_grid_code

				INSERT ep_ui_grid_dtl (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					activity_name,
					ui_name,
					page_bt_synonym,
					section_bt_synonym,
					control_bt_synonym,
					column_bt_synonym,
					column_type,
					column_no,
					grid_sysid,
					ui_control_sysid,
					TIMESTAMP,
					createdby,
					createddate,
					modifiedby,
					modifieddate,
					control_id,
					view_name,
					visible_length,
					proto_tooltip,
					sample_data,
					col_doc,
					column_prefix,
					wrkreqno,
					Set_User_Pref,
					default_required,
					ColumnClass,
					iskey,
					Kyseq_no,
					visible,
					Forcefit,
					TemplateID,
			--Code added on 19th Jul 2021
					IsExtension,
					ExtensionOrder
					)
				SELECT @engg_customer_name,
					@engg_project_name,
					'Base',
					@prc_name_tmp,
					@component_name_tmp,
					@act_name_tmp,
					@ui_name_tmp,
					@engg_grid_page_bts,
					@engg_grid_sec_bts,
					@engg_grid_btsynname,
					@engg_grid_btsynname + '_ky',
					'DisplayOnly',
					'1',
					newid(),
					newid(),
					1,
					@ctxt_user,
					getdate(),
					@ctxt_user,
					getdate(),
					@control_id,
					'tagkeyfield',
					NULL,
					NULL,
					'',
					@engg_grid_btsynname + '_ky',
					'',
					'',
					'',
					NULL,
					NULL,
					NULL,
					NULL,
					'Yes',
					NULL,
					NULL,
					@engg_extensionreqd, --Code added for TECH-60451
					@engg_extensionorder  --Code added for TECH-60451
				
				UNION
				
				SELECT @engg_customer_name,
					@engg_project_name,
					'Base',
					@prc_name_tmp,
					@component_name_tmp,
					@act_name_tmp,
					@ui_name_tmp,
					@engg_grid_page_bts,
					@engg_grid_sec_bts,
					@engg_grid_btsynname,
					@engg_grid_btsynname + '_va',
					'DisplayOnly',
					'2',
					newid(),
					newid(),
					1,
					@ctxt_user,
					getdate(),
					@ctxt_user,
					getdate(),
					@control_id,
					'tagvalue',
					NULL,
					NULL,
					'',
					@engg_grid_btsynname + '_va',
					'',
					'',
					'',
					NULL,
					NULL,
					NULL,
					NULL,
					'Yes',
					NULL,
					NULL,
					@engg_extensionreqd, --Code added for TECH-60451
					@engg_extensionorder  --Code added for TECH-60451
				
				UNION
				
				SELECT @engg_customer_name,
					@engg_project_name,
					'Base',
					@prc_name_tmp,
					@component_name_tmp,
					@act_name_tmp,
					@ui_name_tmp,
					@engg_grid_page_bts,
					@engg_grid_sec_bts,
					@engg_grid_btsynname,
					@engg_grid_btsynname + '_sq',
					'Edit',
					'3',
					newid(),
					newid(),
					1,
					@ctxt_user,
					getdate(),
					@ctxt_user,
					getdate(),
					@control_id,
					'tagseqno',
					NULL,
					NULL,
					'',
					@engg_grid_btsynname + '_sq',
					'',
					'',
					'',
					NULL,
					NULL,
					NULL,
					NULL,
					'Yes',
					NULL,
					NULL,
					@engg_extensionreqd, --Code added for TECH-60451
					@engg_extensionorder  --Code added for TECH-60451

				CREATE TABLE #tag_columns (
					id INT identity,
					column_name VARCHAR(60)
					)

				INSERT #tag_columns (Column_name)
				SELECT @engg_grid_btsynname + '_ky'
				
				UNION
				
				SELECT @engg_grid_btsynname + '_va'
				
				UNION
				
				SELECT @engg_grid_btsynname + '_sq'

				--declare @temp_column_name engg_name , @cnt engg_seqno , @count_stack  engg_seqno 
				SET @cnt = 1
				SET @count_stack = 3

				WHILE (@count_stack > @cnt)
				BEGIN
					SELECT @temp_column_name = column_name
					FROM #tag_columns
					WHERE id = @cnt

					EXEC engg_gen_prefix_id @engg_customer_name,
						@engg_project_name,
						@component_name_tmp,
						@act_name_tmp,
						@ui_name_tmp,
						@temp_column_name,
						'C',
						6,
						@page_prefix_tmp OUTPUT

					UPDATE ep_ui_grid_dtl
					SET column_prefix = @page_prefix_tmp
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @prc_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @act_name_tmp
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = @engg_grid_page_bts
						AND section_bt_synonym = @engg_grid_sec_bts
						AND control_bt_synonym = @engg_grid_btsynname
						AND column_bt_synonym = @temp_column_name

					SET @cnt = @cnt + 1
				END

				DROP TABLE #tag_columns
			END
		END

		-- For Tag Control Ends

	UPDATE ep_ui_grid_dtl
	SET Compactview = Case @col_Compact_View when 1 then 'Y'   
							Else 'N'  
						End		
	WHERE customer_name = @engg_customer_name
	AND project_name = @engg_project_name
	AND process_name = @prc_name_tmp
	AND component_name = @component_name_tmp
	AND activity_name = @act_name_tmp
	AND ui_name = @ui_name_tmp
	AND page_bt_synonym = @engg_grid_page_bts
	AND control_bt_synonym = @engg_grid_grid_code
	AND column_bt_synonym = @engg_grid_btsynname


IF ((@engg_grid_btsynname like '%_dic' ) or (@engg_grid_btsynname like '%_selreqd'))  and @engg_grid_doc = 'System Generated' 
BEGIN
	RAISERROR ('System Generated column cannot be deleted.', 16, 1)
	RETURN
END

--Code added by 13639 on 25thJuly2022 starts
			
IF ISNULL(@modeflag,'') IN ('I','X','U','Y') 
BEGIN
	IF ISNULL(@col_associate_ctrl,'') = ''	AND ISNULL(@engg_grid_elem_type,'') IN ('Filesize','FileType') --Code Added for TECH-71262
	BEGIN
	RAISERROR('Please associate Attachment enabled Edit Control in the Associate Control. Please check at row no:%i',16,1,@fprowno)
	return
	end
end
IF ISNULL(@modeflag,'') IN ('I','X','U','Y') and  ISNULL(@col_associate_ctrl,'') <> ''	
	begin
	 IF not EXISTS( SELECT 'X' FROM
	              ep_ui_grid_dtl WITH (NOLOCK)
				  WHERE	customer_name		=  @engg_customer_name  
				  AND	project_name		=  @engg_project_name  
				  AND	process_name		=  @prc_name_tmp  
				  AND   component_name		=  @component_name_tmp  
				  AND	activity_name		=  @act_name_tmp  
				  AND	ui_name				=  @ui_name_tmp  
				  AND	column_bt_synonym	=  @col_associate_ctrl)
		BEGIN
			RAISERROR('Associated control is not available for this UI. Please check at row no:%i',16,1,@fprowno)
			RETURN
		END
	end


	IF ISNULL(@modeflag,'') IN ('I','X','U','Y') 
	BEGIN
		IF ISNULL(@col_associate_ctrl,'') <> '' AND ISNULL(@engg_grid_elem_type,'') IN ('Filesize','Filetype') 
		AND NOT EXISTS (SELECT 'X'
		FROM es_comp_ctrl_type_mst a (NOLOCK)
		JOIN ep_ui_grid_dtl b (NOLOCK)
		ON  a.customer_name		= b.customer_name
		AND	a.project_name		= b.project_name
		AND	a.process_name		= b.process_name
		AND a.component_name	= b.component_name
		AND a.ctrl_type_name    = b.column_type

        WHERE	   b.customer_name		  = @engg_customer_name
        AND        b.project_name		  = @engg_project_name
        AND        b.process_name		  = @prc_name_tmp
        AND        b.component_name       = @component_name_tmp
		AND		   b.activity_name		  = @act_name_tmp  
		AND		   b.ui_name			  = @ui_name_tmp  
		AND		   b.page_bt_synonym	  = @engg_grid_page_bts
		AND		   b.section_bt_synonym   = @engg_grid_sec_bts
		AND		   b.control_bt_synonym   = @engg_grid_grid_code
		AND		   b.column_bt_synonym	  = @col_associate_ctrl
		AND        a.attach_document      = 'y'
        AND        a.AttachmentWithDesc   = 'y'
		and		   a.base_ctrl_type		  = 'Edit'
		)
		BEGIN
		RAISERROR ('Filesize & Filetype should be associated with Attachment enabled columns at rowno : %i.',16,1,@fprowno)
		RETURN
		END
	END

----Code added by 13639 on 25thJuly2022 ends

--IF @modeflag = 'D' AND ISNULL(@col_Icon_class,'') = 'Dynamic'
--BEGIN

--	DELETE 
--		FROM	ep_ui_grid_dtl
--		WHERE	customer_name			= @engg_customer_name
--		AND		project_name			= @engg_project_name		
--		AND		process_name			= @prc_name_tmp
--		AND		component_name			= @component_name_tmp
--		AND		activity_name			= @act_name_tmp
--		AND		ui_name					= @ui_name_tmp
--		AND		page_bt_synonym			= @engg_grid_page_bts
--		AND		section_bt_synonym		= @engg_grid_sec_bts
--		AND		control_bt_synonym		= @engg_grid_grid_code
--		AND		Column_bt_synonym		= ISNULL(@engg_grid_btsynname,'') + '_dic'
--END



--	IF ISNULL(@col_Icon_class, '') = 'Dynamic' AND @modeflag <> 'D' 
--	BEGIN
	
--			Exec ep_columncreation_sp
--								@ctxt_OUInstance			= @ctxt_OUInstance,
--								@ctxt_User					= @ctxt_User,
--								@ctxt_Language				= @ctxt_Language,
--								@ctxt_Service				= @ctxt_Service,
--								@engg_customer_name			= @engg_customer_name,
--								@engg_project_name			= @engg_project_name,
--								@engg_process_name			= @prc_name_tmp,
--								@engg_component_name		= @component_name_tmp,
--								@engg_activity_name			= @act_name_tmp,
--								@engg_ui_name				= @ui_name_tmp,
--								@engg_page_name				= @engg_grid_page_bts,
--								@engg_section_name			= @engg_grid_sec_bts,
--								@engg_control_name			= @engg_grid_grid_code,
--								@engg_column_name			= @engg_grid_btsynname,
--								@engg_req_no				= 'BASE',
--								@ModeFlag					= @ModeFlag,
--								@CreatingFor				= 'ColumnDynamicIconClass',
--								@m_errorid					= @m_errorid output
--	END
--	ELSE IF ISNULL(@col_Icon_class,'') <> 'Dynamic' and  ISNULL(@col_Icon_class,'') = ''	
--	BEGIN

--		DELETE 
--		FROM	ep_ui_grid_dtl
--		WHERE	customer_name			= @engg_customer_name
--		AND		project_name			= @engg_project_name		
--		AND		process_name			= @prc_name_tmp
--		AND		component_name			= @component_name_tmp
--		AND		activity_name			= @act_name_tmp
--		AND		ui_name					= @ui_name_tmp
--		AND		page_bt_synonym			= @engg_grid_page_bts
--		AND		section_bt_synonym		= @engg_grid_sec_bts
--		AND		control_bt_synonym		= @engg_grid_grid_code
--		AND		Column_bt_synonym		= ISNULL(@engg_grid_btsynname,'') + '_dic'

--END


IF @modeflag = 'D' AND ISNULL(@col_Icon_class,'') = 'Dynamic'
BEGIN
	DELETE FROM de_hidden_View
	WHERE	customer_name			= @engg_customer_name
	AND		project_name			= @engg_project_name	
	AND		process_name			= @prc_name_tmp
	AND		component_name			= @component_name_tmp
	AND		activity_name			= @act_name_tmp
	AND		ui_name					= @ui_name_tmp
	AND		page_name				= @engg_grid_page_bts
	AND		section_name			= @engg_grid_sec_bts
	AND		control_bt_synonym		= @engg_grid_btsynname
END

IF ISNULL(@col_Icon_class,'') = 'Dynamic'  AND @modeflag <> 'D' 
BEGIN

		EXEC Hiddenview_Creation_sp
								@ctxt_ouinstance				= @ctxt_ouinstance,
								@ctxt_user						= @ctxt_user,
								@ctxt_language					= @ctxt_language,
								@ctxt_service					= @ctxt_service,								
								@engg_customer					= @engg_customer_name,
								@engg_project					= @engg_project_name,
								@engg_ProcessName				= @prc_name_tmp,
								@engg_componentname				= @component_name_tmp,
								@engg_activityname				= @act_name_tmp,
								@engg_uiname					= @ui_name_tmp,
								@engg_pagesynonym				= @engg_grid_page_bts,
								@engg_sectionsynonym			= @engg_grid_sec_bts,
								@engg_controlsynonym			= @engg_grid_btsynname,								
								@creatingFor					= 'MLDynamicIconClass',
								@m_errorid						= @m_errorid output
END
ELSE IF ISNULL(@col_Icon_class,'') <> 'Dynamic' and  ISNULL(@col_Icon_class,'') = ''
	
BEGIN

		DELETE 
		FROM	de_hidden_view
		WHERE	customer_name			= @engg_customer_name
		AND		project_name			= @engg_project_name		
		AND		process_name			= @prc_name_tmp
		AND		component_name			= @component_name_tmp
		AND		activity_name			= @act_name_tmp
		AND		ui_name					= @ui_name_tmp
		AND		page_name				= @engg_grid_page_bts
		AND		section_name			= @engg_grid_sec_bts
		AND		control_bt_synonym		= @engg_grid_btsynname
		AND		hidden_view_bt_synonym	LIKE 'hdiDIC%'

END
--- **************

	--Code Added by 13639 on 12-Nov-2020 for the DefectId : TECH-51746 starts 
		EXEC ep_set_leave_focusevent_ins_sp
						@ctxt_language_in		=	@ctxt_language, 
						@ctxt_ouinstance_in		=	@ctxt_ouinstance,	
						@ctxt_service_in		=	@ctxt_service,	
						@ctxt_user_in			=	@ctxt_user,	
						@customer_name_in		=	@engg_customer_name,
						@project_name_in		=	@engg_project_name,
						@req_no_in				=	@engg_base_req_no,
						@process_name_in		=	@prc_name_tmp,
						@component_name_in		=	@component_name_tmp,
						@activity_name_in		=	@act_name_tmp,
						@ui_name_in				=   @ui_name_tmp ,
						@page_bt_synonym_in		=	@engg_grid_page_bts,
						@sec_bt_synonym_in		=	@engg_grid_sec_bts,
						@control_bt_synonym_in	=	@engg_grid_grid_code ,
						@column_bt_synonym_in   =   @engg_grid_btsynname ,
						@control_type_name_in	=	@engg_grid_elem_type,
						@modeflag				=	@modeflag,
						@m_errorid				=	@M_ERRORID	
	--Code Added by 13639 on 12-Nov-2020 for the DefectId : TECH-51746 Ends	

		----Code added for defectid TECH-68066 by 14469 starts

	DECLARE @Pre_Taskname engg_name, @Post_Taskname engg_name,	@Pre_Taskdesc	engg_name, @Post_Taskdesc	engg_name,
			@comp_pfx_tmp engg_name, @ui_pfx_tmp engg_name,		@ctrl_pfx_tmp	engg_name, @control_caption engg_name,
			@BrowsePreTask engg_name, @BrowsePostTask engg_name,  @BrowsePreTaskDesc engg_name, @BrowsePostTaskDesc engg_name,  --15Jul2022
			@DeletePreTask engg_name, @DeletePostTask engg_name,  @DeletePreTaskDesc engg_name, @DeletePostTaskDesc engg_name

	SELECT	@comp_pfx_tmp	= current_value
	FROM	es_comp_param_mst (NOLOCK)
	WHERE	customer_name	= rtrim(@engg_customer_name)
	AND		project_name	= rtrim(@engg_project_name)
	AND		process_name	= rtrim(@prc_name_tmp)
	AND		component_name	= rtrim(@component_name_tmp)
	AND		param_category	= 'compprefix' 

	SELECT	@ui_pfx_tmp		= page_prefix
	FROM	ep_ui_page_dtl (NOLOCK)
	WHERE	customer_name	= rtrim(@engg_customer_name)
	AND		project_name	= rtrim(@engg_project_name)
	AND		process_name	= rtrim(@prc_name_tmp)
	AND		component_name	= rtrim(@component_name_tmp)
	AND		req_no			= rtrim(@engg_base_req_no)
	AND 	activity_name   = rtrim(@act_name_tmp)
	AND		ui_name			= rtrim(@ui_name_tmp)
	AND		page_bt_synonym	= '[mainscreen]'
	
	SELECT	@ctrl_pfx_tmp	= column_prefix
	FROM	ep_ui_grid_dtl (NOLOCK)
	WHERE	customer_name	= rtrim(@engg_customer_name)
	and		project_name	= rtrim(@engg_project_name)
	and		process_name	= rtrim(@prc_name_tmp)
	and		component_name	= rtrim(@component_name_tmp)
	and		activity_name	= rtrim(@act_name_tmp)
	and		ui_name			= rtrim(@ui_name_tmp)
	and		page_bt_synonym	= rtrim(@engg_grid_page_bts)
	and		section_bt_synonym = rtrim(@engg_grid_sec_bts)
	and		column_bt_synonym  = rtrim(@engg_grid_btsynname)

	SELECT  @control_caption	=	bt_synonym_caption
	FROM	ep_component_glossary_mst (NOLOCK)
	WHERE	customer_name		= rtrim(@engg_customer_name)
	AND		project_name		= rtrim(@engg_project_name)
	AND		process_name		= rtrim(@prc_name_tmp)
	AND		component_name		= rtrim(@component_name_tmp)
	AND		bt_synonym_name		= rtrim(@engg_grid_btsynname)


	SELECT @Pre_Taskname  = @comp_pfx_tmp + @ui_pfx_tmp + @ctrl_pfx_tmp + 'PrUI',
		   @Post_Taskname  = @comp_pfx_tmp + @ui_pfx_tmp + @ctrl_pfx_tmp + 'PsUI',
		   --Code Added for TECH-71262 starts
		   @BrowsePreTask  = @comp_pfx_tmp + @ui_pfx_tmp + @ctrl_pfx_tmp + 'BrPrUI',			--TECH-71262 	
		   @BrowsePostTask  = @comp_pfx_tmp + @ui_pfx_tmp + @ctrl_pfx_tmp + 'BrPsUI',
		   @DeletePreTask  = @comp_pfx_tmp + @ui_pfx_tmp + @ctrl_pfx_tmp + 'DePrUI',
		   @DeletePostTask  = @comp_pfx_tmp + @ui_pfx_tmp + @ctrl_pfx_tmp + 'DePsUI',
		   --Code Added for TECH-71262 ends
		   @Pre_Taskdesc   = 'Pre Task for attachment of ' + @control_caption,
		   @Post_Taskdesc  = 'Post Task for attachment of ' + @control_caption,
		   --Code Added for TECH-71262 starts
		   @BrowsePreTaskDesc	= 'Browse Pre Task for attachment of ' + @control_caption,   	--TECH-71262 
		   @BrowsePostTaskDesc	= 'Browse Post Task for attachment of ' + @control_caption,
		   @DeletePreTaskDesc	= 'Delete Pre Task for attachment of ' + @control_caption,
		   @DeletePostTaskDesc	= 'Delete Post Task for attachment of ' + @control_caption
		   --Code Added for TECH-71262 ends
	IF ISNULL(@modeflag,'')IN ('I','X','U','Y') AND EXISTS(
	SELECT 'X'
	FROM es_comp_ctrl_type_mst_extn WITH (NOLOCK)
	WHERE customer_name		    =	@engg_customer_name
	AND	  project_name		    =	@engg_project_name
	AND	  process_name		    =	@prc_name_tmp
	AND	  component_name	    =	@component_name_tmp
	AND	  ctrl_type_name		=	@engg_grid_elem_type
	AND	  base_ctrl_type		=	'Edit'
	AND	  ISNULL(PreTask,'')	=	'y'
	)
	BEGIN
		EXEC ep_action_mst_sp_ins
					@CTXT_LANGUAGE_IN			= @ctxt_language,  
					@CTXT_OUINSTANCE_IN			= @ctxt_ouinstance, 
					@CTXT_SERVICE_IN			= @ctxt_service,
					@CTXT_USER_IN				= @ctxt_user, 
					@CUSTOMER_NAME_IN			= @engg_customer_name,
					@PROJECT_NAME_IN			= @engg_project_name,
					@REQ_NO_IN					= @engg_base_req_no,
					@PROCESS_NAME_IN			= @prc_name_tmp,
					@COMPONENT_NAME_IN			= @component_name_tmp,
					@ACTIVITY_NAME_IN			= @act_name_tmp,
					@UI_NAME_IN					= @ui_name_tmp,
					@PAGE_BT_SYNONYM_IN			= @engg_grid_page_bts,
					@TASK_NAME_IN				= @Pre_Taskname,
					@TASK_DESCR_IN				= @Pre_Taskdesc ,
					@TASK_SEQ_IN				= 0,
					@TASK_PATTERN_IN			= 'UI' ,	
					@PRIMARY_CONTROL_BTS_IN		= @engg_grid_btsynname,
					@BASE_TASK_TYPE_IN			= 'UI',
					@TIMESTAMP_IN				= 1 ,
					@engg_req_no				= @engg_req_no,
					@M_ERRORID					= @m_errorid	output								
	END

	IF ISNULL(@modeflag,'')IN ('I','X','U','Y') AND EXISTS(
	SELECT 'X'
	FROM es_comp_ctrl_type_mst_extn WITH (NOLOCK)
	WHERE customer_name		    =	@engg_customer_name
	AND	  project_name		    =	@engg_project_name
	AND	  process_name		    =	@prc_name_tmp
	AND	  component_name	    =	@component_name_tmp
	AND	  ctrl_type_name		=	@engg_grid_elem_type
	AND	  base_ctrl_type		=	'Edit'
	AND	  ISNULL(PostTask,'')	=	'y')
	BEGIN
		EXEC ep_action_mst_sp_ins
					@CTXT_LANGUAGE_IN			= @ctxt_language,  
					@CTXT_OUINSTANCE_IN			= @ctxt_ouinstance, 
					@CTXT_SERVICE_IN			= @ctxt_service,
					@CTXT_USER_IN				= @ctxt_user, 
					@CUSTOMER_NAME_IN			= @engg_customer_name,
					@PROJECT_NAME_IN			= @engg_project_name,
					@REQ_NO_IN					= @engg_base_req_no,
					@PROCESS_NAME_IN			= @prc_name_tmp,
					@COMPONENT_NAME_IN			= @component_name_tmp,
					@ACTIVITY_NAME_IN			= @act_name_tmp,
					@UI_NAME_IN					= @ui_name_tmp,
					@PAGE_BT_SYNONYM_IN			= @engg_grid_page_bts,
					@TASK_NAME_IN				= @Post_Taskname,
					@TASK_DESCR_IN				= @Post_Taskdesc ,
					@TASK_SEQ_IN				= 0,
					@TASK_PATTERN_IN			= 'UI' ,	
					@PRIMARY_CONTROL_BTS_IN		= @engg_grid_btsynname,
					@BASE_TASK_TYPE_IN			= 'UI',
					@TIMESTAMP_IN				= 1 ,
					@engg_req_no				= @engg_req_no,
					@M_ERRORID					= @m_errorid	output								
	END
	----Code added for defectid TECH-68066 by 14469 ends

	--Code Added for TECH-71262 starts

	IF ISNULL(@modeflag,'') IN ('I','X','U','Y') AND  EXISTS(
	SELECT 'X'
	FROM es_comp_ctrl_type_mst_extn WITH (NOLOCK)
	WHERE customer_name		    =	@engg_customer_name
	AND	  project_name		    =	@engg_project_name
	AND	  process_name		    =	@prc_name_tmp
	AND	  component_name	    =	@component_name_tmp
	AND	  ctrl_type_name		=	@engg_grid_elem_type
	AND	  base_ctrl_type		=	'Edit'
	AND	  ISNULL(BrowsePreTask,'')	=	'y')
	BEGIN
		EXEC ep_action_mst_sp_ins
					@CTXT_LANGUAGE_IN			= @ctxt_language,  
					@CTXT_OUINSTANCE_IN			= @ctxt_ouinstance, 
					@CTXT_SERVICE_IN			= @ctxt_service,
					@CTXT_USER_IN				= @ctxt_user, 
					@CUSTOMER_NAME_IN			= @engg_customer_name,
					@PROJECT_NAME_IN			= @engg_project_name,
					@REQ_NO_IN					= @engg_base_req_no,
					@PROCESS_NAME_IN			= @prc_name_tmp,
					@COMPONENT_NAME_IN			= @component_name_tmp,
					@ACTIVITY_NAME_IN			= @act_name_tmp,
					@UI_NAME_IN					= @ui_name_tmp,
					@PAGE_BT_SYNONYM_IN			= @engg_grid_page_bts,
					@TASK_NAME_IN				= @BrowsePreTask,
					@TASK_DESCR_IN				= @BrowsePreTaskDesc ,
					@TASK_SEQ_IN				= 0,
					@TASK_PATTERN_IN			= 'UI' ,	
					@PRIMARY_CONTROL_BTS_IN		= @engg_grid_btsynname,
					@BASE_TASK_TYPE_IN			= 'UI',
					@TIMESTAMP_IN				= 1 ,
					@engg_req_no				= @engg_req_no,
					@M_ERRORID					= @m_errorid	output									
	END

	IF ISNULL(@modeflag,'') IN ('I','X','U','Y') AND  EXISTS(
	SELECT 'X'
	FROM es_comp_ctrl_type_mst_extn WITH (NOLOCK)
	WHERE customer_name		    =	@engg_customer_name
	AND	  project_name		    =	@engg_project_name
	AND	  process_name		    =	@prc_name_tmp
	AND	  component_name	    =	@component_name_tmp
	AND	  ctrl_type_name		=	@engg_grid_elem_type
	AND	  base_ctrl_type		=	'Edit'
	AND	  ISNULL(BrowsePostTask,'')	=	'y')
	BEGIN
		EXEC ep_action_mst_sp_ins
					@CTXT_LANGUAGE_IN			= @ctxt_language,  
					@CTXT_OUINSTANCE_IN			= @ctxt_ouinstance, 
					@CTXT_SERVICE_IN			= @ctxt_service,
					@CTXT_USER_IN				= @ctxt_user, 
					@CUSTOMER_NAME_IN			= @engg_customer_name,
					@PROJECT_NAME_IN			= @engg_project_name,
					@REQ_NO_IN					= @engg_base_req_no,
					@PROCESS_NAME_IN			= @prc_name_tmp,
					@COMPONENT_NAME_IN			= @component_name_tmp,
					@ACTIVITY_NAME_IN			= @act_name_tmp,
					@UI_NAME_IN					= @ui_name_tmp,
					@PAGE_BT_SYNONYM_IN			= @engg_grid_page_bts,
					@TASK_NAME_IN				= @BrowsePostTask,
					@TASK_DESCR_IN				= @BrowsePostTaskDesc ,
					@TASK_SEQ_IN				= 0,
					@TASK_PATTERN_IN			= 'UI' ,	
					@PRIMARY_CONTROL_BTS_IN		= @engg_grid_btsynname,
					@BASE_TASK_TYPE_IN			= 'UI',
					@TIMESTAMP_IN				= 1 ,
					@engg_req_no				= @engg_req_no,
					@M_ERRORID					= @m_errorid	output									
	END

	IF ISNULL(@modeflag,'') IN ('I','X','U','Y') AND  EXISTS(
	SELECT 'X'
	FROM es_comp_ctrl_type_mst_extn WITH (NOLOCK)
	WHERE customer_name		    =	@engg_customer_name
	AND	  project_name		    =	@engg_project_name
	AND	  process_name		    =	@prc_name_tmp
	AND	  component_name	    =	@component_name_tmp
	AND	  ctrl_type_name		=	@engg_grid_elem_type
	AND	  base_ctrl_type		=	'Edit'
	AND	  ISNULL(DeletePreTask,'')	=	'y')
	BEGIN
		EXEC ep_action_mst_sp_ins
					@CTXT_LANGUAGE_IN			= @ctxt_language,  
					@CTXT_OUINSTANCE_IN			= @ctxt_ouinstance, 
					@CTXT_SERVICE_IN			= @ctxt_service,
					@CTXT_USER_IN				= @ctxt_user, 
					@CUSTOMER_NAME_IN			= @engg_customer_name,
					@PROJECT_NAME_IN			= @engg_project_name,
					@REQ_NO_IN					= @engg_base_req_no,
					@PROCESS_NAME_IN			= @prc_name_tmp,
					@COMPONENT_NAME_IN			= @component_name_tmp,
					@ACTIVITY_NAME_IN			= @act_name_tmp,
					@UI_NAME_IN					= @ui_name_tmp,
					@PAGE_BT_SYNONYM_IN			= @engg_grid_page_bts,
					@TASK_NAME_IN				= @DeletePreTask,
					@TASK_DESCR_IN				= @DeletePreTaskDesc ,
					@TASK_SEQ_IN				= 0,
					@TASK_PATTERN_IN			= 'UI' ,	
					@PRIMARY_CONTROL_BTS_IN		= @engg_grid_btsynname,
					@BASE_TASK_TYPE_IN			= 'UI',
					@TIMESTAMP_IN				= 1 ,
					@engg_req_no				= @engg_req_no,
					@M_ERRORID					= @m_errorid	output									
	END

	
	IF ISNULL(@modeflag,'') IN ('I','X','U','Y') AND  EXISTS(
	SELECT 'X'
	FROM es_comp_ctrl_type_mst_extn WITH (NOLOCK)
	WHERE customer_name		    =	@engg_customer_name
	AND	  project_name		    =	@engg_project_name
	AND	  process_name		    =	@prc_name_tmp
	AND	  component_name	    =	@component_name_tmp
	AND	  ctrl_type_name		=	@engg_grid_elem_type
	AND	  base_ctrl_type		=	'Edit'
	AND	  ISNULL(DeletePostTask,'')	=	'y')
	BEGIN
		EXEC ep_action_mst_sp_ins
					@CTXT_LANGUAGE_IN			= @ctxt_language,  
					@CTXT_OUINSTANCE_IN			= @ctxt_ouinstance, 
					@CTXT_SERVICE_IN			= @ctxt_service,
					@CTXT_USER_IN				= @ctxt_user, 
					@CUSTOMER_NAME_IN			= @engg_customer_name,
					@PROJECT_NAME_IN			= @engg_project_name,
					@REQ_NO_IN					= @engg_base_req_no,
					@PROCESS_NAME_IN			= @prc_name_tmp,
					@COMPONENT_NAME_IN			= @component_name_tmp,
					@ACTIVITY_NAME_IN			= @act_name_tmp,
					@UI_NAME_IN					= @ui_name_tmp,
					@PAGE_BT_SYNONYM_IN			= @engg_grid_page_bts,
					@TASK_NAME_IN				= @DeletePostTask,
					@TASK_DESCR_IN				= @DeletePostTaskDesc ,
					@TASK_SEQ_IN				= 0,
					@TASK_PATTERN_IN			= 'UI' ,	
					@PRIMARY_CONTROL_BTS_IN		= @engg_grid_btsynname,
					@BASE_TASK_TYPE_IN			= 'UI',
					@TIMESTAMP_IN				= 1 ,
					@engg_req_no				= @engg_req_no,
					@M_ERRORID					= @m_errorid	output									
	END
	--Code Added for TECH-71262 ends

		--TECH-73996
	DECLARE @tmp_base_ctrl_type	engg_name, @hiddenbtsynonym engg_name

	SELECT @hiddenbtsynonym	=	'hdnauto'+@ctrl_pfx_tmp

	SELECT	@tmp_base_ctrl_type	=	base_ctrl_type
	FROM	es_comp_ctrl_type_mst_extn with(nolock)
	WHERE	customer_name	=	@engg_customer_name
	AND		project_name	=	@engg_project_name
	AND		process_name	=	@prc_name_tmp
	AND		component_name	=	@component_name_tmp
	AND		ctrl_type_name	=	@engg_grid_elem_type

	IF ISNULL(@modeflag,'')	IN ('I','X')
		BEGIN
			IF EXISTS ( SELECT 'X'
						FROM	es_quick_code_met WITH (NOLOCK)
						WHERE	CustomerName	=	@engg_customer_name
						AND		ProjectName		=	@engg_project_name
						AND		ParameterCode	=	'HiddenViewCreation'
						AND		ParameterText	=	'AUTO_POPULATE_HDNVIEW_COMBO'
						AND		ParameterValue	=	'Y' )
						AND		ISNULL(@tmp_base_ctrl_type,'')	=	'Combo'
					BEGIN
							INSERT INTO DE_HIDDEN_VIEW 
										(	customer_name,			project_name,				process_name,			component_name,		
											activity_name,			ui_name,					page_name,				section_name,
											Control_bt_synonym,		hidden_view_bt_synonym,		transfer_flag,			hidden_view_sysid,	
											control_sysid,			timestamp,	
											createdby,				createddate,				modifiedby,				modifieddate,
											control_id,				view_name,					new_control_bt_synonym,	HIDDEN_VIEW_SOURCE,	
											ecrno,					IsGlance )
							SELECT
										@engg_customer_name,	@engg_project_name,				@prc_name_tmp,			@component_name_tmp,		
										@act_name_tmp,			@ui_name_tmp,					@engg_grid_page_bts,	@engg_grid_sec_bts,	
										@engg_grid_btsynname,	@hiddenbtsynonym,				'N',					newid(),
										newid(),					1,
										@ctxt_user,				getdate(),						@ctxt_user,				getdate(),
										@ctrl_bt_syn_id,		@view_name,						@hiddenbtsynonym,		NULL,
										'BASE',					NULL

							INSERT INTO ep_component_glossary_mst 
									(	customer_name,			project_name,					req_no,					process_name,
										component_name,			bt_synonym_name,				data_type,				length,
										bt_synonym_caption,		glossary_sysid,					timestamp,				
										createdby,				createddate,					modifiedby,				modifieddate,
										ref_bt_synonym_name,	bt_synonym_doc,					bt_name,				synonym_status,
										singleinst_sample_data,	multiinst_sample_data,			wrkreqno,				IsGlance )
							SELECT
										@engg_customer_name,		@engg_project_name,				@engg_base_req_no,		@prc_name_tmp,
										@component_name_tmp,		@hiddenbtsynonym,				'Char',					60,
										@hiddenbtsynonym,			newid(),							1,
										@ctxt_user,					getdate(),						@ctxt_user,				getdate(),
										NULL,						@hiddenbtsynonym,				'',						'U',
										NULL,						NULL,							@engg_base_req_no,		NULL
						END 
					END
			--TECH-73996

		--output parameters    
		SELECT @fprowno = @fprowno + 1

		SELECT @fprowno 'fprowno',
			@engg_del_columns 'engg_del_columns'
			/*   
 --OutputList  
  Select  
  null 'fprowno',   
  null 'engg_del_columns',   
 */
	END

	SET NOCOUNT OFF
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME= 'ep_layout_sp_savgrdgdml' AND TYPE='P')
BEGIN
	GRANT EXEC ON  ep_layout_sp_savgrdgdml TO PUBLIC
END
GO  

