IF EXISTS  (SELECT 'X' FROM SYSOBJECTS WHERE NAME ='ep_layout_sp_defsec_hsv' AND TYPE = 'P')
    BEGIN
        DROP PROC ep_layout_sp_defsec_hsv
    END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		ep_layout_sp_defsec_hsv.sql
********************************************************************************/
/*      V E R S I O N      :  2.0.2    */
/*      Released By        :  PTech    */
/*      Release Comments   :  Released on  22-Jan-2004    */
/********************************************************************************/
/* procedure      ep_layout_sp_defsec_hsv                                       */
/* description                                                                  */
/********************************************************************************/
/* project        Preview                                                       */
/* version                                                                      */
/********************************************************************************/
/* referenced                                                                   */
/* tables                                                                       */
/********************************************************************************/
/* development history                                                          */
/********************************************************************************/
/* author         Shafina Begum.B                                               */
/* date           29/ 11/ 2003                                                  */
/********************************************************************************/
/* modification history                                                         */
/********************************************************************************/
/* modified by  : B.Shafina Begum                                               */
/* date         : 04-feb-2004	                                                */
/* description  : To check for ui's req_status								    */
/* modified by  : ARUNN			           	                                    */
/* date         : 29-Jun-2005	                                                */
/* bugid		: PNR2.0_3088													*/
/* bug desc		: On Clicking 'Default from reference UI', getting an error message */
/*				  Cannot insert the value NULL into column 'tab_height',        */
/*                table 'rvw20appdb.dbo.ep_ui_mst'; column does not allow nulls.*/
/*				  UPDATE fails. 												*/
/********************************************************************************/
/********************************************************************************/
/* modified by  : C Lavanya                                         */
/* date         : 21-oct-2005                                                */
/* description  : Htm Problem in Specify tree layout , Sp changed for default From Reference UI  in specify Layout.
		  for fixnote : _DM_FN_124				    */
/********************************************************************************/
/* modified by			: Chanheetha N A								*/
/* date					: 17-nov-2007									*/
/* BugId				: PNR2.0_16023 									*/
/************************************************************************/
/* Modified by : Jeya Latha K/Ganesh Prabhu S	for callid TECH-7349				*/
/* Modified on : 14-03-2017				 											*/
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and New Feature Organization chart */
/***********************************************************************************/
/* Modified by	:	VimalKumar R 												*/
/* Modified on	:	08/06/22				 									*/
/* Defect ID	:	TECH-69624													*/
/* Description	:	Custom border, Custom actions and Responsive layout			*/
/********************************************************************************/
/* Modified by					:	Priyadharshini U							*/
/* Modified on					:	11-July-22				 					*/
/* Defect ID					:	TECH-70687									*/
/* Description					:	Tool and Toolbars							*/
/********************************************************************************/
/* Modified by					:	Ponmalar A									*/
/* Modified on					:	23-Aug-2022				 					*/
/* Defect ID					:	TECH-72114									*/
/* Description					:	Platform Modeling for Section Title Icon	*/
/********************************************************************************/
/* Modified by  : Ponmalar A	Date: 02-Dec-2022  Defect ID : TECH-75230		*/
/********************************************************************************/
CREATE PROCEDURE ep_layout_sp_defsec_hsv
	@ctxt_language_in engg_ctxt_language,
	@ctxt_ouinstance_in engg_ctxt_ouinstance,
	@ctxt_service_in engg_ctxt_service,
	@ctxt_user_in engg_ctxt_user,
	@engg_act_descr_in engg_description,
	@engg_component_in engg_description,
	@engg_cont_page_bts_in engg_name,
	@engg_customer_name_in engg_name,
	@engg_enum_page_bts_in engg_name,
	@engg_grid_page_bts_in engg_name,
	@engg_lay_page_bts_in engg_name,
	@engg_process_descr_in engg_description,
	@engg_project_name_in engg_name,
	@engg_radpage_bts_in engg_name,
	@engg_req_no_in engg_name,
	@engg_rf_act_in engg_description,
	@engg_rf_comp_in engg_description,
	@engg_rf_ui_in engg_description,
	@engg_sec_page_bts_in engg_name,
	@engg_ui_descr_in engg_description,
	@guid_in engg_guid,
	@m_errorid INT OUTPUT
AS
BEGIN
	SET NOCOUNT ON

	--declaration of temporary variables
	DECLARE @ctxt_language engg_ctxt_language
	DECLARE @ctxt_ouinstance engg_ctxt_ouinstance
	DECLARE @ctxt_service engg_ctxt_service
	DECLARE @ctxt_user engg_ctxt_user
	DECLARE @engg_act_descr engg_description
	DECLARE @engg_component engg_description
	DECLARE @engg_cont_page_bts engg_name
	DECLARE @engg_customer_name engg_name
	DECLARE @engg_enum_page_bts engg_name
	DECLARE @engg_grid_page_bts engg_name
	DECLARE @engg_lay_page_bts engg_name
	DECLARE @engg_process_descr engg_description
	DECLARE @engg_project_name engg_name
	DECLARE @engg_radpage_bts engg_name
	DECLARE @engg_req_no engg_name
	DECLARE @engg_rf_act engg_description
	DECLARE @engg_rf_comp engg_description
	DECLARE @engg_rf_ui engg_description
	DECLARE @engg_sec_page_bts engg_name
	DECLARE @engg_ui_descr engg_description
	DECLARE @guid engg_guid
	DECLARE @Sec_CollapseMode engg_name
	DECLARE @Sec_Collapse engg_name
	DECLARE @section_rowspan engg_name
	DECLARE @section_colspan engg_name
	DECLARE @Region engg_name
	DECLARE @TitlePosition engg_name
	DECLARE @CollapseDir engg_name
	DECLARE @SectionLayout engg_name
	DECLARE @XYCoordinates engg_name
	DECLARE @ColumnLayWidth engg_name
	DECLARE @engg_associatedcontrol engg_name
	DECLARE @engg_sect_forresponsive engg_seqno		--Code Added for TECH-69624
	DECLARE @engg_mob_responsive  engg_flag
	DECLARE @Orientation  engg_name --TECH-75230

	--temporary and formal parameters mapping
	SELECT @ctxt_language = @ctxt_language_in

	SELECT @ctxt_ouinstance = @ctxt_ouinstance_in

	SELECT @ctxt_service = ltrim(rtrim(@ctxt_service_in))

	SELECT @ctxt_user = ltrim(rtrim(@ctxt_user_in))

	SELECT @engg_act_descr = ltrim(rtrim(@engg_act_descr_in))

	SELECT @engg_component = ltrim(rtrim(@engg_component_in))

	SELECT @engg_cont_page_bts = ltrim(rtrim(@engg_cont_page_bts_in))

	SELECT @engg_customer_name = ltrim(rtrim(@engg_customer_name_in))

	SELECT @engg_enum_page_bts = ltrim(rtrim(@engg_enum_page_bts_in))

	SELECT @engg_grid_page_bts = ltrim(rtrim(@engg_grid_page_bts_in))

	SELECT @engg_lay_page_bts = ltrim(rtrim(@engg_lay_page_bts_in))

	SELECT @engg_process_descr = ltrim(rtrim(@engg_process_descr_in))

	SELECT @engg_project_name = ltrim(rtrim(@engg_project_name_in))

	SELECT @engg_radpage_bts = ltrim(rtrim(@engg_radpage_bts_in))

	SELECT @engg_req_no = ltrim(rtrim(@engg_req_no_in))

	SELECT @engg_rf_act = ltrim(rtrim(@engg_rf_act_in))

	SELECT @engg_rf_comp = ltrim(rtrim(@engg_rf_comp_in))

	SELECT @engg_rf_ui = ltrim(rtrim(@engg_rf_ui_in))

	SELECT @engg_sec_page_bts = ltrim(rtrim(@engg_sec_page_bts_in))

	SELECT @engg_ui_descr = ltrim(rtrim(@engg_ui_descr_in))

	SELECT @guid = ltrim(rtrim(@guid_in))

	--null checking
	IF @ctxt_language = - 915
		SELECT @ctxt_language = NULL

	IF @ctxt_ouinstance = - 915
		SELECT @ctxt_ouinstance = NULL

	IF @ctxt_service = '~#~'
		SELECT @ctxt_service = NULL

	IF @ctxt_user = '~#~'
		SELECT @ctxt_user = NULL

	IF @engg_act_descr = '~#~'
		SELECT @engg_act_descr = NULL

	IF @engg_component = '~#~'
		SELECT @engg_component = NULL

	IF @engg_cont_page_bts = '~#~'
		SELECT @engg_cont_page_bts = NULL

	IF @engg_customer_name = '~#~'
		SELECT @engg_customer_name = NULL

	IF @engg_enum_page_bts = '~#~'
		SELECT @engg_enum_page_bts = NULL

	IF @engg_grid_page_bts = '~#~'
		SELECT @engg_grid_page_bts = NULL

	IF @engg_lay_page_bts = '~#~'
		SELECT @engg_lay_page_bts = NULL

	IF @engg_process_descr = '~#~'
		SELECT @engg_process_descr = NULL

	IF @engg_project_name = '~#~'
		SELECT @engg_project_name = NULL

	IF @engg_radpage_bts = '~#~'
		SELECT @engg_radpage_bts = NULL

	IF @engg_req_no = '~#~'
		SELECT @engg_req_no = NULL

	IF @engg_rf_act = '~#~'
		SELECT @engg_rf_act = NULL

	IF @engg_rf_comp = '~#~'
		SELECT @engg_rf_comp = NULL

	IF @engg_rf_ui = '~#~'
		SELECT @engg_rf_ui = NULL

	IF @engg_sec_page_bts = '~#~'
		SELECT @engg_sec_page_bts = NULL

	IF @engg_ui_descr = '~#~'
		SELECT @engg_ui_descr = NULL

	IF @guid = '~#~'
		SELECT @guid = NULL

	--errors mapped
	DECLARE @iudmodeflag engg_flag,
		@tmp_processname engg_name,
		@tmp_componentname engg_name,
		@tmp_activity engg_name,
		@tmp_ui engg_name,
		@tmp_ref_componentname engg_name,
		@tmp_ref_activity engg_name,
		@tmp_ref_ui engg_name,
		@msg engg_documentation,
		@border_required engg_flag,
		@section_bt_synonym engg_name,
		@title_required engg_flag,
		@visisble_flag engg_flag,
		@section_doc engg_documentation,
		@parent_section engg_name,
		@horder engg_length,
		@vorder engg_length,
		@engg_base_req_no engg_name,
		@title_alignment engg_name,
		@btLength engg_seqno,
		@sec_bt_caption engg_description,
		/*fIXNOTE:_DM_FN_124*/
		@ENGG_SECTION_TYPE_IN engg_name,
		@engg_sec_cap_align engg_name,
		@engg_sec_cap_format engg_flag,
		@sectionheight engg_seqno,
		@sectionwidth engg_seqno,
		@Section_width_Scalemode engg_name,
		@Section_height_Scalemode engg_name,
		--TECH-70687
		@engg_lefttb		engg_seqno,
		@engg_righttb		engg_seqno,
		@engg_toptb			engg_seqno,
		@engg_bottomtb		engg_seqno,
		@MinimizedRows		engg_seqno,
		@ViewMode			engg_name,
		--TECH-70687
		@engg_sec_titleicon	engg_name --TECH-72114

	/*fIXNOTE:_DM_FN_124*/
	SELECT @engg_base_req_no = 'BASE'

	--GETTING THE PROCESS NAME FOR DESCRIPTION
	SELECT @tmp_processname = process_name
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND process_descr = @engg_process_descr
		AND req_no = @engg_req_no

	--GETTING THE COMPONENT NAME FOR THE DESCRIPTION
	SELECT @tmp_componentname = component_name
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND process_name = @tmp_processname
		AND component_descr = @engg_component
		AND req_no = @engg_req_no

	--GETTING THE ACTIVITY NAME FOR THE DESCRIPTION
	SELECT @tmp_activity = activity_name
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND process_name = @tmp_processname
		AND component_name = @tmp_componentname
		AND activity_descr = @engg_act_descr
		AND req_no = @engg_req_no

	--GETTING THE UI NAME FOR THE DESCRIPTION
	SELECT @tmp_ui = ui_name
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND process_name = @tmp_processname
		AND component_name = @tmp_componentname
		AND activity_name = @tmp_activity
		AND ui_descr = @engg_ui_descr
		AND req_no = @engg_req_no

	IF EXISTS (
			SELECT 'x'
			FROM ep_ui_req_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_req_no
				AND process_name = @tmp_processname
				AND component_name = @tmp_componentname
				AND activity_name = @tmp_activity
				AND ui_name = @tmp_ui
				AND req_status = 'P'
			)
	BEGIN
		SELECT @msg = 'Cannot default as Selected UI is in published status'

		EXEC engg_error_sp 'ep_flow_sp_save_hsv',
			1,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		IF @m_errorid <> 0
			RETURN
	END

	IF @engg_act_descr IS NULL
	BEGIN
		SELECT @msg = 'Select Activity'

		EXEC engg_error_sp 'en_layout_sp_defsecscml',
			1,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		RETURN
	END

	--Check whether UI is selected. If not display error message
	IF @engg_ui_descr IS NULL
	BEGIN
		SELECT @msg = 'Select User Interface'

		EXEC engg_error_sp 'en_layout_sp_defsecscml',
			2,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		RETURN
	END

	--Check whether Page BT is selected. If not display error message
	IF @engg_sec_page_bts IS NULL
	BEGIN
		SELECT @msg = 'Select page (BT Synonym)'

		EXEC engg_error_sp 'en_layout_sp_defsecscml',
			3,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		RETURN
	END

	--For the selected activity/UI combination check whether refernce UI has been defined. If not, display error message
	IF @engg_rf_ui IS NULL
	BEGIN
		SELECT @msg = 'Reference UI does not exists for the selected UI.'

		EXEC engg_error_sp 'en_layout_sp_defsecscml',
			3,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		RETURN
	END

	--GETTING THE REF COMPONENT NAME FOR THE DESCRIPTION
	SELECT @tmp_ref_componentname = component_name
	-- 	from 	ep_ui_req_dtl (nolock)			
	FROM Fw_BPT_RE_NameDesc_Vw(NOLOCK) -- Modified By Arunn for pnr2.0_3088
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		--	and 	process_name 		= @tmp_processname
		AND component_descr = @engg_rf_comp

	--  and     req_no				= @engg_req_no
	--GETTING THE REF ACTIVITY NAME FOR THE DESCRIPTION
	SELECT @tmp_ref_activity = activity_name
	-- 	from 	ep_ui_req_dtl (nolock)			
	FROM Fw_BPT_RE_NameDesc_Vw(NOLOCK) -- Modified By Arunn for pnr2.0_3088
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		--	and		process_name		= @tmp_processname
		AND component_name = @tmp_ref_componentname
		AND activity_descr = @engg_rf_act

	--  and     req_no				= @engg_req_no
	--GETTING THE REF UI NAME FOR THE DESCRIPTION
	SELECT @tmp_ref_ui = ui_name
	-- 	from 	ep_ui_req_dtl (nolock)			
	FROM Fw_BPT_RE_NameDesc_Vw(NOLOCK) -- Modified By Arunn for pnr2.0_3088
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		--	and		process_name		= @tmp_processname
		AND component_name = @tmp_ref_componentname
		AND activity_name = @tmp_ref_activity
		AND ui_descr = @engg_rf_ui

	--  and     req_no				= @engg_req_no
	--Check whether the Page exists in reference UI for the reference UI. If not, display error message.
	IF NOT EXISTS (
			SELECT 'A'
			FROM ep_ui_page_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_base_req_no
				-- code modified by shafina on 07-July-2004 for PREVIEWENG203SYS_000115
				-- When i click 'Default from Reference UI' task in Sections tabs, it says that "Page does not exist in Reference UI".
				-- 					and		process_name		= @tmp_processname
				AND component_name = @tmp_ref_componentname
				AND activity_name = @tmp_ref_activity
				AND ui_name = @tmp_ref_ui
				AND page_bt_synonym = @engg_sec_page_bts
			)
	BEGIN
		SELECT @msg = 'Page does not exist in Reference UI.'

		EXEC engg_error_sp 'en_layout_sp_defsecscml',
			4,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		RETURN
	END

	/*Check whether no sections exist for the normal ui/page.Else display error*/
	IF (
			SELECT count('x')
			FROM ep_ui_section_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_base_req_no
				AND process_name = @tmp_processname
				AND component_name = @tmp_componentname
				AND activity_name = @tmp_activity
				AND ui_name = @tmp_ui
				AND page_bt_synonym = @engg_sec_page_bts
				AND section_bt_synonym NOT IN (
					'PrjHdnSection',
					'[tabcontrol]'
					)
			) = 0
	BEGIN
		SELECT @tmp_ui = rtrim(@tmp_ui)
	END
	ELSE
	BEGIN
		SELECT @msg = 'Default from Reference UI cannot be done as there are sections defined for this UI/page already'

		EXEC engg_error_sp 'en_layout_sp_defsecscml',
			5,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		RETURN
	END

	/*
	EXPANATION FOR THE FOLLOWING QUERY:
	
	First Part [Query part before Union]:
	-------------------------------------

	selecting all the section details for the selected customer, project, process, 
	reference component, reference activity, reference ui and Page BT Synonym from the table 
	ep_ui_section_dtl also filtering the ui names for which the section detail already saved.
	Inserting the above selected values in the ep_ui_section_dtl table for the selected customer, 
	project, process, component, activity and ui

	Second Part [Query part after Union]:
	-------------------------------------

	selecting all the section details for the selected customer, project, process, component, 
	activity, ui and page bt synonym from the table ep_ui_section_dtl along with the BT Synonym caption for the 
	corresponding section_bt_synonym from the table ep_glossary_mst.
*/
	DECLARE insert_cur INSENSITIVE CURSOR
	FOR
	SELECT border_required,
		section_bt_synonym,
		title_required,
		visisble_flag,
		section_doc,
		parent_section,
		horder,
		vorder,
		title_alignment,
		/*fIXNOTE:_DM_FN_124*/
		section_type,
		ctrl_caption_align,
		caption_Format,
		height,
		width,
		Section_width_Scalemode,
		Section_height_Scalemode,
		section_collapsemode,
		section_collapse,
		req_no,
		NRowSpan,
		NColSpan,
		Region,
		TitlePosition,
		CollapseDir,
		SectionLayout,
		XYCoordinates,
		ColumnLayWidth,
		Associated_control,
		ForResponsive,								--Code Added for TECH-69624
		Orientation, --TECH-75230
		--TECH-70687
		case when LeftToolbar=	'y' then 1 else 0 end	,
		case when RightToolbar=	'y' then 1 else 0 end	,
		case when TopToolbar=	'y' then 1 else 0 end	,
		case when BottomToolbar=	'y' then 1 else 0 end	,
		MinimizedRows,
		ViewMode,
		--TECH-70687
		TitleIcon	--TECH-72114
	FROM ep_ui_section_dtl a(NOLOCK)
	WHERE a.customer_name = @engg_customer_name
		AND a.project_name = @engg_project_name
		AND a.req_no = @engg_base_req_no
		-- 	and	a.process_name			=	@tmp_processname
		AND a.component_name = @tmp_ref_componentname
		AND a.activity_name = @tmp_ref_activity
		AND a.ui_name = @tmp_ref_ui
		AND a.page_bt_synonym = @engg_sec_page_bts
		AND section_bt_synonym NOT IN (
			'PrjHdnSection',
			'[tabcontrol]'
			)

	/*	and		not exists(	select 'A' from ep_ui_section_dtl c (nolock)
						where	a.customer_name		=	c.customer_name
						and		a.project_name		=	c.project_name
						and     a.req_no			=   c.req_no
						and		a.process_name		=	c.process_name
						and		a.component_name	=	c.component_name
						and		a.activity_name		=	c.activity_name
						and		a.ui_name			=	c.ui_name
						and		a.page_bt_synonym	<>	c.page_bt_synonym
						and		a.section_bt_synonym=	c.section_bt_synonym)*/
	OPEN insert_cur

	WHILE (1 = 1)
	BEGIN
		FETCH NEXT
		FROM insert_cur
		INTO @border_required,
			@section_bt_synonym,
			@title_required,
			@visisble_flag,
			/*fIXNOTE:_DM_FN_124*/
			@section_doc,
			@parent_section,
			@horder,
			@vorder,
			@title_alignment,
			@ENGG_SECTION_TYPE_IN,
			@engg_sec_cap_align,
			@engg_sec_cap_format,
			@sectionheight,
			@sectionwidth,
			@Section_width_Scalemode,
			@Section_height_Scalemode,
			@Sec_CollapseMode,
			@Sec_Collapse,
			@engg_req_no,
			@section_rowspan,
			@section_colspan,
			@Region,
			@TitlePosition,
			@CollapseDir,
			@SectionLayout,
			@XYCoordinates,
			@ColumnLayWidth,
			@engg_associatedcontrol,
			@engg_sect_forresponsive,			--Code Added for TECH-69624
			@Orientation,	--TECH-75230
			--TECH-70687
			@engg_lefttb,
			@engg_righttb,
			@engg_toptb	,
			@engg_bottomtb,
			@MinimizedRows,
			@ViewMode,
			--TECH-70687
			@engg_sec_titleicon --09aug2022

		IF @@fetch_status <> 0
			BREAK

		EXEC ep_ui_section_dtl_sp_ins @ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			@engg_customer_name,
			@engg_project_name,
			@engg_base_req_no,
			@tmp_processname,
			@tmp_componentname,
			@tmp_activity,
			@tmp_ui,
			@engg_sec_page_bts,
			@section_bt_synonym,
			@visisble_flag,
			@title_required,
			@border_required,
			@title_alignment,
			@parent_section,
			@horder,
			@vorder,
			@section_doc,
			1,
			/*fIXNOTE:_DM_FN_124*/
			@ENGG_SECTION_TYPE_IN,
			@engg_sec_cap_align,
			@engg_sec_cap_format,
			@sectionheight,
			@sectionwidth,
			@Section_width_Scalemode,
			@Section_height_Scalemode,
			@Sec_CollapseMode,
			@Sec_Collapse,
			@engg_req_no, --chan
			@section_rowspan,
			@section_colspan,
			@Region,
			@TitlePosition,
			@CollapseDir,
			@SectionLayout,
			@XYCoordinates,
			@ColumnLayWidth,
			@engg_associatedcontrol,
			'',
			'',
			@engg_sect_forresponsive,				--Code Added for TECH-69624
			@Orientation,	--TECH-75230
			--TECH-70687
			@engg_lefttb,
			@engg_righttb,
			@engg_toptb	,
			@engg_bottomtb,
			@MinimizedRows,
			@ViewMode,
			--TECH-70687
			@engg_sec_titleicon,	--TECH-72114
			@m_errorid OUTPUT

		/*fIXNOTE:_DM_FN_124*/
		-- modified by shafina on 01-mar-2004
		IF @m_errorid <> 0
		BEGIN
			CLOSE insert_cur

			DEALLOCATE insert_cur

			RETURN
		END

		-- code modified by shafina on 09-June-2004 for PREVIEWENG203ACC_000070
		-- When controls/columns are defaulted form reference ui , corresponding glossary entry and task entry is not done.
		SELECT @btLength = 20

		IF NOT EXISTS (
				SELECT 'x'
				FROM ep_component_glossary_mst NOLOCK
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND req_no = @engg_base_req_no
					AND process_name = @tmp_processname
					AND component_name = @tmp_componentname
					AND bt_synonym_name = @section_bt_synonym
				)
		BEGIN
			-- code modified by shafina on 14-June-2004 for PREVIEWENG203ACC_000070
			-- 			exec	ep_generate_caption @section_bt_synonym , @sec_bt_caption out
			SELECT @sec_bt_caption = bt_synonym_caption
			FROM ep_component_glossary_mst(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_base_req_no
				AND component_name = @tmp_ref_componentname
				AND bt_synonym_name = @section_bt_synonym

				--TECH-70687
				IF ISNULL(@sec_bt_caption,'')	=	''
				BEGIN
				IF EXISTS ( SELECT 'X'
							FROM	ep_ui_section_dtl WITH(NOLOCK)
							WHERE	customer_name		= @engg_customer_name
							AND		project_name		= @engg_project_name
							AND		req_no				= @engg_base_req_no
							and		process_name		= @tmp_processname
							AND		component_name		= @tmp_ref_componentname
							AND		activity_name		= @tmp_ref_activity
							AND		ui_name				= @tmp_ref_ui
							AND		page_bt_synonym		= @engg_sec_page_bts
							AND		section_bt_synonym	= @section_bt_synonym
							AND		Section_type  IN ('Toolbar','Sidebar')	)
				BEGIN
						SELECT @sec_bt_caption	=	@section_bt_synonym
				END
				END
				--TECH-70687

			-- code modified by shafina on 17-June-2004 for PREVIEWENG203ACC_000073
			EXEC ep_component_glossary_mst_sp_ins @ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@engg_customer_name,
				@engg_project_name,
				-- code modified by shafina on 12-July-2004 as req_no is inserted wrongly.
				'BASE',
				@tmp_processname,
				@tmp_componentname,
				@section_bt_synonym,
				NULL,
				'Char',
				@btLength,
				@sec_bt_caption,
				@section_bt_synonym,
				'',
				'U',
				'',
				'',
				1,
				@engg_req_no,
				@m_errorid OUTPUT

			IF @m_errorid <> 0
			BEGIN
				CLOSE insert_cur

				DEALLOCATE insert_cur

				RETURN
			END
		END
	END

	CLOSE insert_cur

	DEALLOCATE insert_cur

	--output parameters
	SELECT 0 'fprowno'

	SET NOCOUNT OFF
END
GO
IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_layout_sp_defsec_hsv' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON ep_layout_sp_defsec_hsv TO PUBLIC
END
GO