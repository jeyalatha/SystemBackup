IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_maireeSpCGDefengcol' AND TYPE = 'P')
BEGIN
	DROP PROC ep_maireeSpCGDefengcol
END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		ep_maireeSpCGDefengcol.sql
********************************************************************************/
/******************************************************************************/
/* Procedure					: ep_maireeSpCGDefengcol								 */
/* Description					: 								 */
/******************************************************************************/
/* Project						: 								 */
/* EcrNo						: 								 */
/* Version						: 								 */
/******************************************************************************/
/* Referenced					: 								 */
/* Tables						: 								 */
/******************************************************************************/
/* Development history			: 								 */
/******************************************************************************/
/* Author						: ModelExplorer								 */
/* Date							: May 31 2016  3:36PM								 */
/******************************************************************************/
/* Modification History			: 								 */
/******************************************************************************/
/* modified by			Date				Defect ID							*/
/* Veena U				08-Jun-2016			PLF2.0_18487						*/
/********************************************************************************/
/* Modified by : Jeya Latha K/Ganesh Prabhu S	for callid TECH-7349				*/
/* Modified on : 14-03-2017				 											*/
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and New Feature Organization chart */
/***********************************************************************************************/
/* Modified by    :    VimalKumar R                                                            */
/* Modified on    :    03/11/22                                                                */
/* Defect ID      :    TECH-73052															   */
/* Description    :    Need new column- Column caption from Respective grid controls-In column
                       grouping tab in addition with existing Column name/synonym.             */
/***********************************************************************************************/
CREATE PROCEDURE ep_maireeSpCGDefengcol
	@ctxt_ouinstance ctxt_ouinstance, --Input 
	@ctxt_user ctxt_user, --Input 
	@ctxt_language ctxt_language, --Input 
	@ctxt_service ctxt_service, --Input 
	@engg_act_descr engg_description, --Input 
	@engg_col_or_group engg_name, --Input 
	@engg_component engg_description, --Input 
	@engg_control_name engg_name, --Input 
	@engg_customer_name engg_name, --Input 
	@engg_group_caption engg_description, --Input 
	@engg_group_name engg_name, --Input 
	@engg_group_seq engg_seqno, --Input 
	@engg_mapped_entity engg_name, --Input 
	@engg_map_seq engg_seqno, --Input 
	@engg_page_name engg_name, --Input 
	@engg_process_descr engg_description, --Input 
	@engg_project_name engg_name, --Input 
	@engg_req_no engg_name, --Input 
	@engg_rf_act engg_description, --Input 
	@engg_rf_comp engg_description, --Input 
	@engg_rf_ui engg_description, --Input 
	@engg_sect_name engg_name, --Input 
	@engg_ui_descr engg_description, --Input 
	@engg_ui_map engg_flag, --Input 
	@engg_col_caption	engg_description, --Code Added for TECH-73052
	@modeflag modeflag, --Input 
	@fprowno rowno, --Input/Output
	@m_errorid INT OUTPUT --To Return Execution Status
AS
BEGIN
	-- nocount should be switched on to prevent phantom rows
	SET NOCOUNT ON
	-- @m_errorid should be 0 to Indicate Success
	SET @m_errorid = 0
	--declaration of temporary variables
	--temporary and formal parameters mapping
	SET @ctxt_user = ltrim(rtrim(@ctxt_user))
	SET @ctxt_service = ltrim(rtrim(@ctxt_service))
	SET @engg_act_descr = ltrim(rtrim(@engg_act_descr))
	SET @engg_col_or_group = ltrim(rtrim(@engg_col_or_group))
	SET @engg_component = ltrim(rtrim(@engg_component))
	SET @engg_control_name = ltrim(rtrim(@engg_control_name))
	SET @engg_customer_name = ltrim(rtrim(@engg_customer_name))
	SET @engg_group_caption = ltrim(rtrim(@engg_group_caption))
	SET @engg_group_name = ltrim(rtrim(@engg_group_name))
	SET @engg_mapped_entity = ltrim(rtrim(@engg_mapped_entity))
	SET @engg_page_name = ltrim(rtrim(@engg_page_name))
	SET @engg_process_descr = ltrim(rtrim(@engg_process_descr))
	SET @engg_project_name = ltrim(rtrim(@engg_project_name))
	SET @engg_req_no = ltrim(rtrim(@engg_req_no))
	SET @engg_rf_act = ltrim(rtrim(@engg_rf_act))
	SET @engg_rf_comp = ltrim(rtrim(@engg_rf_comp))
	SET @engg_rf_ui = ltrim(rtrim(@engg_rf_ui))
	SET @engg_sect_name = ltrim(rtrim(@engg_sect_name))
	SET @engg_ui_descr = ltrim(rtrim(@engg_ui_descr))
	SET @engg_ui_map = ltrim(rtrim(@engg_ui_map))
	SET @modeflag = ltrim(rtrim(@modeflag))

	--null checking
	IF @ctxt_ouinstance = - 915
		SELECT @ctxt_ouinstance = NULL

	IF @ctxt_user = '~#~'
		SELECT @ctxt_user = NULL

	IF @ctxt_language = - 915
		SELECT @ctxt_language = NULL

	IF @ctxt_service = '~#~'
		SELECT @ctxt_service = NULL

	IF @engg_act_descr = '~#~'
		SELECT @engg_act_descr = NULL

	IF @engg_col_or_group = '~#~'
		SELECT @engg_col_or_group = NULL

	IF @engg_component = '~#~'
		SELECT @engg_component = NULL

	IF @engg_control_name = '~#~'
		SELECT @engg_control_name = NULL

	IF @engg_customer_name = '~#~'
		SELECT @engg_customer_name = NULL

	IF @engg_group_caption = '~#~'
		SELECT @engg_group_caption = NULL

	IF @engg_group_name = '~#~'
		SELECT @engg_group_name = NULL

	IF @engg_group_seq = - 915
		SELECT @engg_group_seq = NULL

	IF @engg_mapped_entity = '~#~'
		SELECT @engg_mapped_entity = NULL

	IF @engg_map_seq = - 915
		SELECT @engg_map_seq = NULL

	IF @engg_page_name = '~#~'
		SELECT @engg_page_name = NULL

	IF @engg_process_descr = '~#~'
		SELECT @engg_process_descr = NULL

	IF @engg_project_name = '~#~'
		SELECT @engg_project_name = NULL

	IF @engg_req_no = '~#~'
		SELECT @engg_req_no = NULL

	IF @engg_rf_act = '~#~'
		SELECT @engg_rf_act = NULL

	IF @engg_rf_comp = '~#~'
		SELECT @engg_rf_comp = NULL

	IF @engg_rf_ui = '~#~'
		SELECT @engg_rf_ui = NULL

	IF @engg_sect_name = '~#~'
		SELECT @engg_sect_name = NULL

	IF @engg_ui_descr = '~#~'
		SELECT @engg_ui_descr = NULL

	IF @engg_ui_map = '~#~'
		SELECT @engg_ui_map = NULL

	IF @modeflag = '~#~'
		SELECT @modeflag = NULL

	IF @fprowno = - 915
		SELECT @fprowno = NULL

	/* 
	--OutputList
		Select
		null 'fprowno', 
	*/
	SET NOCOUNT OFF
END

GO

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_maireeSpCGDefengcol' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON ep_maireeSpCGDefengcol TO PUBLIC
END
GO

