IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'EP_Layout_sp_SActScML_O' AND TYPE = 'P')
BEGIN
	DROP PROC EP_Layout_sp_SActScML_O
END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		EP_Layout_sp_SActScML_O.sql
********************************************************************************/
/********************************************************************************/
/* Procedure    : EP_Layout_sp_SActScML_O                                       */
/* Description  :                                                               */
/********************************************************************************/
/* Project      :                                                               */
/* ECR          :                                                               */
/* Version      :                                                               */
/********************************************************************************/
/* Referenced   :                                                               */
/* Tables       :                                                               */
/********************************************************************************/
/* Development history                                                          */
/********************************************************************************/
/* Author       : Swaminathan R.                                                */
/* Date         : 22/Sep/2005                                                   */
/********************************************************************************/
/* Modification history                                                         */
/********************************************************************************/
/* Modified by : Feroz		 													*/
/* Modified on : 08/11/06	 													*/
/* Description : State Processing 												*/
/********************************************************************************/
/* Modified by  : Gopinath S                                                    */
/* Date         : 17-06-2009                                                    */
/* Call ID	: PNR2.0_22596                                                  */
/* Description	: Incorrect Section Caption Format on launch of the screen	*/
/********************************************************************************/
/* Modified by  : Shakthi P                                                            */
/* Date         : 22-Mar-2011                                                          */
/* Description  : The state section should not appear in sections and Page Layout tabs.*/
/* CaseID       : PNR2.0_30667                                                         */
/***************************************************************************************/
/***************************************************************************************************/
/* modified by  : Ganesh Prabhu S                                      						       */
/* date         : Oct 10 2014                                      							       */
/* BugId        : PLF2.0_09035                                          						   */
/* description  : Model changes for rowspan,colspan,IsStatic,IsCallout in  layout level							*/
/****************************************************************************************************************/
/* Modified by  : Veena U																						*/
/* Date         : 25-Feb-2015																					*/
/* Call ID		: PLF2.0_11499																					*/
/****************************************************************************************************************/
/* Modified by  : Veena U																					    */
/* Date         : 28-Mar-2016																					*/
/* Call ID		: PLF2.0_17570																					*/
/****************************************************************************************************************/
/* modified by			Date				Defect ID															*/
/* Veena U				08-Jun-2016			PLF2.0_18487														*/
/****************************************************************************************************************/
/* modified by			Date				Defect ID															*/
/* Loganayaki P			14-Oct-2016			Tech-406															*/
/****************************************************************************************************************/
/* Modified by : Jeya Latha K/Ganesh Prabhu S	for callid TECH-7349											*/
/* Modified on : 14-03-2017				 																		*/
/* Description : New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and New Feature Organization chart  */
/* Modified by : Priyadharshini U/Jeya Latha K   Date: 27-Feb-2020  Defect ID : TECH-43307						*/
/****************************************************************************************************************/
/* Modified by	:	VimalKumar R 																				*/
/* Modified on	:	08/06/22				 																	*/
/* Defect ID	:	TECH-69624																					*/
/* Description	:	Custom border, Custom actions and Responsive layout											*/
/****************************************************************************************************************/
/* Modified by	:	VimalKumar R																				*/
/* Modified on	:	11/07/22				 																	*/
/* Defect ID	:	TECH-70687																					*/
/* Description	:	Tool and Toolbars																			*/
/****************************************************************************************************************/
/* Modified by : Ponmalar A		Date: 24-Aug-2022  Defect ID : TECH-72114										*/
/****************************************************************************************************************/
/* Modified by	:	VimalKumar R																				*/
/* Modified on	:	03/11/22				 																	*/
/* Defect ID	:	TECH-75230																					*/
/* Description	:	Platform Release for the Month of Nov'22													*/
/****************************************************************************************************************/
CREATE PROCEDURE EP_Layout_sp_SActScML_O
	@ctxt_language engg_ctxt_language, --Input  
	@ctxt_ouinstance engg_ctxt_ouinstance, --Input  
	@ctxt_service engg_ctxt_service,
	@ctxt_user engg_ctxt_user, --Input  
	@engg_act_descr engg_description, --Input  
	@engg_component engg_description, --Input  
	@engg_customer_name engg_name, --Input  
	@engg_process_descr engg_description, --Input  
	@engg_project_name engg_name, --Input  
	@engg_req_no engg_name, --Input  
	@engg_sec_page_bts engg_name, --Input  
	@engg_ui_descr engg_description, --Input  
	@guid engg_guid, --Input
	@m_errorid INT OUTPUT --To Return Execution Status  
AS
BEGIN
	-- nocount should be switched on to prevent phantom rows  
	SET NOCOUNT ON
	-- @m_errorid should be 0 to Indicate Success  
	SET @m_errorid = 0
	--declaration of temporary variables  
	--temporary and formal parameters mapping  
	SET @ctxt_user = ltrim(rtrim(@ctxt_user))
	SET @ctxt_service = ltrim(rtrim(@ctxt_service))
	SET @ctxt_user = ltrim(rtrim(@ctxt_user))
	SET @ctxt_service = ltrim(rtrim(@ctxt_service))
	SET @engg_customer_name = ltrim(rtrim(@engg_customer_name))
	SET @engg_act_descr = ltrim(rtrim(@engg_act_descr))
	SET @engg_component = ltrim(rtrim(@engg_component))
	SET @engg_process_descr = ltrim(rtrim(@engg_process_descr))
	SET @engg_project_name = ltrim(rtrim(@engg_project_name))
	SET @engg_project_name = ltrim(rtrim(@engg_project_name))
	SET @engg_req_no = ltrim(rtrim(@engg_req_no))
	SET @engg_sec_page_bts = ltrim(rtrim(@engg_sec_page_bts))
	SET @engg_ui_descr = ltrim(rtrim(@engg_ui_descr))
	SET @guid = ltrim(rtrim(@guid))

	--null checking  
	IF @ctxt_ouinstance = - 915
		SET @ctxt_ouinstance = NULL

	IF @ctxt_language = - 915
		SET @ctxt_language = NULL

	IF @ctxt_ouinstance = - 915
		SET @ctxt_ouinstance = NULL

	IF @ctxt_user = '~#~'
		SET @ctxt_user = NULL

	IF @ctxt_service = '~#~'
		SET @ctxt_service = NULL

	IF @ctxt_language = - 915
		SET @ctxt_language = NULL

	IF @ctxt_user = '~#~'
		SET @ctxt_user = NULL

	IF @ctxt_service = '~#~'
		SET @ctxt_service = NULL

	IF @engg_customer_name = '~#~'
		SET @engg_customer_name = NULL

	IF @engg_act_descr = '~#~'
		SET @engg_act_descr = NULL

	IF @engg_component = '~#~'
		SET @engg_component = NULL

	IF @engg_customer_name = '~#~'
		SET @engg_customer_name = NULL

	IF @engg_process_descr = '~#~'
		SET @engg_process_descr = NULL

	IF @engg_project_name = '~#~'
		SET @engg_project_name = NULL

	IF @engg_req_no = '~#~'
		SET @engg_req_no = NULL

	IF @engg_sec_page_bts = '~#~'
		SET @engg_sec_page_bts = NULL

	IF @engg_ui_descr = '~#~'
		SET @engg_ui_descr = NULL

	IF @guid = '~#~'
		SET @guid = NULL


	--errors mapped  
	DECLARE @tmp_comp_name engg_name,
		@tmp_proc engg_name,
		@tmp_acty_name engg_name,
		@tmp_ui_name engg_name,
		@engg_base_req_no engg_name

	SELECT @engg_base_req_no = 'BASE'

	--select process name for description  
	SELECT @tmp_proc = rtrim(process_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_req_no)
		AND process_descr = rtrim(@engg_process_descr)

	--select component name for description  
	SELECT @tmp_comp_name = rtrim(component_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_descr = rtrim(@engg_component)

	--select activity name for description  
	SELECT @tmp_acty_name = rtrim(activity_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp_name)
		AND activity_descr = rtrim(@engg_act_descr)

	--select UI name for description  
	SELECT @tmp_ui_name = min(rtrim(ui_name))
	--modified by shafina on 09-jan-2004 to fetch the ui from ui_mst table  
	--modified by Sulochana on 08-oct-2004 to fetch the ui from ep_ui_req_dtl table  
	FROM ep_ui_req_dtl(NOLOCK)
	-- from ep_ui_mst (nolock)  
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		--modified by shafina on 16-jan-2004 comment the req_no condition  
		AND req_no = rtrim(@engg_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp_name)
		AND activity_name = rtrim(@tmp_acty_name)

	/*select the min of page*/
	DECLARE @page_bt_synonym_tmp engg_name

	SELECT TOP 1 @page_bt_synonym_tmp = rtrim(page_bt_synonym)
	FROM ep_ui_page_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_base_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp_name)
		AND activity_name = rtrim(@tmp_acty_name)
		AND ui_name = rtrim(@tmp_ui_name)
	ORDER BY horder,
		vorder

	/*  
fetch the section details for the selected activity/ui/pages and display in the  
multiline  
*/
	SELECT CASE upper(border_required)
			WHEN 'y'
				THEN 1
			ELSE 0
			END 'engg_sec_bord_req',
		section_bt_synonym 'engg_sec_btsynname',
		bt_synonym_caption 'engg_sec_descr',
		NColSpan 'section_colspan',
		NRowSpan 'section_rowspan',
		--case upper(IsStatic)  
		--when 'Y'  then 1  
		--else 0  
		--end    'isstatic',  
		a.title_alignment 'engg_sec_title_align',
		CASE upper(title_required)
			WHEN 'y'
				THEN 1
			ELSE 0
			END 'engg_sec_title_req',
		CASE upper(visisble_flag)
			WHEN 'y'
				THEN 1
			ELSE 0
			END 'engg_sec_visible',
		a.section_type 'engg_sec_type',
		---Tech-406, on change of Activity name section width and height should come with scalemode
-- Added for Request TECH-43307 Starts
					CASE 
						WHEN IsResponsive = 'y'
						  THEN 1
						WHEN IsResponsive = 'n'
						  THEN 0
						END 'engg_mob_responsive',
                    CASE 
                        WHEN mob_pop_fullview = 'y'
                          THEN 1
                        WHEN mob_pop_fullview = 'n'
                          THEN 0
                    END 'engg_mob_fullview',
-- Added for Request TECH-43307 Ends

		cast(a.height AS VARCHAR(60)) + a.Section_height_Scalemode 'engg_sec_height',
		cast(a.Width AS VARCHAR(60)) + a.Section_width_Scalemode 'engg_sec_width',
		-- code modified by Gopinath S for the Call ID PNR2.0_22596 begins  
		--   a.caption_Format 'engg_sec_cap_format',  
		CASE 
			WHEN caption_Format = 'bes'
				THEN 'Control Besides Caption'
			WHEN caption_Format = 'und'
				THEN 'Control Under Caption'
			END 'engg_sec_cap_format',
		-- code modified by Gopinath S for the Call ID PNR2.0_22596 ends  
		a.ctrl_caption_align 'engg_sec_cap_align',
		a.SectionPrefixClass 'engg_sec_prefix_class',
		a.section_doc 'engg_sect_doc',
		a.section_collapse 'Sec_Collapse',
		a.section_collapsemode 'sec_collapsemode' --shakthi  
		,
		isnull(reg.parameter_text, '') 'engg_region',
		isnull(titlpo.parameter_text, '') 'engg_title_pos',
		isnull(col.parameter_text, '') 'engg_col_dir',
		isnull(sectl.parameter_text, '') 'engg_sect_lay',
		CASE 
			WHEN SectionLayout = 'abs'
				THEN isnull(XYCoordinates, '')
			WHEN SectionLayout = 'col'
				THEN isnull(ColumnLayWidth, '')
			ELSE NULL
			END 'engg_sec_lay_con' -- PLF2.0_17570   
		,
		ISNULL(Associated_Control,	'') 'engg_associatedcontrol',
		ISNULL(a.ForResponsive,		'') 'engg_sect_forresponsive',		--Code Added for TECH-69624
		'...'							'engg_sec_customborder',		--Code Added for TECH-69624
		ISNULL(a.Orientation,		'') 'Orientation',					--Code Added for TECH-75230
		--Code Added for the Defectid Tech-70687 starts
		'...'													'engg_sec_titleaction',
        CASE WHEN a.LeftToolbar		= 'Y' THEN 1 ELSE 0 END		'engg_sec_lefttb',
        CASE WHEN a.RightToolbar	= 'Y' THEN 1 ELSE 0 END		'engg_sec_righttb',
        CASE WHEN a.TopToolbar		= 'Y' THEN 1 ELSE 0 END		'engg_sec_toptb',
        CASE WHEN a.BottomToolbar	= 'Y' THEN 1 ELSE 0 END		'engg_sec_bottomtb',
		a.MinimizedRows											'engg_sec_MinRows',
		a.ViewMode												'engg_sec_VwMode',
		a.TitleIcon						'engg_sec_titleicon'		--TECH-72114
        --Code Added for the Defectid Tech-70687 ends
	FROM ep_component_glossary_mst b(NOLOCK)
	RIGHT JOIN ep_ui_section_dtl a(NOLOCK) ON b.customer_name = a.customer_name
		AND b.project_name = a.project_name
		AND b.req_no = a.req_no
		AND b.process_name = a.process_name
		AND b.component_name = a.component_name
		AND b.bt_synonym_name = a.section_bt_synonym
	LEFT JOIN ep_device_quick_code_met reg(NOLOCK) ON a.Region = reg.parameter_code
		AND reg.parameter_type = 'Region'
	LEFT JOIN ep_device_quick_code_met titlpo(NOLOCK) ON a.TitlePosition = titlpo.parameter_code
		AND titlpo.parameter_type = 'TitlePosition'
	LEFT JOIN ep_device_quick_code_met col(NOLOCK) ON a.CollapseDir = col.parameter_code
		AND col.parameter_type = 'CollapseDir'
	LEFT JOIN ep_device_quick_code_met sectl(NOLOCK) ON a.SectionLayout = sectl.parameter_code
		AND sectl.parameter_type = 'SectionLayout'
	WHERE a.customer_name = rtrim(@engg_customer_name)
		AND a.project_name = rtrim(@engg_project_name)
		AND a.req_no = rtrim(@engg_base_req_no)
		AND a.process_name = rtrim(@tmp_proc)
		AND a.component_name = rtrim(@tmp_comp_name)
		AND a.activity_name = rtrim(@tmp_acty_name)
		AND a.ui_name = rtrim(@tmp_ui_name)
		AND a.page_bt_synonym = rtrim(@page_bt_synonym_tmp)
		--  and b.customer_name  =* a.customer_name  
		--  and b.project_name  =* a.project_name  
		--  and b.req_no  =* a.req_no  
		--  and b.process_name  =* a.process_name  
		--  and b.component_name =* a.component_name  
		--  and b.bt_synonym_name =* a.section_bt_synonym  
		-- modified by shafina on 30-jan-2004  
		AND section_bt_synonym NOT IN (
			'PrjHdnSection',
			'[tabcontrol]',
			'hdnrt_stsection'
			)
		AND section_type NOT IN ('Sidebar','Toolbar') --Tech-70687
	/* Code Modified for the Case ID:PNR2.0_30667 By Shakthi P */
	ORDER BY section_bt_synonym

	/*  
--OuputList  
Select --null 'freefr_userstatus',  
null 'engg_sec_bord_req',  
null 'engg_sec_btsynname',  
null 'engg_sec_descr',  
null 'engg_sec_title_align',  
null 'engg_sec_title_req',  
null 'engg_sec_visible',  
null 'engg_sec_type',  
null 'engg_sec_height',  
null 'engg_sec_width',  
null 'engg_sec_cap_format',  
null 'engg_sec_cap_align',  
null 'engg_sec_prefix_class',  
null 'engg_sect_doc' from ***  
*/
	SET NOCOUNT OFF
END
GO

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'EP_Layout_sp_SActScML_O' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON EP_Layout_sp_SActScML_O TO PUBLIC
END
GO

