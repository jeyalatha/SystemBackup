IF EXISTS(SELECT 'X' From SYSOBJECTS WHERE NAME ='ep_maireeSpep_layHdrRef' AND TYPE='P')
   BEGIN
        DROP PROC ep_maireeSpep_layHdrRef
   END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		ep_maireeSpep_layHdrRef.sql
********************************************************************************/
/******************************************************************************/
/* Procedure					: ep_maireeSpep_layHdrRef								 */
/* Description					: 								 */
/******************************************************************************/
/* Project						: 								 */
/* EcrNo						: 								 */
/* Version						: 								 */
/******************************************************************************/
/* Referenced					: 								 */
/* Tables						: 								 */
/******************************************************************************/
/* Development history			: 								 */
/******************************************************************************/
/* Author						: 								 */
/* Date							: Apr 16 2008 10:25AM								 */
/******************************************************************************/
/* Modification History			: 								 */
/******************************************************************************/
/* modified by			: Jeya											*/
/* date					: 24-nov-2008									*/
/* BugId				: PNR2.0_1790 									*/
/************************************************************************/
/* modified by  : Gowrisankar M For BugId : PNR2.0_20554                        */
/* date         : 07-Jan-2009	                                                */
/* description  : State section must not get loaded in the section combo		*/
/********************************************************************************/
/* modified by		: Jeyalatha K 											*/
/* date				: 11-Feb-2011                                           */
/* Bug Id			: PNR2.0_30127											*/
/* Modified for		: Feature  Release										*/
/****************************************************************************/
/* Modified by  : Kalidas S	                                                  */
/* Date         : 03-Aug-2015                                                  */
/* Defect ID	: PLF2.0_14096                                                 */
/********************************************************************************/
/* Modified by  : Veena U	                                                  */
/* Date         : 24-Dec-2015*/
/* Defect ID	: PLF2.0_16153                                                 */
/********************************************************************************/
/* Modified by  : Veena U                                                  */
/* Date         : 24-Feb-2016                                                 */
/* Defect ID	: PLF2.0_16291                                                */
/********************************************************************************/
/* Modified by  : Veena U                                                  */
/* Date         : 28-Mar-2016                                                 */
/* Call ID		: PLF2.0_17570                                               */
/********************************************************************************/
/* modified by			Date				Defect ID							*/
/* Veena U				08-Jun-2016			PLF2.0_18487						*/
/********************************************************************************/
/***********************************************************************************************/
/* Modified by : Ganesh Prabhu S/Ranjitha R       Date: 30-May-2017     Defect ID:TECH-10118   */
/* Modified by : Jeya Latha K					  Date: 25-Jul-2019     Defect ID:TECH-36371   */
/* Modified by : Priyadharshini U/Rajeswari M	  Date: 29-Jan-2020     Defect ID:TECH-42483   */
/***********************************************************************************************/
/* Modified by	:	Priyadharshini U 														   */
/* Modified on	:	08/07/2022				 												   */
/* Defect ID	:	Tech-70687																   */
/* Description	:	Tool and Toolbars														   */
/***********************************************************************************************/
/* Modified by : Priyadharshini U  															   */
/* Modified on : 27-July-2022																   */
/* Defect ID   : TECH-71262																	   */
/* Description : Platform Features for the Month of July'22									   */
/***********************************************************************************************/
/* Modified by    :    Ponmalar A															   */
/* Modified on    :    02/12/22																   */
/* Defect ID      :    TECH-75230															   */
/* Description    : Platform Release for the Month of Nov'22								   */
/***********************************************************************************************/
create PROCEDURE ep_maireeSpep_layHdrRef
	@ctxt_ouinstance ctxt_ouinstance, --Input 
	@ctxt_user ctxt_user, --Input 
	@ctxt_language ctxt_language, --Input 
	@ctxt_service ctxt_service, --Input 
	@enggad_fprowno rowno, --Input/Output
	@enggpa_fprowno rowno, --Input/Output
	@engg_act_descr engg_description, --Input/Output
	@engg_att_ui_cap_align engg_name, --Input/Output
	@engg_att_ui_format engg_description, --Input/Output
	@engg_att_ui_grid_type engg_type, --Input/Output
	@engg_att_ui_trail_bar engg_name, --Input/Output
	@engg_att_ui_type engg_name, --Input/Output
	@engg_callout_type engg_type, --Input/Output
	@engg_component engg_description, --Input/Output
	@engg_cont_page_bts engg_name, --Input/Output
	@engg_cont_sec_bts engg_name, --Input/Output
	@engg_customer_name engg_name, --Input/Output
	@engg_c_fprowno rowno, --Input/Output
	@engg_enum_btsynname engg_name, --Input/Output
	@engg_enum_page_bts engg_name, --Input/Output
	@engg_enum_sec_bts engg_name, --Input/Output
	@engg_grid_grid_code engg_name, --Input/Output
	@engg_grid_page_bts engg_name, --Input/Output
	@engg_grid_sec_bts engg_name, --Input/Output
	@engg_lay_page_bts engg_name, --Input/Output
	@engg_lnk_page_descr engg_description, --Input/Output
	@engg_l_fprowno rowno, --Input/Output
	@engg_m_fprowno rowno, --Input/Output
	@engg_process_descr engg_description, --Input/Output
	@engg_project_name engg_name, --Input/Output
	@engg_radio_btsynname engg_name, --Input/Output
	@engg_radio_page_bts engg_name, --Input/Output
	@engg_radio_sec_bts engg_name, --Input/Output
	@engg_req_no engg_name, --Input/Output
	@engg_rf_act engg_description, --Input/Output
	@engg_rf_comp engg_description, --Input/Output
	@engg_rf_ui engg_description, --Input/Output
	@engg_r_fprowno rowno, --Input/Output
	@engg_sec_page_bts engg_name, --Input/Output
	@engg_tab_height engg_length, --Input/Output
	@engg_ui_descr engg_name, --Input/Output
	@engg_y_fprowno rowno, --Input/Output
	@ezee_taskpane engg_name, --Input/Output
	@state_processing engg_name, --Input/Output
	@_sec_fprowno rowno, --Input/Output
	@engg_isdevice engg_flag, --Input/Output
	@engg_smarthide engg_flag, --Input/Output
	@engg_ilbotitle engg_flag, --Input/Output
	@engg_hdrpersonalisation engg_flag, --Input/Output
	@engg_syst_excl_tab_ind engg_flag, --Input/Output
	@engg_phone engg_flag, --Input/Output
	@engg_tablet engg_flag, --Input/Output
	@engg_desk_brw engg_flag, --Input/Output
	@engg_tab_style engg_name, --Input/Output
	@engg_ui_layout engg_name, --Input/Output
	@engg_ui_laycon engg_description, --Input/Output
	@engg_tab_hdr_pos engg_name, --Input/Output
	@engg_hide_print engg_flag, --Input/Output
	@engg_tab_rotate engg_name, --Input/Output
	@engg_page_name engg_name, --Input/Output
	@engg_sect_name engg_name, --Input/Output
	@engg_control_name engg_name, --Input/Output
	@engg_group_caption engg_description, --Input/Output
	@engg_group_name engg_name, --Input/Output
	@engg_hide_default engg_flag, --Input/Output
	@engg_uisubtype engg_name, --Input/Output
	@engg_nativeapp engg_flag,
	@engg_popup_close engg_flag,
	@engg_titlebar_search	engg_flag,
	@engg_lefttb		engg_seqno,
	@engg_righttb		engg_seqno,
	@engg_toptb			engg_seqno,
	@engg_bottomtb		engg_seqno,
	@engg_att_sidebar	engg_seqno,
	@engg_att_docked	engg_name,
	--Code Added for TECH-71262 starts
	@engg_cont_sec_type_bts		engg_name,
	@engg_grid_sec_type_bts		engg_name,
	@engg_grid_ctrl_type_bts	engg_name,
	--Code Added for TECH-71262 ends
	@PullToRefresh		engg_seqno,		--Code added for TECH-75230
	@m_errorid INT OUTPUT --To Return Execution Status
AS
BEGIN
	-- nocount should be switched on to prevent phantom rows
	SET NOCOUNT ON
	-- @m_errorid should be 0 to Indicate Success
	SET @m_errorid = 0
	--declaration of temporary variables
	--temporary and formal parameters mapping
	SET @ctxt_user = ltrim(rtrim(@ctxt_user))
	SET @ctxt_service = ltrim(rtrim(@ctxt_service))
	SET @engg_act_descr = ltrim(rtrim(@engg_act_descr))
	SET @engg_att_ui_cap_align = ltrim(rtrim(@engg_att_ui_cap_align))
	SET @engg_att_ui_format = ltrim(rtrim(@engg_att_ui_format))
	SET @engg_att_ui_grid_type = ltrim(rtrim(@engg_att_ui_grid_type))
	SET @engg_att_ui_trail_bar = ltrim(rtrim(@engg_att_ui_trail_bar))
	SET @engg_att_ui_type = ltrim(rtrim(@engg_att_ui_type))
	SET @engg_component = ltrim(rtrim(@engg_component))
	SET @engg_cont_page_bts = ltrim(rtrim(@engg_cont_page_bts))
	SET @engg_cont_sec_bts = ltrim(rtrim(@engg_cont_sec_bts))
	SET @engg_customer_name = ltrim(rtrim(@engg_customer_name))
	SET @engg_enum_btsynname = ltrim(rtrim(@engg_enum_btsynname))
	SET @engg_enum_page_bts = ltrim(rtrim(@engg_enum_page_bts))
	SET @engg_enum_sec_bts = ltrim(rtrim(@engg_enum_sec_bts))
	SET @engg_grid_grid_code = ltrim(rtrim(@engg_grid_grid_code))
	SET @engg_grid_page_bts = ltrim(rtrim(@engg_grid_page_bts))
	SET @engg_grid_sec_bts = ltrim(rtrim(@engg_grid_sec_bts))
	SET @engg_lay_page_bts = ltrim(rtrim(@engg_lay_page_bts))
	SET @engg_lnk_page_descr = ltrim(rtrim(@engg_lnk_page_descr))
	SET @engg_process_descr = ltrim(rtrim(@engg_process_descr))
	SET @engg_project_name = ltrim(rtrim(@engg_project_name))
	SET @engg_radio_btsynname = ltrim(rtrim(@engg_radio_btsynname))
	SET @engg_radio_page_bts = ltrim(rtrim(@engg_radio_page_bts))
	SET @engg_radio_sec_bts = ltrim(rtrim(@engg_radio_sec_bts))
	SET @engg_req_no = ltrim(rtrim(@engg_req_no))
	SET @engg_rf_act = ltrim(rtrim(@engg_rf_act))
	SET @engg_rf_comp = ltrim(rtrim(@engg_rf_comp))
	SET @engg_rf_ui = ltrim(rtrim(@engg_rf_ui))
	SET @engg_sec_page_bts = ltrim(rtrim(@engg_sec_page_bts))
	SET @engg_ui_descr = ltrim(rtrim(@engg_ui_descr))
	SET @eZee_Taskpane = ltrim(rtrim(@eZee_Taskpane)) -- added for Bug id: PNR2.0_30127	
	SET @state_processing = ltrim(rtrim(@state_processing))
	SET @engg_callout_type = ltrim(rtrim(@engg_callout_type)) -- added for request id: PNR2.0_1790
	SET @engg_isdevice = ltrim(rtrim(@engg_isdevice))
	SET @engg_smarthide = ltrim(rtrim(@engg_smarthide))
	SET @engg_ilbotitle = ltrim(rtrim(@engg_ilbotitle))
	SET @engg_hdrpersonalisation = ltrim(rtrim(@engg_hdrpersonalisation))
	SET @engg_syst_excl_tab_ind = ltrim(rtrim(@engg_syst_excl_tab_ind))
	SET @engg_phone = ltrim(rtrim(@engg_phone))
	SET @engg_tablet = ltrim(rtrim(@engg_tablet))
	SET @engg_desk_brw = ltrim(rtrim(@engg_desk_brw))
	SET @engg_tab_style = ltrim(rtrim(@engg_tab_style))
	SET @engg_ui_layout = ltrim(rtrim(@engg_ui_layout))
	SET @engg_ui_laycon = ltrim(rtrim(@engg_ui_laycon))
	SET @engg_tab_hdr_pos = ltrim(rtrim(@engg_tab_hdr_pos))
	SET @engg_hide_print = ltrim(rtrim(@engg_hide_print))
	SET @engg_tab_rotate = ltrim(rtrim(@engg_tab_rotate))
	SET @engg_page_name = ltrim(rtrim(@engg_page_name))
	SET @engg_sect_name = ltrim(rtrim(@engg_sect_name))
	SET @engg_control_name = ltrim(rtrim(@engg_control_name))
	SET @engg_group_caption = ltrim(rtrim(@engg_group_caption))
	SET @engg_group_name = ltrim(rtrim(@engg_group_name))
	SET @engg_hide_default = ltrim(rtrim(@engg_hide_default))
	SET @engg_uisubtype = ltrim(rtrim(@engg_uisubtype))
	SET @engg_nativeapp = LTRIM(rtrim(@engg_nativeapp))
	SET @engg_popup_close = LTRIM(rtrim(@engg_popup_close))
	SET @engg_att_docked = LTRIM(rtrim(@engg_att_docked)) --Tech-70687	 

	--null checking
	IF @ctxt_ouinstance = - 915
		SELECT @ctxt_ouinstance = NULL

	IF @ctxt_user = '~#~'
		SELECT @ctxt_user = NULL

	IF @ctxt_language = - 915
		SELECT @ctxt_language = NULL

	IF @ctxt_service = '~#~'
		SELECT @ctxt_service = NULL

	IF @enggad_fprowno = - 915
		SELECT @enggad_fprowno = NULL

	IF @enggpa_fprowno = - 915
		SELECT @enggpa_fprowno = NULL

	IF @engg_act_descr = '~#~'
		SELECT @engg_act_descr = NULL

	IF @engg_att_ui_cap_align = '~#~'
		SELECT @engg_att_ui_cap_align = NULL

	IF @engg_att_ui_format = '~#~'
		SELECT @engg_att_ui_format = NULL

	IF @engg_att_ui_grid_type = '~#~'
		SELECT @engg_att_ui_grid_type = NULL

	IF @engg_att_ui_trail_bar = '~#~'
		SELECT @engg_att_ui_trail_bar = NULL

	IF @engg_att_ui_type = '~#~'
		SELECT @engg_att_ui_type = NULL

	IF @engg_component = '~#~'
		SELECT @engg_component = NULL

	IF @engg_cont_page_bts = '~#~'
		SELECT @engg_cont_page_bts = NULL

	IF @engg_cont_sec_bts = '~#~'
		SELECT @engg_cont_sec_bts = NULL

	IF @engg_customer_name = '~#~'
		SELECT @engg_customer_name = NULL

	IF @engg_c_fprowno = - 915
		SELECT @engg_c_fprowno = NULL

	IF @engg_enum_btsynname = '~#~'
		SELECT @engg_enum_btsynname = NULL

	IF @engg_enum_page_bts = '~#~'
		SELECT @engg_enum_page_bts = NULL

	IF @engg_enum_sec_bts = '~#~'
		SELECT @engg_enum_sec_bts = NULL

	IF @engg_grid_grid_code = '~#~'
		SELECT @engg_grid_grid_code = NULL

	IF @engg_grid_page_bts = '~#~'
		SELECT @engg_grid_page_bts = NULL

	IF @engg_grid_sec_bts = '~#~'
		SELECT @engg_grid_sec_bts = NULL

	IF @engg_lay_page_bts = '~#~'
		SELECT @engg_lay_page_bts = NULL

	IF @engg_lnk_page_descr = '~#~'
		SELECT @engg_lnk_page_descr = NULL

	IF @engg_l_fprowno = - 915
		SELECT @engg_l_fprowno = NULL

	IF @engg_m_fprowno = - 915
		SELECT @engg_m_fprowno = NULL

	IF @engg_process_descr = '~#~'
		SELECT @engg_process_descr = NULL

	IF @engg_project_name = '~#~'
		SELECT @engg_project_name = NULL

	IF @engg_radio_btsynname = '~#~'
		SELECT @engg_radio_btsynname = NULL

	IF @engg_radio_page_bts = '~#~'
		SELECT @engg_radio_page_bts = NULL

	IF @engg_radio_sec_bts = '~#~'
		SELECT @engg_radio_sec_bts = NULL

	IF @engg_req_no = '~#~'
		SELECT @engg_req_no = NULL

	IF @engg_rf_act = '~#~'
		SELECT @engg_rf_act = NULL

	IF @engg_rf_comp = '~#~'
		SELECT @engg_rf_comp = NULL

	IF @engg_rf_ui = '~#~'
		SELECT @engg_rf_ui = NULL

	IF @engg_r_fprowno = - 915
		SELECT @engg_r_fprowno = NULL

	IF @engg_sec_page_bts = '~#~'
		SELECT @engg_sec_page_bts = NULL

	IF @engg_tab_height = - 915
		SELECT @engg_tab_height = NULL

	IF @engg_ui_descr = '~#~'
		SELECT @engg_ui_descr = NULL

	-- added for Bug id: PNR2.0_30127	
	IF @eZee_Taskpane = '~#~'
		SELECT @eZee_Taskpane = NULL

	IF @engg_y_fprowno = - 915
		SELECT @engg_y_fprowno = NULL

	IF @state_processing = '~#~'
		SELECT @state_processing = NULL

	IF @_sec_fprowno = - 915
		SELECT @_sec_fprowno = NULL

	-- added for request id: PNR2.0_1790
	IF @engg_callout_type = '~#~'
		SELECT @engg_callout_type = NULL

	IF @engg_isdevice = '~#~'
		SELECT @engg_isdevice = NULL

	IF @engg_smarthide = '~#~'
		SELECT @engg_smarthide = NULL

	IF @engg_ilbotitle = '~#~'
		SELECT @engg_ilbotitle = NULL

	IF @engg_hdrpersonalisation = '~#~'
		SELECT @engg_hdrpersonalisation = NULL

	IF @engg_syst_excl_tab_ind = '~#~'
		SELECT @engg_syst_excl_tab_ind = NULL

	IF @engg_phone = '~#~'
		SELECT @engg_phone = NULL

	IF @engg_tablet = '~#~'
		SELECT @engg_tablet = NULL

	IF @engg_desk_brw = '~#~'
		SELECT @engg_desk_brw = NULL

	IF @engg_tab_style = '~#~'
		SELECT @engg_tab_style = NULL

	IF @engg_ui_layout = '~#~'
		SELECT @engg_ui_layout = NULL

	IF @engg_ui_laycon = '~#~'
		SELECT @engg_ui_laycon = NULL

	IF @engg_tab_hdr_pos = '~#~'
		SELECT @engg_tab_hdr_pos = NULL

	IF @engg_hide_print = '~#~'
		SELECT @engg_hide_print = NULL

	IF @engg_tab_rotate = '~#~'
		SELECT @engg_tab_rotate = NULL

	IF @engg_page_name = '~#~'
		SELECT @engg_page_name = NULL

	IF @engg_sect_name = '~#~'
		SELECT @engg_sect_name = NULL

	IF @engg_control_name = '~#~'
		SELECT @engg_control_name = NULL

	IF @engg_group_caption = '~#~'
		SELECT @engg_group_caption = NULL

	IF @engg_group_name = '~#~'
		SELECT @engg_group_name = NULL

	IF @engg_hide_default = '~#~'
		SELECT @engg_hide_default = NULL

	IF @engg_uisubtype = '~#~'
		SELECT @engg_uisubtype = NULL

	IF @engg_nativeapp = '~#~'
		SELECT @engg_nativeapp = NULL

	IF @engg_popup_close = '~#~'
		SELECT @engg_popup_close = NULL

		--Tech-70687

	IF @engg_lefttb = - 915
		SELECT @engg_lefttb = NULL

	IF @engg_righttb = - 915
		SELECT @engg_righttb = NULL

	IF @engg_toptb = - 915
		SELECT @engg_toptb = NULL

	IF @engg_bottomtb = - 915
		SELECT @engg_bottomtb = NULL

	IF @engg_att_sidebar = - 915
		SELECT @engg_att_sidebar = NULL

	IF @engg_att_docked = '~#~'
		SELECT @engg_att_docked = NULL			--Tech-70687

	IF @PullToRefresh = - 915		--Code added for TECH-75230
		SELECT @PullToRefresh = NULL

	DECLARE @tmp_proc engg_name,
		@tmp_comp engg_name,
		@tmp_act engg_name,
		@tmp_ui engg_name,
		@engg_base_req_no engg_name,
		-- Added for PLF2.0_14096 starts
		@smarthide engg_name,
		@isdevice engg_name,
		@ilbotitle engg_name,
		-- Added for PLF2.0_14096 ends,
		@personalistion engg_name,
		@exclude_syst_tab_ind engg_name,
		@enggphone engg_name,
		@enggtablet engg_name,
		@enggtabstyle engg_name,
		@isDesktop engg_flag
	--	@engg_titlebar_search	engg_flag

	-- 	declare	@engg_cont_page_bts		engg_name, 
	-- 			@engg_cont_sec_bts		engg_name, 
	-- 			@engg_enum_btsynname	engg_name
	SELECT @engg_base_req_no = 'Base'

	SELECT @tmp_proc = process_name,
		@tmp_comp = component_name,
		@tmp_act = activity_name,
		@tmp_ui = ui_name
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND req_no = @engg_req_no
		AND process_descr = @engg_process_descr
		AND component_descr = @engg_component
		AND activity_descr = @engg_act_descr
		AND ui_descr = @engg_ui_descr

	SELECT @engg_att_ui_cap_align = CASE 
			WHEN upper(rtrim(caption_alignment)) = 'CENT'
				THEN 'center'
			ELSE isnull(caption_alignment, '')
			END,
		@engg_att_ui_format = CASE 
			WHEN upper(rtrim(ui_format)) = 'BES'
				THEN 'controls beside captions'
			WHEN upper(rtrim(ui_format)) = 'UND'
				THEN 'controls under captions'
			ELSE isnull(ui_format, '')
			END,
		@engg_att_ui_trail_bar = CASE 
			WHEN upper(rtrim(trail_bar)) = 'BOTT'
				THEN 'bottom'
			ELSE isnull(trail_bar, '')
			END,
		@engg_att_ui_grid_type = CASE 
			WHEN upper(rtrim(grid_type)) = 'FP'
				THEN 'far point'
			WHEN upper(rtrim(grid_type)) = 'HTM'
				THEN 'htm'
			ELSE isnull(grid_type, '')
			END,
		@State_Processing = State_Processing,
		@engg_tab_height = rtrim(tab_height),
		@engg_att_ui_type = rtrim(ui_type),
		@engg_callout_type = rtrim(callout_type),
		@eZee_Taskpane = rtrim(taskpane_req), -- added for Bug id: PNR2.0_30127	
		@engg_hide_default = rtrim(hide_imp_defaults),
		@engg_uisubtype = rtrim(ui_subtype),
		@engg_nativeapp = rtrim(NativeApplication),
		@engg_popup_close = rtrim(Conditional_popupclose),
		@engg_titlebar_search	= rtrim(Titlebar_Search)
	FROM ep_ui_mst a(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND req_no = @engg_base_req_no
		AND process_name = @tmp_proc
		AND component_name = @tmp_comp
		AND activity_name = @tmp_act
		AND ui_name = @tmp_ui

	IF @engg_att_ui_cap_align IS NULL
	BEGIN
		SELECT @engg_att_ui_cap_align = current_value
		FROM es_comp_param_mst_vw(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND req_no = @engg_base_req_no
			AND process_name = @tmp_proc
			AND component_name = @tmp_comp
			AND param_category = 'CAPTIONALIGN'
			AND param_type = 'UIFORMAT'
	END

	IF @engg_att_ui_format IS NULL
	BEGIN
		SELECT @engg_att_ui_format = current_value
		FROM es_comp_param_mst_vw(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND req_no = @engg_base_req_no
			AND process_name = @tmp_proc
			AND component_name = @tmp_comp
			AND param_category = 'CAPTIONFORMAT'
			AND param_type = 'UIFORMAT'
	END

	IF @engg_att_ui_trail_bar IS NULL
	BEGIN
		SELECT @engg_att_ui_trail_bar = current_value
		FROM es_comp_param_mst_vw(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND req_no = @engg_req_no
			AND process_name = @tmp_proc
			AND component_name = @tmp_comp
			AND param_category = 'TRAILBAR'
			AND param_type = 'UIFORMAT'
	END

	IF isnull(@engg_att_ui_type, '') = ''
	BEGIN
		SELECT @engg_att_ui_type = rtrim(quick_code_value)
		FROM ep_quick_code_mst(NOLOCK)
		WHERE quick_code_Type = 'UI_FORMAT_TYPE'
			AND quick_code = 'UI_TYPE_BLK'
	END

	/*
	fetch the min of pages defined for the ui (page combo - sections tab )
	*/
	SELECT TOP 1 @engg_sec_page_bts = rtrim(page_bt_synonym)
	FROM ep_ui_page_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND req_no = @engg_base_req_no
		AND process_name = @tmp_proc
		AND component_name = @tmp_comp
		AND activity_name = @tmp_act
		AND ui_name = @tmp_ui
	ORDER BY horder,
		vorder

	/*
	fetch the min of pages defined for the ui (page combo - section layout tab )
	*/
	SELECT TOP 1 @engg_cont_page_bts = rtrim(page_bt_synonym)
	FROM ep_ui_page_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND req_no = @engg_base_req_no
		AND process_name = @tmp_proc
		AND component_name = @tmp_comp
		AND activity_name = @tmp_act
		AND ui_name = @tmp_ui
	ORDER BY horder,
		vorder

	/*
	Fetch the min of sections define for the page (section combo - section layout tab )
	*/
	SELECT @engg_cont_sec_bts = Min(rtrim(section_bt_synonym))
	FROM ep_ui_section_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND req_no = @engg_base_req_no
		AND process_name = @tmp_proc
		AND component_name = @tmp_comp
		AND activity_name = @tmp_act
		AND ui_name = @tmp_ui
		AND page_bt_synonym = @engg_cont_page_bts
		AND section_bt_synonym NOT IN (
			'PrjHdnSection',
			'[tabcontrol]',
			'hdnrt_stsection'
			) -- Code modified for PNR2.0_20554  on  07-Jan-2009
		AND section_type NOT IN (
			'Tree',
			'chart'
			)

	/*
	fetch the min of pages defined for the ui (page combo - page layout tab )
	*/
	SELECT TOP 1 @engg_lay_page_bts = rtrim(page_bt_synonym)
	FROM ep_ui_page_dtl(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND req_no = @engg_base_req_no
		AND process_name = @tmp_proc
		AND component_name = @tmp_comp
		AND activity_name = @tmp_act
		AND ui_name = @tmp_ui
	ORDER BY horder,
		vorder

	/*
	fetch the min of pages defined for the ui ( page combo - grid controls tab )
	*/
	SELECT TOP 1 @engg_grid_page_bts = rtrim(p.page_bt_synonym)
	FROM ep_ui_page_dtl p(NOLOCK)
	WHERE p.customer_name = @engg_customer_name
		AND p.project_name = @engg_project_name
		AND p.req_no = @engg_base_req_no
		AND p.process_name = @tmp_proc
		AND p.component_name = @tmp_comp
		AND p.activity_name = @tmp_act
		AND p.ui_name = @tmp_ui
		AND EXISTS (
			SELECT c.page_bt_synonym
			FROM ep_ui_control_dtl c(NOLOCK),
				es_comp_ctrl_type_mst_vw v(NOLOCK)
			WHERE p.customer_name = c.customer_name
				AND p.project_name = c.project_name
				AND p.process_name = c.process_name
				AND p.component_name = c.component_name
				AND p.activity_name = c.activity_name
				AND p.ui_name = c.ui_name
				AND p.page_bt_synonym = c.page_bt_synonym
				AND c.customer_name = v.customer_name
				AND c.project_name = v.project_name
				AND c.process_name = v.process_name
				AND c.component_name = v.component_name
				AND c.control_type = v.ctrl_type_name
				AND v.base_ctrl_type = 'Grid'
			)
	ORDER BY p.horder,
		p.vorder

	/*
	Fetch the min of sections define for the page ( section combo - grid controls tab )
	*/
	SELECT @engg_grid_sec_bts = min(s.section_bt_synonym),
		   @engg_grid_sec_type_bts = min(s.section_type),	--Code Added for TECH-71262
		   @engg_grid_ctrl_type_bts	= min(c.control_type)	--Code Added for TECH-71262
	FROM ep_ui_section_dtl s(NOLOCK),
		ep_ui_control_dtl c(NOLOCK),
		es_comp_ctrl_type_mst_vw v(NOLOCK)
	WHERE s.customer_name = @engg_customer_name
		AND s.project_name = @engg_project_name
		AND s.req_no = @engg_base_req_no
		AND s.process_name = @tmp_proc
		AND s.component_name = @tmp_comp
		AND s.activity_name = @tmp_act
		AND s.ui_name = @tmp_ui
		AND s.page_bt_synonym = @engg_grid_page_bts
		AND s.customer_name = c.customer_name
		AND s.project_name = c.project_name
		AND s.process_name = c.process_name
		AND s.component_name = c.component_name
		AND s.activity_name = c.activity_name
		AND s.ui_name = c.ui_name
		AND s.page_bt_synonym = c.page_bt_synonym
		AND s.section_bt_synonym = c.section_bt_synonym
		AND c.customer_name = v.customer_name
		AND c.project_name = v.project_name
		AND c.process_name = v.process_name
		AND c.component_name = v.component_name
		AND c.control_type = v.ctrl_type_name
		AND v.base_ctrl_type = 'Grid'
		AND s.section_bt_synonym NOT IN (
			'PrjHdnSection',
			'[tabcontrol]',
			'hdnrt_stsection'
			) -- Code modified for PNR2.0_20554  on  07-Jan-2009
		AND s.section_type NOT IN (
			'Tree',
			'chart'
			)

	/*
	Fetch the min of Grid Controls for the Section (Grid ID combo - Grid Controls tab)
	*/
	SELECT TOP 1 @engg_grid_grid_code = rtrim(a.control_bt_synonym)
	FROM ep_ui_control_dtl a(NOLOCK),
		es_comp_ctrl_type_mst_vw b(NOLOCK)
	WHERE a.customer_name = @engg_customer_name
		AND a.project_name = @engg_project_name
		AND a.req_no = @engg_base_req_no
		AND a.process_name = @tmp_proc
		AND a.component_name = @tmp_comp
		AND a.activity_name = @tmp_act
		AND a.ui_name = @tmp_ui
		AND a.page_bt_synonym = @engg_grid_page_bts
		AND a.section_bt_synonym = @engg_grid_sec_bts
		AND b.customer_name = a.customer_name
		AND b.project_name = a.project_name
		AND b.process_name = a.process_name
		AND b.component_name = a.component_name
		AND a.control_type = b.ctrl_type_name
		AND b.base_ctrl_type = 'Grid'
	ORDER BY a.control_bt_synonym

	/*
	fetch the min of pages defined for the ui ( page combo - radio buttons tab )
	*/
	SELECT TOP 1 @engg_radio_page_bts = rtrim(p.page_bt_synonym)
	FROM ep_ui_page_dtl p(NOLOCK)
	WHERE p.customer_name = @engg_customer_name
		AND p.project_name = @engg_project_name
		AND p.req_no = @engg_base_req_no
		AND p.process_name = @tmp_proc
		AND p.component_name = @tmp_comp
		AND p.activity_name = @tmp_act
		AND p.ui_name = @tmp_ui
		AND EXISTS (
			SELECT 'x'
			FROM ep_ui_control_dtl c(NOLOCK),
				es_comp_ctrl_type_mst_vw v(NOLOCK)
			WHERE p.customer_name = c.customer_name
				AND p.project_name = c.project_name
				AND p.process_name = c.process_name
				AND p.component_name = c.component_name
				AND p.activity_name = c.activity_name
				AND p.ui_name = c.ui_name
				AND p.page_bt_synonym = c.page_bt_synonym
				AND c.customer_name = v.customer_name
				AND c.project_name = v.project_name
				AND c.process_name = v.process_name
				AND c.component_name = v.component_name
				AND c.control_type = v.ctrl_type_name
				AND v.base_ctrl_type = 'RadioButton'
			)
	ORDER BY p.horder,
		p.vorder

	/*
	Fetch the min of sections define for the page ( Section combo - Radio Buttons tab )
	*/
	SELECT @engg_radio_sec_bts = min(s.section_bt_synonym)
	FROM ep_ui_section_dtl s(NOLOCK),
		ep_ui_control_dtl c(NOLOCK),
		es_comp_ctrl_type_mst_vw v(NOLOCK)
	WHERE s.customer_name = @engg_customer_name
		AND s.project_name = @engg_project_name
		AND s.req_no = @engg_base_req_no
		AND s.process_name = @tmp_proc
		AND s.component_name = @tmp_comp
		AND s.activity_name = @tmp_act
		AND s.ui_name = @tmp_ui
		AND s.page_bt_synonym = @engg_grid_page_bts
		AND s.customer_name = c.customer_name
		AND s.project_name = c.project_name
		AND s.process_name = c.process_name
		AND s.component_name = c.component_name
		AND s.activity_name = c.activity_name
		AND s.ui_name = c.ui_name
		AND s.page_bt_synonym = c.page_bt_synonym
		AND s.section_bt_synonym = c.section_bt_synonym
		AND c.customer_name = v.customer_name
		AND c.project_name = v.project_name
		AND c.process_name = v.process_name
		AND c.component_name = v.component_name
		AND c.control_type = v.ctrl_type_name
		AND v.base_ctrl_type = 'RadioButton'
		AND s.section_bt_synonym NOT IN (
			'PrjHdnSection',
			'[tabcontrol]',
			'hdnrt_stsection'
			) -- Code modified for PNR2.0_20554  on  07-Jan-2009
		AND s.section_type NOT IN (
			'Tree',
			'chart'
			)

	/*
	
	fetch the min of radio button controls for the section ( control combo - radio buttons tab )
	*/
	SELECT TOP 1 @engg_radio_btsynname = rtrim(a.control_bt_synonym)
	FROM ep_ui_control_dtl a(NOLOCK),
		es_comp_ctrl_type_mst_vw b(NOLOCK)
	WHERE a.customer_name = @engg_customer_name
		AND a.project_name = @engg_project_name
		AND a.req_no = @engg_base_req_no
		AND a.process_name = @tmp_proc
		AND a.component_name = @tmp_comp
		AND a.activity_name = @tmp_act
		AND a.ui_name = @tmp_ui
		AND a.page_bt_synonym = @engg_radio_page_bts
		AND a.section_bt_synonym = @engg_radio_sec_bts
		AND b.customer_name = a.customer_name
		AND b.project_name = a.project_name
		AND b.req_no = a.req_no
		AND b.process_name = a.process_name
		AND b.component_name = a.component_name
		AND a.control_type = b.ctrl_type_name
		AND b.base_ctrl_type = 'RadioButton'
	ORDER BY a.control_bt_synonym

	/*
	fetch the min of pages defined for the ui ( page combo - enumerated values tab )
	*/
	SELECT TOP 1 @engg_enum_page_bts = rtrim(p.page_bt_synonym)
	FROM ep_ui_page_dtl p(NOLOCK)
	WHERE p.customer_name = @engg_customer_name
		AND p.project_name = @engg_project_name
		AND p.req_no = @engg_base_req_no
		AND p.process_name = @tmp_proc
		AND p.component_name = @tmp_comp
		AND p.activity_name = @tmp_act
		AND p.ui_name = @tmp_ui
		AND p.page_bt_synonym IN (
			SELECT c.page_bt_synonym
			FROM ep_ui_control_dtl c(NOLOCK),
				es_comp_ctrl_type_mst_vw v(NOLOCK)
			WHERE p.customer_name = c.customer_name
				AND p.project_name = c.project_name
				AND p.process_name = c.process_name
				AND p.component_name = c.component_name
				AND p.activity_name = c.activity_name
				AND p.ui_name = c.ui_name
				AND p.page_bt_synonym = c.page_bt_synonym
				AND c.customer_name = v.customer_name
				AND c.project_name = v.project_name
				AND c.process_name = v.process_name
				AND c.component_name = v.component_name
				AND c.control_type = v.ctrl_type_name
				AND v.base_ctrl_type = 'Combo'
			-- code modified by shafina on 24-May-2004 for PREVIEWENG203SYS_000086
			-- In the Enumerated values TAB page the Section that contains combo controls is not loaded
			
			UNION
			
			SELECT c.page_bt_synonym
			FROM ep_ui_grid_dtl c(NOLOCK),
				es_comp_ctrl_type_mst_vw v(NOLOCK)
			WHERE p.customer_name = c.customer_name
				AND p.project_name = c.project_name
				AND p.process_name = c.process_name
				AND p.component_name = c.component_name
				AND p.activity_name = c.activity_name
				AND p.ui_name = c.ui_name
				AND p.page_bt_synonym = c.page_bt_synonym
				AND c.customer_name = v.customer_name
				AND c.project_name = v.project_name
				AND c.process_name = v.process_name
				AND c.component_name = v.component_name
				AND c.column_type = v.ctrl_type_name
				AND v.base_ctrl_type = 'Combo'
			)
	ORDER BY p.horder,
		p.vorder

	/*
	Fetch the min of sections define for the page ( section combo - enumerated values tab )
	*/
	SELECT @engg_enum_sec_bts = min(enum_sec)
	FROM (
		SELECT s.section_bt_synonym enum_sec
		FROM ep_ui_section_dtl s(NOLOCK),
			ep_ui_control_dtl c(NOLOCK),
			es_comp_ctrl_type_mst_vw v(NOLOCK)
		WHERE s.customer_name = @engg_customer_name
			AND s.project_name = @engg_project_name
			AND s.req_no = @engg_base_req_no
			AND s.process_name = @tmp_proc
			AND s.component_name = @tmp_comp
			AND s.activity_name = @tmp_act
			AND s.ui_name = @tmp_ui
			AND s.page_bt_synonym = rtrim(@engg_grid_page_bts)
			AND s.customer_name = c.customer_name
			AND s.project_name = c.project_name
			AND s.process_name = c.process_name
			AND s.component_name = c.component_name
			AND s.activity_name = c.activity_name
			AND s.ui_name = c.ui_name
			AND s.page_bt_synonym = c.page_bt_synonym
			AND s.section_bt_synonym = c.section_bt_synonym
			AND c.customer_name = v.customer_name
			AND c.project_name = v.project_name
			AND c.process_name = v.process_name
			AND c.component_name = v.component_name
			AND c.control_type = v.ctrl_type_name
			AND v.base_ctrl_type = 'Combo'
			-- modified by shafina on 30-jan-2004
			AND s.section_bt_synonym NOT IN (
				'PrjHdnSection',
				'[tabcontrol]',
				'hdnrt_stsection'
				) -- Code modified for PNR2.0_20554  on  07-Jan-2009
			--Modified For BugId : PNR2.0_6270
			AND s.section_type NOT IN (
				'Tree',
				'chart'
				) --gowri 09-Sep-2006
		
		UNION
		
		SELECT s.section_bt_synonym enum_sec
		FROM ep_ui_section_dtl s(NOLOCK),
			ep_ui_grid_dtl c(NOLOCK),
			es_comp_ctrl_type_mst_vw v(NOLOCK)
		WHERE s.customer_name = @engg_customer_name
			AND s.project_name = @engg_project_name
			AND s.req_no = @engg_base_req_no
			AND s.process_name = @tmp_proc
			AND s.component_name = @tmp_comp
			AND s.activity_name = @tmp_act
			AND s.ui_name = @tmp_ui
			AND s.page_bt_synonym = rtrim(@engg_grid_page_bts)
			AND s.customer_name = c.customer_name
			AND s.project_name = c.project_name
			AND s.process_name = c.process_name
			AND s.component_name = c.component_name
			AND s.activity_name = c.activity_name
			AND s.ui_name = c.ui_name
			AND s.page_bt_synonym = c.page_bt_synonym
			AND s.section_bt_synonym = c.section_bt_synonym
			AND c.customer_name = v.customer_name
			AND c.project_name = v.project_name
			AND c.process_name = v.process_name
			AND c.component_name = v.component_name
			AND c.column_type = v.ctrl_type_name
			AND v.base_ctrl_type = 'Combo'
			-- modified by shafina on 30-jan-2004
			AND s.section_bt_synonym NOT IN (
				'PrjHdnSection',
				'[tabcontrol]',
				'hdnrt_stsection'
				) -- Code modified for PNR2.0_20554  on  07-Jan-2009
			--Modified For BugId : PNR2.0_6270
			AND s.section_type NOT IN (
				'Tree',
				'chart'
				) --gowri 09-Sep-2006
		) c

	/*
	fetch all the enumerated combos controls of the sectiona and load them in the combo in
	alpahbetical order.
	*/
	SELECT @engg_enum_btsynname = min(enum_bts)
	FROM (
		SELECT rtrim(a.control_bt_synonym) enum_bts
		FROM ep_ui_control_dtl a(NOLOCK),
			es_comp_ctrl_type_mst_vw b(NOLOCK)
		WHERE a.customer_name = @engg_customer_name
			AND a.project_name = @engg_project_name
			AND a.req_no = @engg_base_req_no
			AND a.process_name = @tmp_proc
			AND a.component_name = @tmp_comp
			AND a.activity_name = @tmp_act
			AND a.ui_name = @tmp_ui
			AND a.page_bt_synonym = rtrim(@engg_enum_page_bts)
			AND a.section_bt_synonym = rtrim(@engg_enum_sec_bts)
			AND b.customer_name = a.customer_name
			AND b.project_name = a.project_name
			AND b.req_no = a.req_no
			AND b.process_name = a.process_name
			AND b.component_name = a.component_name
			AND a.control_type = b.ctrl_type_name
			AND b.base_ctrl_type = 'Combo'
		
		UNION
		
		SELECT rtrim(a.column_bt_synonym) enum_bts
		FROM ep_ui_grid_dtl a(NOLOCK),
			es_comp_ctrl_type_mst_vw b(NOLOCK)
		WHERE a.customer_name = @engg_customer_name
			AND a.project_name = @engg_project_name
			AND a.req_no = @engg_base_req_no
			AND a.process_name = @tmp_proc
			AND a.component_name = @tmp_comp
			AND a.activity_name = @tmp_act
			AND a.ui_name = @tmp_ui
			AND a.page_bt_synonym = rtrim(@engg_enum_page_bts)
			AND a.section_bt_synonym = rtrim(@engg_enum_sec_bts)
			AND b.customer_name = a.customer_name
			AND b.project_name = a.project_name
			AND b.req_no = a.req_no
			AND b.process_name = a.process_name
			AND b.component_name = a.component_name
			AND a.column_type = b.ctrl_type_name
			AND b.base_ctrl_type = 'Combo'
		) c

	-- Added for PLF2.0_14096 starts
	-- smarthide,isdevice,ilbotitle
	SELECT @smarthide = SmartHide,
		@isdevice = Is_device,
		@ilbotitle = HideIlbotitlemenu_req,
		@personalistion = personalization,
		@exclude_syst_tab_ind = Exclude_Systemtabindex,
		@enggphone = DeviceType,
		@enggtablet = DeviceType,
		@enggtabstyle = TabStyle,
		@isDesktop = IsDesktop,
		@engg_hide_print = Hide_Print,
		@engg_ui_layout = Layout,
		@engg_tab_hdr_pos = TabHeaderPostion,
		@engg_ui_laycon = CASE 
			WHEN Layout = 'abs'
				THEN isnull(XYCoordinates, '')
			WHEN Layout = 'col'
				THEN isnull(ColumnLayWidth, '')
			ELSE NULL
			END,
		@engg_hide_default = hide_imp_defaults,
		@engg_tab_rotate = TabRotation,
		@engg_nativeapp = NativeApplication,
		@engg_popup_close = Conditional_popupclose,
		@engg_titlebar_search	= Titlebar_Search,
		--Tech-70687
		@engg_lefttb			= Case when LeftToolbar		=	'Y' then 1 else 0 end,
		@engg_righttb			= Case when RightToolbar	=	'Y' then 1 else 0 end,
		@engg_toptb				= Case when TopToolbar		=	'Y' then 1 else 0 end,
		@engg_bottomtb			= Case when BottomToolbar	=	'Y' then 1 else 0 end,
		@engg_att_Sidebar		= Case when Sidebar			=	'Y' then 1 else 0 end,
		@engg_att_Docked		= Docked,		
		--Tech-70687
		@PullToRefresh			= Case when PullToRefresh	=	'Y' then 1 else 0 end	--Code added for TECH-75230
	FROM ep_ui_mst(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_base_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp)
		AND activity_name = rtrim(@tmp_act)
		AND ui_name = rtrim(@tmp_ui)

	-- Added for PLF2.0_14096 ends
	SELECT @enggtabstyle = parameter_text
	FROM ep_device_quick_code_met(NOLOCK)
	WHERE parameter_type = 'TabStyle'
		AND parameter_code = @enggtabstyle

	SELECT @engg_tab_hdr_pos = parameter_text
	FROM ep_device_quick_code_met(NOLOCK)
	WHERE parameter_type = 'HeaderPosition'
		AND parameter_code = @enggtabstyle

	SELECT @engg_tab_rotate = parameter_text
	FROM ep_device_quick_code_met(NOLOCK)
	WHERE parameter_type = 'TabRotation'
		AND parameter_code = @enggtabstyle

	---------Column Grouping Tabs Controls---------
	SELECT TOP 1 @engg_page_name = rtrim(p.page_bt_synonym)
	FROM ep_ui_page_dtl p(NOLOCK)
	WHERE p.customer_name = rtrim(@engg_customer_name)
		AND p.project_name = rtrim(@engg_project_name)
		AND p.process_name = rtrim(@tmp_proc)
		AND p.component_name = rtrim(@tmp_comp)
		AND p.activity_name = rtrim(@tmp_act)
		AND p.ui_name = rtrim(@tmp_ui)
		AND p.page_bt_synonym IN (
			SELECT c.page_bt_synonym
			FROM ep_ui_control_dtl c(NOLOCK),
				es_comp_ctrl_type_mst_vw v(NOLOCK)
			WHERE p.customer_name = c.customer_name
				AND p.project_name = c.project_name
				AND p.process_name = c.process_name
				AND p.component_name = c.component_name
				AND p.activity_name = c.activity_name
				AND p.ui_name = c.ui_name
				AND p.page_bt_synonym = c.page_bt_synonym
				AND c.customer_name = v.customer_name
				AND c.project_name = v.project_name
				AND c.process_name = v.process_name
				AND c.component_name = v.component_name
				AND c.control_type = v.ctrl_type_name
				AND v.base_ctrl_type = 'Grid'
				AND ISNULL(IsAssorted, 'N') = 'N'
			)
	ORDER BY p.horder,
		p.vorder

	SELECT TOP 1 @engg_sect_name = rtrim(s.section_bt_synonym),
				 @engg_cont_sec_type_bts	= rtrim(s.section_type)	--Code Added for TECH-71262
	FROM ep_ui_section_dtl s(NOLOCK),
		ep_ui_control_dtl c(NOLOCK),
		es_comp_ctrl_type_mst_vw v(NOLOCK)
	WHERE s.customer_name = rtrim(@engg_customer_name)
		AND s.project_name = rtrim(@engg_project_name)
		AND s.process_name = rtrim(@tmp_proc)
		AND s.component_name = rtrim(@tmp_comp)
		AND s.activity_name = rtrim(@tmp_act)
		AND s.ui_name = rtrim(@tmp_ui)
		AND s.page_bt_synonym = rtrim(@engg_page_name)
		AND s.customer_name = c.customer_name
		AND s.project_name = c.project_name
		AND s.process_name = c.process_name
		AND s.component_name = c.component_name
		AND s.activity_name = c.activity_name
		AND s.ui_name = c.ui_name
		AND s.page_bt_synonym = c.page_bt_synonym
		AND s.section_bt_synonym = c.section_bt_synonym
		AND c.customer_name = v.customer_name
		AND c.project_name = v.project_name
		AND c.process_name = v.process_name
		AND c.component_name = v.component_name
		AND c.control_type = v.ctrl_type_name
		AND v.base_ctrl_type = 'Grid'
		AND s.section_bt_synonym NOT IN (
			'PrjHdnSection',
			'[tabcontrol]',
			'hdnrt_stsection'
			)
		AND s.section_type NOT IN (
			'Tree',
			'chart',
			'Tree Grid'
			)
		AND ISNULL(IsAssorted, 'N') = 'N'
	ORDER BY 1

	SELECT TOP 1 @engg_control_name = rtrim(a.control_bt_synonym)
	FROM ep_ui_control_dtl a(NOLOCK),
		es_comp_ctrl_type_mst_vw b(NOLOCK)
	WHERE a.customer_name = rtrim(@engg_customer_name)
		AND a.project_name = rtrim(@engg_project_name)
		AND a.process_name = rtrim(@tmp_proc)
		AND a.component_name = rtrim(@tmp_comp)
		AND a.activity_name = rtrim(@tmp_act)
		AND a.ui_name = rtrim(@tmp_ui)
		AND a.page_bt_synonym = rtrim(@engg_page_name)
		AND a.section_bt_synonym = rtrim(@engg_sect_name)
		AND b.customer_name = a.customer_name
		AND b.project_name = a.project_name
		AND b.process_name = a.process_name
		AND b.component_name = a.component_name
		AND a.control_type = b.ctrl_type_name
		AND b.base_ctrl_type = 'Grid'
		AND ISNULL(IsAssorted, 'N') = 'N'
	ORDER BY 1

	SELECT TOP 1 @engg_group_name = rtrim(Group_name),
		@engg_group_caption = RTRIM(Group_caption)
	FROM ep_ui_columngroup(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp)
		AND activity_name = rtrim(@tmp_act)
		AND ui_name = rtrim(@tmp_ui)
		AND page_bt_synonym = rtrim(@engg_page_name)
		AND section_bt_synonym = rtrim(@engg_sect_name)
		AND grid_control_bt_synonym = RTRIM(@engg_control_name)
	ORDER BY 1

	SELECT NULL 'enggad_fprowno',
		NULL 'enggpa_fprowno',
		@engg_act_descr 'engg_act_descr',
		@engg_component 'engg_component',
		@engg_att_ui_cap_align 'engg_att_ui_cap_align',
		@engg_att_ui_format 'engg_att_ui_format',
		@engg_att_ui_grid_type 'engg_att_ui_grid_type',
		@engg_att_ui_trail_bar 'engg_att_ui_trail_bar',
		@engg_att_ui_type 'engg_att_ui_type',
		@engg_cont_page_bts 'engg_cont_page_bts',
		@engg_cont_sec_bts 'engg_cont_sec_bts',
		@engg_customer_name 'engg_customer_name',
		NULL 'engg_c_fprowno',
		@engg_enum_btsynname 'engg_enum_btsynname',
		@engg_cont_page_bts 'engg_enum_page_bts',
		@engg_enum_sec_bts 'engg_enum_sec_bts',
		@engg_grid_grid_code 'engg_grid_grid_code',
		@engg_grid_page_bts 'engg_grid_page_bts',
		@engg_grid_sec_bts 'engg_grid_sec_bts',
		@engg_lay_page_bts 'engg_lay_page_bts',
		@engg_lnk_page_descr 'engg_lnk_page_descr',
		NULL 'engg_l_fprowno',
		NULL 'engg_m_fprowno',
		@engg_process_descr 'engg_process_descr',
		@engg_project_name 'engg_project_name',
		@engg_radio_btsynname 'engg_radio_btsynname',
		@engg_radio_page_bts 'engg_radio_page_bts',
		@engg_radio_sec_bts 'engg_radio_sec_bts',
		@engg_req_no 'engg_req_no',
		@engg_rf_act 'engg_rf_act',
		@engg_rf_comp 'engg_rf_comp',
		@engg_rf_ui 'engg_rf_ui',
		NULL 'engg_r_fprowno',
		@engg_sec_page_bts 'engg_sec_page_bts',
		@engg_tab_height 'engg_tab_height',
		@engg_ui_descr 'engg_ui_descr',
		NULL 'engg_y_fprowno',
		@State_Processing 'state_processing',
		@engg_callout_type 'engg_callout_type',
		@eZee_Taskpane 'eZee_Taskpane', -- added for Bug id: PNR2.0_30127
		CASE 
			WHEN @engg_nativeapp = 'y'
				THEN 1
			ELSE 0
			END 'engg_nativeapp',
		CASE 
			WHEN @engg_popup_close = 'y'
				THEN 1
			ELSE 0
			END 'engg_popup_close',
		-- Added for PLF2.0_14096 starts
		CASE 
			WHEN @smarthide = 'y'
				THEN 1
			ELSE 0
			END 'engg_smarthide',
		CASE 
			WHEN @isdevice = 'y'
				THEN 1
			ELSE 0
			END 'engg_isdevice',
		CASE 
			WHEN @ilbotitle = 'y'
				THEN 1
			ELSE 0
			END 'engg_ilbotitle',
		CASE 
			WHEN @personalistion = 'y'
				THEN 1
			ELSE 0
			END 'engg_hdrpersonalisation',
		CASE 
			WHEN @exclude_syst_tab_ind = 'y'
				THEN 1
			ELSE 0
			END 'engg_syst_excl_tab_ind', --Changes for PLF2.0_16291
		-- Added for PLF2.0_14096 ends	
		NULL '_sec_fprowno',
		CASE 
			WHEN @isDesktop = 'y'
				THEN 1
			ELSE 0
			END 'engg_desk_brw', --- PLF2.0_17570
		CASE 
			WHEN @enggphone IN (
					'P',
					'B'
					)
				THEN 1
			ELSE 0
			END 'engg_phone',
		CASE 
			WHEN @enggtablet IN (
					'T',
					'B'
					)
				THEN 1
			ELSE 0
			END 'engg_tablet',
		CASE 
			WHEN @engg_titlebar_search = 'y' THEN 1
			ELSE 0
			END 'engg_titlebar_search', 
		isnull(@enggtabstyle, '') 'engg_tab_style',
		isnull(@engg_tab_hdr_pos, '') 'engg_tab_hdr_pos',
		isnull(@engg_tab_rotate, '') 'engg_tab_rotate',
		isnull(@engg_hide_print, '') 'engg_hide_print',
		isnull(@engg_ui_layout, '') 'engg_ui_layout',
		isnull(@engg_ui_laycon, '') 'engg_ui_laycon',
		isnull(@engg_tab_rotate, '') 'engg_tab_rotate',
		isnull(@engg_page_name, '') 'engg_page_name',
		isnull(@engg_sect_name, '') 'engg_sect_name',
		isnull(@engg_group_name, '') 'engg_group_name',
		isnull(@engg_group_caption, '') 'engg_group_caption',
		isnull(@engg_control_name, '') 'engg_control_name',
		@engg_uisubtype 'engg_uisubtype',
		@engg_lefttb		'engg_lefttb'	,		
		@engg_righttb		'engg_righttb',		
		@engg_toptb			'engg_toptb'	,		
		@engg_bottomtb		'engg_bottomtb'	,	
		@engg_att_sidebar	'engg_att_sidebar'	,
		isnull(@engg_att_docked,'')	'engg_att_docked',
		--Code Added for TECH-71262 starts
		isnull(@engg_cont_sec_type_bts,'')	'engg_cont_sec_type_bts',
		isnull(@engg_grid_sec_type_bts,'')	'engg_grid_sec_type_bts',	
		isnull(@engg_grid_ctrl_type_bts,'')	'engg_grid_ctrl_type_bts',
		--Code Added for TECH-71262 ends
		@PullToRefresh		'PullToRefresh'		--Code added for TECH-75230	
	
	/* 
	--OutputList
		Select
		null 'enggad_fprowno', 
		null 'enggpa_fprowno', 
		null 'engg_act_descr', 
		null 'engg_att_ui_cap_align', 
		null 'engg_att_ui_format', 
		null 'engg_att_ui_grid_type', 
		null 'engg_att_ui_trail_bar', 
		null 'engg_att_ui_type', 
		null 'engg_component', 
		null 'engg_cont_page_bts', 
		null 'engg_cont_sec_bts', 
		null 'engg_customer_name', 
		null 'engg_c_fprowno', 
		null 'engg_enum_btsynname', 
		null 'engg_enum_page_bts', 
		null 'engg_enum_sec_bts', 
		null 'engg_grid_grid_code', 
		null 'engg_grid_page_bts', 
		null 'engg_grid_sec_bts', 
		null 'engg_lay_page_bts', 
		null 'engg_lnk_page_descr', 
		null 'engg_l_fprowno', 
		null 'engg_m_fprowno', 
		null 'engg_process_descr', 
		null 'engg_project_name', 
		null 'engg_radio_btsynname', 
		null 'engg_radio_page_bts', 
		null 'engg_radio_sec_bts', 
		null 'engg_req_no', 
		null 'engg_rf_act', 
		null 'engg_rf_comp', 
		null 'engg_rf_ui', 
		null 'engg_r_fprowno', 
		null 'engg_sec_page_bts', 
		null 'engg_tab_height', 
		null 'engg_ui_descr', 
		null 'engg_y_fprowno', 
		null 'state_processing', 
		null '_sec_fprowno', 
	*/
	SET NOCOUNT OFF
END

GO
IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME= 'ep_maireeSpep_layHdrRef' AND TYPE='P')
BEGIN
	GRANT EXEC ON  ep_maireeSpep_layHdrRef TO PUBLIC
END
GO