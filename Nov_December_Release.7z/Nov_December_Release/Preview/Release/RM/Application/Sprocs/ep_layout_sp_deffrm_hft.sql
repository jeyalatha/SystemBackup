IF EXISTS(SELECT 'X' From SYSOBJECTS WHERE NAME ='ep_layout_sp_deffrm_hft' AND TYPE='P')
   BEGIN
        DROP PROC ep_layout_sp_deffrm_hft
   END
GO 
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		ep_layout_sp_deffrm_hft.sql
********************************************************************************/
/*      V E R S I O N      :  PNR2.0_1403    */
/*      Released By        :  Development Team    */
/*      Release Comments   :  For DotNet Migration, Naming convention has been changed  for some of the out parameters by using Stub Generator.Comments will not be there for this Request ID.    */
/*      V E R S I O N      :  2.0.2    */
/*      Released By        :  PTech    */
/*      Release Comments   :  Released on  22-Jan-2004    */
/****** Object:  Stored Procedure dbo.ep_layout_sp_deffrm_hft    Script Date: 11/6/03 5:20:43 PM ******/
/********************************************************************************/
/* procedure      ep_layout_sp_deffrm_hft                                       */
/* description    sp to default ui format attribute values from reference ui in main page*/
/********************************************************************************/
/* project        preview                                                       */
/* version                                                                      */
/********************************************************************************/
/* referenced                                                                   */
/* tables                                                                       */
/********************************************************************************/
/* development history                                                          */
/********************************************************************************/
/* author         B.Shafina Begum                                               */
/* date           23/ 10/ 2003                                                  */
/********************************************************************************/
/* modification history                                                         */
/********************************************************************************/
/* modified by  : B.Shafina Begum                                               */
/* date         : 04-feb-2004	                                                */
/* description  : To check for ui's req_status								    */
/* modified by  : Sangeetha L           	                                    */
/* date         : 03-Mar-2005	                                                */
/* bugid		:PREVIEWENG203SYS_000215										*/
/* bug desc		:Cannot insert the value NULL into column 'tab_height',         */
/*               table 'rvw20appdb.dbo.ep_ui_mst'; column does not allow nulls. */
/*				 UPDATE fails. 												    */
/* modified by  : ARUNN			           	                                    */
/* date         : 29-Jun-2005	                                                */
/* bugid		: PNR2.0_3088													*/
/* bug desc		: On Clicking 'Default from reference UI', getting an error message */
/*				  Cannot insert the value NULL into column 'tab_height',        */
/*                table 'rvw20appdb.dbo.ep_ui_mst'; column does not allow nulls.*/
/*				  UPDATE fails. 												*/
/********************************************************************************/
/* Modified by : Feroz		 													*/
/* Modified on : 08/11/06	 													*/
/* Description : State Processing 												*/
/********************************************************************************/
/* modified by			: Jeya											*/
/* date					: 25-nov-2008									*/
/* BugId				: PNR2.0_1790 									*/
/****************************************************************************/
/* modified by		: Jeyalatha K 											*/
/* date				: 11-Feb-2011                                           */
/* Bug Id			: PNR2.0_30127											*/
/* Modified for		: Feature  Release										*/
/****************************************************************************/
/* Modified by  : Kalidas S	                                                  */
/* Date : 03-Aug-2015                                                  */
/* Defect ID	: PLF2.0_14096                                                 */
/********************************************************************************/
/* Modified by  : Veena U	                                                  */
/* Date         : 24-Dec-2015*/
/* Defect ID	: PLF2.0_16153                                                 */
/********************************************************************************/
/* Modified by  : Veena U                                                  */
/* Date         : 24-Feb-2016                                                 */
/* Defect ID	: PLF2.0_16291                                                */
/********************************************************************************/
/* Modified by : Jeya Latha K/Ganesh Prabhu S	for callid TECH-7349				*/
/* Modified on : 14-03-2017				 											*/
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and New Feature Organization chart */
/***********************************************************************************/
/***********************************************************************************************/
/* Modified by : Ganesh Prabhu S/Ranjitha R		  Date: 30-May-2017	    Defect ID: TECH-10118  */
/* Modified by : Jeya Latha K					  Date: 25-Jul-2019     Defect ID: TECH-36371  */
/* Modified by : Priyadharshini U/Rajeswari M	  Date: 29-Jan-2020  Defect ID : TECH-42483	   */
/***********************************************************************************************/
/* Modified by	:	Priyadharshini U 														   */
/* Modified on	:	08/07/2022				 												   */
/* Defect ID	:	Tech-70687																   */
/* Description	:	Tool and Toolbars														   */
/***********************************************************************************************/
/* Modified by : Ponmalar A		  Date: 29-Aug-2022	    Defect ID: TECH-72114				   */
/***********************************************************************************************/
/* Modified by    :    Ponmalar A                                               */
/* Modified on    :    02/12/22													*/
/* Defect ID      :    TECH-75230												*/
/* Description    : Platform Release for the Month of Nov'22				    */
/********************************************************************************/
CREATE PROCEDURE ep_layout_sp_deffrm_hft
	@ctxt_language_in engg_ctxt_language,
	@ctxt_ouinstance_in engg_ctxt_ouinstance,
	@ctxt_service_in engg_ctxt_service,
	@ctxt_user_in engg_ctxt_user,
	@engg_act_descr_io engg_description,
	@engg_att_ui_cap_align_io engg_name,
	@engg_att_ui_format_io engg_description,
	@engg_att_ui_trail_bar_io engg_name,
	@engg_att_ui_type_io engg_name,
	@engg_component_io engg_description,
	@engg_customer_name_io engg_name,
	@engg_process_descr_io engg_description,
	@engg_project_name_io engg_name,
	@engg_req_no_io engg_name,
	@engg_rf_act_io engg_description,
	@engg_rf_comp_io engg_description,
	@engg_rf_ui_io engg_description,
	@engg_tab_height_io engg_length,
	@engg_ui_descr_io engg_description,
	@guid_io engg_guid,
	@engg_att_ui_Grid_Type engg_type,
	@State_Processing engg_name,
	@engg_callout_type engg_type, -- Modfied for the request PNR2.0_1790
	@ezee_taskpane engg_name, -- Added for the Bug ID:PNR2.0_30127
	@engg_isdevice engg_flag, --Input/Output
	@engg_smarthide engg_flag, --Input/Output
	@engg_ilbotitle engg_flag, --Input/Output
	@engg_hdrpersonalisation engg_flag,
	@engg_syst_excl_tab_ind engg_flag,
	@engg_hide_default engg_flag,
	@engg_uisubtype engg_name, --Input/Output
	@engg_nativeapp engg_flag,
	@engg_popup_close engg_flag,
	@engg_titlebar_search	engg_flag,
	--Tech-70687
	@engg_toptb			engg_seqno,
	@engg_bottomtb		engg_seqno,
	@engg_lefttb		engg_seqno,
	@engg_righttb		engg_seqno,
	@engg_att_sidebar	engg_seqno,
	@engg_att_docked	engg_name,
	--Tech-70687
	@PullToRefresh		engg_seqno,	--Code added for TECH-75230
	@m_errorid INT OUTPUT
AS
BEGIN
	SET NOCOUNT ON

	--declaration of temporary variables
	DECLARE @ctxt_language engg_ctxt_language
	DECLARE @ctxt_ouinstance engg_ctxt_ouinstance
	DECLARE @ctxt_service engg_ctxt_service
	DECLARE @ctxt_user engg_ctxt_user
	DECLARE @engg_act_descr engg_description
	DECLARE @engg_att_ui_cap_align engg_name
	DECLARE @engg_att_ui_format engg_description
	DECLARE @engg_att_ui_trail_bar engg_name
	DECLARE @engg_att_ui_type engg_name
	DECLARE @engg_component engg_description
	DECLARE @engg_customer_name engg_name
	DECLARE @engg_process_descr engg_description
	DECLARE @engg_project_name engg_name
	DECLARE @engg_req_no engg_name
	DECLARE @engg_rf_act engg_description
	DECLARE @engg_rf_comp engg_description
	DECLARE @engg_rf_ui engg_description
	DECLARE @engg_tab_height engg_length
	DECLARE @engg_ui_descr engg_description
	DECLARE @guid engg_guid

	--temporary and formal parameters mapping
	SELECT @ctxt_language = @ctxt_language_in

	SELECT @ctxt_ouinstance = @ctxt_ouinstance_in

	SELECT @ctxt_service = ltrim(rtrim(@ctxt_service_in))

	SELECT @ctxt_user = ltrim(rtrim(@ctxt_user_in))

	SELECT @engg_act_descr = ltrim(rtrim(@engg_act_descr_io))

	SELECT @engg_att_ui_cap_align = ltrim(rtrim(@engg_att_ui_cap_align_io))

	SELECT @engg_att_ui_format = ltrim(rtrim(@engg_att_ui_format_io))

	SELECT @engg_att_ui_trail_bar = ltrim(rtrim(@engg_att_ui_trail_bar_io))

	SELECT @engg_att_ui_type = ltrim(rtrim(@engg_att_ui_type_io))

	SELECT @engg_component = ltrim(rtrim(@engg_component_io))

	SELECT @engg_customer_name = ltrim(rtrim(@engg_customer_name_io))

	SELECT @engg_process_descr = ltrim(rtrim(@engg_process_descr_io))

	SELECT @engg_project_name = ltrim(rtrim(@engg_project_name_io))

	SELECT @engg_req_no = ltrim(rtrim(@engg_req_no_io))

	SELECT @engg_rf_act = ltrim(rtrim(@engg_rf_act_io))

	SELECT @engg_rf_comp = ltrim(rtrim(@engg_rf_comp_io))

	SELECT @engg_rf_ui = ltrim(rtrim(@engg_rf_ui_io))

	SELECT @engg_tab_height = @engg_tab_height_io

	SELECT @engg_ui_descr = ltrim(rtrim(@engg_ui_descr_io))

	SELECT @guid = ltrim(rtrim(@guid_io))

	SELECT @engg_att_ui_Grid_Type = ltrim(rtrim(@engg_att_ui_Grid_Type))

	SELECT @State_Processing = ltrim(rtrim(@State_Processing))

	SELECT @engg_callout_type = ltrim(rtrim(@engg_callout_type)) -- Modfied for the request PNR2.0_1790

	SELECT @ezee_taskpane = ltrim(rtrim(@ezee_taskpane)) -- Added for the Bug ID:PNR2.0_30127

	SELECT @engg_isdevice = ltrim(rtrim(@engg_isdevice))

	SELECT @engg_smarthide = ltrim(rtrim(@engg_smarthide))

	SELECT @engg_ilbotitle = ltrim(rtrim(@engg_ilbotitle))

	SELECT @engg_hdrpersonalisation = ltrim(rtrim(@engg_hdrpersonalisation))

	SELECT @engg_syst_excl_tab_ind = ltrim(rtrim(@engg_syst_excl_tab_ind))

	SELECT @engg_hide_default = LTRIM(rtrim(@engg_hide_default))

	SELECT @engg_uisubtype = ltrim(rtrim(@engg_uisubtype))

	SELECT @engg_nativeapp = LTRIM(rtrim(@engg_nativeapp))

	SELECT @engg_popup_close = LTRIM(rtrim(@engg_popup_close))

	SELECT @engg_att_docked = LTRIM(rtrim(@engg_att_docked))	--Tech-70687
	
	--null checking
	IF @ctxt_language = - 915
		SELECT @ctxt_language = NULL

	IF @ctxt_ouinstance = - 915
		SELECT @ctxt_ouinstance = NULL

	IF @ctxt_service = '~#~'
		SELECT @ctxt_service = NULL

	IF @ctxt_user = '~#~'
		SELECT @ctxt_user = NULL

	IF @engg_act_descr = '~#~'
		SELECT @engg_act_descr = NULL

	IF @engg_att_ui_cap_align = '~#~'
		SELECT @engg_att_ui_cap_align = NULL

	IF @engg_att_ui_format = '~#~'
		SELECT @engg_att_ui_format = NULL

	IF @engg_att_ui_trail_bar = '~#~'
		SELECT @engg_att_ui_trail_bar = NULL

	IF @engg_att_ui_type = '~#~'
		SELECT @engg_att_ui_type = NULL

	IF @engg_component = '~#~'
		SELECT @engg_component = NULL

	IF @engg_customer_name = '~#~'
		SELECT @engg_customer_name = NULL

	IF @engg_process_descr = '~#~'
		SELECT @engg_process_descr = NULL

	IF @engg_project_name = '~#~'
		SELECT @engg_project_name = NULL

	IF @engg_req_no = '~#~'
		SELECT @engg_req_no = NULL

	IF @engg_rf_act = '~#~'
		SELECT @engg_rf_act = NULL

	IF @engg_rf_comp = '~#~'
		SELECT @engg_rf_comp = NULL

	IF @engg_rf_ui = '~#~'
		SELECT @engg_rf_ui = NULL

	IF @engg_tab_height = - 915
		SELECT @engg_tab_height = NULL

	IF @engg_ui_descr = '~#~'
		SELECT @engg_ui_descr = NULL

	IF @guid = '~#~'
		SELECT @guid = NULL

	IF @engg_att_ui_Grid_Type = '~#~'
		SELECT @engg_att_ui_Grid_Type = NULL

	IF @State_Processing = '~#~'
		SELECT @State_Processing = NULL

	-- Modfied for the request PNR2.0_1790
	IF @engg_callout_type = '~#~'
		SELECT @engg_callout_type = NULL

	-- Added for the Bug ID:PNR2.0_30127
	IF @ezee_taskpane = '~#~'
		SELECT @ezee_taskpane = NULL

	IF @engg_isdevice = '~#~'
		SELECT @engg_isdevice = NULL

	IF @engg_smarthide = '~#~'
		SELECT @engg_smarthide = NULL

	IF @engg_ilbotitle = '~#~'
		SELECT @engg_ilbotitle = NULL

	IF @engg_hdrpersonalisation = '~#~'
		SELECT @engg_hdrpersonalisation = NULL

	IF @engg_syst_excl_tab_ind = '~#~'
		SELECT @engg_syst_excl_tab_ind = NULL

	IF @engg_hide_default = - 915
		SELECT @engg_hide_default = NULL

	IF @engg_nativeapp = '~#~'
		SELECT @engg_nativeapp = NULL

	IF @engg_popup_close = '~#~'
		SELECT @engg_popup_close = NULL

	--Tech-70687
	IF @engg_toptb = - 915
		SELECT @engg_toptb = NULL

	IF @engg_bottomtb = - 915
		SELECT @engg_bottomtb = NULL

	IF @engg_lefttb = - 915
		SELECT @engg_lefttb = NULL

	IF @engg_righttb = - 915
		SELECT @engg_righttb = NULL

	IF @engg_att_sidebar = - 915
		SELECT @engg_att_sidebar = NULL
		
	IF @engg_att_docked = '~#~'
		SELECT @engg_att_docked = NULL		
	--Tech-70687

	IF @PullToRefresh = - 915		--Code added for TECH-75230
		SELECT @PullToRefresh = NULL
	
	--errors mapped
	DECLARE @msg engg_description,
		@tmp_comp_name engg_name,
		@tmp_proc engg_name,
		@tmp_acty_name engg_name,
		@tmp_ui_name engg_name,
		@tmp_ref_comp_name engg_name,
		@tmp_ref_acty_name engg_name,
		@tmp_ref_ui_name engg_name,
		@tmp_cap_align engg_name,
		@tmp_ui_format engg_name,
		@tmp_trail_bar engg_name,
		@tmp_ui_type engg_name,
		@tmp_tab_height INT,
		@engg_base_req_no engg_name,
		@ui_type engg_name,
		@tmp_grid_type engg_type,
		@tmp_state_processing engg_name,
		@tmp_callout_type engg_type,
		@tmp_ui_subtype engg_name
	--	@engg_titlebar_search	engg_flag	--13639

	SELECT @engg_base_req_no = 'BASE'

	--select ui name for description
	SELECT @tmp_comp_name = rtrim(component_name),
		@tmp_proc = rtrim(process_name),
		@tmp_acty_name = rtrim(activity_name),
		@tmp_ui_name = rtrim(ui_name)
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_req_no)
		AND process_descr = rtrim(@engg_process_descr)
		AND component_descr = rtrim(@engg_component)
		AND activity_descr = rtrim(@engg_act_descr)
		AND ui_descr = rtrim(@engg_ui_descr)

	IF EXISTS (
			SELECT 'x'
			FROM ep_ui_req_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @engg_req_no
				AND process_name = @tmp_proc
				AND component_name = @tmp_comp_name
				AND activity_name = @tmp_acty_name
				AND ui_name = @tmp_ui_name
				AND req_status = 'P'
			)
	BEGIN
		SELECT @msg = 'Cannot default as Selected UI is in published status'

		EXEC engg_error_sp 'ep_layout_sp_deffrm_hft',
			1,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		IF @m_errorid <> 0
			RETURN
	END

	/*check whether activity is selected. if not display error message*/
	IF @engg_act_descr IS NULL
	BEGIN
		SELECT @msg = 'select activity'

		EXEC engg_error_sp 'ep_layout_sp_deffrm_hft',
			1,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		RETURN
	END

	/*check whether ui is selected. if not display error message*/
	IF @engg_ui_descr IS NULL
	BEGIN
		SELECT @msg = 'select user interface'

		EXEC engg_error_sp 'ep_layout_sp_deffrm_hft',
			2,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		RETURN
	END

	/*for the selected activity/ui combination check whether refernce ui has been defined. 
	if not, display error message*/
	IF @engg_rf_ui IS NULL
	BEGIN
		SELECT @msg = 'reference ui does not exist for the selected ui.'

		EXEC engg_error_sp 'ep_layout_sp_deffrm_hft',
			3,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		RETURN
	END

	/*check project level parameter uniformuiformat type uiformat. 
	if the parameter is set as "do not allow modifications", display error message*/
	-- 	if exists	(
	-- 				select 	'x'
	-- 				from	es_comp_param_mst_vw(nolock)
	-- --				from	ep_proj_param_mst(nolock)
	-- 				where	customer_name			= @engg_customer_name
	-- 				and		project_name			= @engg_project_name
	-- 				and		req_no					= @engg_base_req_no
	-- 				and		process_name			= @tmp_comp_name
	-- 				and		component_name			= @tmp_proc
	-- 				and		upper(param_category)	= 'UNIFORMUIFORMAT'
	-- 				and		upper(param_type)		= 'UIFORMAT'
	-- 				and		upper(current_value)	= 'DO NOT ALLOW MODIFICATIONS'
	-- 				)
	-- 	begin
	-- 		select 	@msg = 'ui format cannot be modified at ui level.'
	-- 		exec	engg_error_sp	'ep_layout_sp_deffrm_hft',
	-- 								4,
	-- 								@msg,
	-- 								@ctxt_language,
	-- 								@ctxt_ouinstance,
	-- 								@ctxt_service,
	-- 								@ctxt_user,
	-- 								'',
	-- 								'',
	-- 								'',
	-- 								'',
	-- 								@m_errorid		output
	-- 		return
	-- 	end	
	/*check component level parameter captionformat type uiformat. 
	if the parameter is not set as "decide at ui level" display error message*/
	-- 	if  not exists	(
	-- 				select 	'x' 
	-- 				from	es_comp_param_mst_vw(nolock)
	-- 				where	customer_name	= @engg_customer_name
	-- 				and		project_name	= @engg_project_name
	-- 				and		req_no			= @engg_req_no
	-- 				and		component_name	= @tmp_comp_name
	-- 				and		process_name	= @tmp_proc
	-- 				and		upper(param_category)	= 'CAPTIONFORMAT'
	-- 				and		upper(param_type)		= 'UIFORMAT'
	-- 				and		upper(current_value)	= 'DECIDE AT UI LEVEL'
	-- 				)
	-- 	begin
	-- 		select 	@msg = 'caption format cannot be modified at ui level.'
	-- 		exec	engg_error_sp	'ep_layout_sp_deffrm_hft',
	-- 								5,
	-- 								@msg,
	-- 								@ctxt_language,
	-- 								@ctxt_ouinstance,
	-- 								@ctxt_service,
	-- 								@ctxt_user,
	-- 								'',
	-- 								'',
	-- 								'',
	-- 								'',
	-- 								@m_errorid		output
	-- 		return
	-- 	end	
	/*check component level parameter captionalign type uiformat. 
	if the parameter is not set as "decide at ui level" display error message*/
	-- 	if not exists	(
	-- 				select 	'x' 
	-- 				from	es_comp_param_mst_vw(nolock)
	-- 				where	customer_name	= @engg_customer_name
	-- 				and		project_name	= @engg_project_name
	-- 				and		req_no			= @engg_req_no
	-- 				and		component_name	= @tmp_comp_name
	-- 				and		process_name	= @tmp_proc
	-- 				and		upper(param_category)	= 'CAPTIONALIGN'
	-- 				and		upper(param_type)		= 'UIFORMAT'
	-- 				and		upper(current_value)	= 'DECIDE AT UI LEVEL'
	-- 				)
	-- 	begin
	-- 		select 	@msg = 'caption alignment cannot be modified at ui level.'
	-- 		exec	engg_error_sp	'ep_layout_sp_deffrm_hft',
	-- 								6,
	-- 								@msg,
	-- 								@ctxt_language,
	-- 								@ctxt_ouinstance,
	-- 								@ctxt_service,
	-- 								@ctxt_user,
	-- 								'',
	-- 								'',
	-- 								'',
	-- 								'',
	-- 								@m_errorid		output
	-- 		return
	-- 	end	
	/*check component level parameter trailbar type uiformat. 
	if the parameter is not set as "decide at ui level" display error message*/
	-- 		if not exists	(
	-- 				select 	'x' 
	-- 				from	es_comp_param_mst_vw(nolock)
	-- 				where	customer_name	= @engg_customer_name
	-- 				and		project_name	= @engg_project_name
	-- 				and		req_no			= @engg_req_no
	-- 				and		component_name	= @tmp_comp_name
	-- 				and		process_name	= @tmp_proc
	-- 				and		upper(param_category)	= 'TRAILBAR'
	-- 				and		upper(param_type)		= 'UIFORMAT'
	-- 				and		upper(current_value)	= 'DECIDE AT UI LEVEL'
	-- 				)
	-- 	begin
	-- 		select 	@msg = 'trailbar option cannot be modified at ui level.'
	-- 		exec	engg_error_sp	'ep_layout_sp_deffrm_hft',
	-- 								7,
	-- 								@msg,
	-- 								@ctxt_language,
	-- 								@ctxt_ouinstance,
	-- 								@ctxt_service,
	-- 								@ctxt_user,
	-- 								'',
	-- 								'',
	-- 								'',
	-- 								'',
	-- 								@m_errorid		output
	-- 		return
	-- 	end
	/*fetch the component name for the ref component*/
	-- code modified by Sangeetha L on 3 mar 2005
	-- bugid:PREVIEWENG203SYS_000215
	-- bug desc:Cannot insert the value NULL into column 'tab_height',
	--          table 'rvw20appdb.dbo.ep_ui_mst'; column does not allow nulls. UPDATE fails. 
	SELECT @tmp_ref_comp_name = rtrim(component_name)
	-- 	from 	ep_ui_req_dtl (nolock)			
	FROM Fw_BPT_RE_NameDesc_Vw(NOLOCK) -- Modified By Arunn for pnr2.0_3088
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		-- 	and		req_no				= rtrim(@engg_base_req_no)
		-- 	and		process_name		= rtrim(@tmp_proc)
		AND component_descr = rtrim(@engg_rf_comp)

	/*fetch the acty name for the ref acty*/
	SELECT @tmp_ref_acty_name = rtrim(activity_name)
	-- 	from 	ep_ui_req_dtl (nolock)
	FROM Fw_BPT_RE_NameDesc_Vw(NOLOCK) -- pnr2.0_3088
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		-- 	and		req_no				= rtrim(@engg_base_req_no)
		-- 	and		process_name		= rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_ref_comp_name)
		AND activity_descr = rtrim(@engg_rf_act)

	/*fetch the ui name for the ref ui*/
	SELECT @tmp_ref_ui_name = rtrim(ui_name)
	-- 	from 	ep_ui_req_dtl (nolock)
	FROM Fw_BPT_RE_NameDesc_Vw(NOLOCK) -- pnr2.0_3088
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		-- 	and		req_no				= rtrim(@engg_base_req_no)
		-- 	and		process_name		= rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_ref_comp_name)
		AND activity_name = rtrim(@tmp_ref_acty_name)
		AND ui_descr = rtrim(@engg_rf_ui)

	/*fetch caption_alignment for the UI*/
	SELECT @tmp_cap_align = rtrim(caption_alignment)
	FROM ep_ui_mst a(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_base_req_no)
		-- 	and		process_name		= rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_ref_comp_name)
		AND activity_name = rtrim(@tmp_ref_acty_name)
		AND ui_name = rtrim(@tmp_ref_ui_name)

	/*fetch ui_format for the UI*/
	SELECT @tmp_ui_format = rtrim(ui_format)
	FROM ep_ui_mst a(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_base_req_no)
		-- 	and		process_name		= rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_ref_comp_name)
		AND activity_name = rtrim(@tmp_ref_acty_name)
		AND ui_name = rtrim(@tmp_ref_ui_name)

	/*fetch trail_bar for the UI*/
	SELECT @tmp_trail_bar = rtrim(trail_bar)
	FROM ep_ui_mst a(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_base_req_no)
		-- 	and		process_name		= rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_ref_comp_name)
		AND activity_name = rtrim(@tmp_ref_acty_name)
		AND ui_name = rtrim(@tmp_ref_ui_name)

	-- code modified by shafina on 14-June-2004 for PREVIEWENG203ACC_000075
	-- when default from reference ui is clicked in ui format tab , the following error is thrown : Cannot insert the value NULL into column 'ui_type', table 'rvw20appdb.dbo.ep_ui_mst'; column does not allow nulls. UPDATE fails.The statement has been terminated.
	/*fetch UI type for the UI*/
	SELECT @tmp_ui_type = isnull(ui_type, '')
	FROM ep_ui_mst a(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_base_req_no)
		-- 	and		process_name		= rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_ref_comp_name)
		AND activity_name = rtrim(@tmp_ref_acty_name)
		AND ui_name = rtrim(@tmp_ref_ui_name)

	/*fetch tab height for the UI*/
	SELECT @tmp_tab_height = isnull(tab_height, '')
	FROM ep_ui_mst a(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_base_req_no)
		-- 	and		process_name		= rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_ref_comp_name)
		AND activity_name = rtrim(@tmp_ref_acty_name)
		AND ui_name = rtrim(@tmp_ref_ui_name)

		--Code added for the Defect Id Tech-70687 starts 
	SELECT	@engg_att_docked	= case when Docked = 'Y' then 1 else 0 end,
			@engg_att_sidebar	= case when Sidebar = 'Y' then 1 else 0 end,
			@engg_lefttb		= case when LeftToolbar = 'Y' then 1 else 0 end,
			@engg_righttb		= case when RightToolbar = 'Y' then 1 else 0 end,
			@engg_toptb			= case when TopToolbar = 'Y' then 1 else 0 end,
			@engg_bottomtb		= case when BottomToolbar = 'Y' then 1 else 0 end,
			@PullToRefresh		= case when PullToRefresh = 'Y' then 1 else 0 end --Code added for TECH-75230
	FROM ep_ui_mst a(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_base_req_no)
		-- 	and		process_name		= rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_ref_comp_name)
		AND activity_name = rtrim(@tmp_ref_acty_name)
		AND ui_name = rtrim(@tmp_ref_ui_name)
		--Code added for the Defect Id Tech-70687 starts 

	SELECT @ui_type = rtrim(ui_type)
	FROM ep_ui_mst(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_base_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp_name)
		AND activity_name = rtrim(@tmp_acty_name)
		AND ui_name = rtrim(@tmp_ui_name)

	-- modified by shafina on 10-dec-2004 , 11-dec-2004
	IF upper(@ui_type) NOT IN ('MAIN')
	BEGIN
		/* To check whether ui of type 'main' or 'search' already exists for the activity*/
		IF rtrim(@tmp_ui_type) IN (
				'Main',
				'Search'
				)
		BEGIN
			IF (
					SELECT count('x')
					FROM ep_ui_mst(NOLOCK)
					WHERE customer_name = rtrim(@engg_customer_name)
						AND project_name = rtrim(@engg_project_name)
						AND req_no = rtrim(@engg_base_req_no)
						AND process_name = rtrim(@tmp_proc)
						AND component_name = rtrim(@tmp_comp_name)
						AND activity_name = rtrim(@tmp_acty_name)
						AND ui_name <> rtrim(@tmp_ui_name)
						AND ui_type IN (
							'Main',
							'Search'
							)
					) > 0
			BEGIN
				SELECT @msg = 'Only one User Interface can be of type "Main" or "Search" for a selected activity'

				EXEC engg_error_sp 'ep_layout_sp_deffrm_hft',
					8,
					@msg,
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					'',
					'',
					'',
					'',
					@m_errorid OUTPUT

				RETURN
			END
		END
	END /*End for Checking Type*/

	IF upper(@ui_type) NOT IN ('SEARCH')
	BEGIN
		/* To check whether ui of type 'main' or 'search' already exists for the activity*/
		IF rtrim(@tmp_ui_type) IN (
				'Main',
				'Search'
				)
		BEGIN
			IF (
					SELECT count('x')
					FROM ep_ui_mst(NOLOCK)
					WHERE customer_name = rtrim(@engg_customer_name)
						AND project_name = rtrim(@engg_project_name)
						AND req_no = rtrim(@engg_base_req_no)
						AND process_name = rtrim(@tmp_proc)
						AND component_name = rtrim(@tmp_comp_name)
						AND activity_name = rtrim(@tmp_acty_name)
						AND ui_name <> rtrim(@tmp_ui_name)
						AND ui_type IN (
							'Main',
							'Search'
							)
					) > 0
			BEGIN
				SELECT @msg = 'Only one User Interface can be of type "Main" or "Search" for a selected activity'

				EXEC engg_error_sp 'ep_layout_sp_deffrm_hft',
					9,
					@msg,
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					'',
					'',
					'',
					'',
					@m_errorid OUTPUT

				RETURN
			END
		END
	END /*End for Checking Type*/

	IF @engg_hide_default = 1
		SELECT @engg_hide_default = 'Y'
	ELSE
		SELECT @engg_hide_default = 'N'

	SELECT @tmp_grid_type = isnull(grid_type, 'HTM'),
		@tmp_state_processing = isnull(state_processing, 'No'),
		@tmp_callout_type = isnull(callout_type, 'None'), -- Modfied for the request PNR2.0_1790
		-- Added for PLF2.0_14096 Starts
		@engg_smarthide = SmartHide,
		@engg_isdevice = Is_device,
		@engg_ilbotitle = HideIlbotitlemenu_req,
		@tmp_ui_subtype = ui_subtype,
		@engg_titlebar_search	= Titlebar_Search
	-- Added for PLF2.0_14096 ends
	FROM ep_ui_mst a(NOLOCK)
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_base_req_no)
		-- 	and		process_name		= rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_ref_comp_name)
		AND activity_name = rtrim(@tmp_ref_acty_name)
		AND ui_name = rtrim(@tmp_ref_ui_name)

	/*update ui format attributes for the selected ui.*/
	UPDATE ep_ui_mst
	SET ui_type = rtrim(@tmp_ui_type),
		ui_format = rtrim(@tmp_ui_format),
		caption_alignment = rtrim(@tmp_cap_align),
		trail_bar = rtrim(@tmp_trail_bar),
		tab_height = rtrim(@tmp_tab_height),
		grid_type = rtrim(@tmp_grid_type),
		state_processing = rtrim(@tmp_state_processing),
		callout_type = rtrim(@tmp_callout_type), -- Modfied for the request PNR2.0_1790,
		-- Added for PLF2.0_14096 Starts
		SmartHide = rtrim(@engg_smarthide),
		Is_device = rtrim(@engg_isdevice),
		hide_imp_defaults = rtrim(@engg_hide_default),
		HideIlbotitlemenu_req = rtrim(HideIlbotitlemenu_req),
		ui_subtype = rtrim(@tmp_ui_subtype),
		Titlebar_Search = @engg_titlebar_search,
		--Code added for the Defect Id Tech-70687 starts 
		Docked			=	@engg_att_docked,
		Sidebar			=	CASE WHEN @engg_att_sidebar		= 1	THEN 'Y' ELSE 'N' END ,	
		LeftToolbar		=	CASE WHEN @engg_lefttb			= 1	THEN 'Y' ELSE 'N' END ,		
		RightToolbar	=	CASE WHEN @engg_righttb			= 1	THEN 'Y' ELSE 'N' END ,		
		TopToolbar		=	CASE WHEN @engg_toptb			= 1	THEN 'Y' ELSE 'N' END ,
		BottomToolbar	=	CASE WHEN @engg_bottomtb		= 1	THEN 'Y' ELSE 'N' END , 
		--Code added for the Defect Id Tech-70687 starts 
		PullToRefresh	=	CASE WHEN @PullToRefresh		= 1	THEN 'Y' ELSE 'N' END	--Code added for TECH-75230
	-- Added for PLF2.0_14096 ends
	WHERE customer_name = rtrim(@engg_customer_name)
		AND project_name = rtrim(@engg_project_name)
		AND req_no = rtrim(@engg_base_req_no)
		AND process_name = rtrim(@tmp_proc)
		AND component_name = rtrim(@tmp_comp_name)
		AND activity_name = rtrim(@tmp_acty_name)
		AND ui_name = rtrim(@tmp_ui_name)

	/*get the quick codes for the attributes*/
	IF lower(ltrim(rtrim(@tmp_ui_format))) = ltrim(rtrim('bes'))
		SELECT @tmp_ui_format = 'controls beside captions'
	ELSE IF lower(ltrim(rtrim(@tmp_ui_format))) = ltrim(rtrim('und'))
		SELECT @tmp_ui_format = 'controls under captions'
	ELSE IF lower(ltrim(rtrim(@tmp_ui_format))) = ltrim(rtrim('top'))   --TECH-72114
		SELECT @tmp_ui_format = 'Top Inner'

	IF lower(ltrim(rtrim(@tmp_cap_align))) = ltrim(rtrim('cent'))
		SELECT @tmp_cap_align = 'center'

	IF lower(ltrim(rtrim(@tmp_trail_bar))) = ltrim(rtrim('bott'))
		SELECT @tmp_trail_bar = 'bottom'

	/*-- smarthide,isdevice,ilbotitle
select	@engg_smarthide	= SmartHide,
		@engg_isdevice	= Is_device,
		@engg_ilbotitle	= HideIlbotitlemenu_req
from ep_ui_mst (nolock)
where customer_name  = rtrim(@engg_customer_name_io)
and project_name  = rtrim(@engg_project_name_io)
and req_no   = rtrim(@engg_base_req_no)
and process_name  = rtrim(@tmp_proc)
and component_name  = rtrim(@tmp_comp_name)
and activity_name  = rtrim(@tmp_acty_name)
and ui_name   = rtrim(@tmp_ui_name)*/
	/*fetch the ui attributes from reference ui and display in the respective controls.*/
	SELECT @engg_act_descr 'engg_act_descr_io', /* DOTNET Migration Tool Changes */
		@tmp_cap_align 'engg_att_ui_cap_align_io', /* DOTNET Migration Tool Changes */
		@tmp_ui_format 'engg_att_ui_format_io', /* DOTNET Migration Tool Changes */
		@tmp_trail_bar 'engg_att_ui_trail_bar_io', /* DOTNET Migration Tool Changes */
		@tmp_ui_type 'engg_att_ui_type_io', /* DOTNET Migration Tool Changes */
		@engg_component 'engg_component_io', /* DOTNET Migration Tool Changes */
		@engg_customer_name 'engg_customer_name_io', /* DOTNET Migration Tool Changes */
		@engg_process_descr 'engg_process_descr_io', /* DOTNET Migration Tool Changes */
		@engg_project_name 'engg_project_name_io', /* DOTNET Migration Tool Changes */
		@engg_req_no 'engg_req_no_io', /* DOTNET Migration Tool Changes */
		@engg_rf_act 'engg_rf_act_io', /* DOTNET Migration Tool Changes */
		@engg_rf_comp 'engg_rf_comp_io', /* DOTNET Migration Tool Changes */
		@engg_rf_ui 'engg_rf_ui_io', /* DOTNET Migration Tool Changes */
		@tmp_tab_height 'engg_tab_height_io', /* DOTNET Migration Tool Changes */
		@engg_ui_descr 'engg_ui_descr_io', /* DOTNET Migration Tool Changes */
		@guid 'guid_io', /* DOTNET Migration Tool Changes */
		@tmp_grid_type 'engg_att_ui_Grid_Type',
		@tmp_state_processing 'state_processing',
		@tmp_callout_type 'engg_callout_type', -- Modfied for the request PNR2.0_1790
		CASE 
			WHEN @engg_nativeapp = 'y'
				THEN 1
			ELSE 0
			END 'engg_nativeapp',
		CASE 
			WHEN @engg_popup_close = 'y'
				THEN 1
			ELSE 0
			END 'engg_popup_close',
		-- Added for PLF2.0_14096 Starts
		CASE 
			WHEN @engg_smarthide = 'y'
				THEN 1
			ELSE 0
			END 'engg_smarthide',
		CASE 
			WHEN @engg_isdevice = 'y'
				THEN 1
			ELSE 0
			END 'engg_isdevice',
		CASE 
			WHEN @engg_ilbotitle = 'y'
				THEN 1
			ELSE 0
			END 'engg_ilbotitle',
		CASE 
			WHEN @engg_hdrpersonalisation = 'y'
				THEN 1
			ELSE 0
			END 'engg_hdrpersonalisation',
		CASE 
			WHEN @engg_syst_excl_tab_ind = 'y'
				THEN 1
			ELSE 0
			END 'engg_syst_excl_tab_ind', --PLF2.0_16291  
		CASE 
			WHEN @engg_hide_default = 'y'
				THEN 1
			ELSE 0
			END 'engg_hide_default',
		CASE 
			WHEN @engg_titlebar_search = 'y'
				THEN 1
			ELSE 0
			END 'engg_titlebar_search',
		@tmp_ui_subtype 'engg_uisubtype',
		--Code added for the Defect Id Tech-70687 starts 
		@engg_toptb			'engg_toptb',
		@engg_bottomtb		'engg_bottomtb',
		@engg_lefttb		'engg_lefttb',
		@engg_righttb		'engg_righttb',
		@engg_att_sidebar	'engg_att_sidebar',
		@engg_att_docked	'engg_att_docked',
		--Code added for the Defect Id Tech-70687 starts 
		@PullToRefresh		'PullToRefresh'	--Code added for TECH-75230

	-- Added for PLF2.0_14096 ends
	--output parameters
	-- 	select  null     'engg_act_descr_io', /* DOTNET Migration Tool Changes */ 
	-- 			null     'engg_att_ui_cap_align_io', /* DOTNET Migration Tool Changes */ 
	-- 			null     'engg_att_ui_format_io', /* DOTNET Migration Tool Changes */ 
	-- 			null     'engg_att_ui_trail_bar_io', /* DOTNET Migration Tool Changes */ 
	-- 			null     'engg_att_ui_type_io', /* DOTNET Migration Tool Changes */ 
	-- 			null     'engg_component_io', /* DOTNET Migration Tool Changes */ 
	-- 			null     'engg_customer_name_io', /* DOTNET Migration Tool Changes */ 
	-- 			null     'engg_process_descr_io', /* DOTNET Migration Tool Changes */ 
	-- 			null     'engg_project_name_io', /* DOTNET Migration Tool Changes */ 
	-- 			null     'engg_req_no_io', /* DOTNET Migration Tool Changes */ 
	-- 			null     'engg_rf_act_io', /* DOTNET Migration Tool Changes */ 
	-- 			null     'engg_rf_comp_io', /* DOTNET Migration Tool Changes */ 
	-- 			null     'engg_rf_ui_io', /* DOTNET Migration Tool Changes */ 
	-- 			null     'engg_tab_height_io', /* DOTNET Migration Tool Changes */ 
	-- 			null     'engg_ui_descr_io', /* DOTNET Migration Tool Changes */ 
	--			null     'guid_io' /* DOTNET Migration Tool Changes */
	--			null	'engg_isdevice', 
	--			null	'engg_smarthide', 
	--			null	'engg_ilbotitle', 
	--			null 'engg_uisubtype',  
	SET NOCOUNT OFF
END

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME= 'ep_layout_sp_deffrm_hft' AND TYPE='P')
BEGIN
	GRANT EXEC ON  ep_layout_sp_deffrm_hft TO PUBLIC
END
GO 