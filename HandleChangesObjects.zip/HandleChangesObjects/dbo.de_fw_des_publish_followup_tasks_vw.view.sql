IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_publish_followup_tasks_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_publish_followup_tasks_vw
    End
Go


/* Creating View Script - de_fw_des_publish_followup_tasks_vw on  Feb 10 2011 */
/************************************************************************************
procedure name and id   de_fw_des_publish_followup_tasks_vw
description
name of the author
date created
query file name         de_fw_des_publish_followup_tasks_vw.sql  */
/* modified by  : Sangeetha G            */
/* date    : 11-Feb-2011                                           */
/* Bug Id   : PNR2.0_30127           */
/* Modified for  : Feature  Release          */

Create view [de_fw_des_publish_followup_tasks_vw]
( customer_name,project_name,process_name,component_name,activity_name,ui_name,task_name,
success_errorid,followup_taskname,service_name,ecrno
)
as
select customer_name,project_name,process_name,component_name,activity_name,ui_name,task_name,
success_errorid,followup_taskname,service_name,ecrno
from de_fw_des_publish_followup_tasks (nolock)







GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_publish_followup_tasks_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_publish_followup_tasks_vw TO PUBLIC
END
GO


