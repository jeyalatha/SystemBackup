IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_bo_segment_lng_extn' AND TYPE = 'V')
    Begin
        Drop View de_bo_segment_lng_extn
    End
Go


create view  [de_bo_segment_lng_extn]              
					(bo_name,bo_segment_descr,bo_segment_doc,bo_segment_instance,bo_segment_name,bo_segment_sysid,bo_sysid,component_name,createdby,createddate,customer_name,ecrno,languageid,modifiedby,modifieddate,process_name,project_name,timestamp)          
					as              
					select bo_name,bo_segment_descr,bo_segment_doc,bo_segment_instance,bo_segment_name,bo_segment_sysid,bo_sysid,component_name,createdby,createddate,customer_name,ecrno,languageid,modifiedby,modifieddate,process_name,project_name,timestamp from rvw_publish_db.dbo.de_published_bo_segment_lng_extn a (nolock)        
					where exists (select 'x' from De_Customer_Space b (nolock)        
					where     a.customer_name   = b.customername        
					and       a.project_name    = b.projectname        
					and       a.process_name    = b.processname        
					and       a.component_name  = b.componentname    
					and       a.ecrno        = b.ecrno )
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_bo_segment_lng_extn' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_bo_segment_lng_extn TO PUBLIC
END
GO


