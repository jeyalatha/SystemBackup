IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_ilbo_link_publish_temp' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_ilbo_link_publish_temp
    End
Go


create view  [de_fw_req_ilbo_link_publish_temp]        
		as              
		select activityid,component_name,createdby,createddate,customer_name,description,ilbocode,link_name,linkid,modifiedby,modifieddate,new_linkid,process_name,project_name,subscription_name,taskname,timestamp,updtime,upduser from rvw20appdb.dbo.de_fw_req_ilbo_link_publish_temp a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_ilbo_link_publish_temp' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_ilbo_link_publish_temp TO PUBLIC
END
GO


