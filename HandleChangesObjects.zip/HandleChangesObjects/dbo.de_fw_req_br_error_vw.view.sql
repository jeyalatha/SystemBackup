IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_br_error_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_br_error_vw
    End
Go


 
	/*	Creating View Script - de_fw_req_br_error_vw on 	Jun 26 2005 11:46PM		*/	

create view [de_fw_req_br_error_vw]
as 
select	brname,
errorcode,
upduser,
updtime,
customer_name,
project_name
from 	de_fw_req_br_error(nolock)

GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_br_error_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_br_error_vw TO PUBLIC
END
GO


