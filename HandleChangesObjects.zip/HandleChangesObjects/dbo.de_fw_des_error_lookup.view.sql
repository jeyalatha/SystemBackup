IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_error_lookup' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_error_lookup
    End
Go


create view  [de_fw_des_error_lookup]              
					(activity_name,component_name,createdby,createddate,customer_name,ecrno,errorid,linkid,modifiedby,modifieddate,post_task,process_name,project_name,pub_name,published_act_name,published_comp_name,published_ui_name,service_name,taskname,ui_name)          
					as              
					select activity_name,component_name,createdby,createddate,customer_name,ecrno,errorid,linkid,modifiedby,modifieddate,post_task,process_name,project_name,pub_name,published_act_name,published_comp_name,published_ui_name,service_name,taskname,ui_name from rvw_publish_db.dbo.de_fw_des_publish_error_lookup a (nolock)        
					where exists (select 'x' from De_Customer_Space b (nolock)        
					where     a.customer_name   = b.customername        
					and       a.project_name    = b.projectname        
					and       a.process_name    = b.processname        
					and       a.component_name  = b.componentname    
					and       a.ecrno        = b.ecrno )
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_error_lookup' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_error_lookup TO PUBLIC
END
GO


