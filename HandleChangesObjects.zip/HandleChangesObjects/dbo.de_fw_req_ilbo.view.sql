IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_ilbo' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_ilbo
    End
Go


CREATE view  [de_fw_req_ilbo]                
     as                
     select aspofilepath,componentname 'component_name' ,createdby,createddate,customername 'customer_name' ,description,ecrno,ilbocode,ilbotype,modifiedby,modifieddate,processname 'process_name' ,progid,projectname 'project_name' ,statusflag,timestamp,updtime,upduser,faTransaction from rvw_publish_db.dbo.de_fw_req_publish_ilbo a (nolock)          
     where exists (select 'x' from De_Customer_Space b (nolock)          
     where     a.customername   = b.customername          
     and       a.projectname    = b.projectname          
     and       a.processname    = b.processname          
     and       a.componentname  = b.componentname      
     and       a.ecrno        = b.ecrno )
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_ilbo' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_ilbo TO PUBLIC
END
GO


