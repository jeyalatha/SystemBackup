IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_exrep_report_sections' AND TYPE = 'V')
    Begin
        Drop View de_exrep_report_sections
    End
Go


create view  [de_exrep_report_sections]        
		as              
		select activity_name,caption_req,component_name,createdby,createddate,customer_name,max_sequence,modifiedby,modifieddate,process_name,project_name,row_caption,section_caption,section_instance,section_name,section_prefix,section_seq,sheet_id,start_column,start_row,summary_row,template_id,ui_name from rvw20appdb.dbo.de_exrep_report_sections a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_exrep_report_sections' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_exrep_report_sections TO PUBLIC
END
GO


