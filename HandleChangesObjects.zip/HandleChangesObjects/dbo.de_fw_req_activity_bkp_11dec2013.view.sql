IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_activity_bkp_11dec2013' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_activity_bkp_11dec2013
    End
Go


create view  [de_fw_req_activity_bkp_11dec2013]        
		as              
		select activitydesc,activityid,activityname,activityposition,activitysequence,activitytype,component_name,componentname,createdby,createddate,customer_name,ecrno,iswfenabled,linkedactivityid,modifiedby,modifieddate,process_name,project_name,timestamp,updtime,upduser from rvw20appdb.dbo.de_fw_req_activity_bkp_11dec2013 a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_activity_bkp_11dec2013' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_activity_bkp_11dec2013 TO PUBLIC
END
GO


