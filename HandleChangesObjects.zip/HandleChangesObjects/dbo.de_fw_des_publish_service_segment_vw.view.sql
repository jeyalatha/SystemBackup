IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_publish_service_segment_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_publish_service_segment_vw
    End
Go


/************************************************************************************
procedure name and id   de_fw_des_publish_service_segment_vw
description             The View used for Launch Pad
name of the author
date created
query file name         de_fw_des_publish_service_segment_vw
modifications history
modified by             Senthil Kumar
modified date           19-Jul-2006
modified purpose        PNR2.0_9600

modified by             Sangeetha G
modified date           17-Aug-07
modified purpose        PNR2.0_14989

modified by             Chanheetha
modified date           11-NOV-2010
modified purpose        PNR2.0_27462
************************************************************************************/
create view [de_fw_des_publish_service_segment_vw]
(bocode ,bosegmentname ,componentname ,customername ,ecrno ,instanceflag ,
mandatoryflag ,parentsegmentname ,processname ,projectname ,segmentname ,servicename,
SegmentSequence,process_selrows,process_updrows) --code added for the caseid : PNR2.0_27462
as
select  bocode      as 'bocode',
bosegmentname    as 'bosegmentname',
componentname    as 'componentname',
customername    as 'customername',
ecrno      as 'ecrno',
instanceflag    as 'instanceflag',
mandatoryflag    as 'mandatoryflag',
parentsegmentname  as 'parentsegmentname',
processname    as 'processname',
projectname    as 'projectname',
segmentname    as 'segmentname',
servicename    as 'servicename',
1       as 'SegmentSequence',
process_selrows         as      'process_selrows',
process_updrows         as 'process_updrows' --code added for the caseid : PNR2.0_27462
from  de_fw_des_publish_service_segment a (nolock)
where exists (
select 's'
from de_fw_des_publish_task_segment_attribs b (nolock)
where a.customername  = b.customername
and  a.projectname  = b.projectname
and  a.ecrno    = b.ecrno
and  a.processname  = b.processname
and  a.componentname  = b.componentname
and  a.servicename  = b.servicename
and  a.segmentname  = b.segmentname)
union
select  bocode     as 'bocode',
bosegmentname   as 'bosegmentname',
componentname   as 'componentname',
customername   as 'customername',
ecrno     as 'ecrno',
instanceflag   as 'instanceflag',
mandatoryflag   as 'mandatoryflag',
parentsegmentname  as 'parentsegmentname',
processname    as 'processname',
projectname    as 'projectname',
segmentname    as 'segmentname',
servicename    as 'servicename',
2      as 'SegmentSequence',
process_selrows              as      'process_selrows',
process_updrows         as 'process_updrows'--code added for the caseid : PNR2.0_27462
from  de_fw_des_publish_service_segment a (nolock)
where not exists (
select 's'
from de_fw_des_publish_task_segment_attribs b (nolock)
where a.customername  = b.customername
and  a.projectname  = b.projectname
and  a.ecrno    = b.ecrno
and  a.processname  = b.processname
and  a.componentname  = b.componentname
and  a.servicename  = b.servicename
and  a.segmentname  = b.segmentname)
union
select  sr.bocode     as 'bocode',
sr.bosegmentname   as 'bosegmentname',
sr.component_name   as 'componentname',
sr.customer_name   as 'customername',
ps.ecrno     as 'ecrno',
sr.instanceflag   as 'instanceflag',
sr.mandatoryflag   as 'mandatoryflag',
sr.parentsegmentname  as 'parentsegmentname',
sr.process_name   as 'processname',
sr.project_name   as 'projectname',
sr.segmentname    as 'segmentname',
sr.servicename   as 'servicename',
1       as 'SegmentSequence',
sr.process_selrows      as      'process_selrows',
sr.process_updrows         as 'process_updrows'--code added for the caseid : PNR2.0_27462
from  de_fw_des_service_segment   sr(nolock),
de_fw_des_publish_processsection_br_is  ps(nolock),
de_fw_des_service   d (NOLOCK)
where  sr.servicename   =  ps.integservicename
and  sr.customer_name  =  ps.customername
and  sr.project_name   =  ps.projectname
and ps.componentname  <> sr.component_name

and sr.servicename   =  d.servicename
and  sr.customer_name  =  d.customer_name
and  sr.project_name   =  d.project_name
and sr.component_name  =  d.componentname
and  d.isintegser  =  1

-- from  de_fw_des_service_segment     sr(nolock),
--   de_fw_des_publish_processsection_br_is  ps(nolock)
-- where  sr.servicename   =  ps.integservicename
-- and  sr.customer_name  =  ps.customername
-- and  sr.project_name   =  ps.projectname
-- and  ps.componentname  <> sr.component_name




GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_publish_service_segment_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_publish_service_segment_vw TO PUBLIC
END
GO


