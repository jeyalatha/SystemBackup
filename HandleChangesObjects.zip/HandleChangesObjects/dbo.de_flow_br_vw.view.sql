IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_flow_br_vw' AND TYPE = 'V')
    Begin
        Drop View de_flow_br_vw
    End
Go


 
	/*	Creating View Script - de_flow_br_vw on 	Jun 26 2005 11:46PM		*/	

/************************************************************************************
procedure name and id   de_flow_br_vw
description             
name of the author      
date created            
query file name         de_flow_br_vw.sql
modifications history   
modified by             
modified date           
modified purpose        
************************************************************************************/
create  view [de_flow_br_vw]
as
select	a.customer_name			as	'CustomerID',
		a.project_name			as	'ProjectID',
		a.ecrno					as	'ECR_NO',
		a.process_name			as	'BPID',
		b.functionid			as	'FunctionID',
		a.component_name		as	'ComponentName',
		a.activity_name			as	'ActivityID',
		a.ui_name				as	'UIID',
		a.page_bt_synonym		as	'Page_Bt_Synonym',
		a.task_name				as	'TaskID',
		a.task_name				as	'TaskName',
		a.flowbr_name			as	'BRID',
		a.flowbr_name			as	'BRName',
		a.flowbr_descr			as	'BRDesc',
		a.flowbr_descr  		as	'BRSpec',
		'Y'						as	'Applicable',
		''				as	'Status_Flag',
		1     					as	'LangID',
		a.createdby  			as	'UserID'
from    de_published_flowbr 			     a (nolock),        
		fw_bpt_function_component_vw	b (nolock)
where   a.customer_name		= b.customerid
and		a.project_name		= b.projectid
and		a.process_name		= b.bpid
and	   	a.component_name	= b.componentname
                               /*  = case	
					when	a.flowbr_name	not in
							(select	b.flowbr_name
							from	de_published_flowbr b(nolock)
							where	a.customer_name		= b.customer_name
							and		a.project_name		= b.project_name
							and		a.process_name		= b.process_name
							and		a.component_name	= b.component_name
							and		a.activity_name		= b.activity_name
							and		a.ui_name			= b.ui_name
							and		a.page_bt_synonym	= b.page_bt_synonym
							and		a.task_name			= b.task_name
							and		a.flowbr_name		= b.flowbr_name)
					then	'I'
					when	a.flowbr_name	in 
							(select	b.flowbr_name
							from	de_published_flowbr b(nolock)
							where	a.customer_name		= b.customer_name
							and		a.project_name		= b.project_name
							and		a.process_name		= b.process_name
							and		a.component_name	= b.component_name
							and		a.activity_name		= b.activity_name
							and		a.ui_name			= b.ui_name
							and		a.page_bt_synonym	= b.page_bt_synonym
							and		a.task_name			= b.task_name
							and		a.flowbr_name		= b.flowbr_name
							and		(isnull(a.flowbr_descr,'')		<> isnull(b.flowbr_descr,'')
							or		isnull(a.flowbr_sequence,'')	<> isnull(b.flowbr_sequence,'')
							or		isnull(a.control_id,'')			<> isnull(b.control_id,'')
							or		isnull(a.view_name,'')			<> isnull(b.view_name,'')
							or		isnull(a.event_name,'')			<> isnull(b.event_name,'')
							or		isnull(a.map_flag,'')			<> isnull(b.map_flag,'')))
					then	'U'
					when	a.flowbr_name	in 
							(select	b.flowbr_name
							from	de_published_flowbr b(nolock)
							where	a.customer_name		= b.customer_name
							and		a.project_name		= b.project_name
							and		a.process_name		= b.process_name
							and		a.component_name	= b.component_name
							and		a.activity_name		= b.activity_name
							and		a.ui_name			= b.ui_name
							and		a.page_bt_synonym	= b.page_bt_synonym
							and		a.task_name			= b.task_name
							and		a.flowbr_name		= b.flowbr_name
							and		isnull(a.flowbr_descr,'')		= isnull(b.flowbr_descr,'')
							and		isnull(a.flowbr_sequence,'')	= isnull(b.flowbr_sequence,'')
							and		isnull(a.control_id,'')			= isnull(b.control_id,'')
							and		isnull(a.view_name,'')			= isnull(b.view_name,'')
							and		isnull(a.event_name,'')			= isnull( b.event_name,'')
							and		isnull(a.map_flag,'')			= isnull(b.map_flag,''))
					then	'S'
					when	b.flowbr_name	not in
							(select	a.flowbr_name
							from	de_published_flowbr b(nolock)
							where	a.customer_name		= b.customer_name
							and		a.project_name		= b.project_name
							and		a.proc
ess_name		= b.process_name
							and		a.component_name	= b.component_name
							and		a.activity_name		= b.activity_name
							and		a.ui_name			= b.ui_name
							and		a.page_bt_synonym	= b.page_bt_synonym
							and		a.task_name			= b.task_name
							and		a.flowbr_name		= b.flowbr_name)
					then	'D'
				  end,
		1     					as	'LangID',
		a.createdby  			as	'UserID'
from	de_flowbr 						a (nolock),
		de_published_flowbr 			b (nolock),
		fw_bpt_function_component_vw	c (nolock)
where	a.customer_name		*= b.customer_name
and		a.project_name		*= b.project_name
and		a.process_name		*= b.process_name
and		a.component_name	*= b.component_name
and		a.activity_name		*= b.activity_name
and		a.ui_name			*= b.ui_name
and		a.page_bt_synonym	*= b.page_bt_synonym
and		a.task_name			*= b.task_name
and		a.flowbr_name		*= b.flowbr_name

and		a.customer_name		= c.customerid
and		a.project_name		= c.projectid
and		a.process_name		= c.bpid
and		a.component_name	= c.componentname

UNION

select	b.customer_name			as	'CustomerID',
		b.project_name			as	'ProjectID',
		b.ico_no				as	'ECR_NO',
		b.process_name			as	'BPID',
		c.functionid			as	'FunctionID',
		b.component_name		as	'ComponentName',
		b.activity_name			as	'ActivityID',
		b.ui_name				as	'UIID',
		b.page_bt_synonym		as	'Page_Bt_Synonym',
		b.task_name				as	'TaskID',
		b.task_name				as	'TaskName',
		b.flowbr_name			as	'BRID',
		b.flowbr_name			as	'BRName',
		b.flowbr_descr			as	'BRDesc',
		b.flowbr_descr  		as	'BRSpec',
		isnull(b.map_flag,'Y')	as	'Applicable',					
		'Status_Flag' 	= case	
					when	b.flowbr_name	not in
							(select	a.flowbr_name
							from	de_published_flowbr b(nolock)
							where	a.customer_name		= b.customer_name
							and		a.project_name		= b.project_name
							and		a.process_name		= b.process_name
							and		a.component_name	= b.component_name
							and		a.activity_name		= b.activity_name
							and		a.ui_name			= b.ui_name
							and		a.page_bt_synonym	= b.page_bt_synonym
							and		a.task_name			= b.task_name
							and		a.flowbr_name		= b.flowbr_name)
					then	'D'
					when	a.flowbr_name	not in
							(select	b.flowbr_name
							from	de_published_flowbr b(nolock)
							where	a.customer_name		= b.customer_name
							and		a.project_name		= b.project_name
							and		a.process_name		= b.process_name
							and		a.component_name	= b.component_name
							and		a.activity_name		= b.activity_name
							and		a.ui_name			= b.ui_name
							and		a.page_bt_synonym	= b.page_bt_synonym
							and		a.task_name			= b.task_name
							and		a.flowbr_name		= b.flowbr_name)
					then	'I'
					when	a.flowbr_name	in 
							(select	b.flowbr_name
							from	de_published_flowbr b(nolock)
							where	a.customer_name		= b.customer_name
							and		a.project_name		= b.project_name
							and		a.process_name		= b.process_name
							and		a.component_name	= b.component_name
							and		a.activity_name		= b.activity_name
							and		a.ui_name			= b.ui_name
							and		a.page_bt_synonym	= b.page_bt_synonym
							and		a.task_name			= b.task_name
							and		a.flowbr_name		= b.flowbr_name
							and		(isnull(a.flowbr_descr,'')		<> isnull(b.flowbr_descr,'')
							or		isnull(a.flowbr_sequence,'')	<> isnull(b.flowbr_sequence,'')
							or		isnull(a.control_id,'')			<> isnull(b.control_id,'')
							or		isnull(a.view_name,'')			<> isnull(b.view_name,'')
							or		isnull(a.event_name,'')			<> isnull(b.event_name,'')
							or		isnull(a.map_flag,'')			<> isnull(b.map_flag,'')))
					then	'U'
					when	a.flowbr_name	in 
							(select	b.flowbr_name
							from	de_published_flowbr b(nolock)
							where	a.customer_name		= b.customer_name
							and		a.project_name		= b.project_name
							and		a.process_name		= b.process_name
							and		a.component_name	= b.component_name
							and		a.activity_name		= b.activity_name
							and		a.ui_name			= b.ui_name
							and		a.page_bt_synon
ym	= b.page_bt_synonym
							and		a.task_name			= b.task_name
							and		a.flowbr_name		= b.flowbr_name
							and		isnull(a.flowbr_descr,'')		= isnull(b.flowbr_descr,'')
							and		isnull(a.flowbr_sequence,'')	= isnull(b.flowbr_sequence,'')
							and		isnull(a.control_id,'')			= isnull(b.control_id,'')
							and		isnull(a.view_name,'')			= isnull(b.view_name,'')
							and		isnull(a.event_name,'')			= isnull( b.event_name,'')
							and		isnull(a.map_flag,'')			= isnull(b.map_flag,''))
					then	'S'
				  end,
		1     					as	'LangID',
		b.createdby  			as	'UserID'
from	de_flowbr 						a (nolock),
		de_published_flowbr 			b (nolock),        
		fw_bpt_function_component_vw	c (nolock)
where	a.customer_name		=* b.customer_name
and		a.project_name		=* b.project_name
and		a.process_name		=* b.process_name
and		a.component_name	=* b.component_name
and		a.activity_name		=* b.activity_name
and		a.ui_name			=* b.ui_name
and		a.page_bt_synonym	=* b.page_bt_synonym
and		a.task_name			=* b.task_name
and		a.flowbr_name		=* b.flowbr_name

and		b.customer_name		= c.customerid
and		b.project_name		= c.projectid
and		b.process_name		= c.bpid
and		b.component_name	= c.componentname */

GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_flow_br_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_flow_br_vw TO PUBLIC
END
GO


