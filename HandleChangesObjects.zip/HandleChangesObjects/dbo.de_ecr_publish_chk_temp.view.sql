IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_ecr_publish_chk_temp' AND TYPE = 'V')
    Begin
        Drop View de_ecr_publish_chk_temp
    End
Go


create view  [de_ecr_publish_chk_temp]        
		as              
		select createdby,createddate,customer_Name,ecr_no,host_mcname,modifiedby,modifieddate,Project_Name,publ_username,start_time,timestamp,work_flag from rvw20appdb.dbo.de_ecr_publish_chk_temp a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_ecr_publish_chk_temp' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_ecr_publish_chk_temp TO PUBLIC
END
GO


