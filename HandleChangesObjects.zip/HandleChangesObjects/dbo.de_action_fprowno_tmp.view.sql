IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_action_fprowno_tmp' AND TYPE = 'V')
    Begin
        Drop View de_action_fprowno_tmp
    End
Go


create view  [de_action_fprowno_tmp]              
			(activity_name,component_name,createdby,createddate,customer_name,modifiedby,modifieddate,page_bt_synonym,process_name,project_name,task_name,timestamp,ui_name)        
			as              
			select activity_name,component_name,createdby,createddate,customer_name,modifiedby,modifieddate,page_bt_synonym,process_name,project_name,task_name,timestamp,ui_name from rvw20appdb.dbo.de_action_fprowno_tmp (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_action_fprowno_tmp' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_action_fprowno_tmp TO PUBLIC
END
GO


