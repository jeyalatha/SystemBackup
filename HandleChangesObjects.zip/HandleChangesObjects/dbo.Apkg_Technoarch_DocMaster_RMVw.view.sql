IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='Apkg_Technoarch_DocMaster_RMVw' AND TYPE = 'V')
    Begin
        Drop View Apkg_Technoarch_DocMaster_RMVw
    End
Go


 
	/*	Creating View Script - Apkg_Technoarch_DocMaster_RMVw on 	Jun 26 2005 11:46PM		*/	
	Create View [Apkg_Technoarch_DocMaster_RMVw] As Select 
	Platform,	
	ReleaseArtifactType,
	ReleaseArtifactTypeName,
	CompilerSoftwareUsed,
	CompilerSoftwareVersion,
	UpdUser,
	UpdTime
	from Apkg_Technoarch_DocMaster(nolock)
	where	ReleaseArtifactType in ('SQL','BAT')

GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'Apkg_Technoarch_DocMaster_RMVw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  Apkg_Technoarch_DocMaster_RMVw TO PUBLIC
END
GO


