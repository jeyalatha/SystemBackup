IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='CE_RMT_ICO_Descr_Vw' AND TYPE = 'V')
    Begin
        Drop View CE_RMT_ICO_Descr_Vw
    End
Go


 
	/*	Creating View Script - CE_RMT_ICO_Descr_Vw on 	Jun 26 2005 11:46PM		*/	

-- Modified by Hamsika on 15/12/2004
-- Bug ID 	:	ECPF204SYS_000054
-- Bug Descr	:	While selecting a Direct ICO No and trying to download it, the staus is not changed. No error message also raised.

CREATE VIEW [CE_RMT_ICO_Descr_Vw] AS  
	SELECT  B.CustomerID    'Customer_Name',  
			B.ProjectID     'Project_Name',   
			B.ICONumber    'ICO_No',   
			A.Process_Name   'Process_Name',   
			A.Process_Descr   'Process_Descr',  
			A.Component_Name  'Component_Name',  
			A.Component_Descr  'Component_Descr',  
	   		A.Activity_Name   'Activity_Name',   
			A.Activity_Descr   'Activity_Descr',  
		   	A.UI_Name     'UI_Name',     
			A.UI_Descr     'UI_Descr'  

	FROM 	DE_UI_ICO A (NOLOCK),   
		CE_RMT_ICO_vw B (NOLOCK)  
	WHERE 	A.Customer_Name = B.CustomerID  
	AND  	A.Project_Name  = B.ProjectID  
	AND  	A.ICO_No    	= B.ECRNumber  
	and	a.Process_Name	= B.ProcessName
	and	a.Component_Name= b.ComponentName  
	and     B.ICOType ='ECRB'

	UNION
	
	SELECT  Distinct B.CustomerID    'Customer_Name',  
			B.ProjectID     'Project_Name',   
			B.ICONumber    'ICO_No',   
			A.Process_Name   'Process_Name',   
			A.Process_Descr   'Process_Descr',  
			A.Component_Name  'Component_Name',  
			A.Component_Descr  'Component_Descr',  
	   		A.Activity_Name   'Activity_Name',   
			A.Activity_Descr   'Activity_Descr',  
		   	A.UI_Name     'UI_Name',     
			A.UI_Descr     'UI_Descr'  

	FROM 	DE_UI_ICO A (NOLOCK),   
			CE_RMT_ICO_vw B (NOLOCK)  
	WHERE 	A.Customer_Name = B.CustomerID  
	AND  	A.Project_Name  = B.ProjectID  
	and	a.Process_Name	= B.ProcessName
	and	a.Component_Name= b.ComponentName  
	and     B.ICOType ='DIR'


GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'CE_RMT_ICO_Descr_Vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  CE_RMT_ICO_Descr_Vw TO PUBLIC
END
GO


