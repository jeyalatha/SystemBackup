IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_bterm_group' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_bterm_group
    End
Go


create view  [de_fw_req_bterm_group]              
				as              
				select btname,componentname,createdby,createddate,customername 'customer_name' ,ecrno,modifiedby,modifieddate,processname 'process_name' ,projectname 'project_name' ,timestamp,updtime,upduser from rvw_publish_db.dbo.de_fw_req_publish_bterm_group a (nolock)        
				where exists (select 'x' from De_Customer_Space b (nolock)        
				where     a.customername   = b.customername        
				and       a.projectname    = b.projectname        
				and       a.processname    = b.processname        
				and       a.componentname  = b.componentname    
				and       a.ecrno        = b.ecrno )
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_bterm_group' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_bterm_group TO PUBLIC
END
GO


