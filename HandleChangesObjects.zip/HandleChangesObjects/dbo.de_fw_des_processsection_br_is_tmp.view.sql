IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_processsection_br_is_tmp' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_processsection_br_is_tmp
    End
Go


CREATE view  [de_fw_des_processsection_br_is_tmp]              
(component_name,createdby,createddate,customer_name,guid,integ_servicename,method_name,modifiedby,modifieddate,process_name,project_name,sectionname,sequenceno,servicename,timestamp,QueryID)        
as              
select component_name,createdby,createddate,customer_name,guid,integ_servicename,method_name,modifiedby,modifieddate,process_name,project_name,sectionname,sequenceno,servicename,timestamp,QueryID
from rvw20appdb.dbo.de_fw_des_processsection_br_is_tmp (nolock)


GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_processsection_br_is_tmp' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_processsection_br_is_tmp TO PUBLIC
END
GO


