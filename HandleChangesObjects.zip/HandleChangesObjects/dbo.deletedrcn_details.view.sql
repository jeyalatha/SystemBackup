IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='deletedrcn_details' AND TYPE = 'V')
    Begin
        Drop View deletedrcn_details
    End
Go


create view  [deletedrcn_details]        
		as              
		select component_name,Customer_name,deletedby,deletedon,process_name,Project_name,rcn_no,req_deleted,req_no from rvw20appdb.dbo.deletedrcn_details a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'deletedrcn_details' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  deletedrcn_details TO PUBLIC
END
GO


