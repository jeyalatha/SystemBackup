IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_base_ilbo_data_publish_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_base_ilbo_data_publish_vw
    End
Go



/************************************************************************************    
procedure name and id   de_fw_req_publish_ilbo_data_publish_vw
description             The View used for Launch Pad
name of the author          
date created                
query file name         de_fw_req_publish_ilbo_data_publish_vw
modifications history       
modified by                 : Saravanan for PNR2.0_3889
modified date               : 20/09/2005
modified purpose            : The help pages are not getting launched because the link
 information is not available in the following tables. 1. fw_req_ilbo_data_publish 2. fw_req_ilbo_link_publish
************************************************************************************/  
Create View [de_fw_req_base_ilbo_data_publish_vw]
		(componentname ,controlid ,controlvariablename ,customername ,dataitemname  ,
		flowtype ,havemultiple ,ilbocode ,iscontrol ,linkid ,mandatoryflag ,processname ,
		projectname ,viewname , parentcomponentname) 
as 
select 	component_name ,controlid ,controlvariablename ,customer_name ,dataitemname  ,
		flowtype ,havemultiple ,ilbocode ,iscontrol ,linkid ,mandatoryflag ,process_name ,
		project_name ,viewname , component_name
from 	de_fw_req_ilbo_data_publish (nolock)

Union
Select 	p.component_name, p.controlid , p.controlvariablename, p.customer_name,  p.dataitemname, 
	p.flowtype, p.havemultiple, p.ilbocode, p.iscontrol, p.linkid, p.mandatoryflag, p.process_name,
	p.project_name, p.viewname ,u.component_name
from de_fw_req_ilbo_data_use u (nolock), 
     de_fw_req_ilbo_data_publish p (nolock),  
     de_fw_req_activity a (nolock),
     de_fw_req_ilbo_link_publish lp (nolock)
where u.customer_name 	= p.customer_name
and   u.project_name  	= p.project_name
and   u.childilbocode 	= p.ilbocode 
and   u.linkid 		= p.linkid 
and   u.dataitemname 	= p.dataitemname

and   u.customer_name 	= lp.customer_name
and   u.project_name  	= lp.project_name
and   u.linkid 		= lp.linkid 

and   lp.customer_name 	= a.customer_name
and   lp.project_name  	= a.project_name
and   lp.activityid 	= a.activityid 
--and   lp.ecrno    	= a.ecrno

--and   lp.ecrno    	= p.ecrno
and   p.linkid 		= lp.linkid 
and   lp.ilbocode 	= u.childilbocode

-- and   lp.customer_name + lp.project_name + lp.process_name + lp.component_name  in  
-- (Select x.customer_name	+ x.project_name + x.process_name + x.component_name 
-- from	de_ui_ico	x(nolock)
-- where	x.modifieddate	=  (Select max(d.modifieddate)
-- 				from	de_ui_ico d(nolock)
-- 				where	x.customer_name	= d.customer_name
-- 				and	x.project_name	= d.project_name
-- 				and	x.process_name	= d.process_name
-- 				and	x.component_name = d.component_name
-- 				and     d.ico_status     = 'P'))






GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_base_ilbo_data_publish_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_base_ilbo_data_publish_vw TO PUBLIC
END
GO


