IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='deletedecr_details' AND TYPE = 'V')
    Begin
        Drop View deletedecr_details
    End
Go


create view  [deletedecr_details]        
		as              
		select component_name,Customer_name,deletedby,deletedon,ecr_no,process_name,Project_name,rcn_deleted,rcn_no from rvw20appdb.dbo.deletedecr_details a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'deletedecr_details' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  deletedecr_details TO PUBLIC
END
GO


