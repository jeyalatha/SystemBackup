IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='Ce_Design_SchemaObj_vw' AND TYPE = 'V')
    Begin
        Drop View Ce_Design_SchemaObj_vw
    End
Go


 
	/*	Creating View Script - Ce_Design_SchemaObj_vw on 	Jun 26 2005 11:46PM		*/	

/************************************************************************************
procedure name and id   Ce_Design_SchemaObj_vw
description             
name of the author      
date created            
query file name         Ce_Design_SchemaObj_vw.sql
modifications history   
modified by             
modified date           
modified purpose        
************************************************************************************/
Create view [Ce_Design_SchemaObj_vw]
As
	Select	customer_name,
			project_name,
			process_name,
			component_name,
			'objectname' = view_name,
			'Object_Descr' = view_descr,
			'object_type' = 'V' 
			From de_schema_view_vw (nolock)
UNION
	select	customer_name,
			project_name,
			process_name,
			component_name,
			'objectname' = table_name,
			'Object_Descr' = table_descr,
			'object_type' = 'U' 
From de_schema_table_vw (nolock)






GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'Ce_Design_SchemaObj_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  Ce_Design_SchemaObj_vw TO PUBLIC
END
GO


