IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='dec22' AND TYPE = 'V')
    Begin
        Drop View dec22
    End
Go


create view  [dec22]        
		as              
		select Activityname,Filterbutton56,ILBOName,NewServiceName1,NewServiceName2,OldServiceName,Searchbutton56,Taskfilterbutton,Tasksearchbutton,UIName from rvw20appdb.dbo.dec22 a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'dec22' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  dec22 TO PUBLIC
END
GO


