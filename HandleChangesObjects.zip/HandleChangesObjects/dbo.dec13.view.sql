IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='dec13' AND TYPE = 'V')
    Begin
        Drop View dec13
    End
Go


create view  [dec13]        
		as              
		select ControlCaption,ControlName,ControlType,NewPageName,NewSectionName,PageName,SectionCaption,SectionName from rvw20appdb.dbo.dec13 a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'dec13' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  dec13 TO PUBLIC
END
GO


