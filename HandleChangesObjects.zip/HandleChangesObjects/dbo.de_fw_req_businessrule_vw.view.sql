IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_businessrule_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_businessrule_vw
    End
Go


 
	/*	Creating View Script - de_fw_req_businessrule_vw on 	Jun 26 2005 11:46PM		*/	

create view [de_fw_req_businessrule_vw]
as
select brname,
brtype,
brdesc,
upduser,
updtime,
customer_name,
project_name
from	de_fw_req_businessrule(nolock)

GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_businessrule_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_businessrule_vw TO PUBLIC
END
GO


