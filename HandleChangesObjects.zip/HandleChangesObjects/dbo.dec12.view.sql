IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='dec12' AND TYPE = 'V')
    Begin
        Drop View dec12
    End
Go


create view  [dec12]        
		as              
		select activitydescription,activityname,componentdescription,componentname,customername,Newsectionname,pagename,processdescription,processname,projectname,sectionname,uidescription,uiname from rvw20appdb.dbo.dec12 a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'dec12' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  dec12 TO PUBLIC
END
GO


