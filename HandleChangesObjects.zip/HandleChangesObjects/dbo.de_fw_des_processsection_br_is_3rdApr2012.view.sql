IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_processsection_br_is_3rdApr2012' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_processsection_br_is_3rdApr2012
    End
Go


create view  [de_fw_des_processsection_br_is_3rdApr2012]        
		as              
		select component_name,connectivityflag,controlexpression,createdby,createddate,customer_name,ecrno,executionflag,integservicename,isbr,method_name,methodid,modifiedby,modifieddate,process_name,project_name,sectionname,sequenceno,servicename,timestamp,updtime,upduser from rvw20appdb.dbo.de_fw_des_processsection_br_is_3rdApr2012 a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_processsection_br_is_3rdApr2012' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_processsection_br_is_3rdApr2012 TO PUBLIC
END
GO


