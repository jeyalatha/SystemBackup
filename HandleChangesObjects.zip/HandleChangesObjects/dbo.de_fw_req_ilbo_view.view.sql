IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_ilbo_view' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_ilbo_view
    End
Go


CREATE view  [de_fw_req_ilbo_view]                
     as                
     select btsynonym,componentname 'component_name' ,control_bt_synonym,controlid,createdby,createddate,customername 'customer_name' ,displayflag,displaylength,ecrno,ilbocode,listedit,modifiedby,modifieddate,page_bt_synonym,processname 'process_name' ,projectname 'project_name' ,timestamp,updtime,upduser,viewname,ctrl_type_name, store_path, systemgeneratedfileid from rvw_publish_db.dbo.de_fw_req_publish_ilbo_view a (nolock)          
     where exists (select 'x' from De_Customer_Space b (nolock)          
     where     a.customername   = b.customername          
     and       a.projectname    = b.projectname          
     and       a.processname    = b.processname          
     and       a.componentname  = b.componentname      
     and       a.ecrno        = b.ecrno )
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_ilbo_view' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_ilbo_view TO PUBLIC
END
GO


