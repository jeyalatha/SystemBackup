IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_method_doc_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_method_doc_vw
    End
Go


 
	/*	Creating View Script - de_fw_des_method_doc_vw on 	Jun 26 2005 11:46PM		*/	

/************************************************************************************
procedure name and id   de_fw_des_method_doc_vw
description             
name of the author     	: A.G.Senthil kumar 
date created            
query file name         de_fw_des_method_doc_vw.sql
modifications history    : for Development Packaging
modified by             
modified date           
modified purpose        
************************************************************************************/
Create view [de_fw_des_method_doc_vw]
(		customer_name , 	project_name , 		process_name , 		component_name,
		activity_name , 	ui_name, 			task_name, 			service_name,
		servicetype,  		method_name, 		methodid,			doctext,
		ecrno)
as 
select 	distinct 
		map.customer_name , map.project_name , 	map.process_name , 	map.component_name,
		map.activity_name , map.ui_name, 		map.task_name, 		map.service_name,
		sr.servicetype,  	mt.methodname, 		pr.methodid,		br.doctext,
		map.ecrno		
from 	de_published_task_service_map 			map(nolock),
	 	de_fw_des_publish_processsection_br_is 	pr (nolock),
	 	de_fw_des_publish_br_documentation		br (nolock),
		de_fw_des_publish_service				sr (nolock),
		de_fw_des_publish_businessrule			mt (nolock)	
where 	map.customer_name		= pr.customername
and   	map.project_name		= pr.projectname
and   	map.process_name		= pr.processname
and 	map.component_name 		= pr.componentname
and		map.ecrno				= pr.ecrno
and   	map.service_name 		= pr.servicename

and 	map.customer_name		= sr.customername
and   	map.project_name		= sr.projectname
and   	map.process_name		= sr.processname
and 	map.component_name 		= sr.componentname
and		map.ecrno				= sr.ecrno
and   	map.service_name 		= sr.servicename


and   	pr.customername			= br.customername
and   	pr.projectname			= br.projectname
and   	pr.processname			= br.processname
and   	pr.componentname 		= br.componentname
and		pr.ecrno				= br.ecrno
and   	pr.methodid 			= br.methodid

and   	pr.customername			= sr.customername
and   	pr.projectname			= sr.projectname
and   	pr.processname			= sr.processname
and   	pr.componentname 		= sr.componentname
and		pr.ecrno				= sr.ecrno
and		pr.servicename			= sr.servicename

and   	br.customername			= mt.customername
and   	br.projectname			= mt.projectname
and   	br.processname			= mt.processname
and   	br.componentname 		= mt.componentname
and		br.ecrno				= mt.ecrno
and   	br.methodid 			= mt.methodid

and   	pr.customername			= mt.customername
and   	pr.projectname			= mt.projectname
and   	pr.processname			= mt.processname
and   	pr.componentname 		= mt.componentname
and		pr.ecrno				= mt.ecrno
and   	pr.methodid 			= mt.methodid

GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_method_doc_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_method_doc_vw TO PUBLIC
END
GO


