IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_error_lookup_dataitem_bkp_apr042012' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_error_lookup_dataitem_bkp_apr042012
    End
Go


create view  [de_fw_des_error_lookup_dataitem_bkp_apr042012]        
		as              
		select activity_name,component_name,createdby,createddate,customer_name,ecrno,errorid,linkid,modifiedby,modifieddate,process_name,project_name,pub_control_bt_synonym,pub_controlid,pub_dataitemname,pub_flowtype,pub_name,pub_page,pub_viewname,published_act_name,published_comp_name,published_ui_name,retrievemultiple,service_name,sub_control_bt_synonym,sub_controlid,sub_flowtype,sub_page,sub_viewname,task_name,ui_name from rvw20appdb.dbo.de_fw_des_error_lookup_dataitem_bkp_apr042012 a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_error_lookup_dataitem_bkp_apr042012' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_error_lookup_dataitem_bkp_apr042012 TO PUBLIC
END
GO


