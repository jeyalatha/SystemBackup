IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='dec17_latest' AND TYPE = 'V')
    Begin
        Drop View dec17_latest
    End
Go


create view  [dec17_latest]        
		as              
		select control_id,controlname,pagename,sectionname,UIname,view_name from rvw20appdb.dbo.dec17_latest a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'dec17_latest' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  dec17_latest TO PUBLIC
END
GO


