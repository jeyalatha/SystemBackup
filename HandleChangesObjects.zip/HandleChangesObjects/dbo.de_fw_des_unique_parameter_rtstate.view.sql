IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_unique_parameter_rtstate' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_unique_parameter_rtstate
    End
Go


create view  [de_fw_des_unique_parameter_rtstate]        
		as              
		select activity_name,component_name,control_bt_synonym,controlid,customer_name,dataitemname,ilbocode,method_name,methodid,newsynonym,page_bt_synonym,parametername,process_name,project_name,sectionname,segmentname,sequenceno,servicename,taskname,viewname from rvw20appdb.dbo.de_fw_des_unique_parameter_rtstate a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_unique_parameter_rtstate' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_unique_parameter_rtstate TO PUBLIC
END
GO


