IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_base_ilbo_local_info_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_base_ilbo_local_info_vw
    End
Go



/************************************************************************************    
procedure name and id   de_fw_req_base_ilbo_local_info_vw
description             
name of the author      BharathiDasan.V.V
date created            16-07-2007
query file name         de_fw_req_base_ilbo_local_info_vw
modifications history       
************************************************************************************/  
Create view [de_fw_req_base_ilbo_local_info_vw]
		(customername,		projectname,		processname,		componentname,
		ilbocode,			langid,				description,		helpindex) 
as 
select	a.customer_name,	a.project_name,		a.process_name,		a.component_name,
		a.ilbocode,			b.langid,			b.description,		b.helpindex
from 	de_fw_req_ilbo a (nolock),
		de_fw_req_ilbo_local_info b (nolock)
where  	b.customer_name		= a.customer_name	 
and		b.project_name		= a.project_name	
and		b.process_name		= a.process_name	 
and		b.component_name	= a.component_name	
and		b.ilbocode			= a.ilbocode	


GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_base_ilbo_local_info_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_base_ilbo_local_info_vw TO PUBLIC
END
GO


