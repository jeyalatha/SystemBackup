IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='ce_default_customerproject_vw' AND TYPE = 'V')
    Begin
        Drop View ce_default_customerproject_vw
    End
Go


 
	/*	Creating View Script - ce_default_customerproject_vw on 	Jun 26 2005 11:46PM		*/	
/************************************************************************************
procedure name and id   ce_default_customerproject_vw
description             
name of the author      
date created            
query file name         ce_default_customerproject_vw.sql
modifications history   
modified by             
modified date           
modified purpose        
************************************************************************************/
create view [ce_default_customerproject_vw]
as
select 	userid		collate database_default	userid,
		langid	langid,
		CustomerId	collate database_default	Customer_Name,
		ProjectId	collate database_default	Project_Name
from 	fw_bpt_default_custproj_vw(nolock)


GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'ce_default_customerproject_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  ce_default_customerproject_vw TO PUBLIC
END
GO


