IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_component_documentation' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_component_documentation
    End
Go


create view  [de_fw_req_component_documentation]        
		as              
		select componentname,createdby,createddate,customer_name,langid,modifiedby,modifieddate,paragraphname,paragraphno,paragraphtext,project_name,timestamp,updtime,upduser from rvw20appdb.dbo.de_fw_req_component_documentation a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_component_documentation' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_component_documentation TO PUBLIC
END
GO


