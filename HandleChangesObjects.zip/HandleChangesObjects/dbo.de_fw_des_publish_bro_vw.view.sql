IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_publish_bro_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_publish_bro_vw
    End
Go


 
	/*	Creating View Script - de_fw_des_publish_bro_vw on 	Jun 26 2005 11:46PM		*/	
/************************************************************************************    
procedure name and id   de_fw_des_publish_bro_vw
description             The View used for Launch Pad
name of the author          
date created                
query file name         de_fw_des_publish_bro_vw
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/  
/* Modified by Bakiaraj V on 18-jan-2005 for the bug id   : DEPF204ACC_000060 
bug desc : Addtion of Process Name in different tables.  */
/******************************************************************************/
/* Modified by  :  Sangeetha L                                   		        */
/* Date         :  27-06-2005                                           	*/
/* Description  :  For Bug ID:PNR2.0_3047		                        */
/********************************************************************************/

Create view [de_fw_des_publish_bro_vw] 
		(brodescription ,broname ,broscope ,brotype ,clsid ,
		clsname ,customername ,dllname ,ecrno ,progid ,
		projectname ,systemgenerated,componentname,processname ) 
as 
select 	a.brodescription ,a.broname ,a.broscope ,a.brotype ,a.clsid ,
		a.clsname ,a.customername ,a.dllname ,a.ecrno ,a.progid ,
		a.projectname ,a.systemgenerated , a.componentname ,a.processname
from 	de_fw_des_publish_bro a (nolock)

GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_publish_bro_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_publish_bro_vw TO PUBLIC
END
GO


