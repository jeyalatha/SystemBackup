IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_publish_service_segment_copy' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_publish_service_segment_copy
    End
Go


create view  [de_fw_des_publish_service_segment_copy]        
		as              
		select bocode,bosegmentname,componentname,createdby,createddate,customername,ecrno,instanceflag,mandatoryflag,modifiedby,modifieddate,parentsegmentname,process_selrows,process_updrows,processname,projectname,segmentname,servicename,timestamp,updtime,upduser from rvw20appdb.dbo.de_fw_des_publish_service_segment_copy a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_publish_service_segment_copy' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_publish_service_segment_copy TO PUBLIC
END
GO


