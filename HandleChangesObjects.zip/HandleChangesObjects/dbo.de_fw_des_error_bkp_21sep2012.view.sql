IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_error_bkp_21sep2012' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_error_bkp_21sep2012
    End
Go


create view  [de_fw_des_error_bkp_21sep2012]        
		as              
		select componentname,createdby,createddate,customer_name,defaultcorrectiveaction,defaultseverity,detaileddesc,displaytype,ecrno,errorid,errormessage,errorsource,modifiedby,modifieddate,process_name,project_name,reqerror,timestamp,updtime,upduser from rvw20appdb.dbo.de_fw_des_error_bkp_21sep2012 a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_error_bkp_21sep2012' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_error_bkp_21sep2012 TO PUBLIC
END
GO


