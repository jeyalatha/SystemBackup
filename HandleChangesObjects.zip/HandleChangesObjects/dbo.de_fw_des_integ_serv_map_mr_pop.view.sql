IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_integ_serv_map_mr_pop' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_integ_serv_map_mr_pop
    End
Go


create view  [de_fw_des_integ_serv_map_mr_pop]        
		as              
		select callingdataitem,callingsegment,callingservicename,component_name,createdby,createddate,Customer_Name,integdataitem,integsegment,integservicename,mig_id,modifiedby,modifieddate,process_name,Project_Name,sectionname,sequenceno,timestamp,updtime,upduser from rvw20appdb.dbo.de_fw_des_integ_serv_map_mr_pop a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_integ_serv_map_mr_pop' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_integ_serv_map_mr_pop TO PUBLIC
END
GO


