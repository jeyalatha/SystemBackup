IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='De_DefService_vw' AND TYPE = 'V')
    Begin
        Drop View De_DefService_vw
    End
Go



	/*	Creating View Script - De_DefService_vw on 	Jun 26 2005 11:46PM		*/	
-- Created by  :  Venkitesh
-- Desc  : For Fetching the data from Workflow input (From RE)
/********************************************************************************/
/* modified by  Savitha                                                         */
/* date         19-Aug-2005                                                     */
/* description  changed the table names                                         */
/********************************************************************************/

CREATE view [De_DefService_vw] as
select 
   a.customer_code,a.project_code,
   a.area_code,
   c.component_name,
   c.activity_name,c.task_name,
   a.sequence_no,wf_code_description
  from 
   de_wsinp_service_dtl a(nolock),
   re_wsinp_qc_lang_dtl b(Nolock),
   re_wsinp_cat_Hdr c(nolock)
  Where
   a.customer_code  = c.customer_code
  and a.project_code  = c.project_code
  and a.area_code  = c.area_code
and	a.component_name 	= c.component_name
and	a.activity_name		= c.activity_name
and a.task_name		= c.task_name
--  and a.cat_key   = c.cat_key 
  and b.wf_Quick_Code_type = 'Sern'
  and a.service_name  = b.wf_quick_code

GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'De_DefService_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  De_DefService_vw TO PUBLIC
END
GO


