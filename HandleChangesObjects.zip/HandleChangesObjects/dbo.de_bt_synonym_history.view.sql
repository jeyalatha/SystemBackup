IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_bt_synonym_history' AND TYPE = 'V')
    Begin
        Drop View de_bt_synonym_history
    End
Go


create view  [de_bt_synonym_history]        
		as              
		select activity_name,component_name,createdby,createddate,current_bt_synonym,customer_name,ecrno,modifiedby,modifieddate,new_bt_synonym,old_bt_synonym,page_bt_synonym,process_name,project_name,section_bt_synonym,timestamp,ui_name from rvw20appdb.dbo.de_bt_synonym_history a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_bt_synonym_history' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_bt_synonym_history TO PUBLIC
END
GO


