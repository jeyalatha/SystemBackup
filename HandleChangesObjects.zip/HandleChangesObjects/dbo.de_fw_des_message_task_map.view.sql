IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_message_task_map' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_message_task_map
    End
Go



create view  [de_fw_des_message_task_map]        
		as              
		select activity_name,component_name,createdby,createddate,Customer_name,ecrno,HlpAssociatedcontrol,maptask_Descr,maptask_name,maptask_type,MessageDesc,MessageID,modifiedby,modifieddate,process_name,Project_name,taskname,timestamp,ui_name from rvw20appdb
.dbo.de_fw_des_message_task_map a (nolock)

GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_message_task_map' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_message_task_map TO PUBLIC
END
GO


