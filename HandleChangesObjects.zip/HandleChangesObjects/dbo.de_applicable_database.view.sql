IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_applicable_database' AND TYPE = 'V')
    Begin
        Drop View de_applicable_database
    End
Go


create view  [de_applicable_database]              
			(component_name,createdby,createddate,customer_name,db_name,db_sysid,modifiedby,modifieddate,process_name,project_name,timestamp)        
			as              
			select component_name,createdby,createddate,customer_name,db_name,db_sysid,modifiedby,modifieddate,process_name,project_name,timestamp from rvw20appdb.dbo.de_applicable_database (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_applicable_database' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_applicable_database TO PUBLIC
END
GO


