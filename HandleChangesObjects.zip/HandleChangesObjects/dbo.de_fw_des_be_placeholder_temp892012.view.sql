IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_be_placeholder_temp892012' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_be_placeholder_temp892012
    End
Go


create view  [de_fw_des_be_placeholder_temp892012]        
		as              
		select component_name,createdby,createddate,customer_name,dna_parametername,ecrno,errorid,method_name,methodid,modifiedby,modifieddate,parametername,placeholdername,process_name,project_name,timestamp,updtime,upduser from rvw20appdb.dbo.de_fw_des_be_placeholder_temp892012 a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_be_placeholder_temp892012' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_be_placeholder_temp892012 TO PUBLIC
END
GO


