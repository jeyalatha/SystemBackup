IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_context' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_context
    End
Go


create view  [de_fw_des_context]              
					as              
					select componentname 'component_name' ,correctiveaction,createdby,createddate,customername 'customer_name' ,ecrno,errorcontext,errorid,modifiedby,modifieddate,processname 'process_name' ,projectname 'project_name' ,severityid,timestamp,updtime,upduser from rvw_publish_db.dbo.de_fw_des_publish_context a (nolock)        
					where exists (select 'x' from De_Customer_Space b (nolock)        
					where     a.customername   = b.customername        
					and       a.projectname    = b.projectname        
					and       a.processname    = b.processname        
					and       a.componentname  = b.componentname    
					and       a.ecrno        = b.ecrno )
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_context' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_context TO PUBLIC
END
GO


