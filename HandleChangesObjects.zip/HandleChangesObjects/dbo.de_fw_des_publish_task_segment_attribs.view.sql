IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_publish_task_segment_attribs' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_publish_task_segment_attribs
    End
Go


create view  [de_fw_des_publish_task_segment_attribs]              
			(activityid,combofill,componentname,createdby,createddate,customername,displayflag,ecrno,ilbocode,modifiedby,modifieddate,processname,projectname,segmentname,servicename,taskname,timestamp)        
			as              
			select activityid,combofill,componentname,createdby,createddate,customername,displayflag,ecrno,ilbocode,modifiedby,modifieddate,processname,projectname,segmentname,servicename,taskname,timestamp from rvw20appdb.dbo.de_fw_des_publish_task_segment_attribs (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_publish_task_segment_attribs' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_publish_task_segment_attribs TO PUBLIC
END
GO


