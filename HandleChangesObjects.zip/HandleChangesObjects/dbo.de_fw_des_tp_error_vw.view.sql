IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_tp_error_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_tp_error_vw
    End
Go


 
	/*	Creating View Script - de_fw_des_tp_error_vw on 	Jun 26 2005 11:46PM		*/	

create view [de_fw_des_tp_error_vw]
as
select 	a.customer_name		as  'customer_name',
		a.project_name		as	'project_name',
		a.process_name		as  'process_name',
		a.component_name  	as 	'component_name',
		a.activity_name  	as 	'activity_name',
		a.ui_name 			as 	'Ilbocode',
		a.task_name			as	'task_name',
		c.methodid			as	'methodid',
		d.errorid			as 	'errorid',
		e.errormessage		as	'errormessage',
		e.defaultseverity	as	'severityid',
		f.quick_code_value	as	'severitydescr'
from 	de_action						a (nolock),
		de_task_service_map				b (nolock),
		de_fw_des_processsection_br_is	c (nolock),
		de_fw_des_brerror 				d (nolock),
		de_fw_des_error					e (nolock),
		de_quick_code_mst				f (nolock)
where 	a.customer_name 	= 	b.customer_name 
and 	a.project_name  	= 	b.project_name
and 	a.process_name  	= 	b.process_name
and 	a.component_name	= 	b.component_name
and 	a.activity_name 	=	b.activity_name	
and		a.ui_name			=	b.ui_name 
and 	a.task_name			=	b.task_name
and		b.customer_name		=	c.customer_name
and		b.project_name		=	c.project_name
and		b.process_name		=	c.process_name
and		b.component_name	=	c.component_name
and		b.service_name		=	c.servicename
and		c.customer_name		=	d.customer_name
and		c.project_name		=	d.project_name
and		c.process_name		=	d.process_name
and		c.component_name	=	d.component_name
and		c.methodid			=	d.methodid
and		c.method_name		=	d.method_name
and		d.customer_name		=	e.customer_name
and		d.project_name		=	e.project_name
and		d.process_name		=	e.process_name
and		d.component_name	=	e.componentname
and 	d.errorid			=	e.errorid
and		f.quick_code		= 	e.defaultseverity
and		f.quick_code_type 	= 'ERROR_SEVERITY'

GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_tp_error_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_tp_error_vw TO PUBLIC
END
GO


