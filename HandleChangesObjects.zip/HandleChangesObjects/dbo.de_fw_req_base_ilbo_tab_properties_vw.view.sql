IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_base_ilbo_tab_properties_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_base_ilbo_tab_properties_vw
    End
Go



/************************************************************************************    
procedure name and id   de_fw_req_base_ilbo_tab_properties_vw
description             
name of the author      BharathiDasan.V.V
date created            16-07-2007
query file name         de_fw_req_base_ilbo_tab_properties_vw
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/  
Create view [de_fw_req_base_ilbo_tab_properties_vw]
	 (	componentname ,	customername ,	ilbocode ,	processname ,	projectname ,
		propertyname ,	tabname ,		value ) 
as 
select 	component_name,	customer_name ,	ilbocode ,	process_name ,	project_name ,
		propertyname ,	tabname ,		value 
from 	de_fw_req_ilbo_tab_properties (nolock)





GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_base_ilbo_tab_properties_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_base_ilbo_tab_properties_vw TO PUBLIC
END
GO


