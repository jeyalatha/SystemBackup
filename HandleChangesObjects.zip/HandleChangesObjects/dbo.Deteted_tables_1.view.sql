IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='Deteted_tables_1' AND TYPE = 'V')
    Begin
        Drop View Deteted_tables_1
    End
Go


create view  [Deteted_tables_1]        
		as              
		select data,index_size,name,reserved,rows,unused from rvw20appdb.dbo.Deteted_tables_1 a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'Deteted_tables_1' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  Deteted_tables_1 TO PUBLIC
END
GO


