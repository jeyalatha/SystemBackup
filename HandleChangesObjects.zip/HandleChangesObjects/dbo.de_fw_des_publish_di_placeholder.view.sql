IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_publish_di_placeholder' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_publish_di_placeholder
    End
Go


create view  [de_fw_des_publish_di_placeholder]              
			(componentname,createdby,createddate,customername,dataitemname,ecrno,errorid,method_name,methodid,modifiedby,modifieddate,placeholdername,processname,projectname,sectionname,segmentname,sequenceno,servicename,timestamp,updtime,upduser)        
			as              
			select componentname,createdby,createddate,customername,dataitemname,ecrno,errorid,method_name,methodid,modifiedby,modifieddate,placeholdername,processname,projectname,sectionname,segmentname,sequenceno,servicename,timestamp,updtime,upduser from rvw20appdb.dbo.de_fw_des_publish_di_placeholder (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_publish_di_placeholder' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_publish_di_placeholder TO PUBLIC
END
GO


