IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='dec14' AND TYPE = 'V')
    Begin
        Drop View dec14
    End
Go


create view  [dec14]        
		as              
		select ControlCaption,ControlName,ControlType,NewPageName,NewSectionName,PageName,SectionCaption,SectionName from rvw20appdb.dbo.dec14 a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'dec14' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  dec14 TO PUBLIC
END
GO


