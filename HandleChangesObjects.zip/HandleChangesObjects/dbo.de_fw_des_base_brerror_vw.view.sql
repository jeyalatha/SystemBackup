IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_base_brerror_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_base_brerror_vw
    End
Go



/************************************************************************************    
Creating View Script 	de_fw_des_base_brerror_vw
procedure name and id   de_fw_des_base_brerror_vw
description             
name of the author      BharathiDasan.V.V
date created            13-07-2007    	
modifications history       
modified by                 
modified date               
modified purpose            
**************************************************************************************/  

create view [de_fw_des_base_brerror_vw] 
		(componentname ,	customername ,	errorid ,	methodid ,
		processname ,		projectname ,	sperrorcode ) 
as 
select 	component_name ,	customer_name ,	errorid ,	methodid ,
		process_name ,		project_name ,	sperrorcode 
from 	de_fw_des_brerror (nolock)
union 
select 	componentname ,	customer_name ,	errorid ,	0 ,
		process_name ,		project_name ,	convert(varchar(20),errorid)
from 	de_fw_des_error a (nolock)
where 	not exists (select 	's'
					from 	de_fw_des_brerror b (nolock)
					where	a.customer_name		= 	b.customer_name
					and		a.project_name		= 	b.project_name
					and 	a.process_name 		= 	b.process_name
					and 	a.componentname		= 	b.component_name 
					and		a.errorid			= 	b.errorid 
				   )
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_base_brerror_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_base_brerror_vw TO PUBLIC
END
GO


