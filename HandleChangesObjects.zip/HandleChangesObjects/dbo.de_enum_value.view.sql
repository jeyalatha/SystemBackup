IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_enum_value' AND TYPE = 'V')
    Begin
        Drop View de_enum_value
    End
Go


create view  [de_enum_value]              
					(activity_name,component_name,control_bt_synonym,createdby,createddate,customer_name,default_flag,ecrno,enum_caption,enum_code,enum_value_sysid,modifiedby,modifieddate,page_bt_synonym,process_name,project_name,req_no,section_bt_synonym,seq_no,timestamp,ui_name,ui_page_sysid)          
					as              
					select activity_name,component_name,control_bt_synonym,createdby,createddate,customer_name,default_flag,ecrno,enum_caption,enum_code,enum_value_sysid,modifiedby,modifieddate,page_bt_synonym,process_name,project_name,req_no,section_bt_synonym,seq_no,timestamp,ui_name,ui_page_sysid from rvw_publish_db.dbo.de_published_enum_value a (nolock)        
					where exists (select 'x' from De_Customer_Space b (nolock)        
					where     a.customer_name   = b.customername        
					and       a.project_name    = b.projectname        
					and       a.process_name    = b.processname        
					and       a.component_name  = b.componentname    
					and       a.ecrno        = b.ecrno )
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_enum_value' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_enum_value TO PUBLIC
END
GO


