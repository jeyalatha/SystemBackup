IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_base_bterm_enumerated_option_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_base_bterm_enumerated_option_vw
    End
Go



/************************************************************************************    
procedure name and id   de_fw_req_base_bterm_enumerated_option_vw
description             
name of the author      BharathiDasan.V.V
date created            16-07-2007
query file name         de_fw_req_base_bterm_enumerated_option_vw
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/  
create view [de_fw_req_base_bterm_enumerated_option_vw] 
	 (	btname ,		componentname ,	customername ,	langid ,	optioncode ,	optiondesc ,
		processname,	projectname ,	sequenceno ) 
as 
select 	btname ,		component_name,	customer_name ,	langid ,	optioncode ,	optiondesc ,
		process_name ,	project_name ,	sequenceno 
from 	de_fw_req_bterm_enumerated_option (nolock)





GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_base_bterm_enumerated_option_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_base_bterm_enumerated_option_vw TO PUBLIC
END
GO


