IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='Ce_method_doc_vw' AND TYPE = 'V')
    Begin
        Drop View Ce_method_doc_vw
    End
Go


 
	/*	Creating View Script - Ce_method_doc_vw on 	Jun 26 2005 11:46PM		*/	

/************************************************************************************
procedure name and id   Ce_method_doc_vw
description             
name of the author      
date created            
query file name         Ce_method_doc_vw.sql
modifications history   
modified by             
modified date           
modified purpose        
************************************************************************************/

CREATE VIEW [Ce_method_doc_vw]
AS select customer_name, project_name, process_name, component_name ,method_name, doctext
from de_fw_des_br_documentation (nolock)

GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'Ce_method_doc_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  Ce_method_doc_vw TO PUBLIC
END
GO


