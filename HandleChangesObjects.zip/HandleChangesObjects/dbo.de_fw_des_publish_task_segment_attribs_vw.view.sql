IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_publish_task_segment_attribs_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_publish_task_segment_attribs_vw
    End
Go



/************************************************************************************    
procedure name and id   de_fw_des_publish_task_segment_attribs_vw
description             The View used for Launch Pad
name of the author          
date created                
query file name         de_fw_des_publish_task_segment_attribs_vw
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/  
Create view [de_fw_des_publish_task_segment_attribs_vw]
	(	customername,	projectname,	processname,	componentname,
		ecrno,			activityid, 	ilbocode,		taskname,
		servicename,	segmentname,	combofill,		displayflag) 
as 
select	a.customername,	a.projectname,	a.processname,	a.componentname,
		a.ecrno,		a.activityid, 	a.ilbocode,		a.taskname,
		a.servicename,	a.segmentname,	1,				a.displayflag
    from de_fw_des_publish_task_segment_attribs a(nolock)		
-- from	de_fw_des_publish_ilbo_service_view_datamap a (nolock),
-- 		de_fw_req_publish_ilbo_control_property		b (nolock),
-- 		de_fw_req_publish_ilbo_control				c (nolock),
-- 		-- code added by Ganesh for the callid :: PNR2.0_3557 on 22/08/04
-- 		de_fw_req_publish_ilbo_view					d (nolock)
-- where	a.customername		= b.customername
-- and		a.projectname		= b.projectname
-- and		a.processname		= b.processname
-- and		a.componentname		= b.componentname
-- and		a.ecrno				= b.ecrno
-- and		a.ilbocode			= b.ilbocode
-- and		a.controlid			= b.controlid
-- and		a.viewname			= b.viewname
-- 
-- and		b.propertyname 		= 'ColumnType'
-- and		b.value 			= 'ComboBox'
-- 
-- and		b.customername		= c.customername
-- and		b.projectname		= c.projectname
-- and		b.processname		= c.processname
-- and		b.componentname		= c.componentname
-- and		b.ecrno				= c.ecrno
-- and		b.ilbocode			= c.ilbocode
-- and		b.controlid			= c.controlid
-- 
-- and		a.customername		= d.customername
-- and		a.projectname		= d.projectname
-- and		a.processname		= d.processname
-- and		a.componentname		= d.componentname
-- and		a.ecrno				= d.ecrno
-- and		a.ilbocode			= d.ilbocode
-- and		a.controlid			= d.controlid
-- and		a.viewname			= d.viewname
-- and		d.displayflag		= 'T'
-- 
-- and		c.type				= 'RSGrid'
-- -- code modified by Ganesh on 13/4/05 for the bugid :: PNR2.0_1634
-- -- For multi line combo segment issue
-- and   	exists( select 	'x' 
-- 				from 	de_fw_des_publish_ilbo_service_view_datamap dm (nolock),
-- 						de_fw_req_publish_ilbo_view 				ctl (nolock)		
-- 				where	dm.customername			= a.customername
-- 				and		dm.projectname			= a.projectname
-- 				and		dm.processname			= a.processname
-- 				and		dm.componentname		= a.componentname
-- 				and		dm.ecrno				= a.ecrno
-- 				and		dm.ilbocode				= a.ilbocode
-- 				and 	dm.segmentname			= a.segmentname
-- 			/* Code Modified by Balaji S on 01/06/2005 For Bug Id : PNR2.0_2658 */
-- 				and		dm.servicename			= a.servicename
-- 				and		dm.taskname				= a.taskname
-- 
-- 				and		dm.customername			= ctl.customername
-- 				and		dm.projectname			= ctl.projectname
-- 				and		dm.processname			= ctl.processname
-- 				and		dm.componentname		= ctl.componentname
-- 				and		dm.ecrno				= ctl.ecrno
-- 				and		dm.ilbocode				= ctl.ilbocode
-- 				and		dm.controlid			= ctl.controlid
-- 				and		dm.viewname				= ctl.viewname
-- 				group by dm.customername, 	dm.projectname, 	dm.processname	,	
-- 						 dm.componentname,	dm.ecrno,			dm.ilbocode,
-- 						 dm.segmentname,	ctl.customername,	ctl.projectname	,
-- 						 ctl.processname,	ctl.componentname,	ctl.ecrno,			
-- 						 ctl.ilbocode,		ctl.viewname
-- 				having count(*) = 1)
-- and 	not exists ( 
-- 		select	'x'
-- 		from	de_fw_des_publish_ilbo_service_view_datamap vd (nolock),
-- 				de_fw_req_publish_ilbo_control_property		cp (nolock)
-- 		where	vd.customername		= cp.customername
-- 		and		vd.projectname		= cp.projectname
-- 		and		vd.processname		= cp.processname
-- 		and		vd.componentname	= cp.componentname
-- 		and		vd.ecrno			= cp.ecrno
-- 		and		vd.ilbocode			= cp.ilbocode
-- 		and		vd.controlid		= cp.controlid
-- 		and		vd.viewname			= cp.viewname
-- 		and 	vd.customername		= a.customername
-- 		and		vd.projectname		= a.projectname
-- 		and		vd.processname		= a.processname
-- 		and		vd.componentname	= a.componentname
-- 		and		vd.ecrno			= a.ecrno
-- 		and		vd.ilbocode			= a.ilbocode
-- 		and 	vd.segmentname 		= a.segmentname
-- 		and		cp.propertyname 	= 'ColumnType'
-- 		and		cp.value 			<> 'ComboBox')
-- 
-- group by	a.customername,	a.projectname,	a.processname,	a.componentname,
-- 			a.ecrno,		a.activityid, 	a.ilbocode,		a.taskname,
-- 			a.servicename,	a.segmentname,	a.controlid,	d.displayflag
-- having count(*) = 1
-- union
-- -- code Added by Ganesh for the bugid :: pnr2.0_2874 on 16/06/05
-- -- To add the Header combo load.
-- select	b.customername,	b.projectname,	b.processname,	b.componentname,
-- 		b.ecrno,		b.activityid, 	b.ilbocode,		b.taskname,
-- 		b.servicename,	b.segmentname,	1,				'T'
-- from	de_fw_des_publish_service_segment			a (nolock),
-- 		de_fw_des_publish_ilbo_service_view_datamap	b (nolock),
-- 		de_published_ui_control						c (nolock),
-- 		es_comp_ctrl_type_mst						d (nolock)
-- where	a.customername		= b.customername
-- and		a.projectname		= b.projectname
-- and		a.processname		= b.processname
-- and		a.componentname		= b.componentname
-- and		a.ecrno				= b.ecrno
-- and		a.servicename		= b.servicename
-- and		a.segmentname		= b.segmentname
-- 
-- and		b.customername		= c.customer_name
-- and		b.projectname		= c.project_name
-- and		b.processname		= c.process_name
-- and		b.componentname		= c.component_name
-- and		b.ecrno				= c.ecrno
-- and		b.ilbocode			= c.ui_name
-- and		b.controlid			= c.control_id
-- and		b.viewname			= c.view_name
-- 
-- and		c.customer_name		= c.customer_name
-- and		c.project_name		= c.project_name
-- and		c.process_name		= c.process_name
-- and		c.component_name	= d.component_name
-- and		c.control_type		= d.ctrl_type_name
-- and		d.base_ctrl_type	= 'Combo'
-- and		a.instanceflag		= 1
-- group by 	b.customername,	b.projectname,	b.processname,	b.componentname,
-- 			b.ecrno,		b.activityid, 	b.ilbocode,		b.taskname,
-- 			b.servicename,	b.segmentname
-- having count(*) = 1






GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_publish_task_segment_attribs_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_publish_task_segment_attribs_vw TO PUBLIC
END
GO


