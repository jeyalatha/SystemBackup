IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_activity_ilbo_task' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_activity_ilbo_task
    End
Go


CREATE view  [de_fw_req_activity_ilbo_task]                
     as                
     select activity_name,activityid,componentname 'component_name' ,createdby,createddate,customername 'customer_name' ,datasavingtask,ecrno,ilbocode,linktype,modifiedby,modifieddate,processname 'process_name' ,projectname 'project_name' ,Taskconfirmation,taskname,timestamp,updtime,upduser,Autoupload from rvw_publish_db.dbo.de_fw_req_publish_activity_ilbo_task a (nolock)          
     where exists (select 'x' from De_Customer_Space b (nolock)          
     where     a.customername   = b.customername          
     and       a.projectname    = b.projectname          
     and       a.processname    = b.processname          
     and       a.componentname  = b.componentname      
     and       a.ecrno        = b.ecrno )
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_activity_ilbo_task' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_activity_ilbo_task TO PUBLIC
END
GO


