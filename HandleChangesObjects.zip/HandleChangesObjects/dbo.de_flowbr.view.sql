IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_flowbr' AND TYPE = 'V')
    Begin
        Drop View de_flowbr
    End
Go


create view  [de_flowbr]              
					(activity_name,component_name,control_id,createdby,createddate,customer_name,ecrno,event_name,flowbr_descr,flowbr_name,flowbr_sequence,flowbr_sysid,map_flag,modifiedby,modifieddate,page_bt_synonym,process_name,project_name,task_name,task_sysid,timestamp,ui_name,view_name)          
					as              
					select activity_name,component_name,control_id,createdby,createddate,customer_name,ecrno,event_name,flowbr_descr,flowbr_name,flowbr_sequence,flowbr_sysid,map_flag,modifiedby,modifieddate,page_bt_synonym,process_name,project_name,task_name,task_sysid,timestamp,ui_name,view_name from rvw_publish_db.dbo.de_published_flowbr a (nolock)        
					where exists (select 'x' from De_Customer_Space b (nolock)        
					where     a.customer_name   = b.customername        
					and       a.project_name    = b.projectname        
					and       a.process_name    = b.processname        
					and       a.component_name  = b.componentname    
					and       a.ecrno        = b.ecrno )
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_flowbr' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_flowbr TO PUBLIC
END
GO


