IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_errbtn_local_info' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_errbtn_local_info
    End
Go


create view  [de_fw_des_errbtn_local_info]        
		as              
		select buttontext,component_name,createdby,createddate,customer_name,langid,modifiedby,modifieddate,process_name,project_name,severitydesc,severityid,timestamp,updtime,upduser from rvw20appdb.dbo.de_fw_des_errbtn_local_info a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_errbtn_local_info' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_errbtn_local_info TO PUBLIC
END
GO


