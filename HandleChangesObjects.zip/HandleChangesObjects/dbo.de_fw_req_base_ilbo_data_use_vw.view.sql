IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_base_ilbo_data_use_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_base_ilbo_data_use_vw
    End
Go



/************************************************************************************    
procedure name and id   de_fw_req_base_ilbo_data_use_vw
description             
name of the author      BharathiDasan.V.V
date created            16-07-2007                
query file name         de_fw_req_base_ilbo_data_use_vw
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/  
create view [de_fw_req_base_ilbo_data_use_vw] 
	 (	childilbocode ,	componentname ,	controlid ,		controlvariablename ,	customername ,
		dataitemname ,	flowtype ,		iscontrol ,		linkid ,				parentilbocode ,
		primarydata ,	processname ,	projectname ,	retrievemultiple ,		taskname ,
		viewname ) 
as 
select 	childilbocode ,	component_name,	controlid ,		controlvariablename ,	customer_name ,
		dataitemname ,	flowtype ,		iscontrol ,		linkid ,				parentilbocode ,
		primarydata ,	process_name ,	project_name ,	retrievemultiple ,		taskname ,
		viewname 
from 	de_fw_req_ilbo_data_use (nolock)





GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_base_ilbo_data_use_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_base_ilbo_data_use_vw TO PUBLIC
END
GO


