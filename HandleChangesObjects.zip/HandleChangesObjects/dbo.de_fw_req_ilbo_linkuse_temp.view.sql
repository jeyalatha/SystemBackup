IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_ilbo_linkuse_temp' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_ilbo_linkuse_temp
    End
Go


create view  [de_fw_req_ilbo_linkuse_temp]        
		as              
		select childilbocode,childorder,component_name,createdby,createddate,customer_name,link_name,linkid,modifiedby,modifieddate,new_linkid,parentilbocode,process_name,project_name,taskname,timestamp,updtime,upduser from rvw20appdb.dbo.de_fw_req_ilbo_linkuse_temp a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_ilbo_linkuse_temp' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_ilbo_linkuse_temp TO PUBLIC
END
GO


