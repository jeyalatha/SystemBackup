IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_ezeeview_sp' AND TYPE = 'V')
    Begin
        Drop View de_ezeeview_sp
    End
Go


create view  [de_ezeeview_sp]        
		as              
		select activity_name,component_name,createdby,createddate,customer_name,ecrno,Link_Caption,Link_ControlName,Linked_Activity,Linked_Component,Linked_Task,Linked_ui,modifiedby,modifieddate,page_bt_synonym,process_name,project_name,Target_SPName,timestamp,ui_name from rvw20appdb.dbo.de_ezeeview_sp a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_ezeeview_sp' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_ezeeview_sp TO PUBLIC
END
GO


