IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_ilbo_view_bkp_13dec2013' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_ilbo_view_bkp_13dec2013
    End
Go


create view  [de_fw_req_ilbo_view_bkp_13dec2013]        
		as              
		select btsynonym,component_name,control_bt_synonym,controlid,createdby,createddate,customer_name,displayflag,displaylength,ecrno,ilbocode,listedit,modifiedby,modifieddate,page_bt_synonym,process_name,project_name,timestamp,updtime,upduser,viewname from rvw20appdb.dbo.de_fw_req_ilbo_view_bkp_13dec2013 a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_ilbo_view_bkp_13dec2013' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_ilbo_view_bkp_13dec2013 TO PUBLIC
END
GO


