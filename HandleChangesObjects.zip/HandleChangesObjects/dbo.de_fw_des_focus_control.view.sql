IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_focus_control' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_focus_control
    End
Go


create view  [de_fw_des_focus_control]              
					(component_name,controlid,createdby,createddate,customer_name,ecrno,errorcontext,errorid,focusdataitem,modifiedby,modifieddate,process_name,project_name,segmentname)          
					as              
					select component_name,controlid,createdby,createddate,customer_name,ecrno,errorcontext,errorid,focusdataitem,modifiedby,modifieddate,process_name,project_name,segmentname from rvw_publish_db.dbo.de_fw_des_publish_focus_control a (nolock)        
					where exists (select 'x' from De_Customer_Space b (nolock)        
					where     a.customer_name   = b.customername        
					and       a.project_name    = b.projectname        
					and       a.process_name    = b.processname        
					and       a.component_name  = b.componentname    
					and       a.ecrno        = b.ecrno )
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_focus_control' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_focus_control TO PUBLIC
END
GO


