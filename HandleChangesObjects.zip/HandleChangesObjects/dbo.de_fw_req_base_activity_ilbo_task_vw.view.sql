IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_base_activity_ilbo_task_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_base_activity_ilbo_task_vw
    End
Go



/************************************************************************************    
procedure name and id   de_fw_req_base_activity_ilbo_task_vw
description             
name of the author      BharathiDasan.V.V
date created            16-07-2007                
query file name         de_fw_req_base_activity_ilbo_task_vw
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/  
Create view 	[de_fw_req_base_activity_ilbo_task_vw] 
	 (	activityid ,		componentname ,		customername ,		datasavingtask ,	ilbocode ,
		linktype ,			processname ,		projectname, 		taskname, 			activityname, 
		Taskconfirmation ) 
as 
select 	b.activityid ,		a.component_name ,	a.customer_name ,	a.datasavingtask ,	a.ilbocode ,
		a.linktype ,		a.process_name ,	a.project_name ,	a.taskname ,		b.activityname, 
		a.Taskconfirmation
from 	de_fw_req_activity_ilbo_task 	A (nolock),
		de_fw_req_activity 				B (nolock)
where	A.customer_name 	= b.customer_name
and		a.project_name 		= b.project_name
and		a.component_name 	= b.componentname
and 	a.activityid		= b.activityid
and		a.process_name		= b.process_name
and		exists(	select	'A'
				from	de_fw_req_ilbo_control	c (nolock)
				where	c.customer_name 	= b.customer_name
				and		c.project_name 		= b.project_name
				and		c.process_name		= b.process_name
				and		c.component_name 	= b.componentname
				and		c.ilbocode			= a.ilbocode)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_base_activity_ilbo_task_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_base_activity_ilbo_task_vw TO PUBLIC
END
GO


