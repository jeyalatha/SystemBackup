IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_processsection_br_is_mr_pop_bkp' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_processsection_br_is_mr_pop_bkp
    End
Go


create view  [de_fw_des_processsection_br_is_mr_pop_bkp]        
		as              
		select component_name,connectivityflag,controlexpression,createdby,createddate,Customer_Name,executionflag,integservicename,isbr,method_name,methodid,modifiedby,modifieddate,process_name,Project_Name,sectionname,sequenceno,servicename,timestamp,updtime,upduser from rvw20appdb.dbo.de_fw_des_processsection_br_is_mr_pop_bkp a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_processsection_br_is_mr_pop_bkp' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_processsection_br_is_mr_pop_bkp TO PUBLIC
END
GO


