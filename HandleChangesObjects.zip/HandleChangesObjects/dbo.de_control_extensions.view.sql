IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_control_extensions' AND TYPE = 'V')
    Begin
        Drop View de_control_extensions
    End
Go


create view  [de_control_extensions]              
					(activity_name,component_name,control_bt_synonym,controlextension_name,controlextension_seq,createdby,createddate,customer_name,ecrno,extend_as,image_path,linked_activityname,linked_componentname,linked_uiname,modifiedby,modifieddate,page_bt_synonym,process_name,project_name,req_no,section_name,source_from,subscription_name,task_description,task_name,task_type,tooltiptext,ui_name)          
					as              
					select activity_name,component_name,control_bt_synonym,controlextension_name,controlextension_seq,createdby,createddate,customer_name,ecrno,extend_as,image_path,linked_activityname,linked_componentname,linked_uiname,modifiedby,modifieddate,page_bt_synonym,process_name,project_name,req_no,section_name,source_from,subscription_name,task_description,task_name,task_type,tooltiptext,ui_name from rvw_publish_db.dbo.de_published_control_extensions a (nolock)        
					where exists (select 'x' from De_Customer_Space b (nolock)        
					where     a.customer_name   = b.customername        
					and       a.project_name    = b.projectname        
					and       a.process_name    = b.processname        
					and       a.component_name  = b.componentname    
					and       a.ecrno        = b.ecrno )
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_control_extensions' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_control_extensions TO PUBLIC
END
GO


