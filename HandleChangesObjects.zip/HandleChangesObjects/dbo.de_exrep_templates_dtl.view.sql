IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_exrep_templates_dtl' AND TYPE = 'V')
    Begin
        Drop View de_exrep_templates_dtl
    End
Go


create view  [de_exrep_templates_dtl]        
		as              
		select activity_name,component_name,createdby,createddate,customer_name,modifiedby,modifieddate,process_name,project_name,sheet_caption,sheet_id,template_id,ui_name from rvw20appdb.dbo.de_exrep_templates_dtl a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_exrep_templates_dtl' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_exrep_templates_dtl TO PUBLIC
END
GO


