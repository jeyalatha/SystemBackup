IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_err_det_local_info_bkp_apr042012' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_err_det_local_info_bkp_apr042012
    End
Go


create view  [de_fw_des_err_det_local_info_bkp_apr042012]        
		as              
		select component_name,createdby,createddate,customer_name,detaileddesc,ecrno,errorid,errormessage,langid,modifiedby,modifieddate,process_name,project_name,timestamp,updtime,upduser from rvw20appdb.dbo.de_fw_des_err_det_local_info_bkp_apr042012 a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_err_det_local_info_bkp_apr042012' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_err_det_local_info_bkp_apr042012 TO PUBLIC
END
GO


