IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_ext_js_control' AND TYPE = 'V')
    Begin
        Drop View de_ext_js_control
    End
Go


create view  [de_ext_js_control]        
		as              
		select activity_name,Callout_Task,component_name,control_bt_synonym,Control_Class,createdby,createddate,Ctrl_height,ctrl_width,customer_name,ecr_no,Extjs_Ctrl_type,Fade_Delay,Fade_Direction,feature_name,Loop_Count,modifiedby,modifieddate,page_bt_synonym,process_name,project_name,RVW_Task,sample_data,section_bt_synonym,Type_Delay,Type_Direction,ui_name from rvw20appdb.dbo.de_ext_js_control a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_ext_js_control' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_ext_js_control TO PUBLIC
END
GO


