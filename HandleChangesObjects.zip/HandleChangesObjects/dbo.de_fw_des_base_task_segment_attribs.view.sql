IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_base_task_segment_attribs' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_base_task_segment_attribs
    End
Go


create view  [de_fw_des_base_task_segment_attribs]        
		as              
		select activityid,combofill,component_name,createdby,createddate,customer_name,displayflag,ilbocode,modifiedby,modifieddate,process_name,project_name,segmentname,servicename,taskname,timestamp from rvw20appdb.dbo.de_fw_des_base_task_segment_attribs a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_base_task_segment_attribs' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_base_task_segment_attribs TO PUBLIC
END
GO


