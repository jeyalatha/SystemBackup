IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_ilbo_data_publish' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_ilbo_data_publish
    End
Go


create view  [de_fw_req_ilbo_data_publish]              
					as              
					select componentname 'component_name' ,controlid,controlvariablename,createdby,createddate,customername 'customer_name' ,dataitemname,ecrno,flowtype,havemultiple,ilbocode,iscontrol,link_name,linkid,mandatoryflag,modifiedby,modifieddate,processname 'process_name' ,projectname 'project_name' ,timestamp,updtime,upduser,viewname from rvw_publish_db.dbo.de_fw_req_publish_ilbo_data_publish a (nolock)        
					where exists (select 'x' from De_Customer_Space b (nolock)        
					where     a.customername   = b.customername        
					and       a.projectname    = b.projectname        
					and       a.processname    = b.processname        
					and       a.componentname  = b.componentname    
					and       a.ecrno        = b.ecrno )
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_ilbo_data_publish' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_ilbo_data_publish TO PUBLIC
END
GO


