IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_base_ilbo_service_view_datamap_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_base_ilbo_service_view_datamap_vw
    End
Go



/************************************************************************************    
procedure name and id   de_fw_des_base_ilbo_service_view_datamap_vw
description              
name of the author      BharathiDasan.V.V
date created            16-07-2007                
query file name         de_fw_des_base_ilbo_service_view_datamap_vw
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/  
create view [de_fw_des_base_ilbo_service_view_datamap_vw] 
	 (	activityid ,	componentname ,		controlid ,		customername ,	dataitemname,
		ilbocode ,		iscontrol ,			processname ,	projectname ,	segmentname ,
		servicename ,	taskname ,			variablename ,	viewname ) 
as
select 	activityid ,	a.component_name,	a.controlid ,	a.customer_name,	a.dataitemname ,
		a.ilbocode ,	a.iscontrol ,		a.process_name,	a.project_name ,	a.segmentname ,
		a.servicename ,	a.taskname ,		a.variablename,	a.viewname 
from 	de_fw_des_ilbo_service_view_datamap a (nolock),
		de_fw_req_ilbo_view	b (nolock)
where	a.customer_name		= b.customer_name
and		a.project_name		= b.project_name
and		a.process_name		= b.process_name
and		a.component_name	= b.component_name
and		a.ilbocode			= b.ilbocode
and		a.controlid			= b.controlid
and		a.viewname			= b.viewname





GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_base_ilbo_service_view_datamap_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_base_ilbo_service_view_datamap_vw TO PUBLIC
END
GO


