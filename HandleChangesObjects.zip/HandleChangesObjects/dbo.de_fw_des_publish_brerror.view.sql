IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_publish_brerror' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_publish_brerror
    End
Go


create view  [de_fw_des_publish_brerror]              
			(componentname,createdby,createddate,customername,ecrno,error_context,errorid,method_name,methodid,modifiedby,modifieddate,processname,projectname,sperrorcode,timestamp,updtime,upduser)        
			as              
			select componentname,createdby,createddate,customername,ecrno,error_context,errorid,method_name,methodid,modifiedby,modifieddate,processname,projectname,sperrorcode,timestamp,updtime,upduser from rvw20appdb.dbo.de_fw_des_publish_brerror (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_publish_brerror' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_publish_brerror TO PUBLIC
END
GO


