IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='ce_comp_sp_obj_vw' AND TYPE = 'V')
    Begin
        Drop View ce_comp_sp_obj_vw
    End
Go


 
	/*	Creating View Script - ce_comp_sp_obj_vw on 	Jun 26 2005 11:46PM		*/	

/************************************************************************************
procedure name and id   ce_comp_sp_obj_vw
description             
name of the author      
date created            
query file name         ce_comp_sp_obj_vw.sql
modifications history   
modified by             
modified date           
modified purpose        
************************************************************************************/


create view [ce_comp_sp_obj_vw]
as
select distinct	customer_name,
		project_name,
		process_name,
		component_name,
		sp_name,
		sp_type
from ce_component_sp(Nolock)





GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'ce_comp_sp_obj_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  ce_comp_sp_obj_vw TO PUBLIC
END
GO


