IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_base_BusinessRule_Vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_base_BusinessRule_Vw
    End
Go




 
	/*	Creating View Script - de_fw_req_publish_BusinessRule_Vw on 	Jun 26 2005 11:46PM		*/	

/************************************************************************************    
procedure name and id   de_fw_req_publish_BusinessRule_Vw
description             The View used for Launch Pad
name of the author          
date created                
query file name         de_fw_req_publish_BusinessRule_Vw
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/ 
CREATE VIEW [de_fw_req_base_BusinessRule_Vw]
AS
SELECT 	MethodName 'BRName',
		'Rule' 'BRType',
		MethodName 'BRDesc',
		UpdUser 'UpdUser',
		UpdTime 'UpdTime',
		customer_name,
		project_name,
		process_name,
		component_name
FROM	de_fw_des_BusinessRule (nolock)




GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_base_BusinessRule_Vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_base_BusinessRule_Vw TO PUBLIC
END
GO


