IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_ilbo_actiongrp_task' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_ilbo_actiongrp_task
    End
Go


create view  [de_fw_des_ilbo_actiongrp_task]        
		as              
		select activity_name,activityid,component_name,createdby,createddate,customer_name,groupcode,ilbocode,modifiedby,modifieddate,process_name,project_name,taskname,timestamp,updtime,upduser from rvw20appdb.dbo.de_fw_des_ilbo_actiongrp_task a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_ilbo_actiongrp_task' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_ilbo_actiongrp_task TO PUBLIC
END
GO


