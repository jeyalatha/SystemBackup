IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_base_task_local_info_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_base_task_local_info_vw
    End
Go



/************************************************************************************      
procedure name and id   de_fw_req_base_task_local_info_vw  
description             
name of the author      BharathiDasan.V.V
date created            16-07-2007
query file name         de_fw_req_base_task_local_info_vw  
modifications history         
modified by                   
modified date                 
modified purpose              
************************************************************************************/    
create view [de_fw_req_base_task_local_info_vw]
  	(	customername,		projectname	,  	processname	,  	componentname,  
  		langid,  			taskname,		description,  	helpindex)   
as   
select 
		a.customer_name,	a.project_name,	a.process_name,	a.component_name,
		a.langid,			a.taskname,		a.description,	a.helpindex
from 	de_fw_req_task_local_info	a(nolock),
		de_fw_req_task				b(nolock)
where 	a.customer_name  	= b.customer_name  
and  	a.project_name  	= b.project_name  
and  	a.process_name 		= b.process_name  
and  	a.component_name 	= b.component_name  
and  	a.taskname   		= b.taskname


GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_base_task_local_info_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_base_task_local_info_vw TO PUBLIC
END
GO


