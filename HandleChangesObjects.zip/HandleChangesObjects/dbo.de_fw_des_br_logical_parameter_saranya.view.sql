IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_br_logical_parameter_saranya' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_br_logical_parameter_saranya
    End
Go


create view  [de_fw_des_br_logical_parameter_saranya]        
		as              
		select btname,component_name,createdby,createddate,customer_name,dna_logicalparametername,dna_logicalparamseqno,ecrno,flowdirection,logicalparametername,logicalparamseqno,method_name,methodid,modifiedby,modifieddate,process_name,project_name,recordsetname,rssequenceno,spparametertype,timestamp,updtime,upduser from rvw20appdb.dbo.de_fw_des_br_logical_parameter_saranya a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_br_logical_parameter_saranya' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_br_logical_parameter_saranya TO PUBLIC
END
GO


