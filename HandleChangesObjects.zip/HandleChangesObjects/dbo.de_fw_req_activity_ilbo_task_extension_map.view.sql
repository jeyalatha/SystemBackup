IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_activity_ilbo_task_extension_map' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_activity_ilbo_task_extension_map
    End
Go


create view  [de_fw_req_activity_ilbo_task_extension_map]        
		as              
		select activity_name,activityid,component_name,compononentname,createdby,createddate,customer_name,ilbocode,modifiedby,modifieddate,process_name,project_name,resultantaspname,sessionvariable,taskname,timestamp from rvw20appdb.dbo.de_fw_req_activity_ilbo_task_extension_map a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_activity_ilbo_task_extension_map' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_activity_ilbo_task_extension_map TO PUBLIC
END
GO


