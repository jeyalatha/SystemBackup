IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_base_ilbo_control_property' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_base_ilbo_control_property
    End
Go


create view  [de_fw_req_base_ilbo_control_property]        
		as              
		select componentname,controlid,createdby,createddate,customername,ilbocode,modifiedby,modifieddate,processname,projectname,propertyname,timestamp,type,value,viewname from rvw20appdb.dbo.de_fw_req_base_ilbo_control_property a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_base_ilbo_control_property' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_base_ilbo_control_property TO PUBLIC
END
GO


