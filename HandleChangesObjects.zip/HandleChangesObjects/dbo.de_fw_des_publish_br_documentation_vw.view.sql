IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_publish_br_documentation_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_publish_br_documentation_vw
    End
Go


 
	/*	Creating View Script - de_fw_des_publish_br_documentation_vw on 	Jun 26 2005 11:46PM		*/	

/************************************************************************************    
procedure name and id   de_fw_des_publish_br_documentation_vw
description             The View used for Launch Pad
name of the author          
date created                
query file name         de_fw_des_publish_br_documentation_vw
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/  
create view [de_fw_des_publish_br_documentation_vw]
		(customername,		projectname,		processname,		componentname,
		ecrno,				methodid,			serialno,			doctext) 
as 
select	customername,		projectname,		processname,		componentname,
		ecrno,				methodid,			serialno,			doctext
from 	de_fw_des_publish_br_documentation (nolock)



GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_publish_br_documentation_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_publish_br_documentation_vw TO PUBLIC
END
GO


