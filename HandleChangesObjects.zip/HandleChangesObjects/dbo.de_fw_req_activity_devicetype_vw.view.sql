IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_activity_devicetype_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_activity_devicetype_vw
    End
Go


create View [de_fw_req_activity_devicetype_vw]   
AS    
select a.customer_name, a.project_name, a.process_name, a.component_name, a.activity_name, case DeviceType when 'P' then 'MOBILE'  
          when 'T' then 'TABLET'  
          when 'B' then 'ALL'  
          else ''  
          End  'DeviceType'  
  from de_fw_req_activity_ilbo a (nolock),  
   de_fw_req_ilbo b (nolock),  
   de_ui c (nolock)  
where a.customer_name  = b.customer_name  
and  a.project_name = b.project_name  
and  a.process_name = b.process_name  
and  a.component_name = b.component_name  
and  b.customer_name  = c.customer_name  
and  b.project_name = c.project_name  
and  b.process_name = c.process_name  
and  b.component_name = c.component_name  
and  a.ilbocode  = b.ilbocode  
and  b.ilbocode = c.ui_name  
and  a.activity_name = c.activity_name  
and   ilbotype = 2  
  
  
  
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_activity_devicetype_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_activity_devicetype_vw TO PUBLIC
END
GO


