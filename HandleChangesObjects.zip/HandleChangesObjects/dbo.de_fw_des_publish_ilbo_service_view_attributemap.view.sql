IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_publish_ilbo_service_view_attributemap' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_publish_ilbo_service_view_attributemap
    End
Go


create view  [de_fw_des_publish_ilbo_service_view_attributemap]
(customername,projectname,processname,componentname,ecrno,ilbocode,servicename,activityid,taskname,segmentname,dataitemname,createdby,createddate,modifiedby,modifieddate,controlid,viewname,activity_name,control_bt_synonym,page_bt_synonym,PropertyType,PropertyName)
as
select customername,projectname,processname,componentname,ecrno,ilbocode,servicename,activityid,taskname,segmentname,dataitemname,createdby,createddate,modifiedby,modifieddate,controlid,viewname,activity_name,control_bt_synonym,page_bt_synonym,PropertyType,PropertyName from rvw_publish_db.dbo.de_fw_des_publish_ilbo_service_view_attributemap(nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_publish_ilbo_service_view_attributemap' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_publish_ilbo_service_view_attributemap TO PUBLIC
END
GO


