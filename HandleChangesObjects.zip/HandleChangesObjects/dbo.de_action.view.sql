IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_action' AND TYPE = 'V')
    Begin
        Drop View de_action
    End
Go


CREATE view  [de_action]                
     (Act_flag,activity_name,Barcode_sourceCtrl,Barcode_sourceCtrl_Page,Barcode_targetCtrl,Barcode_targetCtrl_Page,browse_control,browse_control_Page,Buttonbar_primary_section,component_name,createdby,createddate,customer_name,ddt_control_bt_synonym,ddt_control_id,ddt_page_bt_synonym,ddt_view_name,ecrno,group_name,IsCallout,modifiedby,modifieddate,page_bt_synonym,PopUp_close,PopUp_page_bt_synonym,PopUp_section,primary_control_bts,process_name,project_name,QR_sourceCtrl,QR_sourceCtrl_Page,QR_targetCtrl,QR_targetCtrl_Page,req_no,task_confirm_msg,task_descr,task_name,task_pattern,task_process_msg,task_seq,task_status_msg,task_sysid,task_type,timestamp,ui_name,ui_sysid,usageid,Autoupload)            
     as                
     select Act_flag,activity_name,Barcode_sourceCtrl,Barcode_sourceCtrl_Page,Barcode_targetCtrl,Barcode_targetCtrl_Page,browse_control,browse_control_Page,Buttonbar_primary_section,component_name,createdby,createddate,customer_name,ddt_control_bt_synonym,ddt_control_id,ddt_page_bt_synonym,ddt_view_name,ecrno,group_name,IsCallout,modifiedby,modifieddate,page_bt_synonym,PopUp_close,PopUp_page_bt_synonym,PopUp_section,primary_control_bts,process_name,project_name,QR_sourceCtrl,QR_sourceCtrl_Page,QR_targetCtrl,QR_targetCtrl_Page,req_no,task_confirm_msg,task_descr,task_name,task_pattern,task_process_msg,task_seq,task_status_msg,task_sysid,task_type,timestamp,ui_name,ui_sysid,usageid,Autoupload from rvw_publish_db.dbo.de_published_action a (nolock)          
     where exists (select 'x' from De_Customer_Space b (nolock)          
     where     a.customer_name   = b.customername          
     and       a.project_name    = b.projectname          
     and       a.process_name    = b.processname          
     and       a.component_name  = b.componentname      
     and       a.ecrno        = b.ecrno )
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_action' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_action TO PUBLIC
END
GO


