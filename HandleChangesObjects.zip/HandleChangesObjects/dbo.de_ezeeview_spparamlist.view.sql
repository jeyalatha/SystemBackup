IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_ezeeview_spparamlist' AND TYPE = 'V')
    Begin
        Drop View de_ezeeview_spparamlist
    End
Go


create view  [de_ezeeview_spparamlist]        
		as              
		select activity_name,component_name,control_page_name,createdby,createddate,customer_name,ecrno,Link_Caption,Link_ControlName,Mapped_Control,modifiedby,modifieddate,page_bt_synonym,ParameterName,process_name,project_name,Target_SPName,timestamp,ui_name from rvw20appdb.dbo.de_ezeeview_spparamlist a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_ezeeview_spparamlist' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_ezeeview_spparamlist TO PUBLIC
END
GO


