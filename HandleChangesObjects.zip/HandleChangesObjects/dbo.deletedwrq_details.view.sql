IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='deletedwrq_details' AND TYPE = 'V')
    Begin
        Drop View deletedwrq_details
    End
Go


create view  [deletedwrq_details]        
		as              
		select component_name,Customer_name,deletedby,deletedon,process_name,Project_name,req_no from rvw20appdb.dbo.deletedwrq_details a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'deletedwrq_details' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  deletedwrq_details TO PUBLIC
END
GO


