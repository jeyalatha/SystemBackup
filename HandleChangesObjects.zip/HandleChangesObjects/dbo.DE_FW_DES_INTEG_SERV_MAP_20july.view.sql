IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='DE_FW_DES_INTEG_SERV_MAP_20july' AND TYPE = 'V')
    Begin
        Drop View DE_FW_DES_INTEG_SERV_MAP_20july
    End
Go


create view  [DE_FW_DES_INTEG_SERV_MAP_20july]        
		as              
		select callingdataitem,callingsegment,callingservicename,component_name,createdby,createddate,customer_name,ecrno,integdataitem,integsegment,integservicename,modifiedby,modifieddate,process_name,project_name,sectionname,sequenceno,timestamp,updtime,upduser from rvw20appdb.dbo.DE_FW_DES_INTEG_SERV_MAP_20july a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'DE_FW_DES_INTEG_SERV_MAP_20july' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  DE_FW_DES_INTEG_SERV_MAP_20july TO PUBLIC
END
GO


