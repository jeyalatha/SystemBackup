IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_ilbo_data_use_10122015' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_ilbo_data_use_10122015
    End
Go


create view  [de_fw_req_ilbo_data_use_10122015]        
		as              
		select childilbocode,component_name,controlid,controlvariablename,createdby,createddate,customer_name,dataitemname,ecrno,flowtype,iscontrol,link_name,linkid,modifiedby,modifieddate,parentilbocode,primarydata,process_name,project_name,retrievemultiple,taskname,timestamp,updtime,upduser,viewname from rvw20appdb.dbo.de_fw_req_ilbo_data_use_10122015 a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_ilbo_data_use_10122015' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_ilbo_data_use_10122015 TO PUBLIC
END
GO


