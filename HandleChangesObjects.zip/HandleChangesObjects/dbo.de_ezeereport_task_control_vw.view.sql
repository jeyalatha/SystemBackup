IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_ezeereport_task_control_vw' AND TYPE = 'V')
    Begin
        Drop View de_ezeereport_task_control_vw
    End
Go



/*      V E R S I O N      :  PNR2.0_25308    */
/*      Released By        :  Development Team    */
/*      Release Comments   :  Phase 4 Release    */
/* Creating View Script - de_ezeereport_task_control_vw */
/************************************************************************************
procedure name and id   de_ezeereport_task_control_vw
description
name of the author
date created            28-Dec-2009
query file name         de_ezeereport_task_control_vw.sql
**********************************************************************************************/
Create view [de_ezeereport_task_control_vw]
as
select	
a.customer_name				'customer_name',
a.project_name				'project_name',		
a.ecrno						'ecrno',
a.process_name				'process_name',
a.component_name			'component_name',
a.activity_name				'activity_name',
a.ui_name					'ui_name',
a.page_bt_synonym			'page_name',
a.control_bt_synonym		'control_name',
a.control_id				'control_id',
b.task_name					'task_name'
from	de_published_ui_control a (nolock),
		de_published_action		b (nolock),
		es_comp_ctrl_type_mst	c (nolock)
where	a.customer_name		= b.customer_name
and		a.project_name		= b.project_name
and		a.ecrno				= b.ecrno
and		a.process_name		= b.process_name
and		a.component_name	= b.component_name
and		a.activity_name		= b.activity_name
and		a.ui_name			= b.ui_name
and		a.control_bt_synonym = b.primary_control_bts
and		a.customer_name		= c.customer_name
and		a.project_name		= c.project_name
and		a.process_name		= c.process_name
and		a.component_name	= c.component_name
and		a.control_type		= c.ctrl_type_name
and		isnull(c.ezee_report,'N') = 'Y'






GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_ezeereport_task_control_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_ezeereport_task_control_vw TO PUBLIC
END
GO


