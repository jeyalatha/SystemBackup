IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_base_activity_local_info_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_base_activity_local_info_vw
    End
Go



/************************************************************************************    
procedure name and id   de_fw_req_base_activity_local_info_vw
description             
name of the author      BharathiDasan.V.V
date created            16-07-2007                
query file name         de_fw_req_base_activity_local_info_vw
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/  
create view 	[de_fw_req_base_activity_local_info_vw] 
	 (	activitydesc ,	activityid ,	componentname ,	customername ,	helpindex ,	langid ,
		processname ,	projectname ,	tooltiptext ) 
as 
select 	activitydesc ,	activityid ,	component_name,	customer_name,	helpindex,	langid ,
		process_name ,	project_name ,	tooltiptext 
from 	de_fw_req_activity_local_info (nolock)

GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_base_activity_local_info_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_base_activity_local_info_vw TO PUBLIC
END
GO


