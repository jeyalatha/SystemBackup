IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_ilboctrl_initval' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_ilboctrl_initval
    End
Go


create view  [de_fw_req_ilboctrl_initval]        
		as              
		select component_name,control_bt_synonym,controlid,createdby,createddate,customer_name,ilbocode,initialvalue,modifiedby,modifieddate,page_bt_synonym,process_name,project_name,sequenceno,timestamp,updtime,upduser,viewname from rvw20appdb.dbo.de_fw_req_ilboctrl_initval a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_ilboctrl_initval' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_ilboctrl_initval TO PUBLIC
END
GO


