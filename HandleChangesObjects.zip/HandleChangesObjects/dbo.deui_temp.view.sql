IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='deui_temp' AND TYPE = 'V')
    Begin
        Drop View deui_temp
    End
Go


create view  [deui_temp]        
		as              
		select activity_name,base_activity_name,base_component_name,base_ui_name,callout_type,caption_alignment,component_name,createdby,createddate,current_req_no,customer_name,ecrno,grid_type,modifiedby,modifieddate,process_name,project_name,state_processing,tab_height,taskpane_req,timestamp,trail_bar,ui_descr,ui_doc,ui_format,ui_name,ui_sysid,ui_type from rvw20appdb.dbo.deui_temp a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'deui_temp' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  deui_temp TO PUBLIC
END
GO


