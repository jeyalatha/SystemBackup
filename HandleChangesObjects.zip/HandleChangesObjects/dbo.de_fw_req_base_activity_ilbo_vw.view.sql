IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_base_activity_ilbo_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_base_activity_ilbo_vw
    End
Go



/************************************************************************************    
procedure name and id   de_fw_req_base_activity_ilbo_vw
description             
name of the author      BharathiDasan.V.V
date created            13-07-2007   
query file name         de_fw_req_base_activity_ilbo_vw
modifications history       
modified by             
modified date           
modified purpose        
************************************************************************************/  
Create	view	[de_fw_req_base_activity_ilbo_vw](
		activityid,		componentname,		customername,		ilbocode ,		processname ,	
		projectname ,		activityname,		ParentComponentName) 
as 
select 	b.activityid ,	A.component_name ,	A.customer_name, 	A.ilbocode ,	A.process_name ,
		A.project_name,	b.activityname,	a.component_name
from 	de_fw_req_activity_ilbo A(nolock),
		de_fw_req_activity 		B (nolock)
where	A.customer_name 	= b.customer_name
and		a.project_name 		= b.project_name
and		a.process_name		= b.process_name
and		a.component_name	= b.componentname
and 	a.activityid		= b.activityid
and		exists(	select	'A'
				from	de_fw_req_ilbo_control	c (nolock)
				where	c.customer_name 	= b.customer_name
				and		c.project_name 		= b.project_name
				and		c.process_name		= b.process_name
				and		c.component_name 	= b.componentname
				and		c.ilbocode			= a.ilbocode)
union	
select	c.activityid ,	 c.componentname ,	a.customer_name ,	b.ilbocode ,	c.process_name 
		,A.project_name, c.activityname, a.component_name
from	de_fw_req_ilbo_linkuse 			a (nolock),
		de_fw_req_activity_ilbo			b (nolock),
		de_fw_req_activity				c (nolock),
		de_fw_req_ilbo_link_publish 	d (nolock)	
where	a.customer_name		= 	b.customer_name
and		a.project_name		= 	b.project_name
and		a.component_name	<> 	b.component_name
and		a.childilbocode		= 	b.ilbocode

and		a.customer_name		= 	c.customer_name
and		a.project_name		= 	c.project_name
and		a.component_name	<> 	c.componentname

and		b.customer_name		= c.customer_name
and		b.project_name		= c.project_name
and		b.component_name	= c.componentname
and		b.activityid		= c.activityid
and		a.customer_name		= d.customer_name
and		a.project_name		= d.project_name
and		a.linkid			= d.linkid
and		b.ilbocode			= d.ilbocode
and		b.component_name	= d.component_name
and		b.activityid		= d.activityid

GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_base_activity_ilbo_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_base_activity_ilbo_vw TO PUBLIC
END
GO


