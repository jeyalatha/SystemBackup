IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_ecr_publish_chk_12_04_2016' AND TYPE = 'V')
    Begin
        Drop View de_ecr_publish_chk_12_04_2016
    End
Go


create view  [de_ecr_publish_chk_12_04_2016]        
		as              
		select createdby,createddate,customer_Name,ecr_no,host_mcname,modifiedby,modifieddate,Project_Name,publ_username,start_time,timestamp,work_flag from rvw20appdb.dbo.de_ecr_publish_chk_12_04_2016 a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_ecr_publish_chk_12_04_2016' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_ecr_publish_chk_12_04_2016 TO PUBLIC
END
GO


