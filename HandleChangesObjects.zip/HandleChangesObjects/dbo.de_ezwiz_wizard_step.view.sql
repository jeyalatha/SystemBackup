IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_ezwiz_wizard_step' AND TYPE = 'V')
    Begin
        Drop View de_ezwiz_wizard_step
    End
Go


create view  [de_ezwiz_wizard_step]        
		as              
		select component_name,created_by,created_date,customer_name,ecrno,modified_by,modified_date,process_name,project_name,step_desc,step_seqno,subscription_level,target_activitydesc,target_activityname,target_componentdesc,target_componentname,target_ilbodesc,target_ilboname,timestamp,wizard_name from rvw20appdb.dbo.de_ezwiz_wizard_step a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_ezwiz_wizard_step' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_ezwiz_wizard_step TO PUBLIC
END
GO


