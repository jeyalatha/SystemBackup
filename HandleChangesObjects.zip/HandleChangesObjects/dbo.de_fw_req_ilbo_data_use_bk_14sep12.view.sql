IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_ilbo_data_use_bk_14sep12' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_ilbo_data_use_bk_14sep12
    End
Go


create view  [de_fw_req_ilbo_data_use_bk_14sep12]        
		as              
		select childilbocode,component_name,controlid,controlvariablename,createdby,createddate,customer_name,dataitemname,ecrno,flowtype,iscontrol,link_name,linkid,modifiedby,modifieddate,parentilbocode,primarydata,process_name,project_name,retrievemultiple,taskname,timestamp,updtime,upduser,viewname from rvw20appdb.dbo.de_fw_req_ilbo_data_use_bk_14sep12 a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_ilbo_data_use_bk_14sep12' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_ilbo_data_use_bk_14sep12 TO PUBLIC
END
GO


