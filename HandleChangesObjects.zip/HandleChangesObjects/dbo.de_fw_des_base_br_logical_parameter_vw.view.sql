IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_base_br_logical_parameter_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_base_br_logical_parameter_vw
    End
Go



/************************************************************************************    
procedure name and id   de_fw_des_base_br_logical_parameter_vw
description             
name of the author      BharathiDasan.V.V
date created            16-07-2007                
query file name         de_fw_des_base_br_logical_parameter_vw
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/  
create view [de_fw_des_base_br_logical_parameter_vw]
 	(	customername,	projectname,			processname,			componentname,
		methodid,		logicalparametername,	logicalparamseqno,		recordsetname,	
		rssequenceno,	flowdirection,			btname,					spparametertype	)
as
select 	customer_name,	project_name,			process_name,			component_name,
		methodid,		logicalparametername,	logicalparamseqno,		recordsetname,	
		rssequenceno,	flowdirection,			btname,					spparametertype	
from 	de_fw_des_br_logical_parameter (nolock)



GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_base_br_logical_parameter_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_base_br_logical_parameter_vw TO PUBLIC
END
GO


