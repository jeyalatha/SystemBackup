IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_business_rule_lng_extn' AND TYPE = 'V')
    Begin
        Drop View de_business_rule_lng_extn
    End
Go


create view  [de_business_rule_lng_extn]              
					(br_descr,br_doc,br_name,component_name,createdby,createddate,customer_name,ecrno,languageid,modifiedby,modifieddate,process_name,project_name,rule_sysid,timestamp)          
					as              
					select br_descr,br_doc,br_name,component_name,createdby,createddate,customer_name,ecrno,languageid,modifiedby,modifieddate,process_name,project_name,rule_sysid,timestamp from rvw_publish_db.dbo.de_published_business_rule_lng_extn a (nolock)        
					where exists (select 'x' from De_Customer_Space b (nolock)        
					where     a.customer_name   = b.customername        
					and       a.project_name    = b.projectname        
					and       a.process_name    = b.processname        
					and       a.component_name  = b.componentname    
					and       a.ecrno        = b.ecrno )
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_business_rule_lng_extn' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_business_rule_lng_extn TO PUBLIC
END
GO


