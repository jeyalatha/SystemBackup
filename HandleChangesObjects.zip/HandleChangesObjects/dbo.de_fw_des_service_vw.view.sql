IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_service_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_service_vw
    End
Go


 
	/*	Creating View Script - de_fw_des_service_vw on 	Jun 26 2005 11:46PM		*/	

/************************************************************************************
view name and id   		: de_fw_des_service_vw
description             : 	
name of the author      : A.G.Senthil kumar
date created            :
query file name         : de_fw_des_service_vw.sql
modifications history   :
modified by             :
modified date           :
modified purpose        :
************************************************************************************/
-- code Modified by feroz for bug id COMMONPF204SYS_000003 on 11\10\2004
create view  [de_fw_des_service_vw]
as 
select servicename,componentname,servicetype,isintegser,
statusflag,customer_name,project_name,
process_name,svconame,processingtype
from de_fw_des_service(nolock)



GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_service_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_service_vw TO PUBLIC
END
GO


