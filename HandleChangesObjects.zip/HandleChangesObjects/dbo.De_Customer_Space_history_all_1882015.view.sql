IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='De_Customer_Space_history_all_1882015' AND TYPE = 'V')
    Begin
        Drop View De_Customer_Space_history_all_1882015
    End
Go


create view  [De_Customer_Space_history_all_1882015]        
		as              
		select componentname,createdby,createddate,CustomerName,database_name,ecrno,map,modby,moddate,processname,ProjectName,validate_req from rvw20appdb.dbo.De_Customer_Space_history_all_1882015 a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'De_Customer_Space_history_all_1882015' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  De_Customer_Space_history_all_1882015 TO PUBLIC
END
GO


