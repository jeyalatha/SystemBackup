IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_publish_service_dataitem_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_publish_service_dataitem_vw
    End
Go


 
	/*	Creating View Script - de_fw_des_publish_service_dataitem_vw on 	Jun 26 2005 11:46PM		*/	

/************************************************************************************    
procedure name and id   de_fw_des_publish_service_dataitem_vw
description             The View used for Launch Pad
name of the author      
date created            
query file name         de_fw_des_publish_service_dataitem_vw
modifications history   
modified by             Gowrisankar M
modified date           30-dec-2009
Bug ID		            PNR2.0_25419
modified purpose        
************************************************************************************/  
create view [de_fw_des_publish_service_dataitem_vw] 
		(componentname ,customername ,dataitemname ,defaultvalue ,ecrno ,
		flowattribute ,ispartofkey ,mandatoryflag ,processname ,projectname ,
		segmentname ,servicename, itk_dataitem ) 	-- code modified by Gowrisankar M for PNR2.0_25419 on 30-Dec-2009
as 
select 	componentname ,customername ,dataitemname ,defaultvalue ,ecrno ,
		flowattribute ,ispartofkey ,mandatoryflag ,processname ,projectname ,
		segmentname ,servicename, 'N' 'ITK_DATAITEM' 	-- code modified by Gowrisankar M for PNR2.0_25419 on 30-Dec-2009
from 	de_fw_des_publish_service_dataitem (nolock)
union
select 	sr.component_name ,sr.customer_name ,sr.dataitemname ,sr.defaultvalue ,ps.ecrno ,
		sr.flowattribute ,sr.ispartofkey ,sr.mandatoryflag ,sr.process_name ,sr.project_name ,
		sr.segmentname ,sr.servicename , 'N' 'ITK_DATAITEM'  -- code modified by Gowrisankar M for PNR2.0_25419 on 30-Dec-2009
from 	de_fw_des_service_dataitem sr(nolock),
		de_fw_des_publish_processsection_br_is ps(nolock)
where 	sr.servicename 		=  ps.integservicename
and 	sr.customer_name 	=  ps.customername
and 	sr.project_name  	=  ps.projectname
and		sr.component_name	<> ps.componentname

GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_publish_service_dataitem_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_publish_service_dataitem_vw TO PUBLIC
END
GO


