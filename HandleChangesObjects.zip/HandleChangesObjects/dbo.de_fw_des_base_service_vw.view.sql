IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_base_service_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_base_service_vw
    End
Go



/************************************************************************************    
procedure name and id   de_fw_des_base_service_vw
description             
name of the author      BharathiDasan.V.V
date created            13-07-2007
query file name         de_fw_des_base_service_vw
modifications history       
modified by             
modified date           
modified purpose        
************************************************************************************/  
Create view [de_fw_des_base_service_vw]
		(componentname ,	customername ,				isintegser ,	processingtype ,	processname ,
		projectname ,		servicename ,				servicetype ,	statusflag ,		svconame,parentcomponentname ) 
as 
select 	componentname ,		customer_name, 				isintegser ,	processingtype ,	process_name,
		project_name ,		ltrim(rtrim(servicename)),	servicetype ,	statusflag ,		svconame,
	componentname
from 	de_fw_des_service (nolock)
union
select 	sr.componentname ,	sr.customer_name ,			sr.isintegser ,	sr.processingtype ,	sr.process_name,
		sr.project_name ,	sr.servicename ,			sr.servicetype,	1,					sr.svconame ,
	ps.component_name
from 	de_fw_des_service sr (nolock),
		de_fw_des_processsection_br_is ps(nolock)
where 	sr.servicename 		=  	ps.integservicename
and 	sr.customer_name 	=  	ps.customer_name
and 	sr.project_name  	=  	ps.project_name
and		sr.isintegser		= 	1
and		sr.componentname 	<>  ps.component_name








GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_base_service_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_base_service_vw TO PUBLIC
END
GO


