IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_chm_selservice_tmp' AND TYPE = 'V')
    Begin
        Drop View de_chm_selservice_tmp
    End
Go


create view  [de_chm_selservice_tmp]        
		as              
		select component_name,createdby,createddate,customer_name,guid,process_name,project_name,service_name from rvw20appdb.dbo.de_chm_selservice_tmp a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_chm_selservice_tmp' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_chm_selservice_tmp TO PUBLIC
END
GO


