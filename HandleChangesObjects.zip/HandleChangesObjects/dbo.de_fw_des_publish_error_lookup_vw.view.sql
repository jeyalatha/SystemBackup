IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_publish_error_lookup_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_publish_error_lookup_vw
    End
Go


/* Creating View Script - de_action_vw on  Jun 26 2005 11:46PM  for PNR2.0_29495 */
/************************************************************************************
procedure name and id   de_action_vw
description
name of the author
date created
query file name         de_fw_des_publish_error_lookup_vw.sql
modifications history
modified by
modified date
modified purpose
************************************************************************************/
create view [de_fw_des_publish_error_lookup_vw]
( customer_name,project_name,process_name,component_name,ecrno,activity_name,ui_name,
taskname,service_name,errorid,pub_name,published_comp_name,published_act_name,published_ui_name ,pub_taskname, linkid )
as
select customer_name,project_name,process_name,component_name,ecrno,activity_name,ui_name,
taskname,service_name,errorid,pub_name,published_comp_name,published_act_name,published_ui_name ,post_task 'pub_taskname' ,linkid
from de_fw_des_publish_error_lookup (nolock)







GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_publish_error_lookup_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_publish_error_lookup_vw TO PUBLIC
END
GO


