IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_bo_segment_relation' AND TYPE = 'V')
    Begin
        Drop View de_bo_segment_relation
    End
Go


create view  [de_bo_segment_relation]              
			(bo_name,bo_segment_name,bosegrel_sysid,component_name,createdby,createddate,customer_name,modifiedby,modifieddate,process_name,project_name,related_bo_name,related_bo_segment_name,relationship_name,relationship_type,timestamp)        
			as              
			select bo_name,bo_segment_name,bosegrel_sysid,component_name,createdby,createddate,customer_name,modifiedby,modifieddate,process_name,project_name,related_bo_name,related_bo_segment_name,relationship_name,relationship_type,timestamp from rvw20appdb.dbo.de_bo_segment_relation (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_bo_segment_relation' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_bo_segment_relation TO PUBLIC
END
GO


