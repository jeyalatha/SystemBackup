IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_businessrule_iedktemp' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_businessrule_iedktemp
    End
Go


create view  [de_fw_des_businessrule_iedktemp]        
		as              
		select Guid,MethodName from rvw20appdb.dbo.de_fw_des_businessrule_iedktemp a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_businessrule_iedktemp' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_businessrule_iedktemp TO PUBLIC
END
GO


