IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='Apkg_TechnoArch_Doc_Rm_Files_Vw' AND TYPE = 'V')
    Begin
        Drop View Apkg_TechnoArch_Doc_Rm_Files_Vw
    End
Go


 
	/*	Creating View Script - Apkg_TechnoArch_Doc_Rm_Files_Vw on 	Jun 26 2005 11:46PM		*/	
	Create View [Apkg_TechnoArch_Doc_Rm_Files_Vw] As Select 
	CustomerID,
	ProjectID,
	LangID,
	ReleaseCount,
	ReleaseVersion,
	RDBMSName,
	RDBMSVersion,
	Filetype,
	FileNam,
	FileSeq,
	FilePath,
	ArtifactVersion,
	CallingFile,
	UpdUser,
	UpdTime
	from Apkg_TechnoArch_Doc_Rm_Files (nolock)
	

GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'Apkg_TechnoArch_Doc_Rm_Files_Vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  Apkg_TechnoArch_Doc_Rm_Files_Vw TO PUBLIC
END
GO


