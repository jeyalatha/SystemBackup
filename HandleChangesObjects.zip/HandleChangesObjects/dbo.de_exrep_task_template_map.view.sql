IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_exrep_task_template_map' AND TYPE = 'V')
    Begin
        Drop View de_exrep_task_template_map
    End
Go


create view  [de_exrep_task_template_map]        
		as              
		select activity_name,associated_control,component_name,createdby,createddate,ctrl_page_name,customer_name,modifiedby,modifieddate,page_name,process_name,project_name,task_name,template_id,ui_name from rvw20appdb.dbo.de_exrep_task_template_map a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_exrep_task_template_map' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_exrep_task_template_map TO PUBLIC
END
GO


