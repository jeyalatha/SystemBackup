IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_base_processsection_br_is_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_base_processsection_br_is_vw
    End
Go



/************************************************************************************    
procedure name and id   de_fw_des_base_processsection_br_is_vw
description             
name of the author      BharathiDasan.V.V
date created            16-07-2007                
query file name         de_fw_des_base_processsection_br_is_vw
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/  
Create view [de_fw_des_base_processsection_br_is_vw]
	 (	componentname ,		connectivityflag ,		controlexpression ,		customername,
		executionflag ,		integservicename ,		isbr ,					methodid ,
		processname ,		projectname ,			sectionname ,			sequenceno ,
		servicename ) 
as 
select 	component_name,		connectivityflag ,		controlexpression ,		customer_name ,
		executionflag ,		integservicename ,		isbr ,					methodid ,
		process_name ,		project_name ,			sectionname ,			sequenceno ,
		servicename 
from 	de_fw_des_processsection_br_is (nolock)






GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_base_processsection_br_is_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_base_processsection_br_is_vw TO PUBLIC
END
GO


