IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_base_svco_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_base_svco_vw
    End
Go



/************************************************************************************    
procedure name and id   de_fw_des_base_svco_vw
description             
name of the author      BharathiDasan.V.V
date created            13-07-2007                
query file name         de_fw_des_base_svco_vw
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/  
create view [de_fw_des_base_svco_vw]
	  ( customername,		projectname,		processname,		componentname,
		svconame,			svcodescription,	svcoscope, 			svcotype,			
		dllname,			progid) 
as 
select	customer_name,		project_name,		process_name,		componentname,
		svconame,			svcodescription,	svcoscope,			svcotype,			
		dllname,			progid
from 	de_fw_des_svco (nolock)
union
select 	ps.customer_name,	ps.project_name,	ps.process_name,	sr.componentname,
		sv.svconame,		sv.svcodescription,	sv.svcoscope,		sv.svcotype,		
		sv.dllname,			sv.progid
from 	de_fw_des_service sr (nolock),
		de_fw_des_processsection_br_is ps(nolock),
		de_fw_des_svco  sv (nolock)
where 	sr.servicename 		= 	ps.integservicename
and 	sr.customer_name 	= 	ps.customer_name
and 	sr.project_name  	= 	ps.project_name
and		sr.componentname	<>	ps.component_name 
and		sv.customer_name	= 	sr.customer_name
and		sv.project_name		= 	sr.project_name
and		sv.process_name		= 	sr.process_name
and		sv.componentname	= 	sr.componentname
and		sv.svconame			= 	sr.svconame
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_base_svco_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_base_svco_vw TO PUBLIC
END
GO


