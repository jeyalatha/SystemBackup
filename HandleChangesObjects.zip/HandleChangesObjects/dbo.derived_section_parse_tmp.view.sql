IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='derived_section_parse_tmp' AND TYPE = 'V')
    Begin
        Drop View derived_section_parse_tmp
    End
Go


create view  [derived_section_parse_tmp]        
		as              
		select activity_name,attributes,class,component_name,control_id,createdby,createddate,ctrl_type,horder,htmname,modifiedby,modifieddate,page_bt_synonym,pheight,pleft,ptop,pwidth,section,ui_name,vorder from rvw20appdb.dbo.derived_section_parse_tmp a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'derived_section_parse_tmp' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  derived_section_parse_tmp TO PUBLIC
END
GO


