IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_base_ilbo_tabs_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_base_ilbo_tabs_vw
    End
Go



/************************************************************************************    
procedure name and id   de_fw_req_base_ilbo_tabs_vw
description             
name of the author      BharathiDasan.V.V
date created            16-07-2007
query file name         de_fw_req_base_ilbo_tabs_vw
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/  
Create view [de_fw_req_base_ilbo_tabs_vw] 
	 (	customername,	projectname,	processname,	componentname,
		ilbocode,		tabname,		btsynonym) 
as 
select 	customer_name,	project_name,	process_name,	component_name,
		ilbocode,		tabname,		btsynonym
from 	de_fw_req_ilbo_tabs (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_base_ilbo_tabs_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_base_ilbo_tabs_vw TO PUBLIC
END
GO


