IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_ilbo_link_use_documentation' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_ilbo_link_use_documentation
    End
Go


create view  [de_fw_req_ilbo_link_use_documentation]        
		as              
		select childilbocode,component_name,createdby,createddate,customer_name,langid,link_name,linkid,modifiedby,modifieddate,paragraphname,paragraphno,paragraphtext,parentilbocode,process_name,project_name,taskname,timestamp,updtime,upduser from rvw20appdb.dbo.de_fw_req_ilbo_link_use_documentation a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_ilbo_link_use_documentation' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_ilbo_link_use_documentation TO PUBLIC
END
GO


