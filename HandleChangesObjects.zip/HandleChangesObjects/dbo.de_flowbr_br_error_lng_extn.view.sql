IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_flowbr_br_error_lng_extn' AND TYPE = 'V')
    Begin
        Drop View de_flowbr_br_error_lng_extn
    End
Go


create view  [de_flowbr_br_error_lng_extn]        
		as              
		select activity_name,br_id,br_sysid,component_name,createdby,createddate,customer_name,default_flag,flowbr_name,languageid,message_descr,message_id,modifiedby,modifieddate,msg_severity,msg_sysid,page_bt_synonym,process_name,project_name,task_name,timestamp,ui_name from rvw20appdb.dbo.de_flowbr_br_error_lng_extn a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_flowbr_br_error_lng_extn' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_flowbr_br_error_lng_extn TO PUBLIC
END
GO


