IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_publish_processsection_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_publish_processsection_vw
    End
Go


 
	/*	Creating View Script - de_fw_des_publish_processsection_vw on 	Jun 26 2005 11:46PM		*/	

/************************************************************************************    
procedure name and id   de_fw_des_publish_processsection_vw
description             The View used for Launch Pad
name of the author          
date created                
query file name         de_fw_des_publish_processsection_vw
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/  
create view [de_fw_des_publish_processsection_vw] 
		(componentname ,controlexpression ,customername ,ecrno ,processingtype ,
		processname ,projectname ,sectionname ,sectiontype ,sequenceno ,servicename ) 
as 
select 	componentname ,controlexpression ,customername ,ecrno ,processingtype ,
		processname ,projectname ,sectionname ,sectiontype ,sequenceno ,servicename 
from 	de_fw_des_publish_processsection (nolock)

GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_publish_processsection_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_publish_processsection_vw TO PUBLIC
END
GO


