IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='avs_published_service_validation_dtl_vw' AND TYPE = 'V')
    Begin
        Drop View avs_published_service_validation_dtl_vw
    End
Go



Create view [avs_published_service_validation_dtl_vw]
as 
select 	customer_name			'customer_name',
		project_name			'project_name',
		ecrno 					'ecrno',
		process_name			'process_name',
		component_name 			'component_name',
		service_name			'service_name',
		segment_name 			'segmentname',
		dataitemname			'dataitemname',
		validation_code			'validation_code',
		value1	 				'value1',
		value2					'value2',
		eval_sequence			'order_of_sequence'
from 	avs_published_service_validation_dtl	(nolock)
where 	validation_code 	in ('207','208','209') 

GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'avs_published_service_validation_dtl_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  avs_published_service_validation_dtl_vw TO PUBLIC
END
GO


