IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_flowbr_br_error_bkp_apr042012' AND TYPE = 'V')
    Begin
        Drop View de_flowbr_br_error_bkp_apr042012
    End
Go


create view  [de_flowbr_br_error_bkp_apr042012]        
		as              
		select activity_name,br_id,br_sysid,component_name,createdby,createddate,customer_name,default_flag,ecrno,error_context,flowbr_name,message_descr,message_id,modifiedby,modifieddate,msg_severity,msg_sysid,page_bt_synonym,process_name,project_name,task_name,timestamp,ui_name from rvw20appdb.dbo.de_flowbr_br_error_bkp_apr042012 a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_flowbr_br_error_bkp_apr042012' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_flowbr_br_error_bkp_apr042012 TO PUBLIC
END
GO


