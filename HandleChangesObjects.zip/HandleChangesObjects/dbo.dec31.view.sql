IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='dec31' AND TYPE = 'V')
    Begin
        Drop View dec31
    End
Go


create view  [dec31]        
		as              
		select activityid,activityname,rolename from rvw20appdb.dbo.dec31 a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'dec31' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  dec31 TO PUBLIC
END
GO


