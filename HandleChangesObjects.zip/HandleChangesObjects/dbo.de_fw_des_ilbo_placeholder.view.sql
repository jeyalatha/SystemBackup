IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_ilbo_placeholder' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_ilbo_placeholder
    End
Go


create view  [de_fw_des_ilbo_placeholder]              
					as              
					select componentname 'component_name' ,control_bt_synonym,controlid,controlname,createdby,createddate,ctrlevent_viewname,customername 'customer_name' ,ecrno,errorid,eventname,ilbocode,iscontrol,modifiedby,modifieddate,page_bt_synonym,placeholdername,processname 'process_name' ,projectname 'project_name' ,timestamp,updtime,upduser,variablename,viewname from rvw_publish_db.dbo.de_fw_des_publish_ilbo_placeholder a (nolock)        
					where exists (select 'x' from De_Customer_Space b (nolock)        
					where     a.customername   = b.customername        
					and       a.projectname    = b.projectname        
					and       a.processname    = b.processname        
					and       a.componentname  = b.componentname    
					and       a.ecrno        = b.ecrno )
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_ilbo_placeholder' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_ilbo_placeholder TO PUBLIC
END
GO


