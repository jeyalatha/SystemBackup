IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_chart_header' AND TYPE = 'V')
    Begin
        Drop View de_chart_header
    End
Go


create view  [de_chart_header]              
					(activity_name,background_color,background_image,canvas_color,chart_desc,chart_title,chart_type,component_name,createdby,createddate,customer_name,datagrid,datagrid_type,divline_color,ecrno,font,font_color,font_size,graphicsmode,height,legend_font,legend_font_color,legend_font_size,legend_title,modifiedby,modifieddate,override_chart_type,page_bt_synonym,process_name,project_name,req_no,section_bt_synonym,series_legend,tooltip,ui_name,width,x_auto_scale,x_axis_title,x_cal_err_value,x_con_color,x_con_style,x_con_type,x_con_weight,x_con_wt_val,x_divisions_max,x_divisions_min,x_error_band_type,x_error_marker_size,x_error_marker_type,x_error_marker_val,x_font,x_font_color,x_font_size,x_marker_color,x_marker_size,x_marker_size_val,x_marker_type,x_numdivlines,x_series_elements,x_show_err_band,x_showname,x_showvalue,x_units,y_auto_scale,y_axis_title,y_cal_err_value,y_con_type,y_con_weight,y_con_wt_val,y_connector_color,y_connector_style,y_divisions_max,y_divisions_min,y_error_band_type,y_error_marker_size,y_error_marker_type,y_error_marker_value,y_font,y_font_color,y_font_size,y_marker_color,y_marker_size,y_marker_size_val,y_marker_type,y_numdivlines,y_secondary_axis,y_series_elements,y_show_err_band,y_units)          
					as              
					select activity_name,background_color,background_image,canvas_color,chart_desc,chart_title,chart_type,component_name,createdby,createddate,customer_name,datagrid,datagrid_type,divline_color,ecrno,font,font_color,font_size,graphicsmode,height,legend_font,legend_font_color,legend_font_size,legend_title,modifiedby,modifieddate,override_chart_type,page_bt_synonym,process_name,project_name,req_no,section_bt_synonym,series_legend,tooltip,ui_name,width,x_auto_scale,x_axis_title,x_cal_err_value,x_con_color,x_con_style,x_con_type,x_con_weight,x_con_wt_val,x_divisions_max,x_divisions_min,x_error_band_type,x_error_marker_size,x_error_marker_type,x_error_marker_val,x_font,x_font_color,x_font_size,x_marker_color,x_marker_size,x_marker_size_val,x_marker_type,x_numdivlines,x_series_elements,x_show_err_band,x_showname,x_showvalue,x_units,y_auto_scale,y_axis_title,y_cal_err_value,y_con_type,y_con_weight,y_con_wt_val,y_connector_color,y_connector_style,y_divisions_max,y_divisions_min,y_error_band_type,y_error_marker_size,y_error_marker_type,y_error_marker_value,y_font,y_font_color,y_font_size,y_marker_color,y_marker_size,y_marker_size_val,y_marker_type,y_numdivlines,y_secondary_axis,y_series_elements,y_show_err_band,y_units from rvw_publish_db.dbo.de_published_chart_header a (nolock)        
					where exists (select 'x' from De_Customer_Space b (nolock)        
					where     a.customer_name   = b.customername        
					and       a.project_name    = b.projectname        
					and       a.process_name    = b.processname        
					and       a.component_name  = b.componentname    
					and       a.ecrno        = b.ecrno )
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_chart_header' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_chart_header TO PUBLIC
END
GO


