IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_publish_processsection_br_is_bkp_test' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_publish_processsection_br_is_bkp_test
    End
Go


create view  [de_fw_des_publish_processsection_br_is_bkp_test]        
		as              
		select componentname,connectivityflag,controlexpression,createdby,createddate,customername,ecrno,executionflag,integservicename,isbr,method_name,methodid,modifiedby,modifieddate,processname,projectname,sectionname,sequenceno,servicename,timestamp,updtime,upduser from rvw20appdb.dbo.de_fw_des_publish_processsection_br_is_bkp_test a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_publish_processsection_br_is_bkp_test' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_publish_processsection_br_is_bkp_test TO PUBLIC
END
GO


