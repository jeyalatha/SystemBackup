IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_error_lookup_tmp' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_error_lookup_tmp
    End
Go


create view  [de_fw_des_error_lookup_tmp]        
		as              
		select errorid,linkid,pub_name,published_act_name,published_comp_name,published_ui_name,service_name,taskname,ui_name from rvw20appdb.dbo.de_fw_des_error_lookup_tmp a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_error_lookup_tmp' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_error_lookup_tmp TO PUBLIC
END
GO


