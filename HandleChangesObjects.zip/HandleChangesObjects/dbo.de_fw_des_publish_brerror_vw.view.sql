IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_publish_brerror_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_publish_brerror_vw
    End
Go


 
	/*	Creating View Script - de_fw_des_publish_brerror_vw on 	Jun 26 2005 11:46PM		*/	

/************************************************************************************    
procedure name and id   de_fw_des_publish_brerror_vw
description             The View used for Launch Pad
name of the author          
date created                
query file name         de_fw_des_publish_brerror_vw
modifications history       
modified by                 
modified date               
modified purpose            
***************************************************************************************/  
/*modified by             Sangeetha L	for bug id :PNR2.0_6843						  */
/*modified date           06-Mar-2006    											  */
/*modified purpose        During Code generation Error files are not getting generated*/    
/**************************************************************************************/  
/*modified by             Balaji S			         					  			  */	
/*modified date           12-Oct-2006    											  */
/*modified purpose        PNR2.0_10525												  */    
/**************************************************************************************/  
/*modified by             Sivakumar S		         					  			  */	
/*modified date           21-AUG-2007    											  */
/*modified purpose        PNR2.0_14980												  */    
/**************************************************************************************/  

Create view [de_fw_des_publish_brerror_vw] 
		(componentname ,customername ,ecrno ,errorid ,methodid ,
		processname ,projectname ,sperrorcode ) 
as 
select 	componentname ,customername ,ecrno ,errorid ,methodid ,processname ,
		projectname ,sperrorcode 
from 	de_fw_des_publish_brerror (nolock)
-- Code Modified For BUG_ID - PNR2.0_14980
--union 
--select 	componentname ,customername ,ecrno ,errorid ,0 ,processname ,
--		projectname ,convert(varchar(20),errorid) --errorid -- modified for PNR2.0_6843
--from 	de_fw_des_publish_error a (nolock)
--where 	not exists (select 	's'
--					from 	de_fw_des_publish_brerror b (nolock)
--					where	a.customername	= 	b.customername
--					and		a.projectname	= 	b.projectname
--					--code modified for bugId : PNR2.0_10525
--					and		a.ecrno			=   b.ecrno
--					and 	a.processname 	= 	b.processname
--					and 	a.componentname	= 	b.componentname 
--					and		a.errorid		= 	b.errorid 
--				   )

GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_publish_brerror_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_publish_brerror_vw TO PUBLIC
END
GO


