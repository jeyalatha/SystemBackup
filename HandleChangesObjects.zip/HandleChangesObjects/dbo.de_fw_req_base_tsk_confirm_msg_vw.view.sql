IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_base_tsk_confirm_msg_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_base_tsk_confirm_msg_vw
    End
Go



/************************************************************************************
procedure name and id   de_fw_req_publish_tsk_confirm_msg_vw
description             
name of the author      
date created            
query file name         de_fw_req_publish_tsk_confirm_msg_vw
modifications history   
modified by             
modified date           
modified purpose        
***********************************************************************************/
create	View	[de_fw_req_base_tsk_confirm_msg_vw]
	(customername,		projectname,	processname,			
	 componentname,		activityname,	ilbocode,	
	 taskname,			languageid,		taskconfirmmsg)
as
select	distinct
		a.customer_name		'customername',		a.project_name		'projectname',		a.process_name		'processname',			
		a.component_name	'componentname',	c.activityname		'activityname',		a.ilbocode			'ilbocode',			
		a.taskname			'taskname',			b.langid			'languageid',		b.task_confirm_msg	'taskconfirmmsg'
from	de_fw_req_activity_ilbo_task a (nolock),
		de_fw_req_task_local_info 	 b (nolock),
		de_fw_req_activity 			 c (nolock)
where	a.Taskconfirmation	= 1
and		b.customer_name		= a.customer_name
and		b.project_name		= a.project_name
and		b.process_name		= a.process_name
and		b.component_name	= a.component_name
and		b.taskname			= a.taskname
and		c.customer_name		= a.customer_name
and		c.project_name		= a.project_name
and		c.process_name		= a.process_name
and		c.component_name	= a.component_name
and		c.activityid		= a.activityid





GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_base_tsk_confirm_msg_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_base_tsk_confirm_msg_vw TO PUBLIC
END
GO


