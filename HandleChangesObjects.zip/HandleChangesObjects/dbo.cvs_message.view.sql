IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='cvs_message' AND TYPE = 'V')
    Begin
        Drop View cvs_message
    End
Go


create view  [cvs_message]              
			(activity_name,component_name,control_name,createdby,createddate,custom_message,customer_name,ecrno,generated_message,message_code,modifiedby,modifieddate,page_name,process_name,Project_name,ref_val_group,task_name,timestamp,ui_name,validation_code)          
			as              
			select activity_name,component_name,control_name,createdby,createddate,custom_message,customer_name,ecrno,generated_message,message_code,modifiedby,modifieddate,page_name,process_name,Project_name,ref_val_group,task_name,timestamp,ui_name,validation_code from rvw_publish_db.dbo.cvs_published_message a (nolock)        
			where exists (select 'x' from De_Customer_Space b (nolock)        
			where     a.customer_name   = b.customername        
			and       a.project_name    = b.projectname        
			and       a.process_name    = b.processname        
			and       a.component_name  = b.componentname    
			and       a.ecrno           = b.ecrno )
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'cvs_message' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  cvs_message TO PUBLIC
END
GO


