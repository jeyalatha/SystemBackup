IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='ce_comp_sp_depends_vw' AND TYPE = 'V')
    Begin
        Drop View ce_comp_sp_depends_vw
    End
Go


 
	/*	Creating View Script - ce_comp_sp_depends_vw on 	Jun 26 2005 11:46PM		*/	
create view [ce_comp_sp_depends_vw]
as
select customer_name, project_name, component_name,
sp_name, child_sp_name, child_sp_Comp 
from ce_comp_sp_depends(nolock)

GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'ce_comp_sp_depends_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  ce_comp_sp_depends_vw TO PUBLIC
END
GO


