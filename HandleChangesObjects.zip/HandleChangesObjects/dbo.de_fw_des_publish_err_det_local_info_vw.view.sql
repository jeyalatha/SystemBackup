IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_publish_err_det_local_info_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_publish_err_det_local_info_vw
    End
Go


 
/************************************************************************************    
procedure name and id   de_fw_des_publish_err_det_local_info_vw
description             The View used for Launch Pad
name of the author          
date created                
query file name         de_fw_des_publish_err_det_local_info_vw
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/  
create view [de_fw_des_publish_err_det_local_info_vw] 
		(componentname ,customername ,detaileddesc ,ecrno ,errorid ,
		errormessage ,langid ,processname ,projectname , defaultcorrectiveaction) 
as
-- code added by Ganesh for the callid :: PNR2.0_3678 on 29/08/05
select 	a.componentname ,a.customername ,a.detaileddesc ,a.ecrno ,a.errorid ,
		a.errormessage ,a.langid ,a.processname ,a.projectname,  b.defaultcorrectiveaction
from 	de_fw_des_publish_err_det_local_info 	a (nolock),
		de_fw_des_publish_error					b (nolock)
where	a.customername	= b.customername
and		a.projectname	= b.projectname
and		a.ecrno			= b.ecrno
and		a.processname	= b.processname
and		a.componentname	= b.componentname
and		a.errorid		= b.errorid
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_publish_err_det_local_info_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_publish_err_det_local_info_vw TO PUBLIC
END
GO


