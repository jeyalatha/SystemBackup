IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_integ_serv_map_RevEngg' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_integ_serv_map_RevEngg
    End
Go


create view  [de_fw_des_integ_serv_map_RevEngg]        
		as              
		select callingdataitem,callingsegment,callingservicename,component_name,createdby,createddate,customer_name,ecrno,integdataitem,integsegment,integservicename,modifiedby,modifieddate,process_name,project_name,sectionname,sequenceno,timestamp,updtime,upduser from rvw20appdb.dbo.de_fw_des_integ_serv_map_RevEngg a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_integ_serv_map_RevEngg' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_integ_serv_map_RevEngg TO PUBLIC
END
GO


