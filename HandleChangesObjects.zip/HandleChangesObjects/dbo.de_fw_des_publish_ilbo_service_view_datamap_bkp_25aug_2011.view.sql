IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_publish_ilbo_service_view_datamap_bkp_25aug_2011' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_publish_ilbo_service_view_datamap_bkp_25aug_2011
    End
Go


create view  [de_fw_des_publish_ilbo_service_view_datamap_bkp_25aug_2011]        
		as              
		select activity_name,activityid,componentname,control_bt_synonym,controlid,createdby,createddate,customername,dataitemname,ecrno,ilbocode,iscontrol,modifiedby,modifieddate,page_bt_synonym,processname,projectname,segmentname,servicename,taskname,timestamp,updtime,upduser,variablename,viewname from rvw20appdb.dbo.de_fw_des_publish_ilbo_service_view_datamap_bkp_25aug_2011 a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_publish_ilbo_service_view_datamap_bkp_25aug_2011' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_publish_ilbo_service_view_datamap_bkp_25aug_2011 TO PUBLIC
END
GO


