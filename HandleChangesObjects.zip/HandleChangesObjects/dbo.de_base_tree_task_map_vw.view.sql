IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_base_tree_task_map_vw' AND TYPE = 'V')
    Begin
        Drop View de_base_tree_task_map_vw
    End
Go



/************************************************************************************
procedure name and id   de_published_tree_task_map_vw   
description             
name of the author      
date created            
query file name         de_published_tree_task_map_vw
modifications history   
modified by             
modified date           
modified purpose        
***********************************************************************************/
create view [de_base_tree_task_map_vw]
	(customername,								projectname,										
	processname,								componentname,						activity_name,								
	ui_name,									page_name,							section_name,	
	control_name,								task_name)
as
select 	a.customer_name 		'customername',	a.project_name 			'projectname',		
		a.process_name			'processname',	a.component_name		'componentname',	a.activity_name			'activity_name',
		a.ui_name				'ui_name',		a.page_bt_synonym 		'page_name',		a.section_bt_synonym 	'section_name',
		b.control_bt_synonym	'control_name',	c.task_name				'task_name'
from 	de_ui_section a (nolock),
		de_ui_control b(nolock),
		de_action   c (nolock)
where 	a.customer_name		= 	b.customer_name
and 	a.project_name		= 	b.project_name
and 	a.process_name		= 	b.process_name
and 	a.component_name	= 	b.component_name
and 	a.activity_name		=	b.activity_name
and 	a.ui_name			= 	b.ui_name
and 	a.page_bt_synonym 	= 	b.page_bt_synonym
and 	a.section_bt_synonym= b.section_bt_synonym
and		b.customer_name		= 	c.customer_name
and 	b.project_name		= 	c.project_name
and 	b.process_name		= 	c.process_name
and 	b.component_name	= 	c.component_name
and 	b.activity_name		=	c.activity_name
and 	b.ui_name			= 	c.ui_name
and 	b.page_bt_synonym 	= 	c.page_bt_synonym
and 	b.control_bt_synonym= 	c.primary_control_bts
and 	a.section_type		= 	'TREE'

GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_base_tree_task_map_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_base_tree_task_map_vw TO PUBLIC
END
GO


