IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_publish_ilbo_service_view_attributemap_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_publish_ilbo_service_view_attributemap_vw
    End
Go


/* Creating View Script - de_fw_des_publish_ilbo_service_view_attributemap_vw on  Feb 14 2014 10:00AM  */
/************************************************************************************
procedure name and id   de_fw_des_publish_ilbo_service_view_attributemap_vw
description             The View used for listing service additional attributes
name of the author
date created
query file name         de_fw_des_publish_ilbo_service_view_attributemap_vw
modifications history
modified by             Ramachandran T
modified date          14 Feb 2014
modified purpose
************************************************************************************/
CREATE view [de_fw_des_publish_ilbo_service_view_attributemap_vw]
(activityid, componentname, controlid, customername, dataitemname, ecrno,
ilbocode, processname, projectname, segmentname, servicename, taskname ,
viewname, propertytype, propertyname)
as
select  a.activityid, a.componentname, a.controlid, a.customername, a.dataitemname, a.ecrno,
a.ilbocode, a.processname, a.projectname, a.segmentname, a.servicename, a.taskname,
a.viewname, a.propertytype, a.propertyname
from  de_fw_des_publish_ilbo_service_view_attributemap a (nolock)


GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_publish_ilbo_service_view_attributemap_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_publish_ilbo_service_view_attributemap_vw TO PUBLIC
END
GO


