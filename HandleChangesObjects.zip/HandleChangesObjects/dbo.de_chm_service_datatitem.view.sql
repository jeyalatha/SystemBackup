IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_chm_service_datatitem' AND TYPE = 'V')
    Begin
        Drop View de_chm_service_datatitem
    End
Go


create view  [de_chm_service_datatitem]        
		as              
		select component_name,createdby,createddate,customer_name,dataitem_name,modifiedby,modifieddate,process_name,project_name,segment_name,service_name from rvw20appdb.dbo.de_chm_service_datatitem a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_chm_service_datatitem' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_chm_service_datatitem TO PUBLIC
END
GO


