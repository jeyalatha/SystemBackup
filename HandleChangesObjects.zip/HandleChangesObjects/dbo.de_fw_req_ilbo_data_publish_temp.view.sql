IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_ilbo_data_publish_temp' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_ilbo_data_publish_temp
    End
Go


create view  [de_fw_req_ilbo_data_publish_temp]        
		as              
		select component_name,controlid,controlvariablename,createdby,createddate,customer_name,dataitemname,flowtype,havemultiple,ilbocode,iscontrol,link_name,linkid,mandatoryflag,modifiedby,modifieddate,new_linkid,process_name,project_name,subscription_name,timestamp,updtime,upduser,viewname from rvw20appdb.dbo.de_fw_req_ilbo_data_publish_temp a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_ilbo_data_publish_temp' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_ilbo_data_publish_temp TO PUBLIC
END
GO


