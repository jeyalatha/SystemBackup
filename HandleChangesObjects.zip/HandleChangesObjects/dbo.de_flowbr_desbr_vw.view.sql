IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_flowbr_desbr_vw' AND TYPE = 'V')
    Begin
        Drop View de_flowbr_desbr_vw
    End
Go


 
	/*	Creating View Script - de_flowbr_desbr_vw on 	Jun 26 2005 11:46PM		*/	

/************************************************************************************
procedure name and id   de_flowbr_desbr_vw
description             
name of the author      
date created            
query file name         de_flowbr_desbr_vw.sql
modifications history   
modified by             
modified date           
modified purpose        
************************************************************************************/
create	view	[de_flowbr_desbr_vw]
as
select	a.customer_name		'CustomerID',
		a.project_name		'ProjectID',
		a.process_name		'BPID',
		a.component_name	'ComponentName',
		c.functionid		'FunctionID',
		a.activity_name		'ActivityID',
		a.ui_name			'UIID',
		b.task_name			'TaskID',
		a.service_name		'ServiceName',
		a.flowbr_name		'FlowBRName',
		a.method_name		'DesBRName'
from	de_flowbr_method_map 			a (nolock),
		de_task_service_map				b (nolock),
		fw_bpt_function_component_vw	c (nolock)

where	a.customer_name		= b.customer_name
and		a.project_name		= b.project_name
and		a.process_name		= b.process_name
and		a.component_name	= b.component_name
and		a.activity_name		= b.activity_name
and		a.ui_name			= b.ui_name
and		a.service_name		= b.service_name

and		a.customer_name		= c.customerid
and		a.project_name		= c.projectid
and		a.process_name		= c.bpid
and		a.component_name	= c.componentname

GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_flowbr_desbr_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_flowbr_desbr_vw TO PUBLIC
END
GO


