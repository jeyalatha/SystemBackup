IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_base_bro_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_base_bro_vw
    End
Go



/************************************************************************************    
procedure name and id   de_fw_des_base_bro_vw
description             
name of the author      BharathiDasan.V.V
date created            16-07-2007                
query file name         de_fw_des_base_bro_vw
modifications history       
modified by                 
modified date               
modified purpose            
********************************************************************************/

Create view [de_fw_des_base_bro_vw] 
	   (brodescription ,	broname ,			broscope ,		brotype ,	clsid ,
		clsname ,			customername ,		dllname ,		progid ,	projectname ,		
		systemgenerated,	componentname,		processname ) 
as 
select 	a.brodescription ,	a.broname ,			a.broscope ,	a.brotype ,	a.clsid ,
		a.clsname ,			a.customer_name ,	a.dllname ,		a.progid ,	a.project_name ,
		a.systemgenerated , a.componentname ,	a.process_name
from 	de_fw_des_bro a (nolock)



GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_base_bro_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_base_bro_vw TO PUBLIC
END
GO


