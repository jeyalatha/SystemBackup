IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_flowbr_lng_extn' AND TYPE = 'V')
    Begin
        Drop View de_flowbr_lng_extn
    End
Go


create view  [de_flowbr_lng_extn]        
		as              
		select activity_name,component_name,control_id,createdby,createddate,customer_name,event_flag,flowbr_descr,flowbr_name,flowbr_sequence,flowbr_sysid,languageid,map_flag,modifiedby,modifieddate,page_bt_synonym,process_name,project_name,task_name,task_sysid,timestamp,ui_name,view_name from rvw20appdb.dbo.de_flowbr_lng_extn a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_flowbr_lng_extn' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_flowbr_lng_extn TO PUBLIC
END
GO


