IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_base_ilbo_link_publish_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_base_ilbo_link_publish_vw
    End
Go



/************************************************************************************    
procedure name and id   de_fw_req_publish_ilbo_link_publish_vw
description             The View used for Launch Pad
name of the author          
date created                
query file name         de_fw_req_publish_ilbo_link_publish_vw
modifications history       
modified by                 : Saravanan for PNR2.0_3889
modified date               : 20/09/2005
modified purpose            : The help pages are not getting launched because the link
 information is not available in the following tables. 1. fw_req_ilbo_data_publish 2. fw_req_ilbo_link_publish
************************************************************************************/  
/*
modified by                 : Ganesh for PNR2.0_4948
modified date               : 17/12/2005
modified purpose            : In Code generation, Activity dll not generated, it is hanging in this view de_fw_req_publish_ilbo_link_publish_vw. 
************************************************************************************/  

Create View [de_fw_req_base_ilbo_link_publish_vw]
		(activityid ,componentname ,customername ,description ,ilbocode ,linkid ,
		processname ,projectname ,taskname,ParentComponentname ) 
as 
select 	activityid ,component_name ,customer_name ,description ,ilbocode ,linkid ,
		process_name ,project_name ,taskname , component_name
from 	de_fw_req_ilbo_link_publish (nolock)
union
Select 	p.activityid, 	p.component_name,p.customer_name, p.description,  p.ilbocode, p.linkid,
		p.process_name, p.project_name, p.taskname ,u.component_name
from 	de_fw_req_ilbo_linkuse 	u (nolock), 
     	de_fw_req_ilbo_link_publish 	p (nolock)
where	p.customer_name	= u.customer_name
and		p.project_name	= u.project_name
and		p.linkid		= u.linkid
and		p.ilbocode		= u.childilbocode
and		p.component_name<> u.component_name
-- Union
-- Select 	lp.activityid, lp.componentname, lp.customername, lp.description, u.ecrno, lp.ilbocode, lp.linkid,
-- 	lp.processname, lp.projectname, lp.taskname 
-- from de_fw_req_publish_ilbo_data_use u (nolock), 
--      de_fw_req_publish_ilbo_data_publish p (nolock),  
--      de_fw_req_publish_activity a (nolock),
--      de_fw_req_publish_ilbo_link_publish lp (nolock)
-- where u.customername 	= p.customername
-- and   u.projectname  	= p.projectname
-- and   u.childilbocode 	= p.ilbocode 
-- and   u.linkid 		= p.linkid 
-- and   u.dataitemname 	= p.dataitemname
-- 
-- and   u.customername 	= lp.customername
-- and   u.projectname  	= lp.projectname
-- and   u.linkid 		= lp.linkid 
-- 
-- and   lp.customername 	= a.customername
-- and   lp.projectname  	= a.projectname
-- and   lp.activityid 	= a.activityid 
-- and   lp.ecrno    	= a.ecrno
-- 
-- and   lp.ecrno    	= p.ecrno
-- and   p.linkid 		= lp.linkid 
-- and   lp.ilbocode 	= u.childilbocode
-- 
-- and   lp.customername + lp.projectname + lp.processname + lp.componentname + lp.ecrno in  
-- (Select x.customer_name	+ x.project_name + x.process_name + x.component_name + x.ico_no
-- from	de_ui_ico	x(nolock)
-- where	x.modifieddate	=  (Select max(d.modifieddate)
-- 				from	de_ui_ico d(nolock)
-- 				where	x.customer_name	= d.customer_name
-- 				and	x.project_name	= d.project_name
-- 				and	x.process_name	= d.process_name
-- 				and	x.component_name = d.component_name
-- 				and     d.ico_status     = 'P'))
-- 



GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_base_ilbo_link_publish_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_base_ilbo_link_publish_vw TO PUBLIC
END
GO


