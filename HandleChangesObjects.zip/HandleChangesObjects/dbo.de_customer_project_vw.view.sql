IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_customer_project_vw' AND TYPE = 'V')
    Begin
        Drop View de_customer_project_vw
    End
Go


 
	/*	Creating View Script - de_customer_project_vw on 	Jun 26 2005 11:46PM		*/	

/************************************************************************************
procedure name and id   de_customer_project_vw
description             
name of the author      
date created            
query file name         de_customer_project_vw.sql
modifications history   
modified by             
modified date           
modified purpose        
************************************************************************************/
create view [de_customer_project_vw]
as
select	customer_name 							as customer_name, 
		project_name 							as project_name,
		'BASE' 									as req_no,
		customer_name+'_'+project_name+'_BASE' 	as adhoc_project_sysid ,
		userid									as userid,
		langid									as langid
from	es_projconfig_customer_project_vw(nolock)

GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_customer_project_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_customer_project_vw TO PUBLIC
END
GO


