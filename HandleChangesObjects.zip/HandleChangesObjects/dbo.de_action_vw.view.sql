IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_action_vw' AND TYPE = 'V')
    Begin
        Drop View de_action_vw
    End
Go



	/*	Creating View Script - de_action_vw on 	Jun 26 2005 11:46PM		*/	
/************************************************************************************
procedure name and id   de_action_vw
description             
name of the author      
date created            
query file name         de_action_vw.sql
modifications history   
modified by             
modified date           
modified purpose        
************************************************************************************/
create view [de_action_vw]
		(	customer_name,project_name,process_name,component_name,activity_name,ui_name,
			page_bt_synonym,task_name,task_descr,primary_control_bts,task_type )
as
select	customer_name,project_name,process_name,component_name,activity_name,ui_name,
		page_bt_synonym,task_name,task_descr,primary_control_bts,task_type
from	de_action (nolock)


GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_action_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_action_vw TO PUBLIC
END
GO


