IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_service_tmp' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_service_tmp
    End
Go


create view  [de_fw_des_service_tmp]              
			(createdby,createddate,customer_name,guid,modifiedby,modifieddate,service_name,timestamp)        
			as              
			select createdby,createddate,customer_name,guid,modifiedby,modifieddate,service_name,timestamp from rvw20appdb.dbo.de_fw_des_service_tmp (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_service_tmp' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_service_tmp TO PUBLIC
END
GO


