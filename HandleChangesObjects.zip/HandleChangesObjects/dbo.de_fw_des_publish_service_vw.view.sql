IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_publish_service_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_publish_service_vw
    End
Go


/* Creating View Script - de_fw_des_publish_service_vw on  Jun 26 2005 11:46PM  */

/************************************************************************************
procedure name and id   de_fw_des_publish_service_vw
description             The View used for Launch Pad
name of the author
date created
query file name         de_fw_des_publish_service_vw
modifications history
modified by                 Saravan Kumar P
modified date               14-Dec-2006
modified purpose            BugID : PNR2.0_11386
modified by                 Balaji D
modified date               1-March-2011
modified purpose            BugID : PNR2.0_35494
************************************************************************************/
create view [de_fw_des_publish_service_vw]
(componentname ,customername ,ecrno ,isintegser ,processingtype ,processname ,
projectname ,servicename ,servicetype ,statusflag ,svconame,isCached,isZipped,SetKey_Pattern,ClearKey_Pattern ) --BugID : PNR2.0_35494
as
select  componentname ,customername ,ecrno ,isintegser ,processingtype ,processname,
projectname ,ltrim(rtrim(servicename)) ,servicetype ,statusflag ,svconame,isCached,isZipped,SetKey_Pattern,ClearKey_Pattern /*PNR2.0_11386,BugID : PNR2.0_35494  */
from  de_fw_des_publish_service (nolock)
union
-- code modified by Ganesh for the bugid :: ECPFSUPPORT_000008 on 23/2/05
-- bugdescr :: Only integration service is to populated in the view for the linked components.
select  sr.componentname ,sr.customer_name ,ps.ecrno,sr.isintegser ,sr.processingtype ,sr.process_name,
sr.project_name ,sr.servicename ,sr.servicetype ,1 ,sr.svconame,sr.isCached,sr.isZipped,sr.SetKey_Pattern,sr.ClearKey_Pattern --BugID : PNR2.0_35494
from  de_fw_des_service sr (nolock),
de_fw_des_publish_processsection_br_is ps(nolock)
where  sr.servicename   =   ps.integservicename
and  sr.customer_name  =   ps.customername
and  sr.project_name   =   ps.projectname
and  sr.isintegser  =  1
and  sr.componentname  <>  ps.componentname
-- code modified by Ganesh for the bugid ::  ECPFSUPPORT_000008 on 23/2/05
-- bugdescr :: Only integration service is to populated in the view for the linked components.

GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_publish_service_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_publish_service_vw TO PUBLIC
END
GO


