IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_action_reuse_info' AND TYPE = 'V')
    Begin
        Drop View de_action_reuse_info
    End
Go


create view  [de_action_reuse_info]              
					(activity_name,component_name,createdby,createddate,customer_name,ecrno,modifiedby,modifieddate,page_bt_synonym,primary_control_bts,process_name,project_name,reuse_activity,reuse_page,reuse_task,reuse_ui,task_descr,task_name,task_pattern,task_seq,task_sysid,task_type,timestamp,ui_name,ui_sysid)          
					as              
					select activity_name,component_name,createdby,createddate,customer_name,ecrno,modifiedby,modifieddate,page_bt_synonym,primary_control_bts,process_name,project_name,reuse_activity,reuse_page,reuse_task,reuse_ui,task_descr,task_name,task_pattern,task_seq,task_sysid,task_type,timestamp,ui_name,ui_sysid from rvw_publish_db.dbo.de_published_action_reuse_info a (nolock)        
					where exists (select 'x' from De_Customer_Space b (nolock)        
					where     a.customer_name   = b.customername        
					and       a.project_name    = b.projectname        
					and       a.process_name    = b.processname        
					and       a.component_name  = b.componentname    
					and       a.ecrno        = b.ecrno )
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_action_reuse_info' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_action_reuse_info TO PUBLIC
END
GO


