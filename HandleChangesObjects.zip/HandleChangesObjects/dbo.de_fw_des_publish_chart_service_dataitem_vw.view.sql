IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_publish_chart_service_dataitem_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_publish_chart_service_dataitem_vw
    End
Go



/*	Creating View Script - de_fw_des_publish_chart_service_dataitem_vw on 	Jan 17 2005 11:46PM		*/	

/************************************************************************************
procedure name and id   de_fw_des_publish_chart_service_dataitem_vw   
description             
name of the author      
date created            17-Jan-2006
query file name         de_fw_des_publish_chart_service_dataitem_vw.sql
modifications history   
modified by             
modified date           
modified purpose        
***********************************************************************************/
create view [de_fw_des_publish_chart_service_dataitem_vw]
	(customer_name, project_name, process_name, component_name, ecrno,	
	 chart_id, chart_section, chart_attribute, servicename, segmentname, 
	 dataitemname, ispartofkey, mandatoryflag, flowattribute, defaultvalue)
as
select 
	customer_name, project_name, process_name, component_name, ecrno,	
	 chart_id, chart_section, chart_attribute, servicename, segmentname, 
	 dataitemname, ispartofkey, mandatoryflag, flowattribute, defaultvalue
from de_fw_des_publish_chart_service_dataitem (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_publish_chart_service_dataitem_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_publish_chart_service_dataitem_vw TO PUBLIC
END
GO


