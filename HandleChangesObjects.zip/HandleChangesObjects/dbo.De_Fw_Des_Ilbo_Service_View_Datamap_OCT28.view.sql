IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='De_Fw_Des_Ilbo_Service_View_Datamap_OCT28' AND TYPE = 'V')
    Begin
        Drop View De_Fw_Des_Ilbo_Service_View_Datamap_OCT28
    End
Go


create view  [De_Fw_Des_Ilbo_Service_View_Datamap_OCT28]        
		as              
		select activity_name,activityid,component_name,control_bt_synonym,controlid,createdby,createddate,customer_name,dataitemname,ecrno,ilbocode,iscontrol,modifiedby,modifieddate,page_bt_synonym,process_name,project_name,segmentname,servicename,taskname,timestamp,updtime,upduser,variablename,viewname,viewname_bk from rvw20appdb.dbo.De_Fw_Des_Ilbo_Service_View_Datamap_OCT28 a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'De_Fw_Des_Ilbo_Service_View_Datamap_OCT28' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  De_Fw_Des_Ilbo_Service_View_Datamap_OCT28 TO PUBLIC
END
GO


