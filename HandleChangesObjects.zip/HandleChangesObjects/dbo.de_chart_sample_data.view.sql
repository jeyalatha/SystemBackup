IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_chart_sample_data' AND TYPE = 'V')
    Begin
        Drop View de_chart_sample_data
    End
Go


create view  [de_chart_sample_data]              
					(activity_name,component_name,createdby,createddate,customer_name,ecrno,modifiedby,modifieddate,page_bt_synonym,process_name,project_name,req_no,section_bt_synonym,seq_no,tooltip_text,ui_name,x_series_data,y_error_value,y_series_id,y_value)          
					as              
					select activity_name,component_name,createdby,createddate,customer_name,ecrno,modifiedby,modifieddate,page_bt_synonym,process_name,project_name,req_no,section_bt_synonym,seq_no,tooltip_text,ui_name,x_series_data,y_error_value,y_series_id,y_value from rvw_publish_db.dbo.de_published_chart_sample_data a (nolock)        
					where exists (select 'x' from De_Customer_Space b (nolock)        
					where     a.customer_name   = b.customername        
					and       a.project_name    = b.projectname        
					and       a.process_name    = b.processname        
					and       a.component_name  = b.componentname    
					and       a.ecrno        = b.ecrno )
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_chart_sample_data' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_chart_sample_data TO PUBLIC
END
GO


