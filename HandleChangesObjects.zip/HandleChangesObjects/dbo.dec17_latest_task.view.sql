IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='dec17_latest_task' AND TYPE = 'V')
    Begin
        Drop View dec17_latest_task
    End
Go


create view  [dec17_latest_task]        
		as              
		select control_id,controlname,pagename,sectionname,task_name,task_type,ui_name,UIname,view_name from rvw20appdb.dbo.dec17_latest_task a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'dec17_latest_task' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  dec17_latest_task TO PUBLIC
END
GO


