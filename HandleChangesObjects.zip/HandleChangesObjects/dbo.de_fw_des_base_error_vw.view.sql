IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_base_error_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_base_error_vw
    End
Go



/************************************************************************************    
procedure name and id   de_fw_des_base_error_vw
description             
name of the author      BharathiDasan.V.V
date created            16-07-2007                
query file name         de_fw_des_base_error_vw
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/  
create view 	[de_fw_des_base_error_vw] 
	  (	componentname ,	customername ,	defaultcorrectiveaction ,	defaultseverity ,
		detaileddesc ,	displaytype ,	errorid ,					errormessage ,
		errorsource ,	processname ,	projectname ,				reqerror ) 
as 
select 	componentname,	customer_name ,	defaultcorrectiveaction ,	defaultseverity ,
		detaileddesc ,	displaytype ,	errorid ,					errormessage ,
		errorsource ,	process_name ,	project_name ,				reqerror 
from 	de_fw_des_error (nolock)





GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_base_error_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_base_error_vw TO PUBLIC
END
GO


