IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_exrep_detail_layout' AND TYPE = 'V')
    Begin
        Drop View de_exrep_detail_layout
    End
Go


create view  [de_exrep_detail_layout]        
		as              
		select activity_name,component_name,control_name,createdby,createddate,custom_formula,customer_name,field_caption,field_name,field_sequence,mapped_column,modifiedby,modifieddate,page_name,process_name,project_name,row_aggregate,section_name,sheet_id,template_id,ui_name from rvw20appdb.dbo.de_exrep_detail_layout a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_exrep_detail_layout' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_exrep_detail_layout TO PUBLIC
END
GO


