IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_publish_be_placeholder' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_publish_be_placeholder
    End
Go


create view  [de_fw_des_publish_be_placeholder]              
			(componentname,createdby,createddate,customername,ecrno,errorid,method_name,methodid,modifiedby,modifieddate,parametername,placeholdername,processname,projectname,timestamp,updtime,upduser)        
			as              
			select componentname,createdby,createddate,customername,ecrno,errorid,method_name,methodid,modifiedby,modifieddate,parametername,placeholdername,processname,projectname,timestamp,updtime,upduser from rvw20appdb.dbo.de_fw_des_publish_be_placeholder (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_publish_be_placeholder' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_publish_be_placeholder TO PUBLIC
END
GO


