IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_processsection_br_is' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_processsection_br_is
    End
Go


CREATE view  [de_fw_des_processsection_br_is]              
					as              
					select componentname 'component_name' ,connectivityflag,controlexpression,createdby,createddate,customername 'customer_name' ,ecrno,executionflag,integservicename,isbr,method_name,methodid,modifiedby,modifieddate,processname 'process_name' ,projectname 'project_name' ,sectionname,sequenceno,servicename,timestamp,updtime,upduser,SpecID,SpecVersion,Path,SpecName,OperationID,OperationVerb,Version,UPEControlExpr,QueryID from RVW_Publish_DB.dbo.de_fw_des_publish_processsection_br_is a (nolock)        
					where exists (select 'x' from De_Customer_Space b (nolock)        
					where     a.customername   = b.customername        
					and       a.projectname    = b.projectname        
					and       a.processname    = b.processname        
					and       a.componentname  = b.componentname    
					and       a.ecrno        = b.ecrno )



GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_processsection_br_is' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_processsection_br_is TO PUBLIC
END
GO


