IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_processsection_tmp' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_processsection_tmp
    End
Go


create view  [de_fw_des_processsection_tmp]              
			(component_name,createdby,createddate,customer_name,guid,modifiedby,modifieddate,process_name,project_name,sectionname,sequenceno,servicename,timestamp)        
			as              
			select component_name,createdby,createddate,customer_name,guid,modifiedby,modifieddate,process_name,project_name,sectionname,sequenceno,servicename,timestamp from rvw20appdb.dbo.de_fw_des_processsection_tmp (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_processsection_tmp' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_processsection_tmp TO PUBLIC
END
GO


