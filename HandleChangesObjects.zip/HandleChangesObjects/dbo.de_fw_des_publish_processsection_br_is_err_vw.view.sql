IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_publish_processsection_br_is_err_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_publish_processsection_br_is_err_vw
    End
Go



/*	Creating View Script - de_fw_des_publish_processsection_br_is_err_vw  on 	Oct 19 2005 04:23PM		*/	

/************************************************************************************    
procedure name and id   de_fw_des_publish_processsection_br_is_err_vw 
description             The View used for Launch Pad
name of the author          
date created                
query file name         de_fw_des_publish_processsection_br_is_err_vw 
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/  
create view [de_fw_des_publish_processsection_br_is_err_vw] 
		(componentname ,connectivityflag ,controlexpression ,customername ,ecrno ,
		executionflag ,integservicename ,isbr ,methodid ,processname ,projectname ,
		sectionname ,sequenceno ,servicename ) 
as 
select 	componentname ,connectivityflag ,controlexpression ,customername ,ecrno ,
		executionflag ,integservicename ,isbr ,methodid ,processname ,projectname ,
		sectionname ,sequenceno ,servicename 
from 	de_fw_des_publish_processsection_br_is (nolock)
union
select 	a.componentname as componentname,
		1 as connectivityflag, 
		null as controlexpression, 
		a.customername as customername, 
		a.ecrno as ecrno,
		1 as executionflag, 
		null as integservicename, 
		1 as isbr, 
		0 as methodid, 
		a.processname as processname, 
		a.projectname as projectname,
		b.sectionname as sectionname, 
		101 as sequenceno, 
		a.servicename as servicename 
from 	de_fw_des_publish_service a (nolock),
		de_fw_des_publish_processsection b (nolock)
where	a.customername 	= b.customername
and		a.projectname	= b.projectname
and		a.ecrno			= b.ecrno
and		a.processname	= b.processname
and		a.componentname	= b.componentname
and		a.servicename	= b.servicename



GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_publish_processsection_br_is_err_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_publish_processsection_br_is_err_vw TO PUBLIC
END
GO


