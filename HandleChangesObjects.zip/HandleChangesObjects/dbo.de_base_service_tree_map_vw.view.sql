IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_base_service_tree_map_vw' AND TYPE = 'V')
    Begin
        Drop View de_base_service_tree_map_vw
    End
Go



/************************************************************************************
procedure name and id   de_base_service_tree_map_vw
description             
name of the author      
date created            
query file name         de_base_service_tree_map_vw
modifications history   
modified by             
modified date           
modified purpose        
***********************************************************************************/
CREATE View [de_base_service_tree_map_vw]
		(customername,	 			projectname,					
		processname,				componentname,					activity_name,				
		ui_name,					page_name,						section_name,		
		servicename,				taskname,						control_bt_synonym,				
		clear_tree_before_population)
as

select 				
distinct 	a.customer_name					'customername',	 
			a.project_name					'projectname',
			a.process_name					'processname',
			a.component_name					'componentname',
			d.activity_name					'activity_name',
			d.ui_name						'ui_name',	
			d.page_bt_synonym				'page_name',
			d.section_bt_synonym			'section_name',
			a.servicename					'servicename',		
			b.taskname						'taskname',
			d.control_bt_synonym			'control_bt_synonym',
			case isnull(e.clear_tree_before_population,0)
			when 0 then 'No' else 'Yes'		end 'clear_tree_before_population'
from 	de_fw_des_service_segment a (nolock),
		de_fw_des_ilbo_service_view_datamap b (nolock),
		de_ui_section 	c (nolock),
		de_ui_control			d (nolock),
		de_flowbr_combo e (nolock)
where 	a.customer_name			= b.customer_name
and 	a.project_name			= b.project_name
and 	a.process_name			= b.process_name
and 	a.component_name			= b.component_name
and 	a.servicename			= b.servicename	
and		a.segmentname in ('tree_data_segment', 'tree_config_segment')
and 	c.customer_name			= 	d.customer_name
and 	c.project_name			= 	d.project_name
and 	c.process_name			= 	d.process_name
and 	c.component_name		= 	d.component_name
and 	c.activity_name			=	d.activity_name
and 	c.ui_name				= 	d.ui_name
and 	c.section_bt_synonym 	= 	d.section_bt_synonym 

and		d.customer_name			= 	b.customer_name
and 	d.project_name			= 	b.project_name
and 	d.process_name			= 	b.process_name
and 	d.component_name		= 	b.component_name
and 	d.ui_name				= 	b.ilbocode
and 	d.control_id			= 	b.controlid
and 	d.view_name				= 	b.viewname
and 	c.section_type			= 	'TREE'

and		d.customer_name			= 	e.customer_name
and 	d.project_name			= 	e.project_name
and 	d.process_name			= 	e.process_name
and 	d.component_name		= 	e.component_name
and 	d.ui_name				= 	e.ui_name
and 	d.control_bt_synonym	= 	e.combo_bt_synonym
and 	d.page_bt_synonym		= 	e.combo_page_name
and 	b.taskname				= 	e.task_name
union

select 				
distinct 	a.customer_name					'customername',	 
			a.project_name					'projectname',
			a.process_name					'processname',
			a.component_name					'componentname',
			d.activity_name					'activity_name',
			d.ui_name						'ui_name',	
			d.page_bt_synonym				'page_name',
			d.section_bt_synonym			'section_name',
			a.servicename					'servicename',		
			b.taskname						'taskname',
			d.control_bt_synonym			'control_bt_synonym',
			'Yes'							'clear_tree_before_population'
from 	de_fw_des_service_segment a (nolock),
		de_fw_des_ilbo_service_view_datamap b (nolock),
		de_ui_section 	c (nolock),
		de_ui_control			d (nolock)
where 	a.customer_name		= b.customer_name
and 	a.project_name		= b.project_name
and 	a.process_name		= b.process_name
and 	a.component_name		= b.component_name
and 	a.servicename		= b.servicename	
and		a.segmentname in ('tree_data_segment', 'tree_config_segment')

and 	c.customer_name			= 	d.customer_name
and 	c.project_name			= 	d.project_name
and 	c.process_name			= 	d.process_name
and 	c.component_name		= 	d.component_name
and 	c.activity_name			=	d.activity_name
and 	c.ui_name				= 	d.ui_name
and 	c.section_bt_synonym 	= 	d.section_bt_synonym 

and		d.customer_name			= 	b.customer_name
and 	d.project_name			= 	b.project_name
and 	d.process_name			= 	b.process_name
and 	d.component_name		= 	b.component_name
and 	d.ui_name				= 	b.ilbocode
and 	d.control_id			= 	b.controlid
and 	d.view_name				= 	b.viewname
and 	c.section_type			= 	'TREE'

and  	not exists (Select 	'x' 
					from	de_flowbr_combo e (nolock)
					where	d.customer_name			= 	e.customer_name
					and 	d.project_name			= 	e.project_name
					and 	d.process_name			= 	e.process_name
					and 	d.component_name		= 	e.component_name
					and 	d.ui_name				= 	e.ui_name
					and 	d.control_bt_synonym	= 	e.combo_bt_synonym
					and 	d.page_bt_synonym		= 	e.combo_page_name
					and 	b.taskname				= 	e.task_name)
			
			
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_base_service_tree_map_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_base_service_tree_map_vw TO PUBLIC
END
GO


