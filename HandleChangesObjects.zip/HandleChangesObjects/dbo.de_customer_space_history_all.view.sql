IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_customer_space_history_all' AND TYPE = 'V')
    Begin
        Drop View de_customer_space_history_all
    End
Go


CREATE view  [de_customer_space_history_all]        
as              
select	componentname,	createdby,	createddate,	CustomerName,	database_name,
		ecrno,			modby,		moddate,		processname,	ProjectName,
		validate_req ,	map 
from	rvw20appdb.dbo.de_customer_space_history_all a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_customer_space_history_all' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_customer_space_history_all TO PUBLIC
END
GO


