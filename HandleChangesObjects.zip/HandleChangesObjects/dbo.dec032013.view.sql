IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='dec032013' AND TYPE = 'V')
    Begin
        Drop View dec032013
    End
Go


create view  [dec032013]        
		as              
		select activitydescription,activityname,componentdescription,componentname,customername,ilbodescription,ilboname,NewSectionName,pagename,processdescription,processname,projectname,sectionname from rvw20appdb.dbo.dec032013 a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'dec032013' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  dec032013 TO PUBLIC
END
GO


