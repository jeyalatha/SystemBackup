IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_custom_listedit_Tst' AND TYPE = 'V')
    Begin
        Drop View de_custom_listedit_Tst
    End
Go


create view  [de_custom_listedit_Tst]      ----it should as same as view only
		as              
		select	activity_name,		component_name,		createdby,			createddate,	customer_name,		list_index_search,	list_recurrent_search,
				list_result_column,	list_search_context,list_search_delay,	list_search_id,	list_select_column,	list_width,			listedit_synonym,
				modifiedby,			modifieddate,		page_bt_synonym,	process_name,	project_name,		ui_name,			Ecrno 
		from rvw_publish_Db.dbo.de_published_custom_listedit a (nolock)
		where exists (select 'x' from De_Customer_Space b (nolock)                
						where     a.customer_name   = b.customername                
						and       a.project_name    = b.projectname                
						and       a.process_name    = b.processname                
						and       a.component_name  = b.componentname            
						and       a.ecrno           = b.ecrno )   


GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_custom_listedit_Tst' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_custom_listedit_Tst TO PUBLIC
END
GO


