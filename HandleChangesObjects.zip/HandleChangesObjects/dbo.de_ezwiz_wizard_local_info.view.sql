IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_ezwiz_wizard_local_info' AND TYPE = 'V')
    Begin
        Drop View de_ezwiz_wizard_local_info
    End
Go


create view  [de_ezwiz_wizard_local_info]        
		as              
		select component_name,created_by,created_date,customer_name,ecrno,lang_id,modified_by,modified_date,process_name,project_name,timestamp,wizard_desc,wizard_name from rvw20appdb.dbo.de_ezwiz_wizard_local_info a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_ezwiz_wizard_local_info' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_ezwiz_wizard_local_info TO PUBLIC
END
GO


