IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_catInfo_vw' AND TYPE = 'V')
    Begin
        Drop View de_catInfo_vw
    End
Go



	/*	Creating View Script - de_catInfo_vw on 	Jun 26 2005 11:46PM		*/	
/************************************************************************************
procedure name and id   de_catInfo_vw
description             Primary Task and Secondary Task Data For ""DE"" Workflow incorporation
name of the author    Venkitesh.A.S   
date created            
query file name         de_catInfo_vw.sql
modifications history   
modified by             
modified date           
modified purpose        
************************************************************************************/
CREATE view [de_catInfo_vw] as
Select  distinct  
  a.customer_code,a.project_code,
  a.area_code,a.component_name,
  b.Component_Descr ,
  b.activity_name,
   b.Activity_Descr ,
  c.task_name,
  c.Task_Descr ,
  d.workflow_action,
  e.wf_code_description,
  c.ui_name  

from
  re_wsinp_cat_hdr a (nolock),
  re_ui_ecr       b (nolock),
  re_action        c (nolock),
  re_wsinp_task_dtl d(nolock),
  re_wsinp_qc_lang_dtl e (nolock)     
where
  a.customer_code  = b.customer_name
and      a.project_code   = b.project_name
and      a.component_name = b.component_name
and      a.activity_name  = b.activity_name

and  a.customer_code  = c.customer_name
and      a.project_code   = c.project_name
and      a.component_name = c.component_name
and      a.activity_name  = c.activity_name
and   a.task_name   = c.task_name

and   b.customer_name  = c.customer_name

and   b.project_name   = c.project_name
and      b.component_name = c.component_name
and      b.activity_name  = c.activity_name

and   c.project_name   = d.project_code
and      c.customer_name = d.customer_code
and      a.cat_key  = d.cat_key

and e.wf_quick_code_type='WACT'
and e.wf_quick_code =d.workflow_action

and d.initiated_task   <> 'OTHR'



GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_catInfo_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_catInfo_vw TO PUBLIC
END
GO


