IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_error_local_info' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_error_local_info
    End
Go


create view  [de_fw_req_error_local_info]              
					as              
					select componentname 'component_name' ,createdby,createddate,customername 'customer_name' ,ecrno,errorcode,errordesc,langid,modifiedby,modifieddate,processname 'process_name' ,projectname 'project_name' ,timestamp,updtime,upduser from rvw_publish_db.dbo.de_fw_req_publish_error_local_info a (nolock)        
					where exists (select 'x' from De_Customer_Space b (nolock)        
					where     a.customername   = b.customername        
					and       a.projectname    = b.projectname        
					and       a.processname    = b.processname        
					and       a.componentname  = b.componentname    
					and       a.ecrno        = b.ecrno )
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_error_local_info' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_error_local_info TO PUBLIC
END
GO


