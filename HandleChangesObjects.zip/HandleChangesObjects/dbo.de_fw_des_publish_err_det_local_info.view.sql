IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_publish_err_det_local_info' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_publish_err_det_local_info
    End
Go


create view  [de_fw_des_publish_err_det_local_info]              
			(componentname,createdby,createddate,customername,detaileddesc,ecrno,errorid,errormessage,langid,modifiedby,modifieddate,processname,projectname,timestamp,updtime,upduser)        
			as              
			select componentname,createdby,createddate,customername,detaileddesc,ecrno,errorid,errormessage,langid,modifiedby,modifieddate,processname,projectname,timestamp,updtime,upduser from rvw20appdb.dbo.de_fw_des_publish_err_det_local_info (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_publish_err_det_local_info' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_publish_err_det_local_info TO PUBLIC
END
GO


