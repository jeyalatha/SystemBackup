IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_flowbr_method_map' AND TYPE = 'V')
    Begin
        Drop View de_flowbr_method_map
    End
Go


create view  [de_flowbr_method_map]              
					(activity_name,component_name,createdby,createddate,customer_name,ecrno,flowbr_name,metbr_sysid,method_name,modifiedby,modifieddate,process_name,project_name,service_name,timestamp,ui_name)          
					as              
					select activity_name,component_name,createdby,createddate,customer_name,ecrno,flowbr_name,metbr_sysid,method_name,modifiedby,modifieddate,process_name,project_name,service_name,timestamp,ui_name from rvw_publish_db.dbo.de_published_flowbr_method_map a (nolock)        
					where exists (select 'x' from De_Customer_Space b (nolock)        
					where     a.customer_name   = b.customername        
					and       a.project_name    = b.projectname        
					and       a.process_name    = b.processname        
					and       a.component_name  = b.componentname    
					and       a.ecrno        = b.ecrno )
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_flowbr_method_map' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_flowbr_method_map TO PUBLIC
END
GO


