IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_base_method_doc_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_base_method_doc_vw
    End
Go



	/*	Creating View Script - de_fw_des_method_doc_vw on 	Jun 26 2005 11:46PM		*/	

/************************************************************************************
procedure name and id   de_fw_des_method_doc_vw
description             
name of the author     	: A.G.Senthil kumar 
date created            
query file name         de_fw_des_method_doc_vw.sql
modifications history    : for Development Packaging
modified by             
modified date           
modified purpose        
************************************************************************************/
Create view [de_fw_des_base_method_doc_vw]
(		customer_name , 	project_name , 		process_name , 		component_name,
		activity_name , 	ui_name, 			task_name, 			service_name,
		servicetype,  		method_name, 		methodid,			doctext
		)
as 
select 	distinct 
		map.customer_name , map.project_name , 	map.process_name , 	map.component_name,
		map.activity_name , map.ui_name, 		map.task_name, 		map.service_name,
		sr.servicetype,  	mt.methodname, 		pr.methodid,		br.doctext
				
from 	de_task_service_map 			map(nolock),
	 	de_fw_des_processsection_br_is 	pr (nolock),
	 	de_fw_des_br_documentation		br (nolock),
		de_fw_des_service				sr (nolock),
		de_fw_des_businessrule			mt (nolock)	
where 	map.customer_name		= pr.customer_name
and   	map.project_name		= pr.project_name
and   	map.process_name		= pr.process_name
and 	map.component_name 		= pr.component_name
and   	map.service_name 		= pr.servicename

and 	map.customer_name		= sr.customer_name
and   	map.project_name		= sr.project_name
and   	map.process_name		= sr.process_name
and 	map.component_name 		= sr.componentname
and   	map.service_name 		= sr.servicename


and   	pr.customer_name		= br.customer_name
and   	pr.project_name			= br.project_name
and   	pr.process_name			= br.process_name
and   	pr.component_name 		= br.component_name
and   	pr.methodid 			= br.methodid

and   	pr.customer_name		= sr.customer_name
and   	pr.project_name			= sr.project_name
and   	pr.process_name			= sr.process_name
and   	pr.component_name 		= sr.componentname
and		pr.servicename			= sr.servicename

and   	br.customer_name		= mt.customer_name
and   	br.project_name			= mt.project_name
and   	br.process_name			= mt.process_name
and   	br.component_name 		= mt.component_name
and   	br.methodid 			= mt.methodid

and   	pr.customer_name		= mt.customer_name
and   	pr.project_name			= mt.project_name
and   	pr.process_name			= mt.process_name
and   	pr.component_name 		= mt.component_name
and   	pr.methodid 			= mt.methodid


GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_base_method_doc_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_base_method_doc_vw TO PUBLIC
END
GO


