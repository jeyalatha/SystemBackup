IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_base_chart_detail_vw' AND TYPE = 'V')
    Begin
        Drop View de_base_chart_detail_vw
    End
Go



/************************************************************************************
procedure name and id   de_base_chart_detail_vw   
description             
name of the author      
date created            
query file name         de_base_chart_detail_vw.sql
modifications history   
modified by             
modified date           
modified purpose        
***********************************************************************************/
create view [de_base_chart_detail_vw]
as
select 	distinct 
		customer_name  			'customername',
		project_name			'projectname',
		process_name			'processname',
		component_name			'componentname',
		activity_name			'activity_name',
		ui_name					'ui_name',
		page_bt_synonym			'page_name',
		section_bt_synonym 		'section_name'
from 	de_ui_section	(nolock)
where 	section_type 		= 'Chart'
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_base_chart_detail_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_base_chart_detail_vw TO PUBLIC
END
GO


