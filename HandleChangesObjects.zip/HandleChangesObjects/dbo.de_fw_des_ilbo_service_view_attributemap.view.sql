IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_ilbo_service_view_attributemap' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_ilbo_service_view_attributemap
    End
Go


create view  [de_fw_des_ilbo_service_view_attributemap]              
					as              
					select activity_name,activityid,componentname 'component_name' ,control_bt_synonym,controlid,createdby,createddate,customername 'customer_name' ,dataitemname,ecrno,ilbocode,modifiedby,modifieddate,page_bt_synonym,processname 'process_name' ,projectname 'project_name' ,PropertyName,PropertyType,segmentname,servicename,taskname,viewname from RVW_Publish_DB.dbo.de_fw_des_publish_ilbo_service_view_attributemap a (nolock)        
					where exists (select 'x' from De_Customer_Space b (nolock)        
					where     a.customername   = b.customername        
					and       a.projectname    = b.projectname        
					and       a.processname    = b.processname        
					and       a.componentname  = b.componentname    
					and       a.ecrno        = b.ecrno )
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_ilbo_service_view_attributemap' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_ilbo_service_view_attributemap TO PUBLIC
END
GO


