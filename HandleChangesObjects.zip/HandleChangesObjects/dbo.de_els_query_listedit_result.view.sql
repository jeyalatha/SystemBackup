IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_els_query_listedit_result' AND TYPE = 'V')
    Begin
        Drop View de_els_query_listedit_result
    End
Go


create view [de_els_query_listedit_result](
CustomerName,
ProjectName,
Ecrno,
ProcessName,
ComponentName,
ActivityName,
UiName,
ListControlSynonym,
ListControlID,
ListViewname,
QueryID,
ResultColumnName,
MappedSynonym,
MappedControlID,
MappedViewName,
ParameterCaption,
Width,
IsVisible,
Createdby,
Createddate,
Modifedby,
Modifieddate,
Seqno)
as select 
CustomerName,
ProjectName,
Ecrno,
ProcessName,
ComponentName,
ActivityName,
UiName,
ListControlSynonym,
ListControlID,
ListViewname,
QueryID,
ResultColumnName,
MappedSynonym,
MappedControlID,
MappedViewName,
ParameterCaption,
Width,
IsVisible,
Createdby,
Createddate,
Modifedby,
Modifieddate,
Seqno
from RVW_Publish_DB.dbo.de_published_els_query_listedit_result a
where exists (select 'x' from De_Customer_Space b (nolock)          
     where     a.customername   = b.customername          
     and       a.projectname    = b.projectname          
     and       a.processname    = b.processname          
     and       a.componentname  = b.componentname      
     and       a.ecrno        = b.ecrno )  
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_els_query_listedit_result' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_els_query_listedit_result TO PUBLIC
END
GO


