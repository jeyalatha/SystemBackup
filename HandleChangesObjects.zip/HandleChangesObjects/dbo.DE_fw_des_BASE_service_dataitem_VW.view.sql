IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='DE_fw_des_BASE_service_dataitem_VW' AND TYPE = 'V')
    Begin
        Drop View DE_fw_des_BASE_service_dataitem_VW
    End
Go



/*	Creating View Script - de_fw_des_publish_service_dataitem_vw on 	Jun 26 2005 11:46PM		*/	

/************************************************************************************    
procedure name and id   de_fw_des_publish_service_dataitem_vw
description             The View used for Launch Pad
name of the author      
date created            
query file name         de_fw_des_publish_service_dataitem_vw
modifications history   
modified by             
modified date           
modified purpose        
************************************************************************************/  
Create view [DE_fw_des_BASE_service_dataitem_VW] 
		(componentname ,customername ,dataitemname ,defaultvalue ,
		flowattribute ,ispartofkey ,mandatoryflag ,processname ,projectname ,
		segmentname ,servicename,ParentComponentname ) 
as 
select 	component_name ,customer_name ,dataitemname ,defaultvalue ,
		flowattribute ,ispartofkey ,mandatoryflag ,process_name ,project_name ,
		segmentname ,servicename ,
	component_name			
from 	de_fw_des_service_dataitem (nolock)
union
select 	sr.component_name ,sr.customer_name ,sr.dataitemname ,sr.defaultvalue ,
		sr.flowattribute ,sr.ispartofkey ,sr.mandatoryflag ,sr.process_name ,sr.project_name ,
		sr.segmentname ,sr.servicename ,	ps.component_name
from 	de_fw_des_service_dataitem sr(nolock),
		de_fw_des_processsection_br_is ps(nolock)
where 	sr.servicename 		=  ps.integservicename
and 	sr.customer_name 	=  ps.customer_name
and 	sr.project_name  	=  ps.project_name
and		sr.component_name	<> ps.component_name





GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'DE_fw_des_BASE_service_dataitem_VW' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  DE_fw_des_BASE_service_dataitem_VW TO PUBLIC
END
GO


