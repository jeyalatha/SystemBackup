IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_base_context_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_base_context_vw
    End
Go



/************************************************************************************    
procedure name and id   de_fw_des_base_context_vw
description             
name of the author      BharathiDasan.V.V
date created            16-07-2007               
query file name         de_fw_des_base_context_vw
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/  
create view [de_fw_des_base_context_vw] 
	  (	componentname ,	correctiveaction ,	customername ,	errorcontext ,	errorid ,
		processname ,	projectname ,		severityid ) 
as 
select 	component_name,	correctiveaction ,	customer_name ,	errorcontext ,	errorid ,
		process_name ,	project_name ,		severityid 
from 	de_fw_des_context (nolock)




GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_base_context_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_base_context_vw TO PUBLIC
END
GO


