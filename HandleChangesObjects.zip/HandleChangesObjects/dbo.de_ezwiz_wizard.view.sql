IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_ezwiz_wizard' AND TYPE = 'V')
    Begin
        Drop View de_ezwiz_wizard
    End
Go


create view  [de_ezwiz_wizard]        
		as              
		select component_name,created_by,created_date,customer_name,ecrno,modified_by,modified_date,process_name,project_name,subscription_level,timestamp,wizard_code,wizard_desc,wizard_name,wizard_type from rvw20appdb.dbo.de_ezwiz_wizard a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_ezwiz_wizard' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_ezwiz_wizard TO PUBLIC
END
GO


