IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='avs_published_service_validation_message_vw' AND TYPE = 'V')
    Begin
        Drop View avs_published_service_validation_message_vw
    End
Go



/*
Modified By  	: Feroz
Modified Date 	: 13/08/2008 
Bug Id 			: PNR2.0_18936
*/
Create view [avs_published_service_validation_message_vw]
as 
select 	a.customer_name			'customer_name',
		a.project_name			'project_name',
		a.ecrno 				'ecrno',
		a.process_name			'process_name',
		a.component_name 		'component_name',
		a.service_name			'service_name',
		b.languageid			'languageid',
		a.segment_name 			'segmentname',
		a.dataitemname			'dataitemname',
		a.validation_code		'validation_code',
		b.message_code			'message_code',
		b.translated_message 	'message_doc',
		a.value1	 			'value1',
		a.value2				'value2',
		a.eval_sequence			'order_of_sequence'
from 	avs_published_service_validation_dtl	a (nolock),
		avs_published_msg_lng_extn				b (nolock)
where 	a.customer_name 	= b.customer_name
and 	a.project_name 		= b.project_name
and 	a.process_name 		= b.process_name
and 	a.component_name	= b.component_name
and 	a.ecrno				= b.ecrno
and 	a.service_name 		= b.service_name
and 	a.segment_name		= b.segment_name
and 	a.dataitemname 		= b.dataitemname 
and 	a.validation_code 	= b.validation_code
union
-- Added By Feroz For Bug id : PNR2.0_18936
select 	customer_name			'customer_name',
		project_name			'project_name',
		ecrno 					'ecrno',
		process_name			'process_name',
		component_name 			'component_name',
		service_name			'service_name',
		1						'languageid',
		segment_name 			'segmentname',
		dataitemname			'dataitemname',
		validation_code			'validation_code',
		''						'message_code',
		''					 	'message_doc',
		value1	 				'value1',
		value2					'value2',
		eval_sequence			'order_of_sequence'
from 	avs_published_service_validation_dtl	
where 	validation_code 	in (207, 208, 209)

GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'avs_published_service_validation_message_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  avs_published_service_validation_message_vw TO PUBLIC
END
GO


