IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_business_term_vw' AND TYPE = 'V')
    Begin
        Drop View de_business_term_vw
    End
Go


 
	/*	Creating View Script - de_business_term_vw on 	Jun 26 2005 11:46PM		*/	
/************************************************************************************
procedure name and id   de_business_term_vw
description             
name of the author      
date created            
query file name         de_business_term_vw.sql
modifications history   
modified by             
modified date           
modified purpose        
************************************************************************************/
create	view [de_business_term_vw]
as
select	customer_name 'customer_name',
		project_name 'project_name',
		component_name 'component_name',
		process_name 'process_name',
		bt_name 'bt_name',
		bt_descr 'bt_descr',
		data_type 'data_type',
		length 'length',
		precision_type 'precision_type'
from	de_business_term (nolock)

GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_business_term_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_business_term_vw TO PUBLIC
END
GO


