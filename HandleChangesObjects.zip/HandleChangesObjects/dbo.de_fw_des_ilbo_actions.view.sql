IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_ilbo_actions' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_ilbo_actions
    End
Go


create view  [de_fw_des_ilbo_actions]        
		as              
		select actionid,actionsequence,component_name,control_bt_synonym,controlid,createdby,createddate,customer_name,groupcode,ilbocode,modifiedby,modifieddate,page_bt_synonym,process_name,project_name,reqbrname,servicename,timestamp,updtime,upduser,viewname from rvw20appdb.dbo.de_fw_des_ilbo_actions a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_ilbo_actions' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_ilbo_actions TO PUBLIC
END
GO


