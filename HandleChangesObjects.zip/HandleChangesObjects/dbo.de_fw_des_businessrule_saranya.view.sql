IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_businessrule_saranya' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_businessrule_saranya
    End
Go


create view  [de_fw_des_businessrule_saranya]        
		as              
		select accessesdatabase,bocode,broname,btstring,btsynonymstring,component_name,createdby,createddate,customer_name,dispid,ecrno,isintegbr,methodid,methodname,modifiedby,modifieddate,operationtype,process_name,project_name,statusflag,systemgenerated,timestamp,updtime,upduser from rvw20appdb.dbo.de_fw_des_businessrule_saranya a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_businessrule_saranya' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_businessrule_saranya TO PUBLIC
END
GO


