IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_publish_service_dataitem_Applog_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_publish_service_dataitem_Applog_vw
    End
Go



/************************************************************************************    
procedure name and id   de_fw_des_publish_service_dataitem_Applog_vw
description             
name of the author      
date created            
query file name         de_fw_des_publish_service_dataitem_Applog_vw
modifications history   
modified by             
modified date           
modified purpose        
************************************************************************************/  
create view [de_fw_des_publish_service_dataitem_Applog_vw]
		(componentname,		customername,	dataitemname,	defaultvalue,	ecrno,
		flowattribute,		ispartofkey,	mandatoryflag,	processname,	projectname ,
		segmentname,		servicename ) 
as
select	'' componentname,	'' customername, 	'' dataitemname, 	'' defaultvalue, 	'' ecrno, 			'' flowattribute, 
		'' ispartofkey, 	'' mandatoryflag, 	'' processname, 	'' projectname, 	'' segmentname,		'' servicename
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_publish_service_dataitem_Applog_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_publish_service_dataitem_Applog_vw TO PUBLIC
END
GO


