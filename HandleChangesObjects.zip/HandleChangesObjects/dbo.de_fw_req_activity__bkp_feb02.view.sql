IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_activity__bkp_feb02' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_activity__bkp_feb02
    End
Go


create view  [de_fw_req_activity__bkp_feb02]        
		as              
		select activitydesc,activityid,activityname,activityposition,activitysequence,activitytype,component_name,componentname,createdby,createddate,customer_name,ecrno,iswfenabled,modifiedby,modifieddate,process_name,project_name,timestamp,updtime,upduser from rvw20appdb.dbo.de_fw_req_activity__bkp_feb02 a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_activity__bkp_feb02' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_activity__bkp_feb02 TO PUBLIC
END
GO


