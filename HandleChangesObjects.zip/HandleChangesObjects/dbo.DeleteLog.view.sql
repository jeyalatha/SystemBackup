IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='DeleteLog' AND TYPE = 'V')
    Begin
        Drop View DeleteLog
    End
Go


create view  [DeleteLog]        
		as              
		select DeletedBy,DeletedEntry,DeletedOn,DeleteType from rvw20appdb.dbo.DeleteLog a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'DeleteLog' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  DeleteLog TO PUBLIC
END
GO


