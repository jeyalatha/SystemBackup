IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_affected_ius_temp' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_affected_ius_temp
    End
Go


create view  [de_fw_des_affected_ius_temp]              
			(componentdesc,componentname,createdby,createddate,iucode,iudesc,iutype,modifiedby,modifieddate,timestamp,tranid)        
			as              
			select componentdesc,componentname,createdby,createddate,iucode,iudesc,iutype,modifiedby,modifieddate,timestamp,tranid from rvw20appdb.dbo.de_fw_des_affected_ius_temp (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_affected_ius_temp' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_affected_ius_temp TO PUBLIC
END
GO


