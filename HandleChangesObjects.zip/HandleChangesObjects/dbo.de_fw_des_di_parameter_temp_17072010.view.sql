IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_di_parameter_temp_17072010' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_di_parameter_temp_17072010
    End
Go


create view  [de_fw_des_di_parameter_temp_17072010]        
		as              
		select component_name,createdby,createddate,customer_name,dataitemname,dna_parametername,ecrno,method_name,methodid,modifiedby,modifieddate,parametername,process_name,project_name,sectionname,segmentname,sequenceno,servicename,timestamp,updtime,upduser from rvw20appdb.dbo.de_fw_des_di_parameter_temp_17072010 a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_di_parameter_temp_17072010' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_di_parameter_temp_17072010 TO PUBLIC
END
GO


