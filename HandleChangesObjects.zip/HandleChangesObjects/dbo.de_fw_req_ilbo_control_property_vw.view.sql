IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_ilbo_control_property_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_ilbo_control_property_vw
    End
Go



/************************************************************************************    
procedure name and id    de_fw_req_ilbo_control_property_vw
description              The View is used For MDCF
name of the author          
date created                
query file name          de_fw_req_ilbo_control_property_vw
modifications history       
modified by               Balaji S For BugId : PNR2.0_3825  
modified date             13-Sep-2005  
modified purpose          Fine tuned the View
modified by               Saravana Kumar P
modified date             02-Jan-2006  
modified purpose          PNR2.0_5234
modified by               Sangeetha L
modified date             13-Apr-2006  
modified purpose          PNR2.0_7958
modified by               Sangeetha G
modified date             03-Apr-2009  
BugID		          PNR2.0_21812 
modified purpose          PLText not fetched  for certain components in MDCF tool
************************************************************************************/  

CREATE view [de_fw_req_ilbo_control_property_vw]
as
	select	Distinct 
		a.customername		'customer_name',
		a.projectname		'project_name',
		a.processname		'Process_name',
		a.componentname		'Component_name',
		a.controlid		'controlid',
		a.ilbocode		'ilbocode',
		a.propertyname		'propertyname',
		a.viewname		'viewname',
		a.type			'type',
		a.value			'value'
	from	de_fw_req_publish_ilbo_control_property	a(nolock),
		De_Customer_Space			b(nolock),
		de_fw_req_publish_ilbo_control		c(nolock),
		de_fw_req_publish_ilbo   e (nolock) 
-- 	where	a.customername	= b.customer_name
-- 	and	a.projectname	= b.project_name
-- 	and	a.processname	= b.process_name
-- 	and	a.componentname = b.component_name
-- 	and	a.customername	= c.customername
-- 	and	a.projectname	= c.projectname
-- 	and	a.processname	= c.processname
-- 	and	a.componentname = c.componentname
-- 	and	a.ecrno		= c.ecrno
-- 	and	a.ecrno		= b.ico_no
-- 	and	a.controlid	= c.controlid
-- 	and	a.ilbocode	= c.ilbocode
-- 	and	a.ilbocode	= b.ui_name
--code modified for bug id:PNR2.0_5234
where b.customername  = e.customername  
and b.projectname  = e.projectname  
and b.processname  = e.processname  
and b.componentname = e.componentname  
and b.ecrno  = e.ecrno  
  
and e.customername = c.customername  
and e.projectname = c.projectname  
and e.processname = c.processname  
and e.componentname = c.componentname  
and e.ecrno  = c.ecrno  
and e.ilbocode = c.ilbocode  
  
and     c.customername = a.customername  
and c.projectname = a.projectname  
and c.processname = a.processname  
and c.componentname = a.componentname  
and c.ecrno  = a.ecrno  
and c.ecrno  = a.ecrno  
and c.ilbocode = a.ilbocode  
and c.controlid = a.controlid  
--code modified for bug id:PNR2.0_5234
--and	b.modifieddate	= 	(select	max(d.modifieddate)
--and		b.ico_no in (select ico_no
--					from	de_ui_ico d(nolock)
--					where	a.customername	= d.customer_name
--					and	a.projectname	= d.project_name
--					and	a.processname	= d.process_name
--					and	a.componentname = d.component_name
----					and	a.ilbocode	= d.ui_name  /*PNR2.0_7958*/
--					and	d.ico_status	= 'P'
--					-- Modification for PNR2.0_21812 starts
--					and     isnull(d.short_close,'')	<> 'Yes' )
--					-- Modification for PNR2.0_21812 ends
--	and 	ico_status	= 'P'

GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_ilbo_control_property_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_ilbo_control_property_vw TO PUBLIC
END
GO


