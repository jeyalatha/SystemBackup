IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_publish_task_state_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_publish_task_state_vw
    End
Go


/************************************************************************************
procedure name and id   de_fw_des_publish_task_state_vw
description
name of the author
date created
query file name         de_fw_des_publish_task_state_vw
modifications history
modified by             Gankan G
modified date           23-APR-2012
modified purpose        PLF2.0_00064
***********************************************************************************/

Create view [de_fw_des_publish_task_state_vw]
as

select  distinct
a.customer_name   'customername',
a.project_name   'projectname',
a.process_name   'processname',
a.component_name  'componentname',
a.ecrno     'ecrno',
a.activity_name   'activityname',
a.ui_name    'uiname',
b.task_name    'taskname',
d.task_type    'tasktype',
c.service_name   'servicename'
from  de_published_ui_state  a (nolock),
de_published_ui_state_task b (nolock),
de_published_task_service_map  c (nolock),
de_published_action  d (nolock),
de_published_ui   e (nolock)
where  a.customer_name   = b.customer_name
and  a.project_name    = b.project_name
and  a.ecrno     = b.ecrno
and  a.process_name    = b.process_name
and  a.component_name  = b.component_name
and  a.activity_name   = b.activity_name
and  a.ui_name     = b.ui_name
and  isnull(b.state_id, '')  <> ''
and  c.customer_name   = b.customer_name
and  c.project_name    = b.project_name
and  c.ecrno     = b.ecrno
and  c.process_name    = b.process_name
and  c.component_name  = b.component_name
and  c.activity_name   = b.activity_name
and  c.ui_name     = b.ui_name
and  c.task_name    = b.task_name
and  c.customer_name   = d.customer_name
and  c.project_name    = d.project_name
and  c.ecrno     = d.ecrno
and  c.process_name    = d.process_name
and  c.component_name  = d.component_name
and  c.activity_name   = d.activity_name
and  c.ui_name     = d.ui_name
and  c.task_name    = d.task_name
and  c.customer_name   = e.customer_name
and  c.project_name    = e.project_name
and  c.ecrno     = e.ecrno
and  c.process_name    = e.process_name
and  c.component_name  = e.component_name
and  c.activity_name   = e.activity_name
and  c.ui_name     = e.ui_name
and isnull(e.state_processing,'No') = 'YES'
union
select  distinct
a.customer_name   'customername',
a.project_name   'projectname',
a.process_name   'processname',
a.component_name  'componentname',
a.ecrno    'ecrno',
a.activity_name   'activityname',
a.ui_name   'uiname',
b.task_name   'taskname',
d.task_type   'tasktype',
c.service_name   'servicename'
from  de_published_ui_state  a (nolock),
de_published_ui_state_task_mst b (nolock),
de_published_task_service_map  c (nolock),
de_published_action  d (nolock),
de_published_ui   e (nolock)
where  a.customer_name   = b.customer_name
and  a.project_name    = b.project_name
and  a.ecrno     = b.ecrno
and  a.process_name    = b.process_name
and  a.component_name  = b.component_name
and  a.activity_name   = b.activity_name
and  a.ui_name     = b.ui_name
and  c.customer_name   = b.customer_name
and  c.project_name    = b.project_name
and  c.ecrno     = b.ecrno
and  c.process_name    = b.process_name
and  c.component_name  = b.component_name
and  c.activity_name   = b.activity_name
and  c.ui_name     = b.ui_name
and  c.task_name    = b.task_name
and  c.customer_name   = d.customer_name
and  c.project_name    = d.project_name
and  c.ecrno     = d.ecrno
and  c.process_name    = d.process_name
and  c.component_name  = d.component_name
and  c.activity_name   = d.activity_name
and  c.ui_name     = d.ui_name
and  c.task_name    = d.task_name
and  c.customer_name   = e.customer_name
and  c.project_name    = e.project_name
and  c.ecrno     = e.ecrno
and  c.process_name    = e.process_name
and  c.component_name  = e.component_name
and  c.activity_name   = e.activity_name
and  c.ui_name     = e.ui_name
and  isnull(e.state_processing,'No') = 'YES'
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_publish_task_state_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_publish_task_state_vw TO PUBLIC
END
GO


