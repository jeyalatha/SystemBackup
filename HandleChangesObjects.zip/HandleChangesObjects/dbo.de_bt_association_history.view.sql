IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_bt_association_history' AND TYPE = 'V')
    Begin
        Drop View de_bt_association_history
    End
Go


create view  [de_bt_association_history]        
		as              
		select bt_synonym_name,component_name,createdby,createddate,customer_name,ecrno,History_version,modifiedby,modifieddate,new_bt_name,old_bt_name,process_name,project_name,timestamp from rvw20appdb.dbo.de_bt_association_history a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_bt_association_history' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_bt_association_history TO PUBLIC
END
GO


