IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_base_REQBR_DESBR_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_base_REQBR_DESBR_vw
    End
Go



/************************************************************************************    
procedure name and id   de_fw_des_base_REQBR_DESBR_vw
description             
name of the author      BharathiDasan.V.V
date created            16-07-2007                
query file name         de_fw_des_base_REQBR_DESBR_vw
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/  
CREATE VIEW [de_fw_des_base_REQBR_DESBR_vw]
AS	
SELECT	MethodName 		'ReqBRName',
		MethodID 		'MethodID',
		UpdUser 		'UpdUser',
		UpdTime 		'UpdTime',
		customer_name,
		project_name,
		process_name,
		component_name
FROM	de_fw_des_BusinessRule (nolock)






GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_base_REQBR_DESBR_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_base_REQBR_DESBR_vw TO PUBLIC
END
GO


