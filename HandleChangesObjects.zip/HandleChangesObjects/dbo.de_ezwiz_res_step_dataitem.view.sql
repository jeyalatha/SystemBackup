IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_ezwiz_res_step_dataitem' AND TYPE = 'V')
    Begin
        Drop View de_ezwiz_res_step_dataitem
    End
Go


create view  [de_ezwiz_res_step_dataitem]        
		as              
		select child_bt_synonym,child_controlid,child_step_desc,child_step_seqno,child_viewname,component_name,created_by,created_date,customer_name,ecrno,modified_by,modified_date,parent_bt_synonym,parent_controlid,parent_step_desc,parent_step_seqno,parent_viewname,process_name,project_name,timestamp,wizard_name from rvw20appdb.dbo.de_ezwiz_res_step_dataitem a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_ezwiz_res_step_dataitem' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_ezwiz_res_step_dataitem TO PUBLIC
END
GO


