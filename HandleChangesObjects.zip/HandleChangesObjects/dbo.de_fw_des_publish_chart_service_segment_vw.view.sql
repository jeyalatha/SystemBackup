IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_publish_chart_service_segment_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_publish_chart_service_segment_vw
    End
Go



/*	Creating View Script - de_fw_des_publish_chart_service_segment_vw on 	Jan 17 2005 11:46PM		*/	
/************************************************************************************
procedure name and id   de_fw_des_publish_chart_service_segment_vw   
description             
name of the author      
date created            25-Jan-2006
query file name         de_fw_des_publish_chart_service_segment_vw.sql
modifications history   
modified by             
modified date           
modified purpose        
***********************************************************************************/
Create view [de_fw_des_publish_chart_service_segment_vw]
	(customer_name, project_name, process_name, component_name, ecrno,
	 chart_id, chart_section, servicename, segmentname, instanceflag, 
	 timestamp, createdby, createddate, modifiedby, modifieddate)
as
select	
	customer_name, project_name, process_name, component_name, ecrno,
	chart_id, chart_section, servicename, segmentname, instanceflag, 
	timestamp, createdby, createddate, modifiedby, modifieddate
from	de_fw_des_publish_chart_service_segment (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_publish_chart_service_segment_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_publish_chart_service_segment_vw TO PUBLIC
END
GO


