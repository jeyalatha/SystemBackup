IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_ilbo_ctrl_event' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_ilbo_ctrl_event
    End
Go


create view  [de_fw_des_ilbo_ctrl_event]              
					as              
					select componentname 'component_name' ,control_bt_synonym,controlid,createdby,createddate,createstubflag,customername 'customer_name' ,ecrno,eventname,ilbocode,methodname,modifiedby,modifieddate,page_bt_synonym,processname 'process_name' ,projectname 'project_name' ,taskname,timestamp,updtime,upduser,viewname from rvw_publish_db.dbo.de_fw_des_publish_ilbo_ctrl_event a (nolock)        
					where exists (select 'x' from De_Customer_Space b (nolock)        
					where     a.customername   = b.customername        
					and       a.projectname    = b.projectname        
					and       a.processname    = b.processname        
					and       a.componentname  = b.componentname    
					and       a.ecrno        = b.ecrno )
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_ilbo_ctrl_event' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_ilbo_ctrl_event TO PUBLIC
END
GO


