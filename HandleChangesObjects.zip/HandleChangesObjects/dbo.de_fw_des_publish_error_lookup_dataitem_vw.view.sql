IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_publish_error_lookup_dataitem_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_publish_error_lookup_dataitem_vw
    End
Go


/* Creating View Script - de_fw_des_publish_error_lookup_dataitem_vw  on  Jun 26 2005 11:46PM for PNR2.0_29495*/
/************************************************************************************
procedure name and id   de_fw_des_publish_error_lookup_dataitem_vw
description
name of the author
date created
query file name         de_fw_des_publish_error_lookup_dataitem_vw.sql
modifications history
modified by
modified date
modified purpose
************************************************************************************/
Create view [de_fw_des_publish_error_lookup_dataitem_vw]
( customer_name,project_name,process_name,component_name,ecrno,activity_name,ui_name,
taskname,service_name,errorid,pub_name,published_comp_name,published_act_name,published_ui_name ,
pub_page,pub_dataitemname,pub_control_bt_synonym,pub_controlid,pub_viewname,pub_flowtype,sub_page,
sub_control_bt_synonym,sub_controlid,sub_viewname,sub_flowtype,retrievemultiple)
as
select customer_name,project_name,process_name,component_name,ecrno,activity_name,ui_name,
taskname,service_name,errorid,pub_name,published_comp_name,published_act_name,published_ui_name ,
pub_page,pub_dataitemname ,pub_control_bt_synonym,pub_controlid,pub_viewname,pub_flowtype,sub_page,
sub_control_bt_synonym,sub_controlid,sub_viewname,sub_flowtype,0
from de_fw_des_publish_error_lookup_dataitem (nolock)




GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_publish_error_lookup_dataitem_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_publish_error_lookup_dataitem_vw TO PUBLIC
END
GO


