IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_base_di_parameter_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_base_di_parameter_vw
    End
Go



/************************************************************************************    
procedure name and id   de_fw_des_base_di_parameter_vw
description             
name of the author      BharathiDasan.V.V
date created            16-07-2007                
query file name         de_fw_des_base_di_parameter_vw
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/  
create view [de_fw_des_base_di_parameter_vw] 
	  (	componentname ,	customername ,	dataitemname ,	methodid ,
		parametername ,	processname ,	projectname ,	sectionname ,
		segmentname ,	sequenceno ,	servicename ) 
as 
select 	component_name,	customer_name ,	dataitemname ,	methodid ,
		parametername ,	process_name ,	project_name ,	sectionname ,
		segmentname ,	sequenceno ,	servicename 
from 	de_fw_des_di_parameter (nolock)





GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_base_di_parameter_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_base_di_parameter_vw TO PUBLIC
END
GO


