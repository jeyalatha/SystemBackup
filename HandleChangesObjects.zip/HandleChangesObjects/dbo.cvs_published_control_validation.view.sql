IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='cvs_published_control_validation' AND TYPE = 'V')
    Begin
        Drop View cvs_published_control_validation
    End
Go


create view  [cvs_published_control_validation]              
			(activity_name,component_name,control_name,createdby,createddate,customer_name,ecrno,eval_sequence,modifiedby,modifieddate,page_name,process_name,project_name,ref_val_group,task_name,timestamp,ui_name,validation_code,value1,value2)          
			as              
			select activity_name,component_name,control_name,createdby,createddate,customer_name,ecrno,eval_sequence,modifiedby,modifieddate,page_name,process_name,project_name,ref_val_group,task_name,timestamp,ui_name,validation_code,value1,value2 from rvw_publish_db.dbo.cvs_published_control_validation a (nolock)        
			where exists (select 'x' from De_Customer_Space b (nolock)        
			where     a.customer_name   = b.customername        
			and       a.project_name    = b.projectname        
			and       a.process_name    = b.processname        
			and       a.component_name  = b.componentname    
			and       a.ecrno           = b.ecrno )
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'cvs_published_control_validation' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  cvs_published_control_validation TO PUBLIC
END
GO


