IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_attribute_quick_code_met' AND TYPE = 'V')
    Begin
        Drop View de_attribute_quick_code_met
    End
Go


create view  [de_attribute_quick_code_met]              
			(applicablefor,btname,quick_code,quick_code_value,suffix)        
			as              
			select applicablefor,btname,quick_code,quick_code_value,suffix from rvw20appdb.dbo.de_attribute_quick_code_met (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_attribute_quick_code_met' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_attribute_quick_code_met TO PUBLIC
END
GO


