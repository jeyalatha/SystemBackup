IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_base_ilbo_linkuse_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_base_ilbo_linkuse_vw
    End
Go


/************************************************************************************
procedure name and id   de_fw_req_base_ilbo_linkuse_vw
description
name of the author
date created
query file name         de_fw_req_base_ilbo_linkuse_vw
modifications history
modified by     Sangeetha G
modified date       10-Mar-2011
modified for    PNR2.0_30511
modified purpose            To include post linktask  in linkuse.
************************************************************************************/
create view [de_fw_req_base_ilbo_linkuse_vw]
( childilbocode , childorder , componentname , customername , linkid , parentilbocode ,
processname , projectname , taskname,   post_task ,post_linktask )  -- modified for  PNR2.0_30511
as
select  childilbocode , childorder , component_name, customer_name , linkid , parentilbocode ,
process_name , project_name , taskname,   post_task ,post_linktask -- modified for  PNR2.0_30511
from  de_fw_req_ilbo_linkuse (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_base_ilbo_linkuse_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_base_ilbo_linkuse_vw TO PUBLIC
END
GO


