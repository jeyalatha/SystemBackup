IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_publish_error_lookup_dataitem' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_publish_error_lookup_dataitem
    End
Go


create view  [de_fw_des_publish_error_lookup_dataitem]              
					(activity_name,component_name,createdby,createddate,customer_name,ecrno,errorid,linkid,modifiedby,modifieddate,process_name,project_name,pub_control_bt_synonym,pub_controlid,pub_dataitemname,pub_flowtype,pub_name,pub_page,pub_viewname,published_act_name,published_comp_name,published_ui_name,retrievemultiple,service_name,sub_control_bt_synonym,sub_controlid,sub_flowtype,sub_page,sub_viewname,taskname,ui_name)          
					as              
					select activity_name,component_name,createdby,createddate,customer_name,ecrno,errorid,linkid,modifiedby,modifieddate,process_name,project_name,pub_control_bt_synonym,pub_controlid,pub_dataitemname,pub_flowtype,pub_name,pub_page,pub_viewname,published_act_name,published_comp_name,published_ui_name,retrievemultiple,service_name,sub_control_bt_synonym,sub_controlid,sub_flowtype,sub_page,sub_viewname,taskname,ui_name from rvw_publish_db.dbo.de_fw_des_publish_error_lookup_dataitem a (nolock)        
					where exists (select 'x' from De_Customer_Space b (nolock)        
					where     a.customer_name   = b.customername        
					and       a.project_name    = b.projectname        
					and       a.process_name    = b.processname        
					and       a.component_name  = b.componentname    
					and       a.ecrno        = b.ecrno )
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_publish_error_lookup_dataitem' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_publish_error_lookup_dataitem TO PUBLIC
END
GO


