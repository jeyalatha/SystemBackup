IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_base_task_rule_Vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_base_task_rule_Vw
    End
Go




 
	/*	Creating View Script - de_fw_req_publish_task_rule_Vw on 	Jun 26 2005 11:46PM		*/	

/************************************************************************************    
procedure name and id   de_fw_req_publish_task_rule_Vw
description             The View used for Launch Pad
name of the author          
date created                
query file name         de_fw_req_publish_task_rule_Vw
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/ 
CREATE VIEW [de_fw_req_base_task_rule_Vw]
AS 
SELECT	MethodName 'TaskName',
		1 'BRSequence',
		MethodName 'BRName',
		1 'InvocationType',
		UpdUser 'UpdUser',
		UpdTime 'UpdTime',
		customer_name,
		project_name,
		process_name,
		component_name

FROM	de_fw_des_BusinessRule (nolock)
WHERE	1=2




GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_base_task_rule_Vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_base_task_rule_Vw TO PUBLIC
END
GO


