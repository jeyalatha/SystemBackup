IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_base_bterm_synonym_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_base_bterm_synonym_vw
    End
Go




 
	/*	Creating View Script - de_fw_req_publish_bterm_synonym_vw on 	Jun 26 2005 11:46PM		*/	

/************************************************************************************    
procedure name and id   de_fw_req_publish_bterm_synonym_vw
description             The View used for Launch Pad
name of the author          
date created                
query file name         de_fw_req_publish_bterm_synonym_vw
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/  
Create view [de_fw_req_base_bterm_synonym_vw] 
	(btname ,btsynonym ,componentname ,customername ,processname ,projectname ) 
as 
select 	btname ,btsynonym ,component_name ,customer_name ,process_name ,project_name 
from 	de_fw_req_bterm_synonym (nolock)
union
select	'modeflag', 'modeflag',componentname ,customer_name ,parentprocess ,project_name 
from 	de_fw_req_process_component (nolock)


GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_base_bterm_synonym_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_base_bterm_synonym_vw TO PUBLIC
END
GO


