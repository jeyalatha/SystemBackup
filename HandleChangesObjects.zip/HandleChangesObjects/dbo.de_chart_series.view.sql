IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_chart_series' AND TYPE = 'V')
    Begin
        Drop View de_chart_series
    End
Go


create view  [de_chart_series]              
					(activity_name,auto_scale,axis_id,cal_err_value,chart_type,component_name,con_color,con_style,con_type,con_weight,con_wt_val,createdby,createddate,customer_name,display_option,divisions_max,divisions_min,ecrno,err_mark_size_val,error_band_type,error_bands,error_marker_size,error_marker_type,mark_color,marker_size,marker_size_val,marker_type,modifiedby,modifieddate,page_bt_synonym,process_name,project_name,req_no,section_bt_synonym,sequence,series_id,series_name,ui_name,units,x_showname,x_showvalue,Y_Legend_Caption,y_secondary_axis)          
					as              
					select activity_name,auto_scale,axis_id,cal_err_value,chart_type,component_name,con_color,con_style,con_type,con_weight,con_wt_val,createdby,createddate,customer_name,display_option,divisions_max,divisions_min,ecrno,err_mark_size_val,error_band_type,error_bands,error_marker_size,error_marker_type,mark_color,marker_size,marker_size_val,marker_type,modifiedby,modifieddate,page_bt_synonym,process_name,project_name,req_no,section_bt_synonym,sequence,series_id,series_name,ui_name,units,x_showname,x_showvalue,Y_Legend_Caption,y_secondary_axis from rvw_publish_db.dbo.de_published_chart_series a (nolock)        
					where exists (select 'x' from De_Customer_Space b (nolock)        
					where     a.customer_name   = b.customername        
					and       a.project_name    = b.projectname        
					and       a.process_name    = b.processname        
					and       a.component_name  = b.componentname    
					and       a.ecrno        = b.ecrno )
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_chart_series' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_chart_series TO PUBLIC
END
GO


