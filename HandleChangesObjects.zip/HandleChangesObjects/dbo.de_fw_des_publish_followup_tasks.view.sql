IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_publish_followup_tasks' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_publish_followup_tasks
    End
Go


create view  [de_fw_des_publish_followup_tasks]              
					(activity_name,component_name,createdby,createddate,customer_name,ecrno,followup_taskname,modifiedby,modifieddate,process_name,project_name,service_name,success_errorid,task_name,ui_name)          
					as              
					select activity_name,component_name,createdby,createddate,customer_name,ecrno,followup_taskname,modifiedby,modifieddate,process_name,project_name,service_name,success_errorid,task_name,ui_name from rvw_publish_db.dbo.de_fw_des_publish_followup_tasks a (nolock)        
					where exists (select 'x' from De_Customer_Space b (nolock)        
					where     a.customer_name   = b.customername        
					and       a.project_name    = b.projectname        
					and       a.process_name    = b.processname        
					and       a.component_name  = b.componentname    
					and       a.ecrno        = b.ecrno )
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_publish_followup_tasks' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_publish_followup_tasks TO PUBLIC
END
GO


