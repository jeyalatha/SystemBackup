IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_base_page_section_state_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_base_page_section_state_vw
    End
Go



/************************************************************************************
procedure name and id   de_fw_des_publish_page_section_state_vw
description             
name of the author      
date created            
query file name         de_fw_des_publish_page_section_state_vw
modifications history   
modified by             Balaji S
modified date           30/Jul/2007
modified purpose        PNR2.0_14723
***********************************************************************************/
Create view [de_fw_des_base_page_section_state_vw]
as
select 	distinct 
	a.customer_name		'customername',
	a.project_name		'projectname',
	a.process_name		'processname',
	a.component_name	'componentname',
	--a.ecrno			'ecrno',
	a.activity_name		'activityname',
	a.ui_name		'uiname',
	a.page_bt_synonym	'pagename',
	a.section_bt_synonym	'sectionname'
from 	de_ui_state_section 	a(nolock),
	de_ui			b(nolock)
where	a.customer_name		= b.customer_name
and	a.project_name		= b.project_name
--and	a.ecrno			= b.ecrno
and	a.process_name		= b.process_name
and	a.component_name	= b.component_name
and	a.activity_name		= b.activity_name
and	a.ui_name		= b.ui_name
and	isnull(b.state_processing,'no') = 'Yes'	
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_base_page_section_state_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_base_page_section_state_vw TO PUBLIC
END
GO


