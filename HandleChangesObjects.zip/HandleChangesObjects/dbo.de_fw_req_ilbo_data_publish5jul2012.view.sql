IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_ilbo_data_publish5jul2012' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_ilbo_data_publish5jul2012
    End
Go


create view  [de_fw_req_ilbo_data_publish5jul2012]        
		as              
		select component_name,controlid,controlvariablename,createdby,createddate,customer_name,dataitemname,ecrno,flowtype,havemultiple,ilbocode,iscontrol,link_name,linkid,mandatoryflag,modifiedby,modifieddate,process_name,project_name,timestamp,updtime,upduser,viewname from rvw20appdb.dbo.de_fw_req_ilbo_data_publish5jul2012 a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_ilbo_data_publish5jul2012' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_ilbo_data_publish5jul2012 TO PUBLIC
END
GO


