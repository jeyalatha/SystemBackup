IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='dec11' AND TYPE = 'V')
    Begin
        Drop View dec11
    End
Go


create view  [dec11]        
		as              
		select ActionDescr,ActivityDescription,ActivityName,FlowBRDesc,FlowBRName,RuleName,Seqno,taskName,UIDesc,UIName from rvw20appdb.dbo.dec11 a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'dec11' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  dec11 TO PUBLIC
END
GO


