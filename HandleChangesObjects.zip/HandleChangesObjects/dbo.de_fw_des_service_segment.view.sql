IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_service_segment' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_service_segment
    End
Go


CREATE view  [de_fw_des_service_segment]                
     as                
     select bocode,bosegmentname,componentname 'component_name' ,createdby,createddate,customername 'customer_name' ,ecrno,instanceflag,mandatoryflag,modifiedby,modifieddate,parentsegmentname,process_selrows,process_updrows,processname 'process_name' ,projectname 'project_name' ,segmentname,servicename,timestamp,updtime,upduser,PersistScrollPosition,AtomicRefresh,ProcessingType from rvw_publish_db.dbo.de_fw_des_publish_service_segment a (nolock)               where exists (select 'x' from De_Customer_Space b (nolock)          
     where     a.customername   = b.customername          
     and       a.projectname    = b.projectname          
     and       a.processname    = b.processname          
     and       a.componentname  = b.componentname      
     and       a.ecrno        = b.ecrno )  
  
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_service_segment' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_service_segment TO PUBLIC
END
GO


