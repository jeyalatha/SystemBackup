IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_base_integ_serv_map_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_base_integ_serv_map_vw
    End
Go



/************************************************************************************    
procedure name and id   de_fw_des_base_integ_serv_map_vw
description                 
name of the author      BharathiDasan.V.V
date created            16-07-2007                
query file name         de_fw_des_base_integ_serv_map_vw
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/  
create view [de_fw_des_base_integ_serv_map_vw] 
	 ( 	callingdataitem ,	callingsegment ,	callingservicename ,	componentname ,	
		customername ,		integdataitem ,		integsegment ,			integservicename ,
		processname ,		projectname ,		sectionname ,			sequenceno ) 
as 
select 	callingdataitem ,	callingsegment ,	callingservicename ,	component_name ,
		customer_name ,		integdataitem ,		integsegment ,			integservicename ,
		process_name ,		project_name ,		sectionname ,			sequenceno 
from 	de_fw_des_integ_serv_map (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_base_integ_serv_map_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_base_integ_serv_map_vw TO PUBLIC
END
GO


