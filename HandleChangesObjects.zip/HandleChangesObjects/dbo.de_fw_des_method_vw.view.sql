IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_method_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_method_vw
    End
Go



/************************************************************************************
procedure name and id   :de_fw_des_method_vw
description
name of the author      : Chanheetha N.A
date created
query file name          :de_fw_des_method_vw.sql
modifications history    : for Development Packaging
modified by
modified date
modified purpose
************************************************************************************/
Create view [de_fw_des_method_vw]
(  customer_name ,  project_name ,   process_name ,   component_name,
activity_name ,  ui_name,    task_name,    service_name,
method_name,   methodid,    ecrno)
as
select  distinct
map.customer_name , map.project_name ,  map.process_name ,  map.component_name,
map.activity_name , map.ui_name,   map.task_name,   map.service_name,
mt.methodname,   pr.methodid,  map.ecrno
from  de_published_task_service_map    map(nolock),
de_fw_des_publish_processsection_br_is  pr (nolock),
de_fw_des_publish_businessrule   mt (nolock)
where  map.customer_name  = pr.customername
and    map.project_name  = pr.projectname
and    map.process_name  = pr.processname
and  map.component_name   = pr.componentname
and  map.ecrno    = pr.ecrno
and    map.service_name   = pr.servicename

and    pr.customername   = mt.customername
and    pr.projectname   = mt.projectname
and    pr.processname   = mt.processname
and    pr.componentname   = mt.componentname
and  pr.ecrno    = mt.ecrno
and    pr.methodid    = mt.methodid




GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_method_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_method_vw TO PUBLIC
END
GO


