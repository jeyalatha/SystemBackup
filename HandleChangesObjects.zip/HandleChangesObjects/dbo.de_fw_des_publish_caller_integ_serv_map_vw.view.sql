IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_publish_caller_integ_serv_map_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_publish_caller_integ_serv_map_vw
    End
Go



/************************************************************************************    
procedure name and id   de_fw_des_publish_caller_integ_serv_map_vw
description                 
name of the author          
date created                
query file name         de_fw_des_publish_caller_integ_serv_map_vw
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/  
CREATE view [de_fw_des_publish_caller_integ_serv_map_vw] 
		(componentname,	callingservicename,	callingsegment,	callingdataitem, integservicename, 
		integsegment,	integdataitem)
as 

select	distinct
		a.componentname,	b.callingservicename,		b.callingsegment,		b.callingdataitem,		b.integservicename, 
		b.integsegment,		b.integdataitem
from	de_fw_des_service			a(nolock),
		de_fw_des_integ_serv_map	b(nolock)
where	a.isintegser	= 1
and		b.integservicename	= a.servicename
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_publish_caller_integ_serv_map_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_publish_caller_integ_serv_map_vw TO PUBLIC
END
GO


