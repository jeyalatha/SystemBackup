IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_action_section_map' AND TYPE = 'V')
    Begin
        Drop View de_action_section_map
    End
Go


create view  [de_action_section_map]              
					(activity_name,component_name,createdby,createddate,customer_name,ecrno,modifiedby,modifieddate,page_bt_synonym,process_name,project_name,req_no,section_bt_synonym,section_page_bt_synonym,task_name,task_section_sysid,task_sysid,timestamp,ui_name)          
					as              
					select activity_name,component_name,createdby,createddate,customer_name,ecrno,modifiedby,modifieddate,page_bt_synonym,process_name,project_name,req_no,section_bt_synonym,section_page_bt_synonym,task_name,task_section_sysid,task_sysid,timestamp,ui_name from rvw_publish_db.dbo.de_published_action_section_map a (nolock)        
					where exists (select 'x' from De_Customer_Space b (nolock)        
					where     a.customer_name   = b.customername        
					and       a.project_name    = b.projectname        
					and       a.process_name    = b.processname        
					and       a.component_name  = b.componentname    
					and       a.ecrno        = b.ecrno )
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_action_section_map' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_action_section_map TO PUBLIC
END
GO


