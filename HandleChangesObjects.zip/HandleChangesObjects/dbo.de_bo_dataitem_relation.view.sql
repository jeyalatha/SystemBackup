IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_bo_dataitem_relation' AND TYPE = 'V')
    Begin
        Drop View de_bo_dataitem_relation
    End
Go


create view  [de_bo_dataitem_relation]              
			(bo_dataitem_name,bo_name,bo_segment_name,bosegrel_sysid,component_name,createdby,createddate,customer_name,modifiedby,modifieddate,process_name,project_name,related_dataitem_name,relationship_name,reldata_sysid,timestamp)        
			as              
			select bo_dataitem_name,bo_name,bo_segment_name,bosegrel_sysid,component_name,createdby,createddate,customer_name,modifiedby,modifieddate,process_name,project_name,related_dataitem_name,relationship_name,reldata_sysid,timestamp from rvw20appdb.dbo.de_bo_dataitem_relation (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_bo_dataitem_relation' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_bo_dataitem_relation TO PUBLIC
END
GO


