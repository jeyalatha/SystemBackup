IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_ext_js_section_column' AND TYPE = 'V')
    Begin
        Drop View de_ext_js_section_column
    End
Go


create view  [de_ext_js_section_column]        
		as              
		select activity_name,callout_task,column_bt_synonym,column_sequence,column_type,component_name,control_bt_synonym,control_class,createdby,createddate,customer_name,datatype,Default_Dragoption,ecr_no,FieldList,grouping,grouping_function,grouping_synonym,is_key,label_class,modifiedby,modifieddate,page_bt_synonym,pivot_sequence,process_name,project_name,rvw_task,sample_data,section_bt_synonym,section_type,ui_name from rvw20appdb.dbo.de_ext_js_section_column a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_ext_js_section_column' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_ext_js_section_column TO PUBLIC
END
GO


