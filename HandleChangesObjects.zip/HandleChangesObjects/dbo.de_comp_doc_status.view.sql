IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_comp_doc_status' AND TYPE = 'V')
    Begin
        Drop View de_comp_doc_status
    End
Go


create view  [de_comp_doc_status]        
		as              
		select component_name,createdby,createddate,customer_name,latest_dwn_ecr_no,latest_pub_ecr_no,modifiedby,modifieddate,process_name,project_name from rvw20appdb.dbo.de_comp_doc_status a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_comp_doc_status' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_comp_doc_status TO PUBLIC
END
GO


