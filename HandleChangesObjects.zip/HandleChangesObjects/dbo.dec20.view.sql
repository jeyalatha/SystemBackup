IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='dec20' AND TYPE = 'V')
    Begin
        Drop View dec20
    End
Go


create view  [dec20]        
		as              
		select controlname,newpagename,newsectionname,pagename,sectionname,uiname from rvw20appdb.dbo.dec20 a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'dec20' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  dec20 TO PUBLIC
END
GO


