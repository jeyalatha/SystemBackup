IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_base_processsection_br_is_err_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_base_processsection_br_is_err_vw
    End
Go



/************************************************************************************    
procedure name and id   de_fw_des_base_processsection_br_is_err_vw 
description             
name of the author      BharathiDasan.V.V
date created            13-07-2007   
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/  
create view [de_fw_des_base_processsection_br_is_err_vw] 
	  (	componentname ,	connectivityflag ,		controlexpression ,	customername ,
		executionflag ,	integservicename ,		isbr,				methodid ,
		processname ,	projectname ,			sectionname ,		sequenceno ,
		servicename ) 
as 
select 	component_name ,	connectivityflag ,	controlexpression ,	customer_name ,
		executionflag ,		integservicename ,	isbr ,				methodid ,
		process_name ,		project_name,		sectionname ,		sequenceno ,
		servicename 
from 	de_fw_des_processsection_br_is (nolock)
union
select 	a.componentname 	as componentname,
		1 					as connectivityflag, 
		null 				as controlexpression, 
		a.customer_name 	as customername, 
		1 					as executionflag, 
		null 				as integservicename, 
		1 					as isbr, 
		0 					as methodid, 
		a.process_name 		as processname, 
		a.project_name 		as projectname,
		b.sectionname 		as sectionname, 
		101 				as sequenceno, 
		a.servicename 		as servicename 
from 	de_fw_des_service a (nolock),
		de_fw_des_processsection b (nolock)
where	a.customer_name = b.customer_name
and		a.project_name	= b.project_name
and		a.process_name	= b.process_name
and		a.componentname	= b.component_name
and		a.servicename	= b.servicename
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_base_processsection_br_is_err_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_base_processsection_br_is_err_vw TO PUBLIC
END
GO


