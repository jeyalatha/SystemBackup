IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_wg_group_dtl' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_wg_group_dtl
    End
Go


create view  [de_fw_des_wg_group_dtl]        
		as              
		select ComponentName,CustomerName,GroupDescr,GroupName,ProcessName,ProjectName,ServiceName from rvw20appdb.dbo.de_fw_des_wg_group_dtl a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_wg_group_dtl' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_wg_group_dtl TO PUBLIC
END
GO


