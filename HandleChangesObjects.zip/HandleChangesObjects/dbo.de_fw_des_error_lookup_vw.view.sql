IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_error_lookup_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_error_lookup_vw
    End
Go


/************************************************************************************
procedure name and id   de_fw_des_publish_focus_control_vw
description
name of the author
date created
query file name         de_fw_des_publish_focus_control_vw
modifications history
modified by
modified date
modified purpose
***********************************************************************************/
Create view [de_fw_des_error_lookup_vw]
as
select customer_name,project_name,process_name,component_name,activity_name,ui_name,task_name,service_name,errorid,pub_name,linkid,published_comp_name,published_act_name,published_ui_name,ecrno,post_task,createddate,createdby,modifieddate,modifiedby
from de_fw_des_error_lookup (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_error_lookup_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_error_lookup_vw TO PUBLIC
END
GO


