IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='Apkg_Configure_DocMaster_Vw' AND TYPE = 'V')
    Begin
        Drop View Apkg_Configure_DocMaster_Vw
    End
Go


 
	/*	Creating View Script - Apkg_Configure_DocMaster_Vw on 	Jun 26 2005 11:46PM		*/	
	Create View [Apkg_Configure_DocMaster_Vw] As Select 
	CustomerID,
	ProjectID,
	LangID,
	RCN,
	ECR,
	ICO,
	Releasecount,
	UpdUser,
	UpdTime
	from Apkg_Configure_DocMaster(nolock)
	

GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'Apkg_Configure_DocMaster_Vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  Apkg_Configure_DocMaster_Vw TO PUBLIC
END
GO


