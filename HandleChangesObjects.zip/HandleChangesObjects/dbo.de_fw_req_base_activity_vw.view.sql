IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_base_activity_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_base_activity_vw
    End
Go



/************************************************************************************    
procedure name and id   de_fw_req_publish_activity_vw
description             The View used for Launch Pad
name of the author          
date created                
query file name         de_fw_req_publish_activity_vw
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/  
Create view [de_fw_req_base_activity_vw]
		(activitydesc ,activityid ,activityname ,activityposition ,activitysequence ,
		activitytype ,componentname ,customername ,iswfenabled ,processname ,projectname,parentcomponentname) 
as 
select 	activitydesc ,activityid ,activityname ,activityposition ,activitysequence ,
		activitytype ,componentname ,customer_name ,iswfenabled ,process_name ,project_name ,componentname
from 	de_fw_req_activity (nolock)
union
-- code commented by Ganesh for the bugid :: PNR2.0_1960
-- In Deployment Entry Activity ID gets duplicated.

-- select	b.publication_act_name , 0, b.publication_act_name ,1 ,0 ,
-- 		2, 	b.publication_comp_name ,a.customername ,ecrno ,1 ,e.BPID ,a.projectname 
-- from	de_fw_req_publish_ilbo_linkuse 	a (nolock),
-- 		re_resolved_link				b (nolock),
-- 		fw_bpt_function_component 		e (nolock)		
-- where	a.customername		= b.customer_name
-- and		a.projectname		= b.project_name
-- and		a.componentname		= b.component_name
-- and		a.parentilbocode	= b.ui_name
-- and		a.componentname		<> b.publication_comp_name
-- and		a.childilbocode		= b.publication_ui_name
-- 
-- and		e.customerid		= b.customer_name
-- and		e.projectid			= b.project_name
-- and		e.ComponentName		= b.publication_comp_name
-- and		not exists ( 
-- 			select	's'
-- 			from	de_fw_req_activity d (nolock)
-- 			where	b.customer_name			= d.customer_name
-- 			and		b.project_name			= d.project_name
-- 			and		e.BPID					= d.process_name
-- 			and		b.publication_comp_name	= d.component_name
-- 			and		publication_act_name	= d.activityname)
-- union
-- code modified by Ganesh for the callid :: PNR2.0_4183
select	c.activitydesc , c.activityid, c.activityname ,1 ,0 ,
		activitytype,  c.component_name ,c.customer_name ,1 ,c.process_name ,c.project_name ,a.component_name
from	de_fw_req_ilbo_linkuse 	a (nolock),
		de_fw_req_activity_ilbo			b (nolock),
		de_fw_req_activity				c (nolock)
where	a.customer_name		= b.customer_name
and		a.project_name		= b.project_name
and		a.component_name		<> b.component_name 
and		a.childilbocode		= b.ilbocode

and		b.customer_name		= c.customer_name
and		b.project_name		= c.project_name
and		b.process_name		= c.process_name
and		b.component_name	= c.component_name
and		b.activityid		= c.activityid



GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_base_activity_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_base_activity_vw TO PUBLIC
END
GO


