IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_base_page_control_state_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_base_page_control_state_vw
    End
Go



/************************************************************************************
procedure name and id   de_fw_des_publish_page_control_state_vw
description             
name of the author      
date created            
query file name         de_fw_des_publish_page_control_state_vw
modifications history   
modified by             Balaji S
modified date           30/Jul/2007
modified purpose        PNR2.0_14723
***********************************************************************************/

create view [de_fw_des_base_page_control_state_vw]
as
select 	distinct 
	a.customer_name			'customername',
	a.project_name			'projectname',
	a.process_name			'processname',
	a.component_name		'componentname',
	--a.ecrno				'ecrno',
	a.activity_name			'activityname',
	a.ui_name			'uiname',
	a.page_bt_synonym		'pagename',
	a.section_bt_synonym 		'sectionname',
	b.control_id		 	'controlname'
from 	de_ui_state_control 	a (nolock),
	de_ui_control 	b (nolock),
	de_ui			c (nolock)
where 	a.customer_name 	= b.customer_name
and 	a.project_name 		= b.project_name
--and	a.ecrno			= b.ecrno
and 	a.process_name 		= b.process_name
and 	a.component_name	= b.component_name
and	a.activity_name 	= b.activity_name
and 	a.ui_name 		= b.ui_name
and 	a.page_bt_synonym 	= b.page_bt_synonym 
and 	a.section_bt_synonym 	= b.section_bt_synonym
and 	a.control_bt_synonym 	= b.control_bt_synonym 	
and	a.customer_name 	= c.customer_name
and 	a.project_name 		= c.project_name
--and	a.ecrno			= c.ecrno
and 	a.process_name 		= c.process_name
and 	a.component_name	= c.component_name
and	a.activity_name 	= c.activity_name
and 	a.ui_name 		= c.ui_name
and	isnull(c.state_processing,'no')	= 'yes'	
union 
select 	distinct 
	a.customer_name			'customername',
	a.project_name			'projectname',
	a.process_name			'processname',
	a.component_name		'componentname',
	--a.ecrno				'ecrno',
	a.activity_name			'activityname',
	a.ui_name			'uiname',
	a.page_bt_synonym		'pagename',
	a.section_bt_synonym		'sectionname',
	'lbl' + b.control_id		'controlname'
from 	de_ui_state_control 	a (nolock),
	de_ui_control 	b (nolock),
	es_comp_ctrl_type_mst_vw	c (nolock),
	de_ui			d (nolock)
where 	a.customer_name 	= b.customer_name
and 	a.project_name 		= b.project_name
--and	a.ecrno			= b.ecrno
and 	a.process_name 		= b.process_name
and 	a.component_name	= b.component_name
and	a.activity_name 	= b.activity_name
and 	a.ui_name 		= b.ui_name
and 	a.page_bt_synonym 	= b.page_bt_synonym 
and 	a.section_bt_synonym 	= b.section_bt_synonym
and 	a.control_bt_synonym 	= b.control_bt_synonym 	

and 	b.customer_name 	= c.customer_name
and 	b.project_name 		= c.project_name
and 	b.process_name 		= c.process_name
and 	b.component_name	= c.component_name
and	c.caption_req		= 'Y'
and 	b.control_type		= c.ctrl_type_name
and 	c.base_ctrl_type	not in ('Button')

and	a.customer_name 	= d.customer_name
and 	a.project_name 		= d.project_name
--and	a.ecrno			= d.ecrno
and 	a.process_name 		= d.process_name
and 	a.component_name	= d.component_name
and	a.activity_name 	= d.activity_name
and 	a.ui_name 		= d.ui_name
and	isnull(d.state_processing,'no')	= 'yes'	
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_base_page_control_state_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_base_page_control_state_vw TO PUBLIC
END
GO


