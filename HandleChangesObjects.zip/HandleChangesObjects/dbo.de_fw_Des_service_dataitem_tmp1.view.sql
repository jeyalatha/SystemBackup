IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_Des_service_dataitem_tmp1' AND TYPE = 'V')
    Begin
        Drop View de_fw_Des_service_dataitem_tmp1
    End
Go


create view  [de_fw_Des_service_dataitem_tmp1]        
		as              
		select component_name,createdby,createddate,customer_name,dataitemname,defaultvalue,ecrno,flowattribute,ispartofkey,mandatoryflag,modifiedby,modifieddate,process_name,project_name,segmentname,servicename,timestamp,updtime,upduser from rvw20appdb.dbo.de_fw_Des_service_dataitem_tmp1 a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_Des_service_dataitem_tmp1' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_Des_service_dataitem_tmp1 TO PUBLIC
END
GO


