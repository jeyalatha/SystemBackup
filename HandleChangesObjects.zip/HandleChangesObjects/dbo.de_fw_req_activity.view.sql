IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_activity' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_activity
    End
Go


CREATE view  [de_fw_req_activity]              
					as              
					select accesskey,activitydesc,activityid,activityname,activityposition,activitysequence,activitytype,base_comptname 'componentname' ,componentname 'component_name' ,createdby,createddate,customername 'customer_name' ,ecrno,iswfenabled,linkedActivityId,modifiedby,modifieddate,processname 'process_name' ,projectname 'project_name' ,timestamp,updtime,upduser,IsForcedActivity,devicetype from rvw_publish_db.dbo.de_fw_req_publish_activity a (nolock)        
					where exists (select 'x' from De_Customer_Space b (nolock)        
					where     a.customername   = b.customername        
					and       a.projectname    = b.projectname        
					and       a.processname    = b.processname        
					and       a.componentname  = b.componentname    
					and       a.ecrno        = b.ecrno )

GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_activity' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_activity TO PUBLIC
END
GO


