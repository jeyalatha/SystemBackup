IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_ilbo_service_view_datamap_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_ilbo_service_view_datamap_vw
    End
Go


 
	/*	Creating View Script - de_fw_des_ilbo_service_view_datamap_vw on 	Jun 26 2005 11:46PM		*/	

/************************************************************************************
view name and id   		: de_fw_des_ilbo_service_view_datamap_vw
description             : 	
name of the author      : A.G.Senthil kumar
date created            :
query file name         : de_fw_des_ilbo_service_view_datamap_vw.sql
modifications history   :
modified by             :
modified date           :
modified purpose        :
************************************************************************************/
create view  [de_fw_des_ilbo_service_view_datamap_vw]
as 
select ilbocode,servicename,activityid,taskname,
segmentname,dataitemname,iscontrol,customer_name,
project_name,process_name,component_name,
activity_name,page_bt_synonym,control_bt_synonym,
controlid,viewname,variablename
from de_fw_des_ilbo_service_view_datamap(nolock)

GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_ilbo_service_view_datamap_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_ilbo_service_view_datamap_vw TO PUBLIC
END
GO


