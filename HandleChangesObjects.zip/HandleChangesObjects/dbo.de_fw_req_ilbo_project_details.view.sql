IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_ilbo_project_details' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_ilbo_project_details
    End
Go


create view  [de_fw_req_ilbo_project_details]        
		as              
		select component_name,createdby,createddate,customer_name,description,developerclassname,developerprojectname,ilbocode,modifiedby,modifieddate,process_name,progid,project_name,projectgroupfilepath,resourceclassname,resourcefilename,resourceprogid,resourceprojectname,screenfilename,screenprojectname,timestamp,updtime,upduser,userprogid from rvw20appdb.dbo.de_fw_req_ilbo_project_details a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_ilbo_project_details' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_ilbo_project_details TO PUBLIC
END
GO


