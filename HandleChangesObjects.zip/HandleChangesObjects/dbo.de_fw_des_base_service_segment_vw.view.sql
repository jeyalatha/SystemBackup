IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_base_service_segment_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_base_service_segment_vw
    End
Go



/************************************************************************************    
procedure name and id   de_fw_des_publish_service_segment_vw
description             The View used for Launch Pad
name of the author          
date created                
query file name         de_fw_des_publish_service_segment_vw
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/  

Create view [de_fw_des_base_service_segment_vw]
		(bocode ,bosegmentname ,componentname ,customername ,instanceflag ,
		mandatoryflag ,parentsegmentname ,processname ,projectname ,segmentname ,servicename,
		SegmentSequence,process_selrows,ParentComponentname) 
as 
select 	bocode 					as	'bocode',
		bosegmentname 			as	'bosegmentname',
		component_name 			as	'componentname',
		customer_name 			as	'customername',
--		ecrno 					as	'ecrno',
		instanceflag 			as	'instanceflag',
		mandatoryflag 			as	'mandatoryflag',
		parentsegmentname		as	'parentsegmentname',
		process_name				as	'processname',
		project_name				as	'projectname',
		segmentname				as	'segmentname',
		servicename				as	'servicename',	 
		1 						as	'SegmentSequence',
	   process_selrows			as  'process_selrows',
	component_name			as	'ParentComponentname'
from 	de_fw_des_service_segment a (nolock)
where	exists (
			select	's'
			from	de_fw_des_base_task_segment_attribs b (nolock)
			where	a.customer_name		= b.customer_name
			and		a.project_name		= b.project_name
--			and		a.ecrno 			= b.ecrno
			and		a.process_name		= b.process_name
			and		a.component_name		= b.component_name
			and		a.servicename		= b.servicename
			and		a.segmentname		= b.segmentname)
union
select 	bocode					as	'bocode',
		bosegmentname			as	'bosegmentname',
		component_name			as	'componentname',
		customer_name			as	'customername',
--		ecrno					as	'ecrno',
		instanceflag			as	'instanceflag',
		mandatoryflag			as	'mandatoryflag',
		parentsegmentname		as	'parentsegmentname',
		process_name				as	'processname',
		project_name				as	'projectname',
		segmentname				as	'segmentname',
		servicename				as	'servicename',	 
		2						as	'SegmentSequence',
		process_selrows			as  'process_selrows',
	component_name			as	'ParentComponentname'
from 	de_fw_des_service_segment a (nolock)
where	not exists (
			select	's'
			from	de_fw_des_base_task_segment_attribs b (nolock)
			where	a.customer_name		= b.customer_name
			and		a.project_name		= b.project_name
--			and		a.ecrno 			= b.ecrno
			and		a.process_name		= b.process_name
			and		a.component_name		= b.component_name
			and		a.servicename		= b.servicename
			and		a.segmentname		= b.segmentname)
union
select 	sr.bocode 				as	'bocode',
		sr.bosegmentname 		as	'bosegmentname',
		sr.component_name 		as	'componentname',
		sr.customer_name 		as	'customername',
--		ps.ecrno 				as	'ecrno',
		sr.instanceflag 		as	'instanceflag',
		sr.mandatoryflag 		as	'mandatoryflag',
		sr.parentsegmentname 	as	'parentsegmentname',
		sr.process_name 		as	'processname',
		sr.project_name 		as	'projectname',
		sr.segmentname 			as	'segmentname',
		sr.servicename			as	'servicename',
		1 						as	'SegmentSequence',
		process_selrows			as  'process_selrows',
	ps.component_name			as	'ParentComponentname'
from 	de_fw_des_service_segment 				sr(nolock),
		de_fw_des_processsection_br_is 	ps(nolock)
where 	sr.servicename 		=  ps.integservicename
and 	sr.customer_name 	=  ps.customer_name
and 	sr.project_name  	=  ps.project_name
and		ps.component_name 	<> sr.component_name










GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_base_service_segment_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_base_service_segment_vw TO PUBLIC
END
GO


