IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_base_chart_task_map_vw' AND TYPE = 'V')
    Begin
        Drop View de_base_chart_task_map_vw
    End
Go



/************************************************************************************
procedure name and id   de_base_chart_task_map_vw 
description             
name of the author      
date created            
query file name         de_base_chart_task_map_vw 
modifications history   
modified by             
modified date           
modified purpose        
***********************************************************************************/
create view [de_base_chart_task_map_vw]
as
select 	distinct a.customer_name  	'customername',
		a.project_name				'projectname',
		a.process_name				'processname',
		a.component_name			'componentname',
		a.activity_name				'activity_name',
		a.ui_name					'ui_name',
		c.page_bt_synonym			'page_name',
		c.section_bt_synonym 		'section_name',
		a.task_name					'taskname',
		b.service_name 				'servicename',
		d.task_type					'tasktype'
from 	de_flowbr 			a (nolock),
		de_task_service_map 	b (nolock),
		de_ui_section 		c (nolock),
		de_action 			d (nolock)
where 	a.customer_name 	= d.customer_name
and 	a.project_name 		= d.project_name
and 	a.process_name 		= d.process_name
and		a.component_name	= d.component_name
and 	a.activity_name		= d.activity_name
and 	a.ui_name			= d.ui_name
and 	a.page_bt_synonym	= d.page_bt_synonym
and 	a.task_name			= d.task_name

and 	a.customer_name 	= c.customer_name
and 	a.project_name 		= c.project_name
and 	a.process_name 		= c.process_name
and		a.component_name	= c.component_name
and 	a.activity_name		= c.activity_name
and 	a.ui_name			= c.ui_name
--and 	a.page_bt_synonym	= c.page_bt_synonym
and 	(a.flowbr_name  		like '%ChartConfg'
		or  a.flowbr_name  		like '%ChartData' 
		or 	a.flowbr_name  		like '%ChartSeries')
and 	a.map_flag			= 'Y'
and 	c.section_type 		= 'Chart'

and 	b.customer_name 	= d.customer_name
and 	b.project_name 		= d.project_name
and 	b.process_name 		= d.process_name
and		b.component_name	= d.component_name
and 	b.activity_name		= d.activity_name
and 	b.ui_name			= d.ui_name
and 	b.task_name			= d.task_name




GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_base_chart_task_map_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_base_chart_task_map_vw TO PUBLIC
END
GO


