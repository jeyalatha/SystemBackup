IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_download_log' AND TYPE = 'V')
    Begin
        Drop View de_download_log
    End
Go


create view  [de_download_log]        
		as              
		select activity_name,component_name,createdby,createddate,customer_name,doc_no,l1,l2,l3,l4,log_type,logged_by,logged_date,modifiedby,modifieddate,process_name,project_name,seq_no,table_name,timestamp,ui_name from rvw20appdb.dbo.de_download_log a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_download_log' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_download_log TO PUBLIC
END
GO


