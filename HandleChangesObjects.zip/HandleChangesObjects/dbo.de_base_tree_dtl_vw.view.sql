IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_base_tree_dtl_vw' AND TYPE = 'V')
    Begin
        Drop View de_base_tree_dtl_vw
    End
Go



/*	Creating View Script - de_published_tree_dtl on 	MAr 31 2006 11:46PM		*/	

/************************************************************************************
procedure name and id   de_published_tree_dtl   
description             
name of the author      
date created            MAr 31 2006
query file name         
modifications history   
modified by             
modified date           
modified purpose        
***********************************************************************************/
create view [de_base_tree_dtl_vw] 
	  (customer_name,		project_name,		process_name,		component_name,
	  activity_name,		ui_name,			page_bt_synonym,	section_bt_synonym,		node_type,
	  node_description,		event_req,			mapped_task,		open_img_name,			not_exp_img_name,
	  expendable_img_name,	expended_img_name,	close_img_name,		chkbox_chk_img,			chkbox_unchk_img,
	  chkbox_parial_chkimg,	createdby,			createddate,		modifiedby,				modifieddate)
as

select customer_name,		project_name,		process_name,		component_name,
	  activity_name,		ui_name,			page_bt_synonym,	section_bt_synonym,		node_type,
	  node_description,		event_req,			mapped_task,		open_img_name,			not_exp_img_name,
	  expendable_img_name,	expended_img_name,	close_img_name,		chkbox_chk_img,			chkbox_unchk_img,
	  chkbox_parial_chkimg,	createdby,			createddate,		modifiedby,				modifieddate
from de_tree_dtl (nolock)


GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_base_tree_dtl_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_base_tree_dtl_vw TO PUBLIC
END
GO


