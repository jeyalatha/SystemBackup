IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_base_activity_task_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_base_activity_task_vw
    End
Go



/************************************************************************************    
procedure name and id   de_fw_req_base_activity_task_vw
description             
name of the author      BharathiDasan.V.V
date created            13-07-2007                
query file name         de_fw_req_base_activity_task_vw
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/  
CREATE view [de_fw_req_base_activity_task_vw] 
	  ( activityid ,		componentname ,		customername, 		invocationtype ,	processname ,
		projectname ,		taskname ,			tasksequence,		Activityname ) 
as 
select 	A.activityid ,		A.component_name ,	A.customer_name ,	A.invocationtype ,	A.process_name ,
		A.project_name ,	A.taskname ,		A.tasksequence ,	B.Activityname
from 	de_fw_req_activity_task A(nolock),
		de_fw_req_activity 		B (nolock)
where	A.customer_name 	= b.customer_name
and		a.project_name 		= b.project_name
and		a.process_name		= b.process_name
and		a.component_name 	= b.componentname
and 	a.activityid		= b.activityid

GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_base_activity_task_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_base_activity_task_vw TO PUBLIC
END
GO


