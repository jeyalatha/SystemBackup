IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_base_sp_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_base_sp_vw
    End
Go



/************************************************************************************    
procedure name and id   de_fw_des_base_sp_vw
description             
name of the author          
date created                
query file name         de_fw_des_base_sp_vw
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/  
create view [de_fw_des_base_sp_vw] 
		(componentname ,	customername ,	methodid ,	processname ,	projectname ,
		sperrorprotocol,	spname ) 
as 
select 	component_name,		customer_name,	methodid ,	process_name,	project_name,
		sperrorprotocol ,	spname 
from 	de_fw_des_sp (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_base_sp_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_base_sp_vw TO PUBLIC
END
GO


