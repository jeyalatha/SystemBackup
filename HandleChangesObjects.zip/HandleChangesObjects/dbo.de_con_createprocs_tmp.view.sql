IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_con_createprocs_tmp' AND TYPE = 'V')
    Begin
        Drop View de_con_createprocs_tmp
    End
Go


create view  [de_con_createprocs_tmp]              
			(guid,procname,rowdata,Seqno)        
			as              
			select guid,procname,rowdata,Seqno from rvw20appdb.dbo.de_con_createprocs_tmp (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_con_createprocs_tmp' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_con_createprocs_tmp TO PUBLIC
END
GO


