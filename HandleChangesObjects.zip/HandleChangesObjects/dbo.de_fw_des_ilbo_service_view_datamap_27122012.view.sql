IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_ilbo_service_view_datamap_27122012' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_ilbo_service_view_datamap_27122012
    End
Go


create view  [de_fw_des_ilbo_service_view_datamap_27122012]        
		as              
		select activity_name,activityid,component_name,control_bt_synonym,controlid,createdby,createddate,customer_name,dataitemname,ecrno,ilbocode,iscontrol,modifiedby,modifieddate,page_bt_synonym,process_name,project_name,segmentname,servicename,taskname,timestamp,updtime,upduser,variablename,viewname,viewname_bk from rvw20appdb.dbo.de_fw_des_ilbo_service_view_datamap_27122012 a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_ilbo_service_view_datamap_27122012' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_ilbo_service_view_datamap_27122012 TO PUBLIC
END
GO


