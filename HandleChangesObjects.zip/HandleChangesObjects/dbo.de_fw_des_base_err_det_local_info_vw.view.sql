IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_base_err_det_local_info_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_base_err_det_local_info_vw
    End
Go



/************************************************************************************    
procedure name and id   de_fw_des_base_err_det_local_info_vw
description             
name of the author      BharathiDasan.V.V
date created            13-07-2007    
query file name         de_fw_des_base_err_det_local_info_vw
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/  
create view [de_fw_des_base_err_det_local_info_vw] 
	  ( componentname ,				customername ,		detaileddesc ,		errorid ,
		errormessage ,				langid ,			processname ,		projectname , 	
		defaultcorrectiveaction) 
as
select 	a.component_name ,			a.customer_name,	a.detaileddesc,		a.errorid ,
		a.errormessage ,			a.langid ,			a.process_name ,	a.project_name,  
		b.defaultcorrectiveaction
from 	de_fw_des_err_det_local_info 	a (nolock),
		de_fw_des_error					b (nolock)
where	a.customer_name		= b.customer_name
and		a.project_name		= b.project_name
and		a.process_name		= b.process_name
and		a.component_name	= b.componentname
and		a.errorid			= b.errorid


GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_base_err_det_local_info_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_base_err_det_local_info_vw TO PUBLIC
END
GO


