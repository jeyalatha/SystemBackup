IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_els_query_ps_map' AND TYPE = 'V')
    Begin
        Drop View de_els_query_ps_map
    End
Go


create view [de_els_query_ps_map](
CustomerName,
ProjectName,
ECRNumber,
ProcessName,
ComponentName,
ServiceName,
ProcessSectionName,
ProcessSectionSeq,
QueryID,
Createdby,
Createddate,
Modifedby,
Modifieddate
)
as select 
CustomerName,
ProjectName,
ECRNumber,
ProcessName,
ComponentName,
ServiceName,
ProcessSectionName,
ProcessSectionSeq,
QueryID,
Createdby,
Createddate,
Modifedby,
Modifieddate
from RVW_Publish_DB.dbo.de_published_els_query_ps_map a
where exists (select 'x' from De_Customer_Space b (nolock)          
     where     a.customername   = b.customername          
     and       a.projectname    = b.projectname          
     and       a.processname    = b.processname          
     and       a.componentname  = b.componentname      
     and       a.ecrnumber       = b.ecrno )  
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_els_query_ps_map' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_els_query_ps_map TO PUBLIC
END
GO


