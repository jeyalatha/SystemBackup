IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_base_businessrule_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_base_businessrule_vw
    End
Go



/************************************************************************************    
procedure name and id   de_fw_des_base_businessrule_vw
description             
name of the author      BharathiDasan.V.V
date created            16-07-2007               
query file name         de_fw_des_base_businessrule_vw
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/  
create view [de_fw_des_base_businessrule_vw] 
	  ( accessesdatabase ,	bocode ,		broname ,	componentname ,	customername ,
		dispid ,			isintegbr ,		methodid ,	methodname ,	operationtype ,
		processname ,		projectname ,	statusflag ,systemgenerated ) 
as 
select 	accessesdatabase ,	bocode ,		broname ,	component_name,	customer_name ,
		dispid ,			isintegbr ,		methodid ,	methodname ,	operationtype ,
		process_name ,		project_name ,	statusflag ,systemgenerated 
from 	de_fw_des_businessrule (nolock)




GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_base_businessrule_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_base_businessrule_vw TO PUBLIC
END
GO


