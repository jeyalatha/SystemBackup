IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_publish_chart_service_segment' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_publish_chart_service_segment
    End
Go


create view  [de_fw_des_publish_chart_service_segment]        
	as              
	select chart_id,chart_section,component_name,createdby,createddate,customer_name,ecrno,instanceflag,map,modifiedby,modifieddate,
	process_name,project_name,segmentname,servicename,timestamp 
	from rvw_publish_db.dbo.de_fw_des_publish_chart_service_segment a 

(nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_publish_chart_service_segment' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_publish_chart_service_segment TO PUBLIC
END
GO


