IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_ecr_publish_chk' AND TYPE = 'V')
    Begin
        Drop View de_ecr_publish_chk
    End
Go


create view  [de_ecr_publish_chk]        
		as              
		select createdby,createddate,customer_Name,ecr_no,host_mcname,modifiedby,modifieddate,Project_Name,publ_username,start_time,timestamp,work_flag from rvw20appdb.dbo.de_ecr_publish_chk a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_ecr_publish_chk' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_ecr_publish_chk TO PUBLIC
END
GO


