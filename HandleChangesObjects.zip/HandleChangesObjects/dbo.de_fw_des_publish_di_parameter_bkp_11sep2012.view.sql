IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_publish_di_parameter_bkp_11sep2012' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_publish_di_parameter_bkp_11sep2012
    End
Go


create view  [de_fw_des_publish_di_parameter_bkp_11sep2012]        
		as              
		select componentname,createdby,createddate,customername,dataitemname,dna_parametername,ecrno,method_name,methodid,modifiedby,modifieddate,parametername,processname,projectname,sectionname,segmentname,sequenceno,servicename,timestamp,updtime,upduser from rvw20appdb.dbo.de_fw_des_publish_di_parameter_bkp_11sep2012 a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_publish_di_parameter_bkp_11sep2012' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_publish_di_parameter_bkp_11sep2012 TO PUBLIC
END
GO


