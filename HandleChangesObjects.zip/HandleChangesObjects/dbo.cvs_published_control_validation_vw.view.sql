IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='cvs_published_control_validation_vw' AND TYPE = 'V')
    Begin
        Drop View cvs_published_control_validation_vw
    End
Go



Create view [cvs_published_control_validation_vw]
as 
select 		a.customer_name			'customer_name',
		a.project_name			'project_name',
		a.ecrno 				'ecrno',
		a.process_name			'process_name',
		a.component_name 		'component_name',
		a.activity_name			'activity_name',
		b.languageid			'languageid',
		a.ui_name 			'ui_name',
		a.page_name			'page_name',
		a.task_name			'task_name',
		a.control_name			'control_name',
		a.validation_code		'validation_code',
		b.message_code			'message_code',
		b.translated_msg 		'message_doc',
		a.value1	 			'value1',
		a.value2				'value2',
		a.eval_sequence			'order_of_sequence'
from 	cvs_published_control_validation	a (nolock),
	cvs_published_message_lng_extn				b (nolock)
where 	a.customer_name 	= b.customer_name
and 	a.project_name 		= b.project_name
and 	a.process_name 		= b.process_name
and 	a.component_name	= b.component_name
and 	a.ecrno			= b.ecrno
and 	a.activity_name		= b.activity_name
and 	a.ui_name		= b.ui_name
and 	a.page_name 		= b.page_name
and	a.task_name		= b.task_name
and	a.control_name		= b.control_name 
and 	a.validation_code 	= b.validation_code
/* Code added by Hemalatha.K on 10th July 2007 */
and	b.translated_msg 	is not null


GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'cvs_published_control_validation_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  cvs_published_control_validation_vw TO PUBLIC
END
GO


