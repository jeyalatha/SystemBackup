IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_bt_attributes_history' AND TYPE = 'V')
    Begin
        Drop View de_bt_attributes_history
    End
Go


create view  [de_bt_attributes_history]        
		as              
		select bt_name,component_name,createdby,createddate,customer_name,ecrno,History_version,modifiedby,modifieddate,new_datatype,new_length,new_prec_declength,new_prec_totlength,new_precisiontype,old_datatype,old_length,old_prec_declength,old_prec_totlength,old_precisiontype,process_name,project_name,timestamp from rvw20appdb.dbo.de_bt_attributes_history a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_bt_attributes_history' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_bt_attributes_history TO PUBLIC
END
GO


