IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='cvs_published_message_lng_extn_vw' AND TYPE = 'V')
    Begin
        Drop View cvs_published_message_lng_extn_vw
    End
Go



create view [cvs_published_message_lng_extn_vw]
as
	select 	customer_name		'customer_name', 
			project_name		'project_name', 
			ecrno				'ecrno',
			process_name		'process_name',
			component_name		'component_name',
			activity_name		'activity_name',
			ui_name				'ui_name',
			page_name			'page_name',
			task_name			'task_name', 
			control_name		'control_name', 
			validation_code		'validation_code',
			message_code 		'message_code',
			languageid	 		'languageid',
			translated_msg		'translated_msg', 
			generated_message	'generated_message',
			timestamp			'timestamp', 
			createdby			'createdby',
			createddate			'createddate', 
			modifiedby			'modifiedby', 
			modifieddate		'modifieddate'
	from 	cvs_published_message_lng_extn (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'cvs_published_message_lng_extn_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  cvs_published_message_lng_extn_vw TO PUBLIC
END
GO


