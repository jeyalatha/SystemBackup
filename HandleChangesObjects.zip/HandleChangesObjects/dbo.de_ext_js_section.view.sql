IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_ext_js_section' AND TYPE = 'V')
    Begin
        Drop View de_ext_js_section
    End
Go


create view  [de_ext_js_section]        
		as              
		select activity_name,Callout_Task,component_name,createdby,createddate,customer_name,Direction,ecr_no,Fade_Delay,modifiedby,modifieddate,No_Of_Columns,page_bt_synonym,process_name,project_name,Property_Class,Report_Item_Class,RVW_Task,sample_data,Scroll_Behaviour,Scroll_Delay,section_bt_synonym,Section_Class,Section_Height,section_type,Section_Width,ui_name,Value_Class from rvw20appdb.dbo.de_ext_js_section a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_ext_js_section' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_ext_js_section TO PUBLIC
END
GO


