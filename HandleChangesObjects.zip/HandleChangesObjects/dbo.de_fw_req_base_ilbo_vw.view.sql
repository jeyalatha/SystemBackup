IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_base_ilbo_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_base_ilbo_vw
    End
Go



/*	Creating View Script - de_fw_req_publish_ilbo_vw on 	Jun 26 2005 11:46PM		*/	

/************************************************************************************    
procedure name and id   de_fw_req_publish_ilbo_vw
description             The View used for Launch Pad
name of the author          
date created                
query file name         de_fw_req_publish_ilbo_vw
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/  
Create view [de_fw_req_base_ilbo_vw]
		(aspofilepath ,componentname ,customername ,description ,ilbocode ,ilbotype ,
		processname ,progid ,projectname ,statusflag ) 
as 
select 	a.aspofilepath ,a.component_name ,a.customer_name ,a.description ,a.ilbocode ,a.ilbotype ,
		a.process_name ,a.progid ,a.project_name ,a.statusflag 
from 	de_fw_req_ilbo 			a (nolock),
		de_fw_req_ilbo_control 	b (nolock)
where	a.customer_name		= b.customer_name
and		a.project_name		= b.project_name
and		a.process_name		= b.process_name
and		a.component_name		= b.component_name
--and		a.ecrno				= b.ecrno
and		a.ilbocode			= b.ilbocode
union
select	c.activity_name+'_'+c.ui_name+'.asp', publication_comp_name, b.customer_name, 
		d.description, c.ui_name,
		case ui_type
		when 	'EntryPoint' 	then	1	
		when 	'Main'			then	2
		when 	'Modify'		then	3
		when	'MainModify'	then	4
		when	'MainView'		then	5
		when	'Others'		then	6
		when	'Security'		then	7
		when	'View'			then	8
		when	'Snapshot'		then	9
		when	'Help'			then 	6
		else	6
		end,
		c.process_name, null, c.project_name, d.statusflag 
from	de_fw_req_ilbo_linkuse 	a (nolock),
		re_resolved_link				b (nolock),
		de_ui						c (nolock),
		de_fw_req_ilbo					d (nolock)
where	a.customer_name			= b.customer_name
and		a.project_name			= b.project_name
and		a.component_name			= b.component_name
and		a.parentilbocode		= b.ui_name
and		a.component_name			<> b.publication_comp_name
and		a.childilbocode			= b.publication_ui_name

and		a.customer_name			= c.customer_name
and		a.project_name			= c.project_name
and		a.childilbocode			= c.ui_name

and		b.customer_name			= c.customer_name
and		b.project_name			= c.project_name
and		b.publication_comp_name	= c.component_name
and		b.publication_act_name	= c.activity_name
and		b.publication_ui_name	= c.ui_name
and		c.customer_name	= d.customer_name
and		c.project_name	= d.project_name
and	c.process_name	= d.process_name
and	c.component_name	= d.component_name
and	c.ui_name	= d.ilbocode




GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_base_ilbo_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_base_ilbo_vw TO PUBLIC
END
GO


