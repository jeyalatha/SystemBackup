IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='ce_component_sp_vw' AND TYPE = 'V')
    Begin
        Drop View ce_component_sp_vw
    End
Go


 
	/*	Creating View Script - ce_component_sp_vw on 	Jun 26 2005 11:46PM		*/	
Create view [ce_component_sp_vw]
as
select 	Customer_Name, 
	Project_Name,
	process_name, 
	component_Name, 	
	Method_Name, 
	Sp_Name,
	sp_type
From ce_component_sp (nolock)


GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'ce_component_sp_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  ce_component_sp_vw TO PUBLIC
END
GO


