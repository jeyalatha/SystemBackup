IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_exrep_lang_extn' AND TYPE = 'V')
    Begin
        Drop View de_exrep_lang_extn
    End
Go


create view  [de_exrep_lang_extn]        
		as              
		select activity_name,component_name,createdby,createddate,customer_name,field_name,FieldCaption_eng,Langid,modifiedby,modifieddate,process_name,project_name,Sampledata_multiIns,Sampledata_singleIns,section_name,Sheet_id,template_id,Translate_to,ui_name from rvw20appdb.dbo.de_exrep_lang_extn a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_exrep_lang_extn' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_exrep_lang_extn TO PUBLIC
END
GO


