IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_activity_history' AND TYPE = 'V')
    Begin
        Drop View de_activity_history
    End
Go


create view  [de_activity_history]        
		as              
		select activity_name,component_name,createdby,createddate,customer_name,ecrno,History_version,modifiedby,modifieddate,new_activity_descr,old_activity_descr,process_name,project_name,timestamp from rvw20appdb.dbo.de_activity_history a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_activity_history' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_activity_history TO PUBLIC
END
GO


