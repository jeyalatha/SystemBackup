IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='Apkg_Ssafe_Dtl_Vw' AND TYPE = 'V')
    Begin
        Drop View Apkg_Ssafe_Dtl_Vw
    End
Go


 
	/*	Creating View Script - Apkg_Ssafe_Dtl_Vw on 	Jun 26 2005 11:46PM		*/	
	Create View [Apkg_Ssafe_Dtl_Vw] As Select 
	CustomerID,
	ProjectID,
	LangID,
	ReleaseVersion,
	DocumentID,
	SsafePath,
	SSafeINI,
	UserName,
	UpdUser,
	UserPassword,
	UpdTime
	from Apkg_Ssafe_Dtl (nolock)
	

GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'Apkg_Ssafe_Dtl_Vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  Apkg_Ssafe_Dtl_Vw TO PUBLIC
END
GO


