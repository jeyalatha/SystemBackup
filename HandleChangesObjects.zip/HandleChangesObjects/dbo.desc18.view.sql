IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='desc18' AND TYPE = 'V')
    Begin
        Drop View desc18
    End
Go


create view  [desc18]        
		as              
		select controlname,newpagename,newsectionname,pagename,sectionname,UI_name from rvw20appdb.dbo.desc18 a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'desc18' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  desc18 TO PUBLIC
END
GO


