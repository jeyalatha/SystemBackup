IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_base_lang_bterm_synonym_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_base_lang_bterm_synonym_vw
    End
Go



/************************************************************************************    
procedure name and id   de_fw_req_base_lang_bterm_synonym_vw
description             
name of the author      BharathiDasan.V.V
date created            16-07-2007
query file name         de_fw_req_base_lang_bterm_synonym_vw
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/  
create view [de_fw_req_base_lang_bterm_synonym_vw] 
	 (	btsynonym ,	componentname ,	customername ,	foreignname ,	langid ,	longdesc ,
		longpltext,	processname,	projectname ,	shortdesc ,	shortpltext ) 
as 
select 	btsynonym ,	component_name,	customer_name ,	foreignname ,	langid ,	longdesc ,
		longpltext,	process_name ,	project_name ,	shortdesc ,	shortpltext 
from 	de_fw_req_lang_bterm_synonym (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_base_lang_bterm_synonym_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_base_lang_bterm_synonym_vw TO PUBLIC
END
GO


