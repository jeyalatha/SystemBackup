IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_ilbo_data_publish_bk_14sep12' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_ilbo_data_publish_bk_14sep12
    End
Go


create view  [de_fw_req_ilbo_data_publish_bk_14sep12]        
		as              
		select component_name,controlid,controlvariablename,createdby,createddate,customer_name,dataitemname,ecrno,flowtype,havemultiple,ilbocode,iscontrol,link_name,linkid,mandatoryflag,modifiedby,modifieddate,process_name,project_name,timestamp,updtime,upduser,viewname from rvw20appdb.dbo.de_fw_req_ilbo_data_publish_bk_14sep12 a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_ilbo_data_publish_bk_14sep12' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_ilbo_data_publish_bk_14sep12 TO PUBLIC
END
GO


