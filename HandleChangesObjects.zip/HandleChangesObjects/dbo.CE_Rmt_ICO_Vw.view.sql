IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='CE_Rmt_ICO_Vw' AND TYPE = 'V')
    Begin
        Drop View CE_Rmt_ICO_Vw
    End
Go


 
	/*	Creating View Script - CE_Rmt_ICO_Vw on 	Jun 26 2005 11:46PM		*/	

---Comments
--BPId, ComponentName  included on 05-06-04.
-- RMT Header View

	CREATE VIEW [CE_Rmt_ICO_Vw]
	AS
    	SELECT 	CustomerID, ProjectID, LangID, ECRNumber, ICONumber, 
		ICODescription, ICOStatus, ICOType, BPId 'ProcessName',ComponentName,	--CodeGenStatus, 
		UpdUser, UpdTime
	FROM	Fw_Rmt_ICO_Vw (nolock)

GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'CE_Rmt_ICO_Vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  CE_Rmt_ICO_Vw TO PUBLIC
END
GO


