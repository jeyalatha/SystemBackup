IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_service_dataitem' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_service_dataitem
    End
Go


create view  [de_fw_des_service_dataitem]              
					as              
					select componentname 'component_name' ,createdby,createddate,customername 'customer_name' ,dataitemname,defaultvalue,ecrno,flowattribute,ispartofkey,mandatoryflag,modifiedby,modifieddate,processname 'process_name' ,projectname 'project_name' ,segmentname,servicename,timestamp,updtime,upduser from rvw_publish_db.dbo.de_fw_des_publish_service_dataitem a (nolock)        
					where exists (select 'x' from De_Customer_Space b (nolock)        
					where     a.customername   = b.customername        
					and       a.projectname    = b.projectname        
					and       a.processname    = b.processname        
					and       a.componentname  = b.componentname    
					and       a.ecrno        = b.ecrno )
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_service_dataitem' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_service_dataitem TO PUBLIC
END
GO


