IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_br_logical_parameter_temp' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_br_logical_parameter_temp
    End
Go


create view  [de_fw_des_br_logical_parameter_temp]        
		as              
		select btname,logicalparametername,logicalparamseqno,spparametertype from rvw20appdb.dbo.de_fw_des_br_logical_parameter_temp a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_br_logical_parameter_temp' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_br_logical_parameter_temp TO PUBLIC
END
GO


