IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_tp_service_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_tp_service_vw
    End
Go


 
	/*	Creating View Script - de_fw_des_tp_service_vw on 	Jun 26 2005 11:46PM		*/	

create view [de_fw_des_tp_service_vw]
as
select  a.customer_name		as  'customer_name',
		a.project_name		as	'project_name',
		a.process_name		as  'process_name',
		a.component_name  	as 	'component_name',
		a.activity_name  	as 	'activity_name',
		b.ilbocode 			as 	'Ilbocode',
		b.servicename		as  'servicename',
		c.isintegser		as  'isintegser'	
from 	de_ui					a (nolock),	
		de_fw_des_ilbo_services b (nolock),
		de_fw_des_service 		c (nolock)
where 	a.customer_name 	= 	b.customer_name
and 	a.project_name  	= 	b.project_name
and 	a.process_name  	= 	b.process_name
and 	a.component_name	= 	b.component_name
and		a.ui_name			=	b.ilbocode
and		b.customer_name		=	c.customer_name
and		b.project_name		=	c.project_name
and		b.process_name		=	c.process_name
and		b.component_name	=	c.componentname
and		b.servicename		=	c.servicename

GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_tp_service_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_tp_service_vw TO PUBLIC
END
GO


