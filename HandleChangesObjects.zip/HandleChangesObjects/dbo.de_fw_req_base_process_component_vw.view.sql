IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_req_base_process_component_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_req_base_process_component_vw
    End
Go




 
/*	Creating View Script - de_fw_req_publish_process_component_vw on 	Jun 26 2005 11:46PM		*/	

/************************************************************************************    
procedure name and id   de_fw_req_publish_process_component_vw
description             The View used for Launch Pad
name of the author          
date created                
query file name         de_fw_req_publish_process_component_vw
modifications history       
modified by             Sangeetha L   For BugId : PNR2.0_5619 
modified date           20-Jan-2006    
modified purpose        New Column primary has to be added in the View de_fw_req_publish_process_component_vw 
						in order to identity the component mapped to the ecr.    
************************************************************************************/  
Create view [de_fw_req_base_process_component_vw]
		(componentdesc ,componentname ,customername ,parentprocess ,projectname ,
		sequenceno,isPrimary) 
as 
select 	componentdesc ,componentname ,customer_name ,parentprocess ,project_name ,
		1,'Yes' 
from 	de_fw_req_process_component (nolock)
union

select 	sr.componentname ,sr.componentname ,sr.customer_name  ,parentprocess ,sr.project_name ,
		1,'No'
from 	de_fw_des_service sr (nolock),
		de_fw_des_processsection_br_is ps(nolock),
		de_fw_req_process_component	ic (nolock)
where 	sr.servicename 		= ps.integservicename
and 	sr.customer_name 	= ps.customer_name
and 	sr.project_name  	= ps.project_name
and		sr.componentname	<>ps.component_name  
and		sr.customer_name	= ic.customer_name
and		sr.project_name		= ic.project_name
and		sr.process_name		= ic.parentprocess
and		sr.componentname	= ic.componentname
union
select	b.publication_comp_name ,b.publication_comp_name ,
		b.customer_name ,c.bpid , b.project_name ,
		1,'No'
from	de_fw_req_ilbo_linkuse 	a (nolock),
		re_resolved_link				b (nolock),
		Fw_Bpt_Function_Component		c(nolock)
where	a.customer_name		= b.customer_name
and		a.project_name		= b.project_name
and		a.process_name		= b.process_name
and		a.component_name		= b.component_name
and		a.parentilbocode	= b.ui_name
and		a.component_name		<> b.publication_comp_name
and		a.childilbocode		= b.publication_ui_name
and		c.customerid		= b.customer_name
and		c.projectid			= b.project_name
and		c.ComponentName		= b.publication_comp_name

GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_base_process_component_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_req_base_process_component_vw TO PUBLIC
END
GO


