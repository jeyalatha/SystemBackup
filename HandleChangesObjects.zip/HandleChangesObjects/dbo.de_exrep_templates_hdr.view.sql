IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_exrep_templates_hdr' AND TYPE = 'V')
    Begin
        Drop View de_exrep_templates_hdr
    End
Go


create view  [de_exrep_templates_hdr]        
		as              
		select activity_name,component_name,createdby,createddate,customer_name,modifiedby,modifieddate,no_sheets,process_name,project_name,report_caption,template_id,template_name,ui_name from rvw20appdb.dbo.de_exrep_templates_hdr a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_exrep_templates_hdr' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_exrep_templates_hdr TO PUBLIC
END
GO


