IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='ce_ui_ico_vw' AND TYPE = 'V')
    Begin
        Drop View ce_ui_ico_vw
    End
Go


 
	/*	Creating View Script - ce_ui_ico_vw on 	Jun 26 2005 11:46PM		*/	

/************************************************************************************
procedure name and id   	ce_ui_ico_vw
description             
name of the author      
date created            
query file name         	ce_ui_ico_vw.sql
modifications history   
modified by             	
modified date           
modified purpose        
************************************************************************************/
create view [ce_ui_ico_vw]
as
	select	customer_name		'customer_name',
		project_name		'project_name',
		ecr_no	 		'ecr_no',
		ico_no	 		'ico_no',
		process_name		'process_name',
		component_name		'component_name',
		ico_status		'ico_status',
		ico_descr		'ico_descr',
		process_descr		'process_descr',
		component_descr		'component_descr',
		timestamp	 	'timestamp',
		createdby	 	'createdby',
		createddate	 	'createddate',
		modifiedby	 	'modifiedby',
		modifieddate		'modifieddate'

	from	ce_ui_ico (nolock)




GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'ce_ui_ico_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  ce_ui_ico_vw TO PUBLIC
END
GO


