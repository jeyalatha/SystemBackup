IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='details' AND TYPE = 'V')
    Begin
        Drop View details
    End
Go


create view  [details]        
		as              
		select Base_data,keys,Publish_data,Table_name,View_created from rvw20appdb.dbo.details a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'details' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  details TO PUBLIC
END
GO


