IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_publish_focus_control_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_publish_focus_control_vw
    End
Go


/************************************************************************************
procedure name and id   de_fw_des_publish_focus_control_vw
description
name of the author
date created
query file name         de_fw_des_publish_focus_control_vw
modifications history
modified by
modified date
modified purpose
*************************************************************************************/
/* modified by  : Gankan G              */
/* date    : 22-Mar-2013             */
/* BugId   : PLF2.0_03588             */
/* modified for  : Code mofdified to handle focus control at method level  */
/************************************************************************************/
CREATE view [de_fw_des_publish_focus_control_vw]
as

select distinct a.customer_name  'customer_name',
a.project_name  'project_name',
a.process_name  'process_name',
a.ecrno    'ecrno',
a.component_name  'component_name',
a.errorcontext  'errorcontext',
a.errorid    'errorid',
a.controlid   'controlid',
a.segmentname   'segmentname',
a.focusdataitem  'focusdataitem',
b.methodid   'methodid',
b.method_name  'method_name'
from de_fw_des_publish_focus_control a(nolock),
de_fw_des_publish_di_parameter b(nolock)
where a.customer_name  = b.customername
and  a.project_name  = b.projectname
and  a.ecrno    = b.ecrno
and  a.process_name  = b.processname
and  a.component_name = b.componentname
and  a.errorcontext  = b.servicename
and  a.segmentname  = b.segmentname
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_publish_focus_control_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_publish_focus_control_vw TO PUBLIC
END
GO


