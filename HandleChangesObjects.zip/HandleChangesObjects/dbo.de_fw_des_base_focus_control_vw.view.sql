IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_base_focus_control_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_base_focus_control_vw
    End
Go



/************************************************************************************
procedure name and id   de_fw_des_base_focus_control_vw
description             
name of the author      BharathiDasan.V.V
date created            16-07-2007         
query file name         de_fw_des_base_focus_control_vw
modifications history   
modified by             
modified date           
modified purpose        
***********************************************************************************/
Create view [de_fw_des_base_focus_control_vw]
as
select	customer_name		'customer_name',
		project_name		'project_name',
		process_name		'process_name',	
		component_name		'component_name',
		errorcontext		'errorcontext',
		errorid				'errorid',
		controlid			'controlid',
		segmentname			'segmentname',
		focusdataitem		'focusdataitem'
from	de_fw_des_focus_control (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_base_focus_control_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_base_focus_control_vw TO PUBLIC
END
GO


