IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_publish_service_dataitem_bkp04jan2012' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_publish_service_dataitem_bkp04jan2012
    End
Go


create view  [de_fw_des_publish_service_dataitem_bkp04jan2012]        
		as              
		select componentname,createdby,createddate,customername,dataitemname,defaultvalue,ecrno,flowattribute,ispartofkey,mandatoryflag,modifiedby,modifieddate,processname,projectname,segmentname,servicename,timestamp,updtime,upduser from rvw20appdb.dbo.de_fw_des_publish_service_dataitem_bkp04jan2012 a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_publish_service_dataitem_bkp04jan2012' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_publish_service_dataitem_bkp04jan2012 TO PUBLIC
END
GO


