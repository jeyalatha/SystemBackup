IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='dec17' AND TYPE = 'V')
    Begin
        Drop View dec17
    End
Go


create view  [dec17]        
		as              
		select controlname,pagename,sectionname from rvw20appdb.dbo.dec17 a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'dec17' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  dec17 TO PUBLIC
END
GO


