IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_ilbo_action_group' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_ilbo_action_group
    End
Go


create view  [de_fw_des_ilbo_action_group]        
		as              
		select component_name,createdby,createddate,customer_name,groupcode,ilbocode,modifiedby,modifieddate,process_name,project_name,timestamp,updtime,upduser from rvw20appdb.dbo.de_fw_des_ilbo_action_group a (nolock)
GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_ilbo_action_group' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_ilbo_action_group TO PUBLIC
END
GO


