IF EXISTS  (SELECT 'Y' FROM SYSOBJECTS WHERE NAME ='de_fw_des_base_di_placeholder_vw' AND TYPE = 'V')
    Begin
        Drop View de_fw_des_base_di_placeholder_vw
    End
Go



/************************************************************************************    
procedure name and id   de_fw_des_base_di_placeholder_vw
description             
name of the author      BharathiDasan.V.V
date created            16-07-2007               
query file name         de_fw_des_base_di_placeholder_vw
modifications history       
modified by                 
modified date               
modified purpose            
************************************************************************************/  
create view [de_fw_des_base_di_placeholder_vw] 
	  (	componentname ,		customername ,	dataitemname ,	errorid ,		methodid ,		
		placeholdername ,	processname ,	projectname ,	sectionname ,	segmentname ,
		sequenceno ,		servicename ) 
as 
select 	component_name,		customer_name ,	dataitemname ,	errorid ,		methodid ,
		placeholdername ,	process_name ,	project_name ,	sectionname ,	segmentname ,
		sequenceno ,		servicename 
from 	de_fw_des_di_placeholder (nolock)





GO
IF EXISTS(SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'de_fw_des_base_di_placeholder_vw' AND TYPE = 'V')
BEGIN
	GRANT EXEC ON  de_fw_des_base_di_placeholder_vw TO PUBLIC
END
GO


