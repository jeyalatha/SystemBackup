/***********************************************************************************************************
Copyright @2004, RAMCO SYSTEMS,  All rights reserved
Author                   :   Ramco.VwPlf.DeveloperConsole
Application/Module Name  :   activity.cs
Code Generated From      :   ramco\UnitTestProj\TC_ECR_00053\techwarcnv18\inst3\sa\Maint_rvw20appdb\TECHWARCNV18
Revision/Version #       :   
Purpose                  :   Activity Implementation
Modifications            :   
Modifier Name & Date     :   
***********************************************************************************************************/
[assembly: System.Reflection.AssemblyDescriptionAttribute("ramco/UnitTestProj/UnitTestProc/TC_ECR_00053/testcomponent/TECHWARCNV18/1/30/2023" +
    " 4:27:34 PM/F589C7EE-BCD9-48FF-B7E5-5733208F114D")]
[assembly: System.Reflection.AssemblyTitleAttribute("ramco/UnitTestProj/UnitTestProc/TC_ECR_00053/testcomponent/TECHWARCNV18/1/30/2023" +
    " 4:27:34 PM/F589C7EE-BCD9-48FF-B7E5-5733208F114D")]

namespace listviewact
{
    using System;
    using System.Web;
    using System.Collections;
    using System.Collections.Generic;
    using System.Diagnostics;
    using Ramco.VW.RT.Web.Core;

    // <summary>
    // This class defines all the methods of Activity class
    // </summary>
    [Serializable()]
    public class activity : CActivity
    {
        private Dictionary<string, Object> htContextItems = new Dictionary<string, Object>();
        private listviewui m_olistviewui = null;
        private Dictionary<long, listviewui> m_olistviewui_Cyclic = new Dictionary<long, listviewui>();
        public activity()
        {
            ComponentName = "testcomponent";
            ActivityName = "listviewact";
        }
        // <summary>
        // This method Creates/Gets the Object Handle of the ILBO
        // </summary>
        // **************************************************************************
        // Function Name		:	GetILBO
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Creates/Gets the Object Handle of the ILBO
        // ***************************************************************************
        public override IILBO GetILBO(string sILBOCode)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "GetILBO(sILBOCode = \"" + sILBOCode + "\")", "ACT0001");
                switch (sILBOCode)
                {
                    case "listviewui":
                        if ((m_olistviewui == null))
                        {
                            m_olistviewui = new listviewui();
                        }
                        return m_olistviewui;
                    default:
                        return base.GetILBO(sILBOCode);
                }//ENDSWITCH
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(string.Format("activity : GetILBO(sILBOCode=\"{0}\")", sILBOCode), "Act0001", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Disposes the Object Handle of the ILBO
        // </summary>
        // **************************************************************************
        // Function Name		:	DisposeILBO
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Disposes the Object Handle of the ILBO
        // ***************************************************************************
        public override void DisposeILBO(string sILBOCode)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "DisposeILBO(sILBOCode = \"" + sILBOCode + "\")", "ACT0002");
                switch (sILBOCode)
                {
                    case "listviewui":
                        if ((m_olistviewui != null))
                        {
                            m_olistviewui = null;
                        }
                        break;
                    default:
                        base.DisposeILBO(sILBOCode);
                        break;
                }//ENDSWITCH
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(string.Format("activity : DisposeILBO(sILBOCode=\"{0}\")", sILBOCode), "Act0002", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Creates/Gets the Object Handle of the ILBO
        // </summary>
        // **************************************************************************
        // Function Name		:	GetILBOEx
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Creates/Gets the Object Handle of the ILBO
        // ***************************************************************************
        public override IILBO GetILBOEx(string sILBOCode, long lILBOIndex)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "GetILBOEx(sILBOCode = \"" + sILBOCode + "\", lILBOIndex = \"" + lILBOIndex + "\")", "ACT0003");
                switch (sILBOCode)
                {
                    case "listviewui":
                        if ((m_olistviewui_Cyclic.ContainsKey((lILBOIndex - 1)) != true))
                        {
                            m_olistviewui_Cyclic.Add((lILBOIndex - 1), new listviewui());
                        }
                        return m_olistviewui_Cyclic[(lILBOIndex - 1)];
                    default:
                        return base.GetILBOEx(sILBOCode, lILBOIndex);
                }//ENDSWITCH
            }
            catch (System.Exception e)
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceError, "GetILBOEx(sILBOCode = \"" + sILBOCode + "\", lILBOIndex = \"" + lILBOIndex + "\")", "ACT0003 - Exception - e.Message");
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Disposes the Object Handle of the ILBO
        // </summary>
        // **************************************************************************
        // Function Name		:	DisposeILBOEx
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Disposes the Object Handle of the ILBO
        // ***************************************************************************
        public override void DisposeILBOEx(string sILBOCode, long lILBOIndex)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "DisposeILBOEx(sILBOCode = \"" + sILBOCode + "\", lILBOIndex = \"" + lILBOIndex + "\")", "ACT0004");
                switch (sILBOCode)
                {
                    case "listviewui":
                        if ((lILBOIndex > 0))
                        {
                            m_olistviewui_Cyclic.Remove((lILBOIndex - 1));
                        }
                        else
                        {
                            m_olistviewui_Cyclic.Clear();
                        }
                        break;
                    default:
                        base.DisposeILBOEx(sILBOCode, lILBOIndex);
                        break;
                }//ENDSWITCH
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(string.Format("activity : DisposeILBOEx(sILBOCode=\"{0}\")", sILBOCode), "Act0002", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Gets the Context Value Information
        // </summary>
        // **************************************************************************
        // Function Name		:	GetContextValue
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Gets the Context Value Information
        // ***************************************************************************
        public override object GetContextValue(string sContextName)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "GetContextValue(sContextName = \"" + sContextName + "\")", "ACT0005");
                return this.htContextItems[sContextName];
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(string.Format("activity : GetContextValue(sContextName=\"{0}\")", sContextName), "Act0003", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Sets the Context Value Information
        // </summary>
        // **************************************************************************
        // Function Name		:	SetContextValue
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Sets the Context Value Information
        // ***************************************************************************
        public override void SetContextValue(string sContextName, object sContextValue)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "SetContextValue(sContextName = \"" + sContextName + "\", sContextValue = \"" + sContextValue + "\")", "ACT0006");
                htContextItems[sContextName] = sContextValue;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(string.Format("activity : SetContextValue(sContextName=\"{0}\",sContextValue=\"{1}\")", sContextName, sContextValue), "Act0004", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Fills the Message object when an error occurs
        // </summary>
        // **************************************************************************
        // Function Name		:	FillMessageObject
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Fills the Message object when an error occurs
        // ***************************************************************************
        private void FillMessageObject(string sMethod, string sErrNumber, string sErrMessage)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "FillMessageObject(sMethod = \"" + sMethod + "\", sErrNumber = \"" + sErrNumber + "\", sErrMessage = \"" + sErrMessage + "\")", "");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IMessage Imsg = ISManager.GetMessageObject();
                Imsg.AddMessage(sErrNumber, sErrMessage, sMethod, string.Empty, "5");
            }
            catch (System.Exception e)
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceError, "FillMessageObject(sMethod = \"" + sMethod + "\", sErrNumber = \"" + sErrNumber + "\", sErrMessage = \"" + sErrMessage + "\")", " - Exception - e.Message");
                throw new Exception(e.Message, e);
            }
        }
    }
}

