/***********************************************************************************************************
Copyright @2004, RAMCO SYSTEMS,  All rights reserved
Author                   :   Ramco.VwPlf.DeveloperConsole
Application/Module Name  :   listviewui.cs
Code Generated From      :   ramco\UnitTestProj\TC_ECR_00053\techwarcnv18\inst3\sa\Maint_rvw20appdb\TECHWARCNV18
Revision/Version #       :   
Purpose                  :   Activity Implementation
Modifications            :   
Modifier Name & Date     :   
***********************************************************************************************************/
namespace listviewact
{
    using System;
    using System.Web;
    using System.Xml;
    using System.Collections;
    using System.Collections.Generic;
    using System.Diagnostics;
    using Ramco.VW.RT.Web.Core;
    using Ramco.VW.RT.Web.Controls;
    using Ramco.VW.RT.Web.Core.Controls.LayoutControls;
    using Ramco.VW.RT.AsyncResult;
    using Ramco.VW.RT.State;
    using Plf.Ui.Ramco.Utility;
    using System.Reflection;

    // <summary>
    // This class defines all the methods of listviewui class
    // </summary>
    [Serializable()]
    internal sealed class listviewui : CILBO
    {
        private Dictionary<String, Object> htContextItems = new Dictionary<String, Object>();
        private Edit m_conhdndefhdn1 = new Edit();
        private Edit m_conhdndefhdn2 = new Edit();
        private Edit m_conhdndefhdn3 = new Edit();
        private Edit m_conhdndefhdn4 = new Edit();
        private Edit m_conhdndefhdn5 = new Edit();
        private Edit m_conhdndefhdn6 = new Edit();
        private Edit m_conhdndefhdn7 = new Edit();
        private Edit m_conhdndefhdn8 = new Edit();
        private Edit m_conhdnprj_hdn_ctrl = new Edit();
        private Edit m_conhdntesthdncntrl = new Edit();
        private Edit m_conhdntesthdnctrl1 = new Edit();
        private ListView m_conlvwemployeenamelistview = new ListView();
        private ListView m_conlvwemployeenolistview = new ListView();
        private Multiline m_conmlgriddetails = new Multiline();
        private Edit m_contxtemployeename = new Edit();
        private Edit m_contxtemployeeno = new Edit();
        private Button _btnsave = new Button();
        private Section _buttonsection = new Section();
        private Section _gridsection = new Section();
        private Section _headersection = new Section();
        private Section _prjhdnsection = new Section();
        private Tab _mainpage = new Tab();
        private Edit m_conrvwrt_cctxt_component = new Edit();
        private Edit m_conrvwrt_cctxt_ou = new Edit();
        private Edit m_conrvwrt_lctxt_ou = new Edit();
        // <summary>
        // This method Calls the AddViewInfo and InitializeControls
        // </summary>
        // **************************************************************************
        // Function Name		:	listviewui
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Calls the AddViewInfo and InitializeControls
        // ***************************************************************************
        public listviewui()
        {
            IsPreProcess3 = true;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "listviewui()", "listviewui");
                this.SetContextValue("ICT_COMPONENTNAME", "testcomponent");
                this.SetContextValue("ICT_COMPONENTDESCRIPTION", "TestComponent");
                this.SetContextValue("ICT_ACTIVITYNAME", "listviewact");
                this.SetContextValue("ICT_ACTIVITYDESCRIPTION", "ListViewAct");
                this.SetContextValue("ICT_ILBOCODE", "listviewui");
                this.SetContextValue("ICT_ILBODESCRIPTION", "ListViewUI");
                base.LoadILBODefinition("testcomponent", "listviewact", "listviewui");
                this.InitializeTabControls();
                this.InitializeLayoutControls();
                this.AddViewInfo();
                this.InitializeControls();
            }
            catch (System.Exception e)
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceError, "listviewui()", "listviewui");
                throw new System.Exception(e.Message, e);
            }
        }
        public void Clear()
        {
        }
        // <summary>
        // This method Initializes the controls of Enumerated datatype.
        // </summary>
        // **************************************************************************
        // Function Name		:	InitializeControls
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Initializes the controls of Enumerated datatype.
        // ***************************************************************************
        private new void InitializeControls()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "InitializeControls()", "listviewui");
                m_conhdndefhdn1.SetIdentity("hdndefhdn1", ControlType.RSEdit);
                _mainpage.AddControl("hdndefhdn1");
                m_conhdndefhdn2.SetIdentity("hdndefhdn2", ControlType.RSEdit);
                _mainpage.AddControl("hdndefhdn2");
                m_conhdndefhdn3.SetIdentity("hdndefhdn3", ControlType.RSEdit);
                _mainpage.AddControl("hdndefhdn3");
                m_conhdndefhdn4.SetIdentity("hdndefhdn4", ControlType.RSEdit);
                _mainpage.AddControl("hdndefhdn4");
                m_conhdndefhdn5.SetIdentity("hdndefhdn5", ControlType.RSEdit);
                _mainpage.AddControl("hdndefhdn5");
                m_conhdndefhdn6.SetIdentity("hdndefhdn6", ControlType.RSEdit);
                _mainpage.AddControl("hdndefhdn6");
                m_conhdndefhdn7.SetIdentity("hdndefhdn7", ControlType.RSEdit);
                _mainpage.AddControl("hdndefhdn7");
                m_conhdndefhdn8.SetIdentity("hdndefhdn8", ControlType.RSEdit);
                _mainpage.AddControl("hdndefhdn8");
                m_conhdnprj_hdn_ctrl.SetIdentity("hdnprj_hdn_ctrl", ControlType.RSEdit);
                _mainpage.AddControl("hdnprj_hdn_ctrl");
                m_conhdntesthdncntrl.SetIdentity("hdntesthdncntrl", ControlType.RSEdit);
                _mainpage.AddControl("hdntesthdncntrl");
                m_conhdntesthdnctrl1.SetIdentity("hdntesthdnctrl1", ControlType.RSEdit);
                _mainpage.AddControl("hdntesthdnctrl1");
                m_conlvwemployeenamelistview.SetIdentity("lvwemployeenamelistview", ControlType.RSListView);
                _mainpage.AddControl("lvwemployeenamelistview");
                m_conlvwemployeenolistview.SetIdentity("lvwemployeenolistview", ControlType.RSListView);
                _mainpage.AddControl("lvwemployeenolistview");
                m_conmlgriddetails.SetIdentity("mlgriddetails", ControlType.RSGrid);
                _mainpage.AddControl("mlgriddetails");
                m_contxtemployeename.SetIdentity("txtemployeename", ControlType.RSEdit);
                _mainpage.AddControl("txtemployeename");
                m_contxtemployeeno.SetIdentity("txtemployeeno", ControlType.RSEdit);
                _mainpage.AddControl("txtemployeeno");
                if (iEDKEIExists)
                {
                    base.InitializeControls();
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("listviewui : InitializeControls()", "ILBO0001", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Resets all the controls of the ILBO
        // </summary>
        // **************************************************************************
        // Function Name		:	ResetControls
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Resets all the controls of the ILBO
        // ***************************************************************************
        public override void ResetControls()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "ResetControls()", "listviewui");
                m_conhdndefhdn1.ClearAll();
                m_conhdndefhdn2.ClearAll();
                m_conhdndefhdn3.ClearAll();
                m_conhdndefhdn4.ClearAll();
                m_conhdndefhdn5.ClearAll();
                m_conhdndefhdn6.ClearAll();
                m_conhdndefhdn7.ClearAll();
                m_conhdndefhdn8.ClearAll();
                m_conhdnprj_hdn_ctrl.ClearAll();
                m_conhdntesthdncntrl.ClearAll();
                m_conhdntesthdnctrl1.ClearAll();
                m_conlvwemployeenamelistview.ClearAll();
                m_conlvwemployeenolistview.ClearAll();
                m_conmlgriddetails.ClearAll();
                m_contxtemployeename.ClearAll();
                m_contxtemployeeno.ClearAll();
                this.ResetLayoutControls();
                this.ResetTabControls();
                if (iEDKEIExists)
                {
                    base.ResetControls();
                }
                this.InitializeControls();
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("listviewui : ResetControls()", "ILBO0002", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method adds view information to the controls.
        // </summary>
        // **************************************************************************
        // Function Name		:	AddViewInfo
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	adds view information to the controls.
        // ***************************************************************************
        private new void AddViewInfo()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "AddViewInfo()", "listviewui");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IContext ISMContext = ISManager.GetContextObject();
                m_conhdndefhdn1.AddView("hdndefhdn1", true, "char", String.Empty, String.Empty);
                m_conhdndefhdn2.AddView("hdndefhdn2", true, "char", String.Empty, String.Empty);
                m_conhdndefhdn3.AddView("hdndefhdn3", true, "char", String.Empty, String.Empty);
                m_conhdndefhdn4.AddView("hdndefhdn4", true, "char", String.Empty, String.Empty);
                m_conhdndefhdn5.AddView("hdndefhdn5", true, "char", String.Empty, String.Empty);
                m_conhdndefhdn6.AddView("hdndefhdn6", true, "char", String.Empty, String.Empty);
                m_conhdndefhdn7.AddView("hdndefhdn7", true, "char", String.Empty, String.Empty);
                m_conhdndefhdn8.AddView("hdndefhdn8", true, "char", String.Empty, String.Empty);
                m_conhdnprj_hdn_ctrl.AddView("hdnprj_hdn_ctrl", true, "char", String.Empty, String.Empty);
                m_conhdntesthdncntrl.AddView("hdntesthdncntrl", true, "char", String.Empty, String.Empty);
                m_conhdntesthdnctrl1.AddView("hdntesthdnctrl1", true, "char", String.Empty, String.Empty);
                m_conlvwemployeenamelistview.AddView("1", true, "char", String.Empty, String.Empty);
                m_conlvwemployeenamelistview.AddView("1", true, "char", String.Empty, String.Empty);
                m_conlvwemployeenamelistview.AddView("2", true, "char", String.Empty, String.Empty);
                m_conlvwemployeenamelistview.AddView("3", true, "char", String.Empty, String.Empty);
                m_conlvwemployeenolistview.AddView("1", true, "char", String.Empty, String.Empty);
                m_conlvwemployeenolistview.AddView("1", true, "char", String.Empty, String.Empty);
                m_conmlgriddetails.SetPageRowCount((12 * 3));
                m_conmlgriddetails.SetVisibleRowCount(12);
                m_conmlgriddetails.AddView("1", true, "char", String.Empty, String.Empty);
                m_conmlgriddetails.SetColumnProperties("1", "editbox", String.Empty);
                m_conmlgriddetails.AddView("2", true, "char", String.Empty, String.Empty);
                m_conmlgriddetails.SetColumnProperties("2", "editbox", String.Empty);
                m_contxtemployeename.AddView("txtemployeename", true, "char", String.Empty, String.Empty);
                m_contxtemployeeno.AddView("txtemployeeno", true, "char", String.Empty, String.Empty);
                m_conrvwrt_lctxt_ou.AddView("rvwrt_lctxt_ou", false, "char", String.Empty, String.Empty);
                m_conrvwrt_cctxt_ou.AddView("rvwrt_cctxt_ou", false, "char", String.Empty, String.Empty);
                m_conrvwrt_cctxt_component.AddView("rvwrt_cctxt_component", false, "char", String.Empty, String.Empty);
                if (iEDKEIExists)
                {
                    base.AddViewInfo();
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("listviewui : AddViewInfo()", "ILBO0003", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method creates/gets the Object Handle of the Control
        // </summary>
        // **************************************************************************
        // Function Name		:	GetControlX
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	creates/gets the Object Handle of the Control
        // ***************************************************************************
        public override IControl GetControlX(string sControlID)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetControlX(sControlID = \"{0}\")", sControlID), "listviewui");
                switch (sControlID.ToLower())
                {
                    case "hdndefhdn1":
                        return this.m_conhdndefhdn1;
                    case "hdndefhdn2":
                        return this.m_conhdndefhdn2;
                    case "hdndefhdn3":
                        return this.m_conhdndefhdn3;
                    case "hdndefhdn4":
                        return this.m_conhdndefhdn4;
                    case "hdndefhdn5":
                        return this.m_conhdndefhdn5;
                    case "hdndefhdn6":
                        return this.m_conhdndefhdn6;
                    case "hdndefhdn7":
                        return this.m_conhdndefhdn7;
                    case "hdndefhdn8":
                        return this.m_conhdndefhdn8;
                    case "hdnprj_hdn_ctrl":
                        return this.m_conhdnprj_hdn_ctrl;
                    case "hdntesthdncntrl":
                        return this.m_conhdntesthdncntrl;
                    case "hdntesthdnctrl1":
                        return this.m_conhdntesthdnctrl1;
                    case "lvwemployeenamelistview":
                        return this.m_conlvwemployeenamelistview;
                    case "lvwemployeenolistview":
                        return this.m_conlvwemployeenolistview;
                    case "mlgriddetails":
                        return this.m_conmlgriddetails;
                    case "txtemployeename":
                        return this.m_contxtemployeename;
                    case "txtemployeeno":
                        return this.m_contxtemployeeno;
                    case "rvwrt_cctxt_component":
                        return this.m_conrvwrt_cctxt_component;
                    case "rvwrt_cctxt_ou":
                        return this.m_conrvwrt_cctxt_ou;
                    case "rvwrt_lctxt_ou":
                        return this.m_conrvwrt_lctxt_ou;
                    default:
                        if (iEDKEIExists)
                        {
                            return base.GetControlX(sControlID);
                        }
                        else
                        {
                            return null;
                        }
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("listviewui : GetControlX(sControlID = \"{0}\")", sControlID), "ILBO0004", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Gets the Context Value
        // </summary>
        // **************************************************************************
        // Function Name		:	GetControl
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Gets the Context Value
        // ***************************************************************************
        public override IControl GetControl(string sControlID)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetControl(sControlID = \"{0}\")", sControlID), "listviewui");
                IControl control = this.GetControlX(sControlID);
                if ((control != null))
                {
                    return control;
                }
                else
                {
                    throw new Exception("String.Format(\"Invalid ControlID - {0}\", sControlID)");
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("listviewui : GetControl(sControlID = \"{0}\")", sControlID), "ILBO0005", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method gets the dataItem
        // </summary>
        // **************************************************************************
        // Function Name		:	GetDataItem
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	gets the dataItem
        // ***************************************************************************
        public override string GetDataItem(string sLinkID, string sDataItemName, long nInstance)
        {
            string sRetData = String.Empty;
            bool bFlag = false;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetDataItem(sLinkID = \"{0}\", sDataItemName = \"{1}\", nInstance = \"{2}\")", sLinkID, sDataItemName, nInstance.ToString()), "listviewui");
                if ((iEDKEIExists && !bFlag))
                {
                    return base.GetDataItem(sLinkID, sDataItemName, nInstance);
                }
                else
                {
                    return sRetData;
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("listviewui : GetDataItem(sLinkID = \"{0}\", sDataItemName = \"{1}\"), nInstance = \"{2}\")", sLinkID, sDataItemName, nInstance.ToString()), "ILBO0006", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method gets the dataItem Instances.
        // </summary>
        // **************************************************************************
        // Function Name		:	GetDataItemInstances
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	gets the dataItem Instances.
        // ***************************************************************************
        public override long GetDataItemInstances(string sLinkID, string sDataItemName)
        {
            long sRetData = 0;
            bool bFlag = false;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetDataItemInstances(sLinkID = \"{0}\", sDataItemName = \"{1}\")", sLinkID, sDataItemName), "listviewui");
                if ((iEDKEIExists && !bFlag))
                {
                    return base.GetDataItemInstances(sLinkID, sDataItemName);
                }
                else
                {
                    return sRetData;
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("listviewui : GetDataItemInstances(sLinkID = \"{0}\", sDataItemName = \"{1}\")", sLinkID, sDataItemName), "ILBO0007", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method sets the DataItem
        // </summary>
        // **************************************************************************
        // Function Name		:	SetDataItem
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	sets the DataItem
        // ***************************************************************************
        public override void SetDataItem(string sLinkID, string sDataItemName, long nInstance, string sValue)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("SetDataItem(sLinkID = \"{0}\", sDataItemName = \"{1}\",nInstance = \"{2}\", sValue = \"{3}\")", sLinkID, sDataItemName, nInstance, sValue), "listviewui");
                bool bFlag = false;
                switch (sLinkID)
                {
                    case "ezeeview":
                        return;
                    default:
                        break;
                }
                if ((iEDKEIExists && !bFlag))
                {
                    base.SetDataItem(sLinkID, sDataItemName, nInstance, sValue);
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("listviewui : SetDataItem(sLinkID = \"{0}\", sDataItemName = \"{1}\", nInstance = \"{2}\", sValue = \"{3}\")", sLinkID, sDataItemName, nInstance.ToString(), sValue.ToString()), "ILBO0008", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Gets the GlobalVariable handle
        // </summary>
        // **************************************************************************
        // Function Name		:	GetVariable
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Gets the GlobalVariable handle
        // ***************************************************************************
        public override IGlobalVariable GetVariable(string sVariable)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetVariable(sVariable = \"{0}\")", sVariable), "listviewui");
                if (iEDKEIExists)
                {
                    return base.GetVariable(sVariable);
                }
                else
                {
                    return null;
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("listviewui : GetVariable(sVariable = \"{0}\")", sVariable), "ILBO0009", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Executes User defined tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	PerformTask
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Executes User defined tasks
        // ***************************************************************************
        public override bool PerformTask(string sControlID, string sEventName, string sEventDetails, out string sTargetURL)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("PerformTask(sControlID = \"{0}\", sEventName = \"{1}\", sEventDetails = \"{2}\")", sControlID, sEventName, sEventDetails), "listviewui");
                long lSubscriptionID = 0;
                bool bServiceResult = false;
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IDataBroker IDBroker = ISManager.GetDataBroker();
                IScreenObjectLauncher IHandler = ISManager.GetScreenObjectLauncher();
                IMessage IMsg = ISManager.GetMessageObject();
                IContext ISMContext = ISManager.GetContextObject();
                IReportManager IRptManager = ISManager.GetReportManager();
                sTargetURL = string.Empty;
                switch (sEventName.ToLower())
                {
                    case "tcmains5save1tr":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "TRANS");
                        bServiceResult = this.ExecuteService("tcmnscnsrsave");
                        if ((bServiceResult == false))
                        {
                            return false;
                        }
                        else
                        {
                            return true;
                        }
                    default:
                        if (iEDKEIExists)
                        {
                            return base.PerformTask(sControlID, sEventName, sEventDetails, out sTargetURL);
                        }
                        break;
                }
                return true;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("listviewui : PerformTask(sControlID = \"{0}\", sEventName = \"{1}\", sEventDetails = \"{2}\")", sControlID, sEventName, sEventDetails), "ILBO0010", e.Message);
                throw new Exception(e.Message, e);
                return false;
            }
        }
        // <summary>
        // This method Executes User defined tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	BeginPerformTask
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Executes User defined tasks
        // ***************************************************************************
        public override IAsyncResult BeginPerformTask(AsyncCallback cb, VWRequestState reqState)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("BeginPerformTask(sControlID = \"{0}\", sEventName = \"{1}\", sEventDetails = \"{2}\")", reqState.Control, reqState.EventName, reqState.EventDetails), "listviewui");
                long lSubscriptionID = 0;
                bool bServiceResult = false;
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IDataBroker IDBroker = ISManager.GetDataBroker();
                IScreenObjectLauncher IHandler = ISManager.GetScreenObjectLauncher();
                IMessage IMsg = ISManager.GetMessageObject();
                IContext ISMContext = ISManager.GetContextObject();
                IReportManager IRptManager = ISManager.GetReportManager();
                bool bExecFlag = base.PreTaskExecution(reqState);
                if ((bExecFlag == false))
                {
                    return ISManager.SetAsyncException(null);
                }
                switch (reqState.TaskName.ToLower())
                {
                    case "tcmains5save1tr":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "TRANS");
                        reqState.ServiceName = "tcmnscnsrsave";
                        reqState.TransactionScope = 0;
                        return this.BeginExecuteService(cb, reqState);
                    default:
                        if (iEDKEIExists)
                        {
                            return base.BeginPerformTask(cb, reqState);
                        }
                        break;
                }
                return ISManager.SetAsyncCompleted(new VWResponseState());
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("listviewui : BeginPerformTask(sControlID = \"{0}\", sEventName = \"{1}\", sEventDetails = \"{2}\")", reqState.Control, reqState.EventName, reqState.EventDetails), "ILBO0011", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Executes User defined tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	EndPerformTask
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Executes User defined tasks
        // ***************************************************************************
        public override bool EndPerformTask(IAsyncResult ar)
        {
            VWAsyncResult result = ar as VWAsyncResult;
            VWRequestState reqState = result.AsyncState as VWRequestState;
            VWResponseState resState = result.ResponseState;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("EndPerformTask(sControlID = \"{0}\", sEventName = \"{1}\", sEventDetails = \"{2}\")", reqState.Control, reqState.EventName, reqState.EventDetails), "listviewui");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IDataBroker IDBroker = ISManager.GetDataBroker();
                IScreenObjectLauncher IHandler = ISManager.GetScreenObjectLauncher();
                IMessage IMsg = ISManager.GetMessageObject();
                IContext ISMContext = ISManager.GetContextObject();
                IReportManager IRptManager = ISManager.GetReportManager();
                long lSubscriptionID = 0;
                bool bServiceResult = true;
                string sTargetURL = string.Empty;
                switch (reqState.TaskName.ToLower())
                {
                    case "tcmains5save1tr":
                        bServiceResult = this.EndExecuteService(ar);
                        break;
                    default:
                        if (iEDKEIExists)
                        {
                            return base.EndPerformTask(ar);
                        }
                        break;
                }
                if (bServiceResult)
                {
                    bServiceResult = base.PostTaskExecution(reqState.TaskName);
                }
                return bServiceResult;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("listviewui : EndPerformTask(sControlID = \"{0}\", sEventName = \"{1}\", sEventDetails = \"{2}\")", reqState.Control, reqState.EventName, reqState.EventDetails), "ILBO0012", e.Message);
                throw new Exception(e.Message, e);
                return false;
            }
        }
        // <summary>
        // This method initializes Scripts for Data Transfer
        // </summary>
        // **************************************************************************
        // Function Name		:	PreProcess1
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	initializes Scripts for Data Transfer
        // ***************************************************************************
        public override bool PreProcess1()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "PreProcess1", "listviewui");
                if (iEDKEIExists)
                {
                    return base.PreProcess1();
                }
                else
                {
                    return true;
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("listviewui : PreProcess1()", "ILBO0013", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initiates Init tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	PreProcess2
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Initiates Init tasks
        // ***************************************************************************
        public override bool PreProcess2()
        {
            bool bReturn = false;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "PreProcess2", "listviewui");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IDataBroker IDBroker = ISManager.GetDataBroker();
                // No Initialization Tasks are defined for the ILBO.
                if (iEDKEIExists)
                {
                    bReturn = base.PreProcess2();
                    return bReturn;
                }
                return true;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("listviewui : PreProcess2()", "ILBO0014 ", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initiates Init tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	BeginPreProcess2
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Initiates Init tasks
        // ***************************************************************************
        public override IAsyncResult BeginPreProcess2(AsyncCallback cb, VWRequestState reqState)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "BeginPreProcess2()", "listviewui");
                // No Initialize Tasks are defined for the ILBO.
                if (iEDKEIExists)
                {
                    return base.BeginPreProcess2(cb, reqState);
                }
                throw new Exception("No Initialization Tasks are defined for the ILBO.");
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("listviewui : BeginPreProcess2()", "ILBO0015", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initiates Init tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	EndPreProcess2
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Initiates Init tasks
        // ***************************************************************************
        public override bool EndPreProcess2(IAsyncResult ar)
        {
            bool bReturn = false;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "EndPreProcess2()", "listviewui");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IDataBroker IDBroker = ISManager.GetDataBroker();
                if (iEDKEIExists)
                {
                    bReturn = base.EndPreProcess2(ar);
                    return bReturn;
                }
                return true;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("listviewui : EndPreProcess2()", "ILBO0016", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initiates Fetch tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	PreProcess3
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Initiates Fetch tasks
        // ***************************************************************************
        public override bool PreProcess3()
        {
            bool bReturn = false;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "PreProcess3()", "listviewui");
                bReturn = this.ExecuteService("tcmnscnsrfet");
                if ((bReturn && iEDKEIExists))
                {
                    bReturn = base.PreProcess3();
                }
                return bReturn;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("listviewui : PreProcess3()", "ILBO0017", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initiates Fetch tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	BeginPreProcess3
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Initiates Fetch tasks
        // ***************************************************************************
        public override IAsyncResult BeginPreProcess3(AsyncCallback cb, VWRequestState reqState)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "BeginPreProcess3()", "listviewui");
                reqState.ServiceName = "tcmnscnsrfet";
                reqState.TransactionScope = 0;
                return this.BeginExecuteService(cb, reqState);
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("listviewui : BeginPreProcess3()", "ILBO0018", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initiates Fetch tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	EndPreProcess3
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Initiates Fetch tasks
        // ***************************************************************************
        public override bool EndPreProcess3(IAsyncResult ar)
        {
            bool bReturn = false;
            object[] upeControlDetails;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "EndPreProcess3()", "listviewui");
                bReturn = this.EndExecuteService(ar);
                return bReturn;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("listviewui : EndPreProcess3()", "ILBO0019", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Gets the Context Value
        // </summary>
        // **************************************************************************
        // Function Name		:	GetContextValue
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Gets the Context Value
        // ***************************************************************************
        public override object GetContextValue(string sContextName)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetContextValue(sContextName = \"{0}\")", sContextName), "listviewui");
                if ((((sContextName != "ICT_PARENTOU")
                            && (sContextName != "ICT_PARENTCOMPONENT"))
                            && (sContextName != "ICT_LAUNCHINGOU")))
                {
                    if (htContextItems.ContainsKey(sContextName))
                    {
                        return htContextItems[sContextName];
                    }
                    else
                    {
                        return null;
                    }
                }
                if ((sContextName == "ICT_PARENTCOMPONENT"))
                {
                    return m_conrvwrt_cctxt_component.GetControlValue("rvwrt_cctxt_component");
                }
                if ((sContextName == "ICT_PARENTOU"))
                {
                    return m_conrvwrt_cctxt_ou.GetControlValue("rvwrt_cctxt_ou");
                }
                if ((sContextName == "ICT_LAUNCHINGOU"))
                {
                    return m_conrvwrt_lctxt_ou.GetControlValue("rvwrt_lctxt_ou");
                }
                return null;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("listviewui : GetContextValue(sContextName = \"{0}\")", sContextName), "ILBO0020", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Adds/Sets the Context Value to the collection based on the contextname
        // </summary>
        // **************************************************************************
        // Function Name		:	SetContextValue
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Adds/Sets the Context Value to the collection based on the contextname
        // ***************************************************************************
        public override void SetContextValue(string sContextName, object sContextValue)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("SetContextValue(sContextName = \"{0}\", sContextValue = \"{1}\")", sContextName, sContextValue), "listviewui");
                if ((((sContextName != "ICT_PARENTOU")
                            && (sContextName != "ICT_PARENTCOMPONENT"))
                            && (sContextName != "ICT_LAUNCHINGOU")))
                {
                    htContextItems[sContextName] = sContextValue;
                }
                if ((sContextName == "ICT_PARENTCOMPONENT"))
                {
                    m_conrvwrt_cctxt_component.SetControlValue("rvwrt_cctxt_component", (string)sContextValue);
                    return;
                }
                if ((sContextName == "ICT_PARENTOU"))
                {
                    m_conrvwrt_cctxt_ou.SetControlValue("rvwrt_cctxt_ou", (string)sContextValue);
                    return;
                }
                if ((sContextName == "ICT_LAUNCHINGOU"))
                {
                    m_conrvwrt_lctxt_ou.SetControlValue("rvwrt_lctxt_ou", (string)sContextValue);
                    return;
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("listviewui : SetContextValue(sContextName = \"{0}\", sContextValue = \"{1}\")", sContextName, sContextValue), "ILBO0021", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Gets the Task specific data
        // </summary>
        // **************************************************************************
        // Function Name		:	GetTaskData
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Gets the Task specific data
        // ***************************************************************************
        public override void GetTaskData(string sTabName, string sTaskName, System.Xml.XmlNode nodeScreenInfo)
        {
            string sOutMTD = string.Empty;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetTaskData(sTabName = \"{0}\", sTaskName = \"{1}\", nodeScreenInfo = \"{2}\")", sTabName, sTaskName, nodeScreenInfo.OuterXml), "listviewui");
                if ((string.CompareOrdinal(GetContextValue("ICT_INLINE_TAB") as String, "1") == 0))
                {
                    ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                    IContext ISMContext = ISManager.GetContextObject();
                    IServiceExecutor ISExecutor = ISManager.GetServiceExecutor();
                    System.Xml.XmlDocument xmlDom = nodeScreenInfo.OwnerDocument;
                    System.Xml.XmlElement eltContextName;
                    System.Xml.XmlElement eltIlboInfo = null;
                    System.Xml.XmlElement eltDTabs = null;
                    System.Xml.XmlElement eltControlInfo = base.GetControlInfoElement(xmlDom, nodeScreenInfo);
                    System.Xml.XmlElement eltLayoutControlInfo = base.GetLayoutControlInfoElement(xmlDom, nodeScreenInfo);
                    if ((xmlDom.SelectSingleNode("trpi/scri/ii") == null))
                    {
                        eltIlboInfo = xmlDom.CreateElement("ii");
                        nodeScreenInfo.AppendChild(eltIlboInfo);
                    }
                    else
                    {
                        eltIlboInfo = xmlDom.SelectSingleNode("trpi/scri/ii") as XmlElement;
                    }
                    switch (sTaskName.ToLower())
                    {
                        case "tcmains5save1tr":
                            m_conhdndefhdn1.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conhdndefhdn2.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conhdndefhdn3.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conhdndefhdn4.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conhdndefhdn5.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conhdndefhdn6.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conhdndefhdn7.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conhdndefhdn8.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conhdnprj_hdn_ctrl.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conhdntesthdncntrl.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conhdntesthdnctrl1.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtemployeename.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtemployeeno.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conmlgriddetails.RenderAsXML(RenderType.renderComplete, eltControlInfo);
                            break;
                    }
                    base.GetTaskData(sTabName, sTaskName, nodeScreenInfo);
                }
                else
                {
                    this.ObsoleteGetTaskData(sTabName, sTaskName, nodeScreenInfo);
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("listviewui : GetTaskData(sTabName = \"{0}\", sTaskName = \"{1}\", nodeScreenInfo = \"{2}\")", sTabName, sTaskName, nodeScreenInfo.OuterXml), "ILBO0022", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Add DirtyTab
        // </summary>
        // **************************************************************************
        // Function Name		:	AddDirtyTab
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Add DirtyTab
        // ***************************************************************************
        private void AddDirtyTab(XmlDocument xmlDom, XmlElement eltDTabs, string sTabName)
        {
            Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("AddDirtyTab(sTabName = \"{0}\")", sTabName), "listviewui");
            System.Xml.XmlElement eltIlboInfo = xmlDom.SelectSingleNode("trpi/scri/ii") as XmlElement;
            eltDTabs = xmlDom.SelectSingleNode("//dtabs") as XmlElement;
            if ((eltDTabs == null))
            {
                eltDTabs = xmlDom.CreateElement("dtabs");
                eltIlboInfo.AppendChild(eltDTabs);
            }
            System.Xml.XmlElement eltDTab = xmlDom.SelectSingleNode("//dtabs/t[@n='" + sTabName + "']") as XmlElement;
            if ((eltDTab == null))
            {
                eltDTab = xmlDom.CreateElement("t");
                eltDTab.SetAttribute("n", sTabName);
                eltDTabs.AppendChild(eltDTab);
            }
        }
        // <summary>
        // This method Gets the Task specific data
        // </summary>
        // **************************************************************************
        // Function Name		:	ObsoleteGetTaskData
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Gets the Task specific data
        // ***************************************************************************
        private void ObsoleteGetTaskData(string sTabName, string sTaskName, XmlNode nodeScreenInfo)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("ObsoleteGetTaskData(sTabName = \"{0}\", sTaskName = \"{1}\", nodeScreenInfo = \"{2}\")", sTabName, sTaskName, nodeScreenInfo.OuterXml), "listviewui");
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("listviewui : ObsoleteGetTaskData(sTabName = \"{0}\", sTaskName = \"{1}\", nodeScreenInfo = \"{2}\")", sTabName, sTaskName, nodeScreenInfo.OuterXml), "ILBO0024", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Gets the display URL based on the tab name
        // </summary>
        // **************************************************************************
        // Function Name		:	GetDisplayURL
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Gets the display URL based on the tab name
        // ***************************************************************************
        public override string GetDisplayURL(string sTabName)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetDisplayURL(sTabName = \"{0}\")", sTabName), "listviewui");
                switch (sTabName.ToLower())
                {
                    default:
                        if ((sTabName == string.Empty))
                        {
                            return "listviewact_listviewui.htm";
                        }
                        else
                        {
                            if (iEDKEIExists)
                            {
                                return base.GetDisplayURL(sTabName);
                            }
                            else
                            {
                                throw new Exception("Invalid TabName");
                            }
                        }
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("listviewui : GetDisplayURL(sTabName = \"{0}\")", sTabName), "ILBO0025", e.Message);
                throw new Exception(e.Message, e);
            }
            return "";
        }
        // <summary>
        // This method executes services for Init, Fetch, Trans and Submit tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	ExecuteService
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	executes services for Init, Fetch, Trans and Submit tasks
        // ***************************************************************************
        protected override bool ExecuteService(string sServiceName)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("ExecuteService(sServiceName = \"{0}\")", sServiceName), "listviewui");
                string sOutMTD = null;
                string sTaskName = String.Empty;
                bool bExecFlag = true;
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IServiceExecutor ISExecutor = ISManager.GetServiceExecutor();
                switch (sServiceName.ToLower())
                {
                    case "tcmnscnsrfet":
                        sTaskName = "tcmains5fth";
                        ISExecutor.SetExecutionContext("testcomponent", "tcmnscnsrfet", "listviewact", "listviewui");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("defhdn1", FlowAttribute.flowInOut, "listviewui", "hdndefhdn1", "hdndefhdn1", String.Empty);
                        ISExecutor.SetServiceDataSource("defhdn2", FlowAttribute.flowInOut, "listviewui", "hdndefhdn2", "hdndefhdn2", String.Empty);
                        ISExecutor.SetServiceDataSource("defhdn3", FlowAttribute.flowInOut, "listviewui", "hdndefhdn3", "hdndefhdn3", String.Empty);
                        ISExecutor.SetServiceDataSource("defhdn4", FlowAttribute.flowInOut, "listviewui", "hdndefhdn4", "hdndefhdn4", String.Empty);
                        ISExecutor.SetServiceDataSource("defhdn5", FlowAttribute.flowInOut, "listviewui", "hdndefhdn5", "hdndefhdn5", String.Empty);
                        ISExecutor.SetServiceDataSource("defhdn6", FlowAttribute.flowInOut, "listviewui", "hdndefhdn6", "hdndefhdn6", String.Empty);
                        ISExecutor.SetServiceDataSource("defhdn7", FlowAttribute.flowInOut, "listviewui", "hdndefhdn7", "hdndefhdn7", String.Empty);
                        ISExecutor.SetServiceDataSource("defhdn8", FlowAttribute.flowInOut, "listviewui", "hdndefhdn8", "hdndefhdn8", String.Empty);
                        ISExecutor.SetServiceDataSource("employeefirstname", FlowAttribute.flowIn, "listviewui", "lvwemployeenamelistview", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("employeelastname", FlowAttribute.flowIn, "listviewui", "lvwemployeenamelistview", "3", String.Empty);
                        ISExecutor.SetServiceDataSource("employeemidname", FlowAttribute.flowIn, "listviewui", "lvwemployeenamelistview", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("employeename", FlowAttribute.flowInOut, "listviewui", "txtemployeename", "txtemployeename", String.Empty);
                        ISExecutor.SetServiceDataSource("employeeno", FlowAttribute.flowInOut, "listviewui", "txtemployeeno", "txtemployeeno", String.Empty);
                        ISExecutor.SetServiceDataSource("employeeuniqueno", FlowAttribute.flowIn, "listviewui", "lvwemployeenolistview", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("prj_hdn_ctrl", FlowAttribute.flowInOut, "listviewui", "hdnprj_hdn_ctrl", "hdnprj_hdn_ctrl", String.Empty);
                        ISExecutor.SetServiceDataSource("testhdncntrl", FlowAttribute.flowInOut, "listviewui", "hdntesthdncntrl", "hdntesthdncntrl", String.Empty);
                        ISExecutor.SetServiceDataSource("testhdnctrl1", FlowAttribute.flowInOut, "listviewui", "hdntesthdnctrl1", "hdntesthdnctrl1", String.Empty);
                        ISExecutor.SetSegmentContext("emnolvmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("employeeuniqueno", FlowAttribute.flowOut, "listviewui", "lvwemployeenolistview", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("modeflag", FlowAttribute.flowOut, "listviewui", "lvwemployeenolistview", "modeflag", String.Empty);
                        ISExecutor.SetSegmentContext("epnlvmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("employeefirstname", FlowAttribute.flowOut, "listviewui", "lvwemployeenamelistview", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("employeelastname", FlowAttribute.flowOut, "listviewui", "lvwemployeenamelistview", "3", String.Empty);
                        ISExecutor.SetServiceDataSource("employeemidname", FlowAttribute.flowOut, "listviewui", "lvwemployeenamelistview", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("modeflag", FlowAttribute.flowOut, "listviewui", "lvwemployeenamelistview", "modeflag", String.Empty);
                        ISExecutor.SetSegmentContext("griddemlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("employeeaddress", FlowAttribute.flowOut, "listviewui", "mlgriddetails", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("employeemailid", FlowAttribute.flowOut, "listviewui", "mlgriddetails", "2", String.Empty);
                        if (iEDKEIExists)
                        {
                            bExecFlag = base.ExecuteService(ISExecutor, sServiceName);
                        }
                        else
                        {
                            bExecFlag = ISExecutor.ExecuteService();
                        }
                        return bExecFlag;
                    case "tcmnscnsrsave":
                        sTaskName = "tcmains5save1tr";
                        ISExecutor.SetExecutionContext("testcomponent", "tcmnscnsrsave", "listviewact", "listviewui");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("defhdn1", FlowAttribute.flowInOut, "listviewui", "hdndefhdn1", "hdndefhdn1", String.Empty);
                        ISExecutor.SetServiceDataSource("defhdn2", FlowAttribute.flowInOut, "listviewui", "hdndefhdn2", "hdndefhdn2", String.Empty);
                        ISExecutor.SetServiceDataSource("defhdn3", FlowAttribute.flowInOut, "listviewui", "hdndefhdn3", "hdndefhdn3", String.Empty);
                        ISExecutor.SetServiceDataSource("defhdn4", FlowAttribute.flowInOut, "listviewui", "hdndefhdn4", "hdndefhdn4", String.Empty);
                        ISExecutor.SetServiceDataSource("defhdn5", FlowAttribute.flowInOut, "listviewui", "hdndefhdn5", "hdndefhdn5", String.Empty);
                        ISExecutor.SetServiceDataSource("defhdn6", FlowAttribute.flowInOut, "listviewui", "hdndefhdn6", "hdndefhdn6", String.Empty);
                        ISExecutor.SetServiceDataSource("defhdn7", FlowAttribute.flowInOut, "listviewui", "hdndefhdn7", "hdndefhdn7", String.Empty);
                        ISExecutor.SetServiceDataSource("defhdn8", FlowAttribute.flowInOut, "listviewui", "hdndefhdn8", "hdndefhdn8", String.Empty);
                        ISExecutor.SetServiceDataSource("employeefirstname", FlowAttribute.flowIn, "listviewui", "lvwemployeenamelistview", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("employeelastname", FlowAttribute.flowIn, "listviewui", "lvwemployeenamelistview", "3", String.Empty);
                        ISExecutor.SetServiceDataSource("employeemidname", FlowAttribute.flowIn, "listviewui", "lvwemployeenamelistview", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("employeename", FlowAttribute.flowInOut, "listviewui", "txtemployeename", "txtemployeename", String.Empty);
                        ISExecutor.SetServiceDataSource("employeeno", FlowAttribute.flowInOut, "listviewui", "txtemployeeno", "txtemployeeno", String.Empty);
                        ISExecutor.SetServiceDataSource("employeeuniqueno", FlowAttribute.flowIn, "listviewui", "lvwemployeenolistview", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("prj_hdn_ctrl", FlowAttribute.flowInOut, "listviewui", "hdnprj_hdn_ctrl", "hdnprj_hdn_ctrl", String.Empty);
                        ISExecutor.SetServiceDataSource("testhdncntrl", FlowAttribute.flowInOut, "listviewui", "hdntesthdncntrl", "hdntesthdncntrl", String.Empty);
                        ISExecutor.SetServiceDataSource("testhdnctrl1", FlowAttribute.flowInOut, "listviewui", "hdntesthdnctrl1", "hdntesthdnctrl1", String.Empty);
                        ISExecutor.SetSegmentContext("emnolvml", "2", true, FlowAttribute.flowIn, false);
                        ISExecutor.SetServiceDataSource("employeeuniqueno", FlowAttribute.flowIn, "listviewui", "lvwemployeenolistview", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("modeflag", FlowAttribute.flowIn, "listviewui", "lvwemployeenolistview", "modeflag", String.Empty);
                        ISExecutor.SetSegmentContext("epnlvml", "2", true, FlowAttribute.flowIn, false);
                        ISExecutor.SetServiceDataSource("employeefirstname", FlowAttribute.flowIn, "listviewui", "lvwemployeenamelistview", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("employeelastname", FlowAttribute.flowIn, "listviewui", "lvwemployeenamelistview", "3", String.Empty);
                        ISExecutor.SetServiceDataSource("employeemidname", FlowAttribute.flowIn, "listviewui", "lvwemployeenamelistview", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("modeflag", FlowAttribute.flowIn, "listviewui", "lvwemployeenamelistview", "modeflag", String.Empty);
                        ISExecutor.SetSegmentContext("griddeml", "2", true, FlowAttribute.flowIn, false);
                        ISExecutor.SetServiceDataSource("employeeaddress", FlowAttribute.flowIn, "listviewui", "mlgriddetails", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("employeemailid", FlowAttribute.flowIn, "listviewui", "mlgriddetails", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("modeflag", FlowAttribute.flowIn, "listviewui", "mlgriddetails", "modeflag", String.Empty);
                        ISExecutor.SetSegmentContext("griddemlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("employeeaddress", FlowAttribute.flowOut, "listviewui", "mlgriddetails", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("employeemailid", FlowAttribute.flowOut, "listviewui", "mlgriddetails", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("modeflag", FlowAttribute.flowOut, "listviewui", "mlgriddetails", "modeflag", String.Empty);
                        if (iEDKEIExists)
                        {
                            bExecFlag = base.ExecuteService(ISExecutor, sServiceName);
                        }
                        else
                        {
                            bExecFlag = ISExecutor.ExecuteService();
                        }
                        return bExecFlag;
                }
                if (iEDKEIExists)
                {
                    return base.ExecuteService(null, sServiceName);
                }
                throw new Exception("Invalid Service");
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("listviewui : ExecuteService(sServiceName = \"{0}\")", sServiceName), "ILBO0026", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method executes services for Init, Fetch, Trans and Submit tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	BeginExecuteService
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	executes services for Init, Fetch, Trans and Submit tasks
        // ***************************************************************************
        protected override IAsyncResult BeginExecuteService(AsyncCallback cb, VWRequestState reqState)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("BeginExecuteService(ServiceName = \"{0}\")", reqState.ServiceName), "listviewui");
                string sOutMTD = null;
                string sTaskName = String.Empty;
                bool bExecFlag = true;
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IServiceExecutor ISExecutor = ISManager.GetServiceExecutor();
                bExecFlag = base.PreServiceProcess(reqState.ServiceName, reqState.ServiceName);
                switch (reqState.ServiceName.ToLower())
                {
                    case "tcmnscnsrfet":
                        sTaskName = "tcmains5fth";
                        ISExecutor.SetExecutionContext("testcomponent", "tcmnscnsrfet", "listviewact", "listviewui");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("defhdn1", FlowAttribute.flowInOut, "listviewui", "hdndefhdn1", "hdndefhdn1", String.Empty);
                        ISExecutor.SetServiceDataSource("defhdn2", FlowAttribute.flowInOut, "listviewui", "hdndefhdn2", "hdndefhdn2", String.Empty);
                        ISExecutor.SetServiceDataSource("defhdn3", FlowAttribute.flowInOut, "listviewui", "hdndefhdn3", "hdndefhdn3", String.Empty);
                        ISExecutor.SetServiceDataSource("defhdn4", FlowAttribute.flowInOut, "listviewui", "hdndefhdn4", "hdndefhdn4", String.Empty);
                        ISExecutor.SetServiceDataSource("defhdn5", FlowAttribute.flowInOut, "listviewui", "hdndefhdn5", "hdndefhdn5", String.Empty);
                        ISExecutor.SetServiceDataSource("defhdn6", FlowAttribute.flowInOut, "listviewui", "hdndefhdn6", "hdndefhdn6", String.Empty);
                        ISExecutor.SetServiceDataSource("defhdn7", FlowAttribute.flowInOut, "listviewui", "hdndefhdn7", "hdndefhdn7", String.Empty);
                        ISExecutor.SetServiceDataSource("defhdn8", FlowAttribute.flowInOut, "listviewui", "hdndefhdn8", "hdndefhdn8", String.Empty);
                        ISExecutor.SetServiceDataSource("employeefirstname", FlowAttribute.flowIn, "listviewui", "lvwemployeenamelistview", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("employeelastname", FlowAttribute.flowIn, "listviewui", "lvwemployeenamelistview", "3", String.Empty);
                        ISExecutor.SetServiceDataSource("employeemidname", FlowAttribute.flowIn, "listviewui", "lvwemployeenamelistview", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("employeename", FlowAttribute.flowInOut, "listviewui", "txtemployeename", "txtemployeename", String.Empty);
                        ISExecutor.SetServiceDataSource("employeeno", FlowAttribute.flowInOut, "listviewui", "txtemployeeno", "txtemployeeno", String.Empty);
                        ISExecutor.SetServiceDataSource("employeeuniqueno", FlowAttribute.flowIn, "listviewui", "lvwemployeenolistview", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("prj_hdn_ctrl", FlowAttribute.flowInOut, "listviewui", "hdnprj_hdn_ctrl", "hdnprj_hdn_ctrl", String.Empty);
                        ISExecutor.SetServiceDataSource("testhdncntrl", FlowAttribute.flowInOut, "listviewui", "hdntesthdncntrl", "hdntesthdncntrl", String.Empty);
                        ISExecutor.SetServiceDataSource("testhdnctrl1", FlowAttribute.flowInOut, "listviewui", "hdntesthdnctrl1", "hdntesthdnctrl1", String.Empty);
                        ISExecutor.SetSegmentContext("emnolvmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("employeeuniqueno", FlowAttribute.flowOut, "listviewui", "lvwemployeenolistview", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("modeflag", FlowAttribute.flowOut, "listviewui", "lvwemployeenolistview", "modeflag", String.Empty);
                        ISExecutor.SetSegmentContext("epnlvmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("employeefirstname", FlowAttribute.flowOut, "listviewui", "lvwemployeenamelistview", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("employeelastname", FlowAttribute.flowOut, "listviewui", "lvwemployeenamelistview", "3", String.Empty);
                        ISExecutor.SetServiceDataSource("employeemidname", FlowAttribute.flowOut, "listviewui", "lvwemployeenamelistview", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("modeflag", FlowAttribute.flowOut, "listviewui", "lvwemployeenamelistview", "modeflag", String.Empty);
                        ISExecutor.SetSegmentContext("griddemlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("employeeaddress", FlowAttribute.flowOut, "listviewui", "mlgriddetails", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("employeemailid", FlowAttribute.flowOut, "listviewui", "mlgriddetails", "2", String.Empty);
                        if (iEDKEIExists)
                        {
                            return base.BeginExecuteService(cb, reqState, ISExecutor);
                        }
                        return ISExecutor.BeginExecuteService(cb, reqState);
                    case "tcmnscnsrsave":
                        sTaskName = "tcmains5save1tr";
                        ISExecutor.SetExecutionContext("testcomponent", "tcmnscnsrsave", "listviewact", "listviewui");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("defhdn1", FlowAttribute.flowInOut, "listviewui", "hdndefhdn1", "hdndefhdn1", String.Empty);
                        ISExecutor.SetServiceDataSource("defhdn2", FlowAttribute.flowInOut, "listviewui", "hdndefhdn2", "hdndefhdn2", String.Empty);
                        ISExecutor.SetServiceDataSource("defhdn3", FlowAttribute.flowInOut, "listviewui", "hdndefhdn3", "hdndefhdn3", String.Empty);
                        ISExecutor.SetServiceDataSource("defhdn4", FlowAttribute.flowInOut, "listviewui", "hdndefhdn4", "hdndefhdn4", String.Empty);
                        ISExecutor.SetServiceDataSource("defhdn5", FlowAttribute.flowInOut, "listviewui", "hdndefhdn5", "hdndefhdn5", String.Empty);
                        ISExecutor.SetServiceDataSource("defhdn6", FlowAttribute.flowInOut, "listviewui", "hdndefhdn6", "hdndefhdn6", String.Empty);
                        ISExecutor.SetServiceDataSource("defhdn7", FlowAttribute.flowInOut, "listviewui", "hdndefhdn7", "hdndefhdn7", String.Empty);
                        ISExecutor.SetServiceDataSource("defhdn8", FlowAttribute.flowInOut, "listviewui", "hdndefhdn8", "hdndefhdn8", String.Empty);
                        ISExecutor.SetServiceDataSource("employeefirstname", FlowAttribute.flowIn, "listviewui", "lvwemployeenamelistview", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("employeelastname", FlowAttribute.flowIn, "listviewui", "lvwemployeenamelistview", "3", String.Empty);
                        ISExecutor.SetServiceDataSource("employeemidname", FlowAttribute.flowIn, "listviewui", "lvwemployeenamelistview", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("employeename", FlowAttribute.flowInOut, "listviewui", "txtemployeename", "txtemployeename", String.Empty);
                        ISExecutor.SetServiceDataSource("employeeno", FlowAttribute.flowInOut, "listviewui", "txtemployeeno", "txtemployeeno", String.Empty);
                        ISExecutor.SetServiceDataSource("employeeuniqueno", FlowAttribute.flowIn, "listviewui", "lvwemployeenolistview", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("prj_hdn_ctrl", FlowAttribute.flowInOut, "listviewui", "hdnprj_hdn_ctrl", "hdnprj_hdn_ctrl", String.Empty);
                        ISExecutor.SetServiceDataSource("testhdncntrl", FlowAttribute.flowInOut, "listviewui", "hdntesthdncntrl", "hdntesthdncntrl", String.Empty);
                        ISExecutor.SetServiceDataSource("testhdnctrl1", FlowAttribute.flowInOut, "listviewui", "hdntesthdnctrl1", "hdntesthdnctrl1", String.Empty);
                        ISExecutor.SetSegmentContext("emnolvml", "2", true, FlowAttribute.flowIn, false);
                        ISExecutor.SetServiceDataSource("employeeuniqueno", FlowAttribute.flowIn, "listviewui", "lvwemployeenolistview", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("modeflag", FlowAttribute.flowIn, "listviewui", "lvwemployeenolistview", "modeflag", String.Empty);
                        ISExecutor.SetSegmentContext("epnlvml", "2", true, FlowAttribute.flowIn, false);
                        ISExecutor.SetServiceDataSource("employeefirstname", FlowAttribute.flowIn, "listviewui", "lvwemployeenamelistview", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("employeelastname", FlowAttribute.flowIn, "listviewui", "lvwemployeenamelistview", "3", String.Empty);
                        ISExecutor.SetServiceDataSource("employeemidname", FlowAttribute.flowIn, "listviewui", "lvwemployeenamelistview", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("modeflag", FlowAttribute.flowIn, "listviewui", "lvwemployeenamelistview", "modeflag", String.Empty);
                        ISExecutor.SetSegmentContext("griddeml", "2", true, FlowAttribute.flowIn, false);
                        ISExecutor.SetServiceDataSource("employeeaddress", FlowAttribute.flowIn, "listviewui", "mlgriddetails", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("employeemailid", FlowAttribute.flowIn, "listviewui", "mlgriddetails", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("modeflag", FlowAttribute.flowIn, "listviewui", "mlgriddetails", "modeflag", String.Empty);
                        ISExecutor.SetSegmentContext("griddemlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("employeeaddress", FlowAttribute.flowOut, "listviewui", "mlgriddetails", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("employeemailid", FlowAttribute.flowOut, "listviewui", "mlgriddetails", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("modeflag", FlowAttribute.flowOut, "listviewui", "mlgriddetails", "modeflag", String.Empty);
                        if (iEDKEIExists)
                        {
                            return base.BeginExecuteService(cb, reqState, ISExecutor);
                        }
                        return ISExecutor.BeginExecuteService(cb, reqState);
                }
                if (iEDKEIExists)
                {
                    return base.BeginExecuteService(cb, reqState, null);
                }
                throw new Exception("Invalid Service");
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("listviewui : BeginExecuteService(sServiceName = \"{0}\")", reqState.ServiceName), "ILBO0027", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method executes services for Init, Fetch, Trans and Submit tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	EndExecuteService
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	executes services for Init, Fetch, Trans and Submit tasks
        // ***************************************************************************
        protected override bool EndExecuteService(IAsyncResult ar)
        {
            bool bExecFlag = true;
            VWRequestState reqState = ar.AsyncState as VWRequestState;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("EndExecuteService(ServiceName = \"{0}\")", reqState.ServiceName), "listviewui");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IServiceExecutor ISExecutor = ISManager.GetServiceExecutor();
                switch (reqState.ServiceName.ToLower())
                {
                    case "tcmnscnsrfet":
                        bExecFlag = ISExecutor.EndExecuteService(ar);
                        break;
                    case "tcmnscnsrsave":
                        bExecFlag = ISExecutor.EndExecuteService(ar);
                        break;
                    default:
                        if (iEDKEIExists)
                        {
                            return base.EndExecuteService(ar);
                        }
                        break;
                }
                if (bExecFlag)
                {
                    bExecFlag = base.PostServiceProcess(reqState.TaskName, reqState.ServiceName);
                }
                return bExecFlag;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("listviewui : EndExecuteService(sServiceName = \"{0}\")", reqState.ServiceName), "ILBO0028", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initializes tab control
        // </summary>
        // **************************************************************************
        // Function Name		:	InitializeTabControls
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Initializes tab control
        // ***************************************************************************
        private new void InitializeTabControls()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "InitializeTabControls()", "listviewui");
                _mainpage.SetIdentity("mainpage");
                base.AddTabControl(_mainpage);
                if (iEDKEIExists)
                {
                    base.InitializeTabControls();
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("listviewui : InitializeTabControls()", "ILBO0029", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initializes Layout Controls
        // </summary>
        // **************************************************************************
        // Function Name		:	InitializeLayoutControls
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Initializes Layout Controls
        // ***************************************************************************
        private new void InitializeLayoutControls()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "InitializeLayoutControls()", "listviewui");
                _btnsave.SetIdentity("btnsave");
                _mainpage.AddLayoutControl("btnsave");
                _buttonsection.SetIdentity("buttonsection");
                _mainpage.AddLayoutControl("buttonsection");
                _gridsection.SetIdentity("gridsection");
                _mainpage.AddLayoutControl("gridsection");
                _headersection.SetIdentity("headersection");
                _mainpage.AddLayoutControl("headersection");
                _prjhdnsection.SetIdentity("prjhdnsection");
                _mainpage.AddLayoutControl("prjhdnsection");
                if (iEDKEIExists)
                {
                    base.InitializeLayoutControls();
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("listviewui : InitializeLayoutControls()", "ILBO0030", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Resets Tab Controls
        // </summary>
        // **************************************************************************
        // Function Name		:	ResetTabControls
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Resets Tab Controls
        // ***************************************************************************
        public override void ResetTabControls()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "ResetTabControls()", "listviewui");
                _mainpage.Clear();
                if (iEDKEIExists)
                {
                    base.ResetTabControls();
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("listviewui : ResetTabControls()", "ILBO0031", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Resets Layout Controls
        // </summary>
        // **************************************************************************
        // Function Name		:	ResetLayoutControls
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Resets Layout Controls
        // ***************************************************************************
        public override void ResetLayoutControls()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "ResetLayoutControls()", "listviewui");
                _btnsave.Clear();
                _buttonsection.Clear();
                _gridsection.Clear();
                _headersection.Clear();
                _prjhdnsection.Clear();
                if (iEDKEIExists)
                {
                    base.ResetLayoutControls();
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("listviewui : ResetLayoutControls()", "ILBO0032", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method 
        // </summary>
        // **************************************************************************
        // Function Name		:	GetTabControl
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	
        // ***************************************************************************
        public override ITabControl GetTabControl(string sTabName)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetTabControl(sTabName = \"{0}\")", sTabName), "listviewui");
                switch (sTabName.ToLower())
                {
                    case "mainpage":
                    case "":
                        return this._mainpage;
                    default:
                        return base.GetTabControl(sTabName);
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("listviewui : GetTabControl(sTabName= \"{0}\")", sTabName), "ILBO0033", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Get Layout Controls
        // </summary>
        // **************************************************************************
        // Function Name		:	GetLayoutControl
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Get Layout Controls
        // ***************************************************************************
        public override ILayoutControl GetLayoutControl(string sLayoutControlName)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetLayoutControl(sLayoutControlName = \"{0}\")", sLayoutControlName), "listviewui");
                switch (sLayoutControlName)
                {
                    case "btnsave":
                        return this._btnsave;
                    case "buttonsection":
                        return this._buttonsection;
                    case "gridsection":
                        return this._gridsection;
                    case "headersection":
                        return this._headersection;
                    case "prjhdnsection":
                        return this._prjhdnsection;
                    default:
                        return base.GetLayoutControl(sLayoutControlName);
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("listviewui : GetLayoutControl(sLayoutControlName= \"{0}\")", sLayoutControlName), "ILBO0034", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Updates the screen data
        // </summary>
        // **************************************************************************
        // Function Name		:	UpdateScreenData
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Updates the screen data
        // ***************************************************************************
        public override void UpdateScreenData(string sTabName, XmlNode nodeScreenInfo)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("UpdateScreenData(sTabName = \"{0}\", nodeScreenInfo = \"{1}\")", sTabName, nodeScreenInfo.OuterXml), "listviewui");
                base.UpdateScreenData(sTabName, nodeScreenInfo);
                return;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("listviewui : UpdateScreenData(sTabName = \"{0}\", nodeScreenInfo = \"{1}\")", sTabName, nodeScreenInfo.OuterXml), "ILBO0035", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Gets the screen data
        // </summary>
        // **************************************************************************
        // Function Name		:	GetScreenData
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Gets the screen data
        // ***************************************************************************
        public override void GetScreenData(string sTabName, XmlNode nodeScreenInfo)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetScreenData(sTabName = \"{0}\", nodeScreenInfo = \"{1}\")", sTabName, nodeScreenInfo.OuterXml), "listviewui");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IContext ISMContext = ISManager.GetContextObject();
                IAuthorizedActivitiesAndOULists IAuthorizedInfo = ISManager.GetAuthorizedInfoObject();
                XmlDocument xmlDom = nodeScreenInfo.OwnerDocument;
                System.Xml.XmlElement eltTask;
                System.Xml.XmlElement eltControlInfo;
                System.Xml.XmlElement eltLayoutControlInfo;
                System.Xml.XmlElement eltIlboInfo = xmlDom.SelectSingleNode("trpi/scri/ii") as XmlElement;
                if ((eltIlboInfo == null))
                {
                    eltIlboInfo = xmlDom.CreateElement("ii");
                    nodeScreenInfo.AppendChild(eltIlboInfo);
                    eltIlboInfo.SetAttribute("dst", "0");
                    ISMContext.SetContextValue("SCT_SETPAGE_STATUS", "0");
                    if ((sTabName == String.Empty))
                    {
                        eltIlboInfo.SetAttribute("at", (String)GetContextValue("ICT_ACTIVE_TAB"));
                        if ((((String)ISMContext.GetContextValue("SCT_LASTTASK_TYPE") == "HELP")
                                    && (GetContextValue("ICT_PARENTILBO") != null)))
                        {
                            if ((ISMContext.GetContextValue("ICT_HELPTASK_TYPE") == null))
                            {
                                this.SetContextValue("ICT_HELPTASK_TYPE", ISMContext.GetContextValue("SCT_LASTTASK_TYPE"));
                            }
                        }
                        if (((String)GetContextValue("ICT_HELPTASK_TYPE") == "HELP"))
                        {
                            eltIlboInfo.SetAttribute("ttype", "HELP");
                            ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "");
                        }
                        else
                        {
                            this.SetContextValue("ICT_HELPTASK_TYPE", "NOTHELP");
                            eltIlboInfo.SetAttribute("ttype", "NOTHELP");
                        }
                    }
                    System.Xml.XmlElement eltDsTaskInfo = nodeScreenInfo.OwnerDocument.CreateElement("dti");
                    nodeScreenInfo.AppendChild(eltDsTaskInfo);
                    eltControlInfo = base.GetControlInfoElement(xmlDom, nodeScreenInfo);
                    eltLayoutControlInfo = base.GetLayoutControlInfoElement(xmlDom, nodeScreenInfo);
                }
                else
                {
                    eltIlboInfo = xmlDom.SelectSingleNode("trpi/scri/ii") as XmlElement;
                    eltControlInfo = xmlDom.SelectSingleNode("trpi/scri/ci") as XmlElement;
                }
                base.GetScreenData(sTabName, nodeScreenInfo);
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("listviewui : GetScreenData(sTabName = \"{0}\", nodeScreenInfo = \"{1}\")", sTabName, nodeScreenInfo.OuterXml), "ILBO0036", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Fills the Message object when an error occurs
        // </summary>
        // **************************************************************************
        // Function Name		:	FillMessageObject
        // Author				:	ILDotNetCodeGenerator
        // Date					:	1/30/2023
        // Description			:	Fills the Message object when an error occurs
        // ***************************************************************************
        private void FillMessageObject(string sMethod, string sErrNumber, string sErrMessage)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("listviewui : FillMessageObject(sMethod = \"{0}\",sErrNumber = \"{0}\",sErrMessage = \"{0}\")", sMethod, sErrNumber, sErrMessage), "listviewui");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IMessage Imsg = ISManager.GetMessageObject();
                Imsg.AddMessage(sErrNumber, sErrMessage, sMethod, string.Empty, "5");
            }
            catch (System.Exception e)
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceError, e.Message, String.Format("listviewui : FillMessageObject(sMethod = \"{0}\",sErrNumber = \"{0}\",sErrMessage = \"{0}\")", sMethod, sErrNumber, sErrMessage));
            }
        }
    }
}

