/***********************************************************************************************************
Copyright @2004, RAMCO SYSTEMS,  All rights reserved
Author                   :   Ramco.VwPlf.DeveloperConsole
Application/Module Name  :   Ctcmainsnsrhdrlin.cs
Code Generated From      :   ramco\UnitTestProj\TC_ECR_00053\techwarcnv18\inst3\sa\Maint_rvw20appdb\TECHWARCNV18
Revision/Version #       :   
Purpose                  :   Service Implementation
Modifications            :   
Modifier Name & Date     :   
***********************************************************************************************************/
namespace com.ramco.vw.testcomponent.service
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Diagnostics;
    using System.IO;
    using System.Text;
    using System.Xml;
    using com.ramco.vw.tp;
    using System.Reflection;
    using com.ramco.vw.testcomponent.ehs;

    public class Ctcmainsnsrhdrlin : CUtil
    {
        private double result;
        private long lSPErrorID;
        private long nRecCount = 0;
        private long nLoop;
        private long nMax = 1;
        private long nErrMax = 0;
        private long lISLoop = 0;
        private long lISOutRecCount = 0;
        private long lInstExists = 0;
        private long lRetVal = 0;
        private long lValue = 0;
        private System.Nullable<double> dValue = 0;
        private string defaultValue = string.Empty;
        private string sISKeyValue = string.Empty;
        private string szErrorDesc;
        private string szErrSrc;
        private string sValue = string.Empty;
        private System.IO.MemoryStream mStream = null;
        private System.Collections.Specialized.NameValueCollection nvcTmp = null;
        private System.Collections.Specialized.NameValueCollection nvcISTmp = null;
        private System.Collections.Specialized.NameValueCollection nvcISTmpIS = null;
        private System.Collections.Specialized.NameValueCollection nvcFilterText = null;
        private System.Collections.Specialized.NameValueCollection nvcTmpCrtl = null;
        public System.Collections.Specialized.NameValueCollection nvc_HSEG = new System.Collections.Specialized.NameValueCollection();
        private string s_HSEGcheckboxcolumn = "0";
        private string s_HSEGgrosspay = "0";
        private string s_HSEGhra = "0";
        private string s_HSEGlta = "0";
        private string s_HSEGnetpay = "0";
        private string s_HSEGpf = "0";
        private string s_HSEGpincode = "0";
        private string modeFlagValue = string.Empty;
        public Ctcmainsnsrhdrlin()
        {
            base.iEDKESEngineInit("tcmainsnsrhdrlin", "testcomponent");
        }
        private string GetBOD(bool allSegments)
        {
            string RetVal = string.Empty;
            System.IO.StreamReader read = null;
            try
            {
                base.WriteProfiler(String.Format("Executing GetBOD Method at " + System.DateTime.Now.ToString()));
                this.mStream = new System.IO.MemoryStream();
                this.writer = new System.Xml.XmlTextWriter(mStream, null);
                writer.WriteStartElement("VW-TD");
                base.BuildContextSegments();
                if (allSegments)
                {
                    this.BuildOutSegments();
                }
                base.BuildErrorSegments();
                this.writer.WriteEndElement();
                this.writer.Flush();
                mStream.Position = 0;
                read = new System.IO.StreamReader(this.mStream);
                RetVal = read.ReadToEnd();
                return RetVal;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General exception in GetBOD - {0}", e.Message));
                throw new System.Exception(string.Format("General exception in GetBOD - {0}", e.Message));
            }
            finally
            {
                if ((read != null))
                {
                    read.Close();
                }
                if ((writer != null))
                {
                    writer.Close();
                }
                if ((mStream != null))
                {
                    mStream.Close();
                    mStream = null;
                }
            }
        }
        private void BuildOutSegments()
        {
            try
            {
                System.Collections.Specialized.NameValueCollection nvcTmp = null;
                bool iEDKESSegExists;
                base.WriteProfiler(String.Format("Executing BuildOutSegments Method at " + System.DateTime.Now.ToString()));
                if ((this.nvc_HSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("_hseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("_hseg");
                    this.writer.WriteAttributeString("RecordCount", "1");
                    this.writer.WriteAttributeString("seq", "2");
                    this.writer.WriteStartElement("I2");
                    this.writer.WriteAttributeString("addhlp", System.Convert.ToString(nvc_HSEG["addhlp"]));
                    this.writer.WriteAttributeString("address1", System.Convert.ToString(nvc_HSEG["address1"]));
                    this.writer.WriteAttributeString("address2", System.Convert.ToString(nvc_HSEG["address2"]));
                    this.writer.WriteAttributeString("allowancedtls", System.Convert.ToString(nvc_HSEG["allowancedtls"]));
                    this.writer.WriteAttributeString("basic", System.Convert.ToString(nvc_HSEG["basic"]));
                    this.writer.WriteAttributeString("branch", System.Convert.ToString(nvc_HSEG["branch"]));
                    this.writer.WriteAttributeString("checkboxcolumn", System.Convert.ToString(nvc_HSEG["checkboxcolumn"]));
                    this.writer.WriteAttributeString("city", System.Convert.ToString(nvc_HSEG["city"]));
                    this.writer.WriteAttributeString("dateofjoin", System.Convert.ToString(nvc_HSEG["dateofjoin"]));
                    this.writer.WriteAttributeString("deducthlp", System.Convert.ToString(nvc_HSEG["deducthlp"]));
                    this.writer.WriteAttributeString("deductionreason", System.Convert.ToString(nvc_HSEG["deductionreason"]));
                    this.writer.WriteAttributeString("empcode", System.Convert.ToString(nvc_HSEG["empcode"]));
                    this.writer.WriteAttributeString("emplname", System.Convert.ToString(nvc_HSEG["emplname"]));
                    this.writer.WriteAttributeString("esi", System.Convert.ToString(nvc_HSEG["esi"]));
                    this.writer.WriteAttributeString("grosspay", System.Convert.ToString(nvc_HSEG["grosspay"]));
                    this.writer.WriteAttributeString("hra", System.Convert.ToString(nvc_HSEG["hra"]));
                    this.writer.WriteAttributeString("insurancedtls", System.Convert.ToString(nvc_HSEG["insurancedtls"]));
                    this.writer.WriteAttributeString("lta", System.Convert.ToString(nvc_HSEG["lta"]));
                    this.writer.WriteAttributeString("netpay", System.Convert.ToString(nvc_HSEG["netpay"]));
                    this.writer.WriteAttributeString("pf", System.Convert.ToString(nvc_HSEG["pf"]));
                    this.writer.WriteAttributeString("pfdtls", System.Convert.ToString(nvc_HSEG["pfdtls"]));
                    this.writer.WriteAttributeString("pincode", System.Convert.ToString(nvc_HSEG["pincode"]));
                    this.writer.WriteAttributeString("prj_hdn_ctrl", System.Convert.ToString(nvc_HSEG["prj_hdn_ctrl"]));
                    this.writer.WriteAttributeString("reportreq", System.Convert.ToString(nvc_HSEG["reportreq"]));
                    if (iEDKESSegExists)
                    {
                        base.BuildOutSegments("_hseg", nvc_HSEG);
                    }
                    this.writer.WriteEndElement();
                    this.writer.WriteEndElement();
                }
                if (base.iEDKServiceES)
                {
                    base.BuildOutSegments(string.Empty, null);
                }
            }
            catch (System.Exception e)
            {
                base.WriteProfiler(String.Format("General Exception in BuildOutSegments - " + e.Message));
                base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General Exception in BuildOutSegments - " + e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                throw new Exception(e.Message, e);
            }
        }
        public override int getFieldValue(string SegName, long InstNumber, string DataItem, string DIValue)
        {
            try
            {
                bool IsMand = false;
                SegName = SegName.ToLower();
                DataItem = DataItem.ToLower().Trim();
                if ((DIValue == null))
                {
                    DIValue = string.Empty;
                }
                switch (SegName)
                {
                    case "_hseg":
                        switch (DataItem)
                        {
                            case "addhlp":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "address1":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "address2":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "allowancedtls":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "basic":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "branch":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "checkboxcolumn":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "city":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "dateofjoin":
                                IsMand = false;
                                defaultValue = "01/01/1900";
                                break;
                            case "deducthlp":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "deductionreason":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "empcode":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "emplname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "esi":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "grosspay":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "hra":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "insurancedtls":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "lta":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "netpay":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "pf":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "pfdtls":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "pincode":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "prj_hdn_ctrl":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "reportreq":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            default:
                                if (base.iEDKServiceES)
                                {
                                    return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                                }
                                else
                                {
                                    base.WriteProfiler(string.Format("RVWException in getFieldValue - DataItem - {0}  is not part of the Service", DataItem));
                                    nvc_HSEG[DataItem] = DIValue;
                                }
                                return 0;
                                break;
                        }
                        if ((base.checkforvalidate(ref DIValue, IsMand, defaultValue) == false))
                        {
                            base.WriteProfiler(String.Format("RVWException in getFieldValue - No Value is passed for the mandatory DataItem - " + DataItem + " for the segment - " + SegName));
                            base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Value is passed for the Mandatory DataItem - " + DataItem + " for the segment - " + SegName), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            return 1;
                        }
                        nvc_HSEG[DataItem] = DIValue;
                        return 0;
                    default:
                        if (((base.iEDKServiceES == true)
                                    && (base.iEDKInSegment == true)))
                        {
                            if ((base.GetSegmentType(SegName) != -1))
                            {
                                return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                            }
                        }
                        base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Such Segment Name " + SegName + " is Found in the Service"), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return 1;
                        break;
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General exception in getFieldValue - {0}", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("RVWException in getFieldValue - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return 1;
            }
        }
        public override int GetSegmentType(string szSegName)
        {
            int type = -1;
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "_hseg":
                    type = 0;
                    break;
                default:
                    return base.GetSegmentType(szSegName);
                    break;
            }
            return type;
        }
        public override long GetSegmentRecCount(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                default:
                    return base.GetSegmentRecCount(szSegName);
                    break;
            }
        }
        public override System.Collections.Hashtable GetMultiSegment(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                default:
                    return base.GetMultiSegment(szSegName);
            }
        }
        public override System.Collections.Specialized.NameValueCollection GetSingleSegment(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "_hseg":
                    return this.nvc_HSEG;
                default:
                    return base.GetSingleSegment(szSegName);
            }
        }
        public override string GetSegmentValue(string szSegName, long lnInstNumber, string szDataItem)
        {
            try
            {
                string szValue = string.Empty;
                szSegName = szSegName.ToLower().Trim();
                szDataItem = szDataItem.ToLower().Trim();
                switch (szSegName)
                {
                    case "fw_context":
                        return nvcFW_CONTEXT[szDataItem];
                    case "_hseg":
                        return nvc_HSEG[szDataItem];
                        break;
                    default:
                        szValue = base.GetSegmentValue(szSegName, lnInstNumber, szDataItem);
                        if ((szValue != null))
                        {
                            return szValue;
                        }
                        base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General Exception in GetSegmentValue"), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return string.Empty;
                        break;
                }
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("RVWException in getSegmentValue - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return string.Empty;
            }
        }
        private int ValidateMandatorySegment()
        {
            return 0;
        }
        private int FillUnMappedDataItems()
        {
            try
            {
                if (base.iEDKServiceES)
                {
                    base.FillUnMappedDataItems();
                }
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, e.Source, CUtil.STOP_PROCESSING, string.Format("RVWException in FillUnMappedDataitem - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
            return 0;
        }
        public int ProcessService(string szInMtd, string szSessionToken, out string szOutMtd)
        {
            bool bServicePostResult = true;
            szOutMtd = string.Empty;
            try
            {
                Type myType = (this).GetType();
                PropertyInfo pDeliverableVersionInCUtil = myType.GetProperty("DeliverableVersion", BindingFlags.NonPublic | BindingFlags.Instance);
                if (((pDeliverableVersionInCUtil != null)
                            && (pDeliverableVersionInCUtil.CanWrite == true)))
                {
                    pDeliverableVersionInCUtil.SetValue(this, "TC_ECR_00053", null);
                }
                base.WriteProfiler(String.Format("Service tcmainsnsrhdrlin Started at " + System.DateTime.Now.ToString()));
                if ((base.bIsInteg == false))
                {
                    base.unpackBOD(szInMtd);
                }
                base.Service_Pre_Process(string.Empty, szSessionToken, ref szComponentName, ref szServiceName, ref szLangID, ref szCompInst, ref szOUI, ref szSecToken, ref szUser, ref szConnectionString, ref szTxnID, ref szRole);
                this.ValidateMandatorySegment();
                if ((base.bIsInteg == false))
                {
                    this.FillUnMappedDataItems();
                }
                this.ProcessPS1();
                this.ProcessPS2();
                return ATMA_SUCCESS;
            }
            catch (CRVWException rvwe)
            {
                base.WriteProfiler(String.Format("General Exception in ProcessService - " + rvwe.Message));
                return ATMA_FAILURE;
            }
            catch (System.Exception e)
            {
                try
                {
                    base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General exception in ProcessService - " + e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                catch (System.Exception)
                {
                    base.WriteProfiler(String.Format("General Exception in ProcessService - " + e.Message));
                }
                return ATMA_FAILURE;
            }
            finally
            {
                base.WriteProfiler("Before calling post process");
                try
                {
                    szOutMtd = string.Empty;
                    bServicePostResult = base.Service_Post_Process();
                    if ((base.bIsInteg == false))
                    {
                        szOutMtd = this.GetBOD(bServicePostResult);
                    }
                }
                catch (System.Exception e)
                {
                    szOutMtd = string.Empty;
                    base.WriteProfiler(e.Message);
                }
                base.WriteProfiler("Before exit of finally");
                base.WriteProfiler(String.Format("Service tcmainsnsrhdrlin Ended at  - " + System.DateTime.Now.ToString()));
                base.Out.Dispose();
            }
        }
        private void ProcessPS1()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 1;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 1
                // Starting to execute the BR - 1  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("tcpshdrlin");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["addhlp"];
                            base.Parameters("@addhlp", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["address1"];
                            base.Parameters("@address1", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["address2"];
                            base.Parameters("@address2", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["allowancedtls"];
                            base.Parameters("@allowancedtls", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["basic"];
                            base.Parameters("@basic", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["branch"];
                            base.Parameters("@branch", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["checkboxcolumn"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGcheckboxcolumn = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGcheckboxcolumn);
                            base.Parameters("@checkboxcolumn", DBType.Int, 32, s_HSEGcheckboxcolumn);
                            sValue = nvc_HSEG["city"];
                            base.Parameters("@city", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["dateofjoin"];
                            base.Parameters("@dateofjoin", DBType.NVarchar, 25, sValue);
                            sValue = nvc_HSEG["deducthlp"];
                            base.Parameters("@deducthlp", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["deductionreason"];
                            base.Parameters("@deductionreason", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["empcode"];
                            base.Parameters("@empcode", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["emplname"];
                            base.Parameters("@emplname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["esi"];
                            base.Parameters("@esi", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["grosspay"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGgrosspay = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGgrosspay);
                            base.Parameters("@grosspay", DBType.Int, 32, s_HSEGgrosspay);
                            sValue = nvc_HSEG["hra"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGhra = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGhra);
                            base.Parameters("@hra", DBType.Int, 32, s_HSEGhra);
                            sValue = nvc_HSEG["insurancedtls"];
                            base.Parameters("@insurancedtls", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["lta"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGlta = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGlta);
                            base.Parameters("@lta", DBType.Int, 32, s_HSEGlta);
                            sValue = nvc_HSEG["netpay"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGnetpay = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGnetpay);
                            base.Parameters("@netpay", DBType.Int, 32, s_HSEGnetpay);
                            sValue = nvc_HSEG["pf"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGpf = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGpf);
                            base.Parameters("@pf", DBType.Int, 32, s_HSEGpf);
                            sValue = nvc_HSEG["pfdtls"];
                            base.Parameters("@pfdtls", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["pincode"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGpincode = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGpincode);
                            base.Parameters("@pincode", DBType.Int, 32, s_HSEGpincode);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["reportreq"];
                            base.Parameters("@reportreq", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of tcmainsnmthdrlinhdrsav", nLoop, nMax));
                        base.Execute_SP(false, "tcmainsnsphdrlinhdrsav", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 11762, 1, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 11762, 1, 1);
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS2()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 2;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 2
                // Starting to execute the BR - 1  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("tcpshdrlinhpsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["addhlp"];
                            base.Parameters("@addhlp", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["address1"];
                            base.Parameters("@address1", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["address2"];
                            base.Parameters("@address2", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["allowancedtls"];
                            base.Parameters("@allowancedtls", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["basic"];
                            base.Parameters("@basic", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["branch"];
                            base.Parameters("@branch", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["checkboxcolumn"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGcheckboxcolumn = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGcheckboxcolumn);
                            base.Parameters("@checkboxcolumn", DBType.Int, 32, s_HSEGcheckboxcolumn);
                            sValue = nvc_HSEG["city"];
                            base.Parameters("@city", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["dateofjoin"];
                            base.Parameters("@dateofjoin", DBType.NVarchar, 25, sValue);
                            sValue = nvc_HSEG["deducthlp"];
                            base.Parameters("@deducthlp", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["deductionreason"];
                            base.Parameters("@deductionreason", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["empcode"];
                            base.Parameters("@empcode", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["emplname"];
                            base.Parameters("@emplname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["esi"];
                            base.Parameters("@esi", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["grosspay"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGgrosspay = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGgrosspay);
                            base.Parameters("@grosspay", DBType.Int, 32, s_HSEGgrosspay);
                            sValue = nvc_HSEG["hra"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGhra = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGhra);
                            base.Parameters("@hra", DBType.Int, 32, s_HSEGhra);
                            sValue = nvc_HSEG["insurancedtls"];
                            base.Parameters("@insurancedtls", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["lta"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGlta = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGlta);
                            base.Parameters("@lta", DBType.Int, 32, s_HSEGlta);
                            sValue = nvc_HSEG["netpay"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGnetpay = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGnetpay);
                            base.Parameters("@netpay", DBType.Int, 32, s_HSEGnetpay);
                            sValue = nvc_HSEG["pf"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGpf = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGpf);
                            base.Parameters("@pf", DBType.Int, 32, s_HSEGpf);
                            sValue = nvc_HSEG["pfdtls"];
                            base.Parameters("@pfdtls", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["pincode"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGpincode = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGpincode);
                            base.Parameters("@pincode", DBType.Int, 32, s_HSEGpincode);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["reportreq"];
                            base.Parameters("@reportreq", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of tcmainsnmthdrlinhdrref", nLoop, nMax));
                        base.Execute_SP(true, "tcmainsnsphdrlinhdrref", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 11763, 2, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 11763, 2, 1);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("addhlp");
                                nvc_HSEG["addhlp"] = sValue;
                                sValue = this.GetValue("address1");
                                nvc_HSEG["address1"] = sValue;
                                sValue = this.GetValue("address2");
                                nvc_HSEG["address2"] = sValue;
                                sValue = this.GetValue("allowancedtls");
                                nvc_HSEG["allowancedtls"] = sValue;
                                sValue = this.GetValue("basic");
                                nvc_HSEG["basic"] = sValue;
                                sValue = this.GetValue("branch");
                                nvc_HSEG["branch"] = sValue;
                                sValue = this.GetValue("checkboxcolumn");
                                nvc_HSEG["checkboxcolumn"] = sValue;
                                sValue = this.GetValue("city");
                                nvc_HSEG["city"] = sValue;
                                sValue = this.GetValue("dateofjoin");
                                if ((sValue != string.Empty))
                                {
                                    sValue = base.DateTimeParse(sValue, "yyyy-MM-dd HH:mm:ss");
                                }
                                nvc_HSEG["dateofjoin"] = sValue;
                                sValue = this.GetValue("deducthlp");
                                nvc_HSEG["deducthlp"] = sValue;
                                sValue = this.GetValue("deductionreason");
                                nvc_HSEG["deductionreason"] = sValue;
                                sValue = this.GetValue("empcode");
                                nvc_HSEG["empcode"] = sValue;
                                sValue = this.GetValue("emplname");
                                nvc_HSEG["emplname"] = sValue;
                                sValue = this.GetValue("esi");
                                nvc_HSEG["esi"] = sValue;
                                sValue = this.GetValue("grosspay");
                                nvc_HSEG["grosspay"] = sValue;
                                sValue = this.GetValue("hra");
                                nvc_HSEG["hra"] = sValue;
                                sValue = this.GetValue("insurancedtls");
                                nvc_HSEG["insurancedtls"] = sValue;
                                sValue = this.GetValue("lta");
                                nvc_HSEG["lta"] = sValue;
                                sValue = this.GetValue("netpay");
                                nvc_HSEG["netpay"] = sValue;
                                sValue = this.GetValue("pf");
                                nvc_HSEG["pf"] = sValue;
                                sValue = this.GetValue("pfdtls");
                                nvc_HSEG["pfdtls"] = sValue;
                                sValue = this.GetValue("pincode");
                                nvc_HSEG["pincode"] = sValue;
                                sValue = this.GetValue("prj_hdn_ctrl");
                                nvc_HSEG["prj_hdn_ctrl"] = sValue;
                                sValue = this.GetValue("reportreq");
                                nvc_HSEG["reportreq"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 11763, 2, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 2 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void FillPlaceHolderValue(ref System.Collections.Hashtable PlaceHolderData, long lInstance)
        {
            System.Exception ex = null;
            try
            {
                System.Collections.Hashtable tempdata = null;
                System.Collections.Specialized.NameValueCollection Localtable = null;
                int count = PlaceHolderData.Count;
                for (int i = 1; (i <= count); i = (i + 1))
                {
                    tempdata = (Hashtable)PlaceHolderData[i];
                    switch (tempdata["SegName"].ToString().ToLower())
                    {
                        case "_hseg":
                            Localtable = nvc_HSEG;
                            break;
                        case "fw_context":
                            Localtable = this.nvcFW_CONTEXT;
                            break;
                        default:
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, "RVWException in FillPlaceHolderValue No NameValueCollection is present for the gi" +
                                    "ven segment name", string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            break;
                    }
                    tempdata["DIValue"] = Localtable[tempdata["DIName"].ToString()];
                    PlaceHolderData[i] = tempdata;
                }
                return;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (System.Exception e)
            {
                base.WriteProfiler(string.Format("{0} - {1}", "General exception in FillPlaceHolderValue", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General exception in FillPlaceHolderValue_{0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private bool Process_MethodError_Info(string szErrDesc, string szErrSource, long SPErrorID, long lInstance, long lMethodId, long lPSSeqNo, long lBRSeqNo)
        {
            CErrorHandler ehs = new CErrorHandler(int.Parse(nvcFW_CONTEXT["language"]));
            long lBRErrorId = 0;
            long lServerity = 0;
            string szErrorMsg = string.Empty;
            string szCorrectiveMsg = string.Empty;
            string szFocusSegName = string.Empty;
            string szFocusDI = string.Empty;
            int iStrPos = 0;
            int iEndPos = 0;
            string ErrDesc = string.Empty;
            string ErrNo = string.Empty;
            base.WriteProfiler("Inside Process_MethodError_Info");
            System.Collections.Hashtable PlaceHolderData = new System.Collections.Hashtable();
            try
            {
                if ((szErrSource != CUtil.APP_ERROR))
                {
                    base.WriteProfiler(string.Format("Error Message:{0}", ErrDesc));
                    base.HandleUnknownError(szErrDesc, ref ErrNo, ref ErrDesc);
                    try
                    {
                        SPErrorID = long.Parse(ErrNo.Trim());
                    }
                    catch (System.Exception)
                    {
                        szErrorMsg = ehs.GetResourceInfo("non_num_err");
                        base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, szErrorMsg, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                    if ((SPErrorID > 0))
                    {
                        try
                        {
                            if ((base.Process_MethodError_Info(szErrDesc, szErrSource, SPErrorID, lInstance, lMethodId, lPSSeqNo, lBRSeqNo) == false))
                            {
                                ehs.EHStcmainsnsrhdrlin(lMethodId, SPErrorID, lInstance, lPSSeqNo, lBRSeqNo, ref lBRErrorId, ref szErrorMsg, ref szCorrectiveMsg, ref lServerity, ref szFocusSegName, ref szFocusDI, ref PlaceHolderData);
                                if ((PlaceHolderData.Count > 0))
                                {
                                    this.FillPlaceHolderValue(ref PlaceHolderData, lInstance);
                                    ehs.ReplaceErrMsg(PlaceHolderData, ref szErrorMsg);
                                }
                                base.Set_Error_Info(lBRErrorId, CUtil.APP_ERROR, lServerity.ToString(), szErrorMsg, szFocusDI, szFocusSegName, lInstance, szCorrectiveMsg, "0");
                            }
                        }
                        catch (CRVWException rvwe)
                        {
                            throw rvwe;
                        }
                        catch (Exception e)
                        {
                            if ((ErrDesc.Length > 0))
                            {
                                szErrorMsg = ErrDesc;
                                base.Set_Error_Info(SPErrorID, szErrSource, CUtil.STOP_PROCESSING, szErrorMsg, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                                return true;
                            }
                            else
                            {
                                szErrorMsg = ehs.GetResourceInfo("err_desc_not_found");
                                base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, string.Format("{0} {1}", szErrorMsg, e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                                return false;
                            }
                        }
                    }
                    else
                    {
                        base.Set_Error_Info(SPErrorID, szErrSource, CUtil.STOP_PROCESSING, szErrDesc, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                }
                else
                {
                    try
                    {
                        if ((base.Process_MethodError_Info(szErrDesc, szErrSource, SPErrorID, lInstance, lMethodId, lPSSeqNo, lBRSeqNo) == false))
                        {
                            ehs.EHStcmainsnsrhdrlin(lMethodId, SPErrorID, lInstance, lPSSeqNo, lBRSeqNo, ref lBRErrorId, ref szErrorMsg, ref szCorrectiveMsg, ref lServerity, ref szFocusSegName, ref szFocusDI, ref PlaceHolderData);
                            if ((PlaceHolderData.Count > 0))
                            {
                                this.FillPlaceHolderValue(ref PlaceHolderData, lInstance);
                                ehs.ReplaceErrMsg(PlaceHolderData, ref szErrorMsg);
                            }
                            base.Set_Error_Info(lBRErrorId, CUtil.APP_ERROR, lServerity.ToString(), szErrorMsg, szFocusDI, szFocusSegName, lInstance, szCorrectiveMsg, "0");
                        }
                    }
                    catch (CRVWException rvwe)
                    {
                        throw rvwe;
                    }
                    catch (Exception e)
                    {
                        szErrorMsg = ehs.GetResourceInfo("err_desc_not_found");
                        base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, string.Format("{0} {1}", szErrorMsg, e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                }
                return true;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General Exception in Process_MethodError Info - {0}", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception in Process_MethodError Info - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return false;
            }
        }
        public virtual void LogMessage(string sContext, string sMessage)
        {
            System.Diagnostics.DefaultTraceListener listener = new System.Diagnostics.DefaultTraceListener();
            string sFileName = "c:\\temp\\tcmainsnsrhdrlin.txt";
            listener.WriteLine(string.Format("{0} : {1}", sContext, sMessage));
            if ((System.IO.File.Exists(sFileName) == true))
            {
                try
                {
                    System.IO.StreamWriter sw = new System.IO.StreamWriter(sFileName, true);
                    sw.WriteLine(string.Format("{0} : {1} : {2}", System.DateTime.Now.ToString(), sContext, sMessage));
                    sw.Close();
                }
                catch (System.Exception e)
                {
                    listener.WriteLine(string.Format("LogMessage : {0}", e.Message));
                }
            }
        }
    }
}

