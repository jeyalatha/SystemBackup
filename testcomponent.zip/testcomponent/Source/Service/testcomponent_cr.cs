/********************************************************************************************************
* Copyright @2004, RAMCO SYSTEMS,  All rights reserved.													
* Application/Module Name   :testcomponent_cr.cs
* Code Generated on         :01/30/2023 16:28:39
* Code Generated From       :ramco/UnitTestProj/TC_ECR_00053/techwarcnv18\inst3/sa/Maint_rvw20appdb/TECHWARCNV18
* Revision/Version #        :
* Purpose                   :
* Modifications             :
* Modifier Name & Date      :
********************************************************************************************************/
using System;
using System.Diagnostics;
using System.Reflection;
using System.EnterpriseServices;
using com.ramco.vw.testcomponent.trans;
using com.ramco.vw.tp.CRUtil;

[assembly: AssemblyDescription("ramco/UnitTestProj/UnitTestProc/TC_ECR_00053/testcomponent/TECHWARCNV18/1/30/2023 4:27:34 PM/F589C7EE-BCD9-48FF-B7E5-5733208F114D")]
[assembly: AssemblyTitle("ramco/UnitTestProj/UnitTestProc/TC_ECR_00053/testcomponent/TECHWARCNV18/1/30/2023 4:27:34 PM/F589C7EE-BCD9-48FF-B7E5-5733208F114D")]
[assembly:ApplicationActivation(ActivationOption.Server)]

[assembly:ApplicationAccessControlAttribute(false,AccessChecksLevel=AccessChecksLevelOption.ApplicationComponent)]
 
namespace com.ramco.vw.testcomponent.cr
{
    [Transaction(TransactionOption.Supported, Isolation = TransactionIsolationLevel.ReadCommitted)]
    [EventTrackingEnabled(true)]

    public class Ctestcomponent_cr : ServicedComponent
    {
        public const int ATMA_SUCCESS = 0;
        public const int ATMA_FAILURE = 999;
        public const int ATMA_INVALID_SERVICE = 998;
        DefaultTraceListener output = new DefaultTraceListener();

        public int ProcessDocument(string szInMtd, string szServiceName, string szSessionToken, ref string szOutMtd)
        {
            try
            {
                szOutMtd = "";
                switch (szServiceName.ToLower().Trim())
                {
					case ("tcbractsr_hp_custah"):
                        using (Ctestcomponent1 testcomponent1 = new Ctestcomponent1())
                        {
                            if (testcomponent1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("TESTCOMPONENT.Ctestcomponent_cr.ProcessDocument - tcbractsr_hp_custah service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - tcbractsr_hp_custah service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("tcbractsrcustat"):
                        using (Ctestcomponent1 testcomponent1 = new Ctestcomponent1())
                        {
                            if (testcomponent1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("TESTCOMPONENT.Ctestcomponent_cr.ProcessDocument - tcbractsrcustat service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - tcbractsrcustat service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("tcbractsrfet"):
                        using (Ctestcomponent0 testcomponent0 = new Ctestcomponent0())
                        {
                            if (testcomponent0.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("TESTCOMPONENT.Ctestcomponent_cr.ProcessDocument - tcbractsrfet service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - tcbractsrfet service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("tcbractsrlinkcu"):
                        using (Ctestcomponent1 testcomponent1 = new Ctestcomponent1())
                        {
                            if (testcomponent1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("TESTCOMPONENT.Ctestcomponent_cr.ProcessDocument - tcbractsrlinkcu service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - tcbractsrlinkcu service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("tcbractsrpopcon"):
                        using (Ctestcomponent1 testcomponent1 = new Ctestcomponent1())
                        {
                            if (testcomponent1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("TESTCOMPONENT.Ctestcomponent_cr.ProcessDocument - tcbractsrpopcon service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - tcbractsrpopcon service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("tcbractsrsave1"):
                        using (Ctestcomponent1 testcomponent1 = new Ctestcomponent1())
                        {
                            if (testcomponent1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("TESTCOMPONENT.Ctestcomponent_cr.ProcessDocument - tcbractsrsave1 service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - tcbractsrsave1 service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("tcbractsrsmartv"):
                        using (Ctestcomponent1 testcomponent1 = new Ctestcomponent1())
                        {
                            if (testcomponent1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("TESTCOMPONENT.Ctestcomponent_cr.ProcessDocument - tcbractsrsmartv service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - tcbractsrsmartv service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("tcbractsrtestli"):
                        using (Ctestcomponent1 testcomponent1 = new Ctestcomponent1())
                        {
                            if (testcomponent1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("TESTCOMPONENT.Ctestcomponent_cr.ProcessDocument - tcbractsrtestli service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - tcbractsrtestli service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("tcmacreesrfet"):
                        using (Ctestcomponent0 testcomponent0 = new Ctestcomponent0())
                        {
                            if (testcomponent0.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("TESTCOMPONENT.Ctestcomponent_cr.ProcessDocument - tcmacreesrfet service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - tcmacreesrfet service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("tcmacreesrsubmit"):
                        using (Ctestcomponent1 testcomponent1 = new Ctestcomponent1())
                        {
                            if (testcomponent1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("TESTCOMPONENT.Ctestcomponent_cr.ProcessDocument - tcmacreesrsubmit service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - tcmacreesrsubmit service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("tcmains3sremploy"):
                        using (Ctestcomponent1 testcomponent1 = new Ctestcomponent1())
                        {
                            if (testcomponent1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("TESTCOMPONENT.Ctestcomponent_cr.ProcessDocument - tcmains3sremploy service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - tcmains3sremploy service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("tcmains3srfet"):
                        using (Ctestcomponent0 testcomponent0 = new Ctestcomponent0())
                        {
                            if (testcomponent0.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("TESTCOMPONENT.Ctestcomponent_cr.ProcessDocument - tcmains3srfet service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - tcmains3srfet service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("tcmains3srinit"):
                        using (Ctestcomponent0 testcomponent0 = new Ctestcomponent0())
                        {
                            if (testcomponent0.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("TESTCOMPONENT.Ctestcomponent_cr.ProcessDocument - tcmains3srinit service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - tcmains3srinit service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("tcmainscsrbubbu2"):
                        using (Ctestcomponent0 testcomponent0 = new Ctestcomponent0())
                        {
                            if (testcomponent0.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("TESTCOMPONENT.Ctestcomponent_cr.ProcessDocument - tcmainscsrbubbu2 service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - tcmainscsrbubbu2 service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("tcmainscsrbubman"):
                        using (Ctestcomponent1 testcomponent1 = new Ctestcomponent1())
                        {
                            if (testcomponent1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("TESTCOMPONENT.Ctestcomponent_cr.ProcessDocument - tcmainscsrbubman service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - tcmainscsrbubman service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("tcmainscsrbubref"):
                        using (Ctestcomponent1 testcomponent1 = new Ctestcomponent1())
                        {
                            if (testcomponent1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("TESTCOMPONENT.Ctestcomponent_cr.ProcessDocument - tcmainscsrbubref service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - tcmainscsrbubref service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("tcmainscsrfet"):
                        using (Ctestcomponent0 testcomponent0 = new Ctestcomponent0())
                        {
                            if (testcomponent0.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("TESTCOMPONENT.Ctestcomponent_cr.ProcessDocument - tcmainscsrfet service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - tcmainscsrfet service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("tcmainscsrsave1"):
                        using (Ctestcomponent1 testcomponent1 = new Ctestcomponent1())
                        {
                            if (testcomponent1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("TESTCOMPONENT.Ctestcomponent_cr.ProcessDocument - tcmainscsrsave1 service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - tcmainscsrsave1 service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("tcmainscsrtestbu"):
                        using (Ctestcomponent0 testcomponent0 = new Ctestcomponent0())
                        {
                            if (testcomponent0.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("TESTCOMPONENT.Ctestcomponent_cr.ProcessDocument - tcmainscsrtestbu service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - tcmainscsrtestbu service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("tcmainsesrfet"):
                        using (Ctestcomponent0 testcomponent0 = new Ctestcomponent0())
                        {
                            if (testcomponent0.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("TESTCOMPONENT.Ctestcomponent_cr.ProcessDocument - tcmainsesrfet service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - tcmainsesrfet service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("tcmainsnsr_hp_addhlp"):
                        using (Ctestcomponent1 testcomponent1 = new Ctestcomponent1())
                        {
                            if (testcomponent1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("TESTCOMPONENT.Ctestcomponent_cr.ProcessDocument - tcmainsnsr_hp_addhlp service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - tcmainsnsr_hp_addhlp service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("tcmainsnsr_hp_deduch"):
                        using (Ctestcomponent1 testcomponent1 = new Ctestcomponent1())
                        {
                            if (testcomponent1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("TESTCOMPONENT.Ctestcomponent_cr.ProcessDocument - tcmainsnsr_hp_deduch service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - tcmainsnsr_hp_deduch service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("tcmainsnsr_hp_edithe"):
                        using (Ctestcomponent1 testcomponent1 = new Ctestcomponent1())
                        {
                            if (testcomponent1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("TESTCOMPONENT.Ctestcomponent_cr.ProcessDocument - tcmainsnsr_hp_edithe service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - tcmainsnsr_hp_edithe service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("tcmainsnsrfet"):
                        using (Ctestcomponent0 testcomponent0 = new Ctestcomponent0())
                        {
                            if (testcomponent0.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("TESTCOMPONENT.Ctestcomponent_cr.ProcessDocument - tcmainsnsrfet service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - tcmainsnsrfet service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("tcmainsnsrhdrlin"):
                        using (Ctestcomponent1 testcomponent1 = new Ctestcomponent1())
                        {
                            if (testcomponent1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("TESTCOMPONENT.Ctestcomponent_cr.ProcessDocument - tcmainsnsrhdrlin service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - tcmainsnsrhdrlin service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("tcmainsnsrinit"):
                        using (Ctestcomponent0 testcomponent0 = new Ctestcomponent0())
                        {
                            if (testcomponent0.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("TESTCOMPONENT.Ctestcomponent_cr.ProcessDocument - tcmainsnsrinit service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - tcmainsnsrinit service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("tcmainsnsrlinkco"):
                        using (Ctestcomponent1 testcomponent1 = new Ctestcomponent1())
                        {
                            if (testcomponent1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("TESTCOMPONENT.Ctestcomponent_cr.ProcessDocument - tcmainsnsrlinkco service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - tcmainsnsrlinkco service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("tcmainsnsrlnkctr"):
                        using (Ctestcomponent1 testcomponent1 = new Ctestcomponent1())
                        {
                            if (testcomponent1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("TESTCOMPONENT.Ctestcomponent_cr.ProcessDocument - tcmainsnsrlnkctr service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - tcmainsnsrlnkctr service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("tcmainsnsrsavebt"):
                        using (Ctestcomponent1 testcomponent1 = new Ctestcomponent1())
                        {
                            if (testcomponent1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("TESTCOMPONENT.Ctestcomponent_cr.ProcessDocument - tcmainsnsrsavebt service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - tcmainsnsrsavebt service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("tcmainsnsrsavete"):
                        using (Ctestcomponent1 testcomponent1 = new Ctestcomponent1())
                        {
                            if (testcomponent1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("TESTCOMPONENT.Ctestcomponent_cr.ProcessDocument - tcmainsnsrsavete service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - tcmainsnsrsavete service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("tcmnscnsrfet"):
                        using (Ctestcomponent0 testcomponent0 = new Ctestcomponent0())
                        {
                            if (testcomponent0.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("TESTCOMPONENT.Ctestcomponent_cr.ProcessDocument - tcmnscnsrfet service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - tcmnscnsrfet service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("tcmnscnsrsave"):
                        using (Ctestcomponent1 testcomponent1 = new Ctestcomponent1())
                        {
                            if (testcomponent1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("TESTCOMPONENT.Ctestcomponent_cr.ProcessDocument - tcmnscnsrsave service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - tcmnscnsrsave service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("tcmnscrnsrfet"):
                        using (Ctestcomponent0 testcomponent0 = new Ctestcomponent0())
                        {
                            if (testcomponent0.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("TESTCOMPONENT.Ctestcomponent_cr.ProcessDocument - tcmnscrnsrfet service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - tcmnscrnsrfet service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("tcmnscrnsrsave"):
                        using (Ctestcomponent1 testcomponent1 = new Ctestcomponent1())
                        {
                            if (testcomponent1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("TESTCOMPONENT.Ctestcomponent_cr.ProcessDocument - tcmnscrnsrsave service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - tcmnscrnsrsave service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					default:
                        int iType = -1;
                        string szPSXmlPath = string.Empty;
                        CRUtil.PassiveServiceCheck(szServiceName, ref iType, ref szPSXmlPath);
                        switch (iType)
                        {
                            case 0:
                                using (Ctestcomponent0 testcomponent0 = new Ctestcomponent0())
                                {
                                    if (testcomponent0.PassiveProcessDocument(szInMtd, szPSXmlPath, szSessionToken, out szOutMtd) == 0)
                                    {
                                        output.WriteLine("testcomponent.Ctestcomponent_cr.PassiveProcessDocument - " + szServiceName + " service executed successfully.");
                                        return ATMA_SUCCESS;
                                    }
                                    else
                                    {
                                        output.WriteLine("Ctestcomponent_cr.PassiveProcessDocument - " + szServiceName + " service executed with a failure.");
                                        return ATMA_FAILURE;
                                    }
                                }
                            case 1:
                                using (Ctestcomponent1 testcomponent1 = new Ctestcomponent1())
                                {
                                    if (testcomponent1.PassiveProcessDocument(szInMtd, szPSXmlPath, szSessionToken, out szOutMtd) == 0)
                                    {
                                        output.WriteLine("testcomponent.Ctestcomponent_cr.ProcessDocument - " + szServiceName + " service executed successfully.");
                                        return ATMA_SUCCESS;
                                    }
                                    else
                                    {
                                        output.WriteLine("Ctestcomponent_cr.PassiveProcessDocument - " + szServiceName + " service executed with a failure.");
                                        return ATMA_FAILURE;
                                    }
                                }
                            default:
                                output.WriteLine("Ctestcomponent_cr.ProcessDocument - Service referred Is Not part of the runtime component-" + szServiceName);
                                return ATMA_INVALID_SERVICE;
                        }
                }
            }
            catch (Exception e)
            {
                output.WriteLine("Ctestcomponent_cr.ProcessDocument - General Exception :");
                output.WriteLine(e.Message);
                szOutMtd = "";
                return ATMA_FAILURE;
            }
            finally
            {
                base.Dispose(true);
            }
        }

        public Ctestcomponent_cr()
        {
        }
    }
}
