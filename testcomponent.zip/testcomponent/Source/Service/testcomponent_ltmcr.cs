/********************************************************************************************************
* Copyright @2004, RAMCO SYSTEMS,  All rights reserved.													
* Application/Module Name   :testcomponent_ltmcr.cs
* Code Generated on         :01/30/2023 16:28:39
* Code Generated From       :ramco/UnitTestProj/TC_ECR_00053/techwarcnv18\inst3/sa/Maint_rvw20appdb/TECHWARCNV18
* Revision/Version #        :
* Purpose                   :
* Modifications             :
* Modifier Name & Date      :
********************************************************************************************************/
using System;
using System.Reflection;
using System.Diagnostics;
[assembly: AssemblyDescription("ramco/UnitTestProj/TC_ECR_00053/techwarcnv18-inst3/sa/Maint_rvw20appdb/TECHWARCNV18/1/30/2023")]
//transction scope - Dotnet ltm transaction scope - 0 - Required, 1 - Required New, 2 - Supported
// model scope - 0 Supported, 1 - Required
//outZBytes - true - zipped byte[]  , false - string
//tdFormat = 0 - String , 1- JSON , 2-Dataset
namespace com.ramco.vw.testcomponent.service
{
	public class Ctestcomponent_ltmcr
	{
		public const int ATMA_SUCCESS = 0;
		public const int ATMA_FAILURE = 999;
		public const int ATMA_INVALID_SERVICE = 998;


		public int ProcessDocument(string szInMtd, string szServiceName, string szSessionToken, bool outZBytes, int tdFormat, ref string szOutMtd, ref byte[] byteOutMtd)
		{
			DefaultTraceListener output = new DefaultTraceListener();
			try
			{
				szOutMtd = "";
				byteOutMtd = null;

				Ctestcomponent_ltm ctestcomponent_ltm = new Ctestcomponent_ltm();
				switch (szServiceName.ToLower().Trim())
				{
					case("tcbractsr_hp_custah"):
						output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcbractsr_hp_custah service started.");
						if (ctestcomponent_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcbractsr_hp_custah service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcbractsr_hp_custah service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("tcbractsrcustat"):
						output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcbractsrcustat service started.");
						if (ctestcomponent_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcbractsrcustat service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcbractsrcustat service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("tcbractsrfet"):
						output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcbractsrfet service started.");
						if (ctestcomponent_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcbractsrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcbractsrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("tcbractsrlinkcu"):
						output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcbractsrlinkcu service started.");
						if (ctestcomponent_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcbractsrlinkcu service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcbractsrlinkcu service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("tcbractsrpopcon"):
						output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcbractsrpopcon service started.");
						if (ctestcomponent_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcbractsrpopcon service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcbractsrpopcon service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("tcbractsrsave1"):
						output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcbractsrsave1 service started.");
						if (ctestcomponent_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcbractsrsave1 service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcbractsrsave1 service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("tcbractsrsmartv"):
						output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcbractsrsmartv service started.");
						if (ctestcomponent_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcbractsrsmartv service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcbractsrsmartv service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("tcbractsrtestli"):
						output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcbractsrtestli service started.");
						if (ctestcomponent_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcbractsrtestli service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcbractsrtestli service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("tcmacreesrfet"):
						output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmacreesrfet service started.");
						if (ctestcomponent_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmacreesrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmacreesrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("tcmacreesrsubmit"):
						output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmacreesrsubmit service started.");
						if (ctestcomponent_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmacreesrsubmit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmacreesrsubmit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("tcmains3sremploy"):
						output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmains3sremploy service started.");
						if (ctestcomponent_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmains3sremploy service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmains3sremploy service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("tcmains3srfet"):
						output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmains3srfet service started.");
						if (ctestcomponent_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmains3srfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmains3srfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("tcmains3srinit"):
						output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmains3srinit service started.");
						if (ctestcomponent_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmains3srinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmains3srinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("tcmainscsrbubbu2"):
						output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainscsrbubbu2 service started.");
						if (ctestcomponent_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainscsrbubbu2 service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainscsrbubbu2 service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("tcmainscsrbubman"):
						output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainscsrbubman service started.");
						if (ctestcomponent_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainscsrbubman service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainscsrbubman service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("tcmainscsrbubref"):
						output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainscsrbubref service started.");
						if (ctestcomponent_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainscsrbubref service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainscsrbubref service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("tcmainscsrfet"):
						output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainscsrfet service started.");
						if (ctestcomponent_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainscsrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainscsrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("tcmainscsrsave1"):
						output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainscsrsave1 service started.");
						if (ctestcomponent_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainscsrsave1 service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainscsrsave1 service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("tcmainscsrtestbu"):
						output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainscsrtestbu service started.");
						if (ctestcomponent_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainscsrtestbu service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainscsrtestbu service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("tcmainsesrfet"):
						output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainsesrfet service started.");
						if (ctestcomponent_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainsesrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainsesrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("tcmainsnsr_hp_addhlp"):
						output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainsnsr_hp_addhlp service started.");
						if (ctestcomponent_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainsnsr_hp_addhlp service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainsnsr_hp_addhlp service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("tcmainsnsr_hp_deduch"):
						output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainsnsr_hp_deduch service started.");
						if (ctestcomponent_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainsnsr_hp_deduch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainsnsr_hp_deduch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("tcmainsnsr_hp_edithe"):
						output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainsnsr_hp_edithe service started.");
						if (ctestcomponent_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainsnsr_hp_edithe service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainsnsr_hp_edithe service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("tcmainsnsrfet"):
						output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainsnsrfet service started.");
						if (ctestcomponent_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainsnsrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainsnsrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("tcmainsnsrhdrlin"):
						output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainsnsrhdrlin service started.");
						if (ctestcomponent_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainsnsrhdrlin service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainsnsrhdrlin service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("tcmainsnsrinit"):
						output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainsnsrinit service started.");
						if (ctestcomponent_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainsnsrinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainsnsrinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("tcmainsnsrlinkco"):
						output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainsnsrlinkco service started.");
						if (ctestcomponent_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainsnsrlinkco service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainsnsrlinkco service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("tcmainsnsrlnkctr"):
						output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainsnsrlnkctr service started.");
						if (ctestcomponent_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainsnsrlnkctr service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainsnsrlnkctr service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("tcmainsnsrsavebt"):
						output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainsnsrsavebt service started.");
						if (ctestcomponent_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainsnsrsavebt service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainsnsrsavebt service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("tcmainsnsrsavete"):
						output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainsnsrsavete service started.");
						if (ctestcomponent_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainsnsrsavete service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmainsnsrsavete service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("tcmnscnsrfet"):
						output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmnscnsrfet service started.");
						if (ctestcomponent_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmnscnsrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmnscnsrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("tcmnscnsrsave"):
						output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmnscnsrsave service started.");
						if (ctestcomponent_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmnscnsrsave service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmnscnsrsave service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("tcmnscrnsrfet"):
						output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmnscrnsrfet service started.");
						if (ctestcomponent_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmnscrnsrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmnscrnsrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("tcmnscrnsrsave"):
						output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmnscrnsrsave service started.");
						if (ctestcomponent_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmnscrnsrsave service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("TESTCOMPONENT.Ctestcomponent_ltmcr.ProcessDocument - tcmnscrnsrsave service executed with a failure.");
							return ATMA_FAILURE;
						}
					default:
						output.WriteLine("Ctestcomponent_ltmcr.ProcessDocument - Service referred Is Not part of the runtime component-" + szServiceName);
						return ATMA_INVALID_SERVICE;
				}
			}
			catch (Exception e)
			{
				output.WriteLine("Ctestcomponent_ltmcr.ProcessDocument - General Exception :");
				output.WriteLine(e.Message);
				szOutMtd = "";
				return ATMA_FAILURE;
			}
			finally
			{
			}
		}
	}
}
