/********************************************************************************************************
* Copyright @2004, RAMCO SYSTEMS,  All rights reserved.													
* Application/Module Name   :testcomponent_rb.cs
* Code Generated on         :01/30/2023 16:28:39
* Code Generated From       :ramco/UnitTestProj/TC_ECR_00053/techwarcnv18\inst3/sa/Maint_rvw20appdb/TECHWARCNV18
* Revision/Version #        :
* Purpose                   :
* Modifications             :
* Modifier Name & Date      :
********************************************************************************************************/
using System;
using System.Reflection;
using System.EnterpriseServices;
using System.Diagnostics;
using System.Runtime.Remoting;
[assembly:ApplicationActivation(ActivationOption.Server)]
[assembly:ApplicationAccessControlAttribute(false,AccessChecksLevel=AccessChecksLevelOption.ApplicationComponent)]
namespace com.ramco.vw.testcomponent.trans
{
    [Transaction(TransactionOption.RequiresNew,Isolation = TransactionIsolationLevel.ReadCommitted)]
    [EventTrackingEnabled(true)]
    public class Ctestcomponent_rb :ServicedComponent
    {
        public const int ATMA_SUCCESS = 0;
        public const int ATMA_FAILURE = 999;
        DefaultTraceListener output = new DefaultTraceListener();
		public Ctestcomponent_rb()
        {

        }
        public int ProcessDocument(string szInMtd,string szServiceName ,string szSessionToken ,out string szOutMtd)
        {
            try
            {
                szOutMtd = "";
                Type myType = Type.GetType("com.ramco.vw.testcomponent.service.C"+szServiceName.Trim().ToLower()+"_RB");
                object myObject = Activator.CreateInstance(myType); 
                object[] args = new object[]{szInMtd,szSessionToken,szOutMtd};
                ParameterModifier pm = new ParameterModifier(3);
                pm[0] = false;
                pm[1] = false;
                pm[2] = true;
                ParameterModifier[] mods= {pm};
                object c = myType.InvokeMember("ProcessService", BindingFlags.InvokeMethod,null, myObject, args, mods, null, null);
                szOutMtd = args[2].ToString();
                if ((int)c == ATMA_FAILURE)
                {
                    ContextUtil.SetAbort();
                    return ATMA_FAILURE;
                }
                else if ((int)c == ATMA_SUCCESS)
                {
                    ContextUtil.SetComplete();
                    return ATMA_SUCCESS;
                }
            }
            catch(Exception e)
            {
               output.WriteLine("Ctestcomponent1.ProcessDocument - General Exception :");
               output.WriteLine(e.Message);
               szOutMtd = "";
               ContextUtil.SetAbort();
               return ATMA_FAILURE;
             }
             finally
             {
                 output.Dispose();
                 base.Dispose(true);
             }
            return ATMA_SUCCESS;
          }
    }
}
