/********************************************************************************************************
* Copyright @2004, RAMCO SYSTEMS,  All rights reserved.													
* Application/Module Name   :testcomponent_ltm.cs
* Code Generated on         :01/30/2023 16:28:39
* Code Generated From       :ramco/UnitTestProj/TC_ECR_00053/techwarcnv18\inst3/sa/Maint_rvw20appdb/TECHWARCNV18
* Revision/Version #        :
* Purpose                   :
* Modifications             :
* Modifier Name & Date      :
********************************************************************************************************/
using System;
using System.Reflection;
using System.Diagnostics;
using System.Transactions;
using Ramco.VW.RT.GatewayServer.VWService;
using VirtualWorksRT.tp.Utilities;
namespace com.ramco.vw.testcomponent.service
{
//transction scope - Dotnet ltm transaction scrope - 0 - Required, 1 - Required New, 2 - Supported
//outZBytes - true - zipped byte[]  , false - string
//tdFormat = 0 - String , 1- JSON , 2-Dataset
	public class Ctestcomponent_ltm
	{
		public const int ATMA_SUCCESS = 0;
		public const int ATMA_FAILURE = 999;

		public int ProcessDocument(string szInMtd, string szServiceName, string szSessionToken, int transactionScope, bool outZBytes, int tdFormat, out string szOutMtd, out byte[] byteOutMtd)
		{
			DefaultTraceListener output = new DefaultTraceListener();
			try
			{
				output.WriteLine("Ctestcomponent_ltm.ProcessDocument Begin - :" + szServiceName );
				VWComponentProperties vwComponentProperties = VWHelper.GetVWComponentProperties("testcomponent", szServiceName, transactionScope);
				using (TransactionScope scope = new TransactionScope(vwComponentProperties.TransScopeOption, vwComponentProperties.TransOptions))
				{
					szOutMtd = "";
					byteOutMtd = null;
					object returnVal = null;
					ParameterModifier pm;
					object[] args = null;

					Type myType = Type.GetType("com.ramco.vw.testcomponent.service.C" + szServiceName.Trim().ToLower());
					object myObject = Activator.CreateInstance(myType);

					if (outZBytes == true)
					{//zipped byte td
						output.WriteLine("Ctestcomponent_ltm.ProcessDocument OutTd to be processed as ByteArray format for service : " + szServiceName);
						args = new object[] { szInMtd, szSessionToken, false, byteOutMtd };


						pm = new ParameterModifier(4);
						pm[0] = false;
						pm[1] = false;
						pm[2] = false;
						pm[3] = true;
						ParameterModifier[] mods = { pm };
						returnVal = myType.InvokeMember("ProcessZippedService", BindingFlags.InvokeMethod, null, myObject, args, mods, null, null);
						byteOutMtd = (byte[])args[3];
					}
					else
					{//string td
						output.WriteLine("Ctestcomponent_ltm.ProcessDocument OutTd to be processed as String format for service : " + szServiceName);
						args = new object[] { szInMtd, szSessionToken, szOutMtd };
						pm = new ParameterModifier(3);
						pm[0] = false;
						pm[1] = false;
						pm[2] = true;
						ParameterModifier[] mods = { pm };
						returnVal = myType.InvokeMember("ProcessService", BindingFlags.InvokeMethod, null, myObject, args, mods, null, null);
						szOutMtd = args[2].ToString();
					}


					if ((int)returnVal == ATMA_FAILURE)
					{
						output.WriteLine("Ctestcomponent_ltm.ProcessDocument End failure - :" + szServiceName);
						return ATMA_FAILURE;
					}
					else if ((int)returnVal == ATMA_SUCCESS && szOutMtd.Length != 0)
					{
						scope.Complete();
						output.WriteLine("Ctestcomponent_ltm.ProcessDocument End success - :" + szServiceName);
						return ATMA_SUCCESS;
					}
				}
			}
			catch(Exception e)
			{
				output.WriteLine("Ctestcomponent_ltm.ProcessDocument - General Exception :"  + szServiceName + " - " + e.Message);
				szOutMtd = "";
				byteOutMtd = null;
				return ATMA_FAILURE;
			}
			finally
			{
				output.Dispose();
			}
			return ATMA_SUCCESS;
		}
	}
}
