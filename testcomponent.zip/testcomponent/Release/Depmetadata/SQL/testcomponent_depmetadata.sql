IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME ='testcomponent_Metadata' AND XTYPE='P')
BEGIN	DROP PROC testcomponent_Metadata
End
GO
Create Procedure testcomponent_Metadata 
	@ActivityOffset numeric(10,0) = 0,
	@UpdateFlag  integer = 0
As
Begin
SET NOCOUNT ON
-- This Deployment script is generated from Platform Model Server : TECHWARCNV18\INST3 Database Name : Maint_rvw20appdb Component : testcomponent ECR  : TC_ECR_00053
create table #fw_admin_activity_offset (ComponentName nvarchar(40), ActivityOffset int, UpdUser nvarchar(20), UpdTime datetime)
create table #fw_admin_dep_components_tmp (ComponentName nvarchar(40), DepComponentName nvarchar(40), IntegLayer smallint, UpdUser nvarchar(20), UpdTime datetime)
create table #fw_req_process_component (ComponentName nvarchar(40), ComponentDesc nvarchar(256), ParentProcess nvarchar(40), UpdUser nvarchar(20), UpdTime datetime, SequenceNo int null)
create table #fw_req_activity (ActivityId int, ActivityName nvarchar(40), ActivityDesc nvarchar(256), ComponentName nvarchar(40), ActivityType tinyint, ActivityPosition tinyint, ActivitySequence int, IsWFEnabled tinyint, UpdUser nvarchar(20), UpdT

ime datetime, IsForcedActivity tinyint )
create table #fw_req_ilbo (ilbocode  nvarchar(200), description  nvarchar(510), ASPOFilePath nvarchar(510), progid nvarchar(256), ILBOType tinyint, StatusFlag tinyint, req_2fa_tran tinyint, UpdUser nvarchar(20), UpdTime datetime)
create table #fw_req_activity_ilbo (ActivityId int,ActivityName nvarchar(40), ilbocode  nvarchar(200), UpdUser nvarchar(20), UpdTime datetime)
create table #fw_req_activity_local_info (ActivityId int,ActivityName nvarchar(40), LangId tinyint, ActivityDesc nvarchar(256), HelpIndex int null, ToolTipText nvarchar(256) Null, UpdUser nvarchar(20), UpdTime datetime)
create table #fw_req_component_local_info (ComponentName nvarchar(40), LangId tinyint, ComponentDesc nvarchar(256), HelpFileName nvarchar(510) null, ToolTipText nvarchar(256) Null, UpdUser nvarchar(20), UpdTime datetime)
create table #fw_des_service (ServiceName nvarchar(64), ComponentName nvarchar(40), ServiceType tinyint, IsIntegSer tinyint, StatusFlag tinyint, UpdUser nvarchar(20), UpdTime datetime, ToValidate tinyint)
create table #fw_admin_Activity_Service (ActivityId int,ActivityName nvarchar(40), ServiceName nvarchar(64), UpdUser nvarchar(20), UpdTime datetime)
create table #fw_req_task (TaskName nvarchar(100), TaskType nchar(20), TaskDesc nvarchar(256), UpdUser nvarchar(20), UpdTime datetime)
create table #fw_req_activity_task (ActivityId int, ActivityName nvarchar(40), TaskName nchar(100), InvocationType tinyint, TaskSequence int, UpdUser nvarchar(20), UpdTime datetime)
create table #fw_req_activity_ilbo_task (ActivityId int, ActivityName nvarchar(40), ILBOCode nvarchar(200), TaskName nchar(100), UpdUser nvarchar(20), UpdTime datetime, DataSavingTask tinyint, LinkType tinyint, Taskconfirmation tinyint)
create table #fw_req_precision (PrecisionType nchar(20), TotalLength tinyint, DecimalLength tinyint, UpdUser nvarchar(20), UpdTime datetime)
create table #fw_admin_linked_activities (ActivityName nvarchar(40),LinkedActivityName nvarchar(40), ActivityID int, LinkedActivityID int)
create table #fw_req_activity_ilbo_task_local_info (ActivityId int, ActivityName nvarchar(40), ILBOCode nvarchar(200), ILBODescription  nvarchar(510) ,TaskName nvarchar(100) ,TaskDesc nvarchar(256),LangId tinyint , UpdUser nvarchar(20), UpdTime da

tetime)
create table #fw_admin_meta_state (ActivityName nvarchar(60), ILBOCode nvarchar(60), ControlID  nvarchar(60) ,ControlDesc nvarchar(255), ViewName nvarchar(60), ViewDesc nvarchar(255), TabName nvarchar(60), Tabdesc nvarchar(255), IsHeaderControl in

t)
create table #fw_admin_application_dtl (DepConfiguredAppName nvarchar(200), ApplicationDescription nvarchar(200), ApplicationMode  nvarchar(20) ,UpdUser  nvarchar(40) ,UpdTime datetime)
create table #fw_admin_application_activity_map (DepConfiguredAppName nvarchar(200), ActivityName nvarchar(40), UpdUser  nvarchar(40) ,UpdTime datetime)
if exists (select '*' from sysobjects (nolock) where name = 'fw_req_ilbo_control')
begin
create table #fw_req_ilbo_control (ilbocode nvarchar(100), ControlID nvarchar(32), Type nvarchar(32), tabname nvarchar(32), UpdUser nvarchar(20),UpdTime datetime)
end
IF EXISTS (SELECT '*' FROM INFORMATION_SCHEMA.COLUMNS (nolock) WHERE  TABLE_NAME = 'fw_req_activity_ilbo_task' AND COLUMN_NAME = 'ServiceName')
BEGIN
alter table #fw_req_activity_ilbo_task add  ServiceName nvarchar(64)
END
create table #fw_req_activity_ilbo_task_apispec (ActivityId int, ActivityName nvarchar(40), ILBOCode nvarchar(200), TaskName nchar(100), ApiSpecID tinyint, ApiSpecName nchar(100), ApiVersion tinyint, ApiPath nchar(100), ApiOperationVerb nchar(100)

, ApiOperationID nchar(100), ThirdParty nchar(100), UpdUser nvarchar(20), UpdTime datetime)
----------------------------------------------------------------------------------------------------------------------------------------------
insert into #fw_admin_activity_offset
		(ComponentName, ActivityOffset, UpdUser, UpdTime)
Values
		('testcomponent',0,'Installer', getdate())
----------------------------------------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------------------
insert into #fw_req_process_component
		(ComponentName , ComponentDesc , ParentProcess , UpdUser , UpdTime , SequenceNo)
values
		('TestComponent', 'TestComponent', 'UnitTestProc', 'Installer', getdate() , 2                             )
----------------------------------------------------------------------------------------------------------------------------------------------
insert into #fw_req_activity
		(ActivityId, ActivityName, ActivityDesc, ComponentName, ActivityType, ActivityPosition, ActivitySequence, IsWFEnabled, UpdUser, UpdTime,IsForcedActivity)
valu


es
		(299, 'TestActivity',N'TestActivity', 'TestComponent', 1, 1, 2, 1, 'Installer', getdate(),0 )
insert into #fw_req_activity
		(ActivityId, ActivityName, ActivityDesc, ComponentName, ActivityType, ActivityPosition, ActivitySequence, IsWFEnabled, UpdUser, UpdTime,IsForcedActivity)
valu


es
		(304, 'LineActivity',N'LineActivity', 'TestComponent', 1, 1, 3, 1, 'Installer', getdate(),0 )
insert into #fw_req_activity
		(ActivityId, ActivityName, ActivityDesc, ComponentName, ActivityType, ActivityPosition, ActivitySequence, IsWFEnabled, UpdUser, UpdTime,IsForcedActivity)
valu


es
		(305, 'CustomAction',N'Custom Action', 'TestComponent', 1, 1, 4, 1, 'Installer', getdate(),0 )
insert into #fw_req_activity
		(ActivityId, ActivityName, ActivityDesc, ComponentName, ActivityType, ActivityPosition, ActivitySequence, IsWFEnabled, UpdUser, UpdTime,IsForcedActivity)
valu


es
		(307, 'BorderAction',N'Border Action', 'TestComponent', 1, 1, 5, 1, 'Installer', getdate(),0 )
insert into #fw_req_activity
		(ActivityId, ActivityName, ActivityDesc, ComponentName, ActivityType, ActivityPosition, ActivitySequence, IsWFEnabled, UpdUser, UpdTime,IsForcedActivity)
valu


es
		(309, 'TestEnhance',N'TestEnhance', 'TestComponent', 1, 1, 11, 1, 'Installer', getdate(),0 )
insert into #fw_req_activity
		(ActivityId, ActivityName, ActivityDesc, ComponentName, ActivityType, ActivityPosition, ActivitySequence, IsWFEnabled, UpdUser, UpdTime,IsForcedActivity)
valu


es
		(310, 'CustomAct',N'Custom Activity', 'TestComponent', 1, 1, 10, 1, 'Installer', getdate(),0 )
insert into #fw_req_activity
		(ActivityId, ActivityName, ActivityDesc, ComponentName, ActivityType, ActivityPosition, ActivitySequence, IsWFEnabled, UpdUser, UpdTime,IsForcedActivity)
valu


es
		(311, 'TestToolbar',N'TestToolbar', 'TestComponent', 1, 1, 12, 1, 'Installer', getdate(),0 )
insert into #fw_req_activity
		(ActivityId, ActivityName, ActivityDesc, ComponentName, ActivityType, ActivityPosition, ActivitySequence, IsWFEnabled, UpdUser, UpdTime,IsForcedActivity)
valu


es
		(325, 'ColumnGrouping',N'Column  Grouping', 'TestComponent', 1, 1, 14, 1, 'Installer', getdate(),0 )
insert into #fw_req_activity
		(ActivityId, ActivityName, ActivityDesc, ComponentName, ActivityType, ActivityPosition, ActivitySequence, IsWFEnabled, UpdUser, UpdTime,IsForcedActivity)
valu


es
		(335, 'ListViewAct',N'ListViewAct', 'TestComponent', 1, 1, 16, 1, 'Installer', getdate(),0 )
----------------------------------------------------------------------------------------------------------------------------------------------
insert into #fw_req_ilbo
		(ilbocode, description, ASPOFilePath, progid, ILBOType, StatusFlag, req_2fa_tran, UpdUser, UpdTime)
values
		('BorderActionui','BorderActionui','BorderAction_BorderActionui.asp','','2','0','0','dbo','2023-01-30')
insert into #fw_req_ilbo
		(ilbocode, description, ASPOFilePath, progid, ILBOType, StatusFlag, req_2fa_tran, UpdUser, UpdTime)
values
		('BorderRef','BorderRef','BorderAction_BorderRef.asp','','3','0','0','dbo','2023-01-30')
insert into #fw_req_ilbo
		(ilbocode, description, ASPOFilePath, progid, ILBOType, StatusFlag, req_2fa_tran, UpdUser, UpdTime)
values
		('ColgroupUI','Column Grouping','ColumnGrouping_ColgroupUI.asp','','2','0','0','dbo','2023-01-30')
insert into #fw_req_ilbo
		(ilbocode, description, ASPOFilePath, progid, ILBOType, StatusFlag, req_2fa_tran, UpdUser, UpdTime)
values
		('CustomActionUI','Custom Action','CustomAction_CustomActionUI.asp','','2','0','0','dbo','2023-01-30')
insert into #fw_req_ilbo
		(ilbocode, description, ASPOFilePath, progid, ILBOType, StatusFlag, req_2fa_tran, UpdUser, UpdTime)
values
		('CustomUI','Custom UI','CustomAct_CustomUI.asp','','2','0','0','dbo','2023-01-30')
insert into #fw_req_ilbo
		(ilbocode, description, ASPOFilePath, progid, ILBOType, StatusFlag, req_2fa_tran, UpdUser, UpdTime)
values
		('LineUI','LineUI','LineActivity_LineUI.asp','','2','0','0','dbo','2023-01-30')
insert into #fw_req_ilbo
		(ilbocode, description, ASPOFilePath, progid, ILBOType, StatusFlag, req_2fa_tran, UpdUser, UpdTime)
values
		('ListViewUI','ListViewUI','ListViewAct_ListViewUI.asp','','2','0','0','dbo','2023-01-30')
insert into #fw_req_ilbo
		(ilbocode, description, ASPOFilePath, progid, ILBOType, StatusFlag, req_2fa_tran, UpdUser, UpdTime)
values
		('TestEnhanceUI','TestEnhanceUI','TestEnhance_TestEnhanceUI.asp','','2','0','0','dbo','2023-01-30')
insert into #fw_req_ilbo
		(ilbocode, description, ASPOFilePath, progid, ILBOType, StatusFlag, req_2fa_tran, UpdUser, UpdTime)
values
		('TestToolbarui','TestToolbarui','TestToolbar_TestToolbarui.asp','','2','0','0','dbo','2023-01-30')
insert into #fw_req_ilbo
		(ilbocode, description, ASPOFilePath, progid, ILBOType, StatusFlag, req_2fa_tran, UpdUser, UpdTime)
values
		('TestUI','TestUI','TestActivity_TestUI.asp','','2','0','0','dbo','2023-01-30')
----------------------------------------------------------------------------------------------------------------------------------------------
insert into #fw_req_activity_ilbo
		(ActivityId, activityname, ilbocode ,UpdUser, UpdTime)
values
		(299, 'TestActivity', 'TestUI', 'Installer', getdate() )
insert into #fw_req_activity_ilbo
		(ActivityId, activityname, ilbocode ,UpdUser, UpdTime)
values
		(304, 'LineActivity', 'LineUI', 'Installer', getdate() )
insert into #fw_req_activity_ilbo
		(ActivityId, activityname, ilbocode ,UpdUser, UpdTime)
values
		(305, 'CustomAction', 'CustomActionUI', 'Installer', getdate() )
insert into #fw_req_activity_ilbo
		(ActivityId, activityname, ilbocode ,UpdUser, UpdTime)
values
		(307, 'BorderAction', 'BorderActionui', 'Installer', getdate() )
insert into #fw_req_activity_ilbo
		(ActivityId, activityname, ilbocode ,UpdUser, UpdTime)
values
		(307, 'BorderAction', 'BorderRef', 'Installer', getdate() )
insert into #fw_req_activity_ilbo
		(ActivityId, activityname, ilbocode ,UpdUser, UpdTime)
values
		(309, 'TestEnhance', 'TestEnhanceUI', 'Installer', getdate() )
insert into #fw_req_activity_ilbo
		(ActivityId, activityname, ilbocode ,UpdUser, UpdTime)
values
		(310, 'CustomAct', 'CustomUI', 'Installer', getdate() )
insert into #fw_req_activity_ilbo
		(ActivityId, activityname, ilbocode ,UpdUser, UpdTime)
values
		(311, 'TestToolbar', 'TestToolbarui', 'Installer', getdate() )
insert into #fw_req_activity_ilbo
		(ActivityId, activityname, ilbocode ,UpdUser, UpdTime)
values
		(325, 'ColumnGrouping', 'ColgroupUI', 'Installer', getdate() )
insert into #fw_req_activity_ilbo
		(ActivityId, activityname, ilbocode ,UpdUser, UpdTime)
values
		(335, 'ListViewAct', 'ListViewUI', 'Installer', getdate() )
----------------------------------------------------------------------------------------------------------------------------------------------
insert into #fw_req_activity_local_info
		(ActivityId, activityname, LangId, ActivityDesc, HelpIndex, ToolTipText, UpdUser, UpdTime)
values
		(299,N'TestActivity',1,N'TestActivity', null, NULL, 'Installer', getdate())
insert into #fw_req_activity_local_info
		(ActivityId, activityname, LangId, ActivityDesc, HelpIndex, ToolTipText, UpdUser, UpdTime)
values
		(304,N'LineActivity',1,N'LineActivity', null, NULL, 'Installer', getdate())
insert into #fw_req_activity_local_info
		(ActivityId, activityname, LangId, ActivityDesc, HelpIndex, ToolTipText, UpdUser, UpdTime)
values
		(305,N'CustomAction',1,N'Custom Action', null, NULL, 'Installer', getdate())
insert into #fw_req_activity_local_info
		(ActivityId, activityname, LangId, ActivityDesc, HelpIndex, ToolTipText, UpdUser, UpdTime)
values
		(307,N'BorderAction',1,N'Border Action', null, NULL, 'Installer', getdate())
insert into #fw_req_activity_local_info
		(ActivityId, activityname, LangId, ActivityDesc, HelpIndex, ToolTipText, UpdUser, UpdTime)
values
		(309,N'TestEnhance',1,N'TestEnhance', null, NULL, 'Installer', getdate())
insert into #fw_req_activity_local_info
		(ActivityId, activityname, LangId, ActivityDesc, HelpIndex, ToolTipText, UpdUser, UpdTime)
values
		(310,N'CustomAct',1,N'Custom Activity', null, NULL, 'Installer', getdate())
insert into #fw_req_activity_local_info
		(ActivityId, activityname, LangId, ActivityDesc, HelpIndex, ToolTipText, UpdUser, UpdTime)
values
		(311,N'TestToolbar',1,N'TestToolbar', null, NULL, 'Installer', getdate())
insert into #fw_req_activity_local_info
		(ActivityId, activityname, LangId, ActivityDesc, HelpIndex, ToolTipText, UpdUser, UpdTime)
values
		(325,N'ColumnGrouping',1,N'Column  Grouping', null, NULL, 'Installer', getdate())
insert into #fw_req_activity_local_info
		(ActivityId, activityname, LangId, ActivityDesc, HelpIndex, ToolTipText, UpdUser, UpdTime)
values
		(335,N'ListViewAct',1,N'ListViewAct', null, NULL, 'Installer', getdate())
----------------------------------------------------------------------------------------------------------------------------------------------
insert into #fw_req_component_local_info
		(ComponentName, LangId, ComponentDesc, HelpFileName, ToolTipText, UpdUser, UpdTime )
values
		('TestComponent', 1,N'TestComponent', NULL, '', 'Installer', getdate() )
----------------------------------------------------------------------------------------------------------------------------------------------
insert into #fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime)
values
		( 'TCBrActSrcustat', 'TestComponent', 2, 0, 0, 'Installer', getdate())
insert into #fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime)
values
		( 'TCBrActSrfet', 'TestComponent', 0, 0, 0, 'Installer', getdate())
insert into #fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime)
values
		( 'TCBrActSrlinkcu', 'TestComponent', 2, 0, 0, 'Installer', getdate())
insert into #fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime)
values
		( 'TCBrActSrpopcon', 'TestComponent', 2, 0, 0, 'Installer', getdate())
insert into #fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime)
values
		( 'TCBrActSrSave1', 'TestComponent', 2, 0, 0, 'Installer', getdate())
insert into #fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime)
values
		( 'TCBrActSrsmartv', 'TestComponent', 2, 0, 0, 'Installer', getdate())
insert into #fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime)
values
		( 'TCBrActSrtestli', 'TestComponent', 2, 0, 0, 'Installer', getdate())
insert into #fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime)
values
		( 'TCBrActSr_Hp_custah', 'TestComponent', 2, 0, 0, 'Installer', getdate())
insert into #fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime)
values
		( 'TCmacreeSrfet', 'TestComponent', 0, 0, 0, 'Installer', getdate())
insert into #fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime)
values
		( 'TCmacreeSrsubmit', 'TestComponent', 2, 0, 0, 'Installer', getdate())
insert into #fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime)
values
		( 'TCmains3SrEmploy', 'TestComponent', 2, 0, 0, 'Installer', getdate())
insert into #fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime)
values
		( 'TCmains3Srfet', 'TestComponent', 0, 0, 0, 'Installer', getdate())
insert into #fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime)
values
		( 'TCmains3Srinit', 'TestComponent', 0, 0, 0, 'Installer', getdate())
insert into #fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime)
values
		( 'TCmainscSrBubBu2', 'TestComponent', 0, 0, 0, 'Installer', getdate())
insert into #fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime)
values
		( 'TCmainscSrBubMan', 'TestComponent', 2, 0, 0, 'Installer', getdate())
insert into #fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime)
values
		( 'TCmainscSrBubRef', 'TestComponent', 2, 0, 0, 'Installer', getdate())
insert into #fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime)
values
		( 'TCmainscSrfet', 'TestComponent', 0, 0, 0, 'Installer', getdate())
insert into #fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime)
values
		( 'TCmainscSrSave1', 'TestComponent', 2, 0, 0, 'Installer', getdate())
insert into #fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime)
values
		( 'TCmainscSrTestBu', 'TestComponent', 0, 0, 0, 'Installer', getdate())
insert into #fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime)
values
		( 'TCmainseSrfet', 'TestComponent', 0, 0, 0, 'Installer', getdate())
insert into #fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime)
values
		( 'TCmainsnSrfet', 'TestComponent', 0, 0, 0, 'Installer', getdate())
insert into #fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime)
values
		( 'TCmainsnSrHdrLin', 'TestComponent', 2, 0, 0, 'Installer', getdate())
insert into #fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime)
values
		( 'TCmainsnSrinit', 'TestComponent', 0, 0, 0, 'Installer', getdate())
insert into #fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime)
values
		( 'TCmainsnSrlinkco', 'TestComponent', 2, 0, 0, 'Installer', getdate())
insert into #fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime)
values
		( 'TCmainsnSrLnkCtr', 'TestComponent', 2, 0, 0, 'Installer', getdate())
insert into #fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime)
values
		( 'TCmainsnSrsavebt', 'TestComponent', 2, 0, 0, 'Installer', getdate())
insert into #fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime)
values
		( 'TCmainsnSrSaveTe', 'TestComponent', 2, 0, 0, 'Installer', getdate())
insert into #fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime)
values
		( 'TCmainsnSr_Hp_AddHlp', 'TestComponent', 2, 0, 0, 'Installer', getdate())
insert into #fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime)
values
		( 'TCmainsnSr_Hp_DeducH', 'TestComponent', 2, 0, 0, 'Installer', getdate())
insert into #fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime)
values
		( 'TCmainsnSr_Hp_edithe', 'TestComponent', 2, 0, 0, 'Installer', getdate())
insert into #fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime)
values
		( 'TCmnscnSrfet', 'TestComponent', 0, 0, 0, 'Installer', getdate())
insert into #fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime)
values
		( 'TCmnscnSrSave', 'TestComponent', 2, 0, 0, 'Installer', getdate())
insert into #fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime)
values
		( 'TCmnscrnSrfet', 'TestComponent', 0, 0, 0, 'Installer', getdate())
insert into #fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime)
values
		( 'TCmnscrnSrSave', 'TestComponent', 2, 0, 0, 'Installer', getdate())
----------------------------------------------------------------------------------------------------------------------------------------------
insert into #fw_admin_Activity_Service
		(ActivityId, activityname, ServiceName, UpdUser, UpdTime)
values
		(299, 'TestActivity','TCmainscSrBubBu2', 'Installer', getdate())
insert into #fw_admin_Activity_Service
		(ActivityId, activityname, ServiceName, UpdUser, UpdTime)
values
		(299, 'TestActivity','TCmainscSrBubMan', 'Installer', getdate())
insert into #fw_admin_Activity_Service
		(ActivityId, activityname, ServiceName, UpdUser, UpdTime)
values
		(299, 'TestActivity','TCmainscSrBubRef', 'Installer', getdate())
insert into #fw_admin_Activity_Service
		(ActivityId, activityname, ServiceName, UpdUser, UpdTime)
values
		(299, 'TestActivity','TCmainscSrfet', 'Installer', getdate())
insert into #fw_admin_Activity_Service
		(ActivityId, activityname, ServiceName, UpdUser, UpdTime)
values
		(299, 'TestActivity','TCmainscSrSave1', 'Installer', getdate())
insert into #fw_admin_Activity_Service
		(ActivityId, activityname, ServiceName, UpdUser, UpdTime)
values
		(299, 'TestActivity','TCmainscSrTestBu', 'Installer', getdate())
insert into #fw_admin_Activity_Service
		(ActivityId, activityname, ServiceName, UpdUser, UpdTime)
values
		(305, 'CustomAction','TCmainseSrfet', 'Installer', getdate())
insert into #fw_admin_Activity_Service
		(ActivityId, activityname, ServiceName, UpdUser, UpdTime)
values
		(307, 'BorderAction','TCmainsnSrfet', 'Installer', getdate())
insert into #fw_admin_Activity_Service
		(ActivityId, activityname, ServiceName, UpdUser, UpdTime)
values
		(307, 'BorderAction','TCmainsnSrHdrLin', 'Installer', getdate())
insert into #fw_admin_Activity_Service
		(ActivityId, activityname, ServiceName, UpdUser, UpdTime)
values
		(307, 'BorderAction','TCmainsnSrinit', 'Installer', getdate())
insert into #fw_admin_Activity_Service
		(ActivityId, activityname, ServiceName, UpdUser, UpdTime)
values
		(307, 'BorderAction','TCmainsnSrLnkCtr', 'Installer', getdate())
insert into #fw_admin_Activity_Service
		(ActivityId, activityname, ServiceName, UpdUser, UpdTime)
values
		(307, 'BorderAction','TCmainsnSrsavebt', 'Installer', getdate())
insert into #fw_admin_Activity_Service
		(ActivityId, activityname, ServiceName, UpdUser, UpdTime)
values
		(307, 'BorderAction','TCmainsnSrSaveTe', 'Installer', getdate())
insert into #fw_admin_Activity_Service
		(ActivityId, activityname, ServiceName, UpdUser, UpdTime)
values
		(307, 'BorderAction','TCmainsnSr_Hp_AddHlp', 'Installer', getdate())
insert into #fw_admin_Activity_Service
		(ActivityId, activityname, ServiceName, UpdUser, UpdTime)
values
		(307, 'BorderAction','TCmainsnSr_Hp_DeducH', 'Installer', getdate())
insert into #fw_admin_Activity_Service
		(ActivityId, activityname, ServiceName, UpdUser, UpdTime)
values
		(309, 'TestEnhance','TCBrActSrcustat', 'Installer', getdate())
insert into #fw_admin_Activity_Service
		(ActivityId, activityname, ServiceName, UpdUser, UpdTime)
values
		(309, 'TestEnhance','TCBrActSrfet', 'Installer', getdate())
insert into #fw_admin_Activity_Service
		(ActivityId, activityname, ServiceName, UpdUser, UpdTime)
values
		(309, 'TestEnhance','TCBrActSrlinkcu', 'Installer', getdate())
insert into #fw_admin_Activity_Service
		(ActivityId, activityname, ServiceName, UpdUser, UpdTime)
values
		(309, 'TestEnhance','TCBrActSrpopcon', 'Installer', getdate())
insert into #fw_admin_Activity_Service
		(ActivityId, activityname, ServiceName, UpdUser, UpdTime)
values
		(309, 'TestEnhance','TCBrActSrSave1', 'Installer', getdate())
insert into #fw_admin_Activity_Service
		(ActivityId, activityname, ServiceName, UpdUser, UpdTime)
values
		(309, 'TestEnhance','TCBrActSrsmartv', 'Installer', getdate())
insert into #fw_admin_Activity_Service
		(ActivityId, activityname, ServiceName, UpdUser, UpdTime)
values
		(309, 'TestEnhance','TCBrActSrtestli', 'Installer', getdate())
insert into #fw_admin_Activity_Service
		(ActivityId, activityname, ServiceName, UpdUser, UpdTime)
values
		(310, 'CustomAct','TCmacreeSrfet', 'Installer', getdate())
insert into #fw_admin_Activity_Service
		(ActivityId, activityname, ServiceName, UpdUser, UpdTime)
values
		(310, 'CustomAct','TCmacreeSrsubmit', 'Installer', getdate())
insert into #fw_admin_Activity_Service
		(ActivityId, activityname, ServiceName, UpdUser, UpdTime)
values
		(311, 'TestToolbar','TCmnscrnSrfet', 'Installer', getdate())
insert into #fw_admin_Activity_Service
		(ActivityId, activityname, ServiceName, UpdUser, UpdTime)
values
		(325, 'ColumnGrouping','TCmains3SrEmploy', 'Installer', getdate())
insert into #fw_admin_Activity_Service
		(ActivityId, activityname, ServiceName, UpdUser, UpdTime)
values
		(325, 'ColumnGrouping','TCmains3Srfet', 'Installer', getdate())
insert into #fw_admin_Activity_Service
		(ActivityId, activityname, ServiceName, UpdUser, UpdTime)
values
		(325, 'ColumnGrouping','TCmains3Srinit', 'Installer', getdate())
insert into #fw_admin_Activity_Service
		(ActivityId, activityname, ServiceName, UpdUser, UpdTime)
values
		(335, 'ListViewAct','TCmnscnSrfet', 'Installer', getdate())
insert into #fw_admin_Activity_Service
		(ActivityId, activityname, ServiceName, UpdUser, UpdTime)
values
		(335, 'ListViewAct','TCmnscnSrSave', 'Installer', getdate())
----------------------------------------------------------------------------------------------------------------------------------------------
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCBorActcustaccustaiLk','Link','Custom Action for the Control custactionctrl - custactionlink','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCBorActcustaccustatTr','Trans','Custom Action for the Control custactionctrl - custactbutton','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCBorActcustaclinkcuLk','Link','Custom Action for the Control custactionctrl - linkcustact','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCBorActcustacpopconTr','Trans','Custom Action for the Control custactionctrl - popcontroltrans','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCBorActcustacsmartvLk','Link','Custom Action for the Control custactionctrl - smartviewlnk','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCBorActcustactestliLk','Link','Custom Action for the Control custactionctrl - testlink','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmacreeCustAcLk','Link','Link to Link','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmacreeCustAtLk','Link','Link to Trans','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmacreeCustLLLk','Link','Link to Link3','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmacreeCustLsLk','Link','Link to Link1','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmacreeCustLtLk','Link','Link to Link2','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmacreeCustPoLk','Link','Link to Link','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmacreeFth','Fetch','Default Fetch','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmacreesubmitTr','Trans','Submit','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmaincrFth','Fetch','Default Fetch','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmaincrInit','initialize','Initialize','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmains1Fth','Fetch','Default Fetch','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmains1Save1Tr','Trans','Save','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmains1SidebaLk','Link','Link to Sidebar Link','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmains1SidebrTr','Trans','Sidebar Save','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmains3EmployUi','UI','On Select of Employee Code','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmains3Fth','Fetch','Default Fetch','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmains3Init','initialize','Initialize','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmains5Fth','Fetch','Default Fetch','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmains5Save1Tr','Trans','Save','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmainscBubbleTr','Trans','Bubble Manual','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmainscBubblRTr','Trans','Bubble Refined','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmainscBubButTr','Trans','Bub Button2','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmainscFth','Fetch','Default Fetch','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmainscSave1Tr','Trans','Save','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmainscTestBuTr','Trans','Test Button','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmainseFth','Fetch','Default Fetch','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmainsehelp1Lk','Link','Link to Help','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmainselink1Lk','Link','Link to Link','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmainsesave1Lk','Link','Link to Save','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmainsnaddresAddHlpHp','Help','Custom Action for the Control address1 - AddHlp','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmainsnaddresLnkCtrLk','Link','Link to LnkCtrl','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmainsnaddresSaveTeTr','Trans','SaveTest','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmainsndeductDeducHHp','Help','Custom Action for the Control deductionreason - DeductHlp','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmainsndeductHdrLinLk','Link','Custom Action for the Control deductionreason - HdrLink','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmainsnempcodcode11Hp','Help','Custom Action for the Control empcode - code1','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmainsnempcodcode21Lk','Link','Custom Action for the Control empcode - code2','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmainsnemplnafirstnHp','Help','Custom Action for the Control emplname - firstname','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmainsnFth','Fetch','Default Fetch','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmainsnInit','initialize','Initialize','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmainsninsurainslinLk','Link','Custom Action for the Control insurancedtls - inslink','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmainsninsurainstraTr','Trans','Custom Action for the Control insurancedtls - instrans','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmainsnsavebtTr','Trans','Save','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmainsrFth','Fetch','Default Fetch','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmcreenFth','Fetch','Default Fetch','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCmcreenSave1Tr','Trans','Save','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCTab11Tab1Title1Lk','Link','Title Action for the Section Tab1Hdrsec - Title Link','dbo','2023-01-30')
insert into #fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
values
		('TCTab11Tab1Title2Tr','Trans','Title Action for the Section Tab1Hdrsec - Title Save','dbo','2023-01-30')
IF EXISTS (SELECT '*' FROM INFORMATION_SCHEMA.COLUMNS (nolock) WHERE  TABLE_NAME = 'fw_req_activity_ilbo_task' and COLUMN_NAME = 'ServiceName' )
BEGIN
----------------------------------------------------------------------------------------------------------------------------------------------

insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(299,'TestActivity','TestUI','TCmainscBubbleTr','Installer', getdate() ,0,0,0, 'TCmainscSrBubMan'	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(299,'TestActivity','TestUI','TCmainscBubblRTr','Installer', getdate() ,0,0,0, 'TCmainscSrBubRef'	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(299,'TestActivity','TestUI','TCmainscBubButTr','Installer', getdate() ,0,0,0, 'TCmainscSrBubBu2'	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(299,'TestActivity','TestUI','TCmainscFth','Installer', getdate() ,0,0,0, 'TCmainscSrfet'	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(299,'TestActivity','TestUI','TCmainscSave1Tr','Installer', getdate() ,0,0,0, 'TCmainscSrSave1'	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(299,'TestActivity','TestUI','TCmainscTestBuTr','Installer', getdate() ,0,0,0, 'TCmainscSrTestBu'	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(304,'LineActivity','LineUI','TCmainsrFth','Installer', getdate() ,0,0,0, ''	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(305,'CustomAction','CustomActionUI','TCmainseFth','Installer', getdate() ,0,0,0, 'TCmainseSrfet'	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(305,'CustomAction','CustomActionUI','TCmainsehelp1Lk','Installer', getdate() ,0,0,0, ''	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(305,'CustomAction','CustomActionUI','TCmainselink1Lk','Installer', getdate() ,0,0,0, ''	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(305,'CustomAction','CustomActionUI','TCmainsesave1Lk','Installer', getdate() ,0,0,0, ''	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(307,'BorderAction','BorderActionui','TCmainsnaddresAddHlpHp','Installer', getdate() ,0,0,0, 'TCmainsnSr_Hp_AddHlp'	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(307,'BorderAction','BorderActionui','TCmainsnaddresLnkCtrLk','Installer', getdate() ,0,0,0, 'TCmainsnSrLnkCtr'	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(307,'BorderAction','BorderActionui','TCmainsnaddresSaveTeTr','Installer', getdate() ,0,0,0, 'TCmainsnSrSaveTe'	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(307,'BorderAction','BorderActionui','TCmainsndeductDeducHHp','Installer', getdate() ,0,0,0, 'TCmainsnSr_Hp_DeducH'	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(307,'BorderAction','BorderActionui','TCmainsndeductHdrLinLk','Installer', getdate() ,0,0,0, 'TCmainsnSrHdrLin'	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(307,'BorderAction','BorderActionui','TCmainsnempcodcode11Hp','Installer', getdate() ,0,0,0, ''	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(307,'BorderAction','BorderActionui','TCmainsnempcodcode21Lk','Installer', getdate() ,0,0,0, ''	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(307,'BorderAction','BorderActionui','TCmainsnemplnafirstnHp','Installer', getdate() ,0,0,0, ''	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(307,'BorderAction','BorderActionui','TCmainsnFth','Installer', getdate() ,0,0,0, 'TCmainsnSrfet'	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(307,'BorderAction','BorderActionui','TCmainsnInit','Installer', getdate() ,0,0,0, 'TCmainsnSrinit'	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(307,'BorderAction','BorderActionui','TCmainsninsurainslinLk','Installer', getdate() ,0,0,0, ''	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(307,'BorderAction','BorderActionui','TCmainsninsurainstraTr','Installer', getdate() ,0,0,0, ''	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(307,'BorderAction','BorderActionui','TCmainsnsavebtTr','Installer', getdate() ,0,0,0, 'TCmainsnSrsavebt'	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(307,'BorderAction','BorderRef','TCmaincrFth','Installer', getdate() ,0,0,0, ''	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(307,'BorderAction','BorderRef','TCmaincrInit','Installer', getdate() ,0,0,0, ''	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(309,'TestEnhance','TestEnhanceUI','TCBorActcustaccustaiLk','Installer', getdate() ,0,0,0, ''	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(309,'TestEnhance','TestEnhanceUI','TCBorActcustaccustatTr','Installer', getdate() ,0,0,0, 'TCBrActSrcustat'	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(309,'TestEnhance','TestEnhanceUI','TCBorActcustaclinkcuLk','Installer', getdate() ,0,0,0, 'TCBrActSrlinkcu'	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(309,'TestEnhance','TestEnhanceUI','TCBorActcustacpopconTr','Installer', getdate() ,0,0,0, 'TCBrActSrpopcon'	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(309,'TestEnhance','TestEnhanceUI','TCBorActcustacsmartvLk','Installer', getdate() ,0,0,0, 'TCBrActSrsmartv'	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(309,'TestEnhance','TestEnhanceUI','TCBorActcustactestliLk','Installer', getdate() ,0,0,0, 'TCBrActSrtestli'	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(309,'TestEnhance','TestEnhanceUI','TCmcreenFth','Installer', getdate() ,0,0,0, 'TCBrActSrfet'	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(309,'TestEnhance','TestEnhanceUI','TCmcreenSave1Tr','Installer', getdate() ,0,0,0, 'TCBrActSrSave1'	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(310,'CustomAct','CustomUI','TCmacreeCustAcLk','Installer', getdate() ,0,0,0, ''	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(310,'CustomAct','CustomUI','TCmacreeCustAtLk','Installer', getdate() ,0,0,0, ''	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(310,'CustomAct','CustomUI','TCmacreeCustLLLk','Installer', getdate() ,0,0,0, ''	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(310,'CustomAct','CustomUI','TCmacreeCustLsLk','Installer', getdate() ,0,0,0, ''	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(310,'CustomAct','CustomUI','TCmacreeCustLtLk','Installer', getdate() ,0,0,0, ''	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(310,'CustomAct','CustomUI','TCmacreeCustPoLk','Installer', getdate() ,0,0,0, ''	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(310,'CustomAct','CustomUI','TCmacreeFth','Installer', getdate() ,0,0,0, 'TCmacreeSrfet'	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(310,'CustomAct','CustomUI','TCmacreesubmitTr','Installer', getdate() ,0,0,0, 'TCmacreeSrsubmit'	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(311,'TestToolbar','TestToolbarui','TCmains1Fth','Installer', getdate() ,0,0,0, 'TCmnscrnSrfet'	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(311,'TestToolbar','TestToolbarui','TCmains1Save1Tr','Installer', getdate() ,0,0,0, ''	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(311,'TestToolbar','TestToolbarui','TCmains1SidebaLk','Installer', getdate() ,0,0,0, ''	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(311,'TestToolbar','TestToolbarui','TCmains1SidebrTr','Installer', getdate() ,0,0,0, ''	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(311,'TestToolbar','TestToolbarui','TCTab11Tab1Title1Lk','Installer', getdate() ,0,0,0, ''	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(311,'TestToolbar','TestToolbarui','TCTab11Tab1Title2Tr','Installer', getdate() ,0,0,0, ''	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(325,'ColumnGrouping','ColgroupUI','TCmains3EmployUi','Installer', getdate() ,0,0,0, 'TCmains3SrEmploy'	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(325,'ColumnGrouping','ColgroupUI','TCmains3Fth','Installer', getdate() ,0,0,0, 'TCmains3Srfet'	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(325,'ColumnGrouping','ColgroupUI','TCmains3Init','Installer', getdate() ,0,0,0, 'TCmains3Srinit'	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(335,'ListViewAct','ListViewUI','TCmains5Fth','Installer', getdate() ,0,0,0, 'TCmnscnSrfet'	)
insert into #fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
values
		(335,'ListViewAct','ListViewUI','TCmains5Save1Tr','Installer', getdate() ,0,0,0, 'TCmnscnSrSave'	)
END
ELSE
BEGIN
----------------------------------------------------------------------------------------------------------------------------------------------
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(299,'TestActivity','TestUI','TCmainscBubbleTr','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(299,'TestActivity','TestUI','TCmainscBubblRTr','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(299,'TestActivity','TestUI','TCmainscBubButTr','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(299,'TestActivity','TestUI','TCmainscFth','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(299,'TestActivity','TestUI','TCmainscSave1Tr','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(299,'TestActivity','TestUI','TCmainscTestBuTr','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(304,'LineActivity','LineUI','TCmainsrFth','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(305,'CustomAction','CustomActionUI','TCmainseFth','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(305,'CustomAction','CustomActionUI','TCmainsehelp1Lk','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(305,'CustomAction','CustomActionUI','TCmainselink1Lk','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(305,'CustomAction','CustomActionUI','TCmainsesave1Lk','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(307,'BorderAction','BorderActionui','TCmainsnaddresAddHlpHp','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(307,'BorderAction','BorderActionui','TCmainsnaddresLnkCtrLk','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(307,'BorderAction','BorderActionui','TCmainsnaddresSaveTeTr','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(307,'BorderAction','BorderActionui','TCmainsndeductDeducHHp','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(307,'BorderAction','BorderActionui','TCmainsndeductHdrLinLk','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(307,'BorderAction','BorderActionui','TCmainsnempcodcode11Hp','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(307,'BorderAction','BorderActionui','TCmainsnempcodcode21Lk','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(307,'BorderAction','BorderActionui','TCmainsnemplnafirstnHp','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(307,'BorderAction','BorderActionui','TCmainsnFth','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(307,'BorderAction','BorderActionui','TCmainsnInit','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(307,'BorderAction','BorderActionui','TCmainsninsurainslinLk','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(307,'BorderAction','BorderActionui','TCmainsninsurainstraTr','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(307,'BorderAction','BorderActionui','TCmainsnsavebtTr','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(307,'BorderAction','BorderRef','TCmaincrFth','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(307,'BorderAction','BorderRef','TCmaincrInit','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(309,'TestEnhance','TestEnhanceUI','TCBorActcustaccustaiLk','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(309,'TestEnhance','TestEnhanceUI','TCBorActcustaccustatTr','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(309,'TestEnhance','TestEnhanceUI','TCBorActcustaclinkcuLk','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(309,'TestEnhance','TestEnhanceUI','TCBorActcustacpopconTr','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(309,'TestEnhance','TestEnhanceUI','TCBorActcustacsmartvLk','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(309,'TestEnhance','TestEnhanceUI','TCBorActcustactestliLk','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(309,'TestEnhance','TestEnhanceUI','TCmcreenFth','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(309,'TestEnhance','TestEnhanceUI','TCmcreenSave1Tr','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(310,'CustomAct','CustomUI','TCmacreeCustAcLk','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(310,'CustomAct','CustomUI','TCmacreeCustAtLk','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(310,'CustomAct','CustomUI','TCmacreeCustLLLk','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(310,'CustomAct','CustomUI','TCmacreeCustLsLk','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(310,'CustomAct','CustomUI','TCmacreeCustLtLk','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(310,'CustomAct','CustomUI','TCmacreeCustPoLk','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(310,'CustomAct','CustomUI','TCmacreeFth','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(310,'CustomAct','CustomUI','TCmacreesubmitTr','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(311,'TestToolbar','TestToolbarui','TCmains1Fth','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(311,'TestToolbar','TestToolbarui','TCmains1Save1Tr','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(311,'TestToolbar','TestToolbarui','TCmains1SidebaLk','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(311,'TestToolbar','TestToolbarui','TCmains1SidebrTr','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(311,'TestToolbar','TestToolbarui','TCTab11Tab1Title1Lk','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(311,'TestToolbar','TestToolbarui','TCTab11Tab1Title2Tr','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(325,'ColumnGrouping','ColgroupUI','TCmains3EmployUi','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(325,'ColumnGrouping','ColgroupUI','TCmains3Fth','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(325,'ColumnGrouping','ColgroupUI','TCmains3Init','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(335,'ListViewAct','ListViewUI','TCmains5Fth','Installer', getdate() ,0,0,0	)
insert into #fw_req_activity_ilbo_task
		(ActivityId, Activityname,ILBOCode, TaskName, UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
values
		(335,'ListViewAct','ListViewUI','TCmains5Save1Tr','Installer', getdate() ,0,0,0	)
END
----------------------------------------------------------------------------------------------------------------------------------------------
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(299,'TestActivity','TestUI',N'TestUI', 'TCmainscBubbleTr',N'Bubble Manual', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(299,'TestActivity','TestUI',N'TestUI', 'TCmainscBubblRTr',N'Bubble Refined', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(299,'TestActivity','TestUI',N'TestUI', 'TCmainscBubButTr',N'Bub Button2', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(299,'TestActivity','TestUI',N'TestUI', 'TCmainscFth',N'Default Fetch', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(299,'TestActivity','TestUI',N'TestUI', 'TCmainscSave1Tr',N'Save', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(299,'TestActivity','TestUI',N'TestUI', 'TCmainscTestBuTr',N'Test Button', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(304,'LineActivity','LineUI',N'LineUI', 'TCmainsrFth',N'Default Fetch', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(305,'CustomAction','CustomActionUI',N'Custom Action', 'TCmainseFth',N'Default Fetch', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(305,'CustomAction','CustomActionUI',N'Custom Action', 'TCmainsehelp1Lk',N'Link to Help', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(305,'CustomAction','CustomActionUI',N'Custom Action', 'TCmainselink1Lk',N'Link to Link', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(305,'CustomAction','CustomActionUI',N'Custom Action', 'TCmainsesave1Lk',N'Link to Save', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(307,'BorderAction','BorderActionui',N'BorderActionui', 'TCmainsnaddresAddHlpHp',N'Custom Action for the Control address1 - AddHlp', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(307,'BorderAction','BorderActionui',N'BorderActionui', 'TCmainsnaddresLnkCtrLk',N'Custom Action for the Control address1 - LnkCtrl', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(307,'BorderAction','BorderActionui',N'BorderActionui', 'TCmainsnaddresSaveTeTr',N'SaveTest', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(307,'BorderAction','BorderActionui',N'BorderActionui', 'TCmainsndeductDeducHHp',N'Custom Action for the Control deductionreason - DeductHlp', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(307,'BorderAction','BorderActionui',N'BorderActionui', 'TCmainsndeductHdrLinLk',N'Custom Action for the Control deductionreason - HdrLink', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(307,'BorderAction','BorderActionui',N'BorderActionui', 'TCmainsnempcodcode11Hp',N'Custom Action for the Control empcode - code1', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(307,'BorderAction','BorderActionui',N'BorderActionui', 'TCmainsnempcodcode21Lk',N'Custom Action for the Control empcode - code2', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(307,'BorderAction','BorderActionui',N'BorderActionui', 'TCmainsnemplnafirstnHp',N'Custom Action for the Control emplname - firstname', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(307,'BorderAction','BorderActionui',N'BorderActionui', 'TCmainsnFth',N'Default Fetch', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(307,'BorderAction','BorderActionui',N'BorderActionui', 'TCmainsnInit',N'Initialize', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(307,'BorderAction','BorderActionui',N'BorderActionui', 'TCmainsninsurainslinLk',N'Custom Action for the Control insurancedtls - inslink', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(307,'BorderAction','BorderActionui',N'BorderActionui', 'TCmainsninsurainstraTr',N'Custom Action for the Control insurancedtls - instrans', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(307,'BorderAction','BorderActionui',N'BorderActionui', 'TCmainsnsavebtTr',N'Save', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(307,'BorderAction','BorderRef',N'BorderRef', 'TCmaincrFth',N'Default Fetch', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(307,'BorderAction','BorderRef',N'BorderRef', 'TCmaincrInit',N'Initialize', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(309,'TestEnhance','TestEnhanceUI',N'TestEnhanceUI', 'TCBorActcustaccustaiLk',N'Custom Action for the Control custactionctrl - custactionlink', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(309,'TestEnhance','TestEnhanceUI',N'TestEnhanceUI', 'TCBorActcustaccustatTr',N'Custom Action for the Control custactionctrl - custactbutton', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(309,'TestEnhance','TestEnhanceUI',N'TestEnhanceUI', 'TCBorActcustaclinkcuLk',N'Custom Action for the Control custactionctrl - linkcustact', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(309,'TestEnhance','TestEnhanceUI',N'TestEnhanceUI', 'TCBorActcustacpopconTr',N'Custom Action for the Control custactionctrl - popcontroltrans', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(309,'TestEnhance','TestEnhanceUI',N'TestEnhanceUI', 'TCBorActcustacsmartvLk',N'Custom Action for the Control custactionctrl - smartviewlnk', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(309,'TestEnhance','TestEnhanceUI',N'TestEnhanceUI', 'TCBorActcustactestliLk',N'Custom Action for the Control custactionctrl - testlink', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(309,'TestEnhance','TestEnhanceUI',N'TestEnhanceUI', 'TCmcreenFth',N'Default Fetch', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(309,'TestEnhance','TestEnhanceUI',N'TestEnhanceUI', 'TCmcreenSave1Tr',N'Save', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(310,'CustomAct','CustomUI',N'Custom UI', 'TCmacreeCustAcLk',N'Link to Link', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(310,'CustomAct','CustomUI',N'Custom UI', 'TCmacreeCustAtLk',N'Link to Trans', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(310,'CustomAct','CustomUI',N'Custom UI', 'TCmacreeCustLLLk',N'Link to Link3', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(310,'CustomAct','CustomUI',N'Custom UI', 'TCmacreeCustLsLk',N'Link to Link1', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(310,'CustomAct','CustomUI',N'Custom UI', 'TCmacreeCustLtLk',N'Link to Link2', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(310,'CustomAct','CustomUI',N'Custom UI', 'TCmacreeCustPoLk',N'Link to Link', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(310,'CustomAct','CustomUI',N'Custom UI', 'TCmacreeFth',N'Default Fetch', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(310,'CustomAct','CustomUI',N'Custom UI', 'TCmacreesubmitTr',N'Submit', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(311,'TestToolbar','TestToolbarui',N'TestToolbarui', 'TCmains1Fth',N'Default Fetch', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(311,'TestToolbar','TestToolbarui',N'TestToolbarui', 'TCmains1Save1Tr',N'Save', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(311,'TestToolbar','TestToolbarui',N'TestToolbarui', 'TCmains1SidebaLk',N'Link to Sidebar Link', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(311,'TestToolbar','TestToolbarui',N'TestToolbarui', 'TCmains1SidebrTr',N'Sidebar Save', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(311,'TestToolbar','TestToolbarui',N'TestToolbarui', 'TCTab11Tab1Title1Lk',N'Title Action for the Section Tab1Hdrsec - Title Link', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(311,'TestToolbar','TestToolbarui',N'TestToolbarui', 'TCTab11Tab1Title2Tr',N'Title Action for the Section Tab1Hdrsec - Title Save', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(325,'ColumnGrouping','ColgroupUI',N'Column Grouping', 'TCmains3EmployUi',N'On Select of Employee Code', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(325,'ColumnGrouping','ColgroupUI',N'Column Grouping', 'TCmains3Fth',N'Default Fetch', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(325,'ColumnGrouping','ColgroupUI',N'Column Grouping', 'TCmains3Init',N'Initialize', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(335,'ListViewAct','ListViewUI',N'ListViewUI', 'TCmains5Fth',N'Default Fetch', 1, 'Installer', getdate()	)
insert into #fw_req_activity_ilbo_task_local_info
		(ActivityId, activityname , ILBOCode, ILBODescription, TaskName, TaskDesc, LangId , UpdUser  , UpdTime)
values
		(335,'ListViewAct','ListViewUI',N'ListViewUI', 'TCmains5Save1Tr',N'Save', 1, 'Installer', getdate()	)
----------------------------------------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------------------
insert into #fw_admin_application_dtl
		(DepConfiguredAppName, ApplicationDescription, ApplicationMode, UpdUser, UpdTime )
values
		( 'unify_ol','DepApp ID For RAMCO Unify - Offline Activities', 'include','admin', sysdatetime())
insert into #fw_admin_application_dtl
		(DepConfiguredAppName, ApplicationDescription, ApplicationMode, UpdUser, UpdTime )
values
		( 'unify','DepApp ID For RAMCO Unify - Online Activities', 'include','admin', sysdatetime())
----------------------------------------------------------------------------------------------------------------------------------------------
insert into #fw_admin_application_activity_map
		(DepConfiguredAppName, ActivityName, UpdUser, UpdTime )
values
		( 'unify','testenhance', 'admin', sysdatetime())
----------------------------------------------------------------------------------------------------------------------------------------------
if exists (
	select * from sysobjects (nolock) where name = 'fw_req_ilbo_control' and xtype = 'U')
begin
	insert into #fw_req_ilbo_control(ilbocode,ControlID,Type,TabName,UpdUser,UpdTime) values ( 'ColgroupUI', 'MLEmpGrid', N'RSGrid', NULL, '', getdate()
	)
end

if exists (
	select * from sysobjects (nolock) where name = 'fw_req_ilbo_control' and xtype = 'U')
begin
	insert into #fw_req_ilbo_control(ilbocode,ControlID,Type,TabName,UpdUser,UpdTime) values ( 'TestUI', 'MLGrid', N'RSGrid', NULL, '', getdate()
	)
end

if exists (
	select * from sysobjects (nolock) where name = 'fw_req_ilbo_control' and xtype = 'U')
begin
	insert into #fw_req_ilbo_control(ilbocode,ControlID,Type,TabName,UpdUser,UpdTime) values ( 'ListViewUI', 'MLGridDetails', N'RSGrid', NULL, '', getdate()
	)
end

if exists (
	select * from sysobjects (nolock) where name = 'fw_req_ilbo_control' and xtype = 'U')
begin
	insert into #fw_req_ilbo_control(ilbocode,ControlID,Type,TabName,UpdUser,UpdTime) values ( 'TestToolbarui', 'MLtab2grid', N'RSGrid', 'Tab2', '', getdate()
	)
end

----------------------------------------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------------------
update #fw_req_activity
set  activityid = activityid + @ActivityOffset

update #fw_req_activity_ilbo
set  activityid = activityid + @ActivityOffset

update #fw_req_activity_local_info
set  activityid = activityid + @ActivityOffset

update #fw_admin_Activity_Service
set  activityid = activityid + @ActivityOffset

update #fw_req_activity_task
set  activityid = activityid + @ActivityOffset

update #fw_req_activity_ilbo_task
set  activityid = activityid + @ActivityOffset

update #fw_admin_linked_activities
set  activityid = activityid + @ActivityOffset

update #fw_req_activity_ilbo_task_local_info
set  activityid = activityid + @ActivityOffset

update #fw_req_activity_ilbo_task_apispec
set  activityid = activityid + @ActivityOffset

----------------------------------------------------------------------------------------------------------------------------------------------
-- update  a
-- set  a.UpdUser   = b.UpdUser, 
	-- a.UpdTime    = b.UpdTime
-- from fw_admin_dep_components_tmp a,
		-- #fw_admin_dep_components_tmp b
-- where b.ComponentName  collate database_default = a.ComponentName
-- and  b.DepComponentName collate database_default = a.DepComponentName
-- and  b.IntegLayer         = a.IntegLayer

update  a
set  a.ComponentDesc  = b.ComponentDesc, 
		a.ParentProcess  = b.ParentProcess, 
		a.UpdUser   = b.UpdUser, 
		a.UpdTime    = b.UpdTime
from fw_req_process_component a,
		#fw_req_process_component b
where b.ComponentName collate database_default = a.ComponentName

if not exists (select '*' from INFORMATION_SCHEMA.COLUMNS (nolock) where TABLE_NAME = 'fw_req_activity' and COLUMN_NAME = 'IsForcedActivity' )
begin
update  a
set  a.ActivityName  = b.ActivityName, 
		a.ActivityDesc  = b.ActivityDesc, 
		a.ComponentName  = b.ComponentName, 
		a.ActivityType  = b.ActivityType, 
		a.ActivityPosition = b.ActivityPosition, 
		a.ActivitySequence = b.ActivitySequence, 
		a.IsWFEnabled  = b.IsWFEnabled, 
		a.UpdUser   = b.UpdUser, 
		a.UpdTime    = b.UpdTime
from fw_req_activity a,
		#fw_req_activity b
where b.ActivityName   collate database_default = a.ActivityName

end
if exists (select '*' from INFORMATION_SCHEMA.COLUMNS (nolock) where TABLE_NAME = 'fw_req_activity' and COLUMN_NAME = 'IsForcedActivity' )
begin
update  a
set  a.ActivityName  = b.ActivityName, 
		a.ActivityDesc  = b.ActivityDesc, 
		a.ComponentName  = b.ComponentName, 
		a.ActivityType  = b.ActivityType, 
		a.ActivityPosition = b.ActivityPosition, 
		a.ActivitySequence = b.ActivitySequence, 
		a.IsWFEnabled  = b.IsWFEnabled, 
		a.UpdUser   = b.UpdUser, 
		a.UpdTime    = b.UpdTime,
a.IsForcedActivity    = b.IsForcedActivity
from fw_req_activity a,
		#fw_req_activity b
where b.ActivityName   collate database_default = a.ActivityName

end
if not exists (select '*' from INFORMATION_SCHEMA.COLUMNS (nolock) where TABLE_NAME = 'fw_req_ilbo' and COLUMN_NAME = 'req_2fa_tran' )
begin
update  a
set  a.description = b.description, 
		a.ASPOFilePath = b.ASPOFilePath, 
		a.progid  = b.progid, 
		a.ILBOType  = b.ILBOType, 
		a.StatusFlag = b.StatusFlag, 
		a.UpdUser  = b.UpdUser, 
		a.UpdTime   = b.UpdTime
from fw_req_ilbo a,
		#fw_req_ilbo b
where b.ILBOCode  collate database_default = a.ILBOCode

end
if exists (select '*' from INFORMATION_SCHEMA.COLUMNS (nolock) where TABLE_NAME = 'fw_req_ilbo' and COLUMN_NAME = 'req_2fa_tran' )
begin
update  a
set  a.description = b.description, 
		a.ASPOFilePath = b.ASPOFilePath, 
		a.progid  = b.progid, 
		a.ILBOType  = b.ILBOType, 
		a.StatusFlag = b.StatusFlag, 
		a.req_2fa_tran = b.req_2fa_tran, 
		a.UpdUser  = b.UpdUser, 
		a.UpdTime   = b.UpdTime
from fw_req_ilbo a,
		#fw_req_ilbo b
where b.ILBOCode  collate database_default = a.ILBOCode

end
-- update  a
-- set  a.UpdUser  = b.UpdUser, 
		-- a.UpdTime   = b.UpdTime
-- from fw_req_activity_ilbo a,
		-- #fw_req_activity_ilbo b
-- where a.ActivityId  = b.ActivityId
-- and  b.ILBOCode   collate database_default = a.ILBOCode

update  a
set  a.ActivityDesc = b.ActivityDesc, 
		a.HelpIndex  = b.HelpIndex, 
		a.ToolTipText = b.ToolTipText, 
		a.UpdUser  = b.UpdUser, 
		a.UpdTime   = b.UpdTime
from fw_req_activity_local_info a,
		#fw_req_activity_local_info b
where b.ActivityName  collate database_default = a.ActivityName
and  b.LangId   = a.LangId

update  a
set  a.ComponentDesc = b.ComponentDesc,
		a.HelpFileName = b.HelpFileName, 
		a.ToolTipText = b.ToolTipText, 
		a.UpdUser  = b.UpdUser, 
		a.UpdTime   = b.UpdTime
from fw_req_component_local_info a,
		#fw_req_component_local_info b
where b.ComponentName collate database_default = a.ComponentName
and  b.LangId          = a.LangId

update  a
set  a.ComponentName = b.ComponentName, 
		a.ServiceType = b.ServiceType, 
		a.IsIntegSer = b.IsIntegSer, 
		a.StatusFlag = b.StatusFlag, 
		a.UpdUser  = b.UpdUser, 
		a.UpdTime   = b.UpdTime
from fw_des_service a,
		#fw_des_service b
where b.ServiceName  collate database_default = a.ServiceName

update  a
set  a.ToValidate = b.ToValidate
from fw_des_service a,
		#fw_des_service b
where b.ServiceName  collate database_default = a.ServiceName
and  b.ToValidate is not null

-- update  a
-- set  a.UpdUser  = b.UpdUser, 
		-- a.UpdTime   = b.UpdTime
-- from fw_admin_Activity_Service a,
		-- #fw_admin_Activity_Service b
-- where b.ActivityId         = a.ActivityId
-- and  b.ServiceName  collate database_default = a.ServiceName

update  a
set  a.TaskType  = b.TaskType, 
		a.TaskDesc  = b.TaskDesc, 
		a.UpdUser  = b.UpdUser, 
		a.UpdTime   = b.UpdTime
from fw_req_task a,
		#fw_req_task b
where b.TaskName   collate database_default = a.TaskName

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'fw_req_activity_task'AND XTYPE='U')
BEGIN
update  a
set  a.InvocationType = b.InvocationType, 
		a.TaskSequence  = b.TaskSequence, 
		a.UpdUser   = b.UpdUser, 
		a.UpdTime    = b.UpdTime
from fw_req_activity_task a,
		#fw_req_activity_task b
where b.ActivityName          collate database_default = a.ActivityName
and  b.TaskName    collate database_default = a.TaskName
End
IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'fw_req_activity_ilbo_task'AND XTYPE='U')
BEGIN
IF EXISTS (SELECT '*' FROM INFORMATION_SCHEMA.COLUMNS (NOLOCK) WHERE  
TABLE_NAME = 'fw_req_activity_ilbo_task' AND COLUMN_NAME = 'ServiceName'  )

BEGIN 
update  a 
set  a.UpdUser   = b.UpdUser, 
		a.UpdTime   = b.UpdTime, 
		a.DataSavingTask = b.DataSavingTask, 
		a.LinkType   = b.LinkType, 
		a.Taskconfirmation  = b.Taskconfirmation, 
a.Servicename       = b.ServiceName
from fw_req_activity_ilbo_task  a,
		#fw_req_activity_ilbo_task  b
where b.ActivityName          = a.ActivityName
and  b.ILBOCode    collate database_default = a.ILBOCode
and  b.TaskName    collate database_default = a.TaskName
End
End
IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'fw_req_activity_ilbo_task'AND XTYPE='U')
BEGIN 
update  a 
set  a.UpdUser   = b.UpdUser, 
		a.UpdTime   = b.UpdTime, 
		a.DataSavingTask = b.DataSavingTask, 
		a.LinkType   = b.LinkType, 
		a.Taskconfirmation  = b.Taskconfirmation
from fw_req_activity_ilbo_task  a,
		#fw_req_activity_ilbo_task  b
where b.ActivityName  collate database_default = a.ActivityName
and  b.ILBOCode    collate database_default = a.ILBOCode
and  b.TaskName    collate database_default = a.TaskName
End
IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'fw_req_activity_ilbo_task_local_info'AND XTYPE='U')
BEGIN 
update  a 
set a.ILBODescription  = b.ILBODescription, 
a.TaskDesc  = b.TaskDesc,
a.UpdUser   = b.UpdUser, 
a.UpdTime   = b.UpdTime  
from fw_req_activity_ilbo_task_local_info  a, 
		#fw_req_activity_ilbo_task_local_info  b 
where b.ActivityName collate database_default = a.ActivityName 
and  b.ILBOCode    collate database_default = a.ILBOCode 
and  b.TaskName    collate database_default = a.TaskName 
End
IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'fw_req_ilbo_control'AND XTYPE='U')
BEGIN
update  a
set  a.Type  = b.Type, 
		a.TabName   = b.TabName, 
		a.UpdTime   = b.UpdTime 
		from fw_req_ilbo_control  a,
		#fw_req_ilbo_control  b
where  b.ilbocode    collate database_default = a.ilbocode
and  b.ControlID   collate database_default = a.ControlID
End
if @UpdateFlag = 1
begin
	update  a
	set  a.TotalLength = b.TotalLength, 
			a.DecimalLength = b.DecimalLength, 
			a.UpdUser  = b.UpdUser, 
			a.UpdTime   = b.UpdTime
	from fw_req_precision  a,
			#fw_req_precision  b
	where b.PrecisionType collate database_default = a.PrecisionType
end

insert  into fw_req_process_component
		(ComponentName , ComponentDesc , ParentProcess , UpdUser , UpdTime , SequenceNo)
select  distinct a.ComponentName , a.ComponentDesc , a.ParentProcess , a.UpdUser , a.UpdTime , a.SequenceNo
from #fw_req_process_component a
where a.ComponentName collate database_default not in 
	(select distinct ComponentName from fw_req_process_component (nolock))

if not exists (select '*' from INFORMATION_SCHEMA.COLUMNS (nolock) where TABLE_NAME = 'fw_req_activity' and COLUMN_NAME = 'IsForcedActivity' )
begin
insert  into fw_req_activity
		(ActivityId, ActivityName, ActivityDesc, ComponentName, ActivityType, ActivityPosition, ActivitySequence, IsWFEnabled, UpdUser, UpdTime)
select  distinct a.ActivityId, a.ActivityName, a.ActivityDesc, a.ComponentName, a.ActivityType, a.ActivityPosition, a.ActivitySequence, a.IsWFEnabled, a.UpdUser, a.UpdTime
from #fw_req_activity a
where a.ActivityName collate database_default not in 
	(select distinct ActivityName from fw_req_activity (nolock))

end
if exists (select '*' from INFORMATION_SCHEMA.COLUMNS (nolock) where TABLE_NAME = 'fw_req_activity' and COLUMN_NAME = 'IsForcedActivity' )
begin
insert  into fw_req_activity
		(ActivityId, ActivityName, ActivityDesc, ComponentName, ActivityType, ActivityPosition, ActivitySequence, IsWFEnabled, UpdUser, UpdTime,IsForcedActivity)
select  distinct a.ActivityId, a.ActivityName, a.ActivityDesc, a.ComponentName, a.ActivityType, a.ActivityPosition, a.ActivitySequence, a.IsWFEnabled, a.UpdUser, a.UpdTime, a.IsForcedActivity
from #fw_req_activity a
where a.ActivityName collate database_default not in 
	(select distinct ActivityName from fw_req_activity (nolock))

end
if not exists (select '*' from INFORMATION_SCHEMA.COLUMNS (nolock) where TABLE_NAME = 'fw_req_ilbo' and COLUMN_NAME = 'req_2fa_tran' )
begin
insert into fw_req_ilbo
		(ilbocode, description, ASPOFilePath, progid, ILBOType, StatusFlag,  UpdUser, UpdTime)
select  distinct a.ilbocode, a.description, a.ASPOFilePath, a.progid, a.ILBOType, a.StatusFlag,  a.UpdUser, a.UpdTime
from #fw_req_ilbo a
where a.ILBOCode collate database_default not in 
	(select distinct ILBOCode from fw_req_ilbo (nolock))

end
if exists (select '*' from INFORMATION_SCHEMA.COLUMNS (nolock) where TABLE_NAME = 'fw_req_ilbo' and COLUMN_NAME = 'req_2fa_tran' )
begin
insert into fw_req_ilbo
		(ilbocode, description, ASPOFilePath, progid, ILBOType, StatusFlag, req_2fa_tran, UpdUser, UpdTime)
select  distinct a.ilbocode, a.description, a.ASPOFilePath, a.progid, a.ILBOType, a.StatusFlag, a.req_2fa_tran, a.UpdUser, a.UpdTime
from #fw_req_ilbo a
where a.ILBOCode collate database_default not in 
	(select distinct ILBOCode from fw_req_ilbo (nolock))

end
insert into fw_req_activity_ilbo
		(ActivityId,activityname, ilbocode, UpdUser, UpdTime)
select  distinct a.ActivityId,a.activityname, a.ilbocode, a.UpdUser, a.UpdTime
from #fw_req_activity_ilbo a
where a.ActivityName + a.ILBOCode  collate database_default not in 
	(select ActivityName + ILBOCode  from fw_req_activity_ilbo (nolock))

insert into fw_req_activity_local_info
		(ActivityId, activityname, LangId, ActivityDesc, HelpIndex, ToolTipText, UpdUser, UpdTime)
select  distinct a.ActivityId, a.activityname, a.LangId, a.ActivityDesc, a.HelpIndex, a.ToolTipText, a.UpdUser, a.UpdTime
from #fw_req_activity_local_info a
where a.ActivityName + cast(a.LangId as varchar(10)) collate database_default not in 
	(select distinct ActivityName + cast(LangId as varchar(10)) from fw_req_activity_local_info (nolock))

insert into fw_req_component_local_info
		(ComponentName, LangId, ComponentDesc, HelpFileName, ToolTipText, UpdUser, UpdTime)
select distinct a.ComponentName, a.LangId, a.ComponentDesc, a.HelpFileName, a.ToolTipText, a.UpdUser, a.UpdTime 
from #fw_req_component_local_info a
where a.ComponentName + cast(a.LangId as varchar(10)) collate database_default not in 
		(select distinct ComponentName + cast(LangId as varchar(10)) from fw_req_component_local_info (nolock))

insert into fw_des_service
		(ServiceName, ComponentName, ServiceType, IsIntegSer, StatusFlag, UpdUser, UpdTime, ToValidate)
select  distinct a.ServiceName, a.ComponentName, a.ServiceType, a.IsIntegSer, a.StatusFlag, a.UpdUser, a.UpdTime, isnull(a.ToValidate,'')
from #fw_des_service a
where a.ServiceName collate database_default not in 
		(select distinct ServiceName from fw_des_service (nolock))

insert into fw_admin_Activity_Service
		(ActivityId, activityname ,ServiceName, UpdUser, UpdTime)
select distinct a.ActivityId, A.activityname ,a.ServiceName, a.UpdUser, getdate()
from #fw_admin_Activity_Service a
where a.ActivityName + a.ServiceName collate database_default not in 
		(select distinct activityname + ServiceName  from fw_admin_Activity_Service (nolock))

insert into fw_req_task
		(TaskName, TaskType, TaskDesc, UpdUser, UpdTime)
select  distinct rtrim(a.TaskName), a.TaskType, a.TaskDesc, a.UpdUser, a.UpdTime
from #fw_req_task a
where a.TaskName collate database_default not in 
		(select distinct TaskName from fw_req_task (nolock))

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'fw_req_activity_task'AND XTYPE='U')
BEGIN
Insert into fw_req_activity_task
		(ActivityId, activityname , TaskName, InvocationType, TaskSequence, UpdUser, UpdTime)
select  distinct a.ActivityId, a.activityname , a.TaskName, a.InvocationType, a.TaskSequence, a.UpdUser, a.UpdTime
from #fw_req_activity_task a
where a.ActivityName + a.TaskName collate database_default not in 
		(select ActivityName + TaskName  from fw_req_activity_task (nolock))
End

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'fw_req_activity_ilbo_task'AND XTYPE='U')
BEGIN
IF EXISTS (SELECT '*' FROM INFORMATION_SCHEMA.COLUMNS (nolock) WHERE  TABLE_NAME = 'fw_req_activity_ilbo_task' AND COLUMN_NAME = 'ServiceName')
BEGIN
insert into fw_req_activity_ilbo_task
		(ActivityId,activityname , ILBOCode, TaskName ,UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation, ServiceName)
select distinct  A.ActivityId,A.activityname , A.ILBOCode, rtrim(A.TaskName), A.UpdUser, A.UpdTime, A.DataSavingTask, A.LinkType, A.Taskconfirmation, A.Servicename
from #fw_req_activity_ilbo_task  A
where a.ActivityName +  + a.ILBOCode + a.TaskName collate database_default not in 
		(select distinct ActivityName + ILBOCode + TaskName  from fw_req_activity_ilbo_task (nolock))
End
ELSE
BEGIN

insert into fw_req_activity_ilbo_task
		(ActivityId,ActivityName , ILBOCode, TaskName ,UpdUser, UpdTime, DataSavingTask, LinkType, Taskconfirmation)
select distinct  A.ActivityId, A.ActivityName,A.ILBOCode, rtrim(A.TaskName), A.UpdUser, A.UpdTime, A.DataSavingTask, A.LinkType, A.Taskconfirmation
from #fw_req_activity_ilbo_task  A
where a.ActivityName + a.ILBOCode + a.TaskName collate database_default not in 
		(select distinct ActivityName + ILBOCode + TaskName  from fw_req_activity_ilbo_task (nolock))
END
END
IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'fw_req_activity_ilbo_task_local_info'AND XTYPE='U')
BEGIN
insert into fw_req_activity_ilbo_task_local_info
		(ActivityId,activityname, ILBOCode, ILBODescription ,TaskName,TaskDesc ,LangId , UpdUser, UpdTime)
select distinct  A.ActivityId, A.activityname , A.ILBOCode, A.ILBODescription , rtrim(A.TaskName), A.TaskDesc , a.langid , a.UpdUser, a.UpdTime
from #fw_req_activity_ilbo_task_local_info  A
where a.ActivityName + a.ILBOCode + rtrim(a.TaskName) + CAST(a.Langid AS VARCHAR(10)) collate database_default not in 
		(select distinct ActivityName + ILBOCode + rtrim(TaskName) + CAST(Langid AS VARCHAR(10))  from fw_req_activity_ilbo_task_local_info (nolock))
End

insert into fw_req_precision
		(PrecisionType, TotalLength, DecimalLength, UpdUser, UpdTime)
select distinct  a.PrecisionType, a.TotalLength, a.DecimalLength, a.UpdUser, a.UpdTime
from #fw_req_precision  a
where a.PrecisionType collate database_default not in 
		(select distinct PrecisionType from fw_req_precision (nolock))

if exists (select '*' from INFORMATION_SCHEMA.COLUMNS (nolock) where TABLE_NAME = 'fw_admin_meta_state' )
begin
insert  into fw_admin_meta_state
		( ActivityName, ILBOCode, ControlID, ControlDesc, ViewName, ViewDesc, TabName, TabDesc, IsHeaderControl)
select  distinct a.ActivityName, a.ILBOCode, a.ControlID, a.ControlDesc, a.ViewName, a.ViewDesc, a.TabName, a.TabDesc, a.IsHeaderControl
from #fw_admin_meta_state a
where a.ActivityName+ a.ILBOCode+a.ControlID+a.ViewName collate database_default not in 
	(select distinct ActivityName+ ILBOCode+ControlID+ViewName from fw_admin_meta_state (nolock))

end
if exists (select '*' from INFORMATION_SCHEMA.COLUMNS (nolock) where TABLE_NAME = 'fw_admin_application_dtl' )
begin
insert  into fw_admin_application_dtl
		( DepConfiguredAppName, ApplicationDescription, ApplicationMode, UpdUser, UpdTime)
select  distinct a.DepConfiguredAppName, a.ApplicationDescription,a.ApplicationMode, a.UpdUser, a.UpdTime
from #fw_admin_application_dtl a
where a.DepConfiguredAppName  collate database_default not in 
	(select distinct DepConfiguredAppName from fw_admin_application_dtl (nolock))

end
if exists (select '*' from INFORMATION_SCHEMA.COLUMNS (nolock) where TABLE_NAME = 'fw_admin_application_dtl' and COLUMN_NAME = 'ApplicationDescription' )
begin
update  a
set  a.ApplicationDescription    = b.ApplicationDescription
from fw_admin_application_dtl a,
		#fw_admin_application_dtl b
where b.DepConfiguredAppName   collate database_default = a.DepConfiguredAppName

end
if exists (select '*' from INFORMATION_SCHEMA.COLUMNS (nolock) where TABLE_NAME = 'fw_admin_application_activity_map' )
begin
insert  into fw_admin_application_activity_map
		( DepConfiguredAppName, ActivityName, UpdUser, UpdTime)
select  distinct a.DepConfiguredAppName, a.ActivityName, a.UpdUser, a.UpdTime
from #fw_admin_application_activity_map a
where a.DepConfiguredAppName+ a.ActivityName collate database_default not in 
	(select distinct DepConfiguredAppName+ ActivityName from fw_admin_application_activity_map (nolock))

end
insert into fw_admin_linked_activities
		(ActivityName,LinkedActivityName,ActivityID, LinkedActivityID)
select distinct  a.ActivityName, a.LinkedActivityName, a.ActivityID, a.LinkedActivityID
from #fw_admin_linked_activities  a
where ActivityName + LinkedActivityName collate database_default not in 
		(select distinct ActivityName + LinkedActivityName from fw_admin_linked_activities (nolock))

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'fw_req_activity_ilbo_task_apispec'AND XTYPE='U')
BEGIN
IF EXISTS (SELECT '*' FROM INFORMATION_SCHEMA.COLUMNS (nolock) WHERE  TABLE_NAME = 'fw_req_activity_ilbo_task_apispec' )
BEGIN
insert into fw_req_activity_ilbo_task_apispec
		( ActivityName, ILBOCode, TaskName, ApiSpecID, ApiSpecName, ApiVersion, ApiPath, ApiOperationVerb, ApiOperationID, ThirdParty, UpdUser, UpdTime)
select distinct  A.ActivityName, A.ILBOCode, rtrim(A.TaskName), a.ApiSpecID, a.ApiSpecName, a.ApiVersion, a.ApiPath, a.ApiOperationVerb, a.ApiOperationID, a.ThirdParty, A.UpdUser, A.UpdTime
from #fw_req_activity_ilbo_task_apispec  A
where a.ActivityName  + a.ILBOCode + a.TaskName + a.ApiSpecID + a.ApiVersion + a.ApiPath + a.ApiOperationVerb collate database_default not in 
		(select distinct ActivityName + ILBOCode + TaskName + a.ApiSpecID + a.ApiVersion + a.ApiPath + a.ApiOperationVerb  from fw_req_activity_ilbo_task_apispec (nolock))
End
End

SET NOCOUNT OFF
End
GO
Exec testcomponent_Metadata
GO
