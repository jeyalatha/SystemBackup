IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME ='testcomponent_Metadata_Language' AND XTYPE='P')
BEGIN	DROP PROC testcomponent_Metadata_Language
End
GO
Create Procedure testcomponent_Metadata_Language 
As
Begin
SET NOCOUNT ON
-- This Deployment (Language) script is generated from Platform Model Server : TECHWARCNV18\INST3 Database Name : Maint_rvw20appdb Component : testcomponent ECR  : TC_ECR_00053
create table #fw_req_language (LangId int, Langdesc nvarchar(160), UpdUser nvarchar(20), UpdTime datetime)
----------------------------------------------------------------------------------------------------------------------------------------------
insert into #fw_req_language
		(LangId, Langdesc, UpdUser, UpdTime)
Values
		(1, 'English', 'Installer', getdate())
insert into #fw_req_language
		(LangId, Langdesc, UpdUser, UpdTime)
Values
		(2, 'German', 'Installer', getdate())
----------------------------------------------------------------------------------------------------------------------------------------------
update 	a
set 	a.Langdesc	= b.Langdesc,
		a.UpdUser			= b.UpdUser, 
		a.UpdTime 			= b.UpdTime
from	fw_req_language a,
		#fw_req_language b
where	b.LangId = a.LangId

----------------------------------------------------------------------------------------------------------------------------------------------
insert into fw_req_language
		(LangId, Langdesc, UpdUser, UpdTime)
select  distinct a.LangId, a.Langdesc, a.UpdUser, a.UpdTime
from	#fw_req_language a
where	a.LangId not in 
(select distinct LangId from fw_req_language (nolock))

SET NOCOUNT OFF
End
GO
Exec testcomponent_Metadata_Language
GO
